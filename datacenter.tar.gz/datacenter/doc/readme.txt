doc http://192.168.10.220:806/category/datacenter

<?php
define("APP_PATH",  realpath(dirname(__FILE__) . '/../')); /* 指向public的上一级 */
$app  = new \Yaf\Application(APP_PATH . "/conf/appcron.ini");
$app->bootstrap()->getDispatcher()->dispatch(new \Yaf\Request\Simple());

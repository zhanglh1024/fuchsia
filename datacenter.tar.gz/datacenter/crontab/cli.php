<?php
define("APP_PATH",  realpath(dirname(__FILE__) . '/../')); /* 指向public的上一级 */
$app  = new \Yaf\Application(APP_PATH . "/conf/appcron.ini");
//file  module  controller action
$params = array();
foreach($argv as $k => $arg)
{
	if($k == 1)
	{
		$module = $arg;
	}
	elseif($k == 2)
	{
		$controller = $arg;
	}
	elseif($k == 3)
	{
		$action = $arg;
	}
	elseif($k >= 4)
	{
		$params[] = $arg;
	}
}
$app->bootstrap()->getDispatcher()->dispatch(new \Yaf\Request\Simple('CLI',$module,$controller,$action,array('params' =>$params)));

<?php
//cgi for goserver with controller and method
//must echo json_encode
//gosever并发请求响应入口，直接请求logic层，格式为manage\member\UserMemberLogic::getMemberBaseInfo
$modules = isset($_GET['controller']) ? $_GET['controller'] : false;
$action = isset($_GET['method']) ? $_GET['method'] : false;
if(!$modules || !$action)
{
	echo json_encode(array('flag' => false, 'msg'=> 'it must have controller and action'));
}
else
{
	define("APP_PATH",  realpath(dirname(__FILE__) . '/../')); /* 指向public的上一级 */
	$app  = new \Yaf\Application(APP_PATH . "/conf/appcron.ini");
	$params = file_get_contents("php://input");
	$paramsArr = json_decode($params, true);
	$app->bootstrap();//启动引入资源
	//引入logic并调用对应方法
	$modules = 'logic\\' . $modules;
	$logic = new $modules;
	$result = call_user_func_array(array($logic, $action), null == $paramsArr ? array($params) : $paramsArr);
	echo json_encode($result);
}

<?php
use lib\manage\finance\FinanceLib;
use tests\TestCase;
use \core\ModBase;
class FinanceLibTest extends TestCase
{
	private $lib;
	private $enameId;
	private $mod;

	public function __construct()
	{
		$this->enameId = 561305;
		$this->lib = new \lib\manage\finance\FinanceLib($this->enameId);
		$this->mod = new ModBase('finance');
	}

	public function testGetUserFinance()
	{
		$info = $this->mod->getRow("select * from e_finances where EnameId = $this->enameId", "", array());
		$info['UseMoney'] = $info['PublicMoney'] + $info['UnWithdrawalMoney'] + $info['WithdrawalMoney'] + $info['MarginMoney'];
		$rs = $this->lib->getUserFinance();
		$this->assertEquals($rs, $info, "getUserFinance出错1");
	}

	public function testFinanceOut()
	{
		$rs = $this->lib->FinanceOut(2000000000000, 1);
		$this->assertFalse($rs, "FinanceOut出错1");
		$rs = $this->lib->FinanceOut(10, 1);
		$this->assertTrue($rs, "FinanceOut出错2");
	}

	public function testConfirmFinanceOut()
	{
		$orderId = 115692;
		$order = $this->mod->getRow("select * from e_finance_orders where orderid = $orderId", "", array());
		// 		$this->lib->setFreezeMoneySort(json_decode($order['FreezeMoneySort'], TRUE));
		// 		$rs = $this->lib->confirmFinanceOut(29999999999999);
		// 		$this->assertFalse($rs, "confirmFinanceOut出错1");
		$this->lib->setFreezeMoney($order['Price']);
		$this->lib->setFreezeType($order['OrderType']);
		$this->lib->setAdminId('99999');
		$this->lib->setFreezeMoneySort(json_decode($order['FreezeMoneySort'], TRUE));
		$rs = $this->lib->confirmFinanceOut(115692);
		$this->assertTrue($rs, "confirmFinanceOut出错1");
	}

	public function testCancelFinanceOut()
	{
		$orderId = 115692;
		$order = $this->mod->getRow("select * from e_finance_orders where orderid = $orderId", "", array());
		$this->lib->setFreezeMoneySort(json_decode($order['FreezeMoneySort'], TRUE));
		$this->lib->setFreezeMoney($order['Price']);
		$rs = $this->lib->cancelFinanceOut();
		$this->assertTrue($rs, "cancelFinanceOut出错1");
	}
}

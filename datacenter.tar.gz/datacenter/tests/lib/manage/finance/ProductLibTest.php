<?php
use lib\manage\finance\ProductLib;
use tests\TestCase;
use \core\ModBase;
class ProductLibTest extends TestCase
{
	private $lib;
	private $enameId;
	private $mod;

	public function __construct()
	{
		$this->enameId = 561305;
		$this->lib = new \lib\manage\finance\ProductLib($this->enameId);
		$this->mod = new ModBase('product');
	}
	
	public function testGetPrice()
	{
		$info = $this->mod->getRow("select Price from e_products a, e_products_price b where a.ProductId = b.ProductId  and a.ProductId = 1 and b.GroupId = 1", "", array());
		$prices = unserialize($info['Price']);
		$this->lib->getProductById(1);
		$rs = $this->lib->getPrice(1);
		$this->assertEquals($rs, $prices[1], "getPrice出错1");
		$rs = $this->lib->getPrice();
		$this->assertEquals($rs, $prices, "getPrice出错2");
	}
	
	public function testGetProductCost()
	{
		$info = $this->mod->getRow("select ProductCost from e_products a, e_products_price b where a.ProductId = b.ProductId  and a.ProductId = 1 and b.GroupId = 1", "", array());
		$prices = unserialize($info['ProductCost']);
		$this->lib->getProductById(1);
		$rs = $this->lib->getProductCost(1);
		$this->assertEquals($rs, $prices[1], "getProductCost出错1");
		$rs = $this->lib->getProductCost();
		$this->assertEquals($rs, $prices, "getProductCost出错2");
	}

	public function testGetProductList()
	{
		$info = $this->mod->select("select * from e_products a, e_products_price b where a.ProductId = b.ProductId and a.ProductStatus = 1 and b.GroupId = 1 and a.ProductType = 1 order by ProductSort DESC", "", array());
		$this->lib->setProductType(1);
		$this->lib->setGroupId(1);
		$rs = $this->lib->getProductList();
		$this->assertEquals($rs, $info, "getProductList出错1");
	}
	
	public function testGetDomainProductList()
	{
		$rs = $this->lib->getDomainProductList();
	}

	public function testGetProductById()
	{
		$info = $this->mod->getRow("select * from e_products a, e_products_price b where a.ProductId = b.ProductId and a.ProductId = 1 and b.GroupId = 1", "", array());
		$info['Price'] = unserialize($info['Price']);
		$rs = $this->lib->getProductById(1);
		$this->assertEquals($rs, $info, "getProductById出错1");
	}

	public function testGetProductByName()
	{
		$info = $this->mod->getRow("select * from e_products a, e_products_price b where a.ProductId = b.ProductId and a.productName = '.cn' and b.GroupId = 1 and a.producttype = 1", "", array());
		$info['Price'] = unserialize($info['Price']);
		$rs = $this->lib->getProductByName('.cn', 1, 1);
		$this->assertEquals($rs, $info, "getProductById出错1");
	}
}

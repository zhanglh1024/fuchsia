<?php
use lib\manage\finance\FinanceInfoLib;
use tests\TestCase;
class OrderLogicTest extends TestCase
{
	private $lib;

	public function __construct()
	{
		$this->lib = new \lib\manage\finance\FinanceInfoLib(561305);
	}

	public function testAddUserFinanceMoney()
	{
		$money = 20;
		$info = $this->lib->getUserFinance();
		$this->lib->setAddMoney($money);
		$this->lib->setMoneyType(1);
		$this->lib->setFinanceType(1);
		$rs = $this->lib->addUserFinanceMoney();
		$newInfo = $this->lib->getUserFinance();
		$info['PublicMoney'] += $money;
		$info['UseMoney'] += $money;
		$this->assertEquals($newInfo, $info, 'addUserFinance出错1');

		$info = $this->lib->getUserFinance();
		$this->lib->setAddMoney($money);
		$this->lib->setMoneyType(2);
		$this->lib->setFinanceType(1);
		$rs = $this->lib->addUserFinanceMoney();
		$newInfo = $this->lib->getUserFinance();
		$info['UnWithdrawalMoney'] += $money;
		$info['UseMoney'] += $money;
		$this->assertEquals($newInfo, $info, 'addUserFinance出错2');

		$info = $this->lib->getUserFinance();
		$this->lib->setAddMoney($money);
		$this->lib->setMoneyType(3);
		$this->lib->setFinanceType(1);
		$rs = $this->lib->addUserFinanceMoney();
		$newInfo = $this->lib->getUserFinance();
		$info['WithdrawalMoney'] += $money;
		$info['UseMoney'] += $money;
		$this->assertEquals($newInfo, $info, 'addUserFinance出错3');

		$info = $this->lib->getUserFinance();
		$this->lib->setAddMoney($money);
		$this->lib->setMoneyType(4);
		$this->lib->setFinanceType(1);
		$rs = $this->lib->addUserFinanceMoney();
		$newInfo = $this->lib->getUserFinance();
		$info['MarginMoney'] += $money;
		$info['UseMoney'] += $money;
		$this->assertEquals($newInfo, $info, 'addUserFinance出错4');
	}

	public function testSubUserFinanceMoney()
	{
		$info = $this->lib->getUserFinance();
		$money = 80;
		$moneySort = array('p' => 20, 'u' => 20, 'w' => 20, 'm' => 20);
		$this->lib->setSubMoney($money);
		$this->lib->setFinanceType(1);
		$rs = $this->lib->subUserFinanceMoney($moneySort);
		$info['PublicMoney'] -= 20;
		$info['UnWithdrawalMoney'] -= 20;
		$info['WithdrawalMoney'] -= 20;
		$info['MarginMoney'] -= 20;
		$info['UseMoney'] -= $money;
		$newInfo = $this->lib->getUserFinance();
		$this->assertEquals($newInfo, $info, 'subUserFinanceMoney出错1');
	}

	public function testAddUserMoney()
	{
		$info = $this->lib->getUserFinance();
		$money = 80;
		$moneySort = array('p' => 20, 'u' => 20, 'w' => 20, 'm' => 20);
		$this->lib->setAddMoney($money);
		$this->lib->setFinanceType(2);
		$rs = $this->lib->addUserFinanceMoney($moneySort);
		$info['PublicMoney'] += 20;
		$info['UnWithdrawalMoney'] += 20;
		$info['WithdrawalMoney'] += 20;
		$info['MarginMoney'] += 20;
		$info['UseMoney'] += $money;
		$newInfo = $this->lib->getUserFinance();
		$this->assertEquals($newInfo, $info, 'addUserMoney出错1');
	}

	public function testSystemRefundMoney()
	{
		$info = $this->lib->getUserFinance();
		$money = 80;
		$moneySort = array('p' => 20, 'u' => 20, 'w' => 20, 'm' => 20);
		$rs = $this->lib->systemRefundMoney($moneySort);
		$info['PublicMoney'] += 20;
		$info['UnWithdrawalMoney'] += 20;
		$info['WithdrawalMoney'] += 20;
		$info['MarginMoney'] += 20;
		$info['UseMoney'] += $money;
		$newInfo = $this->lib->getUserFinance();
		$this->assertEquals($newInfo, $info, 'systemRefundMoney出错1');
	}

	public function testChangeUserFinance()
	{
		$info = $this->lib->getUserFinance();
		$this->lib->getUserFinance();
		$money = 80;
		$moneySort = array('p' => 20, 'u' => 20, 'w' => 20, 'm' => 20);
		$rs = $this->lib->changeUserFinance($moneySort);
		$info['PublicMoney'] -= 20;
		$info['UnWithdrawalMoney'] -= 20;
		$info['WithdrawalMoney'] -= 20;
		$info['MarginMoney'] -= 20;
		$info['UseMoney'] -= $money;
		$info['FreezeMoney'] += $money;
		$newInfo = $this->lib->getUserFinance();
		$this->assertEquals($newInfo, $info, 'changeUserFinance出错1');
	}

	public function testConfirmChangeUserFinance()
	{
		$money = 40;
		$moneySort = array('p' => 20, 'u' => 0, 'w' => 0, 'm' => 20);
		$info = $this->lib->getUserFinance();
		$this->lib->setSubMoney($money);
		$this->lib->setFinanceType(1);
		$rs = $this->lib->confirmChangeUserFinance($moneySort);
		$info['ConsumeMoney'] += $money;
		$info['FreezeMoney'] -= $money;
		$info['AllScore'] += $money;
		$info['TotalScore'] += $money;
		$newInfo = $this->lib->getUserFinance();
		$this->assertEquals($newInfo, $info, 'confirmChangeUserFinance出错1');
	}

	public function cancelChangeUserFinance($freezeMoneySort)
	{
		$money = 80;
		$moneySort = array('p' => 20, 'u' => 20, 'w' => 20, 'm' => 20);
		$info = $this->lib->getUserFinance();
		$rs = $this->lib->cancelChangeUserFinance($moneySort);
		$info['PublicMoney'] += 20;
		$info['UnWithdrawalMoney'] += 20;
		$info['WithdrawalMoney'] += 20;
		$info['MarginMoney'] += 20;
		$info['UseMoney'] += $money;
		$newInfo = $this->lib->getUserFinance();
		$this->assertEquals($newInfo, $info, 'cancelChangeUserFinance出错1');
	}

	public function testSetSort()
	{
		$info = $this->lib->getUserFinance();
		$rs = $this->lib->setSort(1, 10);
		$this->assertTrue($rs, 'setSort出错1');
		$rs = $this->lib->setSort(1, $info['UseMoney'] + 100);
		$this->assertFalse($rs, 'setSort出错2');
	}

	public function testSetScore()
	{
		$money = 80;
		$info = $this->lib->getUserFinance();
		$this->lib->setSubMoney($money);
		$this->lib->setFinanceType(1);
		$rs = $this->lib->setScore();
		$this->assertEquals($rs, $money, 'setScore出错1');
	}
}

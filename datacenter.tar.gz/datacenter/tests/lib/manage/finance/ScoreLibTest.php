<?php
use lib\manage\finance\ScoreLib;
use tests\TestCase;
use \core\ModBase;
class ScoreLibTest extends TestCase
{
	private $lib;
	private $enameId;
	private $mod;

	public function __construct()
	{
		$this->lib = new \lib\manage\finance\ScoreLib(561305);
		$this->mod = new ModBase('finance');
	}

	public function testAddScoreRecord()
	{
		$scoreLast = $this->mod->getRow("select max(scoreId) as maxId from e_finance_score where enameid = 561305", "", array());
		$finLib = new \lib\manage\finance\FinanceInfoLib(561305);
		$info = $finLib->getUserFinance();
		$score = 50;
		$this->lib->setScore($score);
		$this->lib->setCurrentScore($score + $info['TotalScore']);
		$this->lib->setOrderId(123456565);
		$this->lib->setScoreType(1);
		$this->lib->setScoreRemark('test.com');
		$rs = $this->lib->addScoreRecord();
		$this->assertEquals($rs, $scoreLast['maxId'] + 1, 'addScoreRecord出错1');
	}

	public function testSubScoreNum()
	{
		$finLib = new \lib\manage\finance\FinanceInfoLib(561305);
		$info = $finLib->getUserFinance();
		$score = 50;
		$rs = $this->lib->subScoreNum($score);
		$this->assertTrue($rs, 'subScoreNum出错1');
		$newInfo = $finLib->getUserFinance();
		$newInfo['TotalScore'] += $score;
		$this->assertEquals($info, $newInfo, 'subScoreNum出错2');
	}

	public function testAddScoreConsumerRecord()
	{
		$finLib = new \lib\manage\finance\FinanceInfoLib(561305);
		$info = $finLib->getUserFinance();
		$scoreLast = $this->mod->getRow("select max(`ConsumerId`) as maxId from e_finance_score_consumer where enameid = 561305", "", array());
		$score = 50;
		$this->lib->setScore($score);
		$this->lib->setCurrentScore($info['TotalScore'] - $score);
		$this->lib->setOrderId(123456);
		$this->lib->setScoreType(1);
		$this->lib->setScoreRemark('test test.com');
		$rs = $this->lib->addScoreConsumerRecord();
		$this->assertEquals($rs, $scoreLast['maxId'] + 1, 'subScoreNum出错2');
	}
}

<?php
use lib\manage\finance\OrderLib;
use tests\TestCase;
use \core\ModBase;
class OrderLibTest extends TestCase
{
	private $lib;
	private $enameId;
	private $mod;

	public function __construct()
	{
		$this->enameId = 561305;
		$this->lib = new \lib\manage\finance\OrderLib($this->enameId);
		$this->mod = new ModBase('finance');
	}
	
	public function testAddOrder()
	{
		$lastInfo = $this->mod->getRow("select max(orderId) as maxId from e_finance_orders", "", array());
		$moneySort = array('p' => 20, 'u' => 0, 'w' => 0, 'm' => 20);
		$this->lib->setFreezeMoneySort($moneySort);
		$this->lib->setDomain('test.com');
		$this->lib->setPrice(15);
		$this->lib->setLinkEnameId(358334);
		$this->lib->setRemark('test');
		$this->lib->setRemarkHide('');
		$this->lib->setAdminId(9999);
		$this->lib->setRegistarId(1);
		$this->lib->setOrderType(1);
		$rs = $this->lib->addOrder();
		$this->assertEquals($rs, $lastInfo['maxId'] + 1, 'addOrder出错1');
	}

	public function testUpdateOrderInfo()
	{
		$lastInfo = $this->mod->getRow("select max(orderId) as maxId from e_finance_orders where enameid = 561305", "", array());
		$oldInfo = $this->mod->getRow("select * from e_finance_orders where orderid = " . $lastInfo['maxId'], "", array());
		$rs = $this->lib->updateOrderInfo($lastInfo['maxId'], 35);
		$this->assertTrue($rs, 'updateOrderInfo出错1');
		$newInfo = $this->mod->getRow("select * from e_finance_orders where orderid = " . $lastInfo['maxId'], "", array());
		$oldInfo['Price'] = 35;
		$oldInfo['FreezeMoneySort'] = '[]';
		$oldInfo['UpdateTime'] = $newInfo['UpdateTime'];
		$this->assertEquals($newInfo, $oldInfo, 'updateOrderInfo出错2');
	}

	public function testGetOrderInfo()
	{
		$lastInfo = $this->mod->getRow("select max(orderId) as maxId from e_finance_orders where enameid = 561305", "", array());
		$info = $this->mod->getRow("select * from e_finance_orders where orderid = " . $lastInfo['maxId'], "", array());
		$rs = $this->lib->getOrderInfo($lastInfo['maxId']);
		$this->assertEquals($rs, $info, 'getOrderInfo出错1');
	}

	public function testConfirmOrder()
	{
		$lastInfo = $this->mod->getRow("select max(orderId) as maxId from e_finance_orders where enameid = 561305", "", array());
		$rs = $this->lib->confirmOrder($lastInfo['maxId']);
		$this->assertTrue($rs, 'confirmOrder出错1');
	}

	public function testCancelOrder()
	{
		$lastInfo = $this->mod->getRow("select max(orderId) as maxId from e_finance_orders where enameid = 561305", "", array());
		$rs = $this->lib->cancelOrder($lastInfo['maxId']);
		$this->assertTrue($rs, 'confirmOrder出错1');
	}
}

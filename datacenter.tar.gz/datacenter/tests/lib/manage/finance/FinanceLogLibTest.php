<?php
use lib\manage\finance\FinanceLib;
use tests\TestCase;
class FinanceLogLibTest extends TestCase
{
	private $lib;
	private $enameId;
	private $mod;

	public function __construct()
	{
		$this->lib = new \lib\manage\finance\FinanceLogLib();
	}

	public function testLog()
	{
		$this->lib->log('test desc', array('dfadfsdfdf'), TRUE, 1, 1);
	}
}

<?php
use lib\manage\finance\FinanceInLib;
use tests\TestCase;
use \core\ModBase;
class FinanceInLibTest extends TestCase
{
	private $lib;
	private $enameId;
	private $mod;

	public function __construct()
	{
		$this->enameId = 561305;
		$this->lib = new \lib\manage\finance\FinanceInLib($this->enameId);
		$this->finLib = new \lib\manage\finance\FinanceInfoLib($this->enameId);
		$this->mod = new ModBase('finance');
	}

	public function testAddFinanceIn()
	{
		try
		{
			$rs = $this->lib->addFinanceIn();
		}
		catch(\Exception $e)
		{
			$this->assertEquals($e->getCode(), '410043', 'addFinanceIn出错1');
		}
		$orderId = 115676;
		$money = 20;
		$info = $this->finLib->getUserFinance();
		$lastInfo = $this->mod->getRow("select max(inid) as maxId from e_finance_in", "", array());
		$this->lib->setInMoney($money);
		$this->lib->setMoneyType(1);
		$this->lib->setLinkEnameId($this->enameId);
		$this->lib->setInType(1);
		$this->lib->setOrderId($orderId);
		$this->lib->setLinkDomain('');
		$this->lib->setInRemark('test dddd');
		$this->lib->setInRemarkHide('no hide');
		$this->lib->setOperator('9999');
		$rs = $this->lib->addFinanceIn();
		$this->assertEquals($rs, $lastInfo['maxId'] + 1, 'addFinanceIn出错2');
		$newInfo = $this->finLib->getUserFinance();
		$info['PublicMoney'] += $money;
		$info['UseMoney'] += $money;
		$this->assertEquals($newInfo, $info, 'addFinanceIn出错3');
	}

	public function testRefundFinanceIn()
	{
		try
		{
			$rs = $this->lib->refundFinanceIn(array());
		}
		catch(\Exception $e)
		{
			$this->assertEquals($e->getCode(), '410043', 'refundFinanceIn出错1');
		}
		$orderId = 115676;
		$info = $this->finLib->getUserFinance();
		$lastInfo = $this->mod->getRow("select max(inid) as maxId from e_finance_in", "", array());
		$order = $this->mod->getRow("select * from e_finance_orders where orderid = $orderId", "", array());
		$sort = json_decode($order['FreezeMoneySort'], TRUE);
		$this->lib->setOrderId($orderId);
		$this->lib->setInMoney($order['Price']);
		$this->lib->setInType($order['OrderType']);
		$this->lib->setLinkDomain($order['Domain']);
		$this->lib->setOperator('99999');
		$rs = $this->lib->refundFinanceIn($sort);
		$this->assertEquals($rs, $lastInfo['maxId'] + 1, 'refundFinanceIn出错2');
		$newInfo = $this->finLib->getUserFinance();
		if($sort['p'])
		{
			$info['PublicMoney'] += $sort['p'];
		}
		if($sort['u'])
		{
			$info['UnWithdrawalMoney'] += $sort['u'];
		}
		if($sort['w'])
		{
			$info['WithdrawalMoney'] += $sort['w'];
		}
		if($sort['m'])
		{
			$info['MarginMoney'] += $sort['m'];
		}
		$info['UseMoney'] += $sort['p'] + $sort['u'] + $sort['w'] + $sort['m'];
		$this->assertEquals($newInfo, $info, 'refundFinanceIn出错3');
	}

	public function testAddFinanceInSDK()
	{
		$lastInfo = $this->mod->getRow("select max(inid) as maxId from e_finance_in", "", array());
		$this->lib->setInMoney(10);
		$this->lib->setInType(1);
		$this->lib->setMoneyType(2);
		$this->lib->setLinkDomain('test.com');
		$this->lib->setOperator('99999');
		$rs = $this->lib->addFinanceInSDK();
		$this->assertEquals($rs, $lastInfo['maxId'] + 1, 'addFinanceInSDK出错1');
	}

	public function testCheckOrderId()
	{
		try
		{
			$rs = $this->lib->checkOrderId($this->enameId, 5664451);
		}
		catch(\Exception $e)
		{
			$this->assertEquals($e->getCode(), '410046', 'checkOrderId出错2');
		}
		$rs = $this->lib->checkOrderId($this->enameId, 115676);
		$this->assertTrue($rs, 'checkOrderId出错1');
	}

	public function testCheckUniqueId()
	{
		try
		{
			$rs = $this->lib->checkUniqueId($this->enameId, 5664451);
		}
		catch(\Exception $e)
		{
			$this->assertEquals($e->getCode(), '410046', 'checkUniqueId出错2');
		}
		$rs = $this->lib->checkUniqueId(317363, 123126);
		$this->assertTrue($rs, 'checkUniqueId出错1');
	}

	// 	public function testGetFinanceInSDK()
	// 	{
	// 		$rs = $this->lib->getFinanceInSDK(array('enameId'=>561305,'orderId'=>115676,'offset'=>'0','num'=>'1'));
	// 		$this->assertTrue($rs, 'getFinanceInSDK出错1');
	// 	}
}

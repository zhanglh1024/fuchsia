<?php
use lib\manage\finance\PromoLib;
use tests\TestCase;
use \core\ModBase;
class PromoLibTest extends TestCase
{
	private $lib;
	private $enameId;
	private $mod;

	public function __construct()
	{
		$this->lib = new \lib\manage\finance\PromoLib();
		$this->mod = new ModBase('product');
	}

	public function testAddPromoCodeSDK()
	{
// 		$lastInfo = $this->mod->getRow("select max(PromoId) as maxId from e_products_promo_code", "", array());
// 		$info = $this->mod->getRow("select * from e_products_promo_type where PromoTypeId = 101", "", array());
// 		$addData['PromoTypeId'] = $info['PromoTypeId'];
// 		$addData['PromoCode'] = $info['Identifier'] . $this->lib->getString(8);
// 		$addData['EnameId'] = 561305;
// 		$addData['UsedDate'] = '';
// 		$addData['OrderId'] = 0;
// 		$addData['MaxUseTimes'] = 5;
// 		$addData['UseTimes'] = 1;
// 		$addData['ProductId'] = 0;
// 		$addData['PromoStatus'] = 1;
// 		$addData['UniqueId'] = '';
// 		$addData['Domains'] = '';
// 		$nowTime = time();
// 		$addData['CreateDate'] = date('Y-m-d H:i:s', $nowTime);
// 		$promoEndDate = $nowTime + 86400 * $info['UseDays'];
// 		$addData['PromoEndDate'] = empty($info['UseDays']) ? $info['UseEndDate'] : date('Y-m-d H:i:s', $promoEndDate); //有效
// 		$rs = $this->lib->addPromoCodeSDK($addData);
// 		$this->assertEquals($rs, $lastInfo['maxId'] + 1, "addPromoCodeSDK出错1");
	}

	public function testCheckPromo()
	{
		$lastInfo = $this->mod->getRow("select max(PromoId) as maxId from e_products_promo_code where enameid = 561305", "", array());
		$info = $this->mod->getRow("select * from e_products_promo_type where PromoId = " . $lastInfo['maxId'], "", array());
		$this->lib->setCheckEnameId(0);
		$rs = $this->lib->checkPromo();
		$this->assertFalse($rs, "checkPromo出错1");
		try
		{
			$this->lib->setCheckEnameId(561305);
			$this->lib->setCheckPromoCode($info['PromoCode'] . "dfdsf");
			$this->lib->checkPromo();
		}
		catch(\Exception $e)
		{
			$this->assertEquals($e->getCode(), 410004, "checkPromo出错2");
		}
		try
		{
			$this->lib->setCheckEnameId(586378);
			$this->lib->setCheckPromoCode("CNXFPQUad9ZUR");
			$this->lib->checkPromo();
		}
		catch(\Exception $e)
		{
			$this->assertEquals($e->getCode(), 3103, "checkPromo出错3");
		}
		$this->lib->setCheckEnameId(561305);
		$this->lib->setCheckPromoCode($info['PromoCode']);
		$this->lib->setCheckPromoId($lastInfo['maxId']);
		$this->lib->setCheckUserGroupId(1);
		$this->lib->setCheckUseType(1);
		$this->lib->setCheckProductType(1);
		$this->lib->setCheckDomainExp(array('1'=>'.cn'));
		$this->lib->setCheckMoney(array('1'=>'100.00'));
		$this->lib->setCheckYear(array('1'=>'3'));
		$this->lib->setCheckOkDomains(array('1'=>'test.cn'));
		$this->lib->setCheckDomainRegId(array(1));
		$rs = $this->lib->checkPromo();
		$this->assertFalse($rs, "checkPromo出错4");
		$this->lib->setCheckEnameId(358334);
		$rs = $this->lib->checkPromo();
		$this->assertFalse($rs, "checkPromo出错5");
		$this->lib->setCheckEnameId(561305);
		$this->lib->setCheckUseType(2);
		$rs = $this->lib->checkPromo();
		$this->assertFalse($rs, "checkPromo出错6");
	}

	public function testGetPromoContent()
	{
		$lastInfo = $this->mod->getRow("select max(PromoId) as maxId from e_products_promo_code where enameid = 561305", "", array());
		$info = $this->mod->getRow("select * from e_products_promo_type where PromoId = " . $lastInfo['maxId'], "", array());
		$this->lib->setCheckEnameId(561305);
		$this->lib->setCheckPromoCode($info['PromoCode']);
		$this->lib->setCheckPromoId($lastInfo['maxId']);
		$this->lib->setCheckUserGroupId(1);
		$this->lib->setCheckUseType(1);
		$this->lib->setCheckProductType(1);
		$this->lib->setCheckDomainExp(array('1'=>'.cn'));
		$this->lib->setCheckMoney(array('1'=>'100.00'));
		$this->lib->setCheckYear(array('1'=>'3'));
		$this->lib->setCheckOkDomains(array('1'=>'test.cn'));
		$this->lib->setCheckDomainRegId(array(1));
		$this->lib->checkPromo();
		$rs = $this->lib->getPromoContent();
	}

	public function testGetAvailablePromoListSDK()
	{
		$info = $this->mod->select('SELECT * FROM e_products_promo_type AS t, e_products_promo_code AS p WHERE t.PromoTypeId = p.PromoTypeId AND p.EnameId = 561305 AND t.UseStartDate <= "'.date('Y-m-d H:i:s').'" AND t.UseEndDate >= "'.date('Y-m-d H:i:s').'"
				 AND (t.UseType = 1 OR INSTR(t.UseType, ",1,") > 0 OR INSTR(t.UseType, "1,") > 0 OR INSTR(t.UseType, ",1") > 0 AND INSTR(t.UserGroup, 1) > 0) AND p.Usetimes < p.MaxUseTimes AND t.UseEndDate > NOW() ORDER BY p.CreateDate DESC,t.UseEndDate DESC,p.PromoId DESC LIMIT 0,1', "", array());
		$this->lib->setCheckEnameId(561305);
		$this->lib->setCheckUseType(1);
		$this->lib->setCheckUserGroupId(1);
		$rs = $this->lib->getAvailablePromoListSDK(0, 1);
		$this->assertEquals($rs, $info, "getAvailablePromoListSDK出错1");
	}

	public function testGetUserPromoListSDK()
	{
		$info = $this->mod->select('select * from e_products_promo_type AS t, e_products_promo_code AS p where t.PromoTypeId = p.PromoTypeId and p.EnameId = 561305 order by p.CreateDate DESC,t.UseEndDate DESC,p.PromoId desc limit 0,20', "", array());
		$this->lib->setCheckEnameId(561305);
		$rs = $this->lib->getUserPromoListSDK();
		$this->assertEquals($rs, $info, "getUserPromoListSDK出错1");
	}

	public function testGetPromoInfoSDK()
	{
		$lastInfo = $this->mod->getRow("select max(PromoId) as maxId from e_products_promo_code where enameid = 561305", "", array());
		$info = $this->mod->getRow("SELECT t.*, p.* FROM e_products_promo_type AS t, e_products_promo_code AS p WHERE t.PromoTypeId = p.PromoTypeId and PromoStatus = 1 and p.PromoId = " . $lastInfo['maxId'], "", array());
		$this->lib->setCheckPromoId($lastInfo['maxId']);
		$rs = $this->lib->getPromoInfoSDK();
		$this->assertEquals($rs, $info, "getPromoInfoSDK出错1");
	}
	
	public function testGetPromoMoney()
	{
// 		$rs = $this->lib->getPromoMoney();
	}

	public function testUsePromo()
	{
// 		$lastInfo = $this->mod->getRow("select max(PromoId) as maxId from e_products_promo_code where enameid = 561305", "", array());
// 		$info = $this->mod->getRow("select * from e_products_promo_type where PromoId = " . $lastInfo['maxId'], "", array());
// 		$this->lib->setCheckEnameId(561305);
// 		$this->lib->setCheckPromoCode($info['PromoCode']);
// 		$this->lib->setCheckPromoId($lastInfo['maxId']);
// 		$this->lib->setCheckUserGroupId(1);
// 		$this->lib->setCheckUseType(1);
// 		$this->lib->setCheckProductType(1);
// 		$this->lib->setCheckDomainExp(array('1'=>'.cn'));
// 		$this->lib->setCheckMoney(array('1'=>'100.00'));
// 		$this->lib->setCheckYear(array('1'=>'3'));
// 		$this->lib->setCheckOkDomains(array('1'=>'test.cn'));
// 		$this->lib->setCheckDomainRegId(array(1));
// 		$this->lib->setCheckUseType(2);
// 		$rs = $this->lib->usePromo();
// 		$this->assertTrue($rs, "usePromo出错1");
	}

	public function testGetPromoTypeSDK()
	{
		$lastInfo = $this->mod->getRow("select max(PromoId) as maxId from e_products_promo_code where enameid = 561305", "", array());
		$info = $this->mod->getRow("select * from e_products_promo_type where PromoId = " . $lastInfo['maxId'], "", array());
		$rs = $this->lib->getPromoTypeSDK($lastInfo['maxId']);
		$this->assertEquals($rs, $info, "getPromoTypeSDK出错1");
	}

	public function testGetPromoCountByType()
	{
		$lastInfo = $this->mod->getRow("select max(PromoId) as maxId from e_products_promo_type where enameid = 561305", "", array());
		$info = $this->mod->getRow("select count(*) as num from e_products_promo_code where PromoTypeId = " . $lastInfo['maxId'], "", array());
		$rs = $this->lib->getPromoCountByType($lastInfo['maxId']);
		$this->assertEquals($rs, $info['num'], "getPromoCountByType出错1");
	}

	public function testCheckHavePromo()
	{
		$lastInfo = $this->mod->getRow("select max(PromoId) as maxId from e_products_promo_type where enameid = 561305", "", array());
		$info = $this->mod->getRow("select * from e_products_promo_code where PromoTypeId = " . $lastInfo['maxId'], "", array());
		$rs = $this->lib->checkHavePromo(561305, $lastInfo['maxId']);
		$this->assertEquals($rs, $info, "checkHavePromo出错1");
	}

	public function testCancelPromoUsedSDK()
	{
// 		$lastInfo = $this->mod->getRow("select max(PromoId) as maxId from e_products_promo_code where enameid = 561305", "", array());
// 		$this->lib->setCheckOrderId(123456);
// 		$this->lib->setCheckEnameId(561305);
// 		$this->lib->setCheckPromoId($lastInfo['maxId']);
// 		$rs = $this->lib->cancelPromoUsedSDK();
// 		$this->assertTrue($rs, "cancelPromoUsedSDK出错1");
	}

	public function testVCheckHaveUniqueId()
	{
		$lastInfo = $this->mod->getRow("select max(PromoId) as maxId from e_products_promo_type where enameid = 561305", "", array());
		$rs = $this->lib->checkHaveUniqueId(561305, $lastInfo['maxId'], 4545456);
		$this->assertFalse($rs, "checkHaveUniqueId出错1");
	}

	public function getPromoStat($params)
	{

	}

	public function getString($length)
	{
		
	}
}

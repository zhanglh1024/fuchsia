<?php
use tests\TestCase;
class MailLibLibTest extends TestCase
{
	private $lib;

	public function __construct()
	{
		$this->lib = new \lib\manage\queue\MailLib();
	}

	public function testMail()
	{
		$rs = $this->lib->send("viya0412@tom.com", "test tom mail", "正文内容。。。", "<h1>html内容</h1>", 'setTransferMail');
		$this->assertEquals($rs, TRUE, '发送邮件出错1');
		
// 		$rs = $this->lib->send("yangyf@ename.com", "test ename mail", "正文内容。。。", "<h1>html内容</h1>", 'setTransferMail');
// 		$this->assertEquals($rs, TRUE, '发送邮件出错2');
		
// 		$rs = $this->lib->send("yangyf1234@ename.com", "test ename mail", "正文内容。。。", "<h1>html内容</h1>", 'setTransferMail');
// 		$this->assertEquals($rs, FALSE, '发送邮件出错3');
	}
}

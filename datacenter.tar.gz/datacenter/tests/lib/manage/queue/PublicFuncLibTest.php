<?php
use tests\TestCase;
class PublicFuncLibTest extends TestCase
{
	private $lib;

	public function __construct()
	{
		$this->lib = new \lib\manage\queue\PublicFuncLib();
	}
	
	public function testPublicFunc()
	{
		$tplMod = new \models\manage\queue\TemplateMod();
	
		//test transData
		$tplInfo = $tplMod->getDefaultTplById("registerSuccess");
		$data = array("email" => '756554493@qq.com',
				"activatorURL" => 'https://www.ename.net/user/checkbindemailcaptcha?captchacode=1402051790&email=756554493@qq.com',
				"userName" => "杨亚凤");
		$rsExp = array('Id' => '1', 'TemplateId' => 'registerSuccess', 'IsDefault' => '1',
				'Subject' => '恭喜您成功注册易名中国，请进行邮箱认证，完成注册', 'AltBody' => '尊敬的客户'.$data['userName'].'：<br><br>
您好，恭喜您成为易名中国的会员<br>
为了您的账户安全，请您点击下面的链接，进行邮箱验证：<br>
'.$data['activatorURL'].'<br>
如果以上链接无法点击，请将上面的地址复制到您的浏览器(如ie/firefox/chrome)的地址栏打开。<br>
请牢记您的eNameID和注册使用的邮件地址, 您将使用它们登录易名中国进行域名管理和域名交易<br>',
				'HtmlBody' => '尊敬的客户'.$data['userName'].'：<br><br>
您好，恭喜您成为易名中国的会员<br>
为了您的账户安全，请您点击下面的链接，进行邮箱验证：<br>
'.$data['activatorURL'].'<br>
如果以上链接无法点击，请将上面的地址复制到您的浏览器(如ie/firefox/chrome)的地址栏打开。<br>
请牢记您的eNameID和注册使用的邮件地址, 您将使用它们登录易名中国进行域名管理和域名交易<br>', 'GroupId' => '12', 'Created' => '0', 'Updated' => '0',
				'Name' => '注册成功', 'Sort' => '0');
		$rs = $this->lib->transData($tplInfo, $data);
		$this->assertEquals($rs, $rsExp, '模板变量替换出错1');
	
		$tplInfo = $tplMod->getDefaultTplById("sureSendSMS");
		$data = array("domainName" => 'viya.com',
				"handler" => "杨亚凤");
		$rsExp = array('Id' => '35', 'TemplateId' => 'sureSendSMS', 'IsDefault' => '1',
				'Subject' => '接受委托短信信息提醒', 'AltBody' => '尊敬的561305,您委托的域名[' . $data['domainName'] . ']经纪申请已受理您好。经纪人[' . $data['handler'] . ']已经受理了您的经纪请求，您可以登录个人中心查看此交易的相关事宜。',
				'HtmlBody' => '', 'GroupId' => '6', 'Created' => '0', 'Updated' => '0',
				'Name' => '', 'Sort' => '0');
		$rs = $this->lib->transData($tplInfo, $data, 561305);
		$this->assertEquals($rs, $rsExp, '模板变量替换出错2');
	}
	/*
	public function testTransHtmlData()
	{
		$rs = $this->lib->transHtmlData("registerSuccess", "");
		$this->assertTRUE($rs, '模板html替换出错1');
	}
	*/
}

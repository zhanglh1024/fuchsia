<?php
use tests\TestCase;
class DomainHelpLibTest extends TestCase
{
	private $enameId;
	private $lib;
	
	public function __construct()
	{
		$this->enameId = 561305;
		$this->lib = new \lib\manage\domain\DomainHelpLib();
	}
	
	public function testDomainRegErrorIsNoMoney()
	{
		$info = array('resultCode' => 5008, 'data' => array('msg' => "(sysytem not found )Insufficient Balance."));
		$rs = $this->lib->domainRegErrorIsNoMoney($info, "ename.com", 1);

	}
}

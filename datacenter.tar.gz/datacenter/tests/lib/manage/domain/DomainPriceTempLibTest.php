<?php
use tests\TestCase;
use \core\ModBase;
class DomainPriceTempLibTest extends TestCase
{
	private $enameId;
	private $lib;
	private $mod;

	public function __construct()
	{
		parent::__construct();
		$this->enameId = 561305;
		$this->lib = new \lib\manage\domain\DomainPriceTempLib($this->enameId);
	}

	public function testPriceTemplate()
	{
		$rs = $this->lib->priceTemplate($this->enameId, 1, 'ename..com');
		$this->assertEquals($rs['code'], 60001, "priceTemplate出错1");
		$rs = $this->lib->priceTemplate($this->enameId, 1, 'ename.com');
		$this->assertEquals($rs['code'], 60000, "priceTemplate出错1");
	}

	public function testGetDomainYear()
	{
		$rs = $this->lib->getDomainYear('producttest44.org', 1);//注册
		$this->assertEquals(10, $rs, "能够续费的最大年数错误");
		$rs = $this->lib->getDomainYear('producttest44.org', 3);//注册
		$this->assertEquals(9, $rs, "能够续费的最大年数错误");
	}

}

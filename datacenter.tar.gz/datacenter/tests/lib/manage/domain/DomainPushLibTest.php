<?php
namespace lib\manage\domain;
use tests\TestCase;
use \core\ModBase;
use \core\Response;
class DomainPushLibTest extends TestCase
{
	private $enameId;
	private $lib;
	private $mod;

	public function __construct()
	{
		$this->enameId = 561305;
		$this->lib = new \lib\manage\domain\DomainPushLib();
		$this->mod = new ModBase('domain');
	}

	public function testDomainAddToSale()
	{
		$rs = $this->lib->domainAddToSale('test.com', 1);
		$this->assertFalse($rs, "domainAddToSale出错1");
		$this->assertEquals(Response::getErrCode(), 322000, "domainAddToSale出错2");
		
		$this->mod->update("update e_domains set enameid = 561305, templateId = 379011, expdate = '" . date('Y-m-d H:i:s', strtotime("+2 year")) . "', DomainMyStatus = 1, DomainHoldStatus = 0 where DomainName = 'trustyounono.pw'", "", array());
		$info = $this->mod->getRow("select * from e_domains where EnameId = " . $this->enameId . " and DomainName = 'trustyounono.pw'", "", array());
		
		$this->mod->update("update e_domains set expdate = '" . date('Y-m-d H:i:s', strtotime("-3 month")) . "' where DomainName = 'trustyounono.pw'", "", array());
		$rs = $this->lib->domainAddToSale('trustyounono.pw', 1);
		$this->assertFalse($rs, "domainAddToSale出错5");
		$this->assertEquals(Response::getErrCode(), 322006, "domainAddToSale出错6");
		
		$this->mod->update("update e_domains set expdate = '" . $info['ExpDate'] . "', TemplateId = 428291 where DomainName = 'trustyounono.pw'", "", array());
		$rs = $this->lib->domainAddToSale('trustyounono.pw', 1);
		$this->assertFalse($rs, "domainAddToSale出错7");
		$this->assertEquals(Response::getErrCode(), 322002, "domainAddToSale出错8");
		$this->mod->update("update e_domains set TemplateId = 413119 where DomainName = 'trustyounono.pw'", "", array());
		$rs = $this->lib->domainAddToSale('trustyounono.pw', 1);
		$this->assertFalse($rs, "domainAddToSale出错9");
		$this->assertEquals(Response::getErrCode(), 322002, "domainAddToSale出错10");
		
		$this->mod->update("update e_domains set TemplateId = '" . $info['TemplateId'] . "' where DomainName = 'trustyounono.pw'", "", array());
		$this->mod->update("update e_domains set DomainMyStatus = 5 where DomainName = 'trustyounono.pw'", "", array());
		$rs = $this->lib->domainAddToSale('trustyounono.pw', 1);
		$this->assertFalse($rs, "domainAddToSale出错11");
		$this->assertEquals(Response::getErrCode(), 322003, "domainAddToSale出错12");
		
		$this->mod->update("update e_domains set DomainMyStatus = '" . $info['DomainMyStatus'] . "' where DomainName = 'trustyounono.pw'", "", array());
		$this->mod->update("update e_domains set DomainHoldStatus = 2 where DomainName = 'trustyounono.pw'", "", array());
		$rs = $this->lib->domainAddToSale('trustyounono.pw', 1);
		$this->assertFalse($rs, "domainAddToSale出错13");
		$this->assertEquals(Response::getErrCode(), 322003, "domainAddToSale出错14");
		
		$this->mod->update("update e_domains set DomainHoldStatus = 0, DomainMyStatus = 2 where DomainName = 'trustyounono.pw'", "", array());
		$rs = $this->lib->domainAddToSale('trustyounono.pw', 2);
		$this->assertFalse($rs, "domainAddToSale出错15");
		$this->assertEquals(Response::getErrCode(), 322004, "domainAddToSale出错16");
		
		$this->mod->update("update e_domains set DomainMyStatus = 2 where DomainName = 'trustyounono.pw'", "", array());
		$rs = $this->lib->domainAddToSale('trustyounono.pw', 1);
		$this->assertTrue($rs, "domainAddToSale出错17");
		
		$this->mod->update("update e_domains set DomainMyStatus = 1 where DomainName = 'trustyounono.pw'", "", array());
		$rs = $this->lib->domainAddToSale('trustyounono.pw', 2);
		$this->assertTrue($rs, "domainAddToSale出错17");
	}

	public function testMoveDomain()
	{
		$info = $this->mod->getRow("select * from e_domains where EnameId = " . $this->enameId . " and DomainName = 'trustyounono.pw'", "", array());
		$rs = $this->lib->moveDomain('', 358334, 413119, "临时模板", 0);
		$this->assertFalse($rs, "moveDomain出错1");
		$rs = $this->lib->moveDomain($info, 358334, 413119, "临时模板", 0);
		$this->assertTrue($rs, "moveDomain出错2");
		$newInfo = $this->mod->getRow("select EnameId from e_domains where EnameId = 358334 and DomainName = 'trustyounono.pw'", "", array());
		$this->assertEquals($newInfo['EnameId'], 358334, "moveDomain出错3");
		$rs = $this->lib->moveDomain($info, 561305, 413119, "临时模板", 0);
		$this->assertTrue($rs, "moveDomain出错4");
		$newInfo = $this->mod->getRow("select EnameId from e_domains where EnameId = " . $this->enameId . " and DomainName = 'trustyounono.pw'", "", array());
		$this->assertEquals($newInfo['EnameId'], 561305, "moveDomain出错5");
	}
}

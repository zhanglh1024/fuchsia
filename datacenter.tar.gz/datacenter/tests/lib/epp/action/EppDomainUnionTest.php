<?php
use tests\TestCase;
use lib\epp\action\EppDomainUnion;

class EppDomainTest extends TestCase
{
	
	private $dn = '23152332313.com';
	private $tmpId = 'ename_unit_32';
	
	public function testSendCommand()
	{
		$pwd = '4d33afd@#5565'.mt_rand(0,9);
		$eppDn = new EppDomainUnion($this->dn);
		$data = array();
		$data['DNS'] = array('dns1.iidns.com','dns2.iidns.com');
		$data['dnsId'] = 0;
		$eppDn->setPwd($pwd)->setDns($data)->setContactId($this->tmpId);
		$eppDn->setStatus(array(3,4,7));
		$result = $eppDn->sendCommand();
		$this->assertArrayHasKey('code', $result, '更新域名时出错status:3,4,7，没有返回code');
		$this->assertEquals($result['code'], '1000', '更新域名时出错,code!=1000,=' . $result['code']);
		
		$eppDn->setStatus(array(4,5));
		$result = $eppDn->sendCommand();
		$this->assertArrayHasKey('code', $result, '更新域名时出错status:4,5，没有返回code');
		$this->assertEquals($result['code'], '1000', '更新域名时出错,code!=1000,=' . $result['code']);
	}
}
<?php
use tests\TestCase;
use lib\epp\action\EppContact;
use lib\epp\action\EppDomain;

class EppDomainTest extends TestCase
{

	private $dn = 'abc7xxxxxxxxxxxx.com';

	private $checkDn = array('aaa.com','abc6xxxxxxxxxxxx.com','34345345345.com');

	private $tmpId = 'ename_unit_33';

	private $newTmpId = 'ename_unit_32';

	private static $expdate = false;

	private $transferDn = '23152332313.com';
	private $transferPwd = 'ON156wb9V6z9@1Aa';

	public function testCreate()
	{
		$eppDn = new EppDomain($this->dn);
		$result = $eppDn->create(array(), $this->tmpId);
		$this->assertArrayHasKey('code', $result, '注册域名时出错，没有返回code');
		$this->assertEquals($result['code'], '1000', '注册域名时出错,code!=1000,=' . $result['code']);
		$this->assertArrayHasKey('expireDate', $result, '注册域名时出错，没有返回expireDate');
		self::$expdate = $result['expireDate'];
	}

	public function testRewnew()
	{
		$eppDn = new EppDomain($this->dn);
		$data = array();
		$data['period'] = 1;
		$data['expDate'] = date("Y-m-d", strtotime(self::$expdate));
		$result = $eppDn->renew($data);
		$this->assertArrayHasKey('code', $result, '域名续费时出错，没有返回code');
		$this->assertEquals($result['code'], '1000', '域名续费时出错,code!=1000,=' . $result['code']);
	}

	public function testCheck()
	{
		$eppDn = new EppDomain($this->dn);
		$data = array();
		$data['domain'] = $this->checkDn;
		$result = $eppDn->check($data);
		$this->assertArrayHasKey('code', $result, '查询域名时出错，没有返回code');
		$this->assertEquals($result['code'], '1000', '查询域名时出错,code!=1000,=' . $result['code']);
		$this->assertArrayHasKey('registered', $result, '查询域名出错,没有返回registered,');
		$this->assertArrayHasKey('notRegister', $result, '查询域名出错,没有返回notRegister,');
	}

	public function testUpdateDns()
	{
		$eppDn = new EppDomain($this->dn);
		$data = array();
		$data['DNS'] = array('dns1.iidns.com','dns2.iidns.com');
		$data['dnsId'] = 0;
		$result = $eppDn->updateDns($data);
		$this->assertArrayHasKey('code', $result, '更新域名DNS时出错，没有返回code');
		$this->assertEquals($result['code'], '1000', '更新域名DNS时出错,code!=1000,=' . $result['code']);
		$data = array();
		$data['DNS'] = array('dns3.iidns.com','dns6.iidns.com');
		$data['dnsId'] = 0;
		$result = $eppDn->updateDns($data);
		$this->assertArrayHasKey('code', $result, '更新域名DNS时出错，没有返回code');
		$this->assertEquals($result['code'], '1000', '更新域名DNS时出错,code!=1000,=' . $result['code']);
		$data = array();
		$data['DNS'] = array('dns3.iidns.com','dns4.iidns.com','dns5.iidns.com');
		$data['dnsId'] = 0;
		$result = $eppDn->updateDns($data);
		$this->assertArrayHasKey('code', $result, '更新域名DNS时出错，没有返回code');
		$this->assertEquals($result['code'], '1000', '更新域名DNS时出错,code!=1000,=' . $result['code']);
	}

	public function testUpdateContact()
	{
		$eppDn = new EppDomain($this->dn);
		$result = $eppDn->updateContact($this->newTmpId);
		$this->assertArrayHasKey('code', $result, '更新域名联系人时出错，没有返回code');
		$this->assertEquals($result['code'], '1000', '更新联系人时出错,code!=1000,=' . $result['code']);
	}

	public function testUpdatePwd()
	{
		$eppDn = new EppDomain($this->dn);
		$result = $eppDn->updatePwd('fsa@dfa&44sdfa');
		$this->assertArrayHasKey('code', $result, '更新域名密码时出错，没有返回code');
		$this->assertEquals($result['code'], '1000', '更新域名密码时出错,code!=1000,=' . $result['code']);
	}

	public function testUpdateStatus()
	{
		$eppDn = new EppDomain($this->dn);
		$result = $eppDn->updateStatus(array(3,4));
		$this->assertArrayHasKey('code', $result, '更新域名状态时出错，没有返回code');
		$this->assertEquals($result['code'], '1000', '更新域名状态时出错,code!=1000,=' . $result['code']);
		$result = $eppDn->updateStatus(array(5));
		$this->assertArrayHasKey('code', $result, '更新域名状态时出错 加禁止更新，没有返回code');
		$this->assertEquals($result['code'], '1000', '更新域名状态时出错,加禁止更新,code!=1000,=' . $result['code']);
		$result = $eppDn->updateStatus(array(6));
		$this->assertArrayHasKey('code', $result, '删除域名状态时出错，没有返回code');
		$this->assertEquals($result['code'], '1000', '删除域名状态时出错,code!=1000,=' . $result['code']);
	}

	public function testGetConfig()
	{
		$eppDn = new EppDomain($this->dn);
		$result = $eppDn->getConfig();
		$this->assertArrayHasKey('cn', $result, 'get config error，no key for cn');
		$this->assertArrayHasKey('open', $result, 'get config error，no key for open');
	}

	public function testDelete()
	{
		$eppDn = new EppDomain($this->dn);
		$result = $eppDn->delete();
		$this->assertArrayHasKey('code', $result, '删除域名时出错，没有返回code');
		$this->assertEquals($result['code'], '1000', '删除域名时出错,code!=1000,=' . $result['code']);
	}
	
// 	public function testApplyTransferIn()
// 	{
// 		$eppDnOld = new EppDomain($this->transferDn);
// 		$result = $eppDnOld->updateStatus(array());
// 		$eppDn = new EppDomain($this->transferDn, 22);
// 		$result = $eppDn->applyTransferIn(1, $this->transferPwd);
// 		$this->assertArrayHasKey('code', $result, 'apply transfer in domain error，none code');
// 		$this->assertEquals($result['code'], '1000', 'apply transfer in domain error,code!=1000,=' . $result['code']);
// 	}

// 	public function testQueryTransferInfo()
// 	{
// 		$eppDn = new EppDomain($this->transferDn, 22);
// 		$result = $eppDn->queryTransferInfo();
// 		$this->assertArrayHasKey('code', $result, 'query transfer info error，none code');
// 		$this->assertEquals($result['code'], '1000', 'query transfer info error,code!=1000,=' . $result['code']);
// 	}
	
// 	public function testCancelTransferIn()
// 	{
// 		$eppDn = new EppDomain($this->transferDn, 22);
// 		$result = $eppDn->cancelTransferIn();
// 		$this->assertArrayHasKey('code', $result, 'cancel domain transfer error，none code');
// 		$this->assertEquals($result['code'], '1000', 'cancel domain transfer error,code!=1000,=' . $result['code']);
// 		//为了测试拒绝转出 再跑一次提交申请
// 		$eppDn = new EppDomain($this->transferDn, 22);
// 		$result = $eppDn->applyTransferIn(1, $this->transferPwd);
// 		$this->assertArrayHasKey('code', $result, 'apply transfer in domain error，none code');
// 		$this->assertEquals($result['code'], '1000', 'apply transfer in domain error,code!=1000,=' . $result['code']);
// 	}
	
// 	public function testRejectTransferOut()
// 	{
// 		$eppDn = new EppDomain($this->transferDn, 22);
// 		$result = $eppDn->rejectTransferOut();
// 		$this->assertArrayHasKey('code', $result, 'reject transfer out error，none code');
// 		$this->assertEquals($result['code'], '1000', 'reject transfer out error,code!=1000,=' . $result['code']);
// 	}
}
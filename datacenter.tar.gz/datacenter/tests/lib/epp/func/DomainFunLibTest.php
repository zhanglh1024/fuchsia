<?php
use tests\TestCase;
use \lib\epp\func\Domain;
use \core\Response;
class DomainFuncLibTest extends TestCase
{
	public function testGetTld()
	{
		$rs = Domain::getTld('ename.cn');
		$this->assertEquals($rs, 'cn', 'ename.cn后缀获取错误');
		$rs = Domain::getTld('ename.com.cn');
		$this->assertEquals($rs, 'cn', 'ename.com.cn后缀获取错误');
		$rs = Domain::getTld('ename.pw');
		$this->assertEquals($rs, 'pw', 'ename.pw后缀获取错误');
	}
	
	public function testCheckChinese()
	{
		$rs = Domain::checkChinese('abc');
		$this->assertFalse($rs, '判断是否有中文出错"abc"');
		$rs = Domain::checkChinese('中文');
		$this->assertTrue($rs, '判断是否有中文出错"中文"');
		$rs = Domain::checkChinese('a11111中文');
		$this->assertTrue($rs, '判断是否有中文出错"中文"');
	}

	public function testGetNeedTemplateIdTld()
	{
		$rs = Domain::getNeedTemplateIdTld('aaaa.com');
		$this->assertFalse($rs, '判断注册aaaa.com域名是否不需要联系人ID出错');
		$rs = Domain::getNeedTemplateIdTld('aaaa.tv');
		$this->assertFalse($rs, '判断注册aaaa.tv域名是否不需要联系人ID出错');
		$rs = Domain::getNeedTemplateIdTld('aaaa.cn');
		$this->assertTrue($rs, '判断注册aaaa.cn域名是否不需要联系人ID出错');
		$rs = Domain::getNeedTemplateIdTld('aaaa.org');
		$this->assertTrue($rs, '判断注册aaaa.org域名是否不需要联系人ID出错');
	}

}

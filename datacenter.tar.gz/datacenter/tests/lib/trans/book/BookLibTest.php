<?php
use tests\TestCase;
class BookLibTest extends TestCase
{

	public function testcanCancelBook()
	{
		$bookLib = new \lib\trans\book\BookLib();
		$rs = $bookLib->canCancelBook(104102880);
		if(!$rs)
		{
			$this->assertEquals(false,$rs,'testcanCancelBook fail');
		}
		else
		{
			$this->assertTrue($rs);
		}
	}
	
	public function testisYourBookDomain()
	{
		$bookLib = new \lib\trans\book\BookLib();
		$rs = $bookLib->isYourBookDomain(11000, 10410288);
		if($rs)
		{
			$rs = true;
			$this->assertEquals($rs,true,'testisYourBookDomain success');
		}
		else
		{
			$rs = false;
			$this->assertEquals($rs,false,'testisYourBookDomain fail');
		}
	}
	
	public function testCancelBook()
	{
		$lib = new \lib\trans\book\BookLib();
		$flag = true;
		try
		{
			$rs = $lib->cancelBook(10410375, 11000);
		}
		catch (Exception $e)
		{
			$flag = false;
			$rs = $e->getMessage();
		}
		if(!$flag)
		{
			$this->assertEquals($rs,'系统出错，请联系客服','testisYourBookDomain fail');
		}
		else
		{
			$this->assertTrue($rs);
		}
	}
	
	public function testGetCmpTime()
	{
		$lib = new \lib\trans\book\BookLib();
		$rs = $lib->getCmpTime();
		$result = date('Y-m-d').'  00:00:00';
		$this->assertEquals($rs,$result,'testGetCmpTime success');
	}
	
	public function testFormatDomainArray()
	{
		$lib = new \lib\trans\book\BookLib();
		$domainStr = "aa.com,bb.cn,cc.net";
		$rs = $lib->formatDomainArray($domainStr);
		$info = array('aa.com','bb.cn','cc.net');
		$this->assertEquals($rs,$info,'testFormatDomainArray success');
	}
	
	public function testIsOkDomain()
	{
		$lib = new \lib\trans\book\BookLib();
		$rs = $lib->isOkDomain('你好.cn');
		$this->assertTrue($rs);
		
		$rs = $lib->isOkDomain('-你好.cn');
		$this->assertEquals($rs,false,'testIsOkDomain success');
	}
	
	public function testGetEffectDomain()
	{
		$lib = new \lib\trans\book\BookLib();
		$arr = array('aa.com','cc.net','zddd.org','zzz.cn');
		$rs = $lib->getEffectDomain($arr);
		$info = array(array('aa.com','cc.net','zzz.cn'),array(array('domain'=>'zddd.org','msg'=>'此域名不支持预订')));
		$this->assertEquals($rs,$info,'testGetEffectDomain success');
	}
	
	public function testIsCnDomain()
	{
		$lib = new \lib\trans\book\BookLib();
		$rs = $lib->isCnDomain('你好.cn');
		$this->assertTrue($rs);
		$rs = $lib->isCnDomain('aa.com');
		$this->assertEquals($rs,false,'testIsCnDomain success');
	}
	
	public function testGetDomainClass()
	{
		$lib = new \lib\trans\book\BookLib();
		$rs = $lib->getDomainClass('腾讯.com.cn');
		$this->assertEquals($rs,'CN','testGetDomainClass fail');
	}
	
	public function testgetDomainClassName()
	{
		$lib = new \lib\trans\book\BookLib();
		$rs = $lib->getDomainClassName('aa.pw');
		$this->assertEquals($rs,false,'testgetDomainClassName fail');
		$rs = $lib->getDomainClassName('aa.com');
		$this->assertEquals($rs,true,'testgetDomainClassName success');
	}
	
	public function testCheckIsTopLevel()
	{
		$lib = new \lib\trans\book\BookLib();
		$rs = $lib->checkIsTopLevel('aa.com.cn');
		$this->assertEquals($rs,true,'testCheckIsTopLevel success');
		$rs = $lib->checkIsTopLevel('aa.com.zz');
		$this->assertEquals($rs,false,'testCheckIsTopLevel fail');
	}
	
	public function testcategoryDomains()
	{
		$lib = new \lib\trans\book\BookLib();
		$arr = array('中国.cn','aaa.com','we.cn');
		$rs = $lib->categoryDomains($arr);
		$info = array(array('we.cn'),array('aaa.com'),array('中国.cn'),array());
		$this->assertEquals($rs,$info,'testcategoryDomains fail');
	}
	
	public function testClassifyCnDomain()
	{
		$lib = new \lib\trans\book\BookLib();
		$arr = array(array('DomainName'=>'中国.cn'),array('DomainName'=>'aa.网络'));
		$rs = $lib->classifyCnDomain($arr);
		$info = array('cn'=>array(array('DomainName'=>'中国.cn','BookPrice'=>50)),'other'=>array(array('DomainName'=>'aa.网络','BookPrice'=>200)));
		$this->assertEquals($rs,$info,'testClassifyCnDomain fail');
	}
}

?>
<?php
use tests\TestCase;
class FabuLibTest extends TestCase
{
	public function testisYourAuditDomain()
	{
		$fabuLib = new \lib\trans\fabu\FabuLib(11000);
		$rs = $fabuLib->isYourAuditDomain(11000, 7872096);
		if(!$rs)
		{
			$this->assertEquals($rs,false,'testisYourAuditDomain fail');
		}
		else
		{
			$this->assertEquals($rs,true,'testisYourAuditDomain success');
		}
	}
	
	public function testCancelDomainAudit()
	{
		$lib = new \lib\trans\fabu\FabuLib(11000);
		$rs = $lib->cancelDomainAudit(11000, 7872508);
		if(!$rs)
		{
			$this->assertEquals($rs,false,'testCancelDomainAudit fail');
		}
		else
		{
			$this->assertEquals($rs,true,'testCancelDomainAudit success');
		}
	}
	
	public function testDelPreTradeDomain()
	{
		$lib = new \lib\trans\fabu\FabuLib(11000);
		$rs = $lib->delPreTradeDomain('badun11.org');
		$this->assertTrue($rs);
	}
	
	public function testCheckCnTLD()
	{
		$lib = new \lib\trans\fabu\FabuLib(11000);
		$rs = $lib->checkCnTLD('aaa.cn');
		$this->assertTrue($rs);
		$rs = $lib->checkCnTLD('aa.com');
		$this->assertEquals($rs,false,'testCheckCnTLD fail');
	}
}
?>
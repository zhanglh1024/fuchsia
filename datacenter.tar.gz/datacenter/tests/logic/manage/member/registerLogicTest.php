<?php
use tests\TestCase;
class registerLogicTest extends TestCase
{
	private $logic;
	public function __construct()
	{
		$this->logic = new \logic\manage\member\RegisterLogic();
	}
	//测试用户手机是否已经注册，只验证已经绑定的手机
	public function testcheckIsEnameuser()
	{
		$phone = '15280258674';
		$rs = $this->logic->checkIsEnameuser($phone);		
		$this->assertEquals($rs, true, '模板变量替换出错1');
		$phone = '15280250851';
		$rs = $this->logic->checkIsEnameuser($phone);
		$this->assertEquals($rs, false, '模板变量替换出错2');
	}
	//注册
	public function testRegisterMember()
	{
		$data= array();
		$PasswordCode = \common\Random::getString(3);
		$data['Password'] = strtoupper(md5('123456aaa'.$PasswordCode));
		$data['Mobile'] = '15845123698';
		$curEnameId = '787878';
		$data['EnameId'] = $curEnameId;
		$rs = $this->logic->RegisterMember($data);
		$regexp = array('flag'=>1,'data'=>array('msg'=>'注册成功','EnameId'=>$data['EnameId']));
		$this->assertEquals($rs,$regexp,'注册成功');
	}
	//获取当前可用的最大EnameId
	public function testgetEnameId()
	{
		$enameid = $this->logic->getEnameId();
		$testid = '888888';//预留ID 不可能获取到
		$this->assertEquals($rs,$regexp,'返回ID有误');
	}
	
}

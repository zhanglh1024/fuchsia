<?php
use tests\TestCase;
class OperateLogicTest extends TestCase
{
	private $logic;
	public function __construct()
	{
		$this->logic = new \logic\manage\member\OperateLogic();
	}
	
	public function testgetData()
	{
		$data = array('EnameId'=>'561305','identify'=>'U204');
		$data = new stdClass();
		$rs = $this->logic->getData($data);
		$rsExp = array('flag' => 1, 'msg' =>array("enameId"=>652852,"name"=>"U204","flag"=>"0","question"=>array("QuestionId"=>505980,"EnameId"=>652852,
				"Question"=>"1","QuestionType"=>0,"Answer"=>"奶奶","CreateTime"=>"2014-05-12 10:28:29","Status"=>1),"mobile"=>"15811212054","mobileType"=>1,"info"=>array("IsMobileVerified"=>1,"Mobile"=>"15811212054"),"operateMobile"=>"15811212054","CreateTime"=>1403093581));
		$this->assertEquals($rs, $rsExp, '根据标示获取操作保护信息成功');
	
	}
	public function testcheckOperate()
	{
		$data = array('EnameId'=>'561305','identify'=>'U204','answer'=>'奶奶','captcha'=>'586478','questionId0=>505980');
		$data = new stdClass();
		$rs = $this->logic->checkOperate($data);
		$this->assertTRUE($rs,false, '验证失败');
	}
}

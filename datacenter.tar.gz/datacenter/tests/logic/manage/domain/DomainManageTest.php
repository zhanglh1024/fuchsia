<?php
use tests\TestCase;
use \core\ModBase;

class DomainManageTest extends TestCase
{
	private $logic;

	public function __construct()
	{
		parent::__construct();
		$this->enameId = 586378;
		$this->logic = new \logic\manage\domain\DomainManageLogic();
	}

	/**
	 * 获取域名自动续费设置
	 */
	public function testDomainAutorenewGet($params = FALSE)
	{
		$setInfo = $this->logic->autoRenew((object) array('domain' => 'producttest44.org', 'enameId' => $this->enameId));
		$this->assertArrayHasKey('autoRenew', $setInfo, '键值错误');
		$this->assertEquals(0, $setInfo['autoRenew'], '续费设置错误');
	}

	/**
	 * 更新域名自动续费设置
	 */
	public function testDomainAutoRenewSet()
	{
		$upInfo = $this->logic->autoRenewSet((object) array('enameId' => $this->enameId,
				'domain' => 'producttest44.org', 'autoRenew' => 1));
		$this->assertTrue($upInfo, '更新失败');

		//更新后直接获取
		$setInfo = $this->logic->autoRenew((object) array('domain' => 'producttest44.org', 'enameId' => $this->enameId));
		$this->assertArrayHasKey('autoRenew', $setInfo, '键值错误');
		$this->assertEquals(1, $setInfo['autoRenew'], '续费设置错误');
	}

	/**
	 * 获取分组列表
	 */
	public function testGetDomainGroupByEnameId()
	{
		$groupList = $this->logic->getDomainGroupList((object) array('enameId' => $this->enameId));
		$this->assertCount(5, $groupList, '分组数量错误');
		$last = $groupList[count($groupList) - 1];
		$this->assertEquals('未分组', $last['GroupName'], "查无未分组");//最后一个是未分组
		$groupList = $this->logic->getDomainGroupList((object) array('enameId' => 333333));
		$this->assertEmpty($groupList, '当前用户无分组或者错误enameid');
	}

	/**
	 * 获取域名列表根据条件
	 */
	public function testGetDomainList()
	{
		$data = array('status' => 1, 'domainLtd' => '5', 'enameId' => $this->enameId);//正常org
		$list = $this->logic->getDomainListByAdvance((object) $data);
		$this->assertCount(10, $list['data'], "域名个数错误");//没传分页大小
		$this->assertEquals(25, $list['count'], '域名个数部队');

		$data = array('status' => 1, 'domainLtd' => '5', 'group' => -1, 'enameId' => $this->enameId);//正常org
		$list = $this->logic->getDomainListByAdvance((object) $data);
		$this->assertCount(10, $list['data'], "域名个数错误");//没传分页大小
		$this->assertEquals(25, $list['count'], '域名个数部队');
		foreach($list['data'] as $value)
		{
			$this->assertEquals(1, $value['DomainMyStatus'], '状态错误');
		}
		$data = array('keyword' => 'pro', 'enameId' => $this->enameId);//正常org
		$list = $this->logic->getDomainListByAdvance((object) $data);
		$this->assertCount(4, $list['data'], "域名个数错误");//没传分页大小
		$this->assertEquals(4, $list['count'], '域名个数部队');

		$data = array('group' => 211, 'enameId' => $this->enameId);//正常org
		$list = $this->logic->getDomainListByAdvance((object) $data);
		$this->assertCount(0, $list['data'], "域名个数错误");//没传分页大小
		$this->assertEquals(0, $list['count'], '域名个数部队');
		$this->assertEmpty($list['data'], '域名个数部队');

		$data = array('startDomainLength' => 15, 'enameId' => $this->enameId);//正常org
		$list = $this->logic->getDomainListByAdvance((object) $data);
		$this->assertCount(9, $list['data'], "域名个数错误");//没传分页大小
		$this->assertEquals(9, $list['count'], '域名个数部队');
		$this->assertNotEmpty($list['data'], '域名个数部队');
	}

	/**
	 * 获取域名信息
	 */
	public function testGetDomainInfo()
	{
		$data = array('domain' => 'testesfasdfasf5.org', 'enameId' => $this->enameId);
		$list = $this->logic->admin((object) $data);
		$this->assertNotEmpty($list, '域名获取失败');
		$this->assertEquals('2014-07-21 10:48:17', $list['RegDate']);
	}
}

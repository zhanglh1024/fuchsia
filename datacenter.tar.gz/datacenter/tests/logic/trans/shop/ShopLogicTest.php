<?php
	use tests\TestCase;
class ShopLogicTest extends TestCase
{
	public function testAddShopFavorite()
	{
		$logic  = new \logic\trans\shop\ShopLogic();
		$data = array('enameid'=>11000,'id'=>18335);
		$flag = true;
		try
		{
			$rs = $logic->addShopFavorite((Object)$data);
		}
		catch (Exception $e)
		{
			$flag = false;
			$rs = $e->getMessage();
		}
		if(!$flag)
		{
			$this->assertEquals($rs, '您已经关注此店铺了', 'testAddShopFavorite fail');
		}
		else
		{
			$this->assertTrue($rs['flag']);
		}
	}
	
	public function testDelShopFavorite()
	{
		$logic  = new \logic\trans\shop\ShopLogic();
		$data = array('enameid'=>11000,'uid'=>183350);
		$flag = true;
		try
		{
			$rs = $logic->delShopFavorite((Object)$data);
		}
		catch (Exception $e)
		{
			$flag = false;
			$rs = $e->getMessage();
		}
		if(!$flag)
		{
			$this->assertEquals($rs, '此店铺不是您所关注的店铺，您无权删除', 'testDelShopFavorite fail');
		}
		else
		{
			$this->assertTrue($rs['flag']);
		}
	}
	
	public function testAddShopTag()
	{
		$logic = new \logic\trans\shop\ShopLogic();
		$data = array('enameid'=>11000,'tagname'=>'测试11112221','sort'=>20,'tagtranstype'=>1,'displaytype'=>1,'status'=>1);
		$flag = true;
		try
		{
			$rs = $logic->setAddShopTag((Object)$data);
		}
		catch (Exception $e)
		{
			$flag = false;
			$rs =$e->getMessage();
		}
		if(!$flag)
		{
			$this->assertEquals($rs, '抱歉！标签名已存在！', 'testAddShopTag fail');
		}
		else
		{
			$this->assertTrue($rs['flag']);
		}
		
	}
	
	public function testDelShopTag()
	{
		$logic = new \logic\trans\shop\ShopLogic();
		$data = array('enameid'=>11000,'id'=>353);
		$flag = true;
		try 
		{
			$rs = $logic->setDelShopTag((Object)$data);
		}
		catch (Exception $e)
		{
			$flag = false;
			$rs = $e->getMessage();
		}
		if(!$flag)
		{
			$this->assertEquals($rs, '删除失败', 'testDelShopTag fail');
		}
		else
		{
			$this->assertTrue($rs['flag']);
		}
	}
	
	public function testMarkShop()
	{
		$data = array('enameid'=>11000,'id'=>27);
		$logic = new \logic\trans\shop\ShopLogic();
		$flag = true;
		try
		{
			$rs = $logic->MarkShop((Object)$data);
		}
		catch (Exception $e)
		{
			$flag = false;
			$rs = $e->getMessage();
		}
		if(!$flag)
		{
			$this->assertEquals($rs, '该店铺已经被设置成星标店铺', 'testMarkShop fail');
		}
		else
		{
			$this->assertTrue($rs['flag']);
		}
	}
	
	public function testcancelMarkShop()
	{
		$data = array('enameid'=>11000,'id'=>27);
		$logic = new \logic\trans\shop\ShopLogic();
		$flag = true;
		try
		{
			$rs = $logic->cancelMarkShop((Object)$data);
		}
		catch (Exception $e)
		{
			$flag = false;
			$rs = $e->getMessage();
		}
		if(!$flag)
		{
			$this->assertEquals($rs, '记录不存在，删除失败', 'testcancelMarkShop fail');
		}
		else
		{
			$this->assertTrue($rs['flag']);
		}
	}
	
	public function testAddDomainFavorite()
	{
		$logic =  new \logic\trans\shop\ShopLogic();
		$data = array('enameid'=>11000,'id'=>7872510,'transtype'=>1);
		$flag = true;
		try
		{
			$rs = $logic->addDomainFavorite((Object)$data);
		}
		catch (Exception $e)
		{
			$flag = false;
			$rs = $e->getMessage();
		}
		if(!$flag)
		{
			$this->assertEquals($rs, '您已经关注此域名了', 'testAddDomainFavorite fail');
		}
		else
		{
			$this->assertTrue($rs['flag']);
		}
	}
	
	public function testCancelDomainFavorite()
	{
		$logic =  new \logic\trans\shop\ShopLogic();
		$data = array('enameid'=>11000,'id'=>787251000,'transtype'=>1);
		$flag = true;
		try
		{
			$rs = $logic->cancelDomainFavorite((Object)$data);
		}	
		catch (Exception $e)
		{
			$flag = false;
			$rs = $e->getMessage();
		}
		if(!$flag)
		{
			$this->assertEquals($rs, '记录不存在', 'testCancelDomainFavorite fail');
		}
		else
		{
			$this->assertTrue($rs['flag']);
		}
	}
}
?>
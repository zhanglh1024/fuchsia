<?php
use tests\TestCase;
class BookLogicTest extends TestCase
{

	public function testBookDomainConfirm()
	{
		$logic = new \logic\trans\book\BookLogic();
		try 
		{
			$data = array('enameid' => 11000,'domainnames' => "");
			$rs = $logic->bookDomainConfirm((Object)$data);
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		$this->assertEquals($rs, '请选择需要预订的合法域名！', 'testBookDomainConfirm fail');
		
		
		$data = array('enameid' => 11000,'domainnames' => "aa.pw.com");
		$rs = $logic->bookDomainConfirm((Object)$data);
		$this->assertEquals($rs['errorDomains'][0]['msg'], '域名格式错误', 'testBookDomainConfirm fail');
		
		
		$data = array('enameid' => 11000,'domainnames' => "aa.pw");
		$rs = $logic->bookDomainConfirm((Object)$data);
		$this->assertEquals($rs['errorDomains'][0]['msg'], '此域名不支持预订', 'testBookDomainConfirm fail');
		
		$data = array('enameid'=>11000,'domainnames'=>'flights.ln.cn');
		$rs = $logic->bookDomainConfirm((Object)$data);
		$info = array('ExpiredDomainId'=>'1522633','DomainName'=>'flights.ln.cn','DelDate'=>'2014-08-01','BookPrice'=>50);
		$this->assertEquals($rs['enDomestic'][0], $info, 'testBookDomainConfirm fail');
		
		$data = array('enameid'=>11000,'domainnames'=>'邓涛.中国');
		$rs = $logic->bookDomainConfirm((Object)$data);
		$info = array('ExpiredDomainId'=>'1589455','DomainName'=>'邓涛.中国','DelDate'=>'2014-08-02','BookPrice'=>200);
		$this->assertEquals($rs['cnDomesticCn'][0], $info, 'testBookDomainConfirm fail');
		
		$data = array('enameid'=>11000,'domainnames'=>'3rw.net');
		$rs = $logic->bookDomainConfirm((Object)$data);
		$info = array('ExpiredDomainId'=>'6564436','DomainName'=>'3rw.net','DelDate'=>'2014-08-02','BookPrice'=>70);
		$this->assertEquals($rs['enInternational'][0], $info, 'testBookDomainConfirm fail');
		
		
		$data = array('enameid'=>11000,'domainnames'=>'r10.com.cn');
		$rs = $logic->bookDomainConfirm((Object)$data);
		$info = array('DomainName'=>'r10.com.cn','DelDate'=>'未确定','BookPrice'=>0);
		$this->assertEquals($rs['other'][0], $info, 'testBookDomainConfirm fail');
	}
	
	public function testCancelBook()
	{
		$logic =  new \logic\trans\book\BookLogic();
		$data = array('enameid'=>11000,'id'=>104103690);
		try
		{
			$rs = $logic->cancelBook((Object)$data);
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		$this->assertEquals($rs, '非法操作，此预订域名非您所有', 'testCancelBook fail');
		
		$data = array('enameid'=>11000,'id'=>10410169);
		try
		{
			$rs = $logic->cancelBook((Object)$data);
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		$this->assertEquals($rs, '该域名状态无法执行取消预订操作', 'testCancelBook fail');
		
		$data = array('enameid'=>11000,'id'=>10409004);
		try
		{
			$rs = $logic->cancelBook((Object)$data);
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		$this->assertEquals($rs, '抱歉！晚上11点后无法取消明天过期域名的预订！', 'testCancelBook fail');
		$rs = $logic->cancelBook((Object)array('enameid'=>11000,'id'=>10410369));
		$this->assertEquals($rs['flag'], true, 'testCancelBook fail');
	}
	
	public function testDoBookDomain()
	{
		$logic = new \logic\trans\book\BookLogic();
		$data = array('enameid'=>11000,'endomesticids'=>array('1587552'),'cndomesticids'=>array(),'eninternationalids'=>array(),'domainnames'=>array(),'nickname'=>11000);
		$rs = $logic->doBookDomain((Object)$data);
		$info = array('domainName'=>'4hc.cn','msg'=>'您已预订过该域名了','flag'=>0);
		$this->assertEquals($rs[0], $info, 'testCancelBook fail');
		
		$data = array('enameid'=>11000,'endomesticids'=>array(),'cndomesticids'=>array('1589489'),'eninternationalids'=>array(),'domainnames'=>array(),'nickname'=>11000);
		$rs = $logic->doBookDomain((Object)$data);
		$info = array('domainName'=>'深思.中国','msg'=>'预订成功','flag'=>1);
		$this->assertEquals($rs[0], $info, 'testCancelBook success');
		$data = array('enameid'=>11000,'endomesticids'=>array(),'cndomesticids'=>array(),'eninternationalids'=>array('6564153'),'domainnames'=>array(),'nickname'=>11000);
		$rs = $logic->doBookDomain((Object)$data);
		$info = array('domainName'=>'1xx6.com','msg'=>'预订成功','flag'=>1);
		$this->assertEquals($rs[0], $info, 'testCancelBook success');	
		
		$data = array('enameid'=>11000,'endomesticids'=>array(),'cndomesticids'=>array(),'eninternationalids'=>array(),'domainnames'=>array('opensource.net.cn'),'nickname'=>11000);
		$rs = $logic->doBookDomain((Object)$data);
		$info = array('domainName'=>'opensource.net.cn','msg'=>'预订成功','flag'=>1);
		$this->assertEquals($rs[0], $info, 'testCancelBook success');
		
		$data = array('enameid'=>11000,'endomesticids'=>array(),'cndomesticids'=>array(),'eninternationalids'=>array(),'domainnames'=>array('gtgt.cn'),'nickname'=>11000);
		$rs = $logic->doBookDomain((Object)$data);
		$info = array('domainName'=>'gtgt.cn','msg'=>'已经超过预订时间','flag'=>0);
		$this->assertEquals($rs[0], $info, 'testCancelBook fail');
	}
}
?>
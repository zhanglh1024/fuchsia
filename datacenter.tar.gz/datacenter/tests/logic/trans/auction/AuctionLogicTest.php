<?php
use tests\TestCase;
class AuctionLogicTest extends TestCase
{

	public function testAddDiySearch()
	{
		$logic = new \logic\trans\auction\AuctionLogic();
		$name = time();
		$data = array('enameid' => 11000,'domainsld' => '1234.com','skipword1' => '1','sldtypestart' => 1,
			'sldtypeend' => 1,'transtype'=>1,'domaintld' => 1,'domaingroup' => 1,'bidpricestart' => 20,'bidpriceend' => 100,
			'domainlenstart' => 4,'domainlenend' => 50,'registrar' => 1,'sort'=>2,'name'=>$name,'hidenobider'=>1,'bidstartone'=>1);
		$rs = $logic->addDiySearch((Object)$data);
		$this->assertEquals($rs['flag'], true, 'AddDiySearch success');
		
		$data = array('enameid' => 11000,'domainsld' => '1234.com','skipword1' => '1','sldtypestart' => 1,
			'sldtypeend' => 1,'transtype'=>1,'domaintld' => 1,'domaingroup' => 1,'bidpricestart' => 20,'bidpriceend' => 100,
			'domainlenstart' => 4,'domainlenend' => 50,'registrar' => 1,'sort'=>2,'name'=>'测试','hidenobider'=>1,'bidstartone'=>1);
		try
		{
			$rs = $logic->addDiySearch((Object)$data);
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		$this->assertEquals($rs, '此自定义搜索名称已存在！', 'AddDiySearch fail');
	}
	
	public function testDelDiySearch()
	{
		$logic  = new \logic\trans\auction\AuctionLogic();
		$data = $logic->getDiySearch((Object)array('enameid'=>11000));
		$count = isset($data['list']) ? count($data['list']) : 0; 
		if($count > 0)
		{
			$arr = array('enameid'=>11000,'id'=>$data['list'][$count-1]['id']);
			$rs = $logic->delDiySearch((Object)$arr);
			$this->assertEquals($rs['flag'], TRUE, 'DelDiySearch success');
		}
		
		try
		{
			$rs = $logic->delDiySearch((Object)array('enameid'=>11000,'id'=>99999));
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		
		$this->assertEquals($rs, '记录不存在', 'DelDiySearch fail');
	}
}
?>
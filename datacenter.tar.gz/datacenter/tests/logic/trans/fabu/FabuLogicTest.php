<?php
use tests\TestCase;
class FabuLogicTest extends TestCase
{
	public function testCancelAudit()
	{
		$logic = new \logic\trans\fabu\FabuLogic();
		$data = array('enameid'=>11000,'id'=>78720950);
		try
		{
			$rs = $logic->cancelAudit((Object)$data);
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		$this->assertEquals($rs, '非法操作', 'testCancelBook fail');
		
		$data = array('enameid'=>11000,'id'=>7872095);
		$rs = $logic->cancelAudit((Object)$data);
		$this->assertEquals($rs['flag'], true, 'testCancelBook success');
	}
	
	public function testDelPreTradeDomain()
	{
		$logic = new \logic\trans\fabu\FabuLogic();
		$data = array('enameid'=>11000,'domainName'=>'guzhenwwwww.cn');
		try
		{
			$rs = $logic->delPreTradeDomain((Object)$data);
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		$this->assertEquals($rs, '域名不在用户等待上架域名列表', 'testDelPreTradeDomain fail');
		
		$data = array('enameid'=>11000,'domainName'=>'guzhen.cn');
		$rs = $logic->delPreTradeDomain((Object)$data);
		$info = array('flag'=>true,'msg'=>'删除成功');
		$this->assertEquals($rs, $info, 'testDelPreTradeDomain success');
	}
	
	public function testFabuTrade()
	{
		$logic = new \logic\trans\fabu\FabuLogic(11000);
		//transdate不合法
		$data = array('enameid'=>11000,'domainname'=>'producttest11.org','register'=>1,'type'=>1,'transpoundage'=>2,'transdate'=>8,'transtime'=>21,'transmoney'=>600,'transdesc'=>'测试发布交易接口','questionid'=>311627,'answer'=>'111','pass'=>'6666660','identify'=>'T201','captcha'=>'');
		try
		{
			$rs = $logic->fabuTrade((Object)$data);
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		$this->assertEquals($rs, '交易结束日期出错', 'testFabuTrade fail');
		
		//transtime不合法
		$data = array('enameid'=>11000,'domainname'=>'producttest11.org','register'=>1,'type'=>1,'transpoundage'=>2,'transdate'=>1,'transtime'=>30,'transmoney'=>600,'transdesc'=>'测试发布交易接口','questionid'=>311627,'answer'=>'111','pass'=>'6666660','identify'=>'T201','captcha'=>'');
		try
		{
			$rs = $logic->fabuTrade((Object)$data);
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		$this->assertEquals($rs, '交易结束时间段出错', 'testFabuTrade fail');
		
		
		//transmoney
		$data = array('enameid'=>11000,'domainname'=>'producttest11.org','register'=>1,'type'=>1,'transpoundage'=>2,'transdate'=>1,'transtime'=>21,'transmoney'=>0,'transdesc'=>'测试发布交易接口','questionid'=>311627,'answer'=>'111','pass'=>'6666660','identify'=>'T201','captcha'=>'');
		try
		{
			$rs = $logic->fabuTrade((Object)$data);
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		$this->assertEquals($rs, '价格不能为空', 'testFabuTrade fail');
		
		//transmoney
		$data = array('enameid'=>11000,'domainname'=>'producttest11.org','register'=>1,'type'=>1,'transpoundage'=>2,'transdate'=>1,'transtime'=>21,'transmoney'=>505,'transdesc'=>'测试发布交易接口','questionid'=>311627,'answer'=>'111','pass'=>'6666660','identify'=>'T201','captcha'=>'');
		try
		{
			$rs = $logic->fabuTrade((Object)$data);
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		$this->assertEquals($rs, '相关价格不符合规则,超过499元的域名加价幅度为50元,建议您把价格设为500或550', 'testFabuTrade fail');
		
		$logic = new \logic\trans\fabu\FabuLogic(574411);
		$data = array('enameid'=>574411,'domainname'=>'producttest11.org','type'=>1,'transpoundage'=>2,'transdate'=>1,'transtime'=>21,'transmoney'=>500,'transdesc'=>'测试发布交易接口','questionid'=>311627,'answer'=>'111','pass'=>'6666660','identify'=>'T201','captcha'=>'');
		try
		{
			$rs = $logic->fabuTrade((Object)$data);
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		$this->assertEquals($rs, '域名不属于此人', 'testFabuTrade fail');
		
		$logic = new \logic\trans\fabu\FabuLogic(11000);
		
		
		$data = array('enameid'=>11000,'domainname'=>'producttest11.org','type'=>1,'transpoundage'=>2,'transdate'=>1,'transtime'=>21,'transmoney'=>500,'transdesc'=>'测试发布交易接口','questionid'=>311627,'answer'=>'111','pass'=>'6666660','identify'=>'T201','captcha'=>'');
		try
		{
			$rs = $logic->fabuTrade((Object)$data);
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		$this->assertEquals($rs, '域名正在交易中', 'testFabuTrade fail');
		
		$data = array('enameid'=>11000,'domainname'=>'0juli.com.cn','type'=>1,'transpoundage'=>2,'transdate'=>1,'transtime'=>21,'transmoney'=>500,'transdesc'=>'测试发布交易接口','questionid'=>311627,'answer'=>'111','pass'=>'6666660','identify'=>'T201','captcha'=>'');
		try
		{
			$rs = $logic->fabuTrade((Object)$data);
		}
		catch (Exception $e)
		{
			$rs = $e->getMessage();
		}
		$this->assertEquals($rs, '域名已经过期', 'testFabuTrade fail');
		//发布竞价
		$data = array('enameid'=>11000,'domainname'=>'afsdffsafdb131.com','type'=>1,'transpoundage'=>2,'transdate'=>1,'transtime'=>21,'transmoney'=>500,'transdesc'=>'测试发布交易接口','questionid'=>311627,'answer'=>'111','pass'=>'6666660','identify'=>'T201','captcha'=>'');
		$rs = $logic->fabuTrade((Object)$data);
		$info = array('flag'=>1,'msg'=>'发布成功');
		$this->assertEquals($rs, $info, 'testFabuTrade success');

		//发布一口价
		$data = array('enameid'=>11000,'domainname'=>'badun13.org','type'=>2,'transpoundage'=>2,'transdate'=>1,'transtime'=>21,'transmoney'=>500,'transdesc'=>'测试发布交易接口','questionid'=>311627,'answer'=>'111','pass'=>'6666660','identify'=>'T201','captcha'=>'');
		$rs = $logic->fabuTrade((Object)$data);
		$info = array('flag'=>1,'msg'=>'发布成功');
		$this->assertEquals($rs, $info, 'testFabuTrade success');
			
		//发布询价
		$data = array('enameid'=>11000,'domainname'=>'badun12.org','type'=>3,'transpoundage'=>2,'transdate'=>30,'transtime'=>21,'transmoney'=>500,'transdesc'=>'测试发布交易接口','questionid'=>311627,'answer'=>'111','pass'=>'6666660','identify'=>'T201','captcha'=>'');
		$rs = $logic->fabuTrade((Object)$data);
		$info = array('flag'=>1,'msg'=>'发布成功');
		$this->assertEquals($rs, $info, 'testFabuTrade success');

		//发布易拍易卖
		$data = array('enameid'=>11000,'domainname'=>'badun11.org','type'=>4,'transpoundage'=>2,'transdate'=>1,'transtime'=>21,'transmoney'=>1,'transdesc'=>'测试发布交易接口','questionid'=>311627,'answer'=>'111','pass'=>'6666660','identify'=>'T201','captcha'=>'','agent'=>3);
		$rs = $logic->fabuTrade((Object)$data);
		$info = array('flag'=>1,'msg'=>'发布成功');
		$this->assertEquals($rs, $info, 'testFabuTrade success');
		
		//发布专题拍卖
		$data = array('enameid'=>11000,'domainname'=>'bingdian.com','type'=>5,'transpoundage'=>2,'transdate'=>1,'transtime'=>21,'transmoney'=>1,'transdesc'=>'测试发布交易接口','questionid'=>311627,'answer'=>'111','pass'=>'6666660','identify'=>'T201','captcha'=>'','agent'=>'','transtopic'=>2);
		$rs = $logic->fabuTrade((Object)$data);
		$info = array('flag'=>1,'msg'=>'发布成功');
		$this->assertEquals($rs, $info, 'testFabuTrade success');
	}
}
?>
<?php
class LogincheckPlugin extends Yaf\Plugin_Abstract
{

	public function routerShutdown(Yaf\Request_Abstract $request, Yaf\Response_Abstract $response)
	{
		if('index'==strtolower($request->controller))
		{
			return true;
		}
		$user = isset($_GET['user'])? trim($_GET['user']) :FALSE;
		$ip = isset($_GET['ip'])? trim($_GET['ip']) :FALSE;
		if(!$user)
		{
			core\Response::msg('user param can not empty', 2003);
		}
		if(!$ip || common\Common::CheckIp($ip) == false)
		{
			core\Response::msg('ip param can not empty', 2004);
		}
		$ip = common\Client::getIp(); 
		$access = Yaf\Registry::get("access");
		$account = $access->account->account->user;
		if(isset($account->$user) && in_array($ip, explode(",", $account->$user->ip)))
		{
			if(!$this->parseFunc($account->$user->func, $request))
			{
				core\Response::msg($request->controller . '/' . $request->action . ' not allow!', 2002);
			}
		}
		else
		{
			core\Response::msg('ip not allow!', 2001);
		}
	}

	/**
	 * 检测当前URL是否的授权列表
	 *
	 * @param 权限列表 $func        	
	 * @param 当前URL信息 $nowUrl        	
	 * @return boolean
	 */
	private function parseFunc($func, $nowUrl)
	{
		$funList = explode(',', $func);
		$isAllow = false;
		foreach($funList as $v)
		{
			list($m, $c, $f) = explode('/', strtolower($v));
			if($m == strtolower($nowUrl->module) || $m == '*')
			{
				if($c == '*' || $c == strtolower($nowUrl->controller))
				{
					if($f == '*' || $f == strtolower($nowUrl->action))
					{
						$isAllow = true;
						break;
					}
				}
			}
		}
		return $isAllow;
	}
}
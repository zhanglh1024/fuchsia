<?php
namespace interfaces\bbs;

class Bbs
{

	/**
	 * 根据 enameId 获取论坛id
	 * 
	 * @param int $enameId
	 * @author xionyy
	 */
	public function getUid($enameId)
	{
		$pepSDK = new \models\bbs\PreEnamePluginMod();
		return $pepSDK->getUid($enameId);
	}

	/**
	 * 添加玉米变更记录
	 *
	 * @param string $operation 操作备注
	 * @param int $credit 玉米
	 * @param int $uid 必需登录ID
	 * @param int $tid 关联的用户id
	 * @return boolean
	 * @author xionyy
	 */
	public function addCreditsLog($operation, $credit, $uid, $tid)
	{
		$pcclSDK = new \models\bbs\PreCommonCreditLogMod();
		$rs = $pcclSDK->addCreditsLog($operation, $credit, $uid, $tid);
		return $rs? TRUE: FALSE;
	}

	/**
	 * 通过用户ID获取用户玉米数
	 * 
	 * @param int $uid 用户ID（必须）
	 * @author xionyy
	 */
	public function getCredits($uid)
	{
		$pcmcSDK = new \models\bbs\PreCommonMemberCountMod();
		return $pcmcSDK->getCredits($uid);
	}

	/**
	 * 更新 用户 的玉米数量
	 * 
	 * @param int $credit 玉米
	 * @param int $uid 用户id
	 * @return boolean
	 * @author xionyy
	 */
	public function updateCredits($credit, $uid)
	{
		$pcmcSDK = new \models\bbs\PreCommonMemberCountMod();
		$res = $pcmcSDK->updateCredits($credit, $uid);
		return $res? TRUE: FALSE;
	}

	/**
	 * 中秋博饼操作 扣除域名数量并记录日志
	 * 
	 * @param int $credit 玉米 (负数: 如-50)
	 * @param int $uid 用户id
	 * @ author xiongyy
	 */
	public function BobingAction($credit, $uid)
	{
		$pcmcSDK = new \models\bbs\PreCommonMemberCountMod();
		$peclSDK = new \models\bbs\PreEnameCreditLogMod();
		$res1 = $pcmcSDK->updateCredits($credit, $uid);
		$res2 = $peclSDK->addCreditsLog('BOB', $credit, $uid, 0);
		return ($res1 && $res2)? TRUE: FALSE;
	}
	
	
	public function checkIsKeyWord($word)
	{
		$keyWordMod = new \models\trans\KeyWordsMod();
		$tempkey = $keyWordMod->getAll();
		$keyWords = $tempkey? $this->changeKeyWords($tempkey): array();
		
		return $this->checkIsKeyWords($word, $keyWords);
	}
	
	public function changeKeyWords($data)
	{
		$temp = array();
		if($data)
		{
				
			foreach($data as $v)
			{
				$temp[] = $v['word'];
			}
		}
		return $temp;
	}
	
	public function checkIsKeyWords($str, $keyWords)
	{
		$flag = false;
		$keys = array();
		foreach($keyWords as $v)
		{
			if(substr_count($str, $v))
			{
				$flag = true;
				$keys[]= $v;
				continue;
			}
		}
		return array('flag'=>$flag,'keyWords'=>$keys);
	}
}
<?php
namespace interfaces\manage;
use core\Response;
class Whois
{
	private $logic;
	public function __construct()
	{
		$this->logic = new \logic\manage\whois\WhoisLogic();
	}

	/**
	 * 获取whois基本信息 0101
	 * @param string $domain
	 * @return array|boolean
	 */
	public function getWhois($domain)
	{
		$rs = $this->logic->getWhois($domain);
		if(FALSE == $rs)
		{
			Response::setErrMsg(Response::getErrCode(), Response::getErrMsg());
		}
		return $rs;
	}

	/**
	 * 获取whois基本信息 0102
	 * @param string $domain
	 * @return array|boolean
	 */
	public function getWhoisHasMail($domain)
	{
		$rs = $this->logic->getWhois($domain, TRUE);
		if(FALSE == $rs)
		{
			Response::setErrMsg(Response::getErrCode(), Response::getErrMsg());
		}
		return $rs;
	}

	/**
	 * 获取whois详细信息 0103
	 * @param string $domain
	 * @return string|boolean
	 */
	public function getWhoisDetail($domain, $whoisServer)
	{
		$rs = $this->logic->getWhoisDetail($domain, $whoisServer);
		if(FALSE == $rs)
		{
			Response::setErrMsg(Response::getErrCode(), Response::getErrMsg());
		}
		return $rs;
	}
}

<?php
namespace interfaces\manage;
use core\Response;
class Queue
{
	/**
	 * 发邮件 9001
	 * @param string $templateId
	 * @param string $email
	 * @param string $tplData json_encode 模板变量值
	 * @param int $enameId
	 * @param int $taskId
	 * @param string $function
	 * @param int $priority 1-5，5表示直接发送
	 * @return boolean|int 
	 */
	public function sendMail($templateId, $email, $tplData = '', $enameId = 0, $taskId = 0,
			$function = 'sendmail', $priority = 5)
	{
		$tplData = is_array($tplData) ? $tplData : json_decode($tplData);
		$queueLogic = new \logic\manage\newqueue\QueueLogic();
		$params = array('Function' => 'sendmail', 'Target' => $email, 'EnameId' => $enameId, 'Priority' => $priority,
			'Data' => $tplData, 'TemplateName' => $templateId);
		try 
		{
			$rs = $queueLogic->addQueueNormal($params);
			return $rs;
		}
		catch (\Exception $e)
		{
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}

	/**
	 * 发短信 9005
	 * @param string $templateId
	 * @param string $phone
	 * @param string $tplData json_encode
	 * @param int $enameId
	 * @param int $taskId
	 * @param string $function
	 * @param int $priority 1-5，5表示直接发送，失败不入库也不重发
	 * @return boolean|int
	 */
	public function sendSms($templateId, $phone, $tplData = '', $enameId = 0, $taskId = 0, $function = 'send_sms',
			$priority = 5)
	{
		$tplData = is_array($tplData) ? $tplData : json_decode($tplData);
		$queueLogic = new \logic\manage\newqueue\QueueLogic();
		$params = array('Function' => 'send_sms', 'Target' => $phone, 'EnameId' => $enameId, 'Priority' => $priority,
			'Data' => $tplData, 'TemplateName' => $templateId);
		try
		{
			$rs = $queueLogic->addQueueNormal($params);
			return $rs;
		}
		catch (\Exception $e)
		{
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}

	/**
	 * 发语音短信 9003
	 * @param string $templateId
	 * @param string $phone
	 * @param string $tplData json_encode
	 * @param int $enameId
	 * @param int $taskId
	 * @param string $function
	 * @param int $priority 1-5，5表示直接发送，失败不入库也不重发
	 * @return boolean|int
	 */
	public function sendAudioSms($templateId, $phone, $tplData = '', $enameId = 0, $taskId = 0,
			$function = 'send_audio_sms', $priority = 5)
	{
		$tplData = is_array($tplData) ? $tplData : json_decode($tplData);
		$queueLogic = new \logic\manage\newqueue\QueueLogic();
		$params = array('Function' => 'send_audio_sms', 'Target' => $phone, 'EnameId' => $enameId, 'Priority' => $priority,
			'Data' => $tplData, 'TemplateName' => $templateId);
		try
		{
			$rs = $queueLogic->addQueueNormal($params);
			return $rs;
		}
		catch (\Exception $e)
		{
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}
	
	/**
	 * 发送站内信
	 * @param int $enameId
	 * @param string $templateId
	 * @param array $data
	 * @param int $type
	 * @return boolean
	 */
	public function sendSiteMsg($enameId, $templateId, $data, $type = 12)
	{
		$smsLogic = new \logic\manage\queue\SmsLogic();
		$rs = $smsLogic->sendSiteMsg($enameId, $templateId, $data, $type);
		if(FALSE == $rs)
		{
			Response::setErrMsg(Response::getErrCode(), Response::getErrMsg());
		}
		return $rs;
	}
	
	/**
	 * 添加批量任务 9009
	 * @param object $data
	 * @return array|boolean
	 */
	public function addTask($data)
	{
		$queueLogic = new \logic\manage\newqueue\QueueLogic();
		$params = array('Function' => $data->function, 'EnameId' => $data->enameId, 'Data' => $data->data);
		$params['Priority'] = empty($data->priority) ? 1 : $data->priority;
		try
		{
			return $queueLogic->addQueueTask($params);
		}
		catch (\Exception $e)
		{
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}
}

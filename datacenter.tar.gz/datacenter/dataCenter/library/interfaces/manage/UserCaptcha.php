<?php
//todo 整理errcode
namespace interfaces\manage;
use \core\Response;
class UserCaptcha
{ 
	/**
	 * 获取操作保护信息（设置中心）
	 * @param string $identify
	 * @param int $enameId
	 * @param int $questionId 非必须（一般是验证操作保护时重新获取操作保护验证才需要）
	 * @param int  $version 1表示中文版本  2表示英文版本
	 * @return array|boolean
	 */
	public function getOperateData($identify, $enameId, $questionId = 0,$version = 1)
	{
		try
		{ 
			$version = $version == 1 ? 1 : 2;//1中文  2英文
			$operateLogic = new \logic\manage\member\OperateLogic();
			$rs = $operateLogic->getData((object)array('identify' => $identify, 'EnameId' => $enameId,
					'questionId' => $questionId,'version'=>$version));
			if(is_array($rs))
			{
				if(1 == $rs['flag'])
				{
					return $rs['msg'];
				}
				Response::setErrMsg(100001, $rs['msg']);
			}
			return FALSE;
		}
		catch(\Exception $e)
		{
			Response::setErrMsg(100001, $e->getMessage());
			return FALSE;
		}
	}

	/**
	 * 验证操作保护
	 * @param array $info array('identify'=>操作保护标示,'EnameId','questionId','answer','captcha')
	 * @param $flag 是否将验证码设置为已使用
	 * @return boolean
	 */
	public function checkOperateData($info, $flag = FALSE)
	{
		try
		{
			$userLogic = new \logic\manage\member\OperateLogic();
			return $userLogic->checkOperate($info, $flag) ? TRUE : FALSE;
		}
		catch(\Exception $e)
		{
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}

	/**
	 * 发送验证码
	 * @param array('EnameId','smsconfig','purpose'')
	 * @return string|boolean
	 */
	public function sendMobileSmsCaptcha($info)
	{
		try
		{
			$userLogic = new \logic\manage\member\UserCaptachaLogic();
			$rs = $userLogic->sendMobileSmsCaptcha($info);
			if(is_array($rs))
			{
				if(1 == $rs['flag'])
				{
					return $rs['msg'];
				}
				Response::setErrMsg(100001, $rs['msg']);
			}
			return FALSE;
		}
		catch(\Exception $e)
		{
			Response::setErrMsg(100001, $e->getMessage());
			return FALSE;
		}
	}
	/**
	 * 发送验证码
	 * @param array('EnameId','smsconfig','purpose'')
	 * @return string|boolean
	 */
	public function sendMobileVoiceCaptcha($info)
	{
		try
		{
			$userLogic = new \logic\manage\member\UserCaptachaLogic();
			$rs = $userLogic->sendMobileVoiceSmsCaptcha($info);
			if(is_array($rs))
			{
				if(1 == $rs['flag'])
				{
					return $rs['msg'];
				}
				Response::setErrMsg(100001, $rs['msg']);
			}
			return FALSE;
		}
		catch(\Exception $e)
		{
			Response::setErrMsg(100001, $e->getMessage());
			return FALSE;
		}
	}
}

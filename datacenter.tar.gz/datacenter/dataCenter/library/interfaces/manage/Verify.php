<?php
namespace interfaces\manage;
use core\Response;

class Verify
{

	/**
	 * 查询是否bbs认证
	 *
	 * @param int $enameid        	
	 */
	public function queryDnbbsAction($enameid)
	{
		$verifyLogic = new \logic\manage\verify\VerifyLogic();
		return $verifyLogic->queryDnbbs($enameid);
	}
	
	/**
	 * 判断域名whois上的email是否认证
	 * @param int $enameId
	 * @param string $email
	 * @return boolean 
	 */
	public function queryEmailVerify($email, $enameId)
	{
		$verifyLogic = new \logic\manage\verify\VerifyLogic('email');
		return $verifyLogic->queryEmailVerify($email, $enameId);
	}
}
<?php
namespace interfaces\portal;

class ManageInterface
{
	/**
	 * 获得用户站内信的数量
	 */
	public function getSiteMessageCount($enameId)
	{
		$interface = new \interfaces\manage\Member();
		return $interface->getUnreadMessCount($enameId);
	}
	
	/**
	 * 获取用户购物车数量
	 */
	public function getSiteCartCount($enameId)
	{
		$interface = new \interfaces\manage\Cart();
		return $interface->getCartCount($enameId);
	}
	
	/**
	 * 管理平台积分操作
	 */
	public function setUserScore($data)
	{
		$interface = new \interfaces\manage\Finance();
		return $interface->updateFinanceScore($data);
	}
	
	/**
	 * 获取用户昵称和头像
	 */
	public function getUserAppInfo($enameId)
	{
		$interface = new \interfaces\manage\Member();
		return $interface->getAppMemberInfo($enameId);
	}
}
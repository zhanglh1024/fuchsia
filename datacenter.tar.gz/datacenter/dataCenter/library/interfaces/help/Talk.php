<?php
namespace interfaces\help;
class Talk
{
	/**
	 * 获取聊天信息流
	 * @param $enameId 用户Id
	 * @return array('help'=>array('num'=>2, 'msg'=>'test'), 'escrow'=>array('num'=>0, 'msg'=>''))
	 */
	public function getTalkStream($enameId)
	{
		if(!$enameId)
		{
			return array('help' => array('num'=>0, 'msg'=>'', 'sendTime'=>0), 'escrow' => array('num'=>0, 'msg'=>'', 'sendTime'=>0));
		}
		$talkMod = new \models\help\TalkUserMod();
		//客服
		$help = $talkMod->getHelpTalkUser($enameId);
		if($help)
		{
			if($help['role']!=2)
			{
				$help['num'] = 0;
			}
			unset($help['role']);
		}
		else 
		{
			$help = array('num'=>0, 'msg'=>'', 'sendTime'=>0);
		}
		$escrow = $talkMod->getEscrowTalkUser($enameId);
		//经纪
		if($escrow)
		{
			if($escrow['role']!=2)
			{
				$escrow['num'] = 0;
			}
			unset($escrow['role']);
		}
		else 
		{
			$escrow = array('num'=>0, 'msg'=>'', 'sendTime'=>0);
		}
		return array('help' => $help, 'escrow' => $escrow);
	}
}

<?php
namespace interfaces\help;

class Statistics
{

	/**
	 * 客服工作情况统计
	 * 参数：array data(csid=>xx, cstype=>xx,cscount=>xx)
	 * 返回 array('msg'=>xxxx,'flag'=>xx)
	 * xxxx:操作提示信息
	 * flag:为true或false,false:表示添加操作不完全成功
	 */
	public function work($data)
	{
		$logic = new \logic\help\statistics\StatisticsLogic();
		$i=0;
		$j=0;
		foreach($data as $k=>$v)
		{
			$v['vtime'] = strtotime($v['vtime']);
			$rs = $logic->work((Object)$v);
			if(false === $rs)
			{
				$i++;
			}
			else
			{
				$j++;
			}
		}
		if($i)
		{
			return array('msg'=>'操作成功'.$j.'条,操作失败'.$i.'条','flag'=>false);
		}
		else
		{
			return array('msg'=>'操作成功','flag'=>true);
		}
	}
}
?>
<?php
namespace interfaces\trans;

use core\Response;
class Queue
{ 

	private $interface;

	public function __construct()
	{
		$this->interface = new \interfaces\manage\Queue();
	}

	/**
	 * 发送邮件
	 * 
	 * @param string $templateId        	
	 * @param string $email        	
	 * @param array $tplData        	
	 * @param int $enameId        	
	 */
	public function sendMail($templateId, $email, $tplData, $enameId,$priority = 5)
	{
		$rs = $this->interface->sendMail($templateId, $email, json_encode($tplData), $enameId,$taskId = 0, 'sendmail', $priority);
		if($rs == false)
		{
			\core\Log::write("sendMail,$templateId,$email,$enameId,$priority,".json_encode($tplData).'code:' . Response::getErrCode() . ',' . 'msg:' . Response::getErrMsg(), 'queue');
		}
		return $rs;
	}

	/**
	 * 发送站内信
	 * 
	 * @param int $enameId        	
	 * @param int $templateId        	
	 * @param array $tplData        	
	 * @param int $type        	
	 */
	public function sendSiteMsg($enameId, $templateId, $tplData, $type=12)
	{
		$rs = $this->interface->sendSiteMsg($enameId, $templateId, $tplData, $type);
		if($rs == false)
		{
			\core\Log::write("sendSiteMsg,$templateId,$type,$enameId,".json_encode($tplData).'code:' . Response::getErrCode() . ',' . 'msg:' . Response::getErrMsg(), 'queue');
		}
		return $rs;
	}
	
	
	public function sendSms($templateId, $phone, $tplData, $enameId, $priority = 5)
	{
		$rs = $this->interface->sendSms($templateId, $phone, json_encode($tplData), $enameId, $priority);
		if($rs == false)
		{
			\core\Log::write("sendSms,$templateId,$phone,$enameId,$priority,".json_encode($tplData).'code:' . Response::getErrCode() . ',' . 'msg:' . Response::getErrMsg(),'queue');
		}
		return $rs;
	}
}
?> 
<?php
namespace interfaces\trans;
use \core\Response as Response;
class Member
{

	private $interface;

	public function __construct()
	{
		$this->interface = new \interfaces\manage\Member();
	}

	/**
	 * 获得用户站内信的数量
	 */
	public function getSiteMessageCount($EnameId)
	{
		return $this->interface->getUnreadMessCount($EnameId);
	}

	/**新版交易
	 * 获取交易发布提现和不可提现的设置
	 * 0 不可提现 1可提现
	 */
	public function getAcceptInfo($EnameId)
	{
		$rs = $this->interface->getAcceptInfo($EnameId);
		if($rs['flag'])
		{
			return $rs['msg']['AcceptType'];
		}
		else
		{
			throw new \Exception(Response::getErrMsg(), Response::getErrCode());
		}
	}

	/**
	 * 通过EnameId获取用户的所有详细信息
	 *
	 * @param
	 *        	$enameid
	 */
	public function getMemberInfoByEnameId($enameId)
	{
		$userLogic = new \interfaces\manage\Member();
		return $userLogic->getMemberInfoByEnameId($enameId);
	}

	/**
	 * 增加警报消息
	 *
	 * @param int $enameid        	
	 * @param int $BusinessType
	 *        	业务类型 1 => '域名push', 2 => '域名转出', 3 => '结算失败', 4 => '平台登录', 5 => '操作保护', 6 => '在线充值', 7 => '域名转入', 8 => '转入后交易'
	 * @param string $domain        	
	 * @param string $Content
	 *        	内容
	 * @param string $Ext
	 *        	扩展字段
	 * @param string $IP        	
	 * @param int $Priority
	 *        	优先级	1 => 域名转出,2=>操作保护,3=>在线充值,4=>结算失败（域名注册/续费）、账号登陆、域名转入,5=>域名push、转入后交易
	 * @param int $CreateDate
	 *        	创建时间(时间戳)
	 */
	public function addSecureWarning($enameId, $businessType, $domain, $content, $priority, $ip = '', $ext = '', 
		$createdate = '')
	{
		$info = array('enameid' => $enameId,'BusinessType' => $businessType,'domain' => $domain,'Content' => $content,
			'Priority' => $priority,'IP' => $ip,'EXT' => $ext,'CreateDate' => $createdate?  :time());
		$userLogic = new \interfaces\manage\Member();
		return $userLogic->addSecureWarning($info);
	}
	
	/**
	 * 是否手机绑定
	 *
	 * @param
	 *        	$enameid
	 */
	public function isBindMobile($enameId)
	{ 
		$this->logic = new \interfaces\manage\Member();
		return $this->logic->getIsMobile($enameId); 
	}
	/**
	 * 判断用户是否 身份认证 手机绑定(及海外用户认证)
	 * @param unknown $enameId
	 */
	public function getMemberVerify($enameId)
	{
		$this->logic = new \interfaces\manage\Member();
	  return $this->logic->getMemberVerify($enameId);
	}
	
	/**
	 * 获取购物车数量
	 * @param integer $enameId
	 */
	public function getCartCount($enameId)
	{
		$this->logic = new \interfaces\manage\Cart();
		return $this->logic->getCartCount($enameId);
	}
}
<?php
namespace interfaces\trans;

class Custompage
{

	/**
	 * 统计审核模版的数量
	 * 
	 * @param unknown $data($data->status:模版状态,1通过,4不通过,默认是统计通过和不通过的，$data->timerange
	 *        	: 时间范围,默认的是当天0点～24点)
	 * @return Ambigous <\models\trans\Ambigous, boolean, mixed>
	 */
	public function totalAuditTemp($data = null)
	{
		$logic = new \logic\trans\custompage\CustompageLogic();
		return $logic->totalAuditTemp($data);
	}
}
?>
<?php
namespace interfaces\trans;
use core\Response;
class Shop
{

	/**
	 * 获取店铺信息
	 * @param uid:用户ID
	 * return shopName:店铺名称
	 */
	public function shopInfo($data)
	{
		$shopLogic = new \logic\trans\shop\ShopLogic();
		try
		{
			$data = $shopLogic->getShopInfo($data,1);
		}
		catch (\Exception $e)
		{
			$data = array();
			$data['list']['shopName']='';
		}		
		return $data;
	}
}
?>
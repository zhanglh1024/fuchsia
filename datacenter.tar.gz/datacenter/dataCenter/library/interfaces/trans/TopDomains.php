<?php
namespace interfaces\trans;

class TopDomains
{

	/**
	 * 提供给管理模块的接口 获取域名珍品等级
	 * 
	 * @param string $domain        	
	 */
	public function getTopDomainLevel($domain)
	{
		$logic = new \logic\trans\topdomain\TopDomainLogic();
		return $logic->getTopDomainLevel($domain);
	}
	/**
	 * 獲取珍品域名
	 * @param array $status 审核状态 1待 2通过 3未通过 4用户取消  9删除，默認是通過的
	 * @param array $beach  抢滩信息     1一期   2二期   3三期，默認是0
	 * @return Ambigous <\logic\trans\topdomain\multitype:multitype:Ambigous, multitype:multitype:Ambigous <multitype:>  >
	 */
	public function getTopDomain($status=array(),$beach=array())
	{
		$logic = new \logic\trans\topdomain\TopDomainLogic();
		$status = $status ? implode(',', $status) : array();
		$beach = $beach ? implode(',', $beach) : array();
		$data = array('status'=>$status,'beach'=>$beach);
		return $logic->getTopDomain((Object)$data);	
	}
}
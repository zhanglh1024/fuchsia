<?php
	namespace interfaces\trans;
	use \core\Response as Response;
	class UserCaptcha
	{
		private $interface; 
		
		public function __construct()
		{
			$this->interface = new \interfaces\manage\UserCaptcha();
		}
		public function getOperateData($identify, $enameId, $questionId = 0)
		{
			return $this->interface->getOperateData($identify, $enameId, $questionId);
		}
		/**
		 * @param array $info
		 * array('identify'=>操作保护标示,'EnameId','questionId','answer','captcha','pass')
		 * 其中 questionId，answer，captcha,pass 可以为空
		 * identify和EnameId不能为空
		 * @param boolean $noSetUsed true,仅验证,不将验证码设为使用过；默认为false
		 * @return boolean
		 */
		public function checkOperateData($info, $noSetUsed = false)
		{
			\core\Log::write(json_encode($info),'trans','checkOperation');
			$rs = $this->interface->checkOperateData($info, $noSetUsed);
			\core\Log::write(json_encode($rs).','.Response::getErrCode().','.Response::getErrMsg(),'trans','checkOperation');
			if(!$rs)
			{
				throw new \Exception(Response::getErrMsg(),Response::getErrCode());
			}
		}
		
		/**
		 * 发送短信验证码0240
		 * @param unknown $info
		 * @throws \Exception
		 * @return Ambigous <string, boolean, number, multitype:number multitype:string  , multitype:number multitype:Ambigous <number, unknown>  Ambigous <string, string, number, Ambigous <number, unknown_type>, Ambigous <number, multitype:>> >
		 */
		public function sendMobileSmsCaptcha($info)
		{
			$rs = $this->interface->sendMobileSmsCaptcha($info);
			if(!$rs)
			{
				throw new \Exception(Response::getErrMsg(),Response::getErrCode());
			}
			return $rs;
		}
		/**
		 * 发送语音验证码0241
		 * @param unknown $info
		 * @throws \Exception
		 * @return Ambigous <string, boolean, number, multitype:number multitype:Ambigous <number, unknown>  Ambigous <string, string, number, Ambigous <number, unknown_type>, Ambigous <number, multitype:>> >
		 */
		public function sendMobileVoiceCaptcha($info)
		{
			$rs = $this->interface->sendMobileVoiceCaptcha($info);
			if(!$rs)
			{
				throw new \Exception(Response::getErrMsg(),Response::getErrCode());
			}
			return $rs;
		}
	}
?>
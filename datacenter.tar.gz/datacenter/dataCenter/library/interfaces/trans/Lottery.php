<?php
namespace interfaces\trans;

use \core\Response as Response;
class Lottery
{

	private $interface;

	public function __construct()
	{
		$this->interface = new \interfaces\lottery\Lottery();
	}

	/**
	 * 设置域名状态
	 *
	 * @param unknown $domainName        	
	 * @param unknown $domainStatus        	
	 * @return boolean
	 */
	public function creatCode($enameid, $transid, $domain, $bidtime)
	{
		$std = new \stdClass();
		$std->enameid = $enameid;
		$std->transid = $transid;
		$std->domain = $domain;
		$std->bindtime = date('Y-m-d H:i:s', $bidtime);
		return json_encode($this->interface->CreatCode($std));
	}
	
	/**
	 * 生成抽奖机会表
	 *
	 * @param $info enameid 交易ID，  expiretime 过期时间,domain 域名
	 */
	public function addChance($enameid, $time, $domain)
	{
		$std = new \stdClass();
		$std->enameid = $enameid;
		$std->time = $time;
		$std->domain  = $domain;
		return json_encode($this->interface->addChance($std));
	}
}
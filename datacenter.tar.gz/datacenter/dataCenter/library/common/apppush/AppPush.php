<?php
namespace common\apppush;

class AppPush
{

	protected $pushConf = NULL;

	protected $time = NULL;

	protected $device_token = NULL;

	protected $device_type = NULL;

	protected $adminId = NULL;

	function __construct($adminId, $token = '')
	{
		$this->pushConf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'apppush');
		$this->time = strval(time());
		$this->device_token = $token; // 设备号
		$this->adminId = $adminId; // 后台id
		if($token)
		{
			$this->device_type = strlen($this->device_token) > 50 ? 1 : 2; // 1 是ios
			                                                              // 手机 2
			                                                              // 是android 手机
		}
		else
		{
			$this->device_type = 3; // 广播的时候 都是 3
		}
	}

	/**
	 * title 是 标题
	 * text 是内容
	 * extra 是 额外参数
	 * 
	 * @param array $data        	
	 * @return boolean
	 */
	public function push($data)
	{
		// ios 手机 单播
		if($this->device_type == 1 && $data['flag'] == 1)
		{
			$iMess = $this->sendIOSUnicast($data['title'] . $data['text'], $data['extra']);
			$this->pushLog($data['flag'], $iMess, $data['title'] . $data['text']. '-ios');
			return $iMess['ret'] == 'SUCCESS' ? true : false;
		}
		// Android 手机 单播
		if($this->device_type == 2 && $data['flag'] == 1)
		{
			$aMess = $this->sendAndroidUnicast($data['title'], $data['text'], $data['extra']);
			$this->pushLog($data['flag'], $aMess, $data['title']. '-andriod');
			return $aMess['ret'] == 'SUCCESS' ? true : false;
		}
		// ios 手机 广播
		if($this->device_type == 3 && $data['flag'] == 2)
		{
			$iMess = $this->sendIOSBroadcast($data['title'] . $data['text'], $data['extra']);
			$this->pushLog($data['flag'], $iMess, $data['title'] . '-ios');
			return $iMess['ret'] == 'SUCCESS' ? true : false;
		}
		// Android 手机 广播
		if($this->device_type == 3 && $data['flag'] == 3)
		{
			$aMess = $this->sendAndroidBroadcast($data['title'], $data['text'], $data['extra']);
			$this->pushLog($data['flag'], $aMess, $data['title'] . '-andriod');
			return $aMess['ret'] == 'SUCCESS' ? true : false;
		}
		return true;
	}

	/**
	 * Android 广播
	 */
	public function sendAndroidBroadcast($title, $text, $extra = '')
	{
		$brocast = new AndroidBroadcast();
		$brocast->setAppMasterSecret($this->pushConf->android->appMasterSecret);
		$brocast->setPredefinedKeyValue("appkey", $this->pushConf->android->appKey); // 应用唯一标识
		$brocast->setPredefinedKeyValue("timestamp", $this->time); // 时间戳有效期为10分钟
		$brocast->setPredefinedKeyValue("ticker", $title); // 通知栏提示文字
		$brocast->setPredefinedKeyValue("title", $title); // 必填 通知标题
		$brocast->setPredefinedKeyValue("text", $text); // 必填 通知文字描述
		$brocast->setPredefinedKeyValue("after_open", "go_app"); // 必填 值可以为:
		                                                         // "go_app":
		                                                         // 打开应用、"go_url":
		                                                         // 跳转到URL、"go_activity":
		                                                         // 打开特定的activity
		                                                         // 、"go_custom":
		                                                         // 用户自定义内容。
		$brocast->setPredefinedKeyValue("production_mode", $this->pushConf->production_mode); // 可选
		                                                                                      // 正式/测试模式。测试模式下，只会将消息发给测试设备。
		if(is_array($extra))
		{
			foreach($extra as $k => $v)
			{
				$brocast->setExtraField($k, $v);
			}
		}
		$mess = json_decode($brocast->send(), TRUE);
		return $mess;
	}

	/**
	 * Android 单播
	 */
	public function sendAndroidUnicast($title, $text, $extra = '')
	{
		$unicast = new AndroidUnicast();
		$unicast->setAppMasterSecret($this->pushConf->android->appMasterSecret);
		$unicast->setPredefinedKeyValue("appkey", $this->pushConf->android->appKey); // 应用唯一标识
		$unicast->setPredefinedKeyValue("timestamp", $this->time); // 时间戳有效期为10分钟
		$unicast->setPredefinedKeyValue("device_tokens", $this->device_token); // 用户
		                                                                       // 当前手机
		                                                                       // 的
		                                                                       // 设备号
		$unicast->setPredefinedKeyValue("ticker", $title);
		$unicast->setPredefinedKeyValue("title", $title); // 发送的标题
		$unicast->setPredefinedKeyValue("text", $text); // 发送的 内容
		$unicast->setPredefinedKeyValue("after_open", "go_app"); // 打开之后 的动作
		                                                         // 模式 false 开发模式
		                                                         // true 生产模式 不管什么模式
		                                                         // 内网 还是外网 推送都可以 收到消息
		$unicast->setPredefinedKeyValue("production_mode", $this->pushConf->production_mode);
		if(is_array($extra))
		{
			foreach($extra as $k => $v)
			{
				$unicast->setExtraField($k, $v);
			}
		}
		$mess = json_decode($unicast->send(), TRUE);
		return $mess;
	}

	/**
	 * IOS 单播
	 */
	public function sendIOSUnicast($title, $extra = '')
	{
		$unicast = new IOSUnicast();
		$unicast->setAppMasterSecret($this->pushConf->ios->appMasterSecret);
		$unicast->setPredefinedKeyValue("appkey", $this->pushConf->ios->appKey);
		$unicast->setPredefinedKeyValue("timestamp", $this->time); // 时间戳有效期为10分钟
		$unicast->setPredefinedKeyValue("device_tokens", $this->device_token); // 用户设备号
		$unicast->setPredefinedKeyValue("alert", $title); // 发送 内容
		$unicast->setPredefinedKeyValue("badge", 0);
		$unicast->setPredefinedKeyValue("sound", "default"); // 自定义 铃声
		                                                     // 模式 false 开发模式 true
		                                                     // 生产模式 不管什么模式 内网
		                                                     // (false)还是外网(true) 用户
		                                                     // 推送才可以 收到消息
		$unicast->setPredefinedKeyValue("production_mode", $this->pushConf->production_mode);
		if(is_array($extra))
		{
			foreach($extra as $k => $v)
			{
				$unicast->setCustomizedField($k, $v);
			}
		}
		$mess = json_decode($unicast->send(), TRUE);
		
		return $mess;
	}

	/**
	 * IOS 广播
	 */
	public function sendIOSBroadcast($title, $extra = '')
	{
		$brocast = new IOSBroadcast();
		$brocast->setAppMasterSecret($this->pushConf->ios->appMasterSecret);
		$brocast->setPredefinedKeyValue("appkey", $this->pushConf->ios->appKey);
		$brocast->setPredefinedKeyValue("timestamp", $this->time);
		$brocast->setPredefinedKeyValue("alert", $title);
		$brocast->setPredefinedKeyValue("badge", 0);
		$brocast->setPredefinedKeyValue("sound", "default");
		$brocast->setPredefinedKeyValue("production_mode", $this->pushConf->production_mode);
		if(is_array($extra))
		{
			foreach($extra as $k => $v)
			{
				$brocast->setCustomizedField($k, $v);
			}
		}
		$mess = json_decode($brocast->send(), TRUE);
		
		return $mess;
	}

	private function pushLog($flag, $mess, $title)
	{
		if($flag == 1)
		{
			if($mess['ret'] == 'SUCCESS')
			{
				\core\Log::write($this->adminId . '-' . $title . '-单播推送成功,deviceToken:'.($this->device_token?$this->device_token:''), 'app_push');
			}
			else
			{
				\core\Log::write(json_encode($mess).'-'.$title.'-单播推送失败,deviceToken:'.($this->device_token?$this->device_token:''), 'app_push');
			}
		}
		else
		{
			if($mess['ret'] == 'SUCCESS')
			{
				\core\Log::write($this->adminId . '-' . $title . '广播推送成功', 'app_push');
			}
			else
			{
				\core\Log::write(json_encode($mess['data']), 'app_push');
			}
		}
		return true;
	}
}

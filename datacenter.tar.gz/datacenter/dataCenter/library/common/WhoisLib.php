<?php
namespace common;
class WhoisBasicInfo
{
	public $DomainName;
	public $WhoisServer;
	public $Status;
	public $RegistrantName;
	public $RegistrantOrganization;
	public $NameServer;
	public $AdministrativeEmail;
	public $SponsoringRegistrar;
	public $RegistrationDate;
	public $UpdatedDate;
	public $ExpirationDate;
	public $WhoisInfo;
}

/**
 *  域名whois查询类
 */
class WhoisLib
{
	private $Domain;
	private $WhoisInfo;
	private $Server;
	private $whoisServers;
	private $domainPrefix;//域名前缀
	private $domainSuffix;//域名后缀
	private $whoisServer;//域名注册商whois地址
	private $whoisEmail;//域名注册商whois地址
	private $writeLog = FALSE;//是否记录日志
	private $QueryProcess = 'QueryProcess:';//查询流程
	private $useShell = FALSE;//是否使用查询godaddy的Whois信息shell文件
	private $getGodaddyWhoisUrl = array('0' => 'local', '3' => 'http://help.ename.cn/WhoisGodaddy.php',
			'2' => 'http://www.dnbbs.com/WhoisGodaddy.php',
	//		'1'=>'http://iidns.com/WhoisGodaddy.php'
	);
	private $key = '5DEA9B27CAB4D2E047A8C6313FF11596';

	public function __construct()
	{
		$this->whoisServers = array('.cn' => 'whois.cnnic.cn', '.com' => 'whois.verisign-grs.com','.top'=>'whois.nic.top',
				'.net' => 'whois.verisign-grs.com', '.org' => 'whois.publicinterestregistry.net',
				'.asia' => 'whois.nic.asia', '.info' => 'whois.afilias.info', '.biz' => 'whois.nic.biz',
				'.name' => 'whois.nic.name', '.tv' => 'whois.nic.tv', '--.cn' => 'cwhois.cnnic.cn',
				'--.com' => 'whois.verisign-grs.com', '--.net' => 'whois.verisign-grs.com', '--.xn--io0a7i' => 'whois.ngtld.cn',
				'.xn--io0a7i' => 'whois.ngtld.cn', // .网络
				'--.xn--io0a7i' => 'whois.ngtld.cn', //中文.网络
				'.xn--fiqs8s' => 'cwhois.cnnic.cn', // .中国
				'--.xn--fiqs8s' => 'cwhois.cnnic.cn', // 中文.中国
				'.xn--55qx5d' => 'whois.ngtld.cn', // .公司
				'--.xn--55qx5d' => 'whois.ngtld.cn', // 中文.公司
				'--.xn--fiqz9s' => 'cwhois.cnnic.cn', // 中文.中國
				'--.xn--od0alg' => 'whois.ngtld.cn', // 中文.網絡
				'.cc' => 'whois.nic.cc', '.us' => 'whois.nic.us', '.hk' => 'whois.hkirc.hk', '.cd' => 'whois.nic.cd',
				'.me' => 'whois.nic.me', '.tw' => 'whois.twnic.net.tw', '.in' => 'whois.inregistry.net',
				'.co' => 'whois.nic.co', '.pw' => 'whois.nic.pw','.top' => 'whois.nic.top','.wang'=>'whois.nic.wang',
				'--.top' => 'whois.nic.top','--.wang' => 'whois.nic.wang');
	}

	/**
	 * 连接socket获取whois基本信息
	 * @param string $domain
	 * @return number|string
	 */
	private function getWhoisInfoByDomain($domain)
	{
		$domain = strtolower($domain);
		$this->QueryProcess .= '->getWhoisInfoByDomain';
		if(!$domain)
		{
			return 390001;
		}
		$domainArray = explode('.', $domain, 2);
		if(!isset($domainArray['0']) or !isset($domainArray['1']))
		{
			return 390002;
		}
		$this->domainPrefix = $domainArray['0'];
		$this->domainSuffix = $domainArray['1'];
		$this->checkAndPunycodeDomain();
		$this->Domain = $this->domainPrefix . '.' . $this->domainSuffix;
		if(!$this->checkServerExists($this->Server))
		{
			$this->writeLog = TRUE;
			return 390003;
		}
		$this->WhoisInfo = $this->getWhoisInfoBySocketTwo($this->Domain, $this->whoisServers[$this->Server]);
		return $this->WhoisInfo;
	}

	/**
	 * 根据whois server获取WHOIS详细信息
	 * @param string $domain
	 * @param string $server
	 * @return number|string|array
	 * 4300接口基本信息和详细信息全部返回，此步略过
	 */
	public function getWhoisInfoByServer($domain, $server)
	{
		$domain = strtolower($domain);
		$server = strtolower($server);
		$this->QueryProcess .= '->getWhoisInfoByServer';
		if(!$domain)
		{
			$this->writeLog = TRUE;
			return 390001;
		}
		if(!$server || !$this->checkWhoisDetailReq($domain, $server))
		{
			return $this->WhoisInfo;
		}
		$this->Server = $server;
		if(!$this->Domain)
		{
			$this->Domain = $domain;
			$this->checkAndPunycodeDomain();
		}

		$return = $this->getWhoisInfoBySocketTwo($this->Domain, $this->Server);
		//万网中文乱码问题
		if("null" == json_encode($return))
		{
			$return = mb_convert_encoding($return, 'UTF-8', 'GBK');
		}
		return $return;
	}

	/**
	 * 只有com net cc tv的才让请求详细信息
	 * @param string $domain
	 * @param string $server
	 * @return boolean
	 */
	private function checkWhoisDetailReq($domain,$server)
	{
		if(empty($domain) || empty($server) || !in_array(\lib\manage\common\DomainFunLib::getDomainClass($domain),array('CC','TV','COM','NET')))
		{
			return FALSE;
		}
		return TRUE;
	}
	
	/**
	 * 获取域名的基本信息
	 * @param string $domain
	 * @param boolean $needEmail
	 * @return number|array
	 */
	public function getWhoisBasicInfoByDomain($domain, $needEmail = FALSE)
	{
		$domain = strtolower($domain);
		$this->QueryProcess .= '->getWhoisBasicInfoByDomain';
		if(!$domain)
		{
			return 390001;
		}
		$this->Domain = $domain;
		$this->WhoisInfo = $this->getWhoisInfoByDomain($this->Domain);
		if(!$this->WhoisInfo or is_numeric($this->WhoisInfo))
		{
			$this->writeLog = TRUE;
			return $this->WhoisInfo;
		}
		$relust = $this->isNoFound($domain);
		if($relust)
		{
			return $relust;
		}
		$whoisBasicInfo = new WhoisBasicInfo();
		$whoisBasicInfo->DomainName = $domain;
		$whoisBasicInfo->WhoisServer = $this->getWhoisServerFromWhoisInfo();
		$this->whoisServer = $whoisBasicInfo->WhoisServer;
		$whoisBasicInfo->Status = $this->getStatusFromWhoisInfo();
		$whoisBasicInfo->RegistrantName = $this->getRegistrantNameFromWhoisInfo();
		$whoisBasicInfo->RegistrantOrganization = $this->getRegistrantOrganizationFromWhoisInfo();
		$whoisBasicInfo->NameServer = $this->getNameServerFromWhoisInfo();
		$whoisBasicInfo->AdministrativeEmail = $this->getEmailFromWhoisInfo();
		$whoisBasicInfo->SponsoringRegistrar = $this->getRegistrarFromWhoisInfo();
		$whoisBasicInfo->RegistrationDate = $this->getRegistrationDateFromWhoisInfo();
		$whoisBasicInfo->UpdatedDate = $this->getUpdatedDateFromWhoisInfo();
		$whoisBasicInfo->ExpirationDate = $this->getExpirationDateFromWhoisInfo();
		$whoisBasicInfo->WhoisInfo = $this->WhoisInfo;
		if($needEmail)
		{
			//4300接口基本信息和详细信息全部返回，此步略过
			//$this->WhoisInfo = $this->getWhoisInfoByServer($this->Domain, $whoisBasicInfo->WhoisServer);
			//$whoisBasicInfo->WhoisInfo = $this->WhoisInfo;
			if($whoisBasicInfo->WhoisServer)
			{
				if(!$whoisBasicInfo->AdministrativeEmail)
				{
					$whoisBasicInfo->AdministrativeEmail = $this->getEmailFromWhoisInfo();
				}
				if(!$whoisBasicInfo->RegistrantName)
				{
					$whoisBasicInfo->RegistrantName = $this->getRegistrantNameFromWhoisInfo();
				}
				if(!$whoisBasicInfo->RegistrantOrganization)
				{
					$whoisBasicInfo->RegistrantOrganization = $this->getRegistrantOrganizationFromWhoisInfo();
				}
			}
		}
		return $whoisBasicInfo;
	}

	/**
	 * 从whois中获取whois server
	 * @return string
	 */
	private function getWhoisServerFromWhoisInfo()
	{
		$this->QueryProcess .= '->getWhoisServerFromWhoisInfo';
		$WhoisServer = '';
		$getServer = NUll;
		if(preg_match_all("/Whois[\s]+Server:[\s]*([^\s]+)[\r\t\n\f]+/i", $this->WhoisInfo, $getServer))
		{

			if(isset($getServer['1']['1']))
			{
				$WhoisServer = $getServer['1']['1'];
			}
			else
			{
				$WhoisServer = $getServer['1']['0'];
			}
		}
		return $WhoisServer;
	}

	/**
	 * 从whois中匹配获取whois邮箱
	 * @return string
	 */
	private function getEmailFromWhoisInfo()
	{
		$this->QueryProcess .= '->getEmailFromWhoisInfo';
		$Email = '';
		$EmailInfo = NUll;
		if($this->whoisEmail)
		{
			return $this->whoisEmail;
		}
		if($this->whoisServer == 'whois.enom.com')
		{
			if(preg_match("/[\(]{1}([\w.%-]+@[\w.-]+\.[a-z]{2,4})[\)]{1}/i", $this->WhoisInfo, $EmailInfo))
			{
				if(!empty($EmailInfo['1']))
				{
					$this->whoisEmail = $EmailInfo['1'];
					return $EmailInfo['1'];
				}
			}
		}
		//优先获取registrant email
		if(preg_match("/Registrant[\s]+E[\-]?mail[\s]?:[\s]*([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $this->WhoisInfo, $EmailInfo))
		{
			if(!empty($EmailInfo['1']))
			{
				$this->whoisEmail = $EmailInfo['1'];
				return $EmailInfo['1'];
			}
		}
		//优先获取admin email
		if(preg_match("/(Admin|Administrative)+[\s]+E[\-]?mail[\s]?:[\s]*([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $this->WhoisInfo, $EmailInfo))
		{
			if(!empty($EmailInfo['2']))
			{
				$this->whoisEmail = $EmailInfo['2'];
				return $EmailInfo['2'];
			}
		}
		//优先获取Email Address
		if(preg_match("/E[\-]?mail[\s]?Address:[\s]*([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $this->WhoisInfo, $EmailInfo))
		{
			if(!empty($EmailInfo['1']))
			{
				$this->whoisEmail = $EmailInfo['1'];
				return $EmailInfo['1'];
			}
		}
		if(preg_match("/([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $this->WhoisInfo, $EmailInfo))
		{
			$Email = $EmailInfo['1'];
		}
		if($Email == 'support@propersupport.com')
		{
			if(preg_match("/[Registrant:](.*)[\(]{1}([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $this->WhoisInfo, $EmailInfo))
			{
				$Email = $EmailInfo['2'];
			}
		}
		if(stripos($Email,'abuse@') !== FALSE)
		{
			$Email = '';
		}
		$this->whoisEmail = $Email;
		return $Email;
	}

	/**
	 * 从whois中匹配获取注册者名称
	 * @return string
	 */
	private function getRegistrantNameFromWhoisInfo()
	{
		$RegistrantName = '';
		$regs = NUll;
		if(preg_match_all("/Registr[ant]*[\s]*[Contact]*[\s]*Name:[\s]*(.*?)[\r\t\n\f]+/i", $this->WhoisInfo, $regs))
		{
			$RegistrantName = implode(',', $regs['1']);
		}
		return $RegistrantName;
	}

	/**
	 * 从whois中匹配获取注册者机构名称
	 * @return string
	 */
	private function getRegistrantOrganizationFromWhoisInfo()
	{
		$RegistrantOrganization = '';
		$regs = NUll;
		if(preg_match_all("/Registrant[\s]*[Organization]*:[\s]*(.*?)[\r\t\n\f]+/i", $this->WhoisInfo, $regs))
		{
			$RegistrantOrganization = implode(',', $regs['1']);
		}
		return $RegistrantOrganization;
	}

	/**
	 * 从whois中匹配获取NS
	 * @return string
	 */
	private function getNameServerFromWhoisInfo()
	{
		$NameServer = '';
		$regs = NUll;
		if(preg_match_all("/Name[\s]*Server[s]*[0-9]*:[\s]*([^\s]+)[\r\t\n\f]+/i", $this->WhoisInfo, $regs))
		{
			$NameServer = implode(',', $regs['1']);
		}
		return $NameServer;
	}

	/**
	 * 从whois中匹配获取域名状态
	 * @return string
	 */
	private function getStatusFromWhoisInfo()
	{
		$Status = '';
		$regs = NUll;
		if(preg_match_all("/Status:[\s]*(.*?)[\r\t\n\f]+/i", $this->WhoisInfo, $regs))
		{
			$Status = implode(',', $regs['1']);
		}
		return $Status;
	}

	/**
	 * 从whois中匹配获取域名更新时间
	 * @return string
	 */
	private function getUpdatedDateFromWhoisInfo()
	{
		$UpdatedDate = '';
		$regs = NUll;
		if($this->Server == '.name')
		{
			if(preg_match("/Updated[\s]*On:[\s]*(.*?)[\r\t\n\f]+/i", $this->WhoisInfo, $regs))
			{
				$UpdatedDate = $this->formatDate($regs['1']);
			}
			return $UpdatedDate;
		}
		if(preg_match("/Updated[\s]*Date:[\s]*(.*?)[\r\t\n\f]+/i", $this->WhoisInfo, $regs))
		{
			$UpdatedDate = $this->formatDate($regs['1']);
		}
		return $UpdatedDate;
	}

	/**
	 * 从whois中匹配获取域名注册时间
	 * @return string
	 */
	private function getRegistrationDateFromWhoisInfo()
	{
		$RegistrationDate = '';
		$regs = NUll;
		if($this->Server == '.in' ||$this->Server == '.name' || $this->Server == '.org' || $this->Server == '.info' || $this->Server == '.tw')
		{
			if(preg_match("/Created[\s]*On[:\s]*(.*?)[\r\t\n\f]+/i", $this->WhoisInfo, $regs))
			{
				$RegistrationDate = $this->formatDate($regs['1']);
			}
			if($RegistrationDate)
			{
				return $RegistrationDate;
			}
		}
		if(preg_match("/(Registration[\s]*|Creation[\s]*|Create[\s]*)+[\s]*(Date|Time):[\s]*(.*?)[\r\t\n\f]+/i", $this->WhoisInfo, $regs))
		{
			$RegistrationDate = $this->formatDate($regs['3']);
			if($RegistrationDate)
			{
				return $RegistrationDate;
			}
		}
		
		return $RegistrationDate;
	}

	/**
	 * 从whois中匹配获取域名过期时间
	 * @return string
	 */
	private function getExpirationDateFromWhoisInfo()
	{
		$ExpirationDate = '';
		$regs = NUll;
		if($this->Server == '.name' || $this->Server == '.tw')
		{
			if(preg_match("/Expires[\s]*On[:\s]*(.*?)[\r\t\n\f]+/i", $this->WhoisInfo, $regs))
			{
				$ExpirationDate = $this->formatDate($regs['1']);
			}
			return $ExpirationDate;
		}
		if(preg_match("/Expiration[\s]+(Date|Time):[\s]*(.*?)[\r\t\n\f]+/i", $this->WhoisInfo, $regs))
		{
			$ExpirationDate = $this->formatDate($regs['2']);
			if($ExpirationDate)
			{
				return $ExpirationDate;
			}
		}
		if(preg_match("/[Registry]+[\s]*[Expiry]+[\s]*Date:[\s]*(.*?)[\r\t\n\f]+/i", $this->WhoisInfo, $regs))
		{
			$ExpirationDate = $this->formatDate($regs['1']);
		}
		return $ExpirationDate;
	}

	/**
	 * 从whois中匹配获取域名注册商
	 * @return string
	 */
	private function getRegistrarFromWhoisInfo()
	{
		$Registrar = '';
		$regs = NUll;
		if(preg_match_all("/Registr[ar]*[\s]*[Name]*:[\s]*(.*?)[\r\t\n\f]+/i", $this->WhoisInfo, $regs))
		{
			if(isset($this->whoisServers[$this->Server]) && $this->whoisServers[$this->Server] == 'whois.nic.biz')
				return $Registrar = $regs['1']['0'];
			if(isset($regs['1']['1']))
			{
				$Registrar = $regs['1']['1'];
			}
			else
			{
				$Registrar = $regs['1']['0'];
			}
		}
		return $Registrar;
	}

	/**
	 * 检测whois server是否存在
	 * @return boolean
	 */
	private function checkServerExists($Server)
	{
		$this->QueryProcess .= '->checkServerExists';
		if(!array_key_exists($Server, $this->whoisServers))
		{
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * 连接socket获取whois基本信息
	 * @param string $domain
	 * @return string|boolean
	 */
	private function getWhoisInfoBySocketTwo($domain, $server)
	{
		$serviceUser = \common\Common::getRequestUser();
		$data = \Yaf\Registry::get("data");
		$serverip = $data->whois->whoisserver->server1;
		$port = 4300;
		if($serviceUser =='trans' || $serviceUser =='newtrans')
		{
			$serverip = $data->whois->whoisserver->server3;
		}
		$this->QueryProcess .= '->getWhoisInfoBySocket';
		if(!$domain or !$server)
		{
			return FALSE;
		}
		$start = $this->getmicrotime();
		for($i = 0;$i < 3;$i++)
		{
			$outputStr = '';
			$fp = @fsockopen($serverip, $port, $errno, $errstr, 2);//外网4300 内网测试430
			if($fp)
			{
				//xndy.com需要等号查询有两个name
				if($server == 'whois.internic.com' or $server == 'whois.nic.name' or $server == 'whois.verisign-grs.com')
				{
					$domain = '=' . $domain;
				}
				$input = $domain . '|||' . $server . "\r\n";
				fwrite($fp, $input);
				stream_set_timeout($fp, 20);//基本和详细信息一起查询，因此加大一倍超时时间
				while(!feof($fp))
				{
					$outputStr .= fgets($fp, 1024);
				}
				$info = stream_get_meta_data($fp);
				fclose($fp);
			}
			if($outputStr)
			{
				$end = $this->getmicrotime();
				$use = $end - $start;
				$outputStr = str_replace(array('<!--', '-->'), '', $outputStr);
				// 				$outputStr = strip_tags($outputStr);
				return $outputStr . '<br>use time:' . $use;
			}
			sleep(1);
		}
		$this->writeLog = TRUE;
		$outputStr = strip_tags($outputStr);
		return $outputStr;
	}

	/**
	 * 检测域名是否可注册
	 * @param string $domain
	 * @return number|Ambigous <\common\number, string, multitype:, number, boolean, unknown>|boolean
	 */
	private function isNoFound($domain)
	{
		$this->QueryProcess .= '->isNoFound';
		if(!(stripos($this->WhoisInfo, 'no match') === FALSE))
		{
			return 390006;
		}
		if(!(stripos($this->WhoisInfo, 'not found') === FALSE))
		{
			return 390006;
		}
		if(!(stripos($this->WhoisInfo, 'is in auditing') === FALSE))
		{
			return 390007;
		}
		if(FALSE !== stripos($this->WhoisInfo, 'in the reserved') || FALSE !== stripos($this->WhoisInfo, 'is reserved') || FALSE !== stripos($this->WhoisInfo, 'reserved domain') || FALSE !== stripos($this->WhoisInfo, 'reserved name') || trim($this->WhoisInfo) == '網域名稱不合規定')
		{
			return 390008;
		}
		if(0 == $this->checkCn($domain) && stripos($this->WhoisInfo, $this->Domain) === FALSE and stripos($this->WhoisInfo, $domain) === FALSE)
		{
			return $this->WhoisInfo;
		}
		return FALSE;
	}

	/**
	 * 域名punycode检测和转码
	 * @return boolean
	 */
	private function checkAndPunycodeDomain()
	{
		$this->QueryProcess .= '->checkAndPunycodeDomain';
		$Punycode = new Punycode();
		if($this->Server != '')
		{
			$this->Domain = $this->checkCn($this->Domain) ? $Punycode->encode($this->Domain) : $this->Domain;
			return TRUE;
		}
		$this->Server = '.';
		if($this->checkCn($this->domainPrefix))
		{
			$this->Server = '--.';
			$this->domainPrefix = $Punycode->encode($this->domainPrefix);
		}

		if($this->checkCn($this->domainSuffix))
		{
			$this->domainSuffix = $Punycode->encode($this->domainSuffix);
		}
		if(strstr($this->domainSuffix, '.cn'))
		{
			$this->Server .= 'cn';
		}
		else if($this->domainSuffix == 'cc')
		{
			$this->Server = '.cc';
		}
		else
		{
			$this->Server .= $this->domainSuffix;
		}
		$this->Server = strtolower($this->Server);
		return TRUE;
	}

	/**
	 * 检测是否包含中文
	 * @param string $str
	 * @return number 1有0没有
	 */
	private function checkCn($str)
	{
		if(preg_match("/[\x80-\xff]./", $str))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	/**
	 * 判断是不是纯中文
	 * @param string $str
	 * @return number 1是0不是
	 */
	private function checkPureCn($str)
	{
		if(ereg("^[" . chr(0xa1) . "-" . chr(0xff) . "]+$", $str))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	/**
	 * 时间格式化
	 * @param string $date
	 * @return boolean|string
	 */
	private function formatDate($date)
	{
		if(empty($date))
		{
			return FALSE;
		}
		$patterns[0] = "/UTC/";
		$patterns[1] = "/GMT/";
		$patterns[2] = "/T0/";
		$patterns[3] = "/\(YYYY\-MM\-DD\)/";
		$RegistrationDate = preg_replace($patterns, array('', '', ' '), $date);
		$timeNum = strtotime($RegistrationDate);
		return date("Y-m-d", $timeNum);
	}

	/**
	 * 获取时间microtime
	 * @return number
	 */
	private function getmicrotime()
	{
		list($usec, $sec) = explode(" ", microtime());
		return ((float) $usec + (float) $sec);
	}

	/**
	 * 根据域名Whois判断属属注册商
	 *
	 * @param string $whoisInfo
	 * @return 0 非转入待审核注册商 1=》 gd审核 2=》enom待审核 3=》其他待审核
	 */
	public function registerByWhoisInfo($whoisInfo) 
	{
		$gdRegistrarPreg = array("/whois\.godaddy\.com|Registrar:\s?GoDaddy\.com/i",
				"/whois\.wildwestdomains\.com|Registrar:\s?Wild\s?West\s?Domains,\s?LLC/i",
				"/whois\.bluerazor\.com|Registrar:\s?Blue\s?Razor\s?Domains,\s?LLC/i");
		foreach($gdRegistrarPreg as $pregGd)
		{
			if(preg_match($pregGd, $whoisInfo))
			{
				return 1;
			}
		}
		$enomRegistrarPreg = array("/whois\.enom\.com|Registrar:\s?ENOM/i");
		foreach($enomRegistrarPreg as $pregEnom)
		{
			if(preg_match($pregEnom, $whoisInfo))
			{
				return 2;
			}
		}
		$othersRegistrarPreg = array("/whois\.register\.com|Registrar:\s?Register\.com,\s?Inc/i","/whois\.dynadot\.com|Registrar:\s?DYNADOT\s?LLC/i",
				"/whois\.networksolutions\.com|Registrar:\s?NETWORK SOLUTIONS, LLC/i",
				"/whois\.dreamHost\.com|Registrar:\s?DreamHost\.com/i",
				"/whois\.moniker\.com|Registrar:\s?Moniker\s?Online\s?Services\s?LLC/i",
				"/whois\.1api\.net|Registrar:\s?1API\s?GmbH/i",
			    "/whois\.rrpproxy\.net|Registrar:\s?Key-Systems\s?GmbH/i",
		);
		foreach($othersRegistrarPreg as $pregOther)
		{
			if(preg_match($pregOther, $whoisInfo))
			{
				return 3;
			}
		}
		return 0;
	}
}

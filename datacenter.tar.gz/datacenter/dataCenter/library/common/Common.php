<?php
namespace common;
class Common
{
	/**
	 * 检测ip格式
	 * @param unknown_type $ip
	 * @return boolean
	 */
	public static function CheckIp($ip)
	{
		$ipArr = explode('.', $ip);
		if(count($ipArr) != 4)
		{
			return false;
		}
		if(is_numeric(str_replace('.', '', $ip)) === false)
		{
			return false;
		}
		return true;
	}
	
	/**
	 *
	 * checkEnameId 验证enameId
	 * @param unknown_type $enameId
	 * @return unknown|boolean
	 * unknown|boolean
	 */
	public static function checkEnameId($enameId)
	{
		if(preg_match('/^\d{5,8}$/', $enameId))
			return TRUE;
	
		return FALSE;
	}

	/**
	 * 获取客户操作ip（针对平台客户）
	 * @return string
	 */
	public static function getRequestIp()
	{
		$ip = isset($_GET['ip']) ? trim($_GET['ip']) : '';
		return self::CheckIp($ip) ? $ip : '';
	}
	
	/**
	 * 获取接口请求user
	 * @return string
	 */
	public static function getRequestUser()
	{
		return isset($_GET['user']) ? trim($_GET['user']) : '';
	}

	/**
	 * stdClass类型数据转换成数组
	 * @param object $array
	 * @return array
	 */
	public static function objectToarray($array)
	{
		if(is_object($array))
		{
			$array = (array) $array;
		}
		if(is_array($array))
		{
			foreach($array as $key => $value)
			{
				$array[$key] = self::objectToarray($value);
			}
		}
		return $array;
	}

	/**
	 * 获取客户端app版本
	 * 
	 * @return version
	 */
	public static function getAppVersion()
	{
		if(isset($_POST['ver']) || isset($_GET['ver'])) 
		{
			return isset($_POST['ver']) ? $_POST['ver'] : $_GET['ver'];
		}
		return null;
	}
	
	/**
	 * 验证域名合法性
	 */
	public function checkDomain($data){
		$result = array();
		foreach($data as $k => $v){
			if(!preg_match('/^([\x{4e00}-\x{9fa5}]|[a-zA-Z0-9-])+(\.[a-z]{2,4})?\.([a-z]|[\x{4e00}-\x{9fa5}]){2,4}$/ui' ,$v)){//验证域名合法性
				$result[$k] = $v;
			}
		}
		return $result;
	}

	/**
	 * curl POST 请求数据
	 */
	public static function requestPost($url, $postData = FALSE)
	{
		if(! function_exists('curl_init'))
			exit('您的服务器不支持 PHP 的 Curl 模块，请安装。');
		$i = 0; 
		while($i < 3)
		{
			$ch = curl_init(); 
			curl_setopt($ch, CURLOPT_URL, $url);
			//curl普通秒超时设置
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
			curl_setopt($ch, CURLOPT_TIMEOUT, 30);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			if(!empty($postData))
			{
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
			}
			$result = curl_exec($ch);
			if(curl_errno($ch))
			{
				$result = FALSE;
			}
			curl_close($ch);
			if(!empty($result))
				break;
			$i++;
		}
		return $result;
	}
	

	/**
	 * 获取当前URL 
	 */
	public static function urlThis()
	{
		$http_host = empty($_SERVER['HTTP_HOST']) ? $_SERVER['SERVER_NAME'] : $_SERVER['HTTP_HOST'];
		$php_self = !empty($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $_SERVER['PHP_SELF'];
		$url_this = $http_host . $php_self;
		return $url_this;
	}
}

<?php
	namespace common; 
	class Lang
	{
		
		public function __construct($segment,$plat='')
		{
			$this->msgConf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', $segment);
			$this->msgConf = $this->msgConf->toArray();
		}
		public static function create($segment,$plat='')
		{
			return new Lang($segment,$plat);
		}
		public function getMsg($code)
		{
			if(!isset($this->msgConf[$code]))
			{
				return 'code:'.$code.' not found';
			}
			return $this->msgConf[$code];
		}
	}
?>
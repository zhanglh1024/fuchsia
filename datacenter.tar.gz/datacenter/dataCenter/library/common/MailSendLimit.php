<?php
namespace common;

class MailSendLimit
{
	/**
	 * 检查发送邮件是否超出限制(超出限制false,未超出true)
	 *
	 * @param int $enameId
	 * @param string $method 'controller_action'
	 * @param int $limit
	 * @return boolean
	 */
	public static function sendMailIsOutOfLimit($enameId, $method, $limit = 5)
	{
		$redis = \core\RedisLib::getInstance('manage');
		$key = 'manage_' . $enameId . '_' . $method;
		// 判断数据库是否存在
		$value = $redis->get($key);
		if(empty($value) || $limit > $value)
		{
			return true;
		}
		return false;
	}
	
	/**
	 * 设置发送邮件发送次数
	 *
	 * @param int $enameId
	 * @param string $method 'controller_action'
	 * @param int $limit
	 */
	public static function setSendMail($enameId, $method, $expireTime)
	{
		$redis = \core\RedisLib::getInstance('manage');
		$key = 'manage_' . $enameId . '_' . $method;
		// 判断数据库是否存在
		if($redis->exists($key))
		{
			$value = $redis->get($key);
			$redis->setex($key, $redis->ttl($key), intval($value) + 1);
		}
		else
		{
			$redis->setex($key, $expireTime, 1);
		}
	}
}
<?php
namespace common;
class Random
{

	private static function generateRandomString($chars, $length)
	{
		$chars_array = explode(',', $chars);
		$charsLen = count($chars_array) - 1;
		shuffle($chars_array);
		$output = '';
		for ($i = 0; $i < $length; $i ++)
		{
			$output .= $chars_array[mt_rand(0, $charsLen)];
		}
		return $output;
	}

	/**
	 * 随机字符串。大小写、数字混合
	 * @param int $length
	 * @return string
	 * note:time:2010-10-19 author:arden
	 */
	public static function getString($length)
	{
		$chars = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,0,1,2,3,4,5,6,7,8,9";
		return Random::generateRandomString($chars, $length);
	}

	/**
	 * 随机字符串。大小写、数字混合，排除其中容易混淆的字母
	 * @param int $length
	 * @return string
	 * note:time:2010-10-19 author:arden
	 */
	public static function getReadableString($length)
	{
		$chars = "a,b,c,d,e,f,g,h,i,j,k,m,n,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,M,N,P,Q,R,S,T,U,V,W,X,Y,Z,2,3,4,5,6,7,8,9";
		return Random::generateRandomString($chars, $length);
	}

	/**
	 * 随机字符串。小写
	 * @param int $length
	 * @return string
	 * note:time:2010-10-19 author:arden
	 */
	public static function getLowerString($length)
	{
		$chars = "a,b,c,d,e,f,g,h,j,k,m,n,p,q,r,s,t,u,v,w,x,y,z";
		return Random::generateRandomString($chars, $length);
	}

	/**
	 * 随机字符串。数字
	 * @param int $length
	 * @return string
	 * note:time:2010-10-19 author:arden
	 */
	public static function getNumber($length)
	{
		$chars = "0,1,2,3,4,5,6,7,8,9";
		return Random::generateRandomString($chars, $length);
	}

}

?>

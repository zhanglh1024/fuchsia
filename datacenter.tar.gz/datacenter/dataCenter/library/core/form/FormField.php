<?php
namespace core\form;

class ReturnData
{

	public static $success = TRUE;

	public static $info;

	public static $error;
}
class FormField
{

	public static $MAX_INT = PHP_INT_MAX;

	public static $VAR_STRING = 0;

	public static $VAR_INT = 1;

	public static $VAR_STRING_ARRAY = 10;

	public static $VAR_INT_ARRAY = 11;

	public $Name; // 字段名
	public $ObjectPropertyName; // 对象属性名或者数组key。如果等于TRUE或者''则同字段名($Name)。没有属性名就设置为FALSE
	public $HttpMethod; // HTTP方法。例如GET, POST
	public $VarType; // 变量类型(字符型,整数型,浮点型)
	public $Min; // 取值范围：最小值(可以等于)
	public $Max; // 取值范围：最大值(可以等于)
	public $ExtraCheckInfo; // 检查字段合法性的参数，数组形式。例如 array('FormCheck::isEmail'=>'email格式不对', 'isOther'=>'不对不对');
	                        // 检查字段合法性的类名，其中包含的要static方法，验证正确返回TRUE，错误返回FALSE。
	public $Value; // 成功后存放值
	public $IsValidValue; // 值是否合法
	public $ErrorMessage; // 如果值错误的错误信息
	public $isNull = FALSE; // 是否允许为空
	public function __construct($name, $httpMethod, $rangeCheckInfo, $extraCheckInfo = FALSE)
	{
		$this->Name = $name;
		$this->ObjectPropertyName = $name;
		$this->isNull = stripos($httpMethod, '#') !== false? true :false;
		$this->HttpMethod = strtoupper(str_replace("#", '', $httpMethod));
		switch($this->HttpMethod)
		{
			case 'POST':
				$this->Value = isset($_POST[$name])? $_POST[$name] :'';
				break;
			case 'GET':
				$this->Value = isset($_GET[$name])? $_GET[$name] :'';
				break;
			default:
				$this->Value = '';
				$this->HttpMethod = null;
				break;
		}
		$this->Min = $rangeCheckInfo[0];
		$this->Max = $rangeCheckInfo[1];
		$this->ErrorMessage = $rangeCheckInfo[2];
		$this->VarType = isset($rangeCheckInfo[3])? $rangeCheckInfo[3] :self::$VAR_STRING;
		$this->Value = $this->VarType == self::$VAR_INT? trim($this->Value) :$this->Value;
		$this->ExtraCheckInfo = $extraCheckInfo;
	}
}
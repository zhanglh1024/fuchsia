<?php
namespace core;

class Solr
{

	private static $conn = array();

	private static $conf;

	public $path;

	private function __construct($configName, $configInfo)
	{
		$val = $this->get($configName);
		if(isset(self::$conn[$configName]) && self::$conn[$configName])
		{
			return self::$conn[$configName];
		}
		$this->solr = new \SolrClient(array('hostname' => $val->host,'port' => $val->port,'path' => $val->path));
		try
		{
			$this->solr->ping();
		}
		catch(\Exception $e)
		{
			$this->solr = NULL;
		}
		self::$conn[$configName] = $this->solr;
	}

	public static function getInstance($configName)
	{
		if(empty($configName))
		{
			throw new \Exception("configName can not empty", 3001);
		}
		$conf = \Yaf\Registry::get("data");
		self::$conf = $conf;
		if(!isset(self::$conf->solr))
		{
			throw new \Exception("solr config not exists", 3000);
		}
		$solrInfo = self::$conf->solr->$configName;
		new Solr($configName, $solrInfo);
		return self::$conn[$configName];
	}

	/**
	 * 获取配置
	 *
	 * @param unknown $var        	
	 * @param string $val        	
	 * @throws \Exception
	 * @return unknown
	 */
	public function get($var, $val = NULL)
	{
		static $val;
		$solrConf = self::$conf->solr;
		$arrayVar = explode('->', $var);
		if(count($arrayVar) > 1)
		{
			foreach($arrayVar as $k => $v)
			{
				if($k == 0)
				{
					if(isset($solrConf[$v]))
					{
						$val = $solrConf[$v];
					}
					else
					{
						throw new \Exception('配置' . $v . '无法获取');
					}
				}
				
				else
				{
					if(isset($val[$v]))
					{
						$val = $val[$v];
					}
					else
					{
						throw new \Exception('配置' . $v . '无法获取');
					}
				}
			}
		}
		else
		{
			if(count($arrayVar) == 1 && isset($solrConf[$arrayVar[0]]))
			{
				$val = $solrConf[$arrayVar[0]];
			}
			else
			{
				throw new \Exception('配置' . $arrayVar[0] . '无法获取');
			}
		}
		$this->path = 'http://' . $val->host . ':' . $val->port . $val->path;
		return $val;
	}
}
?>
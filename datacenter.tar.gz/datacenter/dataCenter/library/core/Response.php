<?php
/**
 * 注意：
 * 1、关于Response的使用，错误编码规则请严格按照规定使用，详细见http://192.168.10.220:806/2014/05/161。
 * 2、表单错误统一用formError输出，错误码为100002
 */
namespace core;

class Response
{

	public static $errCode;

	public static $errMsg;

	/**
	 * 输出json格式的成功信息，默认编码为100000，信息为success
	 * 
	 * @param string $msg
	 */
	public static function success($msg = '')
	{
		self::msg($msg === ''? 'success': $msg, 100000, TRUE);
	}

	/**
	 * 输出json格式的系统错误信息，默认编码为100001，信息为error
	 * 
	 * @param string $msg
	 */
	public static function error($msg = '', $code = 100001)
	{
		self::msg($msg? $msg: 'error', $code, FALSE);
	}

	/**
	 * 输出json格式的表单错误信息，默认错误编码为100002
	 * 
	 * @param string $msg
	 */
	public static function formError($msg)
	{
		self::msg($msg, 100002);
	}

	/**
	 * 输出json格式的错误信息，包括code和msg
	 * 
	 * @param string $msg 可选，也可通过setErrCode设置
	 * @param string $code 可选，也可通过setErrMsg设置
	 */
	public static function msg($msg = '', $code = '', $flag = FALSE)
	{
		$code = $code? $code: (self::$errCode? self::$errCode: 100001);
		$msg = $msg !== ''? $msg: (self::$errMsg !== ''? self::$errMsg: 'error');
		self::info(array('code'=> $code,'msg'=> $msg,'flag'=> $flag));
	}

	/**
	 * 设置错误编码和信息
	 * 
	 * @param string $msg
	 */
	public static function setErrMsg($code, $msg = '')
	{
		self::$errCode = (string)$code;
		self::$errMsg = $msg;
	}

	/**
	 * 获取错误编码
	 * 
	 * @return string
	 */
	public static function getErrCode()
	{
		return self::$errCode;
	}

	/**
	 * 获取错误编码
	 * 
	 * @reutrn string
	 */
	public static function getErrMsg()
	{
		return self::$errMsg;
	}

	/**
	 * 输出错误信息并结束程序
	 * 
	 * @param array $msg
	 */
	private static function info(array $msg)
	{
		if(is_array($msg))
		{
			echo json_encode($msg);
		}
		else
		{
			echo $msg;
		}
		exit();
	}
}

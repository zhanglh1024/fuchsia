<?php
namespace core;

class RedisLib
{

	private static $conn;

	private function __construct($configName,$serialize=true)
	{
		$redis = new \Redis();
		$data = \Yaf\Registry::get("data");
		$redisConfig = $data->redis->$configName;
		$timeOut = isset($redisConfig->timeout)? intval($redisConfig->timeout) :3;
		if($redis->connect($redisConfig->ip, $redisConfig->port, $timeOut))
		{
			if($serialize)
			{
				$redis->setOption(\Redis::OPT_SERIALIZER, \Redis::SERIALIZER_PHP);
			}
			self::$conn[$configName] = $redis;
		}
		else
		{
			throw new \Exception("redis is down");
		}
	}
    /**
       * 
     * @param string $configName 配置文件名
     * @param string $serialize  是否系列化
     * @param string $newRedis 是否用之前的$newRedis 
     * @return \Redis
     */
	public static function getInstance($configName,$serialize=true ,$newRedis =true)
	{
		if(isset(self::$conn[$configName]) && self::$conn[$configName] && $newRedis)
		{
			return self::$conn[$configName];
		}
		$redis = new redislib($configName,$serialize);
		return self::$conn[$configName]; 
	}
}
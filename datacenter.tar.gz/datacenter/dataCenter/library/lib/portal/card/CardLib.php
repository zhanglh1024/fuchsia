<?php
namespace lib\portal\card;
class CardLib
{
	public function getCard($info)
	{
		$param = $this->setCardData2($info);
		$mod = new \models\portal\card\CardMod();
		$countarray = $mod->getCardCount($param);
		$count = $countarray['COUNT'];
		
		$orderType = empty($info->orderType)?'':$info->orderType;
		
		if(!empty($info->pagesize))
		{
				
			$pagesize = intval($info->pagesize);
			$p = $info->pagenum ? intval($info->pagenum) - 1 : 0;
			$offset = $p * intval($info->pagesize);
				
		}
		else
		{
			$pagesize = 9;//默认取得9条
			$p = $info->pagenum ? intval($info->pagenum) - 1 : 0;
			$offset = $p * $pagesize;
		}
		if(!empty($count))
		{
			$res = $mod->getList($offset,$pagesize,$param, $orderType);
		}
		$pagenumback = $p + 1;
		return $data = array('data' => empty($res) ? array() : $res,'count' => $count,'pagenum' => $pagenumback);
	}


	public function addCard($info)
	{
		$param = $this->setCardData($info);
		$cardMod = new \models\portal\card\CardMod();
		return $cardMod->addCard($param);
	}

	public function editCard($info,$cardId)
	{
		$param = $this->setCardData($info);
		$cardMod = new \models\portal\card\CardMod();
		return $cardMod->editCard($param,$cardId);
	}

	public function delCard($cardId)
	{
		$cardMod = new \models\portal\card\CardMod();
		return $cardMod->deleteCard($cardId);
	}

	public function getOneCard($cardId)
	{
		$cardMod = new \models\portal\card\CardMod();
		return $cardMod->getOneCard($cardId);
	}

	private function setCardData($data)
	{
		$param = array();
		
		$param['pc_ename_id'] = empty($data->enameId) ? array('i', '') : array('i', $data->enameId);
		$param['pc_shop_name'] = empty($data->shopName) ? array('s', '') : array('s', $data->shopName);
		$param['pc_type'] = empty($data->type) ? array('i', '') : array('i', $data->type);
		$param['pc_public'] = empty($data->isPublic) ? array('i', '') : array('i', $data->isPublic);
		$param['pc_status'] = empty($data->status) ? array('i', '') : array('i', $data->status);
		$param['pc_recommend'] = empty($data->isRecommend) ? array('i', '') : array('i', $data->isRecommend);
		$param['pc_real_name'] = empty($data->realName) ? array('s', '') : array('s', $data->realName);
		$param['pc_nic_name'] = empty($data->nickname) ? array('s', '') : array('s', $data->nickname);
		$param['pc_job'] = empty($data->job) ? array('s', '') : array('s', $data->job);
		$param['pc_title'] = empty($data->title) ? array('s', '') : array('s', $data->title);
		$param['pc_address'] = empty($data->address) ? array('s', '') : array('s', $data->address);
		$param['pc_domain'] = empty($data->domain) ? array('s', '') : array('s', $data->domain);
		$param['pc_site'] = empty($data->site) ? array('s', '') : array('s', $data->site);
		$param['pc_weibo'] = empty($data->weibo) ? array('s', '') : array('s', $data->weibo);
		$param['pc_domain_success'] = empty($data->domainSuccess) ? array('s', '') : array('s', $data->domainSuccess);
		$param['pc_pic'] = empty($data->pic) ? array('s', '') : array('s', $data->pic);
		$param['pc_qq'] = empty($data->qq) ? array('s', '') : array('s', $data->qq);
		$param['pc_phone'] = empty($data->phone) ? array('s', '') : array('s', $data->phone);
		$param['pc_introduction'] = empty($data->introduction) ? array('s', '') : array('s', $data->introduction);
		$param['pc_public_phone'] = empty($data->isPhonePublic) ? array('i', '') : array('i', $data->isPhonePublic);
		$param['pc_check_time'] = empty($data->checkTime) ? array('s', '') : array('s', $data->checkTime);
		$param['pc_rec_time'] = empty($data->recTime) ? array('s', '') : array('s', $data->recTime);
		$param['pc_public'] = empty($data->isPublic) ? array('s', '') : array('s', $data->isPublic);
		$param['pc_street'] = empty($data->street) ? array('s', '') : array('s', $data->street);
		
		return $param;
	}

	private function setCardData2($data)
	{
		$param = array();
		$param['pc_id'] = empty($data->cardId) ? '' : array('i', $data->cardId);
		$param['pc_nic_name'] = empty($data->nickname) ? '' : array('s', $data->nickname);
		$param['pc_ename_id'] = empty($data->enameId) ? '' : array('i', $data->enameId);
		$param['pc_status'] = empty($data->status) ? '' : array('i', $data->status);
		$param['pc_type'] = empty($data->type) ? '' : array('i', $data->type);
		$param['pc_recommend'] = empty($data->isRecommend) ? '' : array('i', $data->isRecommend);
		$param['excludeCardId'] = empty($data->excludeCardId) ? '' : array('s', $data->excludeCardId);
		$param['excludeStatus'] = empty($data->excludeStatus) ? '' : array('i', $data->excludeStatus);
		$param['pc_public'] = empty($data->isPublic) ? '' : array('s', $data->isPublic);
		$param['pc_street'] = empty($data->street) ? '' : array('s', $data->street);
		
		return $param;
	}
}
<?php
namespace lib\portal\topic;

class TopicLib
{

	public function getTopic($data)
	{
		$param = $this->setTopicDataCount($data);		
		$mod = new \models\portal\topic\TopicMod();	
		$count = $mod->getTopicCount($param, $data->bigPicNotNull);
		$pagesize = intval($data->pagesize);
		$p = !empty($data->pagenum) ? intval($data->pagenum) - 1 : 0;
		$offset = $p * intval($data->pagesize);
		$info = array();
		if(!empty($count))
		{
			$info = $mod->getList($offset, $pagesize, $param, $data->bigPicNotNull);
		}
		$info = is_array($info) ? $info : array();
		return $data = array('data' => $info,'count' => $count,'pagenum' => $data->pagenum);
	}

	public function addTopic($info)
	{
		$param = $this->setTopicDataCount($info);
		$topicMod = new \models\portal\topic\TopicMod();
		return $topicMod->addTopic($param);
	}

	public function editTopic($info, $toId)
	{
		$param = $this->setTopicData($info);
		$topicMod = new \models\portal\topic\TopicMod();
		return $topicMod->editTopic($param, $toId);
	}

	public function delTopic($topicId)
	{
		$topicMod = new \models\portal\topic\TopicMod();
		return $topicMod->deleteTopic($topicId);
	}

	public function getOneTopic($topicId)
	{
		$topicMod = new \models\portal\topic\TopicMod();
		return $topicMod->getOneTopic($topicId);
	}

	private function setTopicDataCount($data)
	{
		$param = array();
		$param['to_title'] = empty($data->title)? '' :array('s',$data->title);
		$param['to_pic'] = empty($data->pic)? '' :array('s',$data->pic);
		$param['to_big_pic'] = empty($data->bigPic)? '' :array('s',$data->bigPic);
		$param['to_url'] = empty($data->toUrl)? '' :array('s',$data->toUrl);
		$param['to_summary'] = empty($data->summary)? '' :array('s',$data->summary);
		$param['to_show_index'] = empty($data->showIndex)? '' :array('s',$data->showIndex);
		$param['to_status'] = $data->status === '' ? '' :array('i',$data->status);
		return $param;
	}
	private function setTopicData($data)
	{
		$param = array();
		$param['to_title'] = empty($data->title)? array('s','') :array('s',$data->title);
		$param['to_pic'] = empty($data->pic)? array('s','') :array('s',$data->pic);
		$param['to_big_pic'] = empty($data->bigPic)? array('s','') :array('s',$data->bigPic);
		$param['to_url'] = empty($data->toUrl)? array('s','') :array('s',$data->toUrl);
		$param['to_summary'] = empty($data->summary)? array('s','') :array('s',$data->summary);
		$param['to_show_index'] = empty($data->showIndex)? array('s','') :array('s',$data->showIndex);
		$param['to_status'] = $data->status === '' ? array('i','') :array('i',$data->status);
		return $param;
	}
}
<?php
namespace lib\portal\index;

class IndexLib
{
	public function index()
	{
		$indexMod = new \models\portal\index\IndexMod();
		return $indexMod->getList();
	}
}
<?php
namespace lib\portal\articles;

class ArticlesLib
{

	public function getArticleTitleCount($data)
	{
		$info = $this->setTitleData($data);
		$articleTitleMod = new \models\portal\articles\ArticleTitleMod();
		return $articleTitleMod->getArticleTitleCount($info);
	}

	public function getArticleTitleList($data, $offset, $pagesize)
	{
		$orderBy = 'at_create_time';
		if(!empty($data->orderBy))
		{
			switch($data->orderBy)
			{
				case 'viewNum':
					$orderBy = 'at_view_num';
					break;
				case 'comNum':
					$orderBy = 'at_com_num';
					break;
			}
		}
		$sort = empty($data->sort)? ' DESC' :' ' . $data->sort;
		$info = $this->setTitleData($data);
		$articleTitleMod = new \models\portal\articles\ArticleTitleMod();
		$result = $articleTitleMod->getArticleTitleList($info, $offset, $pagesize, $orderBy . $sort);
		$returns = array();
		if(is_array($result))
		{
			foreach($result as $value)
			{
				$returns[] = $this->setTitleReturnData($value);
			}
		}
		return $returns;
	}

	public function getIndexPublish($tag, $limit)
	{
		$tag = $this->articleMakeTag($tag);
		$articleTitleMod = new \models\portal\articles\ArticleTitleMod();
		$result = $articleTitleMod->getIndexPublish($tag, $limit);
		$returns = array();
		if(is_array($result))
		{
			$returns = $result;
		}
		return $returns;
	}

	public function addArticleTitle($data)
	{
		$data = $this->setTitleData($data);
		$data['at_click'] = array('s','[0,0,0,0,0,0,0,0]');
		$data['at_create_time'] = empty($data['at_create_time'])? array('i',$_SERVER['REQUEST_TIME']) :$data['at_create_time'];
		$articleTitleMod = new \models\portal\articles\ArticleTitleMod();
		return $articleTitleMod->addArticleTitle($data);
	}

	public function addArticleTrahsTitle($data)
	{
		$articleTitleMod = new \models\portal\articles\ArticleTitleMod();
		return $articleTitleMod->addArticleTrashTitle($data);
	}

	public function updateArticleTitle($data, $atId)
	{
		$data = $this->setTitleUpdateData($data);
		$articleTitleMod = new \models\portal\articles\ArticleTitleMod();
		return $articleTitleMod->updateArticleTitle($data, $atId);
	}

	public function addArticleContent($atId, $content)
	{
		// 替换论坛图片地址
		$content = preg_replace("#(\<img src=\")(http\:\/\/[www.ename.cn|news.ename.cn|news1.ename.cn]+\/)?(data\/attachment\/portal\/([\/\.\w]*)\")#i", '\1http://www.dnbbs.com/\3', $content);
		$regexp = '/(\<strong\>##########NextPage(\[title=(.*?)\])?##########\<\/strong\>)+/is';
		preg_match_all($regexp, $content, $arr);
		$pagetitle = !empty($arr[3])? $arr[3] :array();
		$pagetitle = array_map('trim', $pagetitle);
		$contents = preg_split($regexp, $content);
		$articleContentMod = new \models\portal\articles\ArticleContentMod();
		foreach($contents as $key => $content)
		{
			$tags = array("'<iframe[^>]*?>.*?</iframe>'is","'<frame[^>]*?>.*?</frame>'is",
				"'<script[^>]*?>.*?</script>'is","'<head[^>]*?>.*?</head>'is","'<title[^>]*?>.*?</title>'is",
				"'<meta[^>]*?>'is","'<link[^>]*?>'is");
			$content = preg_replace($tags, "", $content);
			$page = empty($pagetitle)? '' :($key + 1);
			$title = empty($pagetitle[$key - 1])? '' :$pagetitle[$key - 1];
			$articleContentMod->addArticleContent($atId, $content, $title, $page);
		}
		return true;
	}

	public function updateArticleContent($atId, $content)
	{
		$articleContentMod = new \models\portal\articles\ArticleContentMod();
		return $articleContentMod->updateArticleContent($atId, $content);
	}

	public function addArticleKeyword($atId, $keyword)
	{
		$keyword = strip_tags($keyword);
		$keywordArr = explode(',', $keyword);
		$articleKeywordsMod = new \models\portal\articles\ArticleKeywordsMod();
		$articleKeywordsMapMod = new \models\portal\articles\ArticleKeywordsMapMod();
		foreach($keywordArr as $value)
		{
			$akId = $articleKeywordsMod->getArticleKeyword($value);
			if(!$akId)
			{
				$akId = $articleKeywordsMod->addArticleKeywords(time(), $value);
			}
			$articleKeywordsMapMod->addArticleKeywordsMap($akId, $atId);
		}
		return true;
	}

	public function delArticleKeywordMap($atId)
	{
		$articleKeywordsMapMod = new \models\portal\articles\ArticleKeywordsMapMod();
		return $articleKeywordsMapMod->delArticleKeywordMap($atId);
	}

	public function getArticleKeywords($atId)
	{
		$articleKeywordsMapMod = new \models\portal\articles\ArticleKeywordsMapMod();
		$maps = $articleKeywordsMapMod->getArticleKeywordsMap($atId);
		$keywords = array();
		if(!empty($maps))
		{
			$ids = array();
			$articleKeywordsMod = new \models\portal\articles\ArticleKeywordsMod();
			foreach($maps as $value)
			{
				$ids[] = $value['ak_id'];
			}
			$keys = $articleKeywordsMod->getArticleKeywordByIds($ids);
			if(!empty($keys))
			{
				foreach($ids as $id)
				{
					foreach($keys as $key)
					{
						if($key['ak_id'] == $id)
						{
							$keywords[] = $key['ak_keyword'];
						}
					}
				}
			}
		}
		return $keywords;
	}

	public function getKeywordArticles($atId, $limit ,$order='')
	{
		$articleKeywordsMapMod = new \models\portal\articles\ArticleKeywordsMapMod();
		$maps = $articleKeywordsMapMod->getArticleKeywordsMap($atId);
		$returns = array();
		if(!empty($maps))
		{
			$ids = array();
			foreach($maps as $value)
			{
				$ids[] = $value['ak_id'];
			}
			$atIds = array();
			if(!empty($ids))
			{
				$articleMaps = $articleKeywordsMapMod->getArticleIdsByIds($ids, $limit,$order);
				foreach($articleMaps as $value)
				{
					if($value['at_id'] != $atId)
					{
						$atIds[] = $value['at_id'];
					}
				}
			}
			if(!empty($atIds))
			{
				$articleMod = new \models\portal\articles\ArticleTitleMod();
				$articles = $articleMod->getArticleTitleByIds($atIds, $limit);
				if(!empty($articles))
				{
					foreach($articles as $value)
					{
						$returns[] = array('title' => $value['at_title'],'shortTitle' => $value['at_short_title'],
							'caId' => $value['ca_id'],'atId' => $value['at_id'],'createTime' => $value['at_create_time']);
					}
				}
			}
		}
		return $returns;
	}

	public function addArticleRelated($atId, $relatedId)
	{
		$relatedIdArr = explode(',', $relatedId);
		$data = array();
		foreach($relatedIdArr as $value)
		{
			$data[] = array($atId,$value);
		}
		$articleRelatedMod = new \models\portal\articles\ArticleRelatedMod();
		return $articleRelatedMod->addArticlerelated($data);
	}

	public function getArticleTitleById($atId, $init = true)
	{
		$articleTitleMod = new \models\portal\articles\ArticleTitleMod();
		$result = $articleTitleMod->getArticleTitleById($atId);
		if(!empty($result) && $init)
		{
			$result = $this->setTitleReturnData($result);
		}
		return $result;
	}

	public function getArticleTrashCount()
	{
		$articleTrashMod = new \models\portal\articles\ArticleTrashMod();
		return $articleTrashMod->getArticleTrashCount();
	}

	public function getArticleTrashList($offset, $pagesize)
	{
		$articleTrashMod = new \models\portal\articles\ArticleTrashMod();
		$result = $articleTrashMod->getArticleTrashList($offset, $pagesize);
		$returns = array();
		if(is_array($result))
		{
			foreach($result as $value)
			{
				$trashId = $value['ar_id'];
				$value = json_decode($value['ar_content'], true);
				$returns[] = array('trashId' => $trashId,'title' => $value['at_title'],
					'username' => $value['at_username'],'caId' => $value['ca_id'],
					'createTime' => $value['at_create_time']);
			}
		}
		return $returns;
	}

	public function delArticleTitleById($atId)
	{
		$articleTitleMod = new \models\portal\articles\ArticleTitleMod();
		return $articleTitleMod->delArticleTitleById($atId);
	}

	public function addArticleTitleTrash($info)
	{
		$articleTrashMod = new \models\portal\articles\ArticleTrashMod();
		return $articleTrashMod->addArticleTrash($info);
	}

	public function getArticleTrah($trashId)
	{
		$articleTrashMod = new \models\portal\articles\ArticleTrashMod();
		return $articleTrashMod->getArticleTrash($trashId);
	}

	public function delArticleTrash($trashId)
	{
		$articleTrashMod = new \models\portal\articles\ArticleTrashMod();
		return $articleTrashMod->delArticleTrash($trashId);
	}

	public function delArticleContent($atId)
	{
		$articleContentMod = new \models\portal\articles\ArticleContentMod();
		return $articleContentMod->delArticleContent($atId);
	}

	public function delArticleCount($atId)
	{
		$articleCountMod = new \models\portal\articles\ArticleCountMod();
		return $articleCountMod->delArticleCount($atId);
	}

	public function delArticleRelated($atId)
	{
		$articleCountMod = new \models\portal\articles\ArticleRelatedMod();
		return $articleCountMod->deleteArticleRelate($atId);
	}

	public function getArticleRelated($atId, $limit = '')
	{
		$articleCountMod = new \models\portal\articles\ArticleRelatedMod();
		$related = $articleCountMod->getArticleRelated($atId, $limit);
		$relateds = array();
		if(!empty($related))
		{
			$ids = array();
			foreach($related as $value)
			{
				$ids[] = $value['al_at_id'];
			}
			$articleTitleMod = new \models\portal\articles\ArticleTitleMod();
			$relatedTitles = $articleTitleMod->getArticleTitleByIds($ids);
			if(!empty($relatedTitles))
			{
				foreach($relatedTitles as $value)
				{
					$relateds[] = array('createTime' => $value['at_create_time'],'atId' => $value['at_id'],
						'title' => $value['at_title'],'caId' => $value['ca_id'],'shortTitle' => $value['at_short_title'],
						'titleStyle' => $value['at_title_style']);
				}
			}
		}
		return $relateds;
	}

	public function getArticleContent($atId)
	{
		$articleContentMod = new \models\portal\articles\ArticleContentMod();
		return $articleContentMod->getArticleContent($atId);
	}

	public function getArticleCount($atId, $caId)
	{
		$articleCountMod = new \models\portal\articles\ArticleCountMod();
		return $articleCountMod->getArticleCountById($atId, $caId);
	}

	public function addArticleCount($atId, $caId)
	{
		$articleCountMod = new \models\portal\articles\ArticleCountMod();
		return $articleCountMod->addArticleCount($atId, $caId);
	}

	public function updateArticleCount($data, $atId)
	{
		$data = $this->setArticleCount($data);
		$articleCountMod = new \models\portal\articles\ArticleCountMod();
		return $articleCountMod->updateArticleCount($data, $atId);
	}

	public function getArticleCountCount()
	{
		$articleCountMod = new \models\portal\articles\ArticleCountMod();
		return $articleCountMod->getArticleCountCount();
	}

	public function getArticleCountList($data, $offset, $pagesize)
	{
		$articleCountMod = new \models\portal\articles\ArticleCountMod();
		$orderBy = 'ao_id';
		if(!empty($data->orderBy))
		{
			switch($data->orderBy)
			{
				case 'aoId':
					$orderBy = 'ao_id';
					break;
				case 'favNum':
					$orderBy = 'ao_fav_num';
					break;
				case 'viewNum':
					$orderBy = 'ao_view_num';
					break;
				case 'shareNum':
					$orderBy = 'ao_share_num';
					break;
				case 'comNum':
					$orderBy = 'ao_com_num';
					break;
			}
		}
		$sort = empty($data->sort)? ' DESC' :' ' . $data->sort;
		$result = $articleCountMod->getArticleCountList($orderBy . $sort, $offset, $pagesize);
		$returns = array();
		if(!empty($result))
		{
			$articleTitleMod = new \models\portal\articles\ArticleTitleMod();
			foreach($result as $value)
			{
				$title = $articleTitleMod->getArticleTitleById($value['at_id']);
				$returns[] = array('title' => empty($title['at_title'])? '' :$title['at_title'],
					'favNum' => $value['ao_fav_num'],'viewNum' => $value['ao_view_num'],
					'shareNum' => $value['ao_share_num'],'comNum' => $value['ao_com_num']);
			}
		}
		return $returns;
	}

	public function getArticleClickById($atId, $enameId, $username)
	{
		$articleClickMod = new \models\portal\articles\ArticleClickMod();
		return $articleClickMod->getArticleClickById($atId, $enameId, $username);
	}

	public function addArticleClick($data)
	{
		$articleClickMod = new \models\portal\articles\ArticleClickMod();
		$param['at_id'] = (int)$data->atId;
		$param['ai_ename_id'] = (int)$data->enameId;
		$param['ai_username'] = $data->username;
		$param['ai_click_id'] = (int)$data->clickId;
		$param['ai_create_time'] = time();
		return $articleClickMod->addArticleClick($param);
	}

	public function getArticleClick($atId, $limit)
	{
		$articleClickMod = new \models\portal\articles\ArticleClickMod();
		$result = $articleClickMod->getArticleClick($atId, $limit);
		$returns = array();
		if(!empty($result))
		{
			foreach($result as $value)
			{
				$returns[] = array('enameId' => $value['ai_ename_id'],'username' => $value['ai_username']);
			}
		}
		return $returns;
	}

	public function addArticleAttachment($data)
	{
		$info['at_id'] = empty($data->atId)? 0 :(int)$data->atId;
		$info['aa_url'] = $data->aaUrl;
		$info['aa_file_type'] = $data->aaFileType;
		$info['aa_file_size'] = $data->aaFileSize;
		$info['aa_is_image'] = empty($data->aaIsImage)? 0 :1;
		$articleAttachmentMod = new \models\portal\articles\ArticleAttachmentMod();
		return $articleAttachmentMod->addAttachment($info);
	}

	public function getArticleAttachment($atId, $aaId)
	{
		$articleAttachmentMod = new \models\portal\articles\ArticleAttachmentMod();
		return $articleAttachmentMod->getAttachment($atId, $aaId);
	}

	public function delArticleAttachment($aaId)
	{
		$articleAttachmentMod = new \models\portal\articles\ArticleAttachmentMod();
		return $articleAttachmentMod->delAttachment($aaId);
	}

	public function upArticleAttachment($aaId, $atId)
	{
		$articleAttachmentMod = new \models\portal\articles\ArticleAttachmentMod();
		return $articleAttachmentMod->upAttachment($aaId, $atId);
	}

	public function addArticleComment($data)
	{
		$articleCommentMod = new \models\portal\articles\ArticleCommentMod();
		$data = $this->setArticleComment($data);
		return $articleCommentMod->addArticleComment($data);
	}

	public function getArticleCommentById($amId)
	{
		$articleCommentMod = new \models\portal\articles\ArticleCommentMod();
		return $articleCommentMod->getArticleCommentById($amId);
	}

	public function updateArticleComment($data, $amId)
	{
		$articleCommentMod = new \models\portal\articles\ArticleCommentMod();
		return $articleCommentMod->updateArticleComment($data, $amId);
	}

	public function getArticleCommentCount($data)
	{
		$articleCommentMod = new \models\portal\articles\ArticleCommentMod();
		$params['status'] = $data->status;
		$params['atId'] = (int)$data->atId;
		$params['enameId'] = (int)$data->enameId;
		return $articleCommentMod->getArticleCommentCount($params);
	}

	public function getArticleCommentList($data, $offset, $pagesize)
	{
		$articleCommentMod = new \models\portal\articles\ArticleCommentMod();
		$params['status'] = $data->status;
		$params['atId'] = (int)$data->atId;
		$params['enameId'] = (int)$data->enameId;
		$result = $articleCommentMod->getArticleCommentList($params, $offset, $pagesize);
		$returns = array();
		if(!empty($result))
		{
			$articleTitleMod = new \models\portal\articles\ArticleTitleMod();
			$appconfig = new \Yaf\Config\Ini(APP_PATH . '/conf/application.ini', 'product');
			$memberMod = new \models\manage\member\AppMemberextMod();
			foreach($result as $value)
			{
				$title = $this->getArticleTitleById($value['at_id']);
				$tempData = array('username' => $value['am_username'], 'articleInfo' => $title, 
					'amId' => $value['am_id'], 'message' => $value['am_message'], 'status' => $value['am_status'], 
					'createTime' => $value['am_create_time'], 'favNum' => $value['am_good_num'], 
					'enameId' => $value['am_ename_id'], 'userContact' => $value['am_user_contact'], 
					'userContactType' => $value['am_user_contact_type']);
				//app接口需要 获取用户头像地址
				if(\common\Common::getRequestUser() == 'api')
				{
					$tempData['amAvatar'] = '';
					!isset($appinfo[$value['am_ename_id']]) &&
						 $appinfo[$value['am_ename_id']] = $memberMod->getInfoByEnameId($value['am_ename_id']);
					if(!empty($appinfo[$value['am_ename_id']]['Avatar']))
					{
						list($preName, $time) = explode('_', $appinfo[$value['am_ename_id']]['Avatar']);
						$tempData['amAvatar'] = $appconfig->application->imgurl . $preName . '_118_' . $time;
					}
				}
				$returns[] = $tempData;
			}
		}
		return $returns;
	}

	public function delArticleComment($amId)
	{
		$articleCommentMod = new \models\portal\articles\ArticleCommentMod();
		return $articleCommentMod->delArticleComment($amId);
	}

	public function getArticleTitleMaxCount($params)
	{
		$articleTitleMod = new \models\portal\articles\ArticleTitleMod();
		return $articleTitleMod->getArticleTitleMaxCount($params);
	}

	public function getArticleTitleMaxInfo()
	{
		$articleTitleMod = new \models\portal\articles\ArticleTitleMod();
		return $articleTitleMod->getArticleTitleMaxInfo();
	}

	private function setArticleComment($data)
	{
		$param['am_ename_id'] = array('i',empty($data->enameId)? '' :(int)$data->enameId);
		$param['at_id'] = array('i',empty($data->atId)? '' :(int)$data->atId);
		$param['am_username'] = array('s',empty($data->username)? '' :$data->username);
		$param['am_post_ip'] = array('s',empty($data->comIp)? '' :$data->comIp);
		$param['am_message'] = array('s',empty($_GET['message'])? '' :$_GET['message']);
		$param['am_user_contact_type'] = array('i',empty($data->contactType)? '' :$data->contactType);
		$param['am_user_contact'] = array('s',empty($data->contact)? '' :$data->contact);
		$param['am_create_time'] = array('i',time());
		return $param;
	}

	private function setArticleCount($data)
	{
		if(!empty($data->caId))
		{
			$param['ca_id'] = array('i',(int)$data->caId);
		}
		$param['ao_com_num'] = array('i',empty($data->comNum)? 0 :(int)$data->comNum);
		$param['ao_fav_num'] = array('i',empty($data->favNum)? 0 :(int)$data->favNum);
		$param['ao_view_num'] = array('i',empty($data->viewNum)? 0 :(int)$data->viewNum);
		$param['ao_share_num'] = array('i',empty($data->shareNum)? 0 :(int)$data->shareNum);
		return $param;
	}

	private function setTitleData($data)
	{
		$param = array();
		$param['at_id'] = empty($data->atId)? '' :array('i',(int)$data->atId);
		$param['ca_id'] = empty($data->caId)? '' :array('i',(int)$data->caId);
		$param['at_username'] = empty($data->username)? '' :array('s',$data->username);
		$param['at_ename_id'] = empty($data->enameId)? '' :array('i',(int)$data->enameId);
		$param['at_title'] = empty($data->title)? '' :array('s',$data->title);
		$param['at_pic'] = empty($data->pic)? '' :array('s',$data->pic);
		$param['at_short_title'] = empty($data->shortTitle)? '' :array('s',$data->shortTitle);
		$param['at_author'] = empty($data->author)? '' :array('s',$data->author);
		$param['at_from'] = empty($data->from)? '' :array('s',$data->from);
		$param['at_from_url'] = empty($data->fromUrl)? '' :array('s',$data->fromUrl);
		$param['at_title_style'] = empty($data->titleStyle)? '' :array('s',$data->titleStyle);
		$param['at_summary'] = empty($data->summary)? '' :array('s',$data->summary);
		$param['at_url'] = empty($data->toUrl)? '' :array('s',$data->toUrl);
		$param['at_tid'] = empty($data->tid)? '' :array('i',(int)$data->tid);
		$param['at_allow_comment'] = (!isset($data->allowComment) || $data->allowComment === '')? '' :array('i',
			(int)$data->allowComment);
		$param['at_tag'] = empty($data->tag)? '' :array('i',$this->articleMakeTag($data->tag));
		$param['at_create_time'] = empty($data->createTime)? '' :array('i',$data->createTime);
		$param['at_ios_tag'] = empty($data->iosTag)? '' :array('i',(int)$data->iosTag);
		$param['at_ios_top'] = empty($data->iosTop)? '' :array('i',(int)$data->iosTop);
		$param['at_ios_title'] = empty($data->iosTitle)? '' :array('s',$data->iosTitle);
		$param['at_hd_img'] = empty($data->hdImg)? '' :array('s',$data->hdImg);
		$param['at_zx_img'] = empty($data->zxImg)? '' :array('s',$data->zxImg);
		$param['at_ios_new_img'] = empty($data->iosNewImg)? '' :array('s',$data->iosNewImg);
		$param['at_ios_top_img'] = empty($data->iosTopImg)? '' :array('s',$data->iosTopImg);
		$param['at_tk_from'] = empty($data->tkFrom)? '' :array('s',$data->tkFrom);
		$param['at_status'] = (!isset($data->status) || $data->status === '')? '' :array('i',$data->status);
		$param['at_com_num'] = empty($data->comNum)? '' :array('i',$data->comNum);
		$param['at_view_num'] = empty($data->viewNum)? '' :array('i',$data->viewNum);
		$param['at_credit'] = empty($data->credit)? '' :array('i',$data->credit);
		$param['noIds'] = empty($data->noIds)? '' :explode(',', $data->noIds);
		$param['idLess'] = empty($data->idLess)? '' :(int)$data->idLess;
		$param['idThan'] = empty($data->idThan)? '' :(int)$data->idThan;
		$param['caIds'] = empty($data->caIds)? '' :explode(',', $data->caIds);
		$param['atIds'] = empty($data->atIds)? '' :explode(',', $data->atIds);
		$param['noUser'] = empty($data->noUser)? '' :explode(',', $data->noUser);
		$param['enameIdNotNull'] = empty($data->enameIdNotNull)? '' :$data->enameIdNotNull;
		$param['hdImgNotNull'] = empty($data->hdImgNotNull)? '' :$data->hdImgNotNull;
		$param['zxImgNotNull'] = empty($data->zxImgNotNull)? '' :$data->zxImgNotNull;
		$param['comNumNotNull'] = empty($data->comNumNotNull)? '' :$data->comNumNotNull;
		$param['iosNewImgNotNull'] = empty($data->iosNewImgNotNull)? '' :$data->iosNewImgNotNull;
		$param['iosTopImgNotNull'] = empty($data->iosTopImgNotNull)? '' :$data->iosTopImgNotNull;
		$param['at_user_contact'] = empty($data->contact)? '' :array('s',$data->contact);
		$param['at_user_contact_type'] = empty($data->contactType)? '' :array('i',$data->contactType);
		$param['at_admin_id'] = empty($data->adminId)? 0 :array('i',$data->adminId);
		$param['orTag'] = empty($data->orTag)? array() :$this->setArticleOrtag($data->orTag);
		return $param;
	}

	/**
	 * 聚合标签或的的组合（如：1或2）
	 * @param string $tags
	 * @return array
	 */
	private function setArticleOrtag($tags)
	{
		$orTags = array();
		if(!empty($tags))
		{
			$tagArr = explode(',',$tags);
			foreach ($tagArr as $v){
				$orTags[] = array('i',$this->articleMakeTag($v));
			}
		}
		return $orTags;
	}

	public function setTitleUpdateData($data)
	{
		$param = array();
		$param['ca_id'] = !isset($_POST['caId'])? '' :array('i',(int)$data->caId);
		$param['at_title'] = !isset($_POST['title'])? '' :array('s',$data->title);
		$param['at_pic'] = !isset($_POST['pic'])? '' :array('s',$data->pic);
		$param['at_short_title'] = !isset($_POST['shortTitle'])? '' :array('s',$data->shortTitle);
		$param['at_author'] = !isset($_POST['author'])? '' :array('s',$data->author);
		$param['at_from'] = !isset($_POST['from'])? '' :array('s',$data->from);
		$param['at_from_url'] = !isset($_POST['fromUrl'])? '' :array('s',$data->fromUrl);
		$param['at_title_style'] = !isset($_POST['titleStyle'])? '' :array('s',$data->titleStyle);
		$param['at_summary'] = !isset($_POST['summary'])? '' :array('s',$data->summary);
		$param['at_url'] = !isset($_POST['toUrl'])? '' :array('s',$data->toUrl);
		$param['at_tid'] = !isset($_POST['tid'])? '' :array('i',(int)$data->tid);
		$param['at_allow_comment'] = !isset($_POST['allowComment'])? '' :array('i',(int)$data->allowComment);
		$param['at_tag'] = !isset($_POST['tag'])? '' :array('i',$this->articleMakeTag($data->tag));
		$param['at_create_time'] = !isset($_POST['createTime'])? '' :array('i',(int)$data->createTime);
		$param['at_ios_tag'] = !isset($_POST['iosTag'])? '' :array('i',(int)$data->iosTag);
		$param['at_ios_top'] = !isset($_POST['iosTop'])? '' :array('i',(int)$data->iosTop);
		$param['at_ios_title'] = !isset($_POST['iosTitle'])? '' :array('s',$data->iosTitle);
		$param['at_hd_img'] = !isset($_POST['hdImg'])? '' :array('s',$data->hdImg);
		$param['at_zx_img'] = !isset($_POST['zxImg'])? '' :array('s',$data->zxImg);
		$param['at_ios_new_img'] = !isset($_POST['iosNewImg'])? '' :array('s',$data->iosNewImg);
		$param['at_ios_top_img'] = !isset($_POST['iosTopImg'])? '' :array('s',$data->iosTopImg);
		$param['at_tk_from'] = !isset($_POST['tkFrom'])? '' :array('s',$data->tkFrom);
		$param['at_status'] = (!isset($_POST['status']) || $data->status === '')? '' :array('i',$data->status);
		$param['at_com_num'] = !isset($_POST['comNum'])? '' :array('i',$data->comNum);
		$param['at_view_num'] = !isset($_POST['viewNum'])? '' :array('i',$data->viewNum);
		$param['at_credit'] = !isset($_POST['credit'])? '' :array('i',$data->credit);
		$param['at_click'] = !isset($_POST['click'])? '' :array('s',$data->click);
		$param['at_user_contact'] = !isset($_POST['contact'])? '' :array('s',$data->contact);
		$param['at_user_contact_type'] = !isset($_POST['contactType'])? '' :array('i',$data->contactType);
		$param['at_reject_reason'] = !isset($_POST['reason'])? '' :array('s',$data->reason);
		$param['at_admin_id'] = !isset($_POST['adminId'])? 0 :array('i',$data->adminId);
		return $param;
	}

	public function setTitleReturnData($data)
	{
		$param = array();
		$param['atId'] = empty($data['at_id'])? '' :$data['at_id'];
		$param['caId'] = empty($data['ca_id'])? '' :$data['ca_id'];
		$param['enameId'] = empty($data['at_ename_id'])? '' :$data['at_ename_id'];
		$param['username'] = empty($data['at_username'])? '' :$data['at_username'];
		$param['title'] = empty($data['at_title'])? '' :$data['at_title'];
		$param['shortTitle'] = empty($data['at_short_title'])? '' :$data['at_short_title'];
		$param['titleStyle'] = empty($data['at_title_style'])? '' :$data['at_title_style'];
		$param['author'] = empty($data['at_author'])? '' :$data['at_author'];
		$param['from'] = empty($data['at_from'])? '' :$data['at_from'];
		$param['fromUrl'] = empty($data['at_from_url'])? '' :$data['at_from_url'];
		$param['toUrl'] = empty($data['at_url'])? '' :$data['at_url'];
		$param['summary'] = empty($data['at_summary'])? '' :$data['at_summary'];
		$param['pic'] = empty($data['at_pic'])? '' :$data['at_pic'];
		$param['tid'] = empty($data['at_tid'])? '' :$data['at_tid'];
		$param['allowComment'] = empty($data['at_allow_comment'])? 0 :$data['at_allow_comment'];
		$param['click'] = empty($data['at_click'])? '' :json_decode($data['at_click']);
		$param['tag'] = empty($data['at_tag'])? '' :$this->articleParseTags($data['at_tag']);
		$param['createTime'] = empty($data['at_create_time'])? '' :$data['at_create_time'];
		$param['status'] = empty($data['at_status'])? 0 :$data['at_status'];
		$param['credit'] = empty($data['at_credit'])? 0 :$data['at_credit'];
		$param['iosTag'] = empty($data['at_ios_tag'])? 0 :$data['at_ios_tag'];
		$param['iosTop'] = empty($data['at_ios_top'])? 0 :$data['at_ios_top'];
		$param['hdImg'] = empty($data['at_hd_img'])? '' :$data['at_hd_img'];
		$param['zxImg'] = empty($data['at_zx_img'])? '' :$data['at_zx_img'];
		$param['iosNewImg'] = empty($data['at_ios_new_img'])? '' :$data['at_ios_new_img'];
		$param['iosTopImg'] = empty($data['at_ios_top_img'])? '' :$data['at_ios_top_img'];
		$param['iosTitle'] = empty($data['at_ios_title'])? '' :$data['at_ios_title'];
		$param['tkFrom'] = empty($data['at_tk_from'])? '' :$data['at_tk_from'];
		$param['comNum'] = empty($data['at_com_num'])? 0 :$data['at_com_num'];
		$param['viewNum'] = empty($data['at_view_num'])? 0 :$data['at_view_num'];
		$param['rejectReason'] = empty($data['at_reject_reason'])? '' :$data['at_reject_reason'];
		$param['userContactType'] = empty($data['at_user_contact_type'])? '' :$data['at_user_contact_type'];
		$param['userContact'] = empty($data['at_user_contact'])? '' :$data['at_user_contact'];
		$param['adminId'] = empty($data['at_admin_id'])? '' :$data['at_admin_id'];
		return $param;
	}

	private function articleParseTags($tag)
	{
		$articleTags = array();
		for($i = 1; $i <= 8; $i ++)
		{
			$k = pow(2, $i - 1);
			if($tag & $k)
			{
				$articleTags[] = $i;
			}
		}
		return implode(',', $articleTags);
	}

	private function articleMakeTag($tags)
	{
		$tags = explode(',', $tags);
		$tag = 0;
		for($i = 1; $i <= 8; $i ++)
		{
			if(in_array($i, $tags))
			{
				$tag += pow(2, $i - 1);
			}
		}
		return $tag;
	}
}
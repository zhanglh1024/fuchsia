<?php
namespace lib\portal\seo;
class SeoLib
{
	public function getSeo()
	{
		$mod = new \models\portal\seo\SeoMod();	
		$info = array();
		$info = $mod->getList();
		$info = is_array($info) ? $info : array();
		return $data = array('data' => $info);
	}

	public function editSeo($info, $seId)
	{
		$param = $this->setSeoData($info);
		$seoMod = new \models\portal\seo\SeoMod();
		return $seoMod->editSeo($param, $seId);
	}

	public function getOneSeo($info)
	{
		$param = $this->setSeoData2($info);
		$seoMod = new \models\portal\seo\SeoMod();
		return $seoMod->getOneSeo($param);
	}
	
	private function setSeoData($data)
	{
		$param = array();
		$param['se_title'] = empty($data->title)? array('s','') :array('s',$data->title);
		$param['se_url'] = empty($data->url)? array('s','') :array('s',$data->url);
		$param['se_name'] = empty($data->name)? array('s','') :array('s',$data->name);
		$param['se_desc'] = empty($data->description)? array('s','') :array('s',$data->description);
		$param['se_keywords'] = empty($data->keywords)? array('s','') :array('s',$data->keywords);
		return $param;
	}
	private function setSeoData2($data)
	{
		$param = array();
		$param['se_id'] = empty($data->seId)? '' :array('i',$data->seId);
		
		return $param;
	}
}
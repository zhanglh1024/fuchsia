<?php
namespace lib\epp\func;

/**
 * 更新域名DNS的核心函数，方便外层多个函数使用
 */
class UpdateDns
{

	/**
	 *
	 * @param array $regDns 从注册局获取到的域名DNS
	 * @param array $data 要提交的参数
	 * @return 要提交给注册局的数据
	 */
	public static function getValues($regDns, $data)
	{
		if(! isset($data['domain']))
		{
			throw new \Exception('domain can not be null',2999);
		}
		if(! isset($data['dnsId']) || $data['dnsId'] > 2 || $data['dnsId'] < 0)
		{
			throw new \Exception('dnsId can not be null or must between 0,2',2998);
		}
		if(1 == $data['dnsId'])
		{
			$data['DNS'] = \lib\epp\config\Registar::$dns;
		}
		else
		{
			if(! isset($data['DNS']) || count($data['DNS']) > 6)
			{
				throw new \Exception('DNS unset or must between 0,6');
			}
			foreach($data['DNS'] as $dkey => $dns)
			{
				$data['DNS'][$dkey] = strtolower($dns);
			}
		}
		$regDns = array_map(function($i){return strtolower($i);}, $regDns);//转换大小写 方便对比
		$newDns = array_values($data['DNS']);
		$oldDns = array_values($regDns);
		sort($newDns);
		sort($oldDns);
		if($oldDns == $newDns)
		{
			return true; //表示新旧的DNS是一样的
		}
		unset($data);
		$onlyOld = array_diff($oldDns, $newDns); // 只在旧DNS中存在的，这些是必须是删除的
		$onlyNew = array_diff($newDns, $oldDns); // 只在新DNS中存在的，这些是必须要增加的
		return array($onlyOld,$onlyNew);
	}
}
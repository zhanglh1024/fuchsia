<?php
namespace lib\epp\config;

class StatusConfig
{

	public static $status = array(
			'clientDeleteProhibited'=> 3,
			'clientTransferProhibited'=> 4,
			'clientUpdateProhibited'=> 5,
			'clientRenewProhibited'=> 6,
			'clientHold'=> 7
	);
	
	//如果是转入的域名清楚掉这个状态 因为域名在其他家可能是clientUpdateProhibited 转入我们这边类似一个新域名 不能沿用之前的状态
	public static $haveUpdateStatus = 'clientUpdateProhibited';
}
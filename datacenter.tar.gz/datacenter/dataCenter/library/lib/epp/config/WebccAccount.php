<?php
namespace lib\epp\config;

class WebccAccount
{

	public static $key = 'kongweb';

	public static $source = 'webcc-enamecnxmn';

	public static $username = 'hushanhuitest';

	public static $password = 'hush123';

	public static $webccParams = array('newuser' => 'old','encoding' => 'big5','lang' => 'CHI','reg_contact_type' => 1,
			'custom_reg1' => '801212-12-12','custom_reg2' => '1980-12-12','custom_reg3' => '1980-12-12',
			'custom_adm1' => '1980-12-12','custom_adm2' => '1980-12-12','custom_adm3' => '1980-12-12',
			'custom_tec1' => '1980-12-12','custom_tec2' => '1980-12-12','custom_tec3' => '1980-12-12',
			'custom_bil1' => '1980-12-12','custom_bil2' => '1980-12-12','custom_bil3' => '1980-12-12');
}
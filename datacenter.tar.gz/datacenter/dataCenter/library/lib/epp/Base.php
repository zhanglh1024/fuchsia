<?php
namespace lib\epp;

class Base
{

	private $ip;

	private $port;

	private static $punyLib = false;

	protected $eppClass = false;
	
	protected $eppMethod = false;
	
	protected $regId;//计算出来该请求要走的接口ID
	
	protected $dn;

	function __construct($dn, $regId = false)
	{
		$this->dn = $dn;
		$this->setSocketInfo($regId);
	}

	/**
	 * 配置底层SOCKET资源
	 *
	 * @param string $dn
	 * @param int $regId
	 */
	private function setSocketInfo($regId = false)
	{
		$config = config\Registar::$eppInfo;
		$regId = false == $regId? $this->getEppId($this->dn): $regId;
		$eppConfig = isset($config[$regId])? $config[$regId]: false;
		if(false === $eppConfig)
		{
			throw new \Exception('epp config not have this tld ' . $regId);
		}
		$this->regId = $regId;
		$this->ip = $eppConfig['ip'];
		$this->port = $eppConfig['port'];
	}

	/**
	 * 根据域名后缀 或者 要注册的HOST 获取走那个EPP id
	 *
	 * @param string $dn
	 */
	private function getEppId($dn)
	{
		$tld = func\Domain::getTld($dn);
		$id = isset(config\Registar::$defaultEppId[$tld])? config\Registar::$defaultEppId[$tld]: false;
		if(! $id)
		{
			throw new \Exception('no epp id');
		}
		return $id;
	}

	/**
	 * 域名编码
	 *
	 * @param string $dn
	 */
	private function punycode($dn)
	{
		if(self::$punyLib == false)
		{
			self::$punyLib = new \common\Punycode();
		}
		return self::$punyLib->encode($dn);
	}

	/**
	 * 连接SOCKET服务器
	 *
	 * @param string 要操作的命令
	 * @param array $param
	 */
	protected function connSocketServer($param)
	{
		if(isset($param['domain']))
		{
			if(is_array($param['domain']))
			{
				foreach($param['domain'] as $key => $value)
				{
					$param['domain'][$key] = $this->punycode($value);
				}
			}
			else
			{
				$param['domain'] = $this->punycode($param['domain']);
			}
		}
		if(isset($param['host']))
		{
			$param['host'] = $this->punycode($param['host']);
		}
		$command = $this->eppClass . '::' . $this->eppMethod; // 转换成底层可以识别的命令
		$param = json_encode($param);
		$outputStr = $errno = $errstr = "";
		\core\Log::write($param, 'epp');
		$fp = @fsockopen($this->ip, $this->port, $errno, $errstr, 5); // 设置连接SOCKET
		if(! $fp)
		{
			$outputStr = false;
		}
		else
		{
			set_time_limit(30);
			fwrite($fp, $command . ':::' . $param . "\r\n");
			stream_set_timeout($fp, 30); // 设置读写操作30秒超时
			while(! feof($fp))
			{
				$outputStr .= fgets($fp, 1024);
			}
			fclose($fp);
		}
		if(empty($outputStr))
		{
			return array('code'=> 2345,'msg'=>'network error');
		}
		$result = json_decode($outputStr, true);
		if(! $result)
		{
			return array('code'=> 2346,'msg'=>'content is not json ' .$outputStr);
		}
		return $result;
	}

	/**
	 * 把构造函数里面的域名合并到data参数里面
	 * @param array $data
	 */
	protected function mergeData($data)
	{
		if(!isset($data['domain']))
		{
			$data['domain'] = $this->dn;
		}
		return $data;
	}
	
	/**
	 * 返回提示信息
	 *
	 * @param string $data
	 * @param int $code
	 * @param boolean $succFlag 成功还是失败 失败返回msg 成功返回data
	 */
	protected function returnMsg($data, $code = null, $succFlag = null)
	{
		$code = null == $code ?1000 :$code;
		$succFlag = null == $succFlag ?$succFlag :$succFlag;
		$result = array('code'=> $code);
		if($succFlag)
		{
			$result['data'] = $data;
		}
		else
		{
			$result['msg'] = $data;
		}
		return $result;
	}
	
	/**
	 * 检查参数里面是否有domain这个key
	 * @param array $data
	 */
	protected function checkDomainExists($data)
	{
		if(!isset($data['domain']))
		{
			return $this->returnMsg('domain can not be null',2999,false);
		}
		return true;
	}
}
<?php
namespace lib\epp\action;
use \lib\epp\config;

class EppContact extends \lib\epp\Base
{

	function __construct($dn, $regId = false)
	{
		parent::__construct($dn, $regId);
		$this->eppClass = 'contact';
	}

	/**
	 * 注册联系人,如果是CN/中国/公司/网络的域名e_template_zh,其他传e_template_en
	 * 必须含有:TemplateName,FirstName,LastName,Org,Street,Province,PostCode,CountryName
	 * Phone,TelCC,Fax,FaxCC,Email
	 * 
	 * @param array $data
	 * @return array
	 */
	public function create(array $data,$cardType=NULL,$cardCode=NULL)
	{
		$this->eppMethod = 'create';
		$param = array();
		$param['templateID'] = $data['TemplateName'];
		$param['name'] = $data['FirstName'] . $data['LastName'];
		$param['org'] = $data['Org'];
		$param['street'] = $data['Street'];
		$param['city'] = $data['City'];
		$param['sp'] = $data['Province'];
		$param['pc'] = $data['PostCode'];
		$param['cc'] = $data['CountryName'];
		$param['phonec'] = $data['TelCC'];
		$param['phone'] = $data['Phone'];
		$param['faxc'] = $data['FaxCC'];
		$param['fax'] = $data['Fax'];
		$param['email'] = $data['Email'];
		if($cardType)
		{
			$param['cardType'] = $cardType;
		}
		if($cardCode)
		{
			$param['cardCode'] = $cardCode;
		}
		return $this->connSocketServer($param);
	}
	
	/**
	 * 删除联系人ID 
	 * @param string $templateName  ename_开的字符串
	 * @return array
	 */
	public function delete($templateName)
	{
		$this->eppMethod = 'delete';
		$param = array();
		$param['templateID'] = $templateName;
		return $this->connSocketServer($param);
	}
	
	/**
	 * 更新联系人ID
	 * @param array $info
	 * @return array
	 */
	public function update(array $info)
	{
		$this->eppMethod = 'update';
		$data = array();
		$data['templateID'] = $info['TemplateName'];
		if(!in_array($this->regId, \lib\epp\config\Registar::$notUpdateName))
		{
			$data['name'] = $info['FirstName'] . $info['LastName'];
			$data['org'] = $info['Org'];
		}
		$data['street'] = $info['Street'];
		$data['city'] = $info['City'];
		$data['sp'] = $info['Province'];
		$data['pc'] = $info['PostCode'];
		$data['cc'] = $info['CountryName'];
		$data['phonec'] = $info['TelCC'];
		$data['phone'] = $info['Phone'];
		$data['faxc'] = $info['FaxCC'];
		$data['fax'] = $info['Fax'];
		$data['email'] = $info['Email'];
		return $this->connSocketServer($data);
	}
	
	/**
	 * 查询联系人ID信息
	 * @param string $templateName  ename_开的字符串
	 * @return array
	 */
	public function info($templateName)
	{
		$this->eppMethod = 'info';
		$data = array();
		$data['templateID'] = $templateName;
		return $this->connSocketServer($data);
	}
}
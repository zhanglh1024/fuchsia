<?php
namespace lib\epp\action;
use \lib\epp\config;

class EppDomain extends \lib\epp\Base
{

	function __construct($dn, $regId = false)
	{
		parent::__construct($dn, $regId);
		$this->eppClass = 'domain';
	}

	public function create(array $data,$templateName = '')
	{
		$data = $this->mergeData($data);
		$this->eppMethod = 'create';
		if(! isset($data['domain']))
		{
			return $this->returnMsg('domain can not be null',2999,false);
		}
		$param = array("domain"=> $data['domain']);
		if(array_key_exists('period', $data))
		{
			$param['period'] = $data['period'];
		}
		else
		{
			$param['period'] = 1;
		}
		$param['periodUnit'] = 'y'; // 单位：年
		if(! isset($data['dns']) || empty($data['dns']))
		{
			unset($data['dns']);
			$data['dns'] = config\Registar::$dns;
		}
		$param['DNS'] = $data['dns'];
		if(! empty($data['extension']))
		{
			$param['extension'] = $data['extension'];
		}
		// 非com/net/cc/tv域名必须要有联系人ID
		if(\lib\epp\func\domain::getNeedTemplateIdTld($this->dn))
		{
			$param['templateID'] = $templateName;
		}
		return $this->connSocketServer($param);
	}

	public function renew(array $data)
	{
		$data = $this->mergeData($data);
		$this->eppMethod = 'renew';
		if(empty($data["period"]) || $data["period"] < 1 || $data["period"] > 10)
		{
			return $this->returnMsg('time must be 1-10 year',2999,false);
		}
		if(! isset($data['domain']) || ! isset($data["expDate"]))
		{
			return $this->returnMsg('domain and expDate can not be null',2999,false);
		}
		$data['periodUnit'] = 'y';
		return $this->connSocketServer($data);
	}
	
	public function delete()
	{
		$data = $this->mergeData(array());
		$this->eppMethod = 'delete';
		if(! isset($data['domain']))
		{
			return $this->returnMsg('domain can not be null',2999,false);
		}
		return $this->connSocketServer($data);
	}
	
	/**
	 *
	 * @param array $data
	 * @param int $regId
	 */
	public function check(array $data)
	{
		$data = $this->mergeData($data);
		$this->eppMethod = 'check';
		// 单数字，双数字，三数字 单字母 双字母 三字母 .com .cn .com.cn 无脑返回已经注册
		$dnArr = $data['domain'];
		$toCheck = array();
		$noCheck = array();
		foreach($dnArr as $v)
		{
			$v = strtolower($v);
			$dn = explode('.', $v);
			if(strlen($dn[0]) < 4 && ctype_alnum($dn[0]) &&
				 (in_array($dn[1], array('com','cn','net')) || (isset($dn[2]) && $dn[1] . $dn[2] == 'comcn')))
			{
				$noCheck[] = $v;
			}
			else
			{
				$toCheck[] = $v;
			}
		}
		if($toCheck)
		{
			if(! empty($data['extension']['launch']))
			{
				if(empty($data['extension']['launch']['phase']))
				{
					return $this->returnMsg('launch phase can not be null',2999,false);
				}
			}
			return $this->connSocketServer($data);
		}
		else
		{
			$data = array();
			$data['registered'] = $noCheck;
			$data['notRegister'] = array();
			return $this->returnMsg($data);
		}
	}
	
	/**
	 * 更新域名DNS dnsId=1 表示使用我司固定DNS =0 表示使用参数里面的DNS  DNS:参数必须是数组 key从1开始
	 * @param array $data
	 */
	public function updateDns(array $data)
	{
		$data = $this->mergeData($data);
		try
		{
			$info = $this->info();
			$dns = isset($info['code']) && $info['code']==1000 ?$info['DNS'] :false;
			if($dns)
			{
				$result = \lib\epp\func\UpdateDns::getValues($dns, $data);
				if(true === $result)
				{
					return $this->returnMsg('success');
				}
				list($delete, $add) = $result;
				unset($data['DNS']);//前面提交来的数据
				if($add)
				{
					$data['DNS'] = $add;
				}
				if($delete)
				{
					$data['delDNS'] = $delete;
				}
				$this->eppMethod = 'update_dns';
				return $this->connSocketServer($data);
			}
			else
			{
				throw new \Exception('query domain info error',2995);
			}
		}
		catch (\Exception $e)
		{
			return $this->returnMsg($e->getMessage(),$e->getCode(),false);
		}
	}
	
	/**
	 * 更新域名联系人
	 * @param array $data
	 */
	public function updateContact($templateName)
	{
		$info = $this->info();
		if(isset($info['code']) && $info['code'] == 1000)
		{
			$funcResult = \lib\epp\func\UpdateContact::getValues($info, $this->dn, $this->regId,$templateName);
			if(true === $funcResult)
			{
				return $this->returnMsg('success');
			}
			list($data,$eppMethod,$subData) = $funcResult;
			$this->eppMethod = $eppMethod;
			$result = $this->connSocketServer($data);
			if($subData && $result['code'] == 1000)
			{
				$this->eppMethod = 'update_contact_4';
				$this->connSocketServer($subData);//top,wang 域名只要注册人更新成功了视为更新成功
			}
			return $result;
		}
		else
		{
			return $this->returnMsg('query domain info error',2995,false);
		}
	}
	
	/**
	 * 更新域名转移密码
	 * @param string $pwd
	 */
	public function updatePwd($pwd)
	{
		$data = $this->mergeData(array());
		if(!isset($data['domain']))
		{
			return $this->returnMsg('domain can not be null',2999,false);
		}
		$data['password'] = $pwd;
		$this->eppMethod = 'update_password';
		return $this->connSocketServer($data);
	}
	
	
	/**
	 * 取消域名转入
	 * @return array
	 */
	public function cancelTransferIn()
	{
		$data = $this->mergeData(array());
		$this->eppMethod = 'transfer_cancel';
		if(!isset($data['domain']))
		{
			return $this->returnMsg('domain can not be null',2999,false);
		}
		return $this->connSocketServer($data);
	}
	
	/**
	 * 拒绝域名转出
	 * @return array
	 */
	public function rejectTransferOut()
	{
		$data = $this->mergeData(array());
		$this->eppMethod = 'transfer_reject';
		if(!isset($data['domain']))
		{
			return $this->returnMsg('domain can not be null',2999,false);
		}
		return $this->connSocketServer($data);
	}
	
	/**
	 * 提交域名赎回报告
	 * @param array $data 参数:preData 域名删除时间
	 */
	public function restoreReport(array $data)
	{
		$data = $this->mergeData($data);
		$this->eppMethod = 'restore_report';
		if(!isset($data['domain']))
		{
			return parent::resultInfo(ErrorCode::$PARAMS_ERROR, 'domain can not be null');
		}
		if(!isset($data['preData']))
		{
			return parent::resultInfo(ErrorCode::$PARAMS_ERROR, 'preData not be null');
		}
		$data['delTime'] = $data['preData'];
		$times = time();
		//cn的作下特殊处理 其他先不变化 注册局要求的格式
		if(\lib\epp\func\Domain::getTld($this->dn) == 'cn')
		{
			$data['postData'] = date("Y-m-d",$times)."T".date("H:i:s",$times).".0Z";
			$data['resTime'] = date("Y-m-d",$times)."T".date("H:i:s",$times).".0Z";
		}
		else
		{
			$data['postData'] = date("Y-m-d",$times)."T".date("H:i:s",$times)."Z";
			$data['resTime'] = date("Y-m-d",$times)."T".date("H:i:s",$times)."Z";
		}
		return $this->connSocketServer($data);
	}
	
	/**
	 * 提交域名赎回申请
	 * @return array
	 */
	public function restoreRequest()
	{
		$data = $this->mergeData(array());
		$this->eppMethod = 'restore_request';
		if(!isset($data['domain']))
		{
			return $this->returnMsg('domain can not be null',2999,false);
		}
		return $this->connSocketServer($data);
	}
	
	/**
	 * 更新域名状态
	 * @param array $status 要操作的状态 3-7 \lib\epp\config\StatusConfig::$status 如果要删除所有的状态传空数组 array()
	 */
	public function updateStatus(array $status)
	{
		$data = $this->mergeData(array());
		if(!isset($data['domain']))
		{
			return $this->returnMsg('domain can not be null',2999,false);
		}
		try
		{
			$info = $this->info();
			if(isset($info['code']) && $info['code'] == 1000)
			{
				$this->eppMethod = 'update_status';
				$result = \lib\epp\func\UpdateStatus::getValues($info['status'], $status);
				if(true === $result)
				{
					return $this->returnMsg('success');
				}
				list($add,$del,$needDelete) = $result;
				if(false !== $needDelete)
				{
					$data['delStatus'] = array($needDelete);
					$updateResult = $this->connSocketServer($data);
					if(!isset($updateResult['code']) || $updateResult['code'] != 1000)
					{
						return $this->returnMsg('clear clientUpdateProhibited faield',2994,false);
					}
				}
				$data['addStatus'] = $add;
				$data['delStatus'] = $del;
				return $this->connSocketServer($data);
			}
			else
			{
				return $this->returnMsg('query domain info error',2995,false);
			}
		}
		catch (\Exception $e)
		{
			return $this->returnMsg($e->getMessage(),$e->getCode(),false);
		}
	}
	
	/**
	 * 获取默认接口配置
	 */
	public function getConfig()
	{
		return \lib\epp\config\Registar::$defaultEppId;
	}
	
	/**
	 * 同意域名转出
	 */
	public function approveTransferOut()
	{
		$data = $this->mergeData(array());
		$this->eppMethod = 'transfer_approve';
		if(!isset($data['domain']))
		{
			return $this->returnMsg('domain can not be null',2999,false);
		}
		return $this->connSocketServer($data);
	}
	
	/**
	 * 查询域名转移进度
	 * @param string $pwd 可选的密码
	 */
	public function queryTransferInfo($pwd=null)
	{
		$data = $this->mergeData(array());
		$this->eppMethod = 'transfer_query';
		if(!isset($data['domain']))
		{
			return $this->returnMsg('domain can not be null',2999,false);
		}
		if($pwd)
		{
			$data['password'] = $pwd;
		}
		return $this->connSocketServer($data);
	}
	
	/**
	 * 申请域名转入
	 * @param int $years 要续费的年限
	 * @param string $pwd 域名的密码
	 * @return array
	 */
	public function applyTransferIn($years,$pwd)
	{
		$data = $this->mergeData(array());
		$this->eppMethod = 'transfer_request';
		if(!isset($data['domain']))
		{
			return $this->returnMsg('domain can not be null',2999,false);
		}
		$data['period'] = $years;
		$data['periodUnit'] = 'y';
		$data['password'] = $pwd;
		return $this->connSocketServer($data);
	}
	
	/**
	 * 查询域名信息
	 * @param array $data
	 * @return array
	 */
	public function info()
	{
		$data = $this->mergeData(array());
		$this->eppMethod = 'info';
		if(!isset($data['domain']))
		{
			return $this->returnMsg('domain can not be null',2999,false);
		}
		return $this->connSocketServer($data);
	}
}
<?php
namespace lib\epp\action;

class EppHost extends \lib\epp\Base
{
	function __construct($dn, $regId = false)
	{
		parent::__construct($dn, $regId);
		$this->eppClass = 'host';
	}
	
	/**
	 * 检测HOST是否已经注册
	 * @param string $host
	 * @return array
	 */
	public function check($host)
	{
		$this->eppMethod = 'check';
		$data = $this->mergeData(array());
		$data['host'] = $host;
		return $this->connSocketServer($data);
	}

	/**
	 * 注册HOST 当host和dn后缀不一样的时候不需要传ip
	 * @param string $host
	 * @param string $ip
	 * @param string $ipType
	 * @return array
	 */
	public function create($host,$ip=null,$ipType=null)
	{
		$this->eppMethod = 'create';
		$data = $this->mergeData(array());
		$data['host'] = $host;
		$ipType = null == $ipType ?4:6;
		if($ip)
		{
			$data['ip'] = $ip;
			$data['ipv'] = $ipType;
		}
		return $this->connSocketServer($data);
	}
	
	/**
	 * 删除HOST
	 * @param string $host
	 * @return array
	 */
	public function delete($host)
	{
		$this->eppMethod = 'delete';
		$data = $this->mergeData(array());
		$data['host'] = $host;
		return $this->connSocketServer($data);
	}
	
	/**
	 * 更新HOST指向的IP
	 * @param string $host
	 * @param array $add  array('ip'=>array(多个),'v'=>array(4,6))
	 * @param array $del  array('ip'=>array(多个),'v'=>array(4,6,6))  v和ip 要对应
	 * @return array
	 */
	public function update($host,array $add,array $del)
	{
		$this->eppMethod = 'update';
		$data = $this->mergeData(array());
		$data['host'] = $host;
		if($add)
		{
			$data['addIP'] = $add['ip'];
			$data['addIPv']= $add['v'];
		}
		if($del)
		{
			$data['delIP'] = $del['ip'];
			$data['delIPv'] = $del['v'];
		}
		return $this->connSocketServer($data);
	}
	
	/**
	 * 查询host信息
	 * @param string $host
	 * @return array
	 */
	public function info($host)
	{
		$this->eppMethod = 'info';
		$data = $this->mergeData(array());
		$data['host'] = $host;
		return $this->connSocketServer($data);
	}
}
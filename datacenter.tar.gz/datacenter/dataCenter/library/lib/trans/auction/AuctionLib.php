<?php
namespace lib\trans\auction;

class AuctionLib
{

	private $conf;

	public function __construct()
	{
		// 加载配置 
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
	}

	public function formatData($data)
	{
		$pLib = new \lib\trans\common\PublicLib();
		// 加载配置
		foreach($data as $k => $v)
		{
			$v['FinishDate'] = strtr($v['FinishDate'], array('T' => ' ','Z' => ' '));
			$time = strtotime($v['FinishDate']) - time();
			
			if($time < 0)
			{
				$data[$k]['LeftTime'] = '交易已结束';
			}
			else
			{
				$data[$k]['LeftTime'] = $pLib->NewTimeToDHIS($time);
			}
			$data[$k]['BidPrice'] = intval(explode(',', $v['BidPrice'])[0]);
			unset($data[$k]['FinishDate']);
		}
		
		return $data;
	}

	/**
	 *
	 * @param int $transtype        	
	 * @param array $condition        	
	 * @param int $transtopic        	
	 * @param boolean $pageMore        	
	 * @param boolean $flag
	 *        	是否域名简介一起搜索
	 * @return multitype:number Ambigous <number> NULL multitype: string
	 */
	public function getSearchTransByType($transtype, $condition = array())
	{
		$pubicLib = new \lib\trans\common\PublicLib();
		$domainList = array();
		$transTypeConf = $this->conf->trans_type->toArray();
		$transType = $pubicLib->covertArray($transTypeConf, 1);
		$domainAuctionSolr = new \models\trans\solr\DomainAuctionSolr();
		// Solr服务不通则从mysql获取数据
		if($domainAuctionSolr->ping())
		{
			try
			{
				$r = $domainAuctionSolr->getTransSearch($transtype, $condition['domain']['sld'], 
					$condition['getSldType'], $condition['domain']['tld'], $condition['sysGroupOne'], 
					$condition['sysGroupTwo'], $condition['domainLen'], $condition['bidPrice'], $condition['finishTime'], 
					$condition['registrar'], $condition['transType'], $condition['getHideNoBider'], 
					$condition['getSort'], $condition['page'], $condition['num'], $condition['getBidPriceEnd'], 
					$condition['bidStartOne'], $condition['skip']);
			}
			catch(\Exception $e)
			{
				\core\Log::write("getSearchTransByType," . $e->getMessage(), 'trans', 'tao');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610001'),610001);
			}
			$domainList['list'] = ($r->docs == false)? array() :$r->docs;
			$domainList['count'] = $r->numFound;
		}
		if($domainList['list'])
		{
			$domainList['list'] = $this->formatData($domainList['list']);
		}
		return $domainList;
	}

	/**
	 * 搜索询价记录
	 *
	 * @param array $condition        	
	 * @return multitype:
	 */
	public function getInquirySearchSql($condition)
	{
		$inquirySolr = new \models\trans\solr\InquirySolr();
		if($inquirySolr->ping())
		{
			try
			{
				$r = $inquirySolr->getInquirySearchModel($condition['domain']['sld'], $condition['getSldType'], 
					$condition['domain']['tld'], $condition['sysGroupOne'], $condition['sysGroupTwo'], 
					$condition['domainLen'], $condition['bidPrice'], $condition['finishTime'], $condition['registrar'], 
					$condition['transType'], $condition['getHideNoBider'], $condition['getSort'], $condition['page'], 
					$condition['num'], $condition['skip']);
				$count = $r->numFound;
			}
			catch(\Exception $e)
			{
				\core\Log::write("getInquirySearch," . $e->getMessage(), 'trans', 'tao');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610001'),610001);
			}
			
			$domainList['list'] = ($r->docs == false)? array() :$r->docs;
			$domainList['count'] = $r->numFound;
		}
		
		return $domainList;
	}

	/**
	 * 获取搜索字符位置
	 *
	 * @param unknown $start        	
	 * @param unknown $end        	
	 */
	public function getWordPosition($start, $end)
	{
		if($start && $end)
			return 4; // 开头或结尾
		else
		{
			if($start)
				return 1; // 开头
			elseif($end)
				return 3; // 结尾
			else
				return 2; // 包含
		}
	}

	/**
	 *
	 * @param int $enameId        	
	 * @param int $auditListId        	
	 * @param array $rs        	
	 * @return multitype:string boolean unknown Ambigous <string, number> NULL number Ambigous <unknown, number> Ambigous <number, unknown> Ambigous <boolean, mixed>
	 */
	public function getTransData($enameId, $rs, $isAjax)
	{
		// 加载配置
		$transTopicConf = $this->conf->trans_transtopic->toArray();
		$transStatus = $this->conf->trans_status->toArray();
		$transTypeConf = $this->conf->trans_type->toArray();
		$regConf = $this->conf->fabu_reg->toArray();
		$data = array();
		// 请求时间
		$rqTime = empty($_SERVER['REQUEST_TIME'])? time() :$_SERVER['REQUEST_TIME'];
		// 是否结束
		$isfinish = ((strtotime($rs['FinishDate']) - $rqTime) > 0 && $rs['TransStatus'] == $transStatus['trading'][0])? false :true;
		if(!$isAjax)
		{
			// id
			$data['id'] = $rs['AuditListId'];
			// 域名
			$data['domainName'] = \lib\trans\common\PublicDomainLib::replaceL($rs['DomainName']);
			// 简介
			$data['simpleDec'] = htmlspecialchars_decode($rs['SimpleDec']);
			// 注册商
			$data['reg'] = $rs['IsDomainInEname'] == $regConf['inename'][0]? $regConf['inename'][1] :$regConf['notinename'][1];
			// 卖家
			$data['seller'] = $rs['Seller'];
			// 是否开拍
			$isbegin = ((strtotime($rs['CreateDate']) - $rqTime) > 0)? false :true;
			// 是否是卖家
			$isseller = ($rs['Seller'] == $enameId)? True :False;
			// 判断是否隐藏价格
			$isShowPrice = ($rs['TransStatus'] != 1 && $rs['TransType'] == 4) ? !($isseller || ($rs['Buyer'] == $enameId && $enameId)): false;
			// 买家
			$data['Buyer'] = ($rs['Buyer'] == $enameId) ? $rs['Buyer'] : ($rs['NickName'] != $rs['Buyer'] ? '隐藏':$rs['NickName']);
			// 起拍价
			$data['askingPrice'] = ($isfinish && $rs['TransType'] == $transTypeConf['rengou'][0]) || $isShowPrice? '隐藏' :intval(
				$rs['AskingPrice']);
			// 判断是否登录
			$data['enameId'] = $enameId;
			$data['tips'] = '';
			if(!$isbegin)
			{
				$data['tips'] = '亲！该域名还没开拍哦！敬请期待！';
			}
			elseif($isfinish)
			{
				if($rs['TransStatus'] == $transStatus['sellercanel'][0])
				{
					$data['tips'] = '卖家取消交易';
				}
				else
				{
					$data['tips'] = '交易已经结束';
				}
			}
			elseif($isseller)
			{
				$data['tpis'] = '该域名是您所有，不能出价';
			}
			$userNickName = '';
			$data['userNickName'] = '';
			$data['userName'] = '';
			if($enameId)
			{
				// 出过价就显示这个昵称
				$userNickName = $this->getUserNickName($rs['AuditListId'], $enameId);
				$data['userNickName'] = !empty($userNickName)? $userNickName :'';
			}
			if(!$userNickName)
			{
				// 未出价就显示这个昵称
				$data['userName'] = $enameId? $this->createUserNickName($rs['AuditListId'], $enameId) :'';
			}
			$data['transType'] = $rs['TransType'];
		}
		// 是否结束
		$data['isFinish'] = $isfinish;
		// 是否显示出价记录列表
		$isbidRecorder = false;
		if($enameId&&$isfinish)
		{
			$bidRecordMod = new \models\trans\BidRecordMod();
			$isbidRecorder = $bidRecordMod->checkIsBider($rs['AuditListId'], $enameId)? TRUE :FALSE;
			if($isbidRecorder)
			{
				$isbidRecorder = true;
			}
		}
		if($isfinish&&($enameId == $rs['Seller']))
		{
			$isbidRecorder = TRUE;
		}
		// 当前价格
		$data['bidPrice'] = $isfinish? $isbidRecorder ?  (int)($rs['BidPrice']) : '隐藏' : (int)($rs['BidPrice']);
		$data['askingPrice'] = $isfinish ? 
				$isbidRecorder ? intval($rs['AskingPrice']) : '隐藏' 
			:intval($rs['AskingPrice']);

		// 计算剩余时间$lefttimes
		$pLib = new \lib\trans\common\PublicLib();
		$lefttimes = strtotime($rs['FinishDate']) - time();
		$data['remainTime'] = $lefttimes;
		$data['leftTime'] = $pLib->timeToDHIS($lefttimes);
		
		// 当前领先
		if($isfinish)
		{
			$data['nickName'] = $isbidRecorder ? $rs['NickName'] : '隐藏';
		}
		else
		{
			if($rs['NickName'])
			{
				$data['nickName'] = $rs['NickName'];
			}
			else
			{
				$data['nickName'] = '暂无人出价';
			}
		}
		$data['AgentBidPrice'] = 0;
		if($rs['TransType'] == $transTypeConf['auction'][0])
		{
			if($enameId == $rs['Buyer'] && $rs['Buyer'] != 0)
			{
				$isleader = TRUE;
				$agentBidPrice = ($rs['AgentBidPrice'] > 0)? $rs['AgentBidPrice'] :false;
			}
			else
			{
				$isleader = FALSE;
				$agentBidPrice = FALSE;
			}
			if($rs['BidCount'] == 0)
			{
				$lowPrice = $rs['BidPrice'];
			}
			elseif($isleader && $rs['AgentBidPrice'] != 0)
			{
				$lowPrice = $this->createAddPrice($rs['AgentBidPrice'], FALSE, $rs['Seller']);
				$data['AgentBidPrice'] = intval($rs['AgentBidPrice']);
			}
			else
			{
				$lowPrice = $this->createAddPrice($rs['BidPrice'], FALSE, $rs['Seller']);
			}
			// 出价次数
			$data['bidCount'] = $rs['BidCount'];
			// 加价幅度
			$data['addPrice'] = $this->createAddPrice($rs['BidPrice'], TRUE, $rs['Seller']);
			// 获取出价保证金金额
			$data['deposit'] = $this->createAssMoney($lowPrice, FALSE, $rs['Seller']);
			// 最低出价
			$data['lowPrice'] = intval($lowPrice);
		}
		// 拍卖周期
		$data['transCycleStart'] = date('Y-m-d H:i', strtotime($rs['CreateDate']));
		$data['transCycleEnd'] = date('Y-m-d H:i', strtotime($rs['FinishDate']));
		return $data;
	}

	/**
	 * getUserNickName
	 * 获得当前用户NickName
	 */
	public function getUserNickName($auditListId, $enameId)
	{
		$TBRsdk = new \models\trans\BidRecordMod();
		$nickName = $TBRsdk->getNickNameOfRecord($auditListId, $enameId);
		return $nickName;
	}

	/**
	 * createAddPrice
	 *
	 * @param int $bidPrice        	
	 * @param bool $one
	 *        	true 返回加价幅度
	 *        	return $addPrice
	 */
	public function createAddPrice($bidPrice, $one = FALSE, $seller = FALSE)
	{
		if($seller == $this->conf->cnnicUser)
		{
			$addPriceValue = $this->conf->trans_cnnic_addprice->toArray();
		}
		else
		{
			$addPriceValue = $this->conf->trans_addprice->toArray();
		}
		$addPriceKey = array_keys($addPriceValue);
		foreach($addPriceKey as $v)
		{
			if($bidPrice > $v)
			{
				$addPrice = $addPriceValue[(string)($v)];
				break;
			}
		}
		if($one)
		{
			$addPrice = (int)($addPrice);
			return $addPrice;
		}
		$addPrice = (int)($addPrice) + (int)($bidPrice);
		return $addPrice;
	}
	
	/*
	 * createAssMoney @param int $startPrice return $assMoney
	 */
	public function createAssMoney($bidPrice, $transType = false, $seller = FALSE)
	{
		if($bidPrice > 0 && $bidPrice <= 199)
		{
			$assMoney = 20;
		}
		elseif($bidPrice >= 200 && $bidPrice <= 999)
		{
			$assMoney = 50;
		}
		elseif($bidPrice >= 1000 && $bidPrice <= 4999)
		{
			$assMoney = 100;
		}
		elseif($bidPrice >= 5000 && $bidPrice <= 19999)
		{
			$assMoney = 500;
		}
		elseif($bidPrice >= 20000 && $bidPrice <= 49999)
		{
			$assMoney = 1000;
		}
		elseif($bidPrice >= 50000 && $bidPrice <= 99999)
		{
			$assMoney = 2000;
		}
		if($seller == $this->conf->cnnicUser)
		{
			if($bidPrice >= 100000)
			{
				$assMoney = 5000;
			}
		}
		else
		{
			if($bidPrice >= 100000 && $bidPrice <= 499999)
			{
				$assMoney = 5000;
			}
			elseif($bidPrice >= 500000)
			{
				$assMoney = 10000;
			}
		}
		$transTypeConfig = $this->conf->trans_transtype->toArray();
		if($transType == $transTypeConfig['booking'][0])
		{
			$assMoney = $assMoney > 50? $assMoney :50; // 判断是否是预订竞价 预订竞价最低冻结50元
		}
		return $assMoney;
	}

	/**
	 * createUserNickName
	 * 生成用户Id
	 */
	public function createUserNickName($auditListId, $enameId)
	{
		$pLib = new \lib\trans\common\PublicLib();
		$temp = $auditListId . $enameId;
		$userNickName = $pLib->toBase($temp);
		unset($temp);
		return $userNickName;
	}

	/**
	 * 获取询价详情
	 *
	 * @param int $inquiryId        	
	 * @param int $inquiryOnsaleStatus        	
	 * @return multitype:boolean unknown |multitype:boolean NULL
	 */
	public function inquiryDomainSql($inquiryId, $inquiryOnsaleStatus)
	{
		$TIsdk = new \models\trans\InquiryMod();
		$info = $TIsdk->getInquiryDomainInfoModel($inquiryId, $inquiryOnsaleStatus);
		
		if($info === false)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'),610000);
		}
		
		return $info;
	}

	/**
	 * 设置询价记录过期
	 *
	 * @param unknown $enameId        	
	 * @param unknown $inquiryId        	
	 * @param unknown $inquiryOnsaleStatus        	
	 * @param unknown $inquiryEndsaleStatus        	
	 * @return boolean
	 */
	public function inquiryCanelSql($enameId, $inquiryId, $inquiryOnsaleStatus, $inquiryEndsaleStatus)
	{
		$TIsdk = new \models\trans\InquiryMod();
		$RightInquiryId = $TIsdk->getInquiryCanelIdModel($enameId, $inquiryId, $inquiryOnsaleStatus);
		if($RightInquiryId)
		{
			if($TIsdk->setInquiryCanelIdModel($enameId, $inquiryId, $inquiryOnsaleStatus, $inquiryEndsaleStatus))
			{
				return True;
			}
		}
		return False;
	}

	public function getEbuyDomainList($list, $day, $maxNum)
	{
		// 加载配置
		$transTopicConf = $this->conf->fabu_transtopic->toArray();
		$transStatusConf = $this->conf->trans_status->toArray();
		
		$topicList = array();
		$redis = new \lib\trans\trans\TransRedisLib();
		if($redis->isExistsEbuyRedis() == false)
		{
			$redis->setDetailEbuyRedis($transTopicConf, $transStatusConf);
		}
		$i = 0;
		// 遍历获取数据
		foreach($list as $key => $vaildTopic)
		{
			$keyName = $redis->getEbuyDetailKeyName($vaildTopic['TopicId'], $day);
			$ids = $redis->getAuditListIdsByTopic($keyName);
			$bestIds = $redis->getBestAuditListIdsByTopic($transTopicConf['ebuy'][0], $vaildTopic['TopicId'], $day);
			$bestCount = count($bestIds);
			$topicDomainIds = $bestIds? array_unique(array_merge($bestIds, $ids)) :$ids;
			$topic = $redis->getDomainByTopicId($topicDomainIds, 'ebuy', $bestCount);
			if($topic)
			{
				$topicList[$i]['TopicName'] = $vaildTopic['TopicName'];
				$topicList[$i]['TopicId'] = $vaildTopic['TopicId'];
				foreach($topic as $k => $v)
				{
					$topic[$k]['BidPrice'] = intval($v['BidPrice']);
				}
				$topicList[$i]['Count'] = count($topic);
				if($maxNum && (count($topic) > $maxNum))
				{
					$topic = array_slice($topic, 0, $maxNum);
				}
				$topicList[$i]['TopicDomain'] = $topic;
				$i ++;
			}
		}
		
		return $topicList;
	}

	public function getTopicDomainList($list, $day, $maxNum)
	{
		$topicList = array();
		// 加载配置
		$transTopicConf = $this->conf->fabu_transtopic->toArray();
		$transStatusConf = $this->conf->trans_status->toArray();
		
		$redis = new \lib\trans\trans\TransRedisLib();
		// 判断是否存在redis
		if($redis->isExistsTopicRedis() == false)
		{
			$redis->setDetailTopicRedis($transTopicConf, $transStatusConf);
		}
		// 遍历获取数据
		$i = 0;
		foreach($list as $key => $vaildTopic)
		{
			$keyName = $redis->getTopicDetailKeyName($vaildTopic['TopicId'], $day);
			$ids = $redis->getAuditListIdsByTopic($keyName);
			$bestIds = $redis->getBestAuditListIdsByTopic($transTopicConf['topicshow'][0], $vaildTopic['TopicId'], $day);
			$bestCount = count($bestIds);
			$topicDomainIds = $bestIds? array_unique(array_merge($bestIds, $ids)) :$ids;
			$topic = $redis->getDomainByTopicId($topicDomainIds, 'topic', $bestCount);
			if($topic)
			{
				$topicList[$i]['TopicName'] = $vaildTopic['TopicName'];
				$topicList[$i]['TopicId'] = $vaildTopic['TopicId'];
				foreach($topic as $k => $v)
				{
					$topic[$k]['BidPrice'] = intval($v['BidPrice']);
				}
				$topicList[$i]['Count'] = count($topic);
				if($maxNum && (count($topic) > $maxNum))
				{
					$topic = array_slice($topic, 0, $maxNum);
				}
				$topicList[$i]['TopicDomain'] = $topic;
				$i ++;
			}
		}
		return $topicList;
	}
}
?>
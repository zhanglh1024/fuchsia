<?php
namespace lib\trans\seller;

class SellerLib
{

	private $conf;

	private $financeConf;

	public function __construct()
	{
		// 加载配置
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
		$this->financeConf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
	}

	/**
	 * 批量下架交易
	 */
	public function doCancelTrans($ids, $enameId, $checkBid = FALSE)
	{
		// 加载配置
		$statusConf = $this->conf->trans_status->toArray();
		$transTopicConf = $this->conf->trans_transtopic->toArray();
		
		$TDAsdk = new \models\trans\DomainAuctionMod();
		$TSsdk = new \models\trans\redis\TransSeller();
		$result = array();
		$flag = FALSE;
		if($ids && is_array($ids))
		{
			foreach($ids as $id)
			{
				$data = $TDAsdk->getDelTransInfo($id, $enameId);
				if($data)
				{
					// 抢滩域名禁止下架
					if($data['TransTopic'] == $transTopicConf['beach'][0] || $data['TransTopic'] == $transTopicConf['specialauction'][0])
					{
						$result[] = array('flag' => FALSE,'domainName' => $data['DomainName'],'msg' => \common\Lang::create('transmsg')->getMsg('610003'));
						continue;
					}
					
					if($data['TransStatus'] != $statusConf['trading'][0])
					{
						$result[] = array('flag' => FALSE,'domainName' => $data['DomainName'],
							'msg' => \common\Lang::create('transmsg')->getMsg('610004'));
						continue;
					}
					if(strtotime($data['FinishDate']) < time())
					{
						$result[] = array('flag' => FALSE,'domainName' => $data['DomainName'],'msg' => \common\Lang::create('transmsg')->getMsg('610005'));
						continue;
					}
					if($data['Buyer'])
					{
						$result[] = array('flag' => FALSE,'domainName' => $data['DomainName'],
							'id' => $data['AuditListId'],'msg' => \common\Lang::create('transmsg')->getMsg('610006'));
						\core\Log::write(
							"FALSE,CancelTrans,Have Bider,$enameId,$id," . $data['DomainName'] . ',' . $data['Buyer'] .
								 ',' . $data['AuditListId'], 'trans', 'seller');
					}
					elseif($TDAsdk->cancelTransByIds($enameId, $id, $statusConf['delqueue'][0], 
						$statusConf['trading'][0], $checkBid))
					{
							$result[] = array('flag' => TRUE,'domainName' => $data['DomainName'],'msg' => \common\Lang::create('transmsg')->getMsg('610007'));
							$flag = TRUE;
					}
					else
					{
						$result[] = array('flag' => FALSE,'domainName' => $data['DomainName'],'msg' => \common\Lang::create('transmsg')->getMsg('610009'));
						\core\Log::write(
							"FALSE,CancelTrans,Set TransStatus To Del,$enameId,$id" . ',' . $data['DomainName'], 'trans', 
							'seller');
					}
				}
				else
				{
					$info = $TDAsdk->getAuctionInfoByAuditListId($id);
					if($info)
					{
						$result[] = array('flag' => FALSE,'domainName' => $info['DomainName'],'msg' =>  \common\Lang::create('transmsg')->getMsg('610010'));
					}
					else
					{
						$result[] = array('flag' => FALSE,'domainName' => '未知','msg' => \common\Lang::create('transmsg')->getMsg('610011'));
					}
				}
			}
		}
		return array('data' => $result,'flag' => $flag);
	}

	/**
	 * 竞价/一口价下架操作
	 * 
	 * @param int $auditListId        	
	 * @param int $enameId        	
	 * @throws \Exception
	 * @return multitype:boolean unknown
	 */
	public function cancelTrans($auditListId, $enameId)
	{
		// 验证成功后进行下架操作
		$transDeliveryStatus = $this->conf->trans_delivery_status->toArray();
		$transTransType = $this->conf->trans_transtype->toArray();
		
		$TDAsdk = new \models\trans\DomainAuctionMod();
		$Tlib = new \lib\trans\trans\TransLib();
		
		$sellerCanelInfo = $TDAsdk->getSellerCanel($auditListId, $enameId);
		if(!$sellerCanelInfo)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610012'),610012);
		}
		
		if($sellerCanelInfo['TransStatus'] != $transDeliveryStatus['trading'][0])
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610013'),610013);
		}
		
		// 抢滩域名不能取消交易
		if($sellerCanelInfo['TransTopic'] == 8)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610014'),610014);
		}
		
		$pFinance = new \interfaces\trans\Finance($sellerCanelInfo['Seller']);
		if($sellerCanelInfo['BidCount'] > 0)
		{
			$message = $this->cancelHasBid($enameId, $auditListId, $sellerCanelInfo);
		}
		else
		{
			$message = $this->cancelHasNotBid($enameId, $auditListId, $sellerCanelInfo);
		}
		
		// 若在redis，则删除redis中的数据
		$redis = new \lib\trans\trans\TransRedisLib();
		$redis->doRedisSellerCancel($auditListId, $sellerCanelInfo['TransTopic']);
		
		// 检查是否是白金域名一口价
		if($sellerCanelInfo['TransType'] == $transTransType['buynow'][0])
		{
			$TTDsdk = new \models\trans\TransTopDomainMod();
			$topId = $TTDsdk->getTopBuyNowId($auditListId, $enameId);
			\core\Log::write("SellerCancel,cancelTopBuyNow,$auditListId|$enameId|$topId", 'trans', 'seller');
			if($topId)
			{
				// 设置白金一口价结束
				$TTDsdk->cancelTopBuyNow($topId);
				// 删除白金首页一口价redis
				$TTsdk = new \models\trans\redis\TransTopDomain();
				$TTsdk->delTopBuynowList();
			}
		}
		
		// 论坛店铺推荐域名，信息更新队列redis
		if($sellerCanelInfo['IsShopRecommend'])
		{
			$shopRedis = new \lib\trans\shop\ShopRedisLib();
			$shopRedis->setShopDomainQueue(intval($enameId));
		}
		return array('flag' => true,'code' => $message['code'],'msg' => $message['msg']);
	}

	/**
	 * 询价下架,包括单个和批量
	 * 
	 * @param unknown $ids        	
	 * @param unknown $enameId        	
	 * @throws Exception
	 * @return boolean
	 */
	public function cancelInquiryTrans($ids, $enameId)
	{
		$inquiryStatusConfig = $this->conf->inquiry_status->toArray();
		$inquiryOnsaleStatus = $inquiryStatusConfig['onsale'][0];
		$inquiryEndsaleStatus = $inquiryStatusConfig['endsale'][0];
		
		$inquiryLib = new \lib\trans\trans\InquirySqlLib();
		if(is_array($ids))
		{
			$flag = true;
			foreach($ids as $k => $v)
			{
				$rs = $inquiryLib->inquiryCanelSql($enameId, $v, $inquiryOnsaleStatus, $inquiryEndsaleStatus, true);
				if($rs['flag'] == false)
				{
					$flag = false;
				}
				$cancelRs[] = $rs;
			}
			return array('data' => $cancelRs,'flag' => $flag);
		}
		else
		{
			if($inquiryLib->inquiryCanelSql($enameId, $ids, $inquiryOnsaleStatus, $inquiryEndsaleStatus))
			{
				return array('flag' => true,'msg' => \common\Lang::create('transmsg')->getMsg('610015'),'code' => 610015);
			}
			else
			{
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610001'),610001);
			}
		}
	}
	// 取消有人出价
	public function cancelHasBid($enameId, $auditListId, $sellerCanelInfo)
	{
		// 加载配置
		$transTransType = $this->conf->trans_transtype->toArray();
		// 判断交易类型不存在保留竞价
		return $this->cancelOther($enameId, $auditListId, $sellerCanelInfo);
	}

	/**
	 * 取消有人出价且交易类型不是保留竞价
	 *
	 * @param unknown $enameId        	
	 * @param unknown $auditListId        	
	 * @param unknown $sellerCanelInfo        	
	 * @throws \Exception
	 * @return string
	 */
	public function cancelOther($enameId, $auditListId, $sellerCanelInfo)
	{
		// 加载配置
		$transDeliveryStatus = $this->conf->trans_delivery_status->toArray();
		$transDomainInEname = $this->conf->trans_domain_in_ename->toArray();
		$transDomainMyStatus = $this->conf->trans_domain_my_status->toArray();
		$typeConf = $this->financeConf->type->toArray();
		$moneyTypeConf = $this->financeConf->moneyType->toArray();
		$TDAsdk = new \models\trans\DomainAuctionMod();
		$Tlib = new \lib\trans\trans\TransLib();
		$pFinance = new \interfaces\trans\Finance($sellerCanelInfo['Seller']);
		
		$financeType = $Tlib->FinanceTypeNum($sellerCanelInfo['TransType'], $sellerCanelInfo['TransTopic']); // get trade finance type
		$SellerAbandonOrderId = $pFinance->addOrder($sellerCanelInfo['DomainName'], $typeConf['weiYueJin'], 
			$Tlib->createSellerAbandonMoney($sellerCanelInfo['BidPrice']), $sellerCanelInfo['Buyer'], 
			$sellerCanelInfo['SellerOrderId']);
		if($SellerAbandonOrderId) // seller abandon orderid
		{
			// 设置出价记录交易结束的相关信息
			$Tlib->setAuctionFinish($auditListId, $sellerCanelInfo['DomainName'], $sellerCanelInfo['Buyer'], 
				$sellerCanelInfo['NickName'], $sellerCanelInfo['Seller'], $sellerCanelInfo['BidPrice'], 
				$sellerCanelInfo['TransType'], $sellerCanelInfo['SimpleDec']);
			
			if(!$Tlib->setTransStatusLib($auditListId, $TDAsdk, $transDeliveryStatus['sellerabandon'][0]))
			{
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610016'),610016);
			}
			// 判断域名是否在我司
			$transInfo = $TDAsdk->checkInEname($auditListId);
			// 域名在易名
			if($transInfo['IsDomainInEname'] == $transDomainInEname['domain_inEname'][0])
			{
				// 取消域名冻结状态
				$domains = new \interfaces\trans\Domains();
				$rs = $domains->setDomainMyStatus($transInfo['DomainName'], $transDomainMyStatus['down'][0]);
				if(!$rs['result'])
				{
					\core\Log::write("cancelTrans,$auditListId|$enameId,卖家违约，设置域名下架解锁失败", 'trans', 'seller');
					throw new \Exception(\common\Lang::create('transmsg')->getMsg('610017'),610017);
				}
			}
			// 取消买家出价保证金
			$pFinance->canelOrder($sellerCanelInfo['BuyerOrderId'], $sellerCanelInfo['Buyer']);
			// 确认卖家违约金
			$pFinance->confirmOrder($SellerAbandonOrderId, $moneyTypeConf['unwithdrawal'], $sellerCanelInfo['Buyer']); // confirm to buyer
			                                                                                                           // 设置卖家违约金订单
			$TDAsdk->setSellerAbandon($auditListId, $sellerCanelInfo['Seller'], $SellerAbandonOrderId); // set SellerAbandonOrderId
			
			if(!$Tlib->doComment($sellerCanelInfo['Buyer'], $sellerCanelInfo['Seller'], $sellerCanelInfo['AuditListId'], 
				$transDeliveryStatus['sellerabandon'][0], $sellerCanelInfo['DomainName'], $sellerCanelInfo['BidPrice']))
			{
				\core\Log::write("cancelTrans,$auditListId|$enameId,卖家违约，插入评价表失败", 'trans', 'seller');
			}
			
			$message = \common\Lang::create('transmsg')->getMsg('610018');
		}
		else
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610019'),610019);
		}
		
		return array('code' => 610018,'msg' => $message);
	}

	/**
	 * 取消没有人出价的域名
	 *
	 * @param unknown $enameId        	
	 * @param unknown $auditListId        	
	 * @param unknown $sellerCanelInfo        	
	 * @throws \Exception
	 * @return string
	 */
	public function cancelHasNotBid($enameId, $auditListId, $sellerCanelInfo)
	{
		// 加载配置
		$transDomainMyStatus = $this->conf->trans_domain_my_status->toArray();
		$transTransStatus = $this->conf->trans_status->toArray();
		$transDomainInEname = $this->conf->trans_domain_in_ename->toArray();
		
		$TDAsdk = new \models\trans\DomainAuctionMod();
		$Tlib = new \lib\trans\trans\TransLib();
		// 设置出价记录交易结束的相关信息
		$Tlib->setAuctionFinish($auditListId, $sellerCanelInfo['DomainName'], $sellerCanelInfo['Buyer'], 
			$sellerCanelInfo['NickName'], $sellerCanelInfo['Seller'], $sellerCanelInfo['BidPrice'], 
			$sellerCanelInfo['TransType'], $sellerCanelInfo['SimpleDec']);
		if(($sellerCanelInfo['IsDomainInEname'] == $transDomainInEname['domain_notinEname'][0]) &&
			 $sellerCanelInfo['SellerOrderId']) // domain不在我司的，取消卖家订单
		{
			$pFinance = new \interfaces\trans\Finance($enameId);
			$rs = $pFinance->canelOrder($sellerCanelInfo['SellerOrderId'], $enameId);
			if($rs)
			{
				\core\Log::write("$auditListId|$enameId,取消交易成功,域名不在我司,退还保证金成功", 'trans', 'seller');
			}
			else
			{
				\core\Log::write("$auditListId,$enameId,取消交易失败,域名不在我司,退还保证金失败", 'trans', 'seller');
			}
		}
		else
		{
			// 取消域名冻结状态
			$domains = new \interfaces\trans\Domains();
			$rs = $domains->setDomainMyStatus($sellerCanelInfo['DomainName'], $transDomainMyStatus['down'][0]);
			if(!$rs['result'])
			{
				\core\Log::write("$auditListId|$enameId,卖家违约，设置域名下架解锁失败", 'trans', 'seller');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610017'),610017);
			}
		}
		if(!$TDAsdk->setSellerCanel($auditListId, $enameId, $transTransStatus['sellercanel'][0]))
		{
			\core\Log::write("$auditListId|$enameId,取消交易失败,设置数据库失败", 'trans', 'seller');
		}
		$message = \common\Lang::create('transmsg')->getMsg('610020');
		
		return array('code' => 610020,'msg' => $message);
	}
}
?>
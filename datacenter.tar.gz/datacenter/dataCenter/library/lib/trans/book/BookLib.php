<?php
namespace lib\trans\book;

class BookLib
{

	private $conf;

	private $financeConf;

	public function __construct()
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'book');
		$this->financeConf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
	}

	/**
	 * 获取比较的时间
	 *
	 * @return string
	 */
	public function getCmpTime()
	{
		$today = date('Y-m-d');
		$deadTime = $this->conf->book_dead_time;
		$timeFlag = strtotime($today . " " . $deadTime);
		$now = time();
		if($now > $timeFlag)
		{
			// 超过今天晚上十点，不能预订明天的过期域名
			$cmpTime = date("Y-m-d", strtotime("+1 day", $now));
		}
		else
		{
			$cmpTime = date("Y-m-d");
		}
		return $cmpTime . "  00:00:00";
	}

	/**
	 * 给搜索条件赋予默认值
	 * 1:英文国内 2:英文国际	3:中文国内	4:中文国际
	 *
	 * @param int $domainType        	
	 * @param Object $data        	
	 */
	public function checkSearchData($domainType, $data)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'book');
		if(!empty($data->pos))
		{
			$data->pos = explode(',', $data->pos);
		}
		if(empty($data->tld))
		{
			if($domainType == 1)
			{
				$data->tld = array('1','2');
			}
			elseif($domainType == 2)
			{
				$data->tld = array('3','4');
			}
		}
		else
		{
			$data->tld = explode(',', $data->tld);
		}
		
		$data->num = $data->num? (($data->num > $this->conf->default_maxnum)? $this->conf->default_maxnum :$data->num) :$this->conf->default_getnum;
		
		if(in_array($data->ordertype, array(1,2,3,4)) == false)
		{
			$data->ordertype = 2;
		}
		
		if(empty($data->lengthstart))
		{
			$data->lengthstart = 1;
		}
		
		if(empty($data->lengthend))
		{
			$data->lengthend = 70;
		}
	}

	/**
	 * 获取搜索参数
	 *
	 * @param int $domainType        	
	 * @param Object $data        	
	 * @return multitype:number string unknown Ambigous <string, multitype:> Ambigous <number, multitype:> Ambigous <multitype:number , multitype:unknown > Ambigous <number, unknown, multitype:unknown >
	 */
	public function getSearchParam($domainType, $data)
	{
		$this->checkSearchData($domainType, $data);
		
		$keyWord = trim($data->keyword); // 关键字
		$pos = $data->pos? $data->pos :array(); // 关键字位置（开头/结尾）
		$unkeyWord = trim($data->unkeyword); // 排除关键字
		$lengthStart = $data->lengthstart; // 域名长度范围
		$lengthEnd = $data->lengthend;
		$tldArr = $data->tld? $data->tld :array(); // 后缀
		$type = $data->type? $data->type :0; // 分类
		$delDay = $data->delday; // 删除日期
		$orderType = $data->ordertype; // 排序方式
		$p = $data->p? $data->p :1; // 当前显示第几页的内容
		$pageSize = $data->num; // 每页显示个数
		$offset = ($p - 1) * $pageSize;
		// 关键字位置
		if(in_array(1, $pos) && in_array(2, $pos))
		{
			$position = 4; // 包含
		}
		elseif(in_array(1, $pos))
		{
			$position = 2; // 开头
		}
		elseif(in_array(2, $pos))
		{
			$position = 3; // 结尾
		}
		else
		{
			$position = 1; // 任意位置
		}
		// 后缀
		if($domainType == 1)
		{
			if(in_array(2, $tldArr) && in_array(24, $tldArr))
			{
				$tldArr[] = 6;
				$tldArr[] = 26;
			}
			if(in_array(2, $tldArr))
			{
				$tldArr[] = 6;
			}
			elseif(in_array(24, $tldArr))
			{
				$tldArr[] = 26;
			}
		}
		
		// 分类
		$pDomainLib = new \lib\trans\common\PublicDomainLib();
		$sysGroup = $pDomainLib->getSysGroup($type);
		$sysGroupOne = $sysGroup['sysGroupOne'];
		$sysGroupTwo = $sysGroup['sysGroupTwo'];
		$domainLen = $sysGroup['domainLen'];
		// 长度
		if($lengthStart > $lengthEnd)
		{
			$lengthRange = array(1,70);
		}
		else
		{
			$lengthRange = array($lengthStart,$lengthEnd);
		}
		if(!empty($delDay))
		{
			$delDay = explode(',', $delDay);
			foreach($delDay as $k => $v)
			{
				$delDay[$k] = "'" . $v . "'";
			}
		}
		return array('keyWord' => $keyWord,'unkeyWord' => $unkeyWord,'position' => $position,'tldArr' => $tldArr,
			'delDay' => $delDay,'sysGroupOne' => $sysGroupOne,'sysGroupTwo' => $sysGroupTwo,'domainLen' => $domainLen,
			'lengthRange' => $lengthRange,'offset' => $offset,'pageSize' => $pageSize,'orderType' => $orderType,
			'p' => $p);
	}

	/**
	 * 获取预订域名
	 *
	 * @param int $enameId        	
	 * @param int $status        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getBookTransByEnameId($enameId, $status)
	{
		$domainBookMod = new \models\trans\ExpiredDomainScheduledMod();
		return $domainBookMod->getBookTransByEnameId($enameId, $status);
	}

	/**
	 * 预订竞价列表
	 *
	 * @param int $userBookNum        	
	 * @param int $perPage        	
	 * @param int $perNum        	
	 * @return multitype:boolean string
	 */
	public function getBookTransListLimit($userBookNum, $perPage, $perNum)
	{
		// 取用户预订竞价列表
		if($userBookNum)
		{
			$edageFlag = $userBookNum - ($userBookNum % $perNum); // 临界点
			if($perPage < $edageFlag)
			{
				$userLimit = $perPage . ", " . $perNum;
				$notUserLimit = false;
			}
			elseif($perPage == $edageFlag)
			{
				$userLimit = $perPage . ", " . ($userBookNum - $perPage);
				$notUserLimit = 0 . ", " . ($perPage + $perNum - $userBookNum);
			}
			elseif($perPage > $edageFlag)
			{
				$userLimit = false;
				$notUserLimit = ($perPage - $userBookNum) . ", " . $perNum;
			}
		}
		else
		{
			$userLimit = false;
			$notUserLimit = $perPage . ", " . $perNum;
		}
		
		return array('userLimit' => $userLimit,'notUserLimit' => $notUserLimit);
	}

	/**
	 * 格式化来自textarea的字符串
	 *
	 * @param string $textarea        	
	 */
	public function formatDomainArray($textarea)
	{
		$domain = array();
		$array = explode(",", $textarea);
		foreach($array as $v)
		{
			$v = trim($v);
			if($v && $this->isOkDomain($v))
			{
				$domain[] = $v;
			}
		}
		$domain = array_unique($domain);
		return $domain;
	}

	/**
	 * 判断是否是一个合格的域名,支持中文域名
	 *
	 * @param string $domain        	
	 * @return boolean
	 */
	public function isOkDomain($domain)
	{
		$ok = FALSE;
		if(preg_match("/^([\x{4e00}-\x{9fa5}]|[a-zA-Z0-9-])+(\.[a-z]{2,4})?\.([a-z]|[\x{4e00}-\x{9fa5}]){2,4}$/ui", 
			$domain))
		{
			if(substr($domain, 0, 1) != '-' && stripos($domain, '--') === FALSE) // 去掉-开头的域名
			{
				$ok = true;
			}
		}
		return $ok;
	}

	/**
	 * 判断域名是否的后缀是否是.cn、.中国、.公司、.网络的如果不是，则过滤
	 *
	 * @param array $domainNames        	
	 * @param string $flag        	
	 * @return multitype:Ambigous <multitype:, unknown> multitype:multitype:string unknown
	 */
	public function getEffectDomain($domainNames, $flag = FALSE)
	{
		$success = $error = array();
		if($domainNames)
		{
			foreach($domainNames as $v)
			{
				$v = \strtolower($v);
				if(!$this->checkIsTopLevel($v))
				{
					$error[] = $flag? array($v,'域名格式错误') :array('domain' => $v,'msg' => '域名格式错误');
					continue;
				}
				$domainClass = $this->getDomainClassName($v);
				if($domainClass == FALSE || $this->isOkDomain($v) == FALSE)
					$error[] = $flag? array($v,'此域名不支持预订') :array('domain' => $v,'msg' => '此域名不支持预订');
				else
					$success[] = $v;
			}
		}
		return array($success,$error);
	}

	/**
	 * 判断是否是中文域名 判断是否有汉字
	 *
	 * @param string $domain        	
	 * @return boolean
	 */
	public function isCnDomain($domain)
	{
		if(preg_match("/[\x{4e00}-\x{9fa5}]+/u", $domain))
		{
			return TRUE;
		}
		return FALSE;
	}

	/**
	 * 获取域名最后一级后缀
	 *
	 * @param string $domain        	
	 * @return string
	 */
	public function getDomainClass($domain)
	{
		$domainArr = explode('.', $domain);
		return strtoupper($domainArr[count($domainArr) - 1]);
	}

	/**
	 * 获取域名类型
	 *
	 * @param string $domain        	
	 * @return boolean
	 */
	public function getDomainClassName($domain)
	{
		$effectDomainClass = $this->conf->effect_domain_class->toArray();
		$domLtd = $this->getDomainClass($domain);
		if(!in_array($domLtd, $effectDomainClass) ||
			 (($domLtd == 'COM' || $domLtd == 'NET') && $this->isCnDomain($domain)))
			return FALSE;
		return TRUE;
	}

	/**
	 * 判断域名是否为顶级域名
	 *
	 * @param string $domain        	
	 * @return boolean
	 */
	public function checkIsTopLevel($domain)
	{
		$t = explode('.', $domain);
		$count = count($t);
		if($count == 2)
			return true; // 此处不做后缀合法性检测
		if($count == 3)
		{
			$suffix = $t[1] . '.' . $t[2];
			$top3arr = $this->conf->valid_level3_topdomainltd->toArray();
			if(in_array($suffix, $top3arr))
				return true;
		}
		return false;
	}

	/**
	 * 将域名分类
	 *
	 * @param array $domainNames        	
	 * @return multitype:unknown Ambigous <multitype:, unknown> multitype:unknown
	 */
	public function categoryDomains($domainNames)
	{
		$pLib = new \lib\trans\common\PublicLib();
		$domainClassConf = $this->conf->domain_class->toArray();
		$enDomestic = $enInternational = $cnDomestic = $cnInternational = array();
		foreach($domainNames as $domainName)
		{
			$domainClass = $pLib->getDomainClassName($domainName);
			switch($domainClass)
			{
				case $domainClassConf['en_domestic'][0]:
					$enDomestic[] = \lib\trans\common\PublicDomainLib::replaceL($domainName);
					break;
				case $domainClassConf['en_international'][0]:
					$enInternational[] = \lib\trans\common\PublicDomainLib::replaceL($domainName);
					break;
				case $domainClassConf['cn_domestic'][0]:
					$cnDomestic[] = \lib\trans\common\PublicDomainLib::replaceL($domainName);
					break;
				case $domainClassConf['cn_international'][0]:
					$cnInternational[] = \lib\trans\common\PublicDomainLib::replaceL($domainName);
					break;
				default:
					\core\Log::write('BookDomain,categoryDomainsFalse' . $domainName . ',bookdomain', 'trans', 'book');
			}
		}
		$data = array($enDomestic,$enInternational,$cnDomestic,$cnInternational);
		return $data;
	}

	/**
	 * 判断该域名是否第二天删除
	 *
	 * @param obj|bool $model        	
	 * @param string $domain        	
	 * @return array
	 */
	private function checkDayDomain($model = false, $domain)
	{
		$flag = true;
		if(false == $model)
		{
			return $flag;
		}
		$deadTime = $this->conf->book_dead_time;
		$nowTime = date('H:i:s');
		$nowDate = date('Y-m-d') . ' 00:00:00';
		if($nowTime > $deadTime)
		{
			$endDate = date('Y-m-d', strtotime('+1 days' . $nowDate)) . ' 00:00:00';
			$nowDate = array($nowDate,$endDate);
		}
		// 23点之后查询当天及第二天删除，否则查询当天删除的域名 注意：model运用了2个可预订表
		if($model->checkIsExitDomain($domain, $nowDate))
		{
			$flag = false;
		}
		
		return $flag;
	}

	/**
	 * 检查英文国内域名
	 *
	 * @param array $domainNames        	
	 * @return multitype:multitype:multitype:string unknown Ambigous <multitype:multitype: , number, unknown>
	 */
	public function checkEnDomestic($domainNames)
	{
		$bookMarginConf = $this->conf->book_domain_margin;
		$TEDsdk = new \models\trans\ExpiredDomainMod();
		$cmpTime = $this->getCmpTime();
		$data = array('domain' => array(),'error' => array(),'other' => array());
		$error = array();
		$flag = true;
		if($domainNames)
		{
			$k = 0;
			$i = 0;
			foreach($domainNames as $domainName)
			{
				$domainInfo = $TEDsdk->getBookDomainWithCmpTime($domainName, $cmpTime);
				if($domainInfo)
				{
					$domainInfo['DelDate'] = date('Y-m-d', strtotime($domainInfo['DelDate']));
					$data['domain'][$i] = $domainInfo;
					$data['domain'][$i]['BookPrice'] = $bookMarginConf['en_domestic'];
					$i ++;
				}
				else
				{
					// 判断是否超过晚上23点及是否当天删除域名
					$flag = $this->checkDayDomain($TEDsdk, $domainName);
					if($flag)
					{
						$data['error'][] = $domainName;
						$data['other'][$k]['DomainName'] = $domainName;
						$data['other'][$k]['DelDate'] = '未确定';
						$data['other'][$k]['BookPrice'] = 0;
						$k ++;
					}
					else
					{
						$error[] = array('domain' => $domainName,'msg' => '已经超过预订时间');
					}
				}
			}
		}
		return array($data,$error);
	}

	/**
	 * 检查中文国内域名
	 *
	 * @param array $domainNames        	
	 * @return multitype:multitype:multitype:string unknown Ambigous <multitype:multitype: , number, string, multitype:, boolean, unknown>
	 */
	public function checkCnDomestic($domainNames)
	{
		$TEDIsdk = new \models\trans\ExpiredDomainMod();
		$pLib = new \lib\trans\common\PublicLib();
		$cmpTime = $this->getCmpTime();
		$data = array('domain' => array(),'error' => array(),'other' => array());
		$error = array();
		$flag = true;
		if($domainNames)
		{
			$k = 0;
			foreach($domainNames as $domainName)
			{
				$domainInfo = $TEDIsdk->getBookDomainWithCmpTime($domainName, $cmpTime);
				if($domainInfo)
				{
					$domainInfo['DelDate'] = date('Y-m-d', strtotime($domainInfo['DelDate']));
					$data['domain'][] = $domainInfo;
				}
				else
				{
					// 判断是否超过晚上23点及是否当天删除域名
					$flag = $this->checkDayDomain($TEDIsdk, $domainName);
					if($flag)
					{
						$data['error'][] = $domainName;
						$data['other'][$k]['DomainName'] = $domainName;
						$data['other'][$k]['DelDate'] = '未确定';
						$data['other'][$k]['BookPrice'] = 0;
						$k ++;
					}
					else
					{
						$error[] = array('domain' => $domainName,'msg' => '已经超过预订时间');
					}
				}
			}
		}
		return array($data,$error);
	}

	/**
	 * 检查英文国际域名
	 *
	 * @param array $domainNames        	
	 * @return multitype:multitype:multitype:string unknown Ambigous <multitype:multitype: , number, unknown>
	 */
	public function checkEnInternational($domainNames)
	{
		$bookMarginConf = $this->conf->book_domain_margin;
		$TEDEsdk = new \models\trans\ExpiredDomainEnMod();
		$cmpTime = $this->getCmpTime();
		$data = array('domain' => array(),'error' => array(),'other' => array());
		$error = array();
		$flag = true;
		if($domainNames)
		{
			$k = 0;
			$i = 0;
			foreach($domainNames as $domainName)
			{
				$domainInfo = $TEDEsdk->getBookDomainWithCmpTime($domainName, $cmpTime);
				if($domainInfo)
				{
					$domainInfo['DelDate'] = date('Y-m-d', strtotime($domainInfo['DelDate']));
					$data['domain'][$i] = $domainInfo;
					$data['domain'][$i]['BookPrice'] = $bookMarginConf['en_international'];
					$i ++;
				}
				else
				{
					// 判断是否超过晚上23点及是否当天删除域名
					$flag = $this->checkDayDomain($TEDEsdk, $domainName);
					if($flag)
					{
						$data['error'][] = $domainName;
						$data['other'][$k]['DomainName'] = $domainName;
						$data['other'][$k]['DelDate'] = '未确定';
						$data['other'][$k]['BookPrice'] = 0;
						$k ++;
					}
					else
					{
						$error[] = array('domain' => $domainName,'msg' => '已经超过预订时间');
					}
				}
			}
		}
		return array($data,$error);
	}

	/**
	 * 获取未注册的域名
	 *
	 * @param string $domains        	
	 * @return multitype:Ambigous <multitype:, unknown> multitype:multitype:unknown number
	 */
	public function getUnRegDomains($domains)
	{
		$success = $error = array();
		if($domains)
		{
			$pDomainLib = new \lib\trans\common\PublicDomainLib();
			$domainInterFaces = new \interfaces\trans\Domains();
			foreach($domains as $v)
			{
				$rs = $domainInterFaces->checkIsUnReg($v['DomainName']);
				if($rs['result'] == TRUE)
					$error[] = array('domain' => $v['DomainName'],'msg' => $rs['msg']);
				else
					$success[] = $v;
			}
		}
		return array($success,$error);
	}

	/**
	 * 中文域名分组
	 *
	 * @param string $domains        	
	 * @return Ambigous <multitype:multitype: , unknown>
	 */
	public function classifyCnDomain($domains)
	{
		$bookMarginConf = $this->conf->book_domain_margin;
		$pLib = new \lib\trans\common\PublicLib();
		$data = array('cn' => array(),'other' => array());
		if($domains && is_array($domains))
		{
			foreach($domains as $v)
			{
				if(strtolower($pLib->getDomainClass($v['DomainName'])) == 'cn')
				{
					$v['BookPrice'] = $bookMarginConf['en_domestic'];
					$data['cn'][] = $v;
				}
				else
				{
					$v['BookPrice'] = $bookMarginConf['cn_domestic'];
					$data['other'][] = $v;
				}
			}
		}
		return $data;
	}

	/**
	 * 生成用户Id
	 *
	 * @param int $enameId        	
	 * @return string
	 */
	public function createUserNickName($enameId)
	{
		$temp = mt_rand(0, 10000) . $enameId;
		$userNickName = $this->toBase($temp);
		unset($temp);
		return $userNickName;
	}

	/**
	 * 转换成62进制
	 *
	 * @param int $num        	
	 * @param number $b        	
	 * @return string
	 */
	public function toBase($num, $b = 62)
	{
		$base = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$r = $num % $b;
		$res = $base[$r];
		$q = floor($num / $b);
		while($q)
		{
			$r = $q % $b;
			$q = floor($q / $b);
			$res = $base[$r] . $res;
		}
		return $res;
	}

	/**
	 * 获取预订人数
	 *
	 * @param int $auditListId        	
	 * @return Ambigous <boolean, mixed>
	 */
	public function getBookUserCntById($auditListId)
	{
		$TEDSsdk = new \models\trans\ExpiredDomainScheduledMod();
		return $TEDSsdk->getBookUserCntById($auditListId);
	}

	/**
	 * 返回相应交易页面的数据
	 *
	 * @param Object $data        	
	 * @throws \Exception
	 * @return multitype:multitype:number string boolean NULL unknown Ambigous <\lib\trans\trans\Ambigous, number, unknown> Ambigous <\models\trans\Ambigous, boolean, mixed> Ambigous <boolean, string> Ambigous <string, boolean, \lib\trans\book\Ambigous, \models\trans\Ambigous, mixed> Ambigous <multitype:>
	 */
	public function getTransInfoData($data)
	{
		// 加载配置
		$transStatusConfig = $this->conf->trans_status->toArray();
		$transTopicConf = $this->conf->trans_transtopic->toArray();
		$transTypeConf = $this->conf->trans_transtype->toArray();
		
		// 获取参数
		$auditListId = $data->id;
		$enameId = $data->enameid;
		$isAjax = $data->isajax;
		$info = array();
		
		$TBAsdk = new \models\trans\BookAuctionMod();
		$TBBRsdk = new \models\trans\BookBidRecordMod();
		$TEDSsdk = new \models\trans\ExpiredDomainScheduledMod();
		
		$domainInfo = $TBAsdk->getTransAuctionInfo($auditListId); // 判断是否存在此交易
		if(!$domainInfo)
		{
			throw new \Exception('无此交易或已经结束');
		}
		// 是否是预订竞价
		$isbreakin = 0;
		if($enameId)
		{
			$renshu = $TEDSsdk->getEnameIdIn($enameId, $auditListId);
			$isbreakin = $renshu > 0? 0 :1;
		}
		else
		{
			$isbreakin = 0;
		}
		$isfinish = ((strtotime($domainInfo['FinishDate']) - time()) > 0 &&
			 $domainInfo['TransStatus'] == $transStatusConfig['trading'][0])? false :true;
		// 当前时间
		$nowtime = time();
		// 结束时间
		$endtime = ($domainInfo['TransStatus'] != $transStatusConfig['trading'][0])? 0 :strtotime(
			$domainInfo['FinishDate']);
		// 是否是卖家
		$isseller = ($domainInfo['Seller'] == $enameId)? True :False;
		
		$max = $TBBRsdk->getBidRecordCount($auditListId);
		
		if($enameId)
		{
			$userNickName = $this->getUserNickName($auditListId, $enameId);
		}
		else
		{
			$userNickName = False;
		}
		$pLib = new \lib\trans\common\PublicLib();
		$lefttimes = strtotime($domainInfo['FinishDate']) - time();
		if($domainInfo['TransStatus'] != $transStatusConfig['trading'][0])
		{
			$lefttimes = 0;
		}
		$transCycleStart = date('Y-m-d H:i', strtotime($domainInfo['CreateDate']));
		$transCycleEnd = date('Y-m-d H:i', strtotime($domainInfo['FinishDate']));
		if($domainInfo['Buyer'] > 0)
		{
			$isbuyer = $enameId == $domainInfo['Buyer']? TRUE :FALSE;
		}
		else
		{
			$isbuyer = FALSE;
		}
		
		if($enameId == $domainInfo['Buyer'] && $domainInfo['Buyer'] != 0)
		{
			$isleader = TRUE;
			$agentBidPrice = ($domainInfo['AgentBidPrice'] > 0)? $domainInfo['AgentBidPrice'] :false;
		}
		else
		{
			$isleader = FALSE;
			$agentBidPrice = FALSE;
		}
		// 最低出价
		$info['AgentBidPrice'] = 0;
		if($domainInfo['BidCount'] == 0)
		{
			$lowPrice = intval($domainInfo['BidPrice']);
		}
		elseif($isleader && $domainInfo['AgentBidPrice'] != 0)
		{
			$lowPrice = $this->createAddPrice($domainInfo['AgentBidPrice']);
			$info['AgentBidPrice'] = intval($domainInfo['AgentBidPrice']);
		}
		else
		{
			$lowPrice = $this->createAddPrice($domainInfo['BidPrice']);
		}
		
		// 获取出价保证金金额
		$bLib = new \lib\trans\trans\TransBidPublicLib();
		$deposit = $bLib->createAssMoney($lowPrice, $transTypeConf['booking'][0]);
		$info['deposit'] = $deposit;
		$nickName = '';
		if($domainInfo['NickName'])
		{
			$nickName = $domainInfo['NickName'];
		}
		else
		{
			$nickName = false;
		}
		
		if(!$isAjax)
		{
			$info['id'] = $domainInfo['AuditListId'];
			$info['domainName'] = \lib\trans\common\PublicDomainLib::replaceL($domainInfo['DomainName']);
			$info['simpleDesc'] = $domainInfo['SimpleDec'];
			$info['register'] = '易名中国';
			$info['askingPrice'] = intval($domainInfo['AskingPrice']);
			$info['userNickName'] = $userNickName? $userNickName :'';
			$info['enameId'] = $enameId;
			$info['userName'] = false;
			if(!$userNickName)
			{
				// 昵称
				$bidLib = new \lib\trans\trans\TransBidPublicLib();
				$info['userName'] = $enameId? $bidLib->createUserNickName($auditListId, $enameId) :'';
			}
			$info['tips'] = '';
			if(!$isseller && $enameId && !$isfinish && $isbreakin)
			{
				$info['tips'] = '注意：此域名您未预订，如出价需扣除闯入费50元，无论是否得标该款项均不退还！';
			}
			if($isfinish)
			{
				$info['tips'] = '该交易已经结束';
			}
			$info['transType'] = $transTypeConf['booking'][0];
		}
		// 是否结束
		$info['isFinish'] = $isfinish;
		// 是否闯入
		$info['isbreakin'] = $isbreakin;
		// 预订人数
		$bookUserCnt = $this->getBookUserCntById($auditListId);
		$info['preOrderNum'] = intval($bookUserCnt);
		// 拍卖周期
		$info['transCycleStart'] = $transCycleStart;
		$info['transCycleEnd'] = $transCycleEnd;
		$info['bidPrice'] = (int)($domainInfo['BidPrice']);
		$finishTime = $pLib->NewTimeToDHIS($lefttimes);
		$info['remainTime'] = $lefttimes;
		$info['leftTime'] = $finishTime;
		if($isbuyer)
		{
			$info['nickName'] = '我的出价';
		}
		else
		{
			if($nickName)
			{
				$info['nickName'] = $nickName;
			}
			else
			{
				$info['nickName'] = '暂无人出价';
			}
		}
		$info['bidCount'] = $max;
		$info['addPrice'] = $this->createAddPrice($domainInfo['BidPrice'], TRUE);
		$praiseMod = new \models\trans\PraiseMod();
		$info['praiseCount'] = intval($praiseMod->getPraiseCount($auditListId));
		$info['isPraise'] = false;
		if($enameId)
		{
			$info['isPraise'] = $praiseMod->getPraiseCount($auditListId,$enameId) ? true : false;
		}
		return array('info' => $info);
	}

	/**
	 * 返回加价幅度
	 *
	 * @param int $bidPrice        	
	 * @param bool $one        	
	 * @return number
	 */
	public function createAddPrice($bidPrice, $one = FALSE)
	{
		// 获取配置
		$addPriceValue = $this->conf->trans_addprice->toArray();
		$addPriceKey = array_keys($addPriceValue);
		foreach($addPriceKey as $v)
		{
			if($bidPrice > $v)
			{
				$addPrice = $addPriceValue[(string)($v)];
				break;
			}
		}
		if($one)
		{
			$addPrice = (int)($addPrice);
			return $addPrice;
		}
		$addPrice = (int)($addPrice) + (int)($bidPrice);
		return $addPrice;
	}

	/**
	 * 获得当前用户NickName
	 *
	 * @param int $auditListId        	
	 * @param int $enameId        	
	 * @return Ambigous <\models\trans\Ambigous, boolean, mixed>
	 */
	public function getUserNickName($auditListId, $enameId)
	{
		$TBBRsdk = new \models\trans\BookBidRecordMod();
		$nickName = $TBBRsdk->getNickNameOfRecord($auditListId, $enameId);
		return $nickName;
	}

	/**
	 * 判断是否属于用户的预订域名(expiredDomainScheduledId)
	 *
	 * @param int $enameId        	
	 * @param int $id        	
	 * @return Ambigous <boolean, mixed>
	 */
	public function isYourBookDomain($enameId, $id)
	{
		$TEDSsdk = new \models\trans\ExpiredDomainScheduledMod();
		return $TEDSsdk->isYourBookDomain($enameId, $id);
	}

	/**
	 * 判断是否可以取消预订
	 *
	 * @param int $id        	
	 * @return boolean
	 */
	public function canCancelBook($id)
	{
		// 加载配置
		$bookStatus = $this->conf->book_domain_status->toArray();
		$TEDSsdk = new \models\trans\ExpiredDomainScheduledMod();
		$status = $TEDSsdk->getStatusById($id);
		if($status != $bookStatus['booked'][0])
		{
			return FALSE;
		}
		return true;
	}

	/**
	 * 是否超过可以取消预订的结束时间（当天晚上11点之前可以取消明天的过期域名预订）
	 *
	 * @param int $id        	
	 * @return boolean
	 */
	public function isOverCancelTime($id)
	{
		// 计算出删除日期前一天晚上11点
		$deadTime = $this->conf->book_dead_time;
		$TEDSsdk = new \models\trans\ExpiredDomainScheduledMod();
		$delDate = $TEDSsdk->getDelDateById($id);
		$delTime = date("Y-m-d", strtotime("-1 day", strtotime($delDate))) . ' ' . $deadTime;
		$now = date("Y-m-d H:i:s");
		if($now > $delTime)
		{
			return true;
		}
		return false;
	}

	/**
	 * 取消预订
	 *
	 * @param int $id        	
	 * @param int $enameId        	
	 * @throws \Exception
	 * @return boolean
	 */
	public function cancelBook($id, $enameId)
	{
		// 加载配置
		$book_deldate = $this->conf->predeldate;
		$TEDSsdk = new \models\trans\ExpiredDomainScheduledMod();
		$bookOrderId = $TEDSsdk->getBookOrderById($id);
		$delDate = $TEDSsdk->getDelDateById($id);
		if($delDate != $book_deldate)
		{
			$pFinanceLib = new \interfaces\trans\Finance($enameId);
			$cancelRs = $pFinanceLib->canelOrder($bookOrderId, $enameId);
			if(!$cancelRs)
			{
				\core\Log::write("用户ID" . $enameId . "预订主表ID" . $id . "解冻预订保证金失败", 'trans', 'cancelbook');
				throw new \Exception("系统出错，请联系客服");
			}
		}
		
		\core\Log::write("用户ID" . $enameId . "预订主表ID" . $id . "取消预订" . "解冻预订保证金成功", 'trans', 'cancelbook');
		$rs = $TEDSsdk->delBookDomain($id);
		if(!$rs)
		{
			\core\Log::write("预订表主表ID" . $id . "用户" . $enameId . '取消预订域名失败（删除预订）', 'trans', 'cancelbook');
			return FALSE;
		}
		return true;
	}

	/**
	 * 英文国内域名预订
	 *
	 * @param unknown $enameId        	
	 * @param unknown $enDomesticIds        	
	 * @param unknown $nickName        	
	 * @return Ambigous <multitype:multitype: , \lib\trans\book\Ambigous, multitype:string unknown , multitype:string number >
	 */
	public function bookEnDomestic($enameId, $enDomesticIds, $nickName)
	{
		// 获取参数
		$domainClassConf = $this->conf->domain_class->toArray();
		\core\Log::write("bookEnDomestic,getEnDomesticIds" . json_encode($enDomesticIds) . ',' . $enameId, 'trans', 
			'booken');
		$bookEnDomestic = array('success' => array(),'error' => array());
		// 英文国内域名预订
		if($enDomesticIds)
		{
			$enDomestic = $this->getEnDomesticDetailByIds($enDomesticIds);
			if($enDomestic)
			{
				\core\Log::write(
					"bookEnDomestic,==============Start===========," . json_encode($enDomesticIds) . ',' . $enameId, 
					'trans', 'booken');
				$bookEnDomestic = $this->bookDomainLib($enameId, $enDomestic, $domainClassConf['en_domestic'][0], 
					$nickName);
				\core\Log::write(
					"bookEnDomestic,==============End===========," . json_encode($enDomesticIds) . ',' . $enameId, 
					'trans', 'booken');
			}
			else
			{
				\core\Log::write("bookEnDomestic,NotValidEnDomestic," . json_encode($enDomesticIds) . ',' . $enameId, 
					'trans', 'booken');
			}
		}
		else
		{
			\core\Log::write("bookEnDomestic,getEnDomesticIdsFalse," . json_encode($enDomesticIds) . ',' . $enameId, 
				'trans', 'booken');
		}
		unset($domainClassConf);
		return $bookEnDomestic;
	}

	/**
	 * 获取英文国内域名详细信息
	 *
	 * @param array $domainIds        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getEnDomesticDetailByIds($domainIds)
	{
		$TEDsdk = new \models\trans\ExpiredDomainMod();
		$domainIdStr = implode(',', $domainIds);
		$cmpTime = $this->getCmpTime();
		
		$domain = $TEDsdk->getDomainDetailById($domainIdStr, $cmpTime);
		return $domain;
	}

	/**
	 * 域名预订
	 *
	 * @param int $enameId        	
	 * @param array $domains        	
	 * @param int $domainClass        	
	 * @param string $nickName        	
	 * @return Ambigous <multitype:multitype: , multitype:string unknown , multitype:string number >
	 */
	public function bookDomainLib($enameId, $domains, $domainClass, $nickName)
	{
		// 加载配置
		$book_deldate = $this->conf->predeldate;
		$bookStatus = $this->conf->book_domain_status->toArray();
		$status = array($bookStatus['booked'][0],$bookStatus['trading'][0],$bookStatus['waitToPay'][0]);
		$status = implode(', ', $status);
		
		$TEDSsdk = new \models\trans\ExpiredDomainScheduledMod();
		$rs = array('success' => array(),'error' => array());
		foreach($domains as $v)
		{
			// 检查是否已经预订此域名了
			\core\Log::write("BookDomain,CheckHaveBooked," . $v['DomainName'] . ',' . $enameId . ',' . $v['DelDate'], 
				'trans', 'book');
			$delDate = "'" . date('Y-m-d', strtotime($v['DelDate'])) . "', '" . $book_deldate . "'";
			$domainCnt = $TEDSsdk->getBookDomainCnt($enameId, $v['DomainName'], $delDate, $status);
			if($domainCnt)
			{
				\core\Log::write(
					"BookDomain,CheckHaveBookedFalse," . $v['DomainName'] . ',' . $enameId . ',' . $v['DelDate'], 
					'trans', 'book');
				$rs['error'][] = array($v['DomainName'],"您已预订过该域名了");
				continue;
			}
			else
			{
				// 扣除预订保证金
				$bookOrderId = $this->freezMargin($v['DomainName'], $enameId, $domainClass);
				\core\Log::write(
					"BookDomain,FreezeMargin," . $v['DomainName'] . ',' . $enameId . ',' . $v['DelDate'] . ',' .
						 $bookOrderId, 'trans', 'book');
				if(!$bookOrderId)
				{
					\core\Log::write(
						"BookDomain,FreezeMarginFalse," . $v['DomainName'] . ',' . $enameId . ',' . $v['DelDate'], 
						'trans', 'book');
					// 余额不够
					$rs['error'][] = array($v['DomainName'],"余额不够，无法预订");
					continue;
				}
				// 预订中文域名时没有以下这些字段
				if(!isset($v['SysGroupOne']))
				{
					$v['SysGroupOne'] = 0;
				}
				if(!isset($v['SysGroupTwo']))
				{
					$v['SysGroupTwo'] = 0;
				}
				
				// 获取保证金
				$config = $this->getBookFinanceType($v['DomainName'], $domainClass);
				if($config === false)
				{
					\core\Log::write(
						"FALSE,BookDomain,getBookFinanceType," . $v['DomainName'] . ',' . $enameId . ',' . $v['DelDate'] .
							 ',' . $domainClass, 'trans', 'book');
					$rs['error'][] = array($v['DomainName'],"非法域名");
					continue;
				}
				
				\core\Log::write(
					"BookDomain,AddScheduleTable," . $v['DomainName'] . ',' . $enameId . ',' . $v['DelDate'], 'trans', 
					'book');
				$res = $TEDSsdk->bookDomain($v['DomainName'], $enameId, $config['deposit'], $nickName, 
					$v['DomainLength'], $domainClass, $v['DomainLtd'], $v['SysGroupOne'], $v['SysGroupTwo'], 
					$bookOrderId, $v['DelDate']);
				if(!$res)
				{
					\core\Log::write(
						"BookDomain,AddScheduleTableFalse," . $v['DomainName'] . ',' . $enameId . ',' . $v['DelDate'], 
						'trans', 'book');
					// 解冻预订保证金
					$this->cancelMargin($bookOrderId, $enameId);
					$rs['error'][] = array($v['DomainName'],"解冻保证金出错，请联系客服");
				}
				else
				{
					\core\Log::write(
						"BookDomain,AddScheduleTableSuccess," . $v['DomainName'] . ',' . $enameId . ',' . $v['DelDate'], 
						'trans', 'book');
					$rs['success'][] = array($v['DomainName'],"预订成功");
				}
			}
		}
		return $rs;
	}

	/**
	 * 冻结预订保证金
	 *
	 * @param string $domainName        	
	 * @param int $transMargin        	
	 * @param int $domainClass
	 *        	return bool
	 */
	public function freezMargin($domainName, $enameId, $domainClass)
	{
		$config = $this->getBookFinanceType($domainName, $domainClass);
		if($config === false)
		{
			\core\Log::write("FALSE,BookDomain,getBookFinanceType,$domainName,$domainClass", 'trans', 'book');
			return false;
		}
		$financeLib = new \interfaces\trans\Finance($enameId);
		$rs = $financeLib->addOrder($domainName, $config['depositType'], $config['deposit']);
		if($rs == false)
		{
			\core\Log::write("域名" . $domainName . ",用户" . $enameId . ",预订域名冻结预订保证金失败", 'trans', 'book');
		}
		return $rs;
	}

	/**
	 * 获取预订域名的保证金、预订保证金财务类型和预订竞价财务类型
	 *
	 * @param string $domain        	
	 * @param int $domainClass        	
	 * @return Ambigous <boolean, multitype:unknown >
	 */
	public function getBookFinanceType($domain, $domainClass = '')
	{
		// 加载配置
		$domainClassConf = $this->conf->domain_class->toArray();
		$bookMarginConf = $this->conf->book_domain_margin->toArray();
		$financeType = $this->financeConf->type->toArray();
		$pDoaminLib = new \lib\trans\common\PublicDomainLib();
		$tld = strtolower($pDoaminLib->getDomainClass($domain));
		if(!$domainClass)
		{
			$domainClass = $pDoaminLib->getDomainClassName($domain);
		}
		$flag = true;
		switch($domainClass)
		{
			case $domainClassConf['en_domestic'][0]:
				$deposit = $bookMarginConf['en_domestic']; // 预订保证金
				$depositType = $financeType['bookingDeposit']; // 预订保证金
				$auctionType = $financeType['yuDingJingJia']; // 竞价财务类型
				break;
			case $domainClassConf['cn_domestic'][0]:
				if($tld == 'cn')
				{
					$deposit = $bookMarginConf['en_domestic']; // 预订保证金
					$depositType = $financeType['bookingDeposit']; // 预订财务类型
					$auctionType = $financeType['yuDingJingJia']; // 竞价财务类型
				}
				else
				{
					$deposit = $bookMarginConf['cn_domestic']; // 预订保证金
					$depositType = $financeType['bookingDepositCnidn']; // 预订财务类型
					$auctionType = $financeType['yuDingJingJiaCnidn']; // 竞价财务类型
				}
				break;
			case $domainClassConf['en_international'][0]:
				$deposit = $bookMarginConf['en_international']; // 预订保证金
				if($tld == 'com')
				{
					$depositType = $financeType['bookingDepositCom']; // 预订财务类型
					$auctionType = $financeType['yuDingJingJiaCom']; // 竞价财务类型
				}
				elseif($tld == 'net')
				{
					$depositType = $financeType['bookingDepositNet']; // 预订保证金
					$auctionType = $financeType['yuDingJingJiaNet']; // 竞价财务类型
				}
				else
				{
					$flag = false;
				}
				break;
			default:
				$flag = false;
		}
		return $flag? array('deposit' => $deposit,'depositType' => $depositType,'auctionType' => $auctionType) :false;
	}

	/**
	 * 解冻预订保证金
	 *
	 * @param int $orderId        	
	 * @param unknown $enameId        	
	 * @return Ambigous <boolean, number>
	 */
	public function cancelMargin($orderId, $enameId)
	{
		$pFinanceLib = new \interfaces\trans\Finance($enameId);
		$rs = $pFinanceLib->canelOrder($orderId, $enameId);
		if($rs == false)
		{
			\core\Log::write("用户" . $enameId . ",订单" . $orderId . ",解冻预订保证金失败", 'trans', 'book');
		}
		return $rs;
	}

	/**
	 * 获取中文国内域名详细信息
	 *
	 * @param array $domainIds        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getCnDomesticDetailByIds($domainIds)
	{
		$TEDIsdk = new \models\trans\ExpiredDomainMod();
		$domainIdStr = implode(',', $domainIds);
		$cmpTime = $this->getCmpTime();
		$domain = $TEDIsdk->getDomainDetailById($domainIdStr, $cmpTime);
		return $domain;
	}

	/**
	 * 中文国内域名预订
	 *
	 * @param int $enameId        	
	 * @param array $cnDomesticIds        	
	 * @return Ambigous <multitype:multitype: , multitype:string unknown , multitype:string number >
	 */
	public function bookCnDomestic($enameId, $cnDomesticIds, $nickName)
	{
		// 加载配置
		$domainClassConf = $this->conf->domain_class->toArray();
		\core\Log::write("bookCnDomestic,getCnDomesticIds," . json_encode($cnDomesticIds) . ',' . $enameId, 'trans', 
			'book');
		$bookCnDomestic = array('success' => array(),'error' => array());
		// 英文国内域名预订
		if($cnDomesticIds)
		{
			$cnDomestic = $this->getCnDomesticDetailByIds($cnDomesticIds);
			if($cnDomestic)
			{
				\core\Log::write(
					"bookCnDomestic,==============Start===========," . json_encode($cnDomesticIds) . ',' . $enameId, 
					'trans', 'bookcn');
				$bookCnDomestic = $this->bookDomainLib($enameId, $cnDomestic, $domainClassConf['cn_domestic'][0], 
					$nickName);
				\core\Log::write(
					"bookCnDomestic,==============End===========," . json_encode($cnDomesticIds) . ',' . $enameId, 
					'trans', 'bookcn');
			}
			else
			{
				\core\Log::write("bookCnDomestic,NotValidCnDomestic," . json_encode($cnDomesticIds) . ',' . $enameId, 
					'trans', 'bookcn');
			}
		}
		else
		{
			\core\Log::write("bookCnDomestic,getCnDomesticIdsFalse," . json_encode($cnDomesticIds) . ',' . $enameId, 
				'trans', 'bookcn');
		}
		unset($domainClassConf);
		return $bookCnDomestic;
	}

	/**
	 * 获取英文国际域名详细信息
	 *
	 * @param array $domainIds        	
	 * @return Ambigous <\models\trans\Ambigous, multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getEnInternationalDetailByIds($domainIds)
	{
		$TEDEsdk = new \models\trans\ExpiredDomainEnMod();
		$domainIdStr = implode(',', $domainIds);
		$cmpTime = $this->getCmpTime();
		$domain = $TEDEsdk->getDomainDetailById($domainIdStr, $cmpTime);
		return $domain;
	}

	/**
	 * 英文国际域名预订
	 *
	 * @param unknown $enameId        	
	 * @param unknown $enInternationalIds        	
	 * @return Ambigous <multitype:multitype: , \lib\trans\book\Ambigous, multitype:string unknown , multitype:string number >
	 */
	public function bookEnInternational($enameId, $enInternationalIds, $nickName)
	{
		// 加载配置
		$domainClassConf = $this->conf->domain_class->toArray();
		\core\Log::write(
			"bookEnInternational,getEnInternationalIds," . json_encode($enInternationalIds) . ',' . $enameId, 'trans', 
			'booken');
		$bookEnInternational = array('success' => array(),'error' => array());
		// 英文国内域名预订
		if($enInternationalIds)
		{
			$enInternational = $this->getEnInternationalDetailByIds($enInternationalIds);
			if($enInternational)
			{
				\core\Log::write(
					"bookEnInternational,==============Start===========," . json_encode($enInternationalIds) . ',' .
						 $enameId, 'trans', 'booken');
				$bookEnInternational = $this->bookDomainLib($enameId, $enInternational, 
					$domainClassConf['en_international'][0], $nickName);
				\core\Log::write(
					"bookEnInternational,==============End===============," . json_encode($enInternationalIds) . ',' .
						 $enameId, 'trans', 'booken');
			}
			else
			{
				\core\Log::write(
					"bookEnInternational,NotValidEnInternational," . json_encode($enInternationalIds) . ',' . $enameId, 
					'trans', 'booken');
			}
		}
		else
		{
			\core\Log::write(
				"bookEnInternational,getEnInternationalIdsFalse," . json_encode($enInternationalIds) . ',' . $enameId, 
				'trans', 'booken');
		}
		unset($domainClassConf);
		return $bookEnInternational;
	}

	/**
	 * 未进入删除期的域名添加到trans_expired_domain_scheduled表
	 *
	 * @param int $EnameId        	
	 * @param string $domains        	
	 * @return Ambigous <multitype:multitype: , multitype:string unknown >
	 */
	public function addNotExpiredDomain($EnameId, $domains, $nickName)
	{
		// 加载配置
		$book_deldate = $this->conf->predeldate;
		$bookStatus = $this->conf->book_domain_status->toArray();
		$status = array($bookStatus['booked'][0],$bookStatus['trading'][0],$bookStatus['waitToPay'][0]);
		$status = implode(', ', $status);
		
		$TEDSsdk = new \models\trans\ExpiredDomainScheduledMod();
		$TEDsdk = new \models\trans\ExpiredDomainMod();
		$TEDEsdk = new \models\trans\ExpiredDomainEnMod();
		
		$pDomainLib = new \lib\trans\common\PublicDomainLib();
		$domainInterface = new \interfaces\trans\Domains();
		$rs = array('success' => array(),'error' => array());
		if($domains)
		{
			foreach($domains as $domain)
			{
				// 检查是否已经预订此域名了
				\core\Log::write("BookDomain,CheckHaveBooked,$domain,$EnameId,$book_deldate", 'trans', 'NotExpired');
				$delDate = "'" . $book_deldate . "'";
				$domainCnt = $TEDSsdk->getBookDomainCnt($EnameId, $domain, $delDate, $status);
				if($domainCnt)
				{
					\core\Log::write("BookDomain,CheckHaveBookedFalse,$domain,$EnameId,$book_deldate", 'trans', 
						'NotExpired');
					$rs['error'][] = array($domain,"您已预订过该域名了");
					continue;
				}
				else
				{
					// 判断是否是当天删除域名
					$domainTld = $pDomainLib->getDomainClassAll($domain);
					if(in_array($domainTld, array(1,2,21,22,23)))
					{
						// cn
						$model = $TEDsdk;
					}
					elseif(in_array($domainTld, array(6,7,8,24,26)))
					{
						// 中文
						$model = $TEDsdk;
					}
					elseif(in_array($domainTld, array(3,4)))
					{
						// com, net
						$model = $TEDEsdk;
					}
					else
					{
						$model = false;
					}
					$flag = $this->checkDayDomain($model, $domain);
					if($flag)
					{
						// 提前预订
						$data = array();
						$data['OldExpiredDomainScheduledId'] = 0;
						$data['DomainName'] = $domain;
						$data['AuditListId'] = 0;
						$data['EnameId'] = $EnameId;
						$data['PredeterminedPrice'] = 0;
						$data['PredeterminedDate'] = date('Y-m-d H:i:s');
						$data['DomainLength'] = $pDomainLib->abslength($pDomainLib->getDomainBody($domain)); // 域名长度
						$groupType = $domainInterface->getDomainGroup($domain);
						$data['className'] = $groupType['domainClass']; // 域名类型
						$data['DomainLtd'] = $pDomainLib->getDomainClassAll($domain);
						$data['sysGroupOne'] = $groupType['domainSysOne']; // 域名分组一
						$data['sysGroupTwo'] = $groupType['domainSysTwo']; // 域名分组二
						$data['BookOrderId'] = 0;
						$data['DelDate'] = $book_deldate;
						$data['NicjName'] = $nickName;
						$data['Status'] = 1;
						$data['DomainType'] = $pDomainLib->getDomainClassName($domain);
						$data['AdminId'] = 0;
						$data['FinishDateFlag'] = '0000-00-00';
						\core\Log::write(
							"BookDomain,AddScheduleTable," . $data['DomainName'] . ',' . $EnameId . ',' .
								 $data['DelDate'], 'trans', 'NotExpired');
						$res = $TEDSsdk->bookDomain($data['DomainName'], $EnameId, $data['PredeterminedPrice'], 
							$data['NicjName'], $data['DomainLength'], $data['className'], $data['DomainLtd'], 
							$data['sysGroupOne'], $data['sysGroupTwo'], $data['BookOrderId'], $data['DelDate']);
						
						if(!$res)
						{
							\core\Log::write(
								"BookDomain,AddScheduleTableFalse," . $data['DomainName'] . ',' . $EnameId . ',' .
									 $data['DelDate'], 'trans', 'NotExpired');
						}
						else
						{
							\core\Log::write(
								"BookDomain,AddScheduleTableSuccess," . $data['DomainName'] . ',' . $EnameId . ',' .
									 $data['DelDate'], 'trans', 'NotExpired');
							$rs['success'][] = array($data['DomainName'],"预订成功");
						}
					}
					else
					{
						\core\Log::write(
							"BookDomain,CheckBookedDelDate," . $domain . ',' . $EnameId . ',' . $book_deldate . ',' .
								 '已经超过预订时间', 'trans', 'NotExpired');
						$rs['error'][] = array($domain,"已经超过预订时间");
					}
				}
			}
		}
		return $rs;
	}

	/**
	 * 获取我预订域名数量
	 *
	 * @param int $enameId        	
	 * @param int $status        	
	 * @return Ambigous <\models\trans\Ambigous, boolean, mixed>
	 */
	public function getBookDomainNum($enameId, $status)
	{
		$scheduledMod = new \models\trans\ExpiredDomainScheduledMod();
		return $scheduledMod->getBookDomainNum($enameId, $status);
	}
}
?>
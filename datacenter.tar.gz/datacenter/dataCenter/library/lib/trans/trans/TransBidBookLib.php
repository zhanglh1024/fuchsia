<?php
namespace lib\trans\trans;

class TransBidBookLib implements \interfaces\trans\TransBidInterface
{

	private $sdk;

	private $transBidPublicLib;

	private $conf;

	private $financeConf;

	public function __construct()
	{
		$this->sdk = new \models\trans\BookAuctionMod();
		$this->transBidPublicLib = new TransBidPublicLib();
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'book');
		$this->financeConf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
	}

	public function getTransInfoForBid($auditListId, $transStatus)
	{
		$rs = $this->sdk->getTransInfoForBid($auditListId, $transStatus);
		return $rs?  :false;
	}

	/**
	 * 获得当前用户NickName
	 */
	public function getUserNickName($auditListId, $EnameId)
	{
		$TBBRsdk = new \models\trans\BookBidRecordMod();
		$nickName = $TBBRsdk->getNickNameOfRecord($auditListId, $EnameId);
		return $nickName;
	}

	/**
	 * 检测是否闯入
	 */
	public function checkPre($EnameId, $auditListId, $domainName, $postPrice)
	{
		// 加载配置
		$financeTypeConf = $this->financeConf->type->toArray();
		// 检查余额是否足够支付闯入扣款和出价保证金
		$MoneyChuangRu = $this->conf->trans_chuang_ru_kou_kuan;
		$PredeterminedPrice = $this->conf->trans_freeze_price;
		$bookStatus = $this->conf->book_domain_status->toArray();
		
		$TEDSsdk = new \models\trans\ExpiredDomainScheduledMod();
		$rs = $TEDSsdk->getEnameIdIn($EnameId, $auditListId);
		if($rs > 0)
		{
			return TRUE;
		}
		else
		{
			$this->transBidPublicLib->checkMoney($EnameId, $MoneyChuangRu, $postPrice);
			$pFinanceLib = new \interfaces\trans\Finance($EnameId);
			$PreOrderId = $pFinanceLib->addOrder($domainName, $financeTypeConf['chuangRuKouKuan'], $MoneyChuangRu); // 生成订单
			if(!$PreOrderId)
			{
				\core\Log::write("FALSE,$EnameId,$auditListId,闯入扣款生成订单失败", 'trans','bid');
				throw new \Exception(\common\Lang::create('bookmsg')->getMsg('620013'));
			}
			$ExpiredInfo = $TEDSsdk->getExipiredDomainInfo($domainName, $auditListId);
			$TEDSsdk->addEnameIdIn($domainName, $auditListId, $EnameId, $PredeterminedPrice, 
				$ExpiredInfo['DomainLength'], $ExpiredInfo['ClassName'], $ExpiredInfo['DomainLtd'], 
				$ExpiredInfo['SysGroupOne'], $ExpiredInfo['SysGroupTwo'], $ExpiredInfo['DelDate'], 
				$bookStatus['trading'][0]);
			$rs = $pFinanceLib->confirmOrder($PreOrderId);
			if($rs)
			{
				return TRUE;
			}
		}
		return False;
	}

	/**
	 * 竞价拍卖，第一个出价
	 */
	public function auctionFirstBider($auditListId, $EnameId, $nickName, $buyerOrderId, $askingPrice, $bidAgentPrice)
	{
		return true;
	}

	/**
	 * 领先更新代理价
	 */
	public function leaderUpdateAgentPrice($auditListId, $buyer, $agentBidPrice, $buyerOrderId, $postPrice)
	{
		if($this->sdk->updateAgentPrice($auditListId, $buyer, $agentBidPrice, $buyerOrderId, $postPrice))
		{
			return true;
		}
		return false;
	}

	/**
	 * 非领先更新代理价
	 */
	public function unLeaderUpdatePrice($auditListId, $oldBuyer, $oldBidPrice, $buyer, $nickName, $buyerOrderId, 
		$newBidPrice, $newAgentBidPrice, $newFinishDate, $oldAgentBidPrice = FALSE)
	{
		if($this->sdk->unLeaderUpdatePriceModel($auditListId, $oldBuyer, $oldBidPrice, $buyer, $nickName, $buyerOrderId, 
			$newBidPrice, $newAgentBidPrice, $newFinishDate, $oldAgentBidPrice))
		{
			return true;
		}
		return false;
	}

	/**
	 * 写入出价表，生成出价信息
	 */
	public function CreateBidPrice($auditListId, $domainName, $transType, $bider, $seller, $nickName, $bidPrice, 
		$buyerIP, $finishDate, $isAgentPrice = FALSE, $new = FALSE)
	{
		$TBBRsdk = new \models\trans\BookBidRecordMod();
		if($new === FALSE) // 非第一个出价
		{
			$rs = $TBBRsdk->setDisplayStatusOff($auditListId); // 取消最高出价
			if(!$rs)
			{
				\core\Log::write("FALSE,$bider,$domainName,取消最高出价标志错误", 'trans','bid');
			}
			$rs = $TBBRsdk->setFlagOff($auditListId, $bider); // 取消用户最高出价
			if(!$rs)
			{
				\core\Log::write("FALSE,$bider,$domainName,设置用户最后出价错误", 'trans','bid');
			}
		}
		$bidTime = empty($_SERVER['REQUEST_TIME'])? time() :$_SERVER['REQUEST_TIME'];
		$bidDate = date("Y-m-d H:i:s", $bidTime);
		$displayStatus = 1;
		$flag = 1;
		$isAgentPrice = $isAgentPrice? 1 :0;
		$rs = $TBBRsdk->addBidRecord($auditListId, $domainName, $bider, $nickName, $bidPrice, $isAgentPrice, $bidDate, 
			$transType, $displayStatus, $flag, $buyerIP, $finishDate, $seller);
		if(!$rs)
		{
			return False;
		}
		return TRUE;
	}

	/**
	 * 更新BidCount
	 */
	public function updateBidCount($auditListId)
	{
		$TBAsdk = new \models\trans\BookAuctionMod();
		$TBBRsdk = new \models\trans\BookBidRecordMod();
		$bidCount = $TBBRsdk->getBidRecordCount($auditListId);
		$TBAsdk->updateBidCount($auditListId, $bidCount);
		return true;
	}
}
?>
<?php
namespace lib\trans\trans;

use models\trans\DomainFavoriteMod;
class TransLib
{

	private $conf;

	private $financeConf;

	public function __construct()
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'inquiry');
		$this->financeConf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
	}

	/**
	 * 设置出价表和关注表，交易结束的相关信息
	 */
	public function setAuctionFinish($auditListId, $domainName, $buyer, $nickName, $seller, $price, $transType, 
		$simpleDec)
	{
		// 出价表
		$TBRsdk = new \models\trans\BidRecordMod();
		$TBRsdk->setAuctionFinish($auditListId, $buyer, $price);
		// 关注表
		$TDFsdk = new \models\trans\DomainFavoriteMod();
		$TDFsdk->setAuctionFinish($auditListId, $domainName, $nickName?  :$buyer, $seller, $price, $transType, 
			$simpleDec);
		return TRUE;
	}

	/**
	 * setTransStatusLib
	 * 设置交易表状态
	 * TransScheduleLib->setTransStatusLib()
	 */
	public function setTransStatusLib($auditListId, $TDAsdk, $status)
	{
		$rs = $TDAsdk->setTransStatusModel($auditListId, $status);
		if($rs)
		{
			// 流拍不记录
			if($status != 10)
			{
				\core\Log::write("setTransStatusLib,$auditListId|$status,交易表设置成功",'trans','translib');
			}
			return TRUE;
		}
		\core\Log::write("setTransStatusLib,$auditListId|$status,交易表设置状态失败",'trans','translib');
		return FALSE;
	}

	/**
	 * FinanceTypeNum
	 * 获取相应的财务类型
	 */
	public function FinanceTypeNum($transType = FALSE, $transTopic = FALSE, $trans = FALSE)
	{
		$tempTransType = $this->conf->trans_transtype->toArray();
		$tempTransTopic = $this->conf->trans_transtopic->toArray();
		$typeConf = $this->financeConf->type->toArray();
		if($transTopic !== FALSE)
		{
			switch($transTopic)
			{
				case $tempTransTopic['notopic'][0]:
					break;
				case $tempTransTopic['ebuy'][0]:
					return $typeConf['yiPaiYiMai'];
				case $tempTransTopic['topicshow'][0]:
					return $typeConf['zhuanTiPaiMai'];
				case $tempTransTopic['beach'][0]:
					return $typeConf['niceNumDomain'];
				case $tempTransTopic['specialauction'][0]:
					return $typeConf['niceDomain'];
			}
		}
		if($transType !== FALSE)
		{
			switch($transType)
			{
				case $tempTransType['auction'][0]:
					return $typeConf['niceNumDomain'];
				case $tempTransType['reserved'][0]:
					return $typeConf['baoLiuJingJia'];
				case $tempTransType['booking'][0]:
					return $typeConf['baoLiuJingJia'];
				case $tempTransType['buynow'][0]:
					return $typeConf['yiKouJia'];
				case $tempTransType['inquiry'][0]:
					return $typeConf['yiKouJia'];
			}
		}
		return FALSE;
	}

	public function doComment($buyer, $seller, $auditListId, $transStatus, $domainName, $price)
	{
		$comment = new \lib\trans\shop\ShopLib();
		if($comment->addTransForEvaluate($buyer, $seller, $auditListId, $transStatus, $domainName, $price))
		{
			\core\Log::write("comment,TRUE,$auditListId",'trans','comment');
			return True;
		}
		else
		{
			\core\Log::write("comment,FALSE,$auditListId",'trans','comment');
			return false;
		}
	}

	/**
	 * 写入出价表
	 * 生成出价信息
	 *
	 * @param int $auditListId        	
	 * @param string $domainName        	
	 * @param int $transType        	
	 * @param int $bider        	
	 * @param int $seller        	
	 * @param string $nickName        	
	 * @param int $bidPrice        	
	 * @param string $buyerIP        	
	 * @param datetime $finishDate        	
	 * @param int $isAgentPrice        	
	 * @param string $new        	
	 * @return boolean
	 */
	public function CreateBidPrice($auditListId, $domainName, $transType, $bider, $seller, $nickName, $bidPrice, 
		$buyerIP, $finishDate, $isAgentPrice = FALSE, $new = FALSE)
	{
		$TBRsdk = new \models\trans\BidRecordMod();
		if($new === FALSE) // 非第一个出价
		{
			$rs = $TBRsdk->setDisplayStatusOff($auditListId); // 取消最高出价
			if(!$rs)
			{
				\core\Log::write("FALSE,$bider,$domainName,取消最高出价标志错误",'trans','bid');
			}
			$rs = $TBRsdk->setFlagOff($auditListId, $bider); // 取消用户最高出价
			if(!$rs)
			{
				\core\Log::write("FALSE,$bider,$domainName,设置用户最后出价错误",'trans','bid');
			}
		}
		$bidDate = date("Y-m-d H:i:s");
		$displayStatus = 1;
		$flag = 1;
		$isAgentPrice = $isAgentPrice? 1 :0;
		$rs = $TBRsdk->addBidRecord($auditListId, $domainName, $bider, $nickName, $bidPrice, $isAgentPrice, $bidDate, 
			$transType, $displayStatus, $flag, $buyerIP, $finishDate, $seller);
		if(!$rs)
		{
			\core\Log::write("FALSE,$auditListId,$bider,$domainName,添加用户出价记录失败",'trans','bid');
			return False;
		}
		return TRUE;
	}

	/**
	 * 检测QQ域名
	 *
	 * @param string $domainName        	
	 */
	public function checkQQdomain($domainName)
	{
		$pDomains = new \interfaces\trans\Domains();
		return $pDomains->checkQQDomains($domainName);
	}

	/**
	 * TransAuctionToDelivery
	 *
	 * @param int $auditListId        	
	 * @param int $transStatus
	 *        	交易结束，进入交付流程
	 *        	取交易数据到交付表
	 */
	public function TransAuctionToDelivery($auditListId, $transStatus, $isQQdomain = FALSE)
	{
		$TDAsdk = new \models\trans\DomainAuctionMod();
		$TDsdk = new \models\trans\DeliveryMod();
		
		$rs = $TDAsdk->setTransStatus($auditListId, $transStatus);
		if(!$rs)
		{
			\core\Log::write("$auditListId,转移到交付表，设置域名状态失败",'trans','translib');
			return FALSE;
		}
		// 判断交付表是否有$auditListId的记录，有就不添加
		$rs = $TDsdk->checkDelivery($auditListId);
		if($rs)
		{
			\core\Log::write("$auditListId,交付表已有该信息,交易信息转移到交付表失败",'trans','translib');
			return FALSE;
		}
		// 获取交易表信息
		$transInfo = $TDAsdk->getByAuditListId($auditListId);
		if(!$transInfo)
		{
			\core\Log::write("$auditListId,请求数据库交易数据，失败",'trans','translib');
			return FALSE;
		}
		$sellerDate = ''; // '卖家确认时间';
		$buyerDate = ''; // '买家确认时间';
		
		$deliveryDay = $this->conf->trans_delivery_day->toArray();
		$sellerDeliveryDay = intval($deliveryDay['seller'][0]);
		$buyerDeliveryDay = intval($deliveryDay['seller'][0]) + intval($deliveryDay['buyer'][0]);
		$inEnameConfig = $this->conf->trans_domain_in_ename->toArray();
		
		if($transInfo['IsDomainInEname'] == $inEnameConfig['domain_notinEname'][0])
		{
			$sellerDeliveryDay = $sellerDeliveryDay + intval($deliveryDay['transfer'][0]);
			$buyerDeliveryDay = $buyerDeliveryDay + intval($deliveryDay['transfer'][0]);
		}
		if($isQQdomain)
		{
			$sellerDeliveryDay = $sellerDeliveryDay + 2;
			$buyerDeliveryDay = $buyerDeliveryDay + 2;
		}
		
		$sellerDeadline = date("Y-m-d H:i:s", strtotime("+" . intval($sellerDeliveryDay) . " day")); // = $FinishDate+1
		$buyerDeadline = date("Y-m-d H:i:s", strtotime("+" . intval($buyerDeliveryDay) . " day")); // '买家超时时间';// = $FinishDate+3
		
		$sellerApply = 0;
		$buyerApply = 0;
		$deliveryDate = date("Y-m-d H:i:s");
		$deliveryDateFlag = date("Y-m-d H:i:s");
		$commentFlag = 0;
		
		$transOrderId = ''; // 在买家确认之后生成
		$poundage = $transInfo['Poundage']; // 手续费 根据交易方式的不同 而不同
		$penalty = ''; // 违约金，根据
		$compensation = ''; // 补偿金
		$withdrawType = ''; // 入款类型
		                    
		// 插入交付表
		$rs = $TDsdk->addTransToDelivery($auditListId, $transInfo['TransType'], $transInfo['TransTopic'], 
			$transInfo['SellerIP'], $transInfo['BuyerIP'], $transInfo['Seller'], $transInfo['Buyer'], 
			$transInfo['DomainName'], $transInfo['TransStatus'], $transInfo['ReservePrice'], $sellerDate, 
			$sellerDeadline, $sellerApply, $buyerDate, $buyerDeadline, $buyerApply, $deliveryDate, $commentFlag, 
			$transInfo['BidPrice'], $transOrderId, $poundage, $penalty, $compensation, $withdrawType, $deliveryDateFlag, 
			$transInfo['IsDomainInEname'], $transInfo['BuyerOrderId'], $transInfo['SellerOrderId'], 
			$transInfo['DeadTime']);
		if(!$rs)
		{
			\core\Log::write("FALSE,$auditListId," . $transInfo['Buyer'] . ',' . '交易表插入交付表信息，失败','trans','translib');
			return FALSE;
		}
		\core\Log::write("$auditListId,交易表插入交付表信息，成功",'trans','translib');
		return TRUE;
	}

	/**
	 * 添加交易订单到交付表
	 *
	 * @param int $auditListId        	
	 * @param int $transOrderId        	
	 */
	public function addTransOrderIdToDelivery($auditListId, $transOrderId)
	{
		$TDsdk = new \models\trans\DeliveryMod();
		$rs = $TDsdk->setTransOrderId($auditListId, $transOrderId);
		if(!$rs)
		{
			\core\Log::write("$auditListId,$transOrderId,添加 交付表 订单号 失败",'trans','translib');
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * TransDeliveryToTransfer
	 * 取交付数据到过户表
	 */
	public function TransDeliveryToTransfer($auditListId)
	{
		$TDsdk = new \models\trans\DeliveryMod();
		$TTsdk = new \models\trans\TransferMod();
		// 判断是否有$auditListId的记录，有就不添加
		$rs = $TTsdk->checkTransfer($auditListId);
		if($rs)
		{
			\core\Log::write("$auditListId,过户表已有该信息",'trans','translib');
			return FALSE;
		}
		// 取得交付表过户信息
		$deliveryInfo = $TDsdk->getTransferInfo($auditListId);
		// 验证是否有 交易订单号
		if($deliveryInfo['TransOrderId'] == 0)
		{
			\core\Log::write($deliveryInfo['AuditListId'] . ',' . $deliveryInfo['TransOrderId'] . ',' . "交付表的交易订单异常",'trans','translib');
			return FALSE;
		}
		$rs = $TTsdk->addTransfer($auditListId, $deliveryInfo['DomainName'], $deliveryInfo['Seller'], 
			$deliveryInfo['Buyer'], $deliveryInfo['TransOrderId'], $deliveryInfo['TransMoney']);
		if(!$rs)
		{
			\core\Log::write("$auditListId,添加转移表操作失败",'trans','translib');
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * 解锁域名
	 *
	 * @param string $domain        	
	 * @return boolean
	 */
	public function unlockDomain($domain)
	{
		$domains = new \interfaces\trans\Domains();
		$rs = $domains->setDomainMyStatus($domain, 1);
		if(!$rs['result'])
		{
			\core\Log::write("$domain,解锁失败",'trans','translib');
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * 过户
	 *
	 * @param string $auditListId        	
	 * @return boolean
	 */
	public function doTransfer($auditListId)
	{
		$TTsdk = new \models\trans\TransferMod();
		$TransferInfo = $TTsdk->getTransferInfoForTransfer($auditListId);
		\core\Log::write("TransferInfo,$auditListId," . json_encode($TransferInfo),'trans','translib');
		$pDomain = new \interfaces\trans\Domains();
		$rs = $pDomain->domainPush($TransferInfo['DomainName'], $TransferInfo['Seller'], $TransferInfo['Buyer']);
		if(!$rs)
		{
			\core\Log::write(
				"转移域名失败,$auditListId," . $TransferInfo['DomainName'] . ',' . $TransferInfo['Seller'] . ',' .
					 $TransferInfo['Buyer'] . ',' . $TransferInfo['TransOrderId'],'trans','translib');
			return FALSE;
		}
		return True;
	}

	/**
	 * 锁定域名
	 *
	 * @param string $domain        	
	 * @return boolean
	 */
	public function lockDomain($domain)
	{
		$pDomain = new \interfaces\trans\Domains();
		$rs = $pDomain->setDomainMyStatus($domain, 2);
		if(!$rs['result'])
		{
			\core\Log::write("$domain，锁定失败",'trans','translib');
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * 获取卖家正在交易域名列表
	 *
	 * @param int $enameId        	
	 * @param int $transType        	
	 * @param string $deliveryStatus        	
	 * @param int $offset        	
	 * @param int $pageSize        	
	 * @throws \Exception
	 * @return Ambigous <\models\trans\Ambigous, multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getSellerTrandingList($domain, $enameId, $transType, $deliveryStatus, $offset, $pageSize)
	{
		$deliveryMod = new \models\trans\DeliveryMod();
		$list = $deliveryMod->getSellerDelivery($domain, $enameId, $deliveryStatus, $transType, $offset, $pageSize);
		if(false === $list)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'),610000);
		}
		
		return $list;
	}

	/**
	 * 获取卖家正在交易域名数量
	 *
	 * @param unknown $enameId        	
	 * @param unknown $transType        	
	 * @param unknown $deliveryStatus        	
	 * @throws \Exception
	 * @return Ambigous <\models\trans\Ambigous, boolean, mixed>
	 */
	public function getSellerTrandingCount($domain, $enameId, $transType, $deliveryStatus)
	{
		$deliveryMod = new \models\trans\DeliveryMod();
		$count = $deliveryMod->getSellerDeliveryCount($domain, $enameId, $deliveryStatus, $transType);
		if(false === $count)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'),610000);
		}
		return $count;
	}

	/**
	 * 获取买家正在交易域名列表
	 *
	 * @param int $enameId        	
	 * @param int $transType        	
	 * @param string $deliveryStatus        	
	 * @param int $offset        	
	 * @param int $pageSize        	
	 * @throws \Exception
	 * @return Ambigous <\models\trans\Ambigous, multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getBuyerTrandingList($domain, $enameId, $transType, $deliveryStatus, $offset, $pageSize)
	{
		$deliveryMod = new \models\trans\DeliveryMod();
		$list = $deliveryMod->getBuyerDelivery($domain, $enameId, $deliveryStatus, $transType, $offset, $pageSize);
		if(false === $list)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'),610000);
		}
		return $list;
	}

	/**
	 * 获取买家正在交易域名数量
	 *
	 * @param unknown $enameId        	
	 * @param unknown $transType        	
	 * @param unknown $deliveryStatus        	
	 * @throws \Exception
	 * @return Ambigous <\models\trans\Ambigous, multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getBuyerTrandingCount($domain, $enameId, $transType, $deliveryStatus)
	{
		$delivery = new \models\trans\DeliveryMod();
		$count = $delivery->getBuyerDeliveryCount($domain, $enameId, $deliveryStatus, $transType);
		if(false === $count)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'),610000);
		}
		
		return $count;
	}

	/**
	 * 获取买家昵称
	 *
	 * @param int $AuditListId        	
	 * @param datetime $DeliveryDate        	
	 * @return string
	 */
	public function getNickName($AuditListId, $DeliveryDate)
	{
		$TDAsdk = new \models\trans\DomainAuctionMod();
		$nickName = '';
		// 默认交易表
		$nickName = $TDAsdk->getNickName($AuditListId);
		if(!$nickName)
		{
			// 写入交付表那年的交易表
			$year = date('Y', strtotime($DeliveryDate));
			if($TDAsdk->checkTable($year))
			{
				$nickName = $TDAsdk->getNickName($AuditListId, $year);
				if(!$nickName)
				{
					// 下一年交易表
					$year = $year + 1;
					if($TDAsdk->checkTable($year))
						$nickName = $TDAsdk->getNickName($AuditListId, $year);
				}
			}
		}
		return $nickName;
	}

	/**
	 * 生成卖家违约金
	 *
	 * @param int $transMoney        	
	 * @return number
	 */
	public function createSellerAbandonMoney($transMoney)
	{
		$temp = intval($transMoney);
		if($temp < 200)
		{
			return 50;
		}
		else
		{
			return intval($temp / 10 + 50);
		}
	}

	/**
	 * 计算用户的违约金
	 *
	 * @param string $method        	
	 * @param int $transMoney        	
	 * @param int $enameId        	
	 * @param int $buyer        	
	 * @param int $seller        	
	 * @return Ambigous <\lib\trans\trans\Ambigous, number, unknown>
	 */
	public function getAbandonMoney($method, $transMoney, $enameId, $buyer, $seller)
	{
		switch($method)
		{
			case 'sellerrefuse':
				$abandonMoney = $this->createSellerAbandonMoney($transMoney);
				break;
			case 'buyerrefuse':
				$lib = new \lib\trans\trans\TransBidPublicLib();
				$abandonMoney = $lib->createAssMoney($transMoney, FALSE, $seller);
				break;
		}
		return $abandonMoney;
	}

	/**
	 * 判断是否存在正在交易的竞价
	 *
	 * @param int $id        	
	 * @throws \Exception
	 * @return Ambigous <boolean, mixed>
	 */
	public function autionIsFinish($id)
	{
		$transStatusConf = $this->conf->trans_status->toArray();
		$deliveryStatus = array($transStatusConf['checking'][0],$transStatusConf['buyerchecked'][0],
			$transStatusConf['sellerchecked'][0],$transStatusConf['allchecked'][0]);
		$mod = new \models\trans\DomainAuctionMod();
		$count = $mod->getIstrandding($id, $deliveryStatus);
		if(false === $count)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'),610000);
		}
		return $count? true :false;
	}

	/**
	 * 判断是否存在正在交易的询价
	 *
	 * @param int $id        	
	 * @throws \Exception
	 * @return Ambigous <\models\trans\Ambigous, boolean, mixed>
	 */
	public function inquiryIsFinish($id)
	{
		$inquiryStatusConf = $this->conf->inquiry_reply_status->toArray();
		$inquiryStatusStr = array($inquiryStatusConf['buyerreply'][0],$inquiryStatusConf['sellerreply'][0],
			$inquiryStatusConf['buyeragree'][0],$inquiryStatusConf['selleragree'][0],
			$inquiryStatusConf['buyerconfirm'][0],$inquiryStatusConf['sellerconfirm'][0],
			$inquiryStatusConf['lockdomain'][0],$inquiryStatusConf['unfinishinquiry'][0]);
		$mod = new \models\trans\InquiryReplyMod();
		$count = $mod->getIsTrandding($id, $inquiryStatusStr);
		if(false === $count)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'),610000);
		}
		
		return $count? true :false;
	}
	/**
	 * 检测交易是否存在
	 * @param unknown $id
	 * @param unknown $transType
	 * @throws \Exception
	 * @return boolean
	 */
	public function checkExistTrans($id,$transType)
	{
		$transTypeConf = $this->conf->trans_type->toArray();
		if(!in_array($transType, array($transTypeConf['auction'][0],$transTypeConf['booking'][0],$transTypeConf['buynow'][0],$transTypeConf['inquiry'][0])))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610027'),610027);
		}
		if($transType == $transTypeConf['auction'][0] || $transType == $transTypeConf['buynow'][0])
		{
			$transMod = new \models\trans\DomainAuctionMod();	
		}
		elseif($transType == $transTypeConf['booking'][0])
		{
			$transMod = new \models\trans\BookAuctionMod();
		}
		elseif($transType == $transTypeConf['inquiry'][0])
		{
			$transMod = new \models\trans\InquiryMod();
		}
		if(!$transMod->isDomainExist($id))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610028'),610028);
		}
		else
		{
			return true;
		}
	}
	
	/**
	 * 
	 * @param   int           $enameId
	 * @throws  \Exception
	 * @return  bool                     传入的enameId未被交易冻结时返回true，否则抛出异常
	 */
	static public function checkFrozenStatus($enameId)
	{
		$redis = \core\RedisLib::getInstance('trans');
		$frozenEnameIds = $redis->get('trans_Frozen_EnameIds');
		if (empty($frozenEnameIds))
		{
			return true;
		}
		if (in_array($enameId, $frozenEnameIds))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610127'),610127);
		}
		return true;
	}

}
?>
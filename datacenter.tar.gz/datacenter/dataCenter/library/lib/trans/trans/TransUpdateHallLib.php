<?php

namespace lib\trans\trans;

/**
 * 竞价大厅推送对象
 * @author root
 *
 */
class TransUpdateHallLib
{
	/**
	 * 更新竞价大厅出价，关注，取消关注
	 * @param int 交易id
	 * @param int 用户id      
	 * @param int 交易id
	 * @param int 用户id       	
	 * @param int 推送类型1-关注 2-取消关注 3-出价	
	 */
	public function auctionHallUpdate($host, $port, $auditListId, $enameid, $type=3)
	{
		$auctionMod = new \models\trans\DomainAuctionMod();
		
		// 交易是否是24小时之内
		if($auctionMod->isAuctionIng($auditListId))
		{			
			$http = "http://{$host}:{$port}/update?";
			$data['code'] = "0100";
			$data['auditlistid'] = $auditListId;
			$data['token'] = 'e0d7eff802ca849a1479';
			$data['clientid'] = $enameid;
			$data['type'] = $type;			
			$data = urlencode(json_encode($data));
			$http .= "message={$data}";
			
			// 发送
			$ch = @curl_init($http);
			if(!curl_errno($ch))
			{
				curl_exec($ch);
				curl_close($ch);
			}
		}
	}
}
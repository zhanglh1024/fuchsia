<?php

namespace lib\trans\trans;

class TransMessageLib
{ 

	private $receiveId;

	private $receivePhone;

	private $receiveEmail;

	private $sms;

	private $email;

	private $message;

	private $pQueueLib;

	private $interfaces;

	public function __construct($receiveId, $message = FALSE, $email = FALSE, $sms = FALSE)
	{
		$this->receivePhone = False;
		$this->receiveEmail = False;
		
		$this->receiveId = $receiveId;
		$this->message = $message;
		$this->email = $email;
		$this->sms = $sms;
		$this->interfaces = new \interfaces\trans\Queue();
	}

	public function setReceiveId($receiveId)
	{
		$this->receiveId = $receiveId;
		return TRUE;
	}

	private function getInfo($enameId)
	{
		$userInterface = new \interfaces\trans\User();
		$info = $userInterface->getMemberInfoByEnameId($enameId);
		if(isset($info['Email']))
		{
			$this->receiveEmail = $info['Email'];
		}
		if(isset($info['Mobile']))
		{
			$this->receivePhone = $info['Mobile'];
		}
		return TRUE;
	}

	private function sendEmail($enameId, $templateId, $email, $data, $function = '', $taskId = 0, $priority = 5)
	{
		$this->pQueueLib = new \interfaces\trans\Queue();
		$rs = $this->pQueueLib->sendMail($templateId, $email, $data, $enameId);
		\core\Log::write("$enameId,$templateId,$email" . json_encode($data) . ',' . json_encode($rs), 'trans', 'queue');
	}

	private function sendMessage($receiveId, $messageType, $templateId, $templateData)
	{
		$this->pQueueLib = new \interfaces\trans\Queue();
		$rs = $this->pQueueLib->sendSiteMsg($receiveId, $templateId, $templateData, $messageType);
		\core\Log::write(
			"message,$receiveId,$messageType,$templateId," . json_encode($templateData) . ',' . json_encode($rs), 
			'trans', 'queue');
	}

	private function sendSms($templateId, $phone, $tplData, $enameId, $priority = 5)
	{
		$this->pQueueLib = new \interfaces\trans\Queue();
		$this->pQueueLib->sendSms($templateId, $phone, $tplData, $enameId, $priority);
	}

	private function sender($messageType, $templateId, $templateData, $priority = 5)
	{
		$enameId = $this->receiveId;
		//发送 站内短信 优先  邮件最慢
		if($this->message !== FALSE)
		{
			$this->sendMessage($enameId, $messageType, $templateId, $templateData);
		}
		if($this->sms || $this->email)
		{
			$this->getInfo($enameId);
		}
		if($this->sms !== FALSE)
		{
			$data = $templateData;
			if($this->receivePhone)
			{
				$this->sendSms($templateId, $this->receivePhone, $data, $enameId, $priority);
			}
			else
			{
				\core\Log::write("发送失败,此人无phone,$enameId,$templateId," . $this->receivePhone, 'trans', 'queue');
			}
		}
		if($this->email !== FALSE)
		{
			$data = $templateData;
			if($this->receiveEmail)
			{
				$this->sendEmail($enameId, $templateId, $this->receiveEmail, $data, '', 0, $priority);
			}
			else
			{
				\core\Log::write("发送失败,此人无email,$enameId,$templateId," . $this->receiveEmail, 'trans', 'queue');
			}
		}
	
		return TRUE;
	}

	public function trans_audit_ebuy_pass($data)
	{
		$messageType = 17;
		$templateId = 'trans_audit_ebuy_pass';
		$templateData = array('domainName'=> $data['domainName'],'enameId'=> $data['enameId'],'url'=> $data['url']);
		$rs = $this->sender($messageType, $templateId, $templateData, 4);
		return $rs;
	}

	public function trans_audit_topic_pass($data)
	{
		$messageType = 17;
		$templateId = 'trans_audit_topic_pass';
		$templateData = array('domainName'=> $data['domainName'],'enameId'=> $data['enameId'],'url'=> $data['url']);
		$rs = $this->sender($messageType, $templateId, $templateData, 4);
		return $rs;
	}

	public function trans_buynow_success_buyer_qqdomain($data)
	{
		$messageType = 5;
		$templateId = 'trans_buynow_success_buyer_qqdomain';
		$templateData = array('domainName'=> $data['domainName'],'enameId'=> $this->receiveId,
				'nowTime'=> $data['nowTime'],'price'=> $data['price']);
		$rs = $this->sender($messageType, $templateId, $templateData);
		return $rs;
	}

	public function trans_auction_success_buyer($data)
	{
		$messageType = 5;
		$templateId = 'trans_auction_success_buyer';
		$templateData = array('domainName'=> $data['domainName'],'enameId'=> $this->receiveId,'id'=> $data['id']);
		$rs = $this->sender($messageType, $templateId, $templateData, 4);
		return $rs;
	}

	public function trans_auction_success_seller($data)
	{
		$messageType = 5;
		$templateId = 'trans_auction_success_seller';
		$templateData = array('domainName'=> $data['domainName'],'enameId'=> $this->receiveId,'id'=> $data['id']);
		$rs = $this->sender($messageType, $templateId, $templateData, 4);
		return $rs;
	}

	public function trans_buynow_success_seller_qqdomain($data)
	{
		$messageType = 5;
		$templateId = 'trans_buynow_success_seller_qqdomain';
		$templateData = array('domainName'=> $data['domainName'],'enameId'=> $this->receiveId,
				'nowTime'=> $data['nowTime'],'price'=> $data['price']);
		$rs = $this->sender($messageType, $templateId, $templateData);
		return $rs;
	}

	public function trans_buynow_success_buyer($data)
	{
		$messageType = 26;
		$templateId = 'trans_buynow_success_buyer';
		$templateData = array('domainName'=> $data['domainName'],'enameId'=> $this->receiveId,
				'nowTime'=> $data['nowTime'],'price'=> $data['price'],'id'=> $data['id'],'typeFlag'=> 1,'role'=> 'buyer');
		$rs = $this->sender($messageType, $templateId, $templateData, 4);
		return $rs;
	}

	public function trans_buynow_success_seller($data)
	{
		$messageType = 26;
		$templateId = 'trans_buynow_success_seller';
		$templateData = array('domainName'=> $data['domainName'],'enameId'=> $this->receiveId,
				'nowTime'=> $data['nowTime'],'price'=> $data['price'],'id'=> $data['id'],'typeFlag'=> 1,'role'=> 'seller');
		$rs = $this->sender($messageType, $templateId, $templateData, 4);
		return $rs;
	}

	/**
	 * 发送预订消息
	 * @param array $data
	 * @return boolean
	 */
	public function sendBookMsg($data)
	{
		$messageType = 4;
		$templateId = 'trans_book_auction';
		$templateData = array(
				'title'=>$data['title'],
				'content'=>$data['content'],
				'getNum'=>$data['getNum'],
				'auctionNum'=>$data['auctionNum'],
				'enameId'=>$data['enameId']
		);
		$rs = $this->sender($messageType, $templateId, $templateData);
		return $rs;
	}

	public function trans_buynow_success_seller_notename($data)
	{
		$messageType = 26;
		$templateId = 'trans_buynow_success_seller_notename';
		$templateData = array('domainName'=> $data['domainName'],'enameId'=> $this->receiveId,
				'nowTime'=> $data['nowTime'],'price'=> $data['price'],'createDate'=> $data['createDate'],
				'id'=> $data['id'],'typeFlag'=> 1,'role'=> 'seller');
		$rs = $this->sender($messageType, $templateId, $templateData);
		return $rs;
	}
	
	public function trans_delivery_sellerapply($data)
	{
		$messageType = 26;
		$templateId = 'trans_delivery_sellerapply';
		$templateData = array('domainName' => $data['domainName'],'enameId' => $this->receiveId,'day' => $data['day'],
			'id' => $data['id'],'typeFlag' => 1,'role' => 'buyer');
		$rs = $this->sender($messageType, $templateId, $templateData);
		return $rs;
	}
	
	public function trans_delivery_buyerapply($data)
	{
		$messageType = 26;
		$templateId = 'trans_delivery_buyerapply';
		$templateData = array('domainName' => $data['domainName'],'enameId' => $this->receiveId,'day' => $data['day'],
			'id' => $data['id'],'typeFlag' => 1,'role' => 'seller');
		$rs = $this->sender($messageType, $templateId, $templateData);
		return $rs;
	}
	
	public function trans_delivery_selleraplly_buyerrefuse($data)
	{
		$messageType = 5;
		$templateId = 'trans_delivery_selleraplly_buyerrefuse';
		$templateData = array('domainName' => $data['domainName'],'enameId' => $this->receiveId,'day' => $data['day'],
			'id' => $data['id']);
		$rs = $this->sender($messageType, $templateId, $templateData);
		return $rs;
	}
	
	public function trans_delivery_buyeraplly_sellerrefuse($data)
	{
		$messageType = 5;
		$templateId = 'trans_delivery_buyerapply_sellerrefuse';
		$templateData = array('domainName' => $data['domainName'],'enameId' => $this->receiveId,'day' => $data['day'],
			'id' => $data['id']);
		$rs = $this->sender($messageType, $templateId, $templateData);
		return $rs;
	}
	
	public function trans_delivery_sellerapply_buyeragree($data)
	{
		$messageType = 5;
		$templateId = 'trans_delivery_sellerapply_buyeragree';
		$templateData = array('domainName' => $data['domainName'],'enameId' => $this->receiveId,'day' => $data['day'],
			'deadLine' => $data['deadLine'],'id' => $data['id']);
		$rs = $this->sender($messageType, $templateId, $templateData, 4);
		return $rs;
	}
	
	public function trans_delivery_buyerapply_selleragree($data)
	{
		$messageType = 5;
		$templateId = 'trans_delivery_buyeraplly_selleragree';
		$templateData = array('domainName' => $data['domainName'],'enameId' => $this->receiveId,'day' => $data['day'],
			'deadLine' => $data['deadLine'],'id' => $data['id']);
		$rs = $this->sender($messageType, $templateId, $templateData, 4);
		return $rs;
	}
	
	public function trans_auction_buyerrefuse_buyer($data)
	{
		$messageType = 5;
		
		$templateId = $data['flag']==1 ? 'trans_auction_buyerrefuse_buyer_auto':'trans_auction_buyerrefuse_buyer';
		$templateData = array('domainName' => $data['domainName'],'enameId' => $this->receiveId,
			'nowTime' => $data['nowTime']);
		$rs = $this->sender($messageType, $templateId, $templateData, 4);
		return $rs;
	}
	
	public function trans_auction_buyerrefuse_seller($data)
	{
		$messageType = 5;
		$templateId = 'trans_auction_buyerrefuse_seller';
		$templateData = array('domainName' => $data['domainName'],'enameId' => $this->receiveId,
			'nowTime' => $data['nowTime']);
		$rs = $this->sender($messageType, $templateId, $templateData);
		return $rs;
	}
	
	public function trans_auction_sellerrefuse_seller($data)
	{
		$messageType = 5;
		$templateId = $data['flag']==1 ?'trans_auction_sellerrefuse_seller_auto':'trans_auction_sellerrefuse_seller';
		$templateData = array('domainName' => $data['domainName'],'enameId' => $this->receiveId,
			'nowTime' => $data['nowTime']);
		$rs = $this->sender($messageType, $templateId, $templateData);
		return $rs;
	}
	
	public function trans_auction_sellerrefuse_buyer($data)
	{
		$messageType = 5;
		$templateId = 'trans_auction_sellerrefuse_buyer';
		$templateData = array('domainName' => $data['domainName'],'enameId' => $this->receiveId,
			'nowTime' => $data['nowTime']);
		$rs = $this->sender($messageType, $templateId, $templateData);
		return $rs;
	}
	
	public function trans_auction_buyer_remind($data)
	{
		$messageType = 12;
		$templateId = 'any_template_info';
		$templateData = array('title'=>'充值提醒','content'=>"易名用户{$this->receiveId}：您以{$data['Money']}元得标{$data['DomainName']}，卖家已经确认，您的可用余额不足，请在{$data['EndTime']}前充值确认交易");
		$rs = $this->sender($messageType, $templateId, $templateData, 3);
		return $rs;
	}
	
	/**
	 * 发送众筹中奖通知
	 * @param array $data
	 * @return boolean
	 */
	public function trans_zc_winner_remind($data)
	{
		$messageType = 6; //系统消息
		$templateId = 'any_template_info';
		$templateData = array('title' => "1元博米[{$data['Domain']}]：恭喜中奖", //Subject
			'content' => "尊敬的客户{$data['winner']}：<br>您好，您参与的1元博米域名[{$data['Domain']}]，"
			. "开奖结果是".$data['result']."，恭喜您中奖，域名已经过户。");
		$rs = $this->sender($messageType, $templateId, $templateData, 3);
		return $rs;
	}
	/**
	 * 成功预订域名
	 * 2013-11-11 Wlx Add
	 */
	public function trans_booked_success($data)
	{
		$messageType = 4;
		$templateId = 'trans_booked_success';
		$templateData = array(
			'enameId'=>$data['enameId'],
			'bookDomain'=>$data['bookDomain'],
		);
		$rs = $this->sender($messageType, $templateId, $templateData);
		return $rs;
	}
	
	/**
	 * 预订域名失败
	 * 2013-11-11 Wlx Add
	 */
	public function trans_booked_fail($data)
	{
		$messageType = 4;
		$templateId = 'trans_booked_fail';
		$templateData = array(
			'enameId'=>$data['enameId'],
			'bookDomain'=>$data['bookDomain'],
		);
		$rs = $this->sender($messageType, $templateId, $templateData);
		return $rs;
	}
}
?> 
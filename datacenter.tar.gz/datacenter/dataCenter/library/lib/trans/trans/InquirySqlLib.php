<?php
namespace lib\trans\trans;

class InquirySqlLib
{

	/**
	 * inquirySuccessSql
	 * return True || False
	 */
	public function setInquiryStatusSql($inquiryId, $seller, $inquiryStatus)
	{
		$TIsdk = new \models\trans\InquiryMod();
		$rs = $TIsdk->setInquiryStatusModel($inquiryId, $seller, $inquiryStatus);
		return $rs? True :False;
	}

	/**
	 * inquiryDomainRegSql
	 * 
	 * @return 1 2
	 */
	public function inquiryDomainRegSql($inquiryId)
	{
		$TIsdk = new \models\trans\InquiryMod();
		return $TIsdk->getDomainRegModel($inquiryId);
	}

	/**
	 * checkReplyPremissions
	 * 验证是否有权限，有 返回True 询价信息 无 返回False
	 */
	public function checkReplyPremissions($replyId, $enameId)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$info = $TIRsdk->getReplyPremissions($replyId, $enameId);
		if($info)
		{
			return array('result' => True,'info' => $info);
		}
		else
		{
			return array('result' => False,'info' => Null);
		}
	}
	
	// ---------------------------------buyer--
	public function setBuyerReplyPriceSql($replyId, $enameId, $replyStatus, $price)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$operateDate = date("Y-m-d H:i:s");
		$result = $TIRsdk->setBuyerReplyPriceModel($replyId, $enameId, $replyStatus, $price, $operateDate);
		return $result? True :False;
	}

	public function setBuyerRefusePriceSql($replyId, $enameId, $replyStatus)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$operateDate = date("Y-m-d H:i:s");
		$result = $TIRsdk->setBuyerRefusePriceModel($replyId, $enameId, $replyStatus, $operateDate);
		return $result? True :False;
	}

	public function setBuyerPayAllPriceSql($replyId, $enameId, $replyStatus, $transOrderId)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$operateDate = date("Y-m-d H:i:s");
		$result = $TIRsdk->setBuyerPayAllPriceModel($replyId, $enameId, $replyStatus, $operateDate, $transOrderId);
		return $result? True :False;
	}

	public function setBuyerRefuseInquirySql($replyId, $enameId, $replyStatus)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$operateDate = date("Y-m-d H:i:s");
		$result = $TIRsdk->setBuyerRefuseInquiryModel($replyId, $enameId, $replyStatus, $operateDate);
		return $result? True :False;
	}
	
	// ----------------------------------Seller--
	public function setSellerReplyPriceSql($replyId, $enameId, $replyStatus, $price, $sellerRIO = 0)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$operateDate = date("Y-m-d H:i:s");
		$result = $TIRsdk->setSellerReplyPriceModel($replyId, $enameId, $replyStatus, $price, $operateDate, $sellerRIO);
		return $result? True :False;
	}

	public function setSellerAgreePriceSql($replyId, $enameId, $replyStatus, $price, $sellerOrderId, $inquiryReg)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$operateDate = date("Y-m-d H:i:s");
		return $TIRsdk->setSellerAgreePriceModel($replyId, $enameId, $replyStatus, $operateDate, $price, $sellerOrderId, 
			$inquiryReg);
	}

	public function setSellerRefusePriceSql($replyId, $enameId, $replyStatus)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$operateDate = date("Y-m-d H:i:s");
		$result = $TIRsdk->setSellerRefusePriceModel($replyId, $enameId, $replyStatus, $operateDate);
		return $result? True :False;
	}

	public function checkSellerInquirySql($agreeInquiryArray, $enameId, $inquiryId, $replyId)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$result = $TIRsdk->checkSellerInquiryModel($agreeInquiryArray, $enameId, $inquiryId, $replyId);
		return $result?  :False;
	}

	public function setSellerRefuseInquirySql($replyId, $enameId, $replyStatus, $sellerRefuseOrderId)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$operateDate = date("Y-m-d H:i:s");
		$result = $TIRsdk->setSellerRefuseInquiryModel($replyId, $enameId, $replyStatus, $operateDate, 
			$sellerRefuseOrderId);
		return $result? True :False;
	}

	/**
	 * 买家转经纪交易
	 * 2013-01-29	Qxh	Add
	 */
	public function setBuyerToEscrowSql($replyId, $enameId, $replyStatus)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$operateDate = date("Y-m-d H:i:s");
		$result = $TIRsdk->setBuyerToEscrowModel($replyId, $enameId, $replyStatus, $operateDate);
		return $result? True :False;
	}

	/**
	 * 卖家转经纪交易
	 */
	public function setSellerToEscrowSql($replyId, $enameId, $replyStatus)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$operateDate = date("Y-m-d H:i:s");
		$result = $TIRsdk->setSellerToEscrowModel($replyId, $enameId, $replyStatus, $operateDate);
		return $result? True :False;
	}

	/**
	 * 买家延期
	 */
	public function setBuyerApplySql($replyId, $enameId, $applyStatus, $day)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$operateDate = date("Y-m-d H:i:s");
		$result = $TIRsdk->setBuyerApplyModel($replyId, $enameId, $applyStatus, $day, $operateDate);
		return $result? True :False;
	}

	/**
	 * 卖家延期
	 */
	public function setSellerApplySql($replyId, $enameId, $applyStatus, $day)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$operateDate = date("Y-m-d H:i:s");
		$result = $TIRsdk->setSellerApplyModel($replyId, $enameId, $applyStatus, $day, $operateDate);
		return $result? True :False;
	}

	/**
	 * 设置卖家截止时间
	 */
	public function setBuyerDeadLineSql($replyId, $deadLine, $buyerApply=0)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$operateDate = date("Y-m-d H:i:s");
		$result = $TIRsdk->setBuyerDeadLineModel($replyId, $deadLine, $buyerApply);
		return $result? True :False;
	}

	/**
	 * 设置买家截止时间
	 */
	public function setSellerDeadLineSql($replyId, $deadLine, $sellerApply=0)
	{
		$TIRsdk = new \models\trans\InquiryReplyMod();
		$operateDate = date("Y-m-d H:i:s");
		$result = $TIRsdk->setSellerDeadLineModel($replyId, $deadLine, $sellerApply);
		return $result? True :False;
	}

	/**
	 * addInquiryReplyDetailSql
	 * 
	 * @return ReplyDetailId || False
	 *        
	 */
	public function addInquiryReplyDetailSql($replyId, $enameId, $replyStatus, $price, $message)
	{
		$TIRDsdk = new \models\trans\InquiryReplyDetailMod();
		$operateDate = date("Y-m-d H:i:s");
		$operateIp = \common\Common::getRequestIp();
		$replyDetailId = $TIRDsdk->addInquiryReplyDetailModel($replyId, $enameId, $replyStatus, $price, $message, 
			$operateDate, $operateIp);
		return intval($replyDetailId)?  :False;
	}

	public function inquiryCanelSql($enameId, $inquiryId, $inquiryOnsaleStatus, $inquiryEndsaleStatus, $flag = false)
	{
		$inquiryMod = new \models\trans\InquiryMod();
		$rs = $inquiryMod->getInquiryCanelIdModel($enameId, $inquiryId, $inquiryOnsaleStatus);
		if($rs)
		{
			if($inquiryMod->setInquiryCanelIdModel($enameId, $inquiryId, $inquiryOnsaleStatus, $inquiryEndsaleStatus))
			{
				return $flag? array('flag' => true,'domainName' => $rs['DomainName'],'msg' => \common\Lang::create('inquirymsg')->getMsg('660069')) :True;
			}
			else
			{
				return $flag? array('flag' => false,'domainName' => $rs['DomainName'],'msg' => \common\Lang::create('inquirymsg')->getMsg('660070')) :false;
			}
		}
		return $flag? array('flag' => false,'domainName' => \common\Lang::create('inquirymsg')->getMsg('660072'),'msg' => str_repalce('%%', $inquiryId, \common\Lang::create('inquirymsg')->getMsg('660071'))) :False;
	}
}


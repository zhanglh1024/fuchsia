<?php
namespace lib\trans\trans;
class InquiryReplyLib
{
	private $conf;
	private $inquirySqlLib;
	private $inquiryReplyDetailLib;
	private $inquiryLib;

	public function __construct()
	{
		// 加载配置
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'inquiry');
		$this->inquirySqlLib = new \lib\trans\trans\InquirySqlLib();
		$this->inquiryReplyDetailLib = new \lib\trans\trans\InquiryReplyDetailLib();
		$this->inquiryLib = new \lib\trans\trans\TransInquiryLib();
	}
//--------------------buyer--
	public function setBuyerReplyPrice($replyId,$enameId,$replyStatus,$price,$message)
	{
		if( $this->inquirySqlLib->setBuyerReplyPriceSql($replyId,$enameId,$replyStatus,$price ))
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}
	public function setBuyerAgreePrice($replyId,$enameId,$replyStatus,$price,$message,$buyerOrderId)
	{
		if( $this->inquirySqlLib->setBuyerAgreePriceSql($replyId,$enameId,$replyStatus,intval($price),$buyerOrderId))
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}

	public function setBuyerConfirmPrice($replyId,$enameId,$replyStatus,$price,$message,$buyerOrderId)
	{
		if( $this->inquirySqlLib->setBuyerConfirmPriceSql($replyId,$enameId,$replyStatus,$buyerOrderId))
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}

	public function setBuyerRefusePrice($replyId,$enameId,$replyStatus,$price,$message)
	{
	 	if( $this->inquirySqlLib->setBuyerRefusePriceSql($replyId,$enameId,$replyStatus,$price))
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}

	public function setBuyerPayAllPrice($replyId,$enameId,$replyStatus,$price,$message,$transOrderId)
	{
		if( $this->inquirySqlLib->setBuyerPayAllPriceSql($replyId,$enameId,$replyStatus,$transOrderId) )
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}

	public function setBuyerRedoInquiry($replyId,$enameId,$replyStatus,$price,$message,$transOrderId)
	{
		if( $this->inquirySqlLib->setBuyerRedoInquirySql($replyId,$enameId,$replyStatus,$transOrderId) )
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}
	public function setBuyerRefuseInquiry($replyId,$enameId,$replyStatus,$price,$message)
	{
		if( $this->inquirySqlLib->setBuyerRefuseInquirySql($replyId,$enameId,$replyStatus) )
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}
//---------------------seller--

	public function setSellerRefuseOrderId($replyId,$enameId,$sellerRefuseOrderId)
	{
		if( $this->inquirySqlLib->setSellerRefuseOrderIdSql($replyId,$enameId,$sellerRefuseOrderId))
		{
			return True;
		}
		return False;
	}
	
	public function setSellerRedoInquiry($replyId,$enameId,$replyStatus,$price,$message,$transOrderId)
	{
		if( $this->inquirySqlLib->setSellerRedoInquirySql($replyId,$enameId,$replyStatus,$transOrderId) )
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}
	public function setSellerAgreePrice($replyId,$enameId,$replyStatus,$price,$message,$sellerOrderId,$inquiryReg)
	{
		if( $this->inquirySqlLib->setSellerAgreePriceSql($replyId,$enameId,$replyStatus,intval($price),$sellerOrderId,$inquiryReg))
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,intval($price),$message);
		}
		return False;
	}
	public function setSellerAgreePriceQQDomain($replyId,$enameId,$replyStatus,$price,$message,$sellerOrderId)
	{
		if($this->inquirySqlLib->setSellerAgreePriceQQDomainSql($replyId, $enameId, $replyStatus, $price, $sellerOrderId))
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId, $enameId, $replyStatus, intval($price),$message);
		}
		return false;
	}
	
	public function setSellerConfirmPrice($replyId,$enameId,$replyStatus,$price,$message,$sellerOrderId,$inquiryReg)
	{
		if( $this->inquirySqlLib->setSellerConfirmPriceSql($replyId,$enameId,$replyStatus,intval($price),$sellerOrderId,$inquiryReg))
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}

	public function setSellerReplyPrice($replyId,$enameId,$replyStatus,$price,$message,$sellerRIO=0)
	{
		if( $this->inquirySqlLib->setSellerReplyPriceSql($replyId,$enameId,$replyStatus,$price,$sellerRIO))
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}

	public function setSellerRefusePrice($replyId,$enameId,$replyStatus,$price,$message)
	{
		if( $this->inquirySqlLib->setSellerRefusePriceSql($replyId,$enameId,$replyStatus))
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}

	public function setSellerConfirmDomain($replyId,$enameId,$replyStatus,$price,$message,$inquiryReg)
	{
		if( $this->inquirySqlLib->setSellerConfirmDomainSql($replyId,$enameId,$replyStatus,$inquiryReg))
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}
		
	public function setSellerRefuseInquiry($replyId,$enameId,$replyStatus,$price,$message,$sellerRefuseOrderId)
	{
		if( $this->inquirySqlLib->setSellerRefuseInquirySql($replyId,$enameId,$replyStatus,$sellerRefuseOrderId))
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}



//---------------------other--
	public function replyInfoLib($replyId,$enameId)
	{
		//检查是否有权限查看
		$data = $this->inquirySqlLib->checkReplyPremissions($replyId,$enameId);
		if($data['result'])
		{
			$data['info'] = $this->formatReplyInfo($data['info']);
			return $data['info'];
		}
		else
		{
			throw new \Exception(\common\Lang::create('inquirymsg')->getMsg('660032'), 660032);
		}
	}
	private function formatReplyInfo($data)
	{
		$data['BuyerPriceCn'] = intval($data['BuyerPrice']) ? intval($data['BuyerPrice']).'元' : '-';
		$data['SellerPriceCn'] = intval($data['SellerPrice']) ? intval($data['SellerPrice']).'元' : '-';
		$data['ReplyStatusCn'] = $this->inquiryLib->getReplyStatusCn($data['ReplyStatus']);
		$data['IsDomainInEnameCn'] = $this->inquiryLib->getIsDomainInEname($data['IsDomainInEname']);
		$data['ReplyStatusDeadLine'] = $this->inquiryLib->getReplyStatusDeadLine($data['ReplyStatus'],$data['OperateDate']);
		return $data;
	}
	public function isRightIdentity($identity,$enameId)
	{
		if($identity != $enameId)
		{
			throw new \Exception(\common\Lang::create('inquirymsg')->getMsg('660068'), 660068);
		}
		return True;
	}
	public function checkSellerInquiry($enameId,$inquiryId,$replyId)
	{
		$agreeInquiryArray = $this->conf->inquiry_seller_has_inquiry_status->toArray();
		$result = $this->inquirySqlLib->checkSellerInquirySql($agreeInquiryArray,$enameId,$inquiryId,$replyId);
		return $result ? True : False;
	}

	/**
	 * 买家转经纪交易
	 */
	public function setBuyerToEscrow($replyId,$enameId,$replyStatus,$price,$message)
	{
		if( $this->inquirySqlLib->setBuyerToEscrowSql($replyId,$enameId,$replyStatus))
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}

	/**
	 * 卖家转经纪交易
	 */
	public function setSellerToEscrow($replyId,$enameId,$replyStatus,$price,$message)
	{
		if( $this->inquirySqlLib->setSellerToEscrowSql($replyId,$enameId,$replyStatus))
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}

	/**
	 * 买家申请延期
	 */
	public function setBuyerApply($replyId,$enameId,$replyStatus,$applyStatus,$price,$message,$day)
	{
		if( $this->inquirySqlLib->setBuyerApplySql($replyId,$enameId,$applyStatus,$day))
		{
			return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
		}
		return False;
	}

	/**
	 * 卖家申请延期
	 */
	public function setSellerApply($replyId,$enameId,$replyStatus,$applyStatus,$price,$message,$day)
	{
		if( $this->inquirySqlLib->setSellerApplySql($replyId,$enameId,$applyStatus,$day))
		{
				return $this->inquiryReplyDetailLib->addReplyDetail($replyId,$enameId,$replyStatus,$price,$message);
			}
		return False;
	}

	/**
	 * 设置买家操作截止时间
	 */
	public function setBuyerDeadLine($replyId, $day, $time=0, $buyerApply=0)
	{
		$deadLine = $time ? strtotime("+".$day." days", $time) : strtotime("+".$day." days");
		return $this->inquirySqlLib->setBuyerDeadLineSql($replyId,$deadLine,$buyerApply);
	}
	/**
	 * 设置卖家操作截止时间
	 */
	public function setSellerDeadLine($replyId, $day, $time=0, $sellerApply=0)
	{
		$deadLine = $time ? strtotime("+".$day." days", $time) : strtotime("+".$day." days");
		return $this->inquirySqlLib->setSellerDeadLineSql($replyId,$deadLine, $sellerApply);
	}
}


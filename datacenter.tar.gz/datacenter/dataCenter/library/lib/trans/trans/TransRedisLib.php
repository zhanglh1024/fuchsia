<?php
	namespace lib\trans\trans;
	class TransRedisLib
	{
		private $TIsdk;
		private $TDsdk;
		private $conf;
		
		public function __construct()
		{
			$this->TIsdk = new \models\trans\redis\TransIndex();
			$this->TDsdk = new \models\trans\redis\TransDetailTrans();
			$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
		}
		/**
		 * 卖家取消交易删除redis
		 */
		public function doRedisSellerCancel($auditListId, $transTopic)
		{
			$key = $this->TIsdk->getAuditKeys($auditListId);
			$keys = $this->TIsdk->getKeys($key);
			if($keys && is_array($keys))
			{
				foreach($keys as $val) // 删除详细页及交易redis
				{
					$this->TIsdk->delRedis($val);
				}
		
				// 删除首页redis
				$transTopicConf = $this->conf->trans_transtopic->toArray();
				switch($transTopic)
				{
					case $transTopicConf['ebuy'][0]:
						$this->TIsdk->delIndexEbuyRedis();
						break;
					case $transTopicConf['topicshow'][0]:
						$this->TIsdk->delIndexTopicRedis();
						break;
					case $transTopicConf['parity'][0]:
						$this->TIsdk->delIndexParityRedis();
						break;
					case $transTopicConf['nice'][0]:
						$this->TIsdk->delIndexNiceRedis();
						break;
					default:
						return true;
				}
			}
			return true;
		}
		
		/**
		 * 用户出价更新交易redis
		 * @param unknown $auditListId
		 * @param unknown $transType
		 */
		public function doRedisPostAucAll($auditListId, $transType)
		{
			$TIsdk = new \models\trans\redis\TransIndex();
			$keys = $TIsdk->getAuctionInfoAll($auditListId);
			if($keys && is_array($keys))
			{
				if($transType == 3)
				{
					$TDAsdk = new \models\trans\BookAuctionMod();
				}
				else
				{
					$TDAsdk = new \models\trans\DomainAuctionMod();
				}
				$transInfo = $TDAsdk->getAuctionInfoByAuditListId($auditListId);
				$domain['AuditListId'] = $auditListId;
				$domain['DomainName'] = $transInfo['DomainName'];
				$domain['BidPrice'] = $transInfo['BidPrice'];
				$domain['FinishDate'] = $transInfo['FinishDate'];
				$domain['SimpleDec'] = $transInfo['SimpleDec'];
				$domain['Seller'] = $transInfo['Seller'];
				$domain['BidCount'] = $transInfo['BidCount'];
				$domain['TransType'] = $transInfo['TransType'];
				foreach($keys as $key)
				{
					if(strpos($key, 'auction_comingend'))
					{
						$ttl = $this->TIsdk->getTtl($key);
						if($ttl < 1)
							$ttl = 1;
						$TIsdk->setValue($key, $domain, $ttl);
					}
					elseif(strpos($key, 'auction_recommend'))
					{
						$ttl = $this->TIsdk->getTtl($key);
						if($ttl < 1)
							$ttl = 1;
						$TIsdk->setValue($key, $domain, $ttl);
					}
					elseif(strpos($key, 'book_comingend'))
					{
						$ttl = $this->TIsdk->getTtl($key);
						if($ttl < 1)
							$ttl = 1;
						$TIsdk->setValue($key, $domain, $ttl);
					}
					else
					{
						$TIsdk->setValue($key, $domain);
					}
				}
			}
		}
		
		/**
		 * 判断详细页 易拍易卖是否存在redis
		 * @return boolean
		 */
		public function isExistsEbuyRedis()
		{
			$data = $this->TDsdk->getEbuyKeys();
			if($data)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/**
		 *  设置详细页 易拍易卖读取数据库
		 * @param array $transTopic
		 * @param array $transStatus
		 */
		public function setDetailEbuyRedis($transTopic, $transStatus)
		{
			$i = 1;
			while(!($this->TDsdk->getEbuyKeys()) && $i <= 3)
			{
				if($this->TDsdk->getEbuyStatus())
				{
					sleep(1);
				}
				else
				{
					$TDAsdk = new \models\trans\DomainAuctionMod();
					$this->TDsdk->setEbuyStatus();
					$data = $TDAsdk->getEbuyAllModel($transTopic['ebuy'][0], $transStatus['trading'][0]);
					$this->setEbuyBIgRedis($data);
					$this->TDsdk->delEbuyStatus();
					break;
				}
				$i++;
			}
		}
		/**
		 * 设置易拍易卖大块redis名称
		 */
		public function setEbuyBIgRedis($data, $timeout = 0)
		{
			if($data && is_array($data))
			{
				foreach($data as $key => $val)
				{
					$domain['AuditListId'] = $val['AuditListId'];
					$domain['DomainName'] = $val['DomainName'];
					$domain['BidPrice'] = $val['BidPrice'];
					$domain['FinishDate'] = $val['FinishDate'];
					$domain['SimpleDec'] = $val['SimpleDec'];
					$domain['Seller'] = $val['Seller'];
					$domain['BidCount'] = $val['BidCount'];
					$domain['TransType'] = $val['TransType'];
					$status = $this->TIsdk->setEbuyBigRedis($val['SysGroupOne'], $val['AuditListId'], $val['Topic'], $val['FinishDateFlag'], $domain);
					if(!$status)
						\core\Log::write("设置易拍易卖trans_index_auditList_ebuy_".$val['AuditListId'] . '的redis失败','trans','redis');
					}
					if($timeout > 0)
					{
						$auditListId[] = $val['AuditListId'];
					}
				}
				if($timeout > 0)
				{
					$status = $this->TIsdk->setEbuySamllRedis($timeout, $auditListId);
					if(!$status)
					{
						\core\Log::write('设置首页易拍易卖trans_index_ebuy_list的redis失败','trans','redis');
					}
					return $auditListId;
				}
				return true;
			return false;
		}
		
		/**
		 * 获取易拍易卖详细页 ByTopic
		 */
		public function getEbuyDetailKeyName($topic, $day)
		{
			return $this->TDsdk->getEbuyDetailKeyName($topic, $day);
		}
		
		/**
		 * 获取专题对应的域名id
		 */
		public function getAuditListIdsByTopic($keyName)
		{
			$auditListIds = $finishDate = array();
			if(!empty($keyName))
			{
				$keys = $this->TIsdk->getKeys($keyName);
				$keysValue = $this->TIsdk->getKeysValue($keys);
				if($keysValue)
				{
					foreach($keysValue as $k => $v)
					{
						$auditListIds[$k] = $v['AuditListId'];
						$finishDate[$k] = $v['FinishDate'];
					}
				}
				if($finishDate && $auditListIds)
					array_multisort($finishDate, $auditListIds);
			}
			return $auditListIds;
		}
		/**
		 * 通过专题的获取推荐域名的id
		 */
		public function getBestAuditListIdsByTopic($transtopicId, $topic, $day)
		{
			$auditListIds = array();
			if(!empty($topic))
			{
				$keysName = $this->TIsdk->getBestAuditList($transtopicId, $topic, $day);
				if($keysName)
				{
					$keysName = $this->sortByTtl($keysName);
					$keysValue = $this->TIsdk->getKeysValue($keysName);
					if($keysValue)
					{
						$auditListIds = $keysValue;
					}
				}
		
			}
			return $auditListIds;
		}
		/**
		 * 通过id格式和不同专题类别的域名
		 */
		public function getDomainByTopicId($arr, $transTopic, $bestCount)
		{
			$plib = new \lib\trans\common\PublicLib();
			$domainList = array();
			$i = 0;
			if($arr)
			{
				foreach($arr as $v)
				{
					$keyName = $this->TIsdk->getAuditList($transTopic, $v);
					if(isset($keyName[0]))
					{
						$domainList[$i] = $this->TIsdk->getRedis($keyName[0]);
						$domainList[$i]['is_hot'] = $i < $bestCount ? 1 : 0;
						$domainList[$i]['FinishDate'] = $plib->NewTimeToDHIS(strtotime($domainList[$i]['FinishDate']) - time());
						$i++;
					}
				}
			}
			return $domainList;
		}
		/**
		 * 判断详细页 专题拍卖是否存在redis
		 */
		public function isExistsTopicRedis()
		{
			$data = $this->TDsdk->getTopicKeys();
			if($data)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/**
		 * 设置详细页 专题拍卖读取数据库
		 */
		public function setDetailTopicRedis($transTopic, $transStatus)
		{
			$i = 1;
			while(!($this->TDsdk->getTopicKeys()) && $i <= 3)
			{
				if($this->TDsdk->getTopicStatus())
				{
					sleep(1);
				}
				else
				{
					$TDAsdk = new \models\trans\DomainAuctionMod();
					$this->TDsdk->setTopicStatus();
					$data = $TDAsdk->getEbuyAllModel($transTopic['topicshow'][0], $transStatus['trading'][0]);
					$this->setTopicBIgRedis($data);
					$this->TDsdk->delTopicStatus();
					break;
				}
				$i++;
			}
		}
		/**
		 * 设置专题拍卖大块redis名称
		 */
		public function setTopicBIgRedis($data, $timeout = 0)
		{
			if($data && is_array($data))
			{
				foreach($data as $key => $val)
				{
					$domain['AuditListId'] = $val['AuditListId'];
					$domain['DomainName'] = $val['DomainName'];
					$domain['BidPrice'] = $val['BidPrice'];
					$domain['FinishDate'] = $val['FinishDate'];
					$domain['SimpleDec'] = $val['SimpleDec'];
					$domain['Seller'] = $val['Seller'];
					$domain['BidCount'] = $val['BidCount'];
					$domain['TransType'] = $val['TransType'];
					$status = $this->TIsdk->setTopicBigRedis($val['SysGroupOne'], $val['AuditListId'], $val['Topic'], $val['FinishDateFlag'], $domain);
					if(!$status)
					{
						\core\Log::write('设置专题拍卖trans_index_auditList_topic_' . $val['AuditListId'] . '的redis失败','trans','redis');
					}
					if($timeout > 0)
					{
						$auditListId[] = $val['AuditListId'];
					}
				}
				if($timeout > 0)
				{
					$status = $this->TIsdk->setTopicSamllRedis($timeout, $auditListId);
					if(!$status)
					{
						\core\Log::write('设置首页专题拍卖trans_index_topic_list的redis失败','trans','redis');
					}
					return $auditListId;
				}
				return true;
			}
			return false;
		}
		/**
		 * 获取专题拍卖详细页 ByTopic
		 */
		public function getTopicDetailKeyName($topic, $day)
		{
			return $this->TDsdk->getTopicDetailKeyName($topic, $day);
		}
		
		/**
		 * 数组根据过期时间来排序
		 * @param unknown_type $keys
		 * @return unknown array
		 */
		public function sortByTtl($keys)
		{
			$keyList = array();
			$ttl = array();
			$keysArr = array();
			if($keys)
			{
				foreach($keys as $k => $v)
				{
					$keyList[$k]['key'] = $v;
					$keyList[$k]['ttl'] = $this->TIsdk->getTtl($v);
					$ttl[$k] = $this->TIsdk->getTtl($v);
				}
			}
			if($keyList && $ttl)
			{
				array_multisort($ttl, SORT_ASC, $keyList);
				foreach($keyList as $v)
				{
					$keysArr[] = $v['key'];
				}
			}
			return $keysArr;
		}
	}
?>
<?php
namespace lib\trans\fabu;

class FabuWeightLib
{

	private $enameId;

	private $conf;

	public function __construct($enameId)
	{
		// 加载配置
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
		$this->enameId = $enameId;
	}

	/**
	 * 根据后缀获取权重
	 */
	public function getTldWeight($tld, $weight = 1)
	{
		if($tld == 3) // .com
		{
			$weight = $weight * 5;
		}
		elseif($tld == 2 || $tld == 6) // .cn(包括 中文.cn)
		{
			$weight = $weight * 3;
		}
		elseif(in_array($tld, array(1,4))) // .com.cn/.net
		{
			$weight = $weight * 2;
		}
		elseif(in_array($tld, array(5,11,21,22))) // .org/.cc/.net.cn/.org.cn
		{
			$weight = $weight * 1.5;
		}
		return $weight;
	}

	/**
	 * 根据分组获取权重
	 */
	public function getGroupWeight($groupOne, $groupTwo, $length, $weight = 1)
	{
		if(in_array($groupOne, array(1,101)) && in_array($length, array(1,2))) // 单数字/单字母/双数字/双字母
		{
			$weight = $weight * 10;
		}
		elseif(($groupOne == 1 && $length == 3) || $groupTwo == 1) // 三数字/单拼
		{
			$weight = $weight * 5;
		}
		elseif(($groupOne == 1 && $length == 4) || ($groupOne == 101 && $length == 3) || $groupTwo == 2 || $groupOne ==
			 202) // 四数字/三字母/双拼/二杂
		{
			$weight = $weight * 4;
		}
		elseif(($groupOne == 1 && $length == 5) || ($groupOne == 101 && $length == 4) || $groupTwo == 3) // 五数字/四字母/三拼
		{
			$weight = $weight * 3;
		}
		elseif(in_array($groupOne, array(1,101,203))) // 纯数字/纯字母/三杂
		{
			$weight = $weight * 2;
		}
		return $weight;
	}

	/**
	 * 根据专题获取权重
	 */
	public function getTransTopicWeight($transTopic, $weight = 1)
	{
		$topicConf = $this->conf->trans_transtopic->toArray();
		if($transTopic == $topicConf['parity'][0] || $transTopic == $topicConf['nice'][0]) // 平价域名/精品域名
		{
			$weight = $weight * 2;
		}
		return $weight;
	}

	/**
	 * 根据注册商获取权重
	 */
	public function getRegWeight($reg, $weight = 1)
	{
		$regConf = $this->conf->fabu_reg->toARray();
		if($reg == $regConf['inename'][0]) // 易名
		{
			$weight = $weight * 2;
		}
		return $weight;
	}

	/**
	 * 根据卖家信用和好评率获取权重
	 */
	public function getSellerLevelWeight($grade, $rate, $weight = 1)
	{
		// 信用
		$weight = $weight * (1 + $grade / 10);
		// 好评率
		$weight = $weight * (1 + $rate);
		return $weight;
	}

	/**
	 * 根据交易成交率获取权重
	 */
	public function getDealRateWeight($dealRate, $weight = 1)
	{
		if($dealRate)
		{
			$dealRate = ($dealRate < 0.001)? 0.001 :$dealRate;
			$weight = $weight * (1 + round(log10($dealRate * 1000), 2));
		}
		return $weight;
	}

	/**
	 * 根据最近交易成功量获取权重
	 */
	public function getRecentlyDealWeight($cnt, $weight = 1)
	{
		$shopLib = new \lib\trans\shop\ShopLib();
		$data = $shopLib->getImage($cnt, 'seller');
		$weight = $weight * (1 + $data['grade'] / 10);
		return $weight;
	}

	/**
	 * 根据每天熵增获取权重
	 */
	public function getEntropyWeight($day, $weight = 1)
	{
		$weight = $weight * (1 + $day * 0.01);
		return $weight;
	}

	/**
	 * 获取域名类型
	 */
	private function getDomainType($domain, $groupOne, $length)
	{
		if($groupOne == 1)
		{
			if(strpos('4', $domain) !== FALSE)
				return 1; // 带4
			else
				return 2; // 不带4
		}
		if($groupOne == 101)
		{
			$domainArr = str_split($domain);
			$arr = array('a','e','i','o','u','v');
			if(array_intersect($arr, $domainArr))
			{
				if(strpos('v', $domain) !== FALSE)
					return 3; // 非纯声母(带v)
				else
					return 4; // 带韵母(不带v)
			}
			else
				return 5; // 纯声母
		}
		if($groupOne == 201)
		{
			if($length == 3)
			{
				if(preg_match('/^[a-zA-Z][0-9][a-zA-Z]$/', $domain) || preg_match('/^[0-9][a-zA-Z][0-9]$/', $domain))
					return 6; // 夹杂
				else
					return 7; // 非夹杂
			}
		}
		return 0;
	}

	/**
	 * 根据价格获取权重
	 */
	public function getPriceWeight($price, $domain, $groupOne, $tld, $length, $weight = 1)
	{
		$typeConf = $this->conf->fabu_price->toArray();
		$type = $this->getDomainType($domain, $groupOne, $length);
		$key = $groupOne . '_' . $length . '_' . $tld . '_' . $type;
		if(!empty($typeConf[$key]))
		{
			$tmp = log10(10 * ($typeConf[$key][0] / $price));
			if($tmp > 10)
				$tmp = 10;
			elseif($tmp < 0.1)
				$tmp = 0.1;
			$weight = $weight * round($tmp, 1);
		}
		return $weight;
	}

	/**
	 * 获取权重
	 */
	public function getWeight($tld, $groupOne, $groupTwo, $length, $transTopic, $reg, $grade, $rate, $dealRate, $cnt, 
		$day, $price, $domain)
	{
		$weight = $this->getTldWeight($tld);
		$weight = $this->getGroupWeight($groupOne, $groupTwo, $length, $weight);
		$weight = $this->getTransTopicWeight($transTopic, $weight);
		$weight = $this->getRegWeight($reg, $weight);
		$weight = $this->getSellerLevelWeight($grade, $rate, $weight);
		$weight = $this->getDealRateWeight($dealRate, $weight);
		$weight = $this->getRecentlyDealWeight($cnt, $weight);
		$weight = $this->getEntropyWeight($day, $weight);
		$weight = $this->getPriceWeight($price, $domain, $groupOne, $tld, $length, $weight);
		return round($weight);
	}

	/**
	 * 卖家信用和好评率
	 */
	public function getUserLevel()
	{
		$shopLib = new \lib\trans\shop\ShopLib();
		$user = $shopLib->getUserLevel($this->enameId);
		$data['grade'] = empty($user['sellerLevel']['grade'])? 0 :$user['sellerLevel']['grade'];
		$data['rate'] = empty($user['sellerLevel']['rate'])? 0 :$user['sellerLevel']['rate'];
		return $data;
	}

	/**
	 * 交易成交率
	 */
	public function getDealRate()
	{
		$statusConf = $this->conf->trans_status->toArray();
		$TDAsdk = new \models\trans\DomainAuctionMod();
		$year = date('Y');
		$allCnt = $TDAsdk->getAuctionCnt($this->enameId)?  :0;
		$successCnt = $TDAsdk->getAuctionCnt($this->enameId, $statusConf['successtrans'][0])?  :0;
		for($y = 2012; $y <= $year; $y ++)
		{
			$allCnt += $TDAsdk->getAuctionCnt($this->enameId, 0, $year)?  :0;
			$successCnt += $TDAsdk->getAuctionCnt($this->enameId, $statusConf['successtrans'][0], $year)?  :0;
		}
		return $allCnt? round($successCnt / $allCnt, 3) :0;
	}
	
	/**
	 * 近30天成交数量
	 */
	public function getRecentlyDealCnt($day=30)
	{
		$statusConf = $this->conf->trans_status->toArray();
		$TDsdk = new \models\trans\DeliveryMod();
		$finishDate = date("Y-m-d H:i:s", strtotime("-$day days"));
		return $TDsdk->getAuctionCnt($this->enameId, $statusConf['successtrans'][0], $finishDate) ?: 0;
	}
	
	/**
	 * 每天熵增
	 */
	public function getEntropy()
	{
		$today = strtotime(date('Y-m-d'));
		$sDay = strtotime(date('2013-10-10'));
		$day = ($today-$sDay)/86400;
		return $day;
	}
	
}
?>
<?php

namespace lib\trans\buyer;

class BuyerFinanceLib
{
	private $finance;
	private $conf;

	public function __construct($enameId)
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
		$this->finance = new \interfaces\trans\Finance($enameId);
	}
	public function transBuyerOrder($domainName,$financeType,$price,$linkEnameId,$oldOrderId='')
	{
		$orderId = $this->finance->addOrder($domainName,$financeType,$price,$linkEnameId,$oldOrderId);
		return $orderId ? : False;
	}
	
}
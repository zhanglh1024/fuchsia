<?php
	namespace lib\trans\shop;
	
	class ShopRedisLib
	{
		/**
		 * 论坛店铺推荐域名，信息更新队列
		 * @param unknown $EnameId
		 */
		public function setShopDomainQueue($enameId)
		{
			if($enameId)
			{
				$SIsdk = new \models\trans\redis\ShopIndex();
				$list = $SIsdk->getShopDomainQueue();
				if(in_array($enameId, $list)==false)
					$SIsdk->setShopDomainQueue($enameId);
			}
			return TRUE;
		}
		
		/**
		 * 论坛店铺，信息更新队列
		 * @param unknown $EnameId
		 */
		public function setShopQueue($enameId)
		{
			if($enameId)
			{
				$SIsdk = new \models\trans\redis\ShopIndex();
				$list = $SIsdk->getShopQueue();
				if(in_array($enameId, $list)==false)
				{
					\core\Log::write("setShopQueue,$enameId",'trans','shopredis');
					$SIsdk->setShopQueue($enameId);
				}
			}
			return TRUE;
		}
	}
?>
<?php
namespace lib\trans\shop;

use core\Response;
use models\trans\DomainAuctionMod;
use models\trans\ShopTagsMod;
class ShopLib
{

	private $conf;

	public function __construct()
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'shop');
	}

	/**
	 * 判断关注店铺是否属于用户
	 * 
	 * @param int $enameId        	
	 * @param int $uid        	
	 */
	public function isYourShopFavorite($enameId, $uid)
	{
		$shopFavoriteMod = new \models\trans\ShopFavoriteMod();
		
		return $shopFavoriteMod->getShopFavoriteListCn($enameId, $uid);
	}

	/**
	 * 删除关注店铺
	 * 
	 * @param int $enameId        	
	 * @param int $uid        	
	 * @return boolean
	 */
	public function delShopFavorite($enameId, $uid)
	{
		$shopFavoriteMod = new \models\trans\ShopFavoriteMod();
		
		return $shopFavoriteMod->delShopFavorite($enameId, $uid);
	}

	/**
	 * 判断店铺是否存在
	 *
	 * @param unknown $enameId        	
	 * @return Ambigous <\models\trans\Ambigous, multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function isShopExist($shopUid)
	{
		$customerShopMod = new \models\trans\CustomerShopMod();
		
		return $customerShopMod->getShopInfo($shopUid);
	}

	/**
	 * 判断是否已经关注过了
	 *
	 * @param unknown $enameId        	
	 * @param unknown $shopUid        	
	 * @return Ambigous <boolean, mixed>
	 */
	public function isShopFavorite($enameId, $shopUid)
	{
		$shopFavoriteMod = new \models\trans\ShopFavoriteMod();
		
		return $shopFavoriteMod->isShopFavorite($enameId, $shopUid);
	}

	/**
	 * 关注店铺信息入库
	 *
	 * @param unknown $enameId        	
	 * @param unknown $shopUid        	
	 * @return Ambigous <string, boolean, unknown>
	 */
	public function addShopFavorite($enameId, $shopUid)
	{
		$shopFavoriteMod = new \models\trans\ShopFavoriteMod();
		
		return $shopFavoriteMod->addShopFavorite($shopUid, $enameId);
	}

	/**
	 * 初始化店铺标签
	 */
	public function initShopTag($conf, $enameId)
	{
		$shopTagsMod = new \models\trans\ShopTagsMod();
		if($shopTagsMod->checkIsTagInit($enameId))
		{
			return true;
		}
		else
		{
			$initTags = $conf->shop_tags_init;
			foreach($initTags as $tag)
			{
				$shopTagsMod->addTag($enameId, $tag['name'], $tag['value'], $tag['tag_trans_type'], 
					$tag['display_type'], $tag['tag_type'], $tag['sort'], $tag['trans_type'], $tag['status']);
			}
		}
	}

	/**
	 * 检查标签名是否存在
	 */
	public function checkTagName($enameId, $id, $tagName)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'shop');
		$tagStatusConf = $conf->shop_tag_status->toArray();
		$shopTagsMod = new \models\trans\ShopTagsMod();
		if($shopTagsMod->checkTagName($enameId, $id, $tagName, $tagStatusConf['del'][0]))
			return FALSE;
		return TRUE;
	}

	/**
	 * 检查标签下是否有交易的域名
	 */
	public function checkTagTrans($enameId, $tagValue, $tagTransType)
	{
		// 加载配置
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'shop');
		
		$transTypeConf = $conf->shop_tag_trans_type->toArray();
		if($tagTransType == $transTypeConf['auction'][0])
		{
			$domainAuctionMod = new \models\trans\DomainAuctionMod();
			$cnt = $domainAuctionMod->getAuctionCntByTag($enameId, $tagValue);
			if($cnt)
			{
				return true;
			}
		}
		else
		{
			$inquiryMod = new \models\trans\InquiryMod();
			$cnt = $inquiryMod->getInquiryCntByTag($enameId, $tagValue);
			if($cnt)
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * 检查标签下是否有正在交易的域名
	 */
	public function checkTagAuction($enameId, $tagValue, $tagTransType)
	{
		// 加载配置
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'shop');
		
		$transTypeConf = $conf->shop_tag_trans_type->toArray();
		$statusConf = $conf->trans_status->toArray();
		if($tagTransType == $transTypeConf['auction'][0])
		{
			$domainAuctionMod = new \models\trans\DomainAuctionMod();
			$cnt = $domainAuctionMod->getAuctionCntByTag($enameId, $tagValue);
			if($cnt)
			{
				Response::error('此标签下有存在正在交易的域名');
			}
			
			$transStatus = array($statusConf['buyerabandon'][0],$statusConf['sellerabandon'][0],
				$statusConf['reserverabandon'][0],$statusConf['tradecanel'][0],$statusConf['sellercanel'][0],
				$statusConf['admincanel'][0]);
			$transStatus = implode(',', $transStatus);
			// 检查下架列表中是否存在该标签
			if($domainAuctionMod->checkDownTransTag($enameId, $transStatus, $tagValue))
			{
				// 取消下架中交易中的该标签
				if(false === $domainAuctionMod->cancelDownTransTag($enameId, $transStatus, $tagValue))
				{
					\core\Log::write('delTransTag:' . $tagValue . '|' . $enameId, 'shopLib/checkTagAuction','trans','shop');
					Response::error('取消下架列表中的标签失败');
				}
			}
		}
		else
		{
			$inquiryMod = new \models\trans\InquiryMod();
			$cnt = $inquiryMod->getInquiryCntByTag($enameId, $tagValue);
			if($cnt)
			{
				Response::error('此标签下有存在正在交易的域名');
			}
			// 检查是否存在该标签
			if($inquiryMod->checkInquiryTag($enameId, $tagValue))
			{
				// 取消询价中所有交易下的该标签
				if(false === $inquiryMod->delAllInquiryTag($enameId, $tagValue))
				{
					\core\Log::write('delTransTag:' . $tagValue . '|' . $enameId, 'shopLib/checkTagAuction','trans','shop');
					Response::error('取消询价列表中的标签失败');
				}
			}
		}
		return true;
	}

	/**
	 * 获取标签值（添加新标签）
	 */
	public function getTagValue($tags, $valueNum)
	{
		$allValues = $values = array();
		if(count($tags) < $valueNum)
		{
			if($tags)
			{
				foreach($tags as $tag)
				{
					if($tag['Value'])
						$values[] = $tag['Value'];
				}
			}
			for($i = 1; $i <= $valueNum; $i ++)
			{
				$allValues[] = pow(2, $i);
			}
			
			$diffValues = array_diff($allValues, $values);
			if($diffValues)
				return reset($diffValues);
		}
		Response::error('最多只能设置' . $valueNum . '个自定义标签');
	}

	/**
	 * 获取用户店铺信息
	 *
	 * @param unknown_type $enameId        	
	 */
	Public function getCustomerShopInfo($enameId)
	{
		$TCS = new \models\trans\CustomerShopMod();
		return $TCS->getCustomerShopInfo($enameId);
	}

	/**
	 * 获取用户信息
	 *
	 * @param unknown_type $enameId        	
	 */
	public function getMembershipInfo($enameId)
	{
		$TMI = new \models\trans\MemberShipInfoMod();
		return $TMI->getMembershipInfo($enameId);
	}

	/**
	 * 结束的交易写入待评价列表
	 * 
	 * @param unknown_type $buyer        	
	 * @param unknown_type $seller        	
	 * @param unknown_type $auditListId        	
	 * @param unknown_type $transStatus        	
	 * @param unknown_type $domainName        	
	 * @param unknown_type $price        	
	 */
	public function addTransForEvaluate($buyer, $seller, $auditListId, $transStatus, $domainName, $price, 
		$nickName = FALSE)
	{
		$transCustomerShopRate = new \models\trans\CustomerShopRateMod();
		$isExist = $transCustomerShopRate->getCntByAuditListId($auditListId);
		if($isExist)
		{
			\core\Log::write("$auditListId|$domainName,已经写入过评价表,失败",'trans','shop');
			return false;
		}
		
		// 获取买家昵称
		if(FALSE === $nickName)
		{
			$TDAsdk = new \models\trans\DomainAuctionMod();
			$info = $TDAsdk->getByAuditListId($auditListId, 'NickName');
			$nickName = isset($info['NickName'])? $info['NickName'] :$buyer;
		}
		return $transCustomerShopRate->addTransForEvaluate($buyer, $seller, $auditListId, $transStatus, $domainName, 
			$price, $nickName);
	}

	/**
	 * 获取用户好评率
	 * 
	 * @param int $enameId        	
	 */
	public function getUserGoodRate($enameId)
	{
		$TMI = new \models\trans\MemberShipInfoMod();
		$userInfo = $TMI->getMembershipInfo($enameId);
		
		// 卖家好评率
		if($userInfo['SellerGoodLevel'] == 0 && $userInfo['SellerBadLevel'] == 0)
		{
			$sellerGoodRate = '';
		}
		else
		{
			$sellerGoodRate = round(
				$userInfo['SellerGoodLevel'] / ($userInfo['SellerGoodLevel'] + $userInfo['SellerBadLevel']) * 100, 2) .
				 "%";
		}
		// 买家好评率
		if($userInfo['BuyerGoodLevel'] == 0 && $userInfo['BuyerBadLevel'] == 0)
		{
			$buyerGoodRate = '';
		}
		else
		{
			$buyerGoodRate = round(
				$userInfo['BuyerGoodLevel'] / ($userInfo['BuyerGoodLevel'] + $userInfo['BuyerBadLevel']) * 100, 2) . "%";
		}
		return array('sellerGoodRate' => $sellerGoodRate,'buyerGoodRate' => $buyerGoodRate);
	}

	/**
	 * 获取用户信用
	 * 
	 * @param int $enameId        	
	 */
	public function getUserLevel($enameId)
	{
		$TMI = new \models\trans\MemberShipInfoMod();
		$transEvaluate = $this->conf->trans_evaluate->toArray();
		$rs = $TMI->getUserLevel($enameId);
		$sellerLevel = intval($rs['SellerGoodLevel']) * intval($transEvaluate['good']) -
			 intval($rs['SellerBadLevel']) * intval($transEvaluate['bad']);
		$buyerLevel = intval($rs['BuyerGoodLevel']) * intval($transEvaluate['good']) -
			 intval($rs['BuyerBadLevel']) * intval($transEvaluate['bad']);
		$sellerLevelArr = self::getImage(intval($sellerLevel), 'seller');
		$buyerLevelArr = self::getImage(intval($buyerLevel), 'buyer');
		// 卖家好评率
		if($rs['SellerGoodLevel'] == 0 && $rs['SellerBadLevel'] == 0)
			$sellerGoodRate = 0;
		else
			$sellerGoodRate = round($rs['SellerGoodLevel'] / ($rs['SellerGoodLevel'] + $rs['SellerBadLevel']), 2);
			// 买家好评率
		if($rs['BuyerGoodLevel'] == 0 && $rs['BuyerBadLevel'] == 0)
			$buyerGoodRate = 0;
		else
			$buyerGoodRate = round($rs['BuyerGoodLevel'] / ($rs['BuyerGoodLevel'] + $rs['BuyerBadLevel']), 2);
		
		return array(
			'sellerLevel' => array('num' => $sellerLevelArr['num'],'img' => $sellerLevelArr['img'],
				'level' => $sellerLevelArr['level']),
			'buyerLevel' => array('num' => $buyerLevelArr['num'],'img' => $buyerLevelArr['img'],
				'level' => $buyerLevelArr['level']));
	}

	/**
	 * 用户信息更新
	 *
	 * @param unknown_type $enameId        	
	 */
	public function updateMembershipInfo($enameId, $email, $qq, $phone, $weixin)
	{
		$TMI = new \models\trans\MemberShipInfoMod();
		$rs = $TMI->updateMembershipInfo($enameId, $email, $qq, $phone, $weixin);
		if(!$rs)
		{
			// 写日志
			\core\Log::write("用户ID" . $enameId . "更新用户（店主）信息失败",'trans','shop');
			return false;
		}
		return true;
	}

	/**
	 * 店铺信息更新
	 * 
	 * @param unknown_type $enameId        	
	 */
	public function updateCustomerShop($enameId, $shopName, $shopLogo, $shopAnnounce, $status)
	{
		$TCS = new \models\trans\CustomerShopMod();
		
		$oldInfo = $TCS->getCustomerShopInfo($enameId);
 	 if($oldInfo['Avatar']!=$shopLogo && $shopLogo)
		{
			$KWA= new \models\trans\KeyWordsAuditMod();
			$shopNameFlag =  $this->checkWord($shopName);
			$shopAnnounceFlag =  $this->checkWord($shopAnnounce);
			$tshopName = $shopNameFlag? $shopName:'';
			$tshopAnnounce = $shopAnnounceFlag ? $shopAnnounce:'';
			$shopAuditCount = $KWA->getAuditCount($enameId, $oldInfo['CustomerShopId']);
			//获取有没有审核过 ,有的话更新,没有的话添加审核记录
			if($shopAuditCount)
			{
				$KWA->updateAuditInfo($enameId, $shopLogo, $tshopName, $tshopAnnounce, $oldInfo['CustomerShopId'], 1);
			}
			else 
			{
			 $KWA->sadd($enameId, $shopLogo, $tshopName, $tshopAnnounce, $oldInfo['CustomerShopId'], 1);
			}
		} 
		
$rs = $TCS->updateCustomerShopInfo($enameId, $shopName, $shopLogo, $shopAnnounce, $status);
if(!$rs)
{
	// 写日志
	\core\Log::write("用户ID" . $enameId . "更新店铺信息失败", 'trans', 'shop');
	return false;
}
return true;
	}

	/**
	 * 检查店铺状态
	 * 
	 * @param $userId 店铺用户ID        	
	 * @param $enameId 当前用户        	
	 */
	public function checkShopStatus($userId, $enameId, $shopStatus = 0)
	{
		if(!$shopStatus)
		{
			$info = $this->getCustomerShopInfo($userId);
			if(!$info)
				throw new \Exception('找不到该店铺');
			$shopStatus = $info['Status'];
		}
		// 店铺状态
		$statusConf = $this->conf->shop_status->toArray();
		if($shopStatus == $statusConf['admincancel'][0])
		{
			throw new \Exception('该店铺违规，已经关闭');
		}
		elseif($shopStatus == $statusConf['hide'][0])
		{
			if(empty($enameId) || (!empty($enameId) && $enameId != $userId))
				throw new \Exception('该用户没有启用店铺');
		}
		return TRUE;
	}

	/**
	 * 获取店铺首页标签下的交易
	 * 
	 * @param unknown $displayType        	
	 */
	public function getTagsTransIndex($enameId, $tagId, $displayType, $per_page = 0)
	{
		// 店铺首页
		// 获取店铺所有显示标签
		$statusConf = $this->conf->shop_tag_status->toArray();
		$tagTransTypeConf = $this->conf->shop_tag_trans_type->toArray();
		$shopTags = $this->getShopTags($enameId, $statusConf['show'][0]);
		
		// 格式化json
		$shopTags = $this->transTypeisJson($shopTags);
		
		// 获取标签下的交易
		$result = $sData = $showTags = array();
		if($displayType == 1)
		{
			// 选项卡
			if($tagId)
			{
				$shopTag = $this->getShopTagById($enameId, $tagId, $statusConf['show'][0]);
				if(!$shopTag)
				{
					throw new \Exception('未找到相关标签');
				}
				else
				{
					$showTags = $this->getShowTags($shopTags, $enameId);
					$sData = $this->getTagAucitonWithTag($enameId, $shopTag, $per_page);
				}
			}
			else
			{
				list($sData, $showTags) = $this->getTagAuctionWithTags($enameId, $shopTags, $displayType, $per_page);
			}
		}
		else
		{
			// 块状
			list($sData, $showTags) = $this->getTagAuctionWithTags($enameId, $shopTags, $displayType);
		}
		$result['showTags'] = $showTags;
		$result['data'] = $sData;
		return $result;
	}

	/**
	 * 获取店铺的指定标签
	 */
	public function getShopTagById($enameId, $id, $status = '')
	{
		$TSTsdk = new \models\trans\ShopTagsMod();
		return $TSTsdk->getShopTag($enameId, $id, $status);
	}

	/**
	 * 获取选项卡有效标签
	 * 
	 * @param array $shopTags        	
	 * @param int $enameId        	
	 * @return array
	 */
	public function getShowTags($shopTags, $enameId)
	{
		$showTags = array();
		if($shopTags)
		{
			$getNum = $this->conf->shop_auction_num;
			$tagTransTypeConf = $this->conf->shop_tag_trans_type->toArray();
			$TDAsdk = new \models\trans\DomainAuctionMod();
			$TIsdk = new \models\trans\InquiryMod();
			foreach($shopTags as $tags)
			{
				if($tags['Value'])
				{
					// 有标签值
					if($tags['TagTransType'] == $tagTransTypeConf['auction'][0])
					{
						$cnt = $TDAsdk->getAuctionCntByTag($enameId, $tags['Value']);
					}
					else
					{
						$cnt = $TIsdk->getInquiryCntByTag($enameId, $tags['Value']);
					}
					if($cnt)
					{
						$showTags[] = $tags; // 选项卡过滤无数据标签
					}
				}
				else
				{
					// 无标签值（系统标签，除推荐标签外）
					if($tags['TagTransType'] == $tagTransTypeConf['auction'][0])
					{
						$cnt = $TDAsdk->getAuctionCntByTransType($enameId, $tags['TransType']);
					}
					else
					{
						$cnt = $TIsdk->getInquiryCnt($enameId, $tags['Value']);
					}
					if($cnt)
					{
						$showTags[] = $tags; // 选项卡过滤无数据标签
					}
				}
			}
		}
		return $showTags;
	}

	public function getTagAucitonWithTag($enameId, $shopTag, $per_page = 0)
	{
		// 带标签
		$TDAsdk = new \models\trans\DomainAuctionMod();
		$TIsdk = new \models\trans\InquiryMod();
		$pLib = new \lib\trans\common\PublicLib();
		$tagTypeConf = $this->conf->shop_tag_type->toArray();
		$tagTransTypeConf = $this->conf->shop_tag_trans_type->toArray();
		$transStatus = $this->conf->trans_status->toArray();
		$inquiryStatus = $this->conf->inquiry_status->toArray();
		$getNum = $this->conf->shop_auction_num;
		$limit = $per_page . "," . $getNum;
		
		if(empty($shopTag['domainTLD']))
		{
			$shopTag['domainTLD'] = '';
		}
		
		// 域名分组
		if(isset($shopTag['domaingroup']))
		{
			$shopTag['domaingroup'] = $pLib->getDomainGroup($shopTag['domaingroup'], $this->conf->ts_domaingroup);
		}
		else
		{
			$shopTag['domaingroup'] = array();
		}
		
		if($shopTag['TagTransType'] == $tagTransTypeConf['auction'][0])
		{
			// 搜索交易表
			if(!$shopTag['Value'])
			{
				// 系统标签，按交易类型搜索
				$cnt = $TDAsdk->getAuctionCntByTransType($enameId, $shopTag['TransType'], $shopTag['domaingroup'], 
					$shopTag['domainTLD']);
				$list = $cnt? $TDAsdk->getAuctionByTransType($enameId, $shopTag['TransType'], $limit, 
					$shopTag['domaingroup'], $shopTag['domainTLD']) :array();
				$sData[$shopTag['Id']]['DisplayType'] = $this->getTagDisplayType($enameId, $shopTag['Id']);
				$shopTransType = ($shopTag['TransType'] == '1,2')? 1 :$shopTag['TransType'];
			}
			else
			{
				// 自定义标签，按标签Value搜索
				$cnt = $TDAsdk->getShopDomainsCntByTag($enameId, $transStatus['trading'][0], $shopTag['Value']);
				$list = $cnt? $TDAsdk->getShopDomainsByTag($enameId, $transStatus['trading'][0], $shopTag['Value'], 
					$limit) :array();
				$sData[$shopTag['Id']]['DisplayType'] = $this->getTagDisplayType($enameId, $shopTag['Id']);
			}
		}
		else
		{
			// 搜索询价表
			if(!$shopTag['Value'])
			{
				// 系统标签，按交易类型搜索
				$cnt = $TIsdk->getInquiryCnt($enameId, $shopTag['domaingroup'], $shopTag['domainTLD']);
				$list = $cnt? $TIsdk->getInquiry($enameId, $limit, $shopTag['domaingroup'], $shopTag['domainTLD']) :array();
				$sData[$shopTag['Id']]['DisplayType'] = $this->getTagDisplayType($enameId, $shopTag['Id']);
			}
			else
			{
				// 自定义标签，按标签Value搜索
				$cnt = $TIsdk->getShopDomainsCntByTag($enameId, $inquiryStatus['onsale'][0], $shopTag['Value']);
				$list = $cnt? $TIsdk->getShopDomainsByTag($enameId, $inquiryStatus['onsale'][0], $shopTag['Value'], 
					$limit) :array();
				$sData[$shopTag['Id']]['DisplayType'] = $this->getTagDisplayType($enameId, $shopTag['Id']);
			}
		}
		$sData[$shopTag['Id']]['list'] = $this->convertAuctionData($list);
		$sData[$shopTag['Id']]['auctionCnt'] = $cnt;
		$sData[$shopTag['Id']]['title'] = $shopTag['TagName'];
		$sData[$shopTag['Id']]['tagTransType'] = $shopTag['TagTransType'];
		
		return $sData;
	}

	/**
	 * 获取标签显示方式
	 */
	public function getTagDisplayType($enameId, $tagid)
	{
		$TSTsdk = new \models\trans\ShopTagsMod();
		$display = $TSTsdk->getDisplayById($enameId, $tagid);
		return $display;
	}

	/**
	 * 交易数据处理
	 */
	public function convertAuctionData($list)
	{
		if($list)
		{
			$pLib = new \lib\trans\common\PublicLib();
			foreach($list as $k => $v)
			{
				$time = strtotime($v['FinishDate']) - time();
				if($time < 0)
					$list[$k]['LeftTime'] = '交易已结束';
				else
					$list[$k]['LeftTime'] = $pLib->NewTimeToDHIS($time);
				if(!empty($list[$k]['AuditListId']))
				{
					$list[$k]['Id'] = intval($v['AuditListId']);
					unset($list[$k]['AuditListId']);
				}
				if(!empty($list[$k]['InquiryId']))
				{
					$list[$k]['Id'] = intval($v['InquiryId']);
					unset($list[$k]['InquiryId']);
				}
				if(!empty($list[$k]['BidPrice']))
				{
					$list[$k]['Price'] = intval($v['BidPrice']);
					unset($list[$k]['BidPrice']);
				}
				if(!empty($list[$k]['InquiryPrice']))
				{
					$list[$k]['Price'] = intval($v['InquiryPrice']);
					unset($list[$k]['InquiryPrice']);
				}
				if(!isset($list[$k]['TransType']))
				{
					$list[$k]['TransType'] = 5;
				}
				if(isset($list[$k]['DomainName']))
				{
					$list[$k]['DomainName'] = \lib\trans\common\PublicDomainLib::replaceL($list[$k]['DomainName']);
				}
				unset($list[$k]['FinishDate']);
			}
		}
		return $list;
	}

	/**
	 * 获取店铺的所有标签
	 */
	public function getShopTags($enameId, $status = '')
	{
		$TSTsdk = new \models\trans\ShopTagsMod();
		return $TSTsdk->getShopTags($enameId, $status);
	}

	public function getTagAuctionWithTags($enameId, $shopTags, $displayType, $per_page = 0)
	{
		$sData = $showTags = array();
		if($shopTags)
		{
			$getNum = $this->conf->shop_auction_num;
			$limit = $per_page . "," . $getNum;
			$tagTransTypeConf = $this->conf->shop_tag_trans_type->toArray();
			$pLib = new \lib\trans\common\PublicLib();
			$TDAsdk = new \models\trans\DomainAuctionMod();
			$TIsdk = new \models\trans\InquiryMod();
			$i = 0;
			foreach($shopTags as $tags)
			{
				if($tags['Value'])
				{
					// 有标签值
					if($tags['TagTransType'] == $tagTransTypeConf['auction'][0])
						$cnt = $TDAsdk->getAuctionCntByTag($enameId, $tags['Value']);
					else
						$cnt = $TIsdk->getInquiryCntByTag($enameId, $tags['Value']);
					if($cnt)
					{
						// 选项卡过滤无数据标签
						$showTags[] = $tags;
						if(1 == $displayType && 1 == $i)
						{
							continue;
						}
						$i = 1;
						
						if($tags['TagTransType'] == $tagTransTypeConf['auction'][0])
							$list = $TDAsdk->getAuctionByTag($enameId, $tags['Value'], $limit);
						else
							$list = $TIsdk->getInquiryByTag($enameId, $tags['Value'], $limit);
						if($list)
						{
							$sData[$tags['Id']]['list'] = $this->convertAuctionData($list);
							$sData[$tags['Id']]['auctionCnt'] = $cnt;
							$sData[$tags['Id']]['title'] = $tags['TagName'];
							$sData[$tags['Id']]['tagTransType'] = $tags['TagTransType'];
							$sData[$tags['Id']]['DisplayType'] = $this->getTagDisplayType($enameId, $tags['Id']);
						}
					}
				}
				else
				{
					if(empty($tags['domainTLD']))
					{
						$tags['domainTLD'] = '';
					}
					
					// 域名分组
					if(isset($tags['domaingroup']))
					{
						$tags['domaingroup'] = $pLib->getDomainGroup($tags['domaingroup'], $this->conf->ts_domaingroup);
					}
					else
					{
						$tags['domaingroup'] = array();
					}
					// 无标签值（系统标签，除推荐标签外）
					if($tags['TagTransType'] == $tagTransTypeConf['auction'][0])
						$cnt = $TDAsdk->getAuctionCntByTransType($enameId, $tags['TransType'], $tags['domaingroup'], 
							$tags['domainTLD']);
					else
						$cnt = $TIsdk->getInquiryCnt($enameId, $tags['domaingroup'], $tags['domainTLD']);
					if($cnt)
					{
						// 选项卡过滤无数据标签
						$showTags[] = $tags;
						if(1 == $displayType && 1 == $i)
						{
							continue;
						}
						$i = 1;
						
						if($tags['TagTransType'] == $tagTransTypeConf['auction'][0])
							$list = $TDAsdk->getAuctionByTransType($enameId, $tags['TransType'], $limit, 
								$tags['domaingroup'], $tags['domainTLD']);
						else
							$list = $TIsdk->getInquiry($enameId, $limit, $tags['domaingroup'], $tags['domainTLD']);
						if($list)
						{
							$sData[$tags['Id']]['list'] = $this->convertAuctionData($list);
							$sData[$tags['Id']]['auctionCnt'] = $cnt;
							$sData[$tags['Id']]['title'] = $tags['TagName'];
							$sData[$tags['Id']]['tagTransType'] = $tags['TagTransType'];
							$sData[$tags['Id']]['DisplayType'] = $this->getTagDisplayType($enameId, $tags['Id']);
							$shopTransType = ($tags['TransType'] == '1,2')? 1 :$tags['TransType'];
							$sData[$tags['Id']]['Value'] = $tags['Value'];
							$sData[$tags['Id']]['TransType'] = $tags['TransType'];
							$sData[$tags['Id']]['Id'] = $tags['Id'];
						}
					}
				}
			}
		}
		return array($sData,$showTags);
	}

	/**
	 * 店铺是否已关注
	 */
	public function checkIsShopFavorite($shopUid, $favoriteUid)
	{
		$TUSFsdk = new \models\trans\ShopFavoriteMod();
		if($TUSFsdk->checkIsShopFavorite($shopUid, $favoriteUid))
		{
			return true;
		}
		return false;
	}

	/**
	 * 店铺首页&店铺搜索新接口
	 */
	public function getShopSearch($data)
	{
		$transConf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
		$cnnicUser = $transConf->cnnicUser;
		$data->isCnnicUser = isset($data->uid)&&$data->uid==$cnnicUser ? 1 : 0;
		
		// 后缀转换
		$domaintld = array();
		if($data->domaintld)
		{
			$domaintld = explode(',', $data->domaintld);
			// 域名后缀配置项
			$tldConf = $this->conf->ts_domaintld->toArray();
			//类型转换,考虑到多参数的情况
			foreach($domaintld as $key=>$val)
			{
				if(isset($tldConf[$val][1]))
				{
					$domaintld[$key] = $tldConf[$val][1];
				}
				else
				{
					unset($domaintld[$key]);
				}
			}
			$data->domaintld = $domaintld;
		}
		
		// 带有后缀名的搜索的时候
		if($data->domainsld)
		{
			$domainsld = explode('.', $data->domainsld);
			
			$data->domainsld = $domainsld[0];
			array_splice($domainsld, 0, 1);
			
			if($domainsld)
			{
				$tld = '.'.implode('.',$domainsld);
				$tldConf = $this->conf->ts_domaintld->toArray();
				if(!$data->domaintld)
				{
					foreach($tldConf as $val)
					{
						if($val[0] == $tld)
						{
							$data->domaintld = $domaintld = array($val[1]);
							break;
						}
					}
				}
			}
		}
		
		// 标签表对象
		$tagModel = new \models\trans\ShopTagsMod();
		// 获取指定的标签
		$shoptags = $tagModel->getShopTagsNew($data);
		if(!$shoptags)
		{
			return array();
		}

		// 交易表模型对象
		$auctionModel = new \models\trans\DomainAuctionMod();
		// 询价表模型对象
		$inquiryModel = new \models\trans\InquiryMod(); 
		// 格式化日期用的对象
		$pLib = new \lib\trans\common\PublicLib();
		//域名分类解析
		$pDomainLib = new \lib\trans\common\PublicDomainLib();
		// 返回的结果数组
		$return = array();
		
		// 遍历获得标签下的域名
		foreach($shoptags as $key=>$tag)
		{
			// 域名分类
			$data->SysGroupOne = "";
			$data->SysGroupTwo = "";
			$data->DomainLen = "";
			if($data->domaingroup || $tag['domainGroup'])
			{
				$id = $data->domaingroup ? $data->domaingroup : $tag['domainGroup'];
				$groups = $pDomainLib->getSysGroup($id);
				$data->SysGroupOne = $groups['sysGroupOne'];
				$data->SysGroupTwo = $groups['sysGroupTwo'];
				$data->DomainLen = $groups['domainLen'];
			}
			
			// 标签的后缀
			$data->domaintld = $tag['domainTld'] ? $tag['domainTld'] : ($domaintld ? implode(',', $domaintld) : "");
			
			// 标签当成参数传递
			$data->shoptag = $tag;
			
			// 竞价表对象还是询价表对象
			$object = $tag['TransType'] == 5 || ($tag['TagType'] == 1 && $tag['TagTransType'] == 2) ? $inquiryModel : $auctionModel;
			
			// 获取数量
			if($cnt = $object->getListNew($data, 'count'))
			{
				// 数量
				$tag['Num'] = $cnt;
				// 获取列表
				if($res = $object->getListNew($data, 'list'))
				{
					// 格式化成统一的返回字段
					foreach($res as $k=>$v)
					{
						$tag['DomainList'][$k]['Id'] 			 = isset($v['InquiryId']) ? $v['InquiryId'] : $v['AuditListId'];
						//域名名称
						$tag['DomainList'][$k]['DomainName'] = \lib\trans\common\PublicDomainLib::replaceL($v['DomainName']);
						//域名日期
						$time = strtotime($v['FinishDate']) - time();
						$tag['DomainList'][$k]['LeftTime'] 	 = ($time < 0 || (isset($v['TransStatus']) && $v['TransStatus']>1)) ? '交易已结束' : $pLib->NewTimeToDHIS($time);
						//域名类型
						$tag['DomainList'][$k]['TransType']  = isset($v['TransType']) ? $v['TransType'] : 5;
						//域名价格
						$tag['DomainList'][$k]['Price']		 = intval(isset($v['InquiryPrice']) ? $v['InquiryPrice'] : $v['BidPrice']);
						//域名简介
						$tag['DomainList'][$k]['SimpleDec']  = $v['SimpleDec'];
						//询价次数
						$tag['DomainList'][$k]['BidCount']  = $v['BidCount'];
					}
					
					// 存入返回结果
					$return[] = $tag;
				}
			}
		}

		return $return;
	}

	/**
	 * 获取店铺的指定标签
	 */
	public function getShopTagByValue($enameId, $value, $status = '')
	{
		$TSTsdk = new \models\trans\ShopTagsMod();
		return $TSTsdk->getShopTagByValue($enameId, $value, $status);
	}

	public function getSearch($data)
	{
		$uid = $data->uid;
		if(!$uid)
			throw new \Exception('非法操作');
		
		$perNum = $data->num? $data->num :$this->conf->shop_auction_num;
		$p = $data->p? $data->p :1;
		$perPage = ($p - 1) * $perNum;
		$perPage? $perPage :$perPage = 0;
		$limit = $perPage . ', ' . $perNum;
		
		$getDomainSLD = trim($data->domainsld);
		$pos = $data->pos? explode(',', $data->pos) :array();
		$getTransType = $data->transtype;
		$getBidPriceStart = $data->bidpricestart;
		$getBidPriceEnd = $data->bidpriceend;
		$getRegistrar = $data->registrar;
		$getHideNoBider = $data->hidenobider;
		
		$getSimpleDec = trim($data->simpledec);
		$getDomainTLD = $data->domaintld;
		$getDomainGroup = $data->domaingroup;
		$getDomainLenStart = $data->domainlenstart;
		$getDomainLenEnd = $data->domainlenend;
		$getFinishTime = $data->finishtime;
		$getSort = $data->sort;
		$getBidStartOne = $data->bidstartone;
		
		$getTag = $data->tag;
		
		if(in_array(1, $pos) && in_array(2, $pos))
			$getSldType = 4;
		elseif(in_array(1, $pos))
			$getSldType = 1;
		elseif(in_array(2, $pos))
			$getSldType = 3;
		else
			$getSldType = 2;
			// 竞价1元起拍 竞价有人出价
		if($getBidStartOne || $getHideNoBider)
		{
			$getTransType = 1;
			$data->transtype = 1;
		}
		
		$data->domainsld = $getDomainSLD;
		$data->simpledec = $getSimpleDec;
		
		$data = $this->getSearchCondition($getDomainSLD, $getDomainTLD, $getDomainLenStart, $getDomainLenEnd, 
			$getDomainGroup, $getBidPriceStart, $getBidPriceEnd, $getFinishTime, $getRegistrar, $getTransType, $getSort, 
			$getHideNoBider, $getSldType, $getTag, $getBidStartOne, $getSimpleDec);
		// ///////////域名搜索///////////////////
		$tldConf = $this->conf->ts_domaintld->toArray();
		foreach($tldConf as $k => $v)
		{
			$formTldConf[$v[1]] = $k;
			$searchTldConf[$v[0]] = $v[1];
		}
		$pLib = new \lib\trans\common\PublicLib();
		$domain = $pLib->getDomainSearch($data['getDomainSLD'], $data['domainTLD'], $searchTldConf, $formTldConf);
		$data['sld'] = $domain['sld'];
		$data['tld'] = $domain['tld'];
		$data['limit'] = $limit;
		$data['perNum'] = $perNum;
		return $data;
	}

	/**
	 * 搜索条件
	 * 
	 * @param int $getDomainSLD        	
	 * @param int $getDomainTLD        	
	 * @param int $getDomainLenStart        	
	 * @param int $getDomainLenEnd        	
	 * @param int $getDomainGroup        	
	 * @param int $getBidPriceStart        	
	 * @param int $getBidPriceEnd        	
	 * @param int $getFinishTime        	
	 * @param int $getRegistrar        	
	 * @param int $getTransType        	
	 * @param int $getSort        	
	 * @param int $getHideNoBider        	
	 * @param int $getSldType        	
	 * @param int $getTag        	
	 * @param int $getBidStartOne        	
	 * @param int $getSimpleDec        	
	 * @return array
	 */
	public function getSearchCondition($getDomainSLD, $getDomainTLD, $getDomainLenStart, $getDomainLenEnd, 
		$getDomainGroup, $getBidPriceStart, $getBidPriceEnd, $getFinishTime, $getRegistrar, $getTransType, $getSort, 
		$getHideNoBider, $getSldType, $getTag, $getBidStartOne, $getSimpleDec)
	{
		$default['tsDomainGroup'] = $this->conf->ts_domaingroup->toArray();
		$default['tsDomainTLD'] = $this->conf->ts_domaintld->toArray();
		$default['tsRegistrar'] = $this->conf->ts_registrar->toArray();
		$default['tsTransType'] = $this->conf->shop_transtype->toArray();
		$default['tsFinishTime'] = $this->conf->ts_finishtime->toArray();
		$default['tsSldType'] = $this->conf->ts_sldtype->toArray();
		$default['transType'] = $this->conf->trans_type->toArray();
		
		if(is_numeric($getDomainTLD))
		{
			$data['domainTLD'] = $getDomainTLD? $default['tsDomainTLD'][$getDomainTLD][1] :'';
		}
		else
		{
			$tlds = explode(',', $getDomainTLD);
			$tldArr = array();
			foreach($tlds as $tld)
			{
				$tldArr[] = $tld? $default['tsDomainTLD'][$tld][1] :'';
			}
			$data['domainTLD'] = $tldArr;
		}
		
		if($getDomainGroup)
		{
			$pDomainLib = new \lib\trans\common\PublicDomainLib();
			$sysGroup = $pDomainLib->getSysGroup($getDomainGroup);
			$data['sysGroupOne'] = $sysGroup['sysGroupOne'];
			$data['sysGroupTwo'] = $sysGroup['sysGroupTwo'];
			$data['domainLen'] = $sysGroup['domainLen'];
		}
		else
		{
			$data['sysGroupOne'] = '';
			$data['sysGroupTwo'] = '';
		}
		if(empty($data['domainLen']))
		{
			if($getDomainLenStart && $getDomainLenEnd && $getDomainLenStart <= $getDomainLenEnd && !isset($domainLen))
			{
				$data['domainLen'] = ($getDomainLenStart == $getDomainLenEnd)? $getDomainLenStart :array(
					$getDomainLenStart,$getDomainLenEnd);
			}
			else
			{
				$data['domainLen'] = '';
			}
		}
		if($getBidPriceStart && $getBidPriceEnd && $getBidPriceStart <= $getBidPriceEnd)
		{
			$data['bidPrice'] = ($getBidPriceStart == $getBidPriceEnd)? $getBidPriceStart :array($getBidPriceStart,
				$getBidPriceEnd);
		}
		else
		{
			$data['bidPrice'] = '';
		}
		if($getFinishTime)
		{
			$temp = $default['tsFinishTime'][$getFinishTime][1];
			$data['finishTime'] = date("Y-m-d H:i:s", strtotime(date("Y-m-d H:i:s")) + $temp);
		}
		else
		{
			$data['finishTime'] = '';
		}
		
		$data['registrar'] = $getRegistrar? $default['tsRegistrar'][$getRegistrar][1] :'';
		$data['transType'] = $getTransType? $default['tsTransType'][$getTransType][1] :'';
		
		$data['getDomainSLD'] = $getDomainSLD;
		$data['getHideNoBider'] = $getHideNoBider;
		$data['getSldType'] = $getSldType;
		$data['getSort'] = $getSort;
		$data['getTag'] = $getTag;
		$data['bidStartOne'] = $getBidStartOne;
		$data['simpleDec'] = $getSimpleDec;
		return $data;
	}

	/**
	 * 可搜索的店铺标签
	 * 
	 * @param int $enameId        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getShopTagsForSearch($enameId)
	{
		$TSTsdk = new \models\trans\ShopTagsMod();
		return $TSTsdk->getShopTagsForSearch($enameId);
	}

	/**
	 * 判断域名是否已被关注
	 * 
	 * @param int $enameId        	
	 * @param int $auditListId        	
	 * @return Ambigous <string, boolean, mixed>
	 */
	public function isDomainFavorite($enameId, $auditListId)
	{
		$TDF = new \models\trans\DomainFavoriteMod();
		return $TDF->isDomainFavorite($auditListId, $enameId);
	}

	/**
	 * 添加域名关注
	 * 
	 * @param int $enameId        	
	 * @param int $auditListId        	
	 * @param int $transType        	
	 * @throws \Exception
	 * @return boolean
	 */
	public function addDomainFavorite($enameId, $auditListId, $transType)
	{
		// 加载配置
		$transTypeConf = $this->conf->trans_transtype->toArray();
		$transStatus = $this->conf->trans_status->toArray();
		
		// 检查交易是否存在
		if($transType == $transTypeConf['booking'][0])
		{
			$TBAsdk = new \models\trans\BookAuctionMod();
			if($TBAsdk->isDomainExist($auditListId))
				// 获取结束时间和交易类型
				$info = $TBAsdk->getTransAuctionInfo($auditListId);
			else
				throw new \Exception('抱歉，此交易不存在');
		}
		else
		{
			$TDAsdk = new \models\trans\DomainAuctionMod();
			if($TDAsdk->isDomainExist($auditListId))
				// 获取结束时间和交易类型
				$info = $TDAsdk->getTransAuctionInfo($auditListId);
			else
				throw new \Exception('抱歉，此交易不存在');
		}
		// 是否结束
		$rqTime = empty($_SERVER['REQUEST_TIME'])? time() :$_SERVER['REQUEST_TIME'];
		$isfinish = ((strtotime($info['FinishDate']) - $rqTime) > 0 && $info['TransStatus'] == $transStatus['trading'][0])? false :true;
		if($isfinish)
		{
			throw new \Exception('交易已经结束');
		}
		// 写入关注表
		$TDFsdk = new \models\trans\DomainFavoriteMod();
		if($TDFsdk->addDomainFavorite($auditListId, $enameId, $info['FinishDate'], $info['TransType'], 
			$info['DomainName'], $info['SimpleDec'], $info['Seller']))
		{
			return TRUE;
		}
		\core\Log::write("用户" . $enameId . "收藏交易ID为" . $auditListId . "的域名失败",'trans','shop');
		return FALSE;
	}

	/**
	 * 取消域名关注
	 */
	public function cancelDomainFavorite($auditListId, $enameId)
	{
		$TDFsdk = new \models\trans\DomainFavoriteMod();
		return $TDFsdk->cancelDomainFavorite($auditListId, $enameId);
	}

	/**
	 * 判断是否关注过此域名
	 */
	public function getDomainFavorite($auditListId, $enameId)
	{
		$TDFsdk = new \models\trans\DomainFavoriteMod();
		return $TDFsdk->getDomainFavorite($auditListId, $enameId);
	}

	/**
	 * 获取正在交易中和交易結束的域名
	 * param：$domainFavoriteList
	 * param：$type
	 * return array
	 */
	public function getTransDomain($domainFavoriteList, $type)
	{
		$transTypeConf = $this->conf->trans_transtype->toArray();
		$pLib = new \lib\trans\common\PublicLib();
		$transType = $pLib->covertArray($transTypeConf, 1);
		$transInfo = array();
		
		if($type)
		{
			// 交易结束的域名
			foreach($domainFavoriteList as $v)
			{
				$transInfo[$v['AuditListId']] = $v;
				$transInfo[$v['AuditListId']]['RemainTime'] = date("Y-m-d", strtotime($v['FinishDate']));
			}
		}
		else
		{
			// 正在交易的域名
			$auditListIds = $bookIdList = $auctionIdList = array();
			foreach($domainFavoriteList as $k => $val)
			{
				$auditListIds[] = $val['AuditListId'];
				if($val['TransType'] == $transTypeConf['booking'][0])
					$bookIdList[] = $val['AuditListId'];
				else
					$auctionIdList[] = $val['AuditListId'];
			}
			// 从审核表里取交易的类型和结束时间
			if($bookIdList)
			{
				// 从预订竞价交易表里获取交易信息
				$TBAsdk = new \models\trans\BookAuctionMod();
				$bookList = $TBAsdk->getTransListByIds(implode(', ', $bookIdList));
				if($bookList)
				{
					foreach($bookList as $bookInfo)
					{
						$transInfo[$bookInfo['AuditListId']] = $this->getTransRemainTime($bookInfo);
					}
				}
			}
			
			if($auctionIdList)
			{
				// 从交易表里获取交易信息
				$TDAsdk = new \models\trans\DomainAuctionMod();
				$transList = $TDAsdk->getTransListByIds(implode(', ', $auctionIdList));
				if($transList)
				{
					foreach($transList as $auctionInfo)
					{
						$transInfo[$auctionInfo['AuditListId']] = $this->getTransRemainTime($auctionInfo);
					}
				}
			}
			
			// 将未能找到交易信息的关注，设为取消状态
			if($transInfo)
			{
				$unvalid = array_diff($auditListIds, array_keys($transInfo));
				if($unvalid)
				{
					$domainFavoriteMod = new \models\trans\DomainFavoriteMod();
					$domainFavoriteMod->batchCancelFavorite(implode(', ', $unvalid));
				}
			}
		}
		$info = array();
		if($transInfo)
		{
			foreach($transInfo as $k => $v)
			{
				$v['TransType'] = isset($transType[$v['TransType'] - 1])? $transType[$v['TransType'] - 1] :'未知';
				$v['BidPrice'] = intval($v['BidPrice']);
				if(isset($v['DomainName']))
				{
					$v['DomainName'] = \lib\trans\common\PublicDomainLib::replaceL($v['DomainName']);
				}
				if(isset($v['FinishDate']))
				{
					unset($v['FinishDate']);
				}
				$info[] = $v;
			}
		}
		
		return $info;
	}

	/**
	 * 获取交易的剩余时间
	 * 
	 * @param array $info        	
	 * @return string
	 */
	public function getTransRemainTime($info)
	{
		// 加载配置
		$transTypeConf = $this->conf->trans_type->toArray();
		$pLib = new \lib\trans\common\PublicLib();
		$transType = $pLib->covertArray($transTypeConf, 0);
		// 计算剩余时间
		if($info && in_array($info['TransType'], $transType))
		{
			$info['RemainTime'] = $pLib->NewTimeToDHIS(strtotime($info['FinishDate']) - time());
		}
		else
		{
			$info['RemainTime'] = "交易已结束";
		}
		return $info;
	}

	public function getImage($num, $role)
	{
		// 加载配置
		$shopImgConf = $this->conf->shop_img->toArray();
		switch($role)
		{
			case 'buyer':
				$shopImg = $shopImgConf['buyer'];
				break;
			case 'seller':
				$shopImg = $shopImgConf['seller'];
				break;
			default:
				$shopImg = $shopImgConf['seller'];
		}
		$array = array();
		
		if($num > 3 && $num < 91)
		{
			$array['img'] = $shopImg['xin'];
			$array['level'] = 1;
			if($num > 10 && $num < 41)
			{
				$array['num'] = 2;
				$array['grade'] = 2;
			}
			else 
				if($num > 40 && $num < 91)
				{
					$array['num'] = 3;
					$array['grade'] = 3;
				}
				else
				{
					$array['num'] = 1;
					$array['grade'] = 1;
				}
		}
		else 
			if($num > 90 && $num < 501)
			{
				$array['img'] = $shopImg['xing'];
				$array['level'] = 2;
				if($num > 150 && $num < 251)
				{
					$array['num'] = 2;
					$array['grade'] = 5;
				}
				else 
					if($num > 250 && $num < 501)
					{
						$array['num'] = 3;
						$array['grade'] = 6;
					}
					else
					{
						$array['num'] = 1;
						$array['grade'] = 4;
					}
			}
			else 
				if($num > 500)
				{
					$array['img'] = $shopImg['cup'];
					$array['level'] = 3;
					if($num > 1000 && $num < 2001)
					{
						$array['num'] = 2;
						$array['grade'] = 8;
					}
					else 
						if($num > 2000)
						{
							$array['num'] = 3;
							$array['grade'] = 9;
						}
						else
						{
							$array['num'] = 1;
							$array['grade'] = 7;
						}
				}
				else
				{
					$array['img'] = '';
					$array['level'] = 0;
					$array['num'] = 0;
					$array['grade'] = 0;
				}
		return $array;
	}

	/**
	 * json格式转换
	 */
	public function transTypeisJson($trans)
	{
		foreach($trans as $key => $val)
		{
			if(is_array($val))
			{
				$trans[$key] = $this->transTypeisJson($val);
			}
			else 
				if(strpos($val, '{') === 0)
				{
					$tmp = json_decode($val, TRUE);
					$trans['TransType'] = $tmp['type'];
					$trans['domaingroup'] = $tmp['group'];
					$trans['domainTLD'] = $tmp['id'];
				}
		}
		return $trans;
	}

	public function filterTags($tags, $tagtranstype)
	{
		$tval = 0;
		switch($tagtranstype)
		{
			case 1:
			case 4:
				$tval = 1;
				break;
			case 5:
				$tval = 2;
		}
		
		foreach($tags as $key => $val)
		{
			// 系统标签
			if($val['TransType'] && $val['TransType'] != $tagtranstype)
			{
				unset($tags[$key]);
			}
			else 
				if($val['TagTransType'] != $tval)
				{
					unset($tags[$key]);
				}
		}
		return $tags;
	}

	/**
	 * 检查用户是否已经创建过店铺
	 * 
	 * @param int $enameId        	
	 * @return boolean multitype:number
	 */
	public function isExistShop($enameId)
	{
		$TMI = new \models\trans\MemberShipInfoMod();
		$TCS = new \models\trans\CustomerShopMod();
		$userNum = $TMI->getUserCnt($enameId);
		$shopNum = $TCS->getCustomerShopCnt($enameId);
		if($shopNum && $userNum)
		{
			return false;
		}
		else
		{
			// 返回数组里有1表示要创建用户信息，有2表示要创建店铺信息
			if($shopNum)
			{
				return array(1);
			}
			if($userNum)
			{
				return array(2);
			}
			return array(1,2);
		}
		return true;
	}

	/**
	 * 创建店铺
	 * 
	 * @param int $enameId        	
	 * @param array $flag
	 *        	数组里有1表示要创建用户信息，有2表示要创建店铺信息
	 * @throws Exception
	 */
	public function createShop($enameId, $flag)
	{
		if(in_array(1, $flag))
		{
			$TMI = new \models\trans\MemberShipInfoMod();
			// 查看评价表中是否有此用户数据
			$rate = $this->getUserEvaluateData($enameId);
			// 获取用户信息
			$user = new \interfaces\trans\User();
			$userInfo = $user->getMemberInfoByEnameId($enameId);
			if($userInfo)
			{
				$email = '';
				$phone = '';
				$msn = '';
				$qq = '';
				$address = $userInfo['ChProvince'] . ',' . $userInfo['ChCity'] . ',' . $userInfo['ChStreet'];
				$USRS = $TMI->createUser($enameId, $rate, $email, $phone, $msn, $qq, $address);
				if(!$USRS)
				{
					throw new \Exception("创建店铺失败，请联系管理员");
					\core\Log::write("用户Id,$enameId,写入店主信息表失败", 'trans', 'shop');
				}
			}
			else
			{
				$USRS = $TMI->createUser($enameId, $rate);
				if(!$USRS)
				{
					throw new \Exception("创建店铺失败，请联系管理员");
					\core\Log::write("用户Id,$enameId,写入店主信息表失败", 'trans', 'shop');
				}
			}
		}
		
		if(in_array(2, $flag))
		{
			$TCS = new \models\trans\CustomerShopMod();
			/**
			 * ***店铺默认信息***
			 */
			$shopName = $enameId . '的玉米小店';
			$shoplinks = '易名中国|http://www.ename.com';
			
			$CSRS = $TCS->createShop($enameId, $shopName, $shoplinks);
			if(!$CSRS)
			{
				throw new \Exception("创建店铺失败，请联系管理员");
				\core\Log::write("用户Id,$enameId,写入店铺表（创建店铺）失败", 'trans', 'shop');
			}
		}
	}

	public function getUserEvaluateData($enameId)
	{
		$data = array('BuyerGoodLevel' => 0,'BuyerMiddleLevel' => 0,'BuyerBadLevel' => 0,'SellerGoodLevel' => 0,
			'SellerMiddleLevel' => 0,'SellerBadLevel' => 0);
		$TCSRsdk = new \models\trans\CustomerShopRateMod();
		// 买家评价数
		$buyer = $TCSRsdk->getBuyerRateCnt($enameId);
		if($buyer)
		{
			foreach($buyer as $k => $v)
			{
				switch($v['SellerRateLevel'])
				{
					case 1:
						$data['BuyerGoodLevel'] = $v['Count'];
						break;
					case 0:
						$data['BuyerMiddleLevel'] = $v['Count'];
						break;
					case 1:
						$data['BuyerBadLevel'] = $v['Count'];
						break;
				}
			}
		}
		// 卖家评价数
		$seller = $TCSRsdk->getSellerRateCnt($enameId);
		if($seller)
		{
			foreach($seller as $k => $v)
			{
				switch($v['BuyerRateLevel'])
				{
					case 1:
						$data['SellerGoodLevel'] = $v['Count'];
						break;
					case 0:
						$data['SellerMiddleLevel'] = $v['Count'];
						break;
					case 1:
						$data['SellerBadLevel'] = $v['Count'];break;
				}
			}
		}
		return $data;
	}
	
	public function checkWord($word)
	{
		if($word)
		{
			$keyWordMod = new \models\trans\KeyWordsMod();
			$tempkey = $keyWordMod->getAll();
			$keyWords = $tempkey? $this->changeKeyWords($tempkey): array();
				
			return $this->checkIsKeyWords($word, $keyWords);
		}
		else
		{
			return false;
		}
	}
	
	public function changeKeyWords($data)
	{
		$temp = array();
		if($data)
		{
				
			foreach($data as $v)
			{
				$temp[] = $v['word'];
			}
		}
		return $temp;
	}
	
	public function checkIsKeyWords($str, $keyWords)
	{
		$flag = false;
		foreach($keyWords as $v)
		{
			if(substr_count($str, $v))
			{
				$flag = true;
				break;
			}
		}
		return $flag;
	}
}
?>

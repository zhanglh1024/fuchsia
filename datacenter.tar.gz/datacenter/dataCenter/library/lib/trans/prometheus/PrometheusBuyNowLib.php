<?php
	namespace lib\trans\prometheus;
	use core\Response;
	class PrometheusBuyNowLib
	{
		public $enameId;
		public $id;
		public $postNick;
		public $buyerIp;
		public $transStatus;
		public $transDomainInEname;
		public $transDeliveryStatus;
		public $tdaSDK;
		public $tdSDK;
		public $tLib;
		public $pFinanceLib;
		public $transInfo;
		public $transOrderId;
		public $conf;
		public $finanConf;
		
		public function __construct($enameId, $id, $postNick)
		{
			$this->enameId = $enameId;
			$this->id = $id;
			$this->postNick = $postNick;
			$this->buyerIp = \common\Common::getRequestIp();
			$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
			$this->finanConf =new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
			$this->transStatus         = $this->conf->trans_status->toArray();
			$this->transTopic          = $this->conf->trans_transtopic->toArray();
			$this->transDomainInEname  = $this->conf->trans_domain_in_ename->toArray();
			$this->transDeliveryStatus = $this->conf->trans_delivery_status->toArray();
			$this->tLib = new \lib\trans\trans\TransLib();
			$this->tdaSDK = new \models\trans\DomainAuctionMod();
			$this->tdSDK = new \models\trans\DeliveryMod();
			$this->pFinanceLib = new \interfaces\trans\Finance($this->enameId);
		}
		
		public function getTransInfo()
		{
			$transInfo = $this->tdaSDK->getTransInfoForBuyNow ( $this->id, $this->transStatus['trading'][0]);
			if( $transInfo )
			{
				if( $transInfo['Seller'] != $this->enameId )
				{
					$this->transInfo = $transInfo;
					return True;
				}
				else
				{
					throw new \Exception (\common\Lang::create('transmsg')->getMsg('610084'),610084);
				}
			}
			else
			{
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610083'),610083);
			}
		}
		
		public function checkMoney()
		{
			$typeConf = $this->finanConf->type->toArray();
			$transOrderId = $this->pFinanceLib->addOrder( $this->transInfo['DomainName'],$typeConf['sedoBroker'],$this->transInfo['AskingPrice'],$this->transInfo['Seller']);
			if($transOrderId != False)
			{
				$this->transOrderId = $transOrderId;
			}
			else
			{
				throw New \Exception(\common\Lang::create('transmsg')->getMsg('610104'),610104);
			}
		}
		
		public function createBidPrice()
		{
			if(!$this->tLib->CreateBidPrice($this->id, $this->transInfo['DomainName'], $this->transInfo['TransType'], $this->enameId, $this->transInfo['Seller'], $this->postNick, $this->transInfo['AskingPrice'], $this->buyerIp, $this->transInfo['FinishDate'], FALSE, TRUE))
			{
				\core\Log::write("FALSE,$this->id,$this->enameId,写入出价记录表操作失败",'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610001'),610001);
			}
			$this->tLib->setAuctionFinish($this->id, $this->transInfo['DomainName'], $this->enameId, $this->postNick, $this->transInfo['Seller'], $this->transInfo['AskingPrice'], $this->transInfo['TransType'], $this->transInfo['SimpleDec']);
		}
		
		public function enameDomain()
		{
			if(!$this->tdaSDK->setBuyerNow($this->id,$this->transDeliveryStatus['allchecked'][0],$this->enameId,$this->postNick,$this->transOrderId,$this->transInfo['AskingPrice'],$this->transInfo['BidCount'],$this->buyerIp))//修改主表状
			{
				\core\Log::write("FALSE,$this->enameId，一口价修改主表错误",'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610086'),610086);
			}
			if(!$this->tLib->TransAuctionToDelivery($this->id,$this->transDeliveryStatus['allchecked'][0]))//读取交易表放入交付表
			{
				\core\Log::write("写入交付表失败,$this->enameId,$this->id",'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610087'),610087);
			}
			if(!$this->tLib->addTransOrderIdToDelivery($this->id,$this->transOrderId))//添加交付表交易订单号
			{
				\core\Log::write("添加交付表交易订单号失败,$this->id,$this->transOrderId",'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610088'),610088);
			}
			if(!$this->tLib->TransDeliveryToTransfer($this->id))//读取交付表放入转移表
			{
				\core\Log::write("添加转移表数据失败,$this->id,$this->transInfo",'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610089'),610089);
			}
			if(!$this->tLib->unlockDomain($this->transInfo['DomainName']))//解锁域名
			{
				\core\Log::write("解锁域名，$this->id,".$this->transInfo['DomainName'],'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610090'),610090);
			}
			if(!$this->tLib->doTransfer($this->id))//转移域名
			{
				$this->tLib->lockDomain($this->transInfo['DomainName']);
				\core\Log::write("一口价转移域名失败,$this->id,$this->transOrderId",'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610091'),610091);
			}
			if(!$this->tdaSDK->setTransStatus($this->id,$this->transDeliveryStatus['successtrans'][0]))
			{
				\core\Log::write("一口价设置tda状态成功失败,$this->id,$this->transOrderId",'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610092'),610092);
			}
			if(!$this->tdSDK->setDeliveryStatus($this->id,$this->transDeliveryStatus['successtrans'][0]))	//set delivery = success
			{
				\core\Log::write("一口价设置td状态成功失败,$this->id,$this->transOrderId",'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610105'),610105);
			}
			if(!$this->pFinanceLib->confirmOrder($this->transOrderId,$this->transInfo['Poundage'],$this->transInfo['Seller']))//交钱
			{
				\core\Log::write("一口价交易成功,确认订单失败,已过户,$this->id,$this->transOrderId",'trans','prometheus');
			}
			if(!$this->tLib->doComment($this->enameId, $this->transInfo['Seller'], $this->transInfo['AuditListId'], $this->transDeliveryStatus['successtrans'][0], $this->transInfo['DomainName'], $this->transInfo['BidPrice']))
			{
				\core\Log::write("$this->id,$this->enameId,插入评价信息失败",'trans','prometheus');
			}
			$this->sendMessage(__function__);
			Response::msg(\common\Lang::create('transmsg')->getMsg('610106'),610106);
		}
		
		public function notEnameDomain()
		{
			if(!$this->tdaSDK->setBuyerNow($this->id,$this->transDeliveryStatus['buyerchecked'][0],$this->enameId,$this->postNick,$this->transOrderId,$this->transInfo['AskingPrice'],$this->transInfo['BidCount'],$this->buyerIp))//修改主表状态
			{
				\core\Log::write("一口价修改主表错误,$this->enameId",'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610093'),610093);
			}
			if(!$this->tLib->TransAuctionToDelivery($this->id,$this->transDeliveryStatus['buyerchecked'][0]))
			{
				\core\Log::write("一口价写入交付表失败，$this->id，$this->enameId",'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610093'),610093);
			}
			if(!$this->tLib->addTransOrderIdToDelivery($this->id,$this->transOrderId))
			{
				\core\Log::write("添加交付订单到交付表失败,$this->id,$this->enameId",'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610093'),610093);
			}
			Response::msg(\common\Lang::create('transmsg')->getMsg('610094'),610094);
		}
		
		public function qqDomain()
		{
			if(!$this->tdaSDK->setBuyerNow($this->id,$this->transDeliveryStatus['buyerchecked'][0],$this->enameId,$this->postNick,$this->transOrderId,$this->transInfo['AskingPrice'],$this->transInfo['BidCount'],$this->buyerIp))//修改主表状态
			{
				\core\Log::write("一口价修改主表错误,$this->enameId",'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610093'),610093);
			}
			if(!$this->tLib->TransAuctionToDelivery($this->id,$this->transDeliveryStatus['buyerchecked'][0],true))
			{
				\core\Log::write("一口价写入交付表失败,$this->id,$this->enameId",'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610093'),610093);
			}
			if(!$this->tLib->addTransOrderIdToDelivery($this->id,$this->transOrderId))
			{
				\core\Log::write("添加交付订单到交付表失败,$this->id,$this->enameId",'trans','prometheus');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610093'),610093);
			}
			$this->sendMessage(__function__);
			Response::msg(\common\Lang::create('transmsg')->getMsg('610107'),610107);
		}
		
		public function sedoDomain()
		{
			$transInfo = $this->transInfo;
			$domain = $transInfo['DomainName'];
			$price = $transInfo['AskingPrice'];
			$auditListId = $transInfo['AuditListId'];
		
			//hold domain
			$url = 'https://open.ename.net/rest/?appkey=498b0998f5464f94&timestamp='. time() .'&method=sedogain.holddomain&' . http_build_query(array('domain'=>$domain, 'id'=>$auditListId, 'action'=>'holddomain'));
			$pCurl = new \lib\trans\common\PublicCurlLib();
			$pCurl->setUrl( $url );
			$pCurl->sendRequest();
			$info = $pCurl->getResponseBody();
			$holdRs = json_decode($info, true);
			if($holdRs['code'] == 1000)
			{
				if(!$this->tdaSDK->setBuyerNow($this->id,$this->transDeliveryStatus['buyerchecked'][0],$this->enameId,$this->postNick,$this->transOrderId,$this->transInfo['AskingPrice'],$this->transInfo['BidCount'],$this->buyerIp))//修改主表状态
				{
					\core\Log::write("一口价修改主表错误，$this->enameId",'trans','prometheus');
					throw new \Exception(\common\Lang::create('transmsg')->getMsg('610093'),610093);
				}
				if(!$this->tLib->TransAuctionToDelivery($this->id,$this->transDeliveryStatus['buyerchecked'][0],true))
				{
					\core\Log::write("一口价写入交付表失败,$this->id,$this->enameId",'trans','prometheus');
					throw new \Exception(\common\Lang::create('transmsg')->getMsg('610093'),610093);
				}
				if(!$this->tLib->addTransOrderIdToDelivery($this->id,$this->transOrderId))
				{
					\core\Log::write("添加交付订单到交付表失败,$this->id,$this->enameId",'trans','prometheus');
					throw new \Exception(\common\Lang::create('transmsg')->getMsg('610093'),610093);
				}
				return array('flag'=>true,'msg'=>\common\Lang::create('transmsg')->getMsg('610094'),'code'=>610094);
			}
			else
			{
				$this->pFinanceLib->canelOrder($this->transOrderId, $this->enameId);
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610108'),610108);
			}
		}
		
		public function sendMessage($function)
		{
			$data =  array(	'domainName'=>$this->transInfo['DomainName'],'enameId'=>$this->enameId,'nowTime'=>date("Y-m-d H:i:s"),'price'=>intval($this->transInfo['BidPrice']),'id'=>$this->id);
			switch ($function)
			{
				case 'qqDomain':
					list($buyerModel,$sellerModel) = array('trans_buynow_success_buyer_qqdomain','trans_buynow_success_seller_qqdomain');break;
				case 'enameDomain':
					list($buyerModel,$sellerModel) = array('trans_buynow_success_buyer','trans_buynow_success_seller');break;
				default :
					return False;
			}
			$tMessageLib = new \lib\trans\trans\TransMessageLib($this->enameId,TRUE,TRUE);
			$tMessageLib->$buyerModel($data);
			$tMessageLib->setReceiveId($this->transInfo['Seller']);
			$data['enameId'] = $this->transInfo['Seller'];
			$tMessageLib->$sellerModel($data);
			return True;
		}
		public function doIt()
		{
			$this->getTransInfo();
			$this->checkMoney();
			$this->createBidPrice();
			try
			{
				if($this->transInfo['IsDomainInEname']==$this->transDomainInEname['domain_inEname'][0])
				{
					if($this->tLib->checkQQdomain($this->transInfo['DomainName']))
						return $this->qqDomain();
					else
						return $this->enameDomain();
				}
				else
				{
					if($this->transInfo['TransTopic'] == $this->transTopic['sedo'][0])
						return $this->sedoDomain();
					else
						return $this->notEnameDomain();
 				}
			}
			catch (Exception $e)
			{
				throw new \Exception ($e->getMessage(),$e->getCode());
			}
		}
	}
?>
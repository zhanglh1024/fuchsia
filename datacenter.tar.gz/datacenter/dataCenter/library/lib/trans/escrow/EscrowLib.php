<?php
namespace lib\trans\escrow;

use models\trans\EscrowMod;
use models\trans\EscrowMemberMod;
use models\trans\escrowContactMod;
use core\Response;
class EscrowLib
{

	private $conf;

	public function __construct()
	{
		// 加载配置
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'escrow');
	}

	/**
	 * 派单给专属经纪人
	 */
	public function pdEscrow($enameId, $esid, $distribution, $domainName)
	{
		// 检查是否有设置专属经纪人
		$crmMod = new \models\trans\EscrowCrmMod();
		$memberMod = new \models\trans\EscrowMemberMod();
		$crmInfo = $crmMod->getEscrowAgent($enameId);
		\core\Log::write($enameId,'trans','crm_');
		if($crmInfo)
		{
			\core\Log::write(json_encode($crmInfo),'trans','crm_');
			$acceptStatus = $memberMod->getMemberStatusByNick($crmInfo['crm_agent']); // 是否加入派单, 1加入 2 未加入
			$escrowMod = new \models\trans\EscrowMod();
			// 派单
			\core\Log::write($acceptStatus,'trans','crm_');
			if(($acceptStatus == 1) && $escrowMod->setEscrowPd($esid, $crmInfo['crm_agent'], $distribution))
			{
				// 派单日志
				$remark = '派单给专属经纪人' . $crmInfo['crm_agent'];
				\core\Log::write($esid.','.$remark.','.$distribution.','.$crmInfo['crm_agent'],'trans','crm_');
				$escrowTrackMod = new \models\trans\EscrowTrackMod();
				$escrowTrackMod->addLog($esid, $remark, $distribution, $crmInfo['crm_agent']);
			}
		}
		return true;
	}

	/**
	 * 询价转经纪
	 */
	public function inquiryToEscrow($domainName, $enameId, $receiver, $price, $paytype, $transtype, $remark)
	{
		$escrowConf = $this->conf->escrow->toArray();
		$postData = $this->formatData($domainName, $enameId, $price, $receiver);
		// 读取配置文件
		$transtype = !empty($transtype)? $transtype :$escrowConf['role']; // 经纪购买
		$trideType = $escrowConf['tridetype']; // 经纪
		$fromUrl = $escrowConf['afromurl']; // 询价来源
		$fromHost = $escrowConf['afromhost'];
		$escrowModel = new \models\trans\EscrowMod();
		$eContactMod = new \models\trans\escrowContactMod();
		// enameId是发起人，senameId是对方
		if($transtype == 2)
		{
			$esid = $escrowModel->addEscrow($domainName, $receiver, $enameId, $postData['linkman'], $price, $transtype, 
				$trideType, $paytype, $fromHost, $remark);
		}
		else
		{
			$esid = $escrowModel->addEscrow($domainName, $enameId, $receiver, $postData['linkman'], $price, $transtype, 
				$trideType, $paytype, $fromHost, $remark);
		}
		// 本人联系方式
		$contact = (array)json_decode($postData['contact']);
		$parm['userName'] = $contact['linkman'];
		$parm['contactus']['email'] = $contact['email'];
		$parm['contactus']['telPhone'] = $contact['telPhone'];
		$parm['contactus']['phone'] = $contact['phone'];
		$parm['contactus']['qq'] = $contact['qq'];
		// 对方联系方式
		$opposite = (array)json_decode($postData['opposite']);
		$parm['opposite']['mail'] = $opposite['mail'];
		$parm['opposite']['linkman'] = $opposite['linkman'];
		$parm['opposite']['mobile'] = $opposite['mobile'];
		$parm['opposite']['enameId'] = $opposite['enameId'];
		$parm['opposite']['phone'] = $opposite['phone'];
		$parm['opposite']['qq'] = $opposite['qq'];
		// 添加联系方式
		$flag = $eContactMod->addContact($parm, $esid);
		return $esid;
	}

	/**
	 * 格式化公共数据
	 *
	 * @param string $domainName        	
	 * @param int $enameId        	
	 * @param int $price        	
	 * @param string $senameId        	
	 * @return multitype:string unknown Ambigous <unknown, string> Ambigous <string, unknown>
	 */
	public function formatData($domainName, $enameId, $price, $senameId = '', $linkman = '', $telPhone = '', $email = '')
	{
		$user = new \interfaces\trans\User();
		if($senameId)
		{
			$saleInfo = $user->getMemberInfoByEnameId($senameId);
			if(FALSE === $saleInfo)
			{
				\core\Log::write("inquiryToEscrow,获取EnameId：$senameId,联系人信息失败", 'trans', 'inquiry');
				$senameId = $slinkman = $mobile = $mail = $phone1 = $fax1 = $msn1 = $qq1 = "";
			}
			else
			{
				$senameId = $senameId;
				$slinkman = $saleInfo['ChName'];
				$mail = $saleInfo['Email'];
				$mobile = $saleInfo['Mobile'];
				$phone1 = !empty($saleInfo['PhoneA'])? $saleInfo['PhoneA'] . '-' . $saleInfo['Phone'] :$saleInfo['Phone'];
				$qq1 = "";
			}
		}
		else
		{
			$domains = new \interfaces\trans\Domains();
			$domainInfo = $domains->getDomainEnameId($domainName);
			if(FALSE == $domainInfo)
			{
				\core\Log::write("inquiryToEscrow,获取域名：$domainName,联系人EnameId失败", 'trans', 'inquiry');
				$slinkman = $senameId = $mobile = $mail = $phone1 = $fax1 = $msn1 = $qq1 = "";
			}
			else
			{
				$saleEnameId = $domainInfo;
				$userInfo = $user->getMemberInfoByEnameId($saleEnameId);
				if(FALSE === $userInfo)
				{
					\core\Log::write("inquiryToEscrow,获取EnameId：$saleEnameId,联系人信息失败", 'trans', 'inquiry');
					$senameId = $slinkman = $mobile = $mail = $phone1 = $fax1 = $msn1 = $qq1 = "";
				}
				else
				{
					$senameId = $saleEnameId;
					$slinkman = $userInfo['ChName'];
					$mail = $userInfo['Email'];
					$mobile = $userInfo['Mobile'];
					$phone1 = !empty($userInfo['PhoneA'])? $userInfo['PhoneA'] . '-' . $userInfo['Phone'] :$userInfo['Phone'];
					$qq1 = "";
				}
			}
		}
		if($enameId)
		{
			$buyInfo = $user->getMemberInfoByEnameId($enameId);
			if(FALSE === $buyInfo)
			{
				\core\Log::write("inquiryToEscrow,获取EnameId：$enameId,联系人信息失败", 'trans', 'inquiry');
				$linkman = $telPhone = $phone = $qq = "";
			}
			else
			{
				$linkman = !empty($linkman)? $linkman :$buyInfo['ChName'];
				$telPhone = !empty($telPhone)? $telPhone :$buyInfo['Mobile'];
				$email = !empty($email)? $email :$buyInfo['Email'];
				$phone = !empty($buyInfo['PhoneA'])? $buyInfo['PhoneA'] . '-' . $buyInfo['Phone'] :$buyInfo['Phone'];
				$qq = "";
			}
		}
		else
		{
			$enameId = '游客';
			$phone = $qq = "";
		}
		
		$contact = array('email' => $email,'linkman' => $linkman,'telPhone' => $telPhone,'phone' => $phone,'qq' => $qq);
		$opposite = array('mail' => $mail,'linkman' => $slinkman,'mobile' => $mobile,'enameId' => $senameId,
			'phone' => $phone1,'qq' => $qq1);
		$param = array();
		$param['contactOther'] = $contact;
		$param['oppositeOther'] = $opposite;
		// 数据json化
		$contact = json_encode($contact);
		$opposite = json_encode($opposite);
		$param['contact'] = $contact;
		$param['opposite'] = $opposite;
		$param['senameid'] = $senameId;
		$param['linkman'] = $linkman;
		$param['telPhone'] = $telPhone;
		$param['email'] = $email;
		$param['mobile'] = $mobile;
		$param['mail'] = $mail;
		
		return $param;
	}

	/**
	 * 判断是否是正在交易的经纪中介
	 *
	 * @param int $id        	
	 * @throws \Exception
	 * @return Ambigous <\models\trans\Ambigous, boolean, mixed>
	 */
	public function escrowIsFinish($id)
	{
		$mod = new \models\trans\EscrowMod();
		$count = $mod->escrowIsFinish($id);
		if(false === $count)
		{
			throw new \Exception('系统出错');
		}
		return $count? true :false;
	}

	/**
	 * 获取我的经纪中介列表
	 *
	 * @param int $enameId        	
	 * @param int $pageSize        	
	 */
	public function getEscrowList($enameId, $pageSize)
	{
		$roleConf = $this->conf->escrowRoleConf->toArray();
		$mod = new \models\trans\EscrowMod('trans');
		$list = $mod->getList($enameId, $pageSize);
		$data = array();
		if(!empty($list) && is_array($list))
		{
			foreach($list as $k => $v)
			{
				$data[$k]['url'] = 'http://escrow.ename.com/escrow/showInfo/' . $v['ESID'];
				$data[$k]['type'] = $this->getEscrowRole($enameId, $v['Role'], $v['Bargainor'], $v['Purchaser']);
				$data[$k]['price'] = $this->isShowPrice($enameId, $v['EscrowAttribute'], $v['Role'], $v['Purchaser'], 
					$v['Bargainor'], $v['Status'], $v['SaleStatus'], $v['BuyStatus'], $v['Price']);
				$data[$k]['domain'] = $v['Domainname'];
				$data[$k]['status'] = $this->getEscrowStatus($v['Status'], $v['BuyStatus'], $v['SaleStatus']);
			}
		}
		
		return $data;
	}

	/**
	 * 获取用户角色
	 *
	 * @param int $enameId        	
	 * @param int $role        	
	 * @param int $bargainor        	
	 * @param int $purchaser        	
	 * @return string
	 */
	public function getEscrowRole($enameId, $role, $bargainor, $purchaser)
	{
		$roleConf = $this->conf->escrowRoleConf->toArray();
		$pLib = new \lib\trans\common\PublicLib();
		$roleLiteConf = $pLib->covertArray($roleConf, 1);
		if($role == $roleConf['buy'][0] && $bargainor == $enameId)
		{
			$type = $roleConf['sale'][1];
		}
		elseif($role == $roleConf['sale'][0] && $purchaser == $enameId)
		{
			$type = $roleConf['buy'][1];
		}
		else
		{
			$type = $roleLiteConf[$role - 1];
		}
		return $type;
	}

	/**
	 * 获取经纪状态
	 *
	 * @param int $status        	
	 * @param int $buyerStatus        	
	 * @param int $sellerStatus        	
	 * @return string
	 */
	public function getEscrowStatus($status, $buyerStatus, $sellerStatus)
	{
		if($status < 2)
		{
			$str = '等待处理';
		}
		elseif($status == 2)
		{
			if($buyerStatus == 1 && $sellerStatus == 1)
			{
				$str = '双方已确认';
			}
			elseif($buyerStatus == 1 && $sellerStatus == 0)
			{
				$str = '买家已确认';
			}
			elseif($buyerStatus == 0 && $sellerStatus == 1)
			{
				$str = '卖家已确认';
			}
			else
			{
				$str = '正在处理';
			}
		}
		elseif($status == 3)
		{
			$str = '委托成功';
		}
		elseif($status == 4)
		{
			$str = '委托失败';
		}
		elseif($status == 5)
		{
			$str = '委托已删除';
		}
		else
		{
			$str = '域名过户';
		}
		return $str;
	}

	/**
	 * 获取我的经纪中介交易数量
	 *
	 * @param int $enameId        	
	 * @return Ambigous <\models\trans\Ambigous, boolean, mixed>
	 */
	public function getEscrowNum($enameId)
	{
		$mod = new \models\trans\EscrowMod();
		return $num = $mod->getEscrowNum($enameId);
	}

	/**
	 * 是否显示价格
	 *
	 * @param int $enameId        	
	 * @param int $type        	
	 * @param int $transType        	
	 * @param int $buyer        	
	 * @param int $seller        	
	 * @param int $status        	
	 * @param int $sellerStatus        	
	 * @param int $buyerStatus        	
	 * @param int $price        	
	 * @return boolean
	 */
	public function isShowPrice($enameId, $type, $transType, $buyer, $seller, $status, $sellerStatus, $buyerStatus, 
		$price)
	{
		$isShow = false;
		if($type == 1)
		{
			// 经纪
			if($transType == 1)
			{
				// 购买
				if($buyer == $enameId || $status >= 3 || ($status == 2 && $sellerStatus == 1))
				{
					// 买方，提交的经纪已经结束，提交的经纪正在处理但是卖家已经确认
					$isShow = true;
				}
				else
				{
					$isShow = false;
				}
			}
			else
			{
				// 出售
				if($seller == $enameId || $status == 3 || ($status == 2 && $buyerStatus == 1))
				{
					// 卖方,提交的经纪已经结束，提交的经纪正在处理但是卖家已经确认
					$isShow = true;
				}
				else
				{
					$isShow = false;
				}
			}
		}
		else
		{
			// 中介
			if($transType == 1)
			{
				// 购买
				if($buyer == $enameId || ($seller == $enameId && $status == 2))
				{
					$isShow = true;
				}
				else
				{
					$isShow = false;
				}
			}
			else
			{
				// 出售
				if($seller == $enameId || ($buyer == $enameId && $status == 2))
				{
					$isShow = true;
				}
				else
				{
					$isShow = false;
				}
			}
		}
		return $isShow? $price :'--';
	}

	public function addEscrowLib($parm)
	{
		$pdPerson = $this->conf->system_pd_person->toArray();
		$escrowMod = new \models\trans\EscrowMod();
		$esId = $escrowMod->addAgency($parm);
		$domainLib = new \interfaces\trans\Domains();
		if($esId)
		{
			$eContactMod = new \models\trans\escrowContactMod();
			$rs = $eContactMod->addContact($parm, $esId);
			if($rs)
			{
				if($parm['type'] == 2)
				{
					// 中介
					if($domainLib->getDomainUs($parm['domainName']) && $parm['enameId'] && is_numeric($parm['enameId']))
					{
						// 派单给专属经纪人
						$escrowLib = new \lib\trans\escrow\EscrowLib();
						$escrowLib->pdEscrow($parm['enameId'], $esId, $pdPerson['person'][0], $parm['domainName']);
					}
				}
				else
				{
					if($parm['enameId'])
					{
						// 派单给专属经纪人
						$escrowLib = new \lib\trans\escrow\EscrowLib();
						$escrowLib->pdEscrow($parm['enameId'], $esId, $pdPerson['person'][0], $parm['domainName']);
					}
				}
				return true;
			}
		}
		return false;
	}

	/**
	 * 检测是否提交过相同域名的经纪交易
	 * 
	 * @param int $userId        	
	 * @param string $domain        	
	 * @param string $mobile        	
	 * @param string $email        	
	 * @param int $transtype        	
	 * @return boolean
	 */
	public function checkEscrowIsExist($userId, $domain, $mobile, $email, $transtype)
	{
		$escrowMod = new \models\trans\EscrowMod();
		return $escrowMod->checkEscrowIsExist($userId, $domain, $mobile, $email, $transtype)? true :false;
	}

	public function getEscrowSure($enameId, $id)
	{
		$escrowMod = new \models\trans\EscrowMod();
		$info = $escrowMod->getEscrowInfo($id);
		if(false === $info)
		{
			throw new \Exception('系统出错');
		}
		$escrowInfo = array();
		// 判断是否有权限查看
		if($info['buyer'] != $enameId && $info['seller'] != $enameId)
		{
			throw new \Exception('无权查看非自己的记录');
		}
		if(2 > $info['status'])
		{
			$escrowStatus = '等待处理';
			$status = '1';
		}
		else 
			if(2 == $info['status'])
			{
				if(1 == $info['buyerstatus'] && 1 == $info['sellerstatus'])
				{
					$escrowStatus = '双方已确认';
					$status = '9';
				}
				else 
					if(1 == $info['buyerstatus'] && 0 == $info['sellerstatus'])
					{
						if($info['sendtime'] != 0 && (0 == $info['sellerstatus'] && $enameId == $info['seller']))
						{
							$escrowStatus = '正在处理'; // 卖家确认
							$status = '13';
						}
						else
						{
							$escrowStatus = '买家已确认';
							$status = '8';
						}
					}
					else 
						if(0 == $info['buyerstatus'] && 1 == $info['sellerstatus'])
						{
							if($info['sendtime'] != 0 && (0 == $info['buyerstatus'] && $enameId == $info['buyer']))
							{
								$escrowStatus = '正在处理'; // 买家确认
								$status = '12';
							}
							else
							{
								$escrowStatus = '卖家已确认';
								$status = '7';
							}
						}
						else
						{
							if($info['sendtime'] != 0 && (0 == $info['buyerstatus'] && $enameId == $info['buyer']))
							{
								$escrowStatus = '买家确认';
								$status = '10';
							}
							else 
								if($info['sendtime'] != 0 && (0 == $info['sellerstatus'] && $enameId == $info['seller']))
								{
									$escrowStatus = '卖家确认';
									$status = '11';
								}
								else
								{
									$escrowStatus = '正在处理';
									$status = '2';
								}
						}
			}
			elseif(3 == $info['status'])
			{
				$escrowStatus = '委托成功';
				$status = '3';
			}
			elseif(4 == $info['status'])
			{
				$escrowStatus = '委托失败';
				$status = '4';
			}
			elseif(5 == $info['status'])
			{
				$escrowStatus = '委托已删除';
				$status = '5';
			}
			else
			{
				$escrowStatus = '域名过户';
				$status = '6';
			}
		$escrowInfo['ESID'] = $info['id'];
		$escrowInfo['Domainname'] = $info['domain'];
		$escrowInfo['FinalPrice'] = $info['final_price'];
		$tprice = $info['percentage'] * 0.01;
		if($info['final_price'] * $tprice <= 200)
		{
			$price = 200;
		}
		else
		{
			$price = $info['final_price'] * $tprice;
		}
		$escrowInfo['price'] = $this->getAgentPrice($enameId, $info['buyer'], $info['seller'], $info['pay_type'],$price);
		$escrowInfo['paymode'] = $info['pay_type'];
		$escrowInfo['escrowStatus'] = $status;
		$escrowInfo['escrowName'] = $escrowStatus;
		
		return $escrowInfo;
	}

	public function escrowBuySure($enameId, $id)
	{
		$esrcowErrorConf = $this->conf->esrcowError->toArray();
		$moneytype = $this->conf->moneytype;
		$escrowMod = new \models\trans\EscrowMod();
		$info = $escrowMod->getEscrowInfo($id);
		if(false === $info)
		{
			throw new \Exception('系统出错');
		}
		if($info['buyer'] != $enameId)
		{
			throw new \Exception($esrcowErrorConf[3]);
		}
		if($info['sendtime'] != 0 && $info['buyerstatus'] == 0 && $enameId == $info['buyer'])
		{
			$orderNum = 0;
			// 是否需要冻结钱,先冻结后变更状态
			if($info['margin'] > 0)
			{
				$domain = $info['domain'];
				$price = $info['margin'];
				$finaceInterface = new \interfaces\trans\Finance($enameId);
				\core\Log::write('addOrder' . $domain . ',' . $moneytype . ',' . $price, 'trans', 'escrow');
				$orderNum = $finaceInterface->addOrder($domain, $moneytype, $price);
				if(false == $orderNum)
				{
					throw new \Exception($esrcowErrorConf[6]);
				}
				
				$rs = $escrowMod->updateEscrowBuySure($id, $orderNum);
				if($rs == false)
				{
					\core\Log::write('更新失败' . $id . ',' . $orderNum, 'trans', 'escrow');
					throw new \Exception('更新失败');
				}
			}
			else
			{
				$rs = $escrowMod->updateEscrowBuySure($id, $orderNum);
				if($rs == false)
				{
					\core\Log::write('更新失败' . $id . ',' . $orderNum, 'trans', 'escrow');
					throw new \Exception('更新失败');
				}
			}
			// 记录日志
			$logRs = $this->addEscrowLog($id, $enameId, $info['distribution'], $info['final_price'], 1);
			// 查找当前买卖家状态
			$escrow = $escrowMod->getEscrowInfo($id);
			if($escrow['buyerstatus'] == 1 && $escrow['sellerstatus'] == 1)
			{
				// 双方都确认变更为等待过户状态
				$rs = $escrowMod->updateEscrowStatus($id, 6);
				if(false == $rs)
				{
					\core\Log::write('更新状态updateEscrowStatus失败' . $id, 'trans', 'escrow');
					throw new \Exception($esrcowErrorConf[7]);
				}
			}
			return true;
		}
		else
		{
			throw new \Exception($esrcowErrorConf[4]);
		}
	}

	public function addEscrowLog($esid, $handler, $distribution, $finalPrice, $transType)
	{
		if($transType == 1)
		{
			$remark = '买家已经确认了委托交易的最终价格:' . $finalPrice . '元';
			$status = 9;
		}
		else
		{
			$remark = '卖家已经确认了委托交易的最终价格:' . $finalPrice . '元';
			$status = 10;
		}
		$escrowTrackMod = new \models\trans\EscrowTrackMod();
		if(!$escrowTrackMod->addLog($esid, $remark, $distribution, $handler, $status))
			\core\Log::write('插入日志失败' . $esid . ',' . $remark . ',' . $distribution . ',' . $handler, 'trans', 'escrow');
		return true;
	}

	public function escrowSellerSure($enameId, $id)
	{
		$esrcowErrorConf = $this->conf->esrcowError->toArray();
		$domainStatusConf = $this->conf->information_type->toArray();
		$domainMystatusConf = $this->conf->fabu_domain_mystatus->toArray();
		$moneytype = $this->conf->moneytype;
		$escrowMod = new \models\trans\EscrowMod();
		$domainInterface = new \interfaces\trans\Domains();
		$info = $escrowMod->getEscrowInfo($id);
		if(empty($info))
		{
			throw new \Exception('系统出错');
		}
		if($info['seller'] != $enameId)
		{
			throw new \Exception($esrcowErrorConf[3]);
		}
		if($info['sendtime'] != 0 && $info['sellerstatus'] == 0 && $info['seller'] == $enameId)
		{
			$domains = explode('/', $info['domain']);
			$successDomains = array();
			foreach($domains as $domain)
			{
			    $domain =trim($domain);
				$rs = $domainInterface->getDomainUs($domain);
				if($rs['result'])
				{
					// 判断域名是否属于用户
					$rsu = $domainInterface->getDomainForUser($enameId, $domain);
					if($rsu['result'] == false)
					{
						\core\Log::write(
							'判断域名是否属于用户失败' . $domain . ',' . Response::getErrMsg() . ',' . Response::getErrCode(), 'trans',
							'escrow');
						if($successDomains)
						{
							// 会滚之前成功的域名
							foreach($successDomains as $sdomain)
							{
								$rs = $domainInterface->setDomainMyStatus($sdomain, $domainMystatusConf['down'][0]);
								if($rs['result'] == false)
								{
									\core\Log::write(
											'回滚域名状态失败' . $sdomain . ',' . $domainMystatusConf['down'][0] . ',' .
											Response::getErrMsg() . ',' . Response::getErrCode(), 'trans', 'escrow');
								}
							}
						}
						throw new \Exception(Response::getErrMsg(), Response::getErrCode());
					}
					// 我司域名,设置域名状态为经纪中介
					$rs = $domainInterface->setDomainMyStatus($domain, $domainStatusConf['escrow'][0]);
					if($rs['result'] == false)
					{
						\core\Log::write(
							'更新域名状态失败' . $domain . ',' . $domainStatusConf['escrow'][0] . ',' . Response::getErrMsg() .
								 ',' . Response::getErrCode(), 'trans', 'escrow');
						if($successDomains)
						{
							// 会滚之前成功的域名
							foreach($successDomains as $sdomain)
							{
								$rs = $domainInterface->setDomainMyStatus($sdomain, $domainMystatusConf['down'][0]);
								if($rs['result'] == false)
								{
									\core\Log::write(
										'回滚域名状态失败' . $sdomain . ',' . $domainMystatusConf['down'][0] . ',' .
											 Response::getErrMsg() . ',' . Response::getErrCode(), 'trans', 'escrow');
								}
							}
						}
						throw new \Exception(Response::getErrMsg(), Response::getErrCode());
					}
					else
					{
						$successDomains[] = $domain;
					}
				}
			}
			// 更新状态
			$rs = $escrowMod->updateEscrowSellerSure($id);
			if(false == $rs)
			{
				throw new \Exception('更新失败');
			}
			// 记录日志
			$logRs = $this->addEscrowLog($id, $enameId, $info['distribution'], $info['final_price'], 2);
			// 查找当前卖家状态
			$escrow = $escrowMod->getEscrowInfo($id);
			if($escrow['buyerstatus'] == 1 && $escrow['sellerstatus'] == 1)
			{
				// 双方都确认变更为等待过户状态
				$rs = $escrowMod->updateEscrowStatus($id, 6);
				if(false == $rs)
				{
					throw new \Exception($esrcowErrorConf[7]);
				}
			}
			return true;
		}
		else
		{
			throw new \Exception($esrcowErrorConf[5]);
		}
	}

	/**
	 * 获取经纪人昵称
	 *
	 * @return array
	 */
	public function getAllMember()
	{
		$roleConf = $this->conf->memRole->toArray();
		;
		$eMemberMod = new \models\trans\EscrowMemberMod();
		$data = $eMemberMod->getAllMember();
		$all = array();
		if($data)
		{
			foreach($data as $val)
			{
				$remark = in_array($val['member_role'], array($roleConf['admin'][0],$roleConf['finance'][0]))? '' :'经纪人';
				$all[$val['member_nick']] = $remark . $val['member_nick'];
				$all[$val['member_adminid']] = $remark . $val['member_nick'];
			}
		}
		return $all;
	}

	public function getEscrowLog($esid)
	{
		$escrowTrackMod = new \models\trans\EscrowTrackMod();
		return $escrowTrackMod->getEscrowLog($esid);
	}
	
	/**
	 * 判断中介费是否需要显示
	 * @param int $enameId
	 * @param int $buyer
	 * @param int $seller
	 * @param int $payType,1买家支付 2卖家支付 3双方各付一半
	 * @param int $price 中介费
	 */
	public function getAgentPrice($enameId,$buyer,$seller,$payType,$price)
	{
		$agentPrice = 0;
		switch($payType)
		{
			case 1:
				if($enameId == $buyer)
				{
					$agentPrice = $price;
				}
				break;
			case 2:
				if($enameId == $seller)
				{
					$agentPrice = $price;
				}
				break;
			case 3:
				$agentPrice = $price*0.5;
				break;
		}
		return $agentPrice;
	}
}
?>
<?php
namespace lib\trans\common;
use core;
class PublicDomainLib
{
	
	private $conf;
	public function __construct()
	{
		//加载配置
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
	}

	/**
	 * 获取域名分组和长度
	 * 
	 * @param unknown $type        	
	 * @return multitype:number Ambigous <number, unknown>
	 */
	public function getSysGroup($type)
	{
		$sysGroupOne = 0;
		$sysGroupTwo = 0;
		$domainLen = 0;
		// 加载配置
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
		$tsDomainGroup = $conf->ts_domaingroup->toArray();
		if(isset($tsDomainGroup[$type]))
		{
			$temp = $tsDomainGroup[$type];
			if(isset($temp['sysone']))
			{
				$sysGroupOne = $temp['sysone'];
			}
			elseif(isset($temp['systwo']))
			{
				$sysGroupTwo = $temp['systwo'];
			}
			else
			{
				$sysGroupOne = array($temp['start'],$temp['end']);
			}
			if(isset($temp['len']))
			{
				$domainLen = $temp['len'];
			}
		}
		
		return array('sysGroupOne' => $sysGroupOne,'sysGroupTwo' => $sysGroupTwo,'domainLen' => $domainLen);
	}
	
	/**
	 * 域名搜索
	 */
	public function getDomainSearch($domain, $tld, $searchTldConf, $formTldConf = FALSE)
	{
		$domainArr = explode('.', $domain);
		if($tld)
		{
			$formTld = $formTldConf ? $formTldConf[$tld] : $tld;
			//如果表单有传后缀，则已表单的为准
			return array('sld' => $domainArr[0], 'tld' => $tld, 'formTld' => $formTld);
		}
		else
		{
			//如果表单没传后缀，则分析传过来的字符串是否有后缀
			$level = count($domainArr);
			if($level == 1)
			{
				//无后缀
				return array('sld' => $domain, 'tld' => false, 'formTld' => '');
			}
			//检查是否是汉字.cn
			$strTld = ($level == 3) ? ($domainArr[1] . '.' . $domainArr[2]) : $domainArr[1];
			$strTld = "." . $strTld;
			//若是非法后缀
			if(!empty($searchTldConf[$strTld]))
			{
				$formTld = $formTldConf ? $formTldConf[$searchTldConf[$strTld]] : $searchTldConf[$strTld];
				return array('sld' => $domainArr[0], 'tld' => $searchTldConf[$strTld], 'formTld' => $formTld);
			}
			return array('sld' => $domainArr[0], 'tld' => false, 'formTld' => '');
		}
	}
	
	/**
	 * 获取域名最后一级后缀
	 * @param string $domain
	 * @return string
	 */
	public static function getDomainClass($domain)
	{
		$domainArr = explode('.', $domain);
		return strtoupper($domainArr[count($domainArr) - 1]);
	}
	/**
	 * 判断是否是中文域名 判断是否有汉字
	 * @param string $domain
	 * @return boolean
	 */
	public static function isCnDomain($domain)
	{
		if(preg_match("/[\x{4e00}-\x{9fa5}]+/u", $domain))
		{
			return TRUE;
		}
		return FALSE;
	}
	/**
	 * 获取域名类型
	 * @param string $domain
	 * @return number
	 */
	public static function getDomainClassName($domain)
	{
		$domLtd = self::getDomainClass($domain);
		if($domLtd == 'CN' && self::isCnDomain($domain))
		{
			return 3;//汉字.cn
		}
		elseif($domLtd == 'CN' && self::isCnDomain($domain) == false)
		{
			return 1;//zbc.cn
		}
		elseif($domLtd == '中国' || $domLtd == '公司' || $domLtd == '网络')
		{
			return 3;//zbc.中国
		}
		elseif(($domLtd == 'COM' || $domLtd == 'NET') && self::isCnDomain($domain))
		{
			return 4;//汉字.com
		}
		else
		{
			return 2;
		}
	}
	
	/**
	 * 获取域名后缀类型
	 */
	public function getDomainClassAll($domain)
	{
		$TLDArr = $this->conf->trans_domain_domainTLD->toArray();
		$domainArr = explode('.', $domain);
		$TLD = count($domainArr) == 3 ? ($domainArr[1] . '.' . $domainArr[2]) : $domainArr[1]; //str
		//CN域名
		if(strtolower($TLD) == 'cn')
		{
			if(self::isCnDomain($domainArr[0]))
				$TLDval = array_keys($TLDArr, '中文.cn');
			//中文.cn
			else
				$TLDval = array_keys($TLDArr, 'cn'); //英文.cn
			return $TLDval[0];
		}
		//.中国 域名
		if($TLD == '中国')
		{
			if(self::isCnDomain($domainArr[0]))
				$TLDval = array_keys($TLDArr, '中文.中国');
			//中文.中国
			else
				$TLDval = array_keys($TLDArr, '英文.中国'); //英文.中国
			return $TLDval[0];
		}
		$TLDval = array_keys($TLDArr, $TLD); //val
		//不在配置里的域名归纳为OtherCn,即返回23
		if(empty($TLDval))
		{
			$TLDval = array_keys($TLDArr, 'OtherCn');
		}
		return $TLDval[0];
	}
	/**
	 *获取字符串长度（包含中文）
	 * @param unknown $str
	 * @return number
	 */
	public function abslength($str)
	{
		if(empty($str))
			return 0;
		if(function_exists('mb_strlen'))
			return mb_strlen($str, 'utf-8');
		else
		{
			preg_match_all("/./u", $str, $ar);
			return count($ar[0]);
		}
	}
	/**
	 * 获取域名主体部分
	 * @param string $domain
	 * @return string
	 */
	public function getDomainBody($domain)
	{
		$domainArr = explode('.', $domain);
		return strtoupper($domainArr[0]);
	}
	
	public function getDomainGroup($getDomainGroup,$defaultTsDomainGroup)
	{
		$sysGroupOne	= '';
		$sysGroupTwo	= '';
		$domainLen	= False;
		if($getDomainGroup)
		{
			$temp = $defaultTsDomainGroup[$getDomainGroup][1];
			if(isset($temp['rank']))
			{
				$sysGroupOne = array($temp['rank'][0],$temp['rank'][1]);
				if(isset($temp['rank'][2]))
				{
					$domainLen = $temp['rank'][2];
				}
			}
			elseif(isset($temp['sysone']))
			{
				$sysGroupOne = $temp['sysone'];
			}
			elseif(isset($temp['systwo']))
			{
				$sysGroupTwo = $temp['systwo'];
			}
			unset($temp);
		}
		return array('sysGroupOne'=>$sysGroupOne,'sysGroupTwo'=>$sysGroupTwo,'domainLen'=>$domainLen);
	}
	/**
	 * checkDomain
	 * 检验域名是否格式正确
	 */
	public static function checkDomain($domain)
	{
		$ok = FALSE;
		if(preg_match("/^([\x{4e00}-\x{9fa5}]|[a-zA-Z0-9-])+(\.[a-z]{2,4})?\.([a-z]{2,4}|[\x{4e00}-\x{9fa5}]{2,2})$/ui",
			$domain))
		{
			if(substr($domain, 0, 1) != '-') // 去掉-开头的域名 && stripos($domain,'--')===FALSE
			{
				$ok = true;
			}
		}
		return $ok;
	}
	public static function replaceL($str)
	{
		return str_replace("l","L",$str);
	}

	/**
	 * 转换小写l为大写L
	 * @param array $array 需要转换的二维数组
	 * @param string $key 需要转换的子数组键名
	 * @return array 转换后的二维数组
	 */
	public static function arrayReplaceL($array, $key)
	{
		if(\is_array($array) && $array)
		{
			foreach ($array as &$value)
			{
				if(isset($value[$key]))
				{
					$value[$key] = self::replaceL($value[$key]);
				}
			}
		}
		return $array;
	}
}
?>
<?php
namespace lib\manage\verify;
use models\manage\verify\IdentityVerifyMod;

use models\manage\verify\EmailVerifyMod;

class VerifyLib
{
	private $verifyMod;
	function __construct($model = 'company')
	{
		if($model == 'email')
		{
			$this->verifyMod = new \models\manage\verify\EmailVerifyMod();
		}
		if($model == 'company')
		{
			$this->verifyMod = new \models\manage\verify\CompanyVerifyMod();
		}
		if($model == 'identity')
		{
			$this->verifyMod = new \models\manage\verify\IdentityVerifyMod();
		}
	}
	/**
	 * 生成默认6位验证码
	 */
	public function randomCaptcha($len = 6, $type = 0)
	{
		switch($type)
		{
			case 0:
				$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
				break;
			case 1:
				$chars = '0123456789';
				break;
		}
		$password = '';
		while(strlen($password) < $len)
			$password .= substr($chars, (mt_rand() % strlen($chars)), 1);
		return $password;
	}
	
	/**
	 * IdentityList格式化数据
	 * @param array $identityList
	 * @param array $identityStatus
	 * @return array $identityList
	 */
	public function actionIdentityList($list,$timeout = FALSE,$model = FALSE)
	{
		if(empty($list))
		{
			return array();
		}
		//判断是否过期，过期则修改
		if($timeout)
		{
			foreach($list as $k => $v)
			{
				if($v['VerifyStatus']==2 || $v['VerifyStatus'] == 4)
				{
					continue;
				}
				$time= strtotime(date("Y-m-d h:i:s"))-strtotime($v['CreateTime']);
				if($time>$timeout)
				{
					$this->verifyMod->setVerifyInfo(array('Id' => $v['Id'],'VerifyStatus' => 3));
				}
			}
		}
		$lib = new \lib\manage\domain\TemplateLib();
		foreach($list as $k => $v)
		{
			if($v['VerifyStatus'] == 4)
			{
				continue;
			}
			if($model == 'identity')
			{
				$list[$k]['IdCard']= $this->hideIdentity($v['IdCard']);
				$result = $lib->getTemplateCount(array('EnameId' => $v['EnameId'], 'Name' => $v['Name'], 'IsShow' => 1 ,'in' => array('TemplateType' => array('1,3,4'))));
			}
			elseif($model == 'email')
			{
				$result = $lib->getTemplateCount(array('EnameId' => $v['EnameId'], 'Email' => $v['Email'], 'IsShow' => 1));
			}
			elseif($model == 'company')
			{
				$result = $lib->getTemplateCount(array('EnameId' => $v['EnameId'], 'Org' => $v['CompanyName'], 'TemplateType' => 1, 'IsShow' => 1));
			}
			$list[$k]['isUsedTemplate'] = !empty($result) && $v['VerifyStatus'] != 3 ? 1 : 0;
		}
		return $list;
	}
	private function hideIdentity($identity)
	{
		$len= strlen($identity);
		$identity= substr_replace($identity,'******',$len-6);
		return $identity;
	}
	
	/**
	 * 获取认证通过的企业认证
	 * @param int $enameid
	 * @return array $identityList
	 */
	public function getVerfifyCompany($enameid,$orgname= FALSE)
	{
		$mod = new \models\manage\verify\CompanyVerifyMod();
		$params = array('EnameId' => $enameid, 'VerifyStatus' => '2');
		if($orgname)
		{
			$params['CompanyName'] = $orgname;
		}
		$list = $mod->getVerifyInfo($params);
		return $list;
	}
	/**
	 * 获取认证通过的身份认证
	 * @param int $enameid
	 * @param string $name
	 * @param int $type 1平台认证 2bbs认证 3交易认证
	 * @return array $identityList
	 */
	public function getVerfifyIdentity($enameid, $name = FALSE, $type = 1)
	{
		$mod = new \models\manage\verify\IdentityVerifyMod();
		$params = array('EnameId' => $enameid, 'VerifyStatus' => '2');
		if($name)
		{
			$params['Name'] = $name;
		}
		if($type)
		{
			$params['Type'] = $type;
		}
		$list = $mod->getVerifyInfo($params);
		return $list;
	}
	/**
	 * 获取认证通过的邮箱认证
	 * @param int $enameid
	 * @return array $identityList
	 */ 
	public function getVerfifyEmail($enameid,$email = FALSE)
	{
		$mod = new \models\manage\verify\EmailVerifyMod();
		$params = array('EnameId' => $enameid, 'VerifyStatus' => '2');
		if($email)
		{
			$params['Email'] = $email;
		}
		$list = $mod->getVerifyInfo($params);
		return $list;
	}
	/**
	 * 根据ID获取姓名认证信息
	 * @param int $id
	 * @return array $identityList
	 */
	public function getUserVerifyNameById($id)
	{
		$list = $this->verifyMod->getVerifyById($id);
		if($list)
		{
			return $list['Name'];
		}
		return false;
	}
	
	public function getUserVerifyNameInfoById($id)
	{
		$list = $this->verifyMod->getVerifyById($id);
		if($list)
		{
			return $list;
		}
		return false;
	}
	
	/**
	 * 根据ID获取邮箱认证信息
	 * @param int $id
	 * @return array $identityList
	 */
	public function getUserVerifyMailById($id)
	{
		$list = $this->verifyMod->getVerifyById($id);
		if($list)
		{
			return $list['Email'];
		}
		return false;
	}
	/**
	 * 根据ID获取企业认证信息
	 * @param int $enameid
	 * @return array $identityList
	 */
	public function getUserVerifyCompanyById($id)
	{
		$list = $this->verifyMod->getVerifyById($id);
		if($list)
		{
			return $list['CompanyName'];
		}
		return false;
	}
	
	public function getUserVerifyCompanyInfoById($id)
	{
		$list = $this->verifyMod->getVerifyById($id);
		if($list)
		{
			return $list;
		}
		return false;
	}
	
	/**
	 * 获取企业认证和身份认证的统计信息
	 */
	public function getCustomerCount()
	{
		$CompanyMod = new \models\manage\verify\CompanyVerifyMod();
		$identityMod = new \models\manage\verify\IdentityVerifyMod();
		$compInfo = $CompanyMod->getVerifyCountGroup();
		$idInfo = $identityMod->getVerifyCountGroup(7);
		$compInfo = $compInfo ? $compInfo : array();
		$idInfo = $idInfo ? $idInfo : array();
		return  array_merge($compInfo,$idInfo);//
	}
}

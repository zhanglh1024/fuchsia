<?php
namespace lib\manage\queue;
class MailLib
{
	/**
	 * 发送邮件
	 * @param string $email
	 * @param string $Subject 有加爱你标题
	 * @param string $AltBody 邮件文本内容
	 * @param string $HtmlBody 邮件html正文
	 * @param unknown_type $TemplateId
	 * @return boolean
	 */
	public function send($email, $subject, $altBody, $htmlBody, $templateId = '')
	{
		//判断邮箱是否在白名单内，不在则返回成功但不发送邮件
		$ckWhiteLib = new CheckWhiteLib();
		if(FALSE == $ckWhiteLib->isWhiteMail($email))
		{
			return TRUE;
		}

		//加载发邮件配置
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'queue');
		$mailerConfig = $conf->mailerCom->toArray();
		$mail = new \lib\manage\queue\PHPMailer();

		//邮件编码设置
		$emailArray = explode('@', $email);
		$emailSuffix = str_replace(".", "", $emailArray[1]);
		if(isset($conf->mailCodes->$emailSuffix) && $conf->mailCodes->$emailSuffix)
		{
			$mail->CharSet = $conf->mailCodes->$emailSuffix;
			$mailerConfig['sender'] = iconv("utf-8", $mail->CharSet . "//IGNORE", $mailerConfig['sender']);
			$subject = iconv("utf-8", $mail->CharSet . "//IGNORE", $subject);
			$altBody = iconv("utf-8", $mail->CharSet . "//IGNORE", $altBody);
			$htmlBody = iconv("utf-8", $mail->CharSet . "//IGNORE", $htmlBody);
		}
		else
		{
			$mail->CharSet = 'utf-8';
		}
		$mail->IsSMTP();
		$mail->SMTPAuth = $mailerConfig['SMTPAuth'];
		$mail->SMTPSecure = $mailerConfig['SMTPSecure'];
		$mail->Host = $mailerConfig['Host'];
		$mail->Port = $mailerConfig['Port'];
		$mail->Username = $mailerConfig['Username'];
		$mail->Password = $mailerConfig['Password'];

		//设置回复邮件地址Send
		$mail->AddReplyTo($mailerConfig['senderMail'], $mailerConfig['sender']);
		//设置发信人地址
		$mail->SetFrom($mailerConfig['senderMail'], $mailerConfig['sender']);
		//设置收件人地址
		$mail->AddAddress($email, $email);
		//相关模板秘密抄送
		if(in_array($templateId, explode(",", $mailerConfig['FOATemp'])))
		{
			$mail->AddBCC($mailerConfig['MailBcc']);
		}
		//邮件标题
		$mail->Subject = $subject;
		//邮件文本内容
		$mail->AltBody = $altBody;
		//邮件html内容
		$mail->MsgHTML($htmlBody);
		$result = @$mail->Send();
		return $result;
	}
}

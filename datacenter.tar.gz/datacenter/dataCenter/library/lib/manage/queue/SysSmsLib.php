<?php
namespace lib\manage\queue;
/**
 * 手机短信接口
 *
 */
class SysSmsLib
{
	private $sdkUrl;
	private $adSdkUrl;
	private $sn;
	private $pwd;
	private $method = 'mt';
	private $sign;
	private $logFolder;
	private $userMobile;
	
	public function __construct()
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'queue');
		$this->sdkUrl = $conf->sysSms->sdkUrl;
		$this->adSdkUrl = $conf->sysSms->adSdkUrl;
		$this->sn = $conf->sysSms->sn;
		$this->pwd = $conf->sysSms->pwd;
		$this->sign = $conf->sysSms->sign;
		$this->logFolder = $conf->sysSms->logFolder;
	}

	/**
	 * 查询短信接口账户余额
	 * @return int|boolean
	 */
	public function getBalance()
	{
		$this->method = 'GetBalance';
		$param = array();
		$param['sn'] = $this->sn;
		$param['pwd'] = $this->pwd;
		$rs = $this->doPost($this->getUrl(), $param);
		$rs = $this->formatResult($rs);
		if($rs && is_numeric($rs))
		{
			return $rs;
		}
		return FALSE;
	}

	/**
	 * 发送短信，支持批量(同内容，不同手机号)
	 * @param string $phones 允许多个手机号码，英文逗号隔开，最多3000个
	 * @param string $msg
	 * @return boolean
	 */
	public function sendSms($phones, $msg, $log = TRUE)
	{
		$phones = $this->checkWhitePhones($phones);
		if(TRUE === $phones)
		{
			return TRUE;
		}
	
		$phones = $this->checkPhones($phones);
		if(empty($phones) or empty($msg))
		{
			return FALSE;
		}
		$this->method = 'mdSmsSend_u';
		$param = array();
		$param['sn'] = $this->sn;
		$param['pwd'] = strtoupper(md5($this->sn . $this->pwd));
		$param['mobile'] = $phones;
		$param['content'] = $msg . $this->sign;
		$param['ext'] = '';
		$param['stime'] = '';
		$param['rrid'] = date('YmdHis') . sprintf('%0d', rand(1, 99));
		$rs = $this->doPost($this->getUrl(), $param, "UTF-8");
		if($log)
		{
			$this->addLog(array('mobile' => $phones, 'rrid' => $param['rrid'], 'result' => $rs));
		}
		if(FALSE != $this->formatResult($rs))
		{
			return TRUE;
		}
		return FALSE;
	}

	/**
	 * 发送短信，支持批量(不同内容，不同手机号)
	 * @param string $phones 最多1000个手机号
	 * @param array $msg 内容与手机号一一对应，不要包含英文逗号
	 * @return boolean
	 */
	public function sendGxSms($phones, $contents)
	{
		$phones = $this->checkWhitePhones($phones);
		if(TRUE === $phones)
		{
			return TRUE;
		}

		$phones = $this->checkPhones($phones);
		$contents = $this->checkContents($contents);
		if(empty($phones) or empty($contents) or count($phones) != count($contents))
		{
			return FALSE;
		}

		$this->method = 'gxmt';
		$param = array();
		$param['sn'] = $this->sn;
		$param['pwd'] = strtoupper(md5($this->sn . $this->pwd));
		$param['mobile'] = $phones;
		$param['content'] = $contents;
		$param['ext'] = '';
		$param['stime'] = '';
		$param['rrid'] = date('YmdHis') . sprintf('%0d', rand(1, 99));
		$rs = $this->doPost($this->getUrl(), $param);
		$this->addLog(array('mobile' => $phones, 'rrid' => $param['rrid'], 'result' => $rs));
		if(FALSE != $this->formatResult($rs))
		{
			return TRUE;
		}
		return FALSE;
	}

	/**
	 * 发送语音短信，支持批量(同内容，不同手机号)
	 * @param string $phones 多个手机号码请以英文逗号隔开，最多2000个
	 * @param string $title 40字符以内
	 * @param string $txt 200字符以内
	 * @return boolean
	 */
	public function sendAudioSms($phones, $title, $txt)
	{
		$phones = $this->checkWhitePhones($phones);
		if(TRUE === $phones)
		{
			return TRUE;
		}

		$phones = $this->checkPhones($phones);
		if(empty($phones) or empty($txt))
		{
			return FALSE;
		}

		$this->method = 'mdAudioSend';
		$param = array();
		$param['sn'] = $this->sn;
		$param['pwd'] = strtoupper(md5($this->sn . $this->pwd));
		$param['mobile'] = $phones;
		$param['title'] = $this->switchEncoding($title . $this->sign);
		$param['txt'] = $this->switchEncoding($txt);
		$param['content'] = '';
		$param['srcnumber'] = '';
		$param['stime'] = '';
		$rs = $this->doPost($this->getUrl($this->adSdkUrl), $param);
		$this->addLog(array('mobile' => $phones, 'result' => $rs));
		if(FALSE != $this->formatResult($rs))
		{
			return TRUE;
		}
		return FALSE;
	}

	/**
	 * 判断手机号是否在白名单内，不在则返回成功但不发送短信
	 * @param string $phones
	 * @return string|boolean
	 */
	private function checkWhitePhones($phones)
	{
		$ckWhiteLib = new CheckWhiteLib();
		$phones = $ckWhiteLib->isWhitePhone($phones);
		if(FALSE == $phones)
		{
			return TRUE;
		}
		return $phones;
	}

	/**
	 * 多个手机号码格式检测
	 * @param array $phones|string
	 * @return boolean|string
	 */
	private function checkPhones($phones)
	{
		if(is_string($phones))
		{
			$phones = explode(',', $phones);
		}
		if(is_array($phones))
		{
			//多个手机号的情况
			foreach($phones as $val)
			{
				if(!$this->IsMobilePhone($val))
				{
					return FALSE;
				}
			}
			return implode(',', $phones);

		}
		return $phones;
	}

	/**
	 * 手机号码格式判断
	 * @param string $phone
	 * @return boolean
	 */
	private function IsMobilePhone($phone)
	{
		return preg_match("/^1[0-9]{10}$/", $phone) ? TRUE : FALSE;
	}

	private function checkContents($contents)
	{
		if(is_array($contents))
		{
			foreach($contents as $key => $val)
			{
				$contents[$key] = $this->switchEncoding($val . $this->sign);
			}
			return implode(',', $contents);
		}
		return FALSE;
	}

	/**
	 * 获取请求地址
	 * @return string
	 */
	private function getUrl($url = '')
	{
		return ($url ? $url : $this->sdkUrl) . '/' . $this->method . '?';
	}

	/**
	 * 转码
	 * @param string $str
	 * @param string $toCode
	 * @param string $fromCode
	 * @return string
	 */
	private function switchEncoding($str, $toCode = 'gb2312', $fromCode = 'auto')
	{
		return mb_convert_encoding($str, $toCode, $fromCode);
	}

	/**
	 * curl post 请求接口，语音短信编码必须是gb2312
	 * @param string $url
	 * @param array $data
	 * @return mixed
	 */
	private function doPost($url, $data, $charset = "gb2312")
	{
		$cn = 3;
		while($cn--)
		{
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(
					"Content-Type: application/x-www-form-urlencoded; charset=" . $charset));
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
			$result = curl_exec($ch);
			curl_close($ch);
			if(!empty($result))
			{
				return $result;
			}
		}
		return FALSE;
	}

	/**
	 * 接口返回结果处理
	 * @param string $result xml格式
	 * @return boolean|Ambigous <>
	 */
	private function formatResult($result)
	{
		if(preg_match("/<string[\s]*(.*?)>[\s]*(.*?)[\s]*<\/string>/i", $result, $regs))
		{
			$result = explode(" ", $regs[2]);
			if(is_numeric($result[0]) && $result[0] < 0)
			{
				return FALSE;
			}
			return $result[0];
		}
		return FALSE;
	}

	/**
	 * 写日志
	 */
	private function addLog($message)
	{
		if($this->logFolder)
		{
			return \core\Log::write(json_encode($message), $this->logFolder);
		}
		return FALSE;
	}
}

<?php
namespace lib\manage\domain;
use core\Response;
use lib\manage\common\DomainFunLib;
class DomainEppLib
{
	public $sdk;
	public function __construct($enameId = false)
	{
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$this->sdk = new \ApiSdk();
	}

	/**
	 * 设置域名注册局状态 5012
	 * @param string $domain
	 * @param int $register
	 * @param array $status
	 * @return boolean 
	 */
	public function setDomainRegisterStatus($domain, $register, $status = FALSE)
	{
		if(FALSE === $status)
		{
			$status = array(3, 4);
		}
		$params = array('domain' => $domain, 'status' => $status, 'registrarID' => $register);
		$info = $this->sdk->execSdkFun(5012, $params);
		\lib\manage\domain\DomainLogsLib::addDomainService($domain, json_encode(array('memo' => 'dc_modify_status',
				'param' => $params, 'return' => $info,
				'url' => isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '')), 20);//viyatodo
		if($info['resultCode'] == 5000)
		{
			return $info;
		}
		//重复修改的当做成功来处理
		if($info['resultCode'] != 5000 && !empty($info['data']['msg']['resultMsg']) && stripos($info['data']['msg']['resultMsg'],'nothing done')!==false)
		{
			$info['resultCode']=5000;
			return $info;
		}
		if($info['resultCode'] != 5000 && !empty($info['data']['msg']['resultMsg']) && stripos($info['data']['msg']['resultMsg'],'the same')!==false)
		{
			$info['resultCode']=5000;
			return $info;
		}
		Response::setErrMsg(370001, "修改注册局状态失败");
		return FALSE;
	}

	/**
	 * 查看域名注册局信息
	 */
	public function getDomainRegInfo($domain, $registrarId = false, $return = false)
	{
		$data['domain'] = $domain;
		if($registrarId !== false)
		{
			$data['registrarID'] = $registrarId;
		}
		$info = $this->sdk->execSdkFun(5025, $data);
		if($return)
		{
			return $info;
		}
		if($info['resultCode'] == 5000)
		{
			return $info['data'];
		}
		Response::setErrMsg(370002, "查询域名注册局信息失败");
		return FALSE;
	}

	/**
	 * 查询注册局转移信息
	 */
	public function getDomainRegTransInfo($domain, $registrarId = '', $throw = false, $pwd = '')
	{
		$data = array();
		if(!empty($domain))
		{
			$data['domain'] = $domain;
		}
		if(!empty($registrarId))
		{
			$data['registrarID'] = $registrarId;
		}
		if(!empty($pwd))
		{
			$data['password'] = $pwd;
		}
		$info = $this->sdk->execSdkFun(5028, $data);
		if($info['resultCode'] == 5000)
		{
			return $info['data'];
		}
		Response::setErrMsg(370003, "查询域名注册局转移信息失败");
		return FALSE;
	}

	/**
	 * 修改域名dns
	 */
	public function setDomainDns($domain, $dnsId, $dns, $registrarId, $returnAll = false)
	{
		$data = array('domain' => $domain, 'dnsId' => $dnsId, 'DNS' => $dns, 'registrarID' => $registrarId);
		$info = $this->sdk->execSdkFun(5013, $data);
		\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('memo' => '修改DNS', 'param' => $data,
				'return' => $info), 8);
		if($returnAll)
		{
			return $info;
		}
		if($info['resultCode'] == 5000)
		{
			return $info;
		}
		Response::setErrMsg(370004, "修改域名dns信息失败");
		return FALSE;
	}

	/**
	 *域名申请转入
	 */
	public function refuseTransferOutDomain($domain, $registrarId)
	{
		$param = array('domain' => $domain, 'registrarID' => $registrarId);
		$cancelInfo = $this->sdk->execSdkFun(5030, $param);
		\lib\manage\domain\DomainLogsLib::addDomainService($domain, json_encode(array('memo' => 'cancel_transrer',
				'param' => $param, 'return' => $cancelInfo)), 15);
		if($cancelInfo['resultCode'] == 5000)
		{
			return $cancelInfo;
		}
		return FALSE;
	}
	/**
	 * 获取转移秘密
	 */
	public function changeDomainPass($domain, $registrarId, $password, $memo = 'transfer_out')
	{
		$outData = array('domain' => $domain, 'password' => $password, 'registrarID' => $registrarId);
		$info = $this->sdk->execSdkFun(5026, $outData);
		\lib\manage\domain\DomainLogsLib::addDomainService($domain, json_encode(array('memo' => $memo,
				'param' => $outData, 'return' => $info)), 11, '');
		if($info['resultCode'] == 5000)
		{
			return $info;
		}
		return FALSE;
	}
	/**
	 * 域名申请转chu
	 */
	public function transferOutDomain($domain, $registrarId, $enameid)
	{
		if($registrarId == 41)
		{
			$serverInfo = $this->sdk->execSdkFun(5025, array('domain' => $domain,'registrarID' => $registrarId));
			if($serverInfo['resultCode'] != 5000)
			{
				return false;
			}
			$param = array('domain' => $domain,'registrarID' => $registrarId, 'password'=> $serverInfo['data']['password']);
		}
		else
		{
			$param = array('domain' => $domain, 'registrarID' => $registrarId);
		}
		$info = $this->sdk->execSdkFun(5031, $param);
		\lib\manage\domain\DomainLogsLib::addDomainLog($domain, $enameid, 5, $param, $info,  '同意转出', $info['resultCode'] == 5000 ? true : false);
		if($info['resultCode'] == 5000)
		{
			return $info;
		}
		return FALSE;
	}
	/**
	 * 注册局接口注册模板
	 * @param string $domain
	 * @param string $templateId
	 * @param int $registrarId
	 * @return boolean
	 */
	public function interfaceRegTemplate($domain, $templateId, $registrarId = FALSE, $locData = array(),$templateName = FALSE,$tempType=FALSE)
	{
		$data = array('domain' => $domain, 'templateId' => $templateId);
		if($registrarId)
		{
			$data['registrarID'] = $registrarId;
		}
		if($locData)
		{
			$data = array_merge($data, $locData);
		}
		//$data['tmplType'] = $tempType ==1  || $tempType == 7 ? 'e' : 'i';
		$info = $this->sdk->execSdkFun(5102, $data);
		\lib\manage\domain\DomainLogsLib::addDomainService('temp_' . $templateId, array('memo' => 'create_template', 'param' => $data,
				'return' => $info), 18);
		if($info['resultCode'] != 5000)
		{
			if(!empty($info['data']['msg']['resultMsg']) && (stripos($info['data']['msg']['resultMsg'],'Object exists')!==FALSE || stripos($info['data']['msg']['resultMsg'],'already exists')!==FALSE))
			{
				$epp = $this->getDomainEpp($domain);
				if($epp)
				{
					$info['data']['epp'] = $epp;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return FALSE;
			}
		}
// 		$this->addTemplateLoc($locData, $templateId, $templateName);
		return $info['data']['epp'];
	}
	
	public function getDomainEpp($domain)
	{
		$regidlist = array("ename.top" => 86, "ename.wang"=>86,'ename.org'=>41,"ename.biz" => 82, "ename.asia" => 31, "ename.pw" => 51,"ename.cn"=>1,"ename.公司"=>71,"ename.公司"=>71);
		if(array_key_exists($domain, $regidlist))
		{
			return $regidlist[$domain];
		}
		return FALSE;
	}
	
	/**
	 * 修改模板
	 */
	public function updateTemplateApi($templateId, $domain, $resistarId, $locData = array(),$templateName = '')
	{
		$data = array('templateId' => $templateId, 'domain' => $domain, 'registrarID' => $resistarId);
		if($locData)
		{
			$data = array_merge($data, $locData);
		}
		$info = $this->sdk->execSdkFun(5113, $data);
		\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('memo' => 'api_upate_temp', 'param' => $data, 'return' => $info), 21);
		if($info['resultCode'] != 5000)
		{
			return FALSE;
		}
		$this->addTemplateLoc($locData, $templateId, $templateName);
		return TRUE;
	}
	
	/**
	 * 修改模板
	 */
	public function updateTemplateApiTest($templateId, $domain, $resistarId, $locData = array(),$templateName = '')
	{
		$data = array('templateId' => $templateId, 'domain' => $domain, 'registrarID' => $resistarId);
		if($locData)
		{
			$data = array_merge($data, $locData);
		}
		$info = $this->sdk->execSdkFun(5113, $data);
		\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('memo' => 'api_upate_temp', 'param' => $data, 'return' => $info), 21);
		if($info['resultCode'] != 5000)
		{
			return $info['data'];
		}
		$this->addTemplateLoc($locData, $templateId, $templateName);
		return TRUE;
	}	
	
	
	/**
	 * cdnstatus状态更改 资料上传
	 */
	private function addTemplateLoc($locData,$templateId,$templateName)
	{
		if(!empty($locData) && !empty($locData['locType']) && !empty($locData['locNumber']))
		{
			$tempLib = new \lib\manage\domain\TemplateLib();
			$tempLib->updateTemplateInfo(array('TemplateId' => $templateId), array('CdnStatus' => 3));
		}
		if(!empty($locData) && !empty($locData['locType']) && ($locData['locType'] == 'YYZZ' || $locData['locType'] == 'QT'))
		{
			$uploadData = array('registrantId' => $templateName, 'img' => $locData['img']);//图片先防空
			error_log(json_encode($uploadData),3,'/tmp/addTemplateLoc6991');
			$uploadInfo = $this->sdk->execSdkFun(6991, $uploadData);
			if($uploadInfo['resultCode'] != 6000)
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($templateId, array('memo' => 'upload data failed',
						'param' => $uploadData, 'return' => $uploadInfo), 21);
			}
		}
		return true;
	}
	public function addRecords($data,$domainArr,$enameId)
	{
		$errorMsg = '';
		$info = $this->sdk->execPublicSdkFun('0851', $data);
		\lib\manage\domain\DomainLogsLib::addDomainService($domainArr[0], array('memo' => '设置解析', 'param' => $domainArr,
				'return' => $info), 54,'',$enameId);
		if($info['code'] != 1000)
		{
			$errorMsg = $this->formatErrorMsg($info['data']);
		}
		return $errorMsg;
	}
	/**
	 * 验证批量解析提交的数据是否正确
	 * @param int $operationType
	 * @param array $data
	 * @param DomainTaskLib $domainTaskLib
	 * @return string
	 */
	public function vaildBatchDnsData($operationType, $data)
	{
		$method= ($operationType == 3) ? 'DEL' : '';
		$validData= $this->sdk->execPublicSdkFun('0854', array('data'=> $data, 'method'=> $method));
		$errorMsg= '';
		if($validData['code'] != 1000)
		{
			$errorMsg= $this->formatErrorMsg($validData['data']);
		}
		return $errorMsg;
	}
	/**
	 * 格式化错误信息
	 * example:$data=> array("domain"=> array("fanzw.corm"=> "域名非法" ),
	 *  "record"=> array('1'=> array("record_type"=> "请选择记录类型" ))));
	 * @param array $errorMsg
	 */
	public function formatErrorMsg($errorMsg)
	{
		$domainMsg= '';
		$recordMsg= '';
		foreach ($errorMsg as $k => $v)
		{
			if($k == 'domain')
			{
				foreach($v as $domain => $domainErrorMsg)
				{
					$domainMsg.= $domain.$domainErrorMsg.'域名格式错误,';
				}
			}
			else if($k == 'record')
			{
				foreach($v as $recordId => $record)
				{
					foreach($record as $recordErrorMsg)
					{
						$recordMsg.= '第'.($recordId + 1).'条记录'.$recordErrorMsg.',';
					}
				}
			}
		}
		return $domainMsg.$recordMsg;
	}
	/**
	 * 添加批量任务和批量任务详细信息
	 * @param array $data
	 * @param string $taskName
	 * @param int $totalNum
	 * @param int $enameId
	 * @param string $taskFunctionName
	 * @param string $taskKey
	 * @return array $data
	 * @author linlz
	 * @version 2012-09-25
	 */
	public function addTaskAndTaskInfo($data, $taskName, $totalNum, $enameId, $taskFunctionName='', $taskKey='')
	{
		$taskId= $this->addTask($taskName, $totalNum, $enameId, $taskFunctionName);
		if($taskId === FALSE)
		{
			throw new \Exception('系统添加批量任务出错!请稍后重试!');
		}
		foreach ($data as $k=> $v)
		{
			foreach ($v as $kk => $vv)
			{
				$vv['domain']= $k;
				$taskExtKey= json_encode($vv);
				$subTaskId= $this->addTaskInfo($taskId, $taskName, $taskKey, $taskExtKey);
				if($subTaskId === FALSE)
				{
					throw new \Exception('系统添加批量任务出错!请稍后重试!');
				}
				$data[$k][$kk]['id'] = $subTaskId;
			}
		}
		return $data;
	}
	/**
	 * 添加批量任务
	 * @param string $taskName
	 * @param int $totalNum
	 * @param int $enameId
	 * @param string $taskFunctionName
	 * @return boolean|string
	 * @author linlz
	 * @version 2012-09-25
	 */
	public function addTask($taskName, $totalNum, $enameId, $taskFunctionName)
	{
	
		$taskData= array('TaskName'=> $taskName, 'CreateTime'=> date("Y-m-d H:i:s",$_SERVER['REQUEST_TIME']),
				'TaskStatus'=> 1, 'TotalNum'=> $totalNum, 'TaskGroup'=> 1,
				'EnameId'=> $enameId, 'TaskFunctionName'=> $taskFunctionName);
		$info= $this->sdk->execSdkFun(6870, $taskData);
		if($info['resultCode'] != 6000)
		{
			return FALSE;
		}
		return $info['data'];
	}
	/**
	 * 添加批量任务详细信息
	 * @param int $taskId
	 * @param string $taskName
	 * @param string $taskKey
	 * @param string $taskExtKey
	 * @return boolean|string
	 * @author linlz
	 * @version 2012-09-25
	 */
	public function addTaskInfo($taskId, $taskName, $taskKey='',$taskExtKey='')
	{
		$taskInfoData= array('TaskId'=> $taskId, 'TaskName'=> $taskName,
				'CreateTime'=> date("Y-m-d H:i:s",$_SERVER['REQUEST_TIME']), 'TaskStatus'=> 1,
				'TaskKey'=> $taskKey, 'TaskExtKey'=> $taskExtKey);
		$addInfo= $this->sdk->execSdkFun(6880, $taskInfoData);
		if($addInfo['resultCode'] != 6000)
		{
			return FALSE;
		}
		return $addInfo['data'];
	}
	
	/**
	 * 5011更改域名模版ID(模板过户使用)
	 * @param array $data array('domain'=> .., 'templateId'=> .., 'registrarID'=> .., 'chg_extension'=> ..)
	 */
	public function modifyDomainModelId($data)
	{ 
		if(DomainFunLib::checkIsVspDomainLtd($data['domain']) && FALSE == \lib\manage\domain\DomainQueryLib::switchclose())
		{
			$logic = new \logic\manage\thrift\EppLogic();
			return $logic->domainEppChangeRegistrant($data);
		}
		return $this->sdk->execSdkFun(5011, $data);
	}
	
	
	/**
	 * 5005 域名转入
	 * @param array $data
	 */
	public function transferInDomain($data)
	{
		return $this->sdk->execSdkFun(5005, $data);
	}
	
	/**
	 * 0654 提交个人白名单
	 * @param array $data array('template'=>,'idCard'=>,'sfzImg'=>,'cn')
	 */
	public function uploadCnnicPersion($data)
	{
		return $this->sdk->execPublicSdkFun('0654', $data);
	}
	
	/**
	 * 0655 提交组织机构白名单
	 * @param array $data array('template'=>,'idCard'=>,'orgNum'=>,'sfzImg'=>,'orgImg'=>,'cn'=>,'orgProType'=>,'orgType','blInfo'=>)
	 */
	public function uploadCnnicCompany($data)
	{
		return $this->sdk->execPublicSdkFun('0655', $data);
	}
}

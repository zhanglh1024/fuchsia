<?php
namespace lib\manage\domain;
class DomainTopLib
{
	/**
	 * 获取珍品或者抢滩域名价格
	 */
	public function getTopDomainPrice($level, $domain)
	{
		$priceKey = $this->getDomainExt($domain);
		if(FALSE == $priceKey)
		{
			return FALSE;
		}
		return $this->getConfigInfo('price', $level, $priceKey);
	}

	/**
	 *  具体备注,方便订单查看
	 */
	public function topDomainRemark($level)
	{
		return $this->getConfigInfo('remark', $level);
	}

	public function getDomainExt($domain)
	{
		$priceKey = FALSE;
		if(strtolower(substr($domain, strlen($domain) - 2)) == 'cn')
		{
			$priceKey = 'cn';
		}
		else if(strtolower(substr($domain, strlen($domain) - 3)) == 'com' || strtolower(substr($domain, strlen($domain) - 3)) == 'net')
		{
			$priceKey = 'com';
		}
		return $priceKey;
	}

	/**
	 * 取的配置的值，主要是价格跟备注 
	 */
	private function getConfigInfo($type, $level, $suffix = false)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'topdomain');
		$key = '';
		switch($level)
		{
			case 1:
				$key = 'zhizun';
				break;
			case 2:
				$key = 'diancang';
				break;
			case 3:
				$key = 'rong';
				break;
			default:
				$key = 'beach';
		}
		$info = $key ? $conf->$type->$key : $conf->$type;
		if($level != 1 && $level != 4)
		{
			$info = $suffix ? $info->$suffix : $info;
		}
		return $info;
	}

	/**
	 * 查看域名是否是珍品域名 价格 备注
	 */
	public function checkTopDomain($domain, $checkTime)
	{
		$time = time();
		if ($time >= strtotime ( "2016-11-25 01:00:00" ) && $time <= strtotime ( "2016-11-25 04:00:00" )) {
			return FALSE;
		}
		\lib\manage\common\DomainOpenLib::domainOpen('topdomain');
		if($this->getDomainExt($domain) == FALSE)
		{
			return FALSE;
		}
		$topDomain = new \models\manage\domain\DomainTopMod();
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'topdomain');
		if($topDomain->getTopDomainByDomain(array('domain' => $domain, 'createTime' => $checkTime)))//是否已经在本年度内优惠过
		{
			return $conf->topexists;
		}
		$beachLevel = $this->getTopDomainBeachLevel($domain);
		if(empty($beachLevel['Beach']) && empty($beachLevel['Level']))
		{
			return $conf->notop;
		}
		$topType = $beachLevel['Beach'] ? 4 : $beachLevel['Level'];
		$remark = $this->topDomainRemark($topType);
		$price = $this->getTopDomainPrice($topType, $domain);
		return array('price' => $price, 'remark' => $remark, 'topType' => $topType);
	}

	/**
	 *  获取珍品或者抢滩级别
	 */
	private function getTopDomainBeachLevel($domain)
	{
		$trans = new \models\trans\TopDomainMod();
		$beachLevel = array('Beach' => '0', 'Level' => '0');
		$beachInfo = $trans->getBeachInfoByDomain($domain);
		if(FALSE !== $beachInfo)
		{
			$beachLevel['Beach'] = $beachInfo['Beach'];
			return $beachLevel;
		}
		$leaveInfo = $trans->getInfoByDomain($domain);
		if(FALSE !== $leaveInfo)
		{
			$beachLevel['Level'] = $leaveInfo['Level'];
			return $beachLevel;
		}
		return $beachLevel;
	}

	public function addTopDomain($topData)
	{
		\lib\manage\common\DomainOpenLib::domainOpen('topdomain');
		$topDomain = new \models\manage\domain\DomainTopMod();
		return $topDomain->addTopDomain($topData->domain, $topData->enameId, $topData->topType, $topData->remark, $topData->price);
	}

	public function getTopDomainConsume($data)
	{
		$topDomain = new \models\manage\domain\DomainTopMod();
		$limit = FALSE;
		if(!empty($data['pageNum']))
		{
			$pagesize = !empty($data['pageSize']) && $data['pageSize']>0 ? intval($data['pageSize']) : 20;
			$p = $data['pageNum'] ? intval($data['pageNum']) - 1 : 0;
			$offset = $p * $pagesize;
			$limit = $offset . ',' . $pagesize;
		}
		return $topDomain->getTopDomainByDomain($data,FALSE,$limit);
	}
	
	public function getTopDomainCount($data)
	{
		$topDomain = new \models\manage\domain\DomainTopMod();
		return $topDomain->getTopDomainCount($data);
	}
	
	/**
	 * 查看域名是否是珍品域名
	 */
	public function topDomainDone($shopType, $domain, $enameId)
	{
		if(!in_array($shopType, array(2, 3)))
		{
			return false;
		}
		$return = $this->checkTopDomain($domain, date('Y'));
		if(!$return || !is_array($return))
		{
			return false;
		}
		try
		{
			$addData = array('domain' => $domain, 'enameId' => $enameId, 'topType' => $return['topType'],
					'remark' => $return['remark'], 'price' => $return['price']);
			$add = $this->addTopDomain((object) $addData);
			if(!$add)
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('memo' => 'add record failed', json_encode($return)), 11);
			}
		}
		catch(\Exception $e)
		{
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('memo' => 'add record failed', $e->getMessage()), 11);
		}
	}
}

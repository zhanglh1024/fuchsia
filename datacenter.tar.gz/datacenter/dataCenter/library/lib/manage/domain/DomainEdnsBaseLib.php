<?php
namespace lib\manage\domain;

/**
 * 调用edns接口的sdk类
 *
 */
class DomainEdnsBaseLib
{
	// private $apiUrl = 'http://admin.edns.cn/API/ename/';
	private $apiUrl; //hosts: 110.80.9.54 enameapi.edns.cn
	private $apiKey;
	private $actionPhp;
	private $sendData;

	private $debugLog = TRUE;
	private $logPath;
	private $result;
	private $resultArray;
	private $errorCode = '';
	private $errorMsg = '';
	private $useHttpServer = false;

	public function __construct()
	{
		$config = \Yaf\Registry::get("config");
		$this->logPath = $config->application->logPath . 'edns/sdk_';
		$edns = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'edns');
		$this->apiKey = $edns->apiKey;
		$this->apiUrl = $edns->apiUrl;
	}

	/**
	 * 添加域名
	 * @param string $domains='hush1.com'
	 * @param int $enameid=317363
	 * @return boolean
	 */
	public function addDomain($domain, $enameid, $clientIp = '')
	{
		if(empty($domain) || empty($enameid))
		{
			return FALSE;
		}
		$params = array();
		$params['domain'] = urlencode($domain);
		$params['enameid'] = $enameid;
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'addDomain';
		$this->sendData = $params;
		$result = $this->curlExec();
		$return = $this->formatResult($result);
		if((isset($return['code']) && $return['code'] == '20006') || (isset($return['msg']) && stripos($return['msg'],'域名已存在')!==FALSE))
		{
			$this->log('domain_exists:' . $domain);
			$return = array('status'=>TRUE,'code'=>'20005','msg'=>'域名添加成功');
		}
		return $return;		
	}

	/**
	 * 域名加锁 
	 * * @param string $domains='hush1.com'
	 * @param int $enameid=317363
	 * @return boolean
	 */
	public function domainLock($domain, $clientIp = '')
	{
		if(empty($domain))
		{
			return FALSE;
		}
		$params = array();
		$params['domain'] = urlencode($domain);
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'domainLock';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 域名解锁
	 * * @param string $domains='hush1.com'
	 * @param int $enameid=317363
	 * @return boolean
	 */
	public function domainUnLock($domain, $clientIp = '')
	{
		if(empty($domain))
		{
			return FALSE;
		}
		$params = array();
		$params['domain'] = urlencode($domain);
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'domainUnlock';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 域名设置为展示页
	 * * @param string $domains='hush1.com'
	 * @param int $enameid=317363
	 * @return boolean
	 */
	public function domainCustompage($domain, $clientIp = '')
	{
		if(empty($domain))
		{
			return FALSE;
		}
		$params = array();
		$params['domain'] = urlencode($domain);
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'domainCustompage';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 域名解析记录列表
	 * @param string $domain
	 * @param int $pageNum 第一页$pageNum=0，第二页$pageNum=1，以此类推
	 * @param int $pageSize 记录条数默认30条
	 * @param string $pagetype 查询的类型where为条件查询，其他显示全部
	 * @param string $subDomain 主机头如@、www等
	 * @param int $line 线路类型  1通用、2电信、3联通、4教育网
	 * @param int $type 记录类型 1A、2CNAME、3MX、4URL、5NS、6TXT、7AAAA、8URL0
	 * @param int $value 记录值
	 * return {"data":{"status":true,"msg":"\u83b7\u53d6\u89e3\u6790\u5217\u8868\u6210\u529f","data":{"total":1,"totalPage":1,"curPage":1,"records":[{"drId":"3682748","dId":"376157","sub_domain":"www","record_line":"\u901a\u7528","record_type":"A","ttl":"3600","value":"127.0.0.1","is_del":"\u6b63\u5e38","enabled":"\u542f\u7528","updated_on":"2014\/04\/12 12:53:44","extra":"0","remark":"","created_on":"2014\/04\/12 12:53:44"}]},"code":"20024"}}
	 */
	public function recordList($domain, $pageNum = 0, $pageSize = 30, $pagetype = 'all', $subDomain = '@', $line = 1,
			$type = 1, $value = '', $clientIp = '')
	{
		if(empty($domain))
		{
			return FALSE;
		}
		$params = array();
		$params['domain'] = urlencode($domain);
		$params['pageNum'] = $pageNum;
		$params['pageSize'] = $pageSize;
		$params['pagetype'] = $pagetype;
		if($pagetype == 'where')
		{
			$params['subDomain'] = urlencode($subDomain);
			$params['record_line'] = $line;
			$params['record_type'] = $type;
			$params['value'] = urlencode($value);
		}
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);
		$this->actionPhp = 'recordList';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 域名解析记录详情
	 * @param string $domain
	 * @param int $drId 解析记录ID
	 * return {"data":{"status":true,"msg":"\u83b7\u53d6\u89e3\u6790\u5217\u8868\u6210\u529f","data":{"drId":"3682748","dId":"376157","sub_domain":"www","record_line":"\u901a\u7528","record_type":"A","ttl":"3600","value":"127.0.0.1","is_del":"\u6b63\u5e38","enabled":"\u542f\u7528","updated_on":"2014\/04\/12 12:53:44","extra":"0","remark":"","created_on":"2014\/04\/12 12:53:44"},"code":"20024"}}
	 */
	public function recordInfo($domain, $drId, $clientIp = '')
	{
		if(empty($domain) || empty($drId))
		{
			return FALSE;
		}
		$params = array();
		$params['domain'] = urlencode($domain);
		$params['drId'] = $drId;
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'recordInfo';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 根据域名创建域名解析记录
	 * @param string $domain 域名格式
	 * @param string $subDomain 主机头 如@、www
	 * @param int $rline 线路类型  1通用、2电信、3联通、4教育网
	 * @param int $rtype 记录类型 1A、2CNAME、3MX、4URL、5NS、6TXT、7AAAA、8URL0
	 * @param int $ttl ttl值 如600
	 * @param string $value 解析记录值
	 * @param int $extra mx优先级
	 * return $data
	 */
	public function createRdByDn($domain, $subDomain = '@', $rline = 1, $rtype = 1, $value, $ttl = 600, $extra = 10,
			$clientIp = '')
	{
		if(empty($domain) || empty($subDomain) || empty($rline) || empty($rtype) || empty($value) || empty($ttl))
		{
			return FALSE;
		}
		$params = array();
		$params['domain'] = urlencode($domain);
		$params['subDomain'] = urlencode($subDomain);
		$params['record_line'] = $rline;
		$params['record_type'] = $rtype;
		$params['value'] = urlencode($value);
		$params['ttl'] = $ttl;
		if($rtype == '3')
		{
			$params['extra'] = $extra;
		}
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);
		$this->actionPhp = 'createRdByDn';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 根据域名修改域名解析记录
	 * @param string $domain 域名格式
	 * @param int drId 域名解析记录ID
	 * @param int dId 域名ID
	 * @param string $subDomain 主机头 如@、www
	 * @param int $rline 线路类型  1通用、2电信、3联通、4教育网
	 * @param int $rtype 记录类型 1A、2CNAME、3MX、4URL、5NS、6TXT、7AAAA、8URL0
	 * @param int $ttl ttl值 如600
	 * @param string $value 解析记录值
	 * @param int $extra mx优先级
	 * return $data
	 */
	public function modify($domain, $dId, $drId, $subDomain, $rline, $rtype, $value, $ttl, $extra = 10, $clientIp = '')
	{
		if(empty($domain) || empty($dId) || empty($drId) || empty($subDomain) || empty($rline) || empty($rtype) || empty($value) || empty($ttl))
		{
			return FALSE;
		}
		$params = array();
		$params['domain'] = urlencode($domain);
		$params['dId'] = $dId;
		$params['drId'] = $drId;
		$params['subDomain'] = urlencode($subDomain);
		$params['record_line'] = $rline;
		$params['record_type'] = $rtype;
		$params['ttl'] = $ttl;
		$params['value'] = urlencode($value);
		if($rtype == '3')
		{
			$params['extra'] = $extra;
		}
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'modify';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 删除域名解析记录
	 * @param string $domain 域名格式
	 * @param int drId 域名解析记录ID
	 * @param int dId 域名ID
	 */
	public function removeRecord($domain, $dId, $drId, $clientIp = '')
	{
		if(empty($domain) || empty($dId) || empty($drId))
		{
			return FALSE;
		}
		$params = array();
		$params['domain'] = urlencode($domain);
		$params['dId'] = $dId;
		$params['drId'] = $drId;
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'removeRecord';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 启用域名解析记录
	 * @param string $domain 域名格式
	 * @param int drId 域名解析记录ID
	 * @param int dId 域名ID
	 */
	public function recordEnable($domain, $dId, $drId, $clientIp = '')
	{
		if(empty($domain) || empty($dId) || empty($drId))
		{
			return FALSE;
		}
		$params = array();
		$params['domain'] = urlencode($domain);
		$params['dId'] = $dId;
		$params['drId'] = $drId;
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'recordEnable';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}
	/**
	 * 停用域名解析记录
	 * @param string $domain 域名格式
	 * @param int drId 域名解析记录ID
	 * @param int dId 域名ID
	 */
	public function recordDisable($domain, $dId, $drId, $clientIp = '')
	{
		if(empty($domain) || empty($dId) || empty($drId))
		{
			return FALSE;
		}
		$params = array();
		$params['domain'] = urlencode($domain);
		$params['dId'] = $dId;
		$params['drId'] = $drId;
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'recordDisable';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 暂停或启动域名解析
	 * @param string $domain
	 * @param int $enable 1:启用,2:暂停
	 * @param string $remark
	 */
	public function isPause($domain, $enable=1, $remark='', $clientIp='') {
		if(empty($domain))
		{
			return false;
		}
		$params=array();
		$params['domain'] = $this->useHttpServer ? $domain : urlencode($domain);
		$params['enable'] = $enable == 1 ? 1 : 2;
		$params['remark'] = $remark;
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);
		$this->actionPhp = 'isPause';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}
	
	/**
	 * URL转发审核列表
	 * @param string $pagetype 当$pagetype ='where'时可以使用条件搜索
	 * @param int $urlType url转发类型 1隐藏 2非隐藏
	 * @param int $auditStatus 转发记录审核状态 '1' => '审核中','2' => '审核成功','3' => '审核失败',
	 * @param int $errorStatus 转发记录错误状态 '0'=>'未审核','1'=>'正常','2'=>'违规内容','3'=>'目标地址未备案','4'=>'目标地址动态IP','5'=>'目标地址不能访问','6'=>'不支持此类转发','7'=>'目标地址无具体内容','8'=>'黑名单'
	 * @param int $pageSize 分页大小
	 * @param int $pageNum 分页页码,首页为0
	 */

	public function auditList($pagetype = 'all', $pageNum = 0, $pageSize = NULL, $urlType = NULL, $auditStatus = NULL,
			$errorStatus = NULL, $domain = '', $value = '', $clientIp = '',$admin = '',$startTime = '',$endTime = '')
	{
		$params = array();
		$params['pagetype'] = $pagetype;
		$params['pageNum'] = $pageNum;
		$params['pageSize'] = $pageSize;
		if($pagetype == 'where')
		{
			$params['urlType'] = $urlType;
			if(isset($_REQUEST['tmpadmin']))//tmpcode
			{
				$params['auditStatus'] = $auditStatus;//auditStatus为前台用户看到的状态，搜索可以忽略
			}
			//$params['auditStatus'] = $auditStatus;//auditStatus为前台用户看到的状态，搜索可以忽略
			$params['errorStatus'] = $errorStatus;
			$params['domain'] = urlencode($domain);
			$params['value'] = $value;
			$params['adminId'] = $admin;
			$params['startTime'] = $startTime;
			$params['endTime'] = $endTime;
		}
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'auditList';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * URL转发审核操作
	 * @param int $drId 域名解析记录ID
	 * @param int $errorStatus 转发记录错误状态 '1'=>'正常','2'=>'违规内容','3'=>'目标地址未备案','4'=>'目标地址动态IP','5'=>'目标地址不能访问','6'=>'不支持此类转发','7'=>'目标地址无具体内容'
	 */
	public function audit($drId, $errorStatus, $clientIp,$adminId)
	{
		$params = array();
		if(empty($drId) || empty($errorStatus))
		{
			return FALSE;
		}
		$params['drId'] = $drId;
		$params['errorStatus'] = $errorStatus;
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['adminId'] = $adminId;
		$params['sign'] = $this->getSign($params);
		$this->actionPhp = 'audit';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * URL转发白名单列表
	 * @param string $pagetype 当$pagetype ='where'时可以使用条件搜索
	 * @param int $pageNum 分页页码,首页为0
	 * @param int $urdStatus 转发记录审核状态 '1' => '审核中','2' => '审核成功','3' => '审核失败',
	 * @param int $pageSize 分页大小
	 */
	public function urlDomainList($pagetype = 'all', $pageNum = 0, $pageSize = NULL, $urdStatus = NULL, $clientIp = '')
	{
		$params = array();
		$params['pagetype'] = $pagetype;
		$params['pageNum'] = $pageNum;
		$params['pageSize'] = $pageSize;
		if($pagetype == 'where')
		{
			$params['urdStatus'] = $urdStatus;
		}
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'urlDomainList';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 添加新的URL转发白名单
	 * @param string $urdvalue 值只能为IPV4与域名
	 * @param int $urdStatus 转发记录审核状态 '1' => '审核中','2' => '审核成功','3' => '审核失败',不填或者不再给定范围的值一律审核中
	 */
	public function addWhiteList($urdvalue, $urdStatus = 1, $clientIp = '')
	{
		$params = array();
		if(empty($urdvalue))
		{
			return FALSE;
		}
		$params['urdvalue'] = $urdvalue;
		$params['urdStatus'] = $urdStatus;
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'addWhiteList';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 编辑的URL转发白名单
	 * @param int $urdId 转发白名单表ID
	 * @param string $urdvalue 值只能为IPV4与域名
	 * @param int $urdStatus 转发记录审核状态 '1' => '审核中','2' => '审核成功','3' => '审核失败',不填或者不再给定范围的值一律审核中
	 */
	public function editWhiteList($urdId, $urdvalue, $urdStatus = 3, $clientIp = '')
	{
		$params = array();
		if(empty($urdId) || empty($urdvalue))
		{
			return FALSE;
		}
		$params['urdId'] = $urdId;
		$params['urdvalue'] = $urdvalue;
		$params['urdStatus'] = $urdStatus;
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'editWhiteList';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 删除的URL转发白名单
	 * @param int $urdId 转发白名单表ID
	 */
	public function urldRemove($urdId, $clientIp = '')
	{
		$params = array();
		if(empty($urdId))
		{
			return FALSE;
		}
		$params['urdId'] = $urdId;
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'urldRemove';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 根据解析记录id  获取 域名信息
	 * @params $drId  解析记录id
	 * @return {"data"{"status":"","msg":"","code":"","data":{}}
	 */
	public function domainInfo($drId, $clientIp = '')
	{
		if(empty($drId))
		{
			return FALSE;
		}
		$params = array();
		$params['drId'] = $drId;
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'domainInfo';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * URL转发审核操作
	 * @param int $drId 域名解析记录ID
	 * @param int $errorStatus 转发记录错误状态 '1'=>'正常','2'=>'违规内容','3'=>'目标地址未备案','4'=>'目标地址动态IP','5'=>'目标地址不能访问','6'=>'不支持此类转发','7'=>'目标地址无具体内容'
	 */
	public function batchAudit($drIdArr, $errorStatus, $clientIp,$adminId)
	{
		$params = array();
		if(empty($drIdArr) || empty($errorStatus))
		{
			return false;
		}
		$params['drIdArr'] = json_encode($drIdArr);
		$params['errorStatus'] = $errorStatus;
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['adminId'] = $adminId;
		$params['sign'] = $this->getSign($params);
		$this->actionPhp = 'batchAudit';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 域名日志列表信息
	 * @params str $domain 域名
	 * @params int $pageNum 分页页码
	 * @params int $pageSize 分页大小
	 * @param boolen $showAll 是否显示全部，true显示全部，false隐藏log_type=2的部分
	 * @return  return {"data":{"status":true,"msg":"\u83b7\u53d6\u89e3\u6790\u5217\u8868\u6210\u529f","data":{"total":"",'curpage':"","pagesize":"","logs"{"drId":"3682748","dId":"376157","sub_domain":"www","record_line":"\u901a\u7528","record_type":"A","ttl":"3600","value":"127.0.0.1","is_del":"\u6b63\u5e38","enabled":"\u542f\u7528","updated_on":"2014\/04\/12 12:53:44","extra":"0","remark":"","created_on":"2014\/04\/12 12:53:44"}}};
	 */
	public function domainLogList($domain, $pageNum = 0, $pageSize = 15, $showAll = 0, $clientIp = '')
	{
		if(empty($domain) || empty($pageSize))
		{
			return FALSE;
		}
		$params = array();
		$params['domain'] = urlencode($domain);
		$params['pageNum'] = empty($pageNum) ? 0 : $pageNum;
		$params['pageSize'] = $pageSize;
		$params['pageType'] = $showAll;
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'domainLogList';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}

	/**
	 * 域名信息
	 * @params str $domain
	 * @return {"data"{"status":"","msg":"","code":"","data":{}}
	 */
	public function domainInfoByDn($domain, $clientIp = '')
	{
		if(empty($domain))
		{
			return FALSE;
		}
		$params = array();
		$params['domain'] = urlencode($domain);
		$params['timestamp'] = time();
		$params['ip'] = $clientIp;
		$params['sign'] = $this->getSign($params);

		$this->actionPhp = 'domainInfoByDn';
		$this->sendData = $params;
		$result = $this->curlExec();
		return $this->formatResult($result);
	}
	/**
	 * 生成加密串
	 * 
	 */
	private function getSign($params)
	{
		$authString = $this->getNormalizedString($params);
		return md5($authString . $this->apiKey);
	}

	/**
	 * @brief 对参数进行字典升序排序
	 *
	 * @param $params 参数列表
	 *
	 * @return 排序后用&链接的key-value对（key1=value1&key2=value2...)
	 */
	private function getNormalizedString($params)
	{
		ksort($params);
		unset($params['sign']);
		$normalized = array();
		foreach($params as $key => $val)
		{
			$normalized[] = $key . "=" . $val;
		}
		return implode("&", $normalized);
	}

	private function curlExec()
	{
		//$this->log('sendData:' . $this->apiUrl . $this->actionPhp);
		$ch = curl_init();
		//curl_setopt($ch, CURLOPT_PORT, 81);//外网注释掉
		curl_setopt($ch, CURLOPT_URL, $this->apiUrl . $this->actionPhp);
		//curl普通秒超时设置
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 35);
		curl_setopt($ch, CURLOPT_TIMEOUT, 35);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type' => 'text/xml'));
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $this->sendData);
		$this->result = curl_exec($ch);
		$this->log('return:' . json_encode($this->sendData).','.$this->result);
		if(curl_errno($ch))
		{
			$this->log('error:' . curl_error($ch));
		}
		curl_close($ch);
		return $this->result;
	}

	private function formatResult($result)
	{
		if(empty($result))
		{
			$this->log('return:null' . $result);
			return FALSE;
		}
		$this->resultArray = json_decode($result, TRUE);
		if(empty($this->resultArray) or empty($this->resultArray['status']))
		{
			$this->log('return:' . $result);
		}
		if(isset($this->resultArray['code']) && $this->resultArray['code'] === 0 && isset($this->resultArray['msg']))
		{
			$this->resultArray['msg'] = '抱歉，系统出错';
		}
		return $this->resultArray;
	}

	private function log($message)
	{
		if(!$this->debugLog)
		{
			return FALSE;
		}

		$file = $this->logPath . date("Y-m-d") . '.log';
		$message = date("[Y-m-d H:i:s] [") . $message . ']' . "\n";
 		return error_log($message, 3, $file);
	}

	public function getErrorMsg()
	{
		return $this->errorMsg = empty($this->resultArray['msg']) ? '' : $this->resultArray['msg'];
	}

	public function getErrorCode()
	{
		return $this->ErrorCode = empty($this->resultArray['code']) ? '0' : $this->resultArray['code'];
	}

	public function getResult()
	{
		return $this->result;
	}

	public function getResultData()
	{
		return $this->resultData = empty($this->resultArray['data']) ? '' : $this->resultArray['data'];
	}

	public function getResultArray()
	{
		return $this->resultArray;
	}
}

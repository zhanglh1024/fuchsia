<?php
namespace lib\manage\domain;

use core\form\ReturnData;
use core\Response;
use core\ModBase;
use lib\manage\domain\DomainLogsLib;
use \lib\manage\common\DomainFunLib;
use \lib\manage\common\DomainOpenLib;
use \lib\manage\newqueue\QueueTaskLib;
use common;
class DomainPushLib
{

	private $conf;

	private $domainManageLib;
 
	private $pushmod;
   
	private $enameId; 
 
	public function __construct($enameId = '')
	{
		$this->enameId = $enameId;
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$this->domainManageLib = new \lib\manage\domain\DomainManageLib();
		$this->pushmod = new \models\manage\domain\DomainPushMod();
	}
 
	/**
	 * 域名push列表(正在交易需要显示个数 已经结束的不需要)
	 */
	public function pushList($type, $listType, $enameId, $domain, $status)
	{
		$mod = new \models\manage\domain\DomainPushMod();
		$pagesize = empty(ReturnData::$info->pageSize) ? 8 : intval(ReturnData::$info->pageSize);
		$pageNum = empty(ReturnData::$info->pageNum) ? 1 : intval(ReturnData::$info->pageNum);
		$limit = ($pageNum - 1) * $pagesize . ',' . $pagesize;
		$pushList = array();
		if($type == 1) // 正在交易
		{
			$receiveData = array('ReceiveStatus' => 0, 'Status' => 0, 'ReceiveId' => $this->enameId); // 收到的请求
			$receiveCount = $this->getCount($receiveData); // 个数
			
			$sendData = array('ReceiveStatus' => 0, 'Status' => 0, 'SendId' => $this->enameId); // 发送的请求
			$sendCount = $this->getCount($sendData); // 个数
			if($listType == 1) // 收到的请求
			{
				if(empty($receiveCount))
				{
					$pushList = array('count' => 0, 'pagenum' => 1, 'data' => array());
				}
				else
				{
					// 获取列表
					$receiveData['limit'] = $limit;
					$receiveList = $this->getPushList($receiveData);
					$pushList = array('count' => $receiveCount['total'], 'pagenum' => $pageNum, 
						'data' => $this->returnPushField($receiveList, $listType));
				}
				$pushList['sendCount'] = empty($sendCount['total']) ? 0 : $sendCount['total'];
			}
			else // 发送的请求
			{
				if(empty($sendCount))
				{
					$pushList = array('count' => 0, 'pagenum' => 1, 'data' => array());
				}
				else
				{
					$sendData['limit'] = $limit;
					$sendList = $this->getPushList($sendData);
					$pushList = array('count' => $sendCount['total'], 'pagenum' => $pageNum, 
						'data' => $this->returnPushField($sendList, $listType));
				}
				$pushList['receiveCount'] = empty($receiveCount['total']) ? 0 : $receiveCount['total'];
			}
		}
		else // 交易结束
		{
			// 收到的请求
			// 我已接收 我已拒绝 //对方已取消
			$advanceSearch = $this->getSearchPart($domain, $status); // advance search
			if(!empty($advanceSearch))
			{
				$tmp = $advanceSearch;
				$tmp['ReceiveId'] = $this->enameId;
				$countMe = $this->getCount($tmp);
			}
			else
			{
				$receiveEnd = array('ReceiveId' => $this->enameId, 
					'or' => array('SendStatus' => 3, 'ReceiveStatus' => array(1, 2)));
				$countMe = $this->getCount($receiveEnd);
			}
			$recentCount = empty($countMe['total']) ? 0 : $countMe['total'];
			// 发送的请求
			// 对方已经接收 对方已经拒绝 //我已取消
			if(!empty($advanceSearch))
			{
				$tmp = $advanceSearch;
				$tmp['SendId'] = $this->enameId;
				$sendEndCount = $this->getCount($tmp);
			}
			else
			{
				$sendEnd = array('SendId' => $this->enameId, 
					'or' => array('SendStatus' => 3, 'ReceiveStatus' => array(1, 2)));
				$sendEndCount = $this->getCount($sendEnd);
			}
			$sendCount = empty($sendEndCount['total']) ? 0 : $sendEndCount['total'];
			
			if($listType == 1) // 收到的请求
			{
				if(empty($recentCount))
				{
					$pushList = array('count' => 0, 'pagenum' => 1, 'data' => array());
				}
				else
				{
					// 获取列表 收到的请求
					if($advanceSearch)
					{
						$advanceSearch['limit'] = $limit;
						$advanceSearch['ReceiveId'] = $this->enameId;
						$receiveEndList = $this->getPushList($advanceSearch);
					}
					else
					{
						$receiveEnd['limit'] = $limit;
						$receiveEndList = $this->getPushList($receiveEnd);
					}
					$pushList = array('count' => $recentCount, 'pagenum' => $pageNum, 
						'data' => $this->returnPushField($receiveEndList, $listType));
				}
				$pushList['sendCount'] = $sendCount;
			}
			else // 发送的请求
			{
				if(empty($sendCount))
				{
					$pushList = array('count' => 0, 'pagenum' => 1, 'data' => array());
				}
				else
				{
					$sendEnd['limit'] = $limit;
					if($advanceSearch)
					{
						$advanceSearch['limit'] = $limit;
						$advanceSearch['SendId'] = $this->enameId;
						$sendEndList = $this->getPushList($advanceSearch);
					}
					else
					{
						$sendEndList = $this->getPushList($sendEnd);
					}
					$pushList = array('count' => $sendCount, 'pagenum' => $pageNum, 
						'data' => $this->returnPushField($sendEndList, $listType));
				}
				$pushList['receiveCount'] = $recentCount;
			}
		}
		return $pushList;
	}

	/**
	 * 获取Push总数
	 */
	public function getCount($params)
	{
		$mod = new \models\manage\domain\DomainPushMod();
		if(isset($params['limit']))
		{
			unset($params['limit']);
		}
		$total = $mod->pushList($params, "count(1) as total", TRUE);
		return $total ? $total : 0;
	}

	private function getSearchPart($domain, $status)
	{
		$return = array();
		$return = $this->getSearchStatus($status);
		if(!empty($domain))
		{
			$return['domain'] = $domain;
		}
		return $return;
	}

	private function getSearchStatus($status)
	{
		$where = array();
		if($status == -1)
		{
			return $where;
		}
		switch($status)
		{
			case 0:
				$where = array('ReceiveStatus' => 0, 'Status' => 0, 'ReceiveId' => $this->enameId);
				break;
			case 1:
				$where = array('ReceiveStatus' => 1, 'ReceiveId' => $this->enameId);
				break;
			case 2:
				$where = array('ReceiveStatus' => 2, 'ReceiveId' => $this->enameId);
				break;
			case 3:
				$where = array('SendStatus' => 3, 'ReceiveId' => $this->enameId);
				break;
			case 5:
				$where = array('ReceiveStatus' => 0, 'SendId' => $this->enameId, 'Status' => 0);
				break;
			case 6:
				$where = array('ReceiveStatus' => 1, 'SendId' => $this->enameId);
				break;
			case 7:
				$where = array('ReceiveStatus' => 2, 'SendId' => $this->enameId);
				break;
			case 8:
				$where = array('SendStatus' => 3, 'SendId' => $this->enameId);
				break;
		}
		return $where;
	}

	/**
	 * 获取PUSH列表
	 */
	public function getPushList($params, $fields = "*")
	{
		$mod = new \models\manage\domain\DomainPushMod();
		return $mod->pushList($params, $fields);
	}

	public function returnPushField($pushList)
	{
		if(empty($pushList))
		{
			return $pushList; 
		}
		$return = array();
		foreach($pushList as $key => $value)
		{
			$return[$key]['PushId'] = $value['PushId'];
			$return[$key]['Content'] = $value['Content'];
			$return[$key]['CreateTime'] = $value['CreateTime'];
			$return[$key]['ReceiveTime'] = $value['ReceiveTime'];
			$return[$key]['IsLock'] = $value['IsLock'];
			if(\common\Common::getRequestUser() == 'api')
			{
				$return[$key]['DomainName'] = $this->formatPushDomain($value['DomainName']);
			}
			else 
			{
				$return[$key]['Status'] = $value['Status'];
				$return[$key]['SendStatus'] = $value['SendStatus'];
				$return[$key]['ReceiveStatus'] = $value['ReceiveStatus'];
				$return[$key]['DomainName'] = $value['DomainName'];
			}
			$return[$key]['PushType'] = $value['PushType'];
			$return[$key]['PushPrice'] =  sprintf("%1\$.2f",$value['PushPrice']);
			$return[$key]['SendId'] = $value['SendId'];
			$return[$key]['ReceiveId'] = $value['ReceiveId'];
			$return[$key]['PushStatus'] = $this->formmatPushStatus($value);
		}
		return $return;
	}

	/**
	 * push个数统计
	 */
	public function pushCount($enameId)
	{
		$params = array('ReceiveStatus' => 0, 'Status' => 0, 'ReceiveId' => $this->enameId);
		$count = $this->getCount($params);
		return empty($count) ? 0 : $count['total'];
	}

	/**
	 * 根据pushid获取信息
	 *
	 * @param pushId type 1收到的请求 发送的请求
	 */
	public function getPushInfo($pushId, $ver = '')
	{
		$mod = new \models\manage\domain\DomainPushMod();
		$pushInfo = $mod->pushList(
			array('PushId' => $pushId, 'or' => array('ReceiveId' => $this->enameId, 'SendId' => $this->enameId)), '*', 
			true);
		if(!$pushInfo)
		{
			Response::setErrMsg(322019, "查无PUSH记录");
			throw new \Exception("查无PUSH记录", 322019);
		}
		return $pushInfo;
	}

	public function getFormatPushInfo($pushId, $ver = '')
	{
		$pushInfo = $this->getPushInfo($pushId);
		return array('DomainName' => $this->formatPushDomain($pushInfo['DomainName'], $ver), 
			'PushType' => $pushInfo['PushType'], 'ReceiveId' => $pushInfo['ReceiveId'], 
			'PushPrice' => $pushInfo['PushPrice'], 'SendId' => $pushInfo['SendId'], 
			'PushStatus' => $this->formmatPushStatus($pushInfo), 'CreateTime' => $pushInfo['CreateTime'], 
			'Content' => $pushInfo['Content'],'IsLock'=>$pushInfo['IsLock']);
	}

	/**
	 * 域名是否是打包域名
	 */
	private function formatPushDomain($domain, $ver = '')
	{
		$domain = DomainFunLib::showDomainToEnameShow($domain);
		$domainArr = explode("\n", $domain);
		if($ver)
		{
			return $domainArr;
		}
		if(count($domainArr) > 1)
		{
			return $domainArr[0] . "(打包".count($domainArr)."个)";
		}
		return $domain;
	}

	/**
	 * push信息状态处理
	 */
	private function formmatPushStatus($pushInfo)
	{
		$status = -1; // 防止出错 状态未知
		if($pushInfo['ReceiveStatus'] == 0 && $pushInfo['Status'] == 0 && $pushInfo['ReceiveId'] == $this->enameId)
		{
			$status = 0; // 我未接收
		}
		if($pushInfo['ReceiveStatus'] == 1 && $pushInfo['ReceiveId'] == $this->enameId)
		{
			$status = 1; // 我已接收
		}
		if($pushInfo['ReceiveStatus'] == 2 && $pushInfo['ReceiveId'] == $this->enameId)
		{
			$status = 2; // 我已拒绝
		}
		if($pushInfo['SendStatus'] == 3 && $pushInfo['ReceiveId'] == $this->enameId)
		{
			$status = 3; // 对方已经取消
		}
		if($pushInfo['ReceiveStatus'] == 0 && $pushInfo['Status'] == 0 && $pushInfo['SendId'] == $this->enameId)
		{
			$status = 5; // 对方未接收
		}
		if($pushInfo['ReceiveStatus'] == 1 && $pushInfo['SendId'] == $this->enameId)
		{
			$status = 6; // 对方已接收
		}
		if($pushInfo['ReceiveStatus'] == 2 && $pushInfo['SendId'] == $this->enameId)
		{
			$status = 7; // 对方已拒绝
		}
		if($pushInfo['SendStatus'] == 3 && $pushInfo['SendId'] == $this->enameId)
		{
			$status = 8; // 我已取消
		}
		return $status;
	}

	public function getPushStatus($pushId)
	{
		$mod = new \models\manage\domain\DomainPushMod();
		$pushInfo = $mod->pushList(array('PushId' => $pushId), '*', true);
		if(!$pushInfo)
		{
			Response::setErrMsg(322019, "查无PUSH记录");
			return FALSE;
		}
		// 0 我未接收 1 我已接收 2 我已拒绝 3 对方已经取消 5 对方未接收 6 对方已接收 7 对方已拒绝 8 我已取消
		if($pushInfo['ReceiveStatus'] == 0 && $pushInfo['Status'] == 0)
		{
			return 1;
		}
		else 
			if($pushInfo['ReceiveStatus'] == 1 || $pushInfo['ReceiveStatus'] == 2 || $pushInfo['SendStatus'] == 3)
			{
				return 2;
			}
			else // 其他状态错误，当做非法只
			{
				Response::setErrMsg(322019, "查无PUSH记录");
				return FALSE;
			}
	}

	/**
	 * 更新域名状态
	 *
	 * @param string $domain
	 * @param int $status 1下架(正常状态) 2交易
	 * @return array
	 */
	public function domainAddToSale($domain, $status,$isjingji = false)
	{ 
		$domainList = is_array($domain) ? $domain : array($domain);//全部转成数组的形式
		$dnMod = new ModBase('domain'); 
		$dnMod->db->autocommit(false);
		$isBack = FALSE;
		$domainInfoList = array();
		$domainIdList = array();
		foreach($domainList as $domainName)
		{
			//交易开始 
			\core\Log::write($domainName . '|状态：' . $status . '|start', $this->conf->domain->logFolder, 'domainTrade');

			// 获取域名信息
			$checkInfo = $this->domainManageLib->getDomainInfo(array('DomainName' => $domainName));
			\core\Log::write($domainName . '|原始状态：' . empty($checkInfo['DomainMyStatus']) ? '' : $checkInfo['DomainMyStatus'] . '|info', $this->conf->domain->logFolder, 'domainTrade');
			
			//设置前的状态
			DomainLogsLib::addDomainServiceTransAction($dnMod, $domainName, array('memo' => 'set_domain_my_status', 
				'DomainMyStatus' => empty($checkInfo['DomainMyStatus']) ? '' : $checkInfo['DomainMyStatus'], 'status' => $status), 35);
			
			if(!empty($checkInfo))
			{
				if($status == 1 && $isjingji ==true && $checkInfo['DomainMyStatus']!=3)
				{
					$isBack = TRUE;
					break;
				}
				$domainInfoList[] = $checkInfo;
				$domainIdList[] = $checkInfo['DomainId'];
				if($status != 1)
				{
					// 能否上架基本判断
					if(FALSE == $this->checkDomainSaleStatus($domainName, $checkInfo))
					{
						\core\Log::write($domainName . '|状态：' . $status . '|' . $checkInfo['DomainMyStatus'] .
							'|error|code:' . Response::getErrCode() . '|' . Response::getErrMsg(), $this->conf->domain->logFolder, 'domainTrade');
						$isBack = TRUE;
						break;
					}
				}
				
				// 能否上架下架基本判断
				if(FALSE == $this->checkDomainUpDownStatus($status, $checkInfo))
				{
					Response::setErrMsg(322004, $domainName.'域名状态错误，操作失败');
					\core\Log::write($domainName . '|状态：' . $status . '|' . $checkInfo['DomainMyStatus'] .
						'|error|code:' . Response::getErrCode() . '|' . Response::getErrMsg(), $this->conf->domain->logFolder, 'domainTrade');
					$isBack = TRUE;
					break;
				}
			}
			else
			{
				Response::setErrMsg(322000, $domainName.'域名不存在');
				$isBack = TRUE;
				break;
			}
		}
		
		//上面的检测都符合
		if($isBack === FALSE)
		{
			$info = $this->domainManageLib->setDomainOnOffSale($domainIdList,$status);
			if(FALSE != $info)
			{
				$this->domainSaleSuccessLog($dnMod,$domainInfoList, $status);
				$dnMod->db->autocommit(true);
				return TRUE;
			}
			else
			{
				\core\Log::write(json_encode($domainList) . '|状态：' . $status . '|error|code:2001|update-database-error', 
					$this->conf->domain->logFolder, 'domainTrade');
				$dnMod->db->rollback();
				$dnMod->db->autocommit(true);
				Response::setErrMsg(300000, '系统错误');
				return FALSE;
			}
		}
		
		// 回退处理
		$dnMod->db->rollback();
		$dnMod->db->autocommit(true);
		return FALSE;
	}
	
	/**
	 * 域名过户
	 *
	 * @param array $domainInfo
	 * @param int $newId
	 * @param int $templateId
	 * @param string $templateName
	 * @param int $tempType
	 * @return number|boolean
	 */
	public function moveDomain($domainInfo, $newId, $templateId, $templateName, $tempType)
	{
		if(!$domainInfo || !is_array($domainInfo))
		{
			Response::setErrMsg(300019, '参数有误');
			return FALSE;
		}
		// 若是CN域名临时维护则暂不过户
		if(DomainFunLib::isChinaDomain($domainInfo['DomainName']) && !DomainOpenLib::tmpFuncOpenCheck(FALSE))
		{
			Response::setErrMsg(399999, '域名过户失败');
			return false;
		}
		// 域名过户 无脑取消隐私保护
		$setData = array('EnameId' => $newId, 'DomainMyStatus' => 1, 'AutoRenew' => 0, 
			'AddDate' => gmdate("Y-m-d H:i:s"), 'TemplateId' => $templateId, 'TempUserName' => $templateName, 
			'DomainGroup' => 0, 'PrivacyTemp' => 0);
		// 检测是否展示页并关闭
		if($domainInfo['DomainHoldStatus'] == 3 || $domainInfo['DomainHoldStatus'] == 5)
		{ 
			DomainLogsLib::addDomainService($domainInfo['DomainName'], array('memo' => 'start_close_sell_page'), 37);
			$setData['DomainHoldStatus'] = 0;
		}
		$info = $this->domainManageLib->setDomainInfo(
			array('DomainName' => $domainInfo['DomainName'], 'DomainId' => $domainInfo['DomainId']), $setData);
		if(FALSE == $info)
		{
			Response::setErrMsg(322007, '域名过户失败');
			return FALSE;
		}
		// 经纪域名过户修改域名信息通知消息到监控中心
		$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'domain_status_change')); 
		$amqp->sendMq(
			array('uid' => $newId, 'templateid' => $templateId, 'time' => time(), 'dn' => array($domainInfo['DomainName']), 
				'status' => 1, 'ip' => \common\Common::getRequestIp(), 'source' => 'Monitor'));
		// 修改扩展表信息
		$params = array('TradeTime' => date('Y-m-d H:i:s'), 'EnameId' => $newId);
		if(!empty($domainInfo['PrivacyTemp']))
		{
			$params['LastClosePrivacy'] = date('Y-m-d H:i:s');
		}
		$domainExtMod = new \models\manage\domain\DomainExtMod();
		// 添加交易时间和关闭隐私保护时间
		if(!$upExtInfo = $domainExtMod->setDomainExt(array('DomainId' => $domainInfo['DomainId']), $params))
		{
			\core\Log::write('0603域名push添加扩展信息失败， domain:' . $domainInfo['DomainName'], $this->conf->domain->logFolder, 
				'moveDomain');
		}
		return TRUE;
	}

	public function moveDomainNew($domainList, $newId, $templateList,$domainNameList)
	{
		if(!$domainList || !is_array($domainList))
		{
			Response::setErrMsg(300019, '参数有误');
			return FALSE;
		}
		$templateInfo = $templateList; 
		$pushData =  $privacyDomains = $holdDomains = $domainIdList = array();
		foreach($domainList as $domainInfo)
		{
			array_push($domainIdList,$domainInfo['DomainId']);
			if($domainInfo['DomainHoldStatus'] == 3 || $domainInfo['DomainHoldStatus'] == 5)
			{
				array_push($holdDomains,$domainInfo['DomainId']);
			}
			if(!empty($domainInfo['PrivacyTemp']))
			{
				array_push($privacyDomains,$domainInfo['DomainId']);
			}
			$pushData[] = array('domain' => $domainInfo['DomainName'],
					'oldTemplateId' => $domainInfo['TemplateId'], 'oldTemplateName' => '',
					'registrarId' => $domainInfo['RegistrarId'], 'tempType' => $templateInfo[0]['TemplateType'],
					'templateId' => $templateInfo[0]['TemplateId'],
					'newTemplateName' => $templateInfo[0]['TempUserName']);
		}
		//修改hold状态
		if($holdDomains && FALSE == $this->domainManageLib->setDomainInfo(array('in'=>array('DomainId'=>$holdDomains)), array('DomainHoldStatus'=>0),true,true))
		{
			\core\Log::write('0603 change hold， domain:' . implode(",",$domainNameList), $this->conf->domain->logFolder,
					'moveDomain');
		}
		
		$setData = array('EnameId' => $newId, 'DomainMyStatus' => 1, 'AutoRenew' => 0,'AddDate'=>date('Y-m-d H:i:s'),
				'TemplateId' => $templateInfo[0]['TemplateId'], 'TempUserName' => $templateInfo[0]['TempUserName'],
				'DomainGroup' => 0, 'PrivacyTemp' => 0);
		$rows = $this->domainManageLib->setDomainInfo(array('in' => array('DomainId' => $domainIdList)), $setData,true,true);
		if(FALSE == $rows || $rows != count($domainIdList))
		{
			Response::setErrMsg(322007, implode(',',$domainNameList).'域名过户失败');
			return FALSE;
		}
		$this->domainOtherChange($newId, $domainIdList, $privacyDomains);	
		return $pushData;
	}
	
	
	/**
	 * 检查push域名的状态
	 *
	 * @param array $domainArr
	 */
	public function checkPushDomainStatus($domains)
	{
		$newDomains = array();
		$domainArr = explode(',', $domains);
		$domainArr = array_filter($domainArr);
		$domainArr = array_map(function ($domain) {
			return trim($domain);
		}, $domainArr);
		$domainArr = array_unique($domainArr);
		$checkLocks = array();
		foreach($domainArr as $k => $domain)
		{
			if(!DomainFunLib::isOkDomain($domain))
			{
				$newDomains[] = array(
						'domain' => $domain, 'status' => false, 'msg' => $domain.'域名格式错误，不能PUSH', 'code' => 322069
				);
				continue;
			}
			$info = $this->domainManageLib->getDomainInfo(array('DomainName' => $domain, 'EnameId' => $this->enameId));
			if(!$info)
			{
				$newDomains[] = array(
						'domain' => $domain, 'status' => false, 'msg' => $domain.'不是您的域名，不能PUSH', 'code' => 322070
				);
				continue;
			}
			try
			{
				DomainFunLib::checkDomainToPush($info);
				DomainOpenLib::checkOpen('push', $domain, true);
			}
			catch(\Exception $e)
			{
				$newDomains[] = array(
						'domain' => $domain, 'status' => false, 'msg' => $e->getMessage(), 
						'code' => $e->getCode()
				);
				continue;
			}
			array_push($checkLocks,$domain);
			$newDomains[] = array('domain' => $domain, 'status' => true, 'msg' => '');
		}
		$newDomains = self::arrayOrder($newDomains);
		if($checkLocks)
		{
			$dnlogic = new \logic\manage\domain\DomainManageLogic();
			$checkReturns = $dnlogic->checkDomainIsLock($checkLocks);
		}
		foreach($newDomains as $key=>$domaininfos)
		{
			$newDomains[$key]['islock'] = isset($checkReturns[$domaininfos['domain']]) ? $checkReturns[$domaininfos['domain']] : 0;
		}
		return $newDomains;
	}
	// 批量模板过户,批量设置dns返回域名信息排序
	private function arrayOrder($array)
	{
		if(!is_array($array))
		{
			return $array;
		}
		$arrayNew = array();
		foreach($array as $k => $v)
		{
			if(!$v['status'])
			{
				$arrayNew[] = $array[$k];
				unset($array[$k]);
			}
		}
		return array_merge_recursive($arrayNew, $array);
	}

	/**
	 * push时检测域名是展示页状态 -> 关闭展示页
	 *
	 * @param array $info
	 * @param string $domain
	 * @param string $enameId
	 */
	public function checkIsCloseSellPage($info, $domain, $enameId)
	{
		if(in_array($info['DomainHoldStatus'], array(3, 5)))
		{
			$dnIf = new \interfaces\manage\Domains();
			$data = array('domain' => $domain, 'enameId' => $enameId);
			$closeResult = $dnIf->closeSellPage($domain, $enameId);
			if($closeResult === false)
			{
				DomainLogsLib::addDomainService($domain, 
					array('memo' => 'push_close_sell_page', 'c' => 'PUSH时关闭展示页失败', 'param' => $data, 
						'domainInfo' => $info), 37);
			}
		}
	}

	/**
	 * 检查PUSH记录是否有效 如果是返回记录信息
	 *
	 * @param int $pushId
	 * @param int $enameId
	 * @param int $actionId
	 * @return array
	 */
	public function checkPushIsActive($pushId, $enameId, $actionId)
	{
		//array('templatetyp'=>'push');
		$where = $actionId == 2 ? array('ReceiveId' => $enameId) : array('SendId' => $enameId);
		$where['PushId'] = $pushId;
		$mod = new \models\manage\domain\DomainPushMod();
		$pushInfo = $mod->pushList($where, '*', true);
		if(!$pushInfo)
		{
			throw new \Exception("错误的域名PUSH请求");
		}
		if($pushInfo['Status'])
		{
			throw new \Exception("该域名PUSH请求已经处理，请误重复操作！");
		}
		return $pushInfo;
	}

	/**
	 * 拒绝或者取消PUSH设置域名的状态
	 *
	 * @param DomainLib $domainLib
	 * @param array $domainArr
	 */
	public function setDomainStatus($domainArr, $sendId, $dnMod)
	{
		$redis = \core\RedisLib::getInstance('manage');
		foreach($domainArr as $v)
		{
			// 获取push之前的状态，防止交易限制状态经过push后变正常
			$tempDomainMyStatus = $redis->get('tempdomainmystatus_' . $v);
			$tempDomainMyStatus = $tempDomainMyStatus ? $tempDomainMyStatus : 1;
			$setStr = "update e_domains set DomainMyStatus=? where DomainName=? and DomainMyStatus=? and EnameId=?";
			$bindType = "isii";
			$bindValue = array($tempDomainMyStatus, $v, 4, $sendId);
			$setResult = $dnMod->update($setStr, $bindType, $bindValue);
			if($setResult)
			{
				$addStr = "insert into e_domain_service" . date('Y') .
					 "(Domain,OperationIp,OperationTime,OperationUser,UserId,Content,ServiceType)values(?,?,?,?,?,?,?)";
				$bindType = "ssssisi";
				$bindValue = array($v, \common\Common::getRequestIp(), date('Y-m-d H:i:s'), '系统', $sendId, 
					'拒绝或取消PUSH修改域名状态[' . $tempDomainMyStatus . ']', 12);
				if(!$dnMod->add($addStr, $bindType, $bindValue))
				{
					\core\Log::write($v . '添加域名状态修改日志失败,remark:' . '拒绝或取消PUSH修改域名状态[' . $tempDomainMyStatus . ']', 
						'domain');
				}
			}
			else
			{
				\core\Log::write('拒绝或取消PUSH修改域名状态失败--' . $v);
				throw new \Exception('PUSH更改,操作失败:6002');
			}
		}
	}

	public function setDomainPushStatus($pushId, $status, $receiveStatus, $sendStatus, $dnMod)
	{
		$setStr = "update e_domain_push set Status=?,ReceiveStatus=?,ReceiveTime=?,SendStatus=?,ReceiveIp=? where PushId=?";
		$bindType = "iisisi";
		$bindValue = array($status, $receiveStatus, date("Y-m-d H:i:s"), $sendStatus, \common\Common::getRequestIp(), 
			$pushId);
		$setResult = $dnMod->update($setStr, $bindType, $bindValue);
		if($setResult)
		{
			return TRUE;
		}
		\core\Log::write(
			json_encode(
				array('修改域名PUSH状态失败', 'pushid:' . $pushId, 'status:' . $status, 'r:' . $receiveStatus, 
					's:' . $sendStatus)));
		throw new \Exception('修改域名PUSH状态失败', 322036);
	}

	public function checkDomainInsert($domain, $regId)
	{
		if(!$domain)
		{
			DomainLogsLib::addDomainService($domain, 
				array('memo' => 'qiangzhu_add_dc', 'domain' => $domain, 'c' => '转码后的域名不存在'), 26);
			return array('flag' => false, 'msg' => '转码后的域名不存在');
		}
		if($regId == false)
		{
			DomainLogsLib::addDomainService($domain, array('memo' => 'registrarId_not_exits_dc', 'c' => $regId), 26);
			return array('flag' => false, 'msg' => '接口ID不存在');
		}
		$dnLib = new \lib\manage\domain\DomainManageLib();
		$domainInfo = $dnLib->getDomainInfo(array('DomainName' => $domain));
		if(!empty($domainInfo))
		{
			DomainLogsLib::addDomainService($domain, array('memo' => 'domain_exits_dc', 'c' => '域名已经存在放弃入库'), 26);
			return array('flag' => false, 'msg' => '域名已经存在');
		}
		return true;
	}

	/**
	 * 抢注域名添加扩展信息
	 */
	public function domainExtAdd($domainId, $enameId, $tempType)
	{
		$extMod = new \models\manage\domain\DomainExtMod();
		$ext = $extMod->addDomainExt(
			array('domainId' => $domainId, 'Tooltip' => 1, 'TooltipWay' => '1,2,3', 'dns' => '', 'domainFrom' => 1, 
				'enameId' => $enameId, 'domainIcp' => '', 'templateType' => $tempType));
		if(!$ext)
		{
			DomainLogsLib::addDomainService($domainId, 
				array('memo' => 'add domainext failed', 'params' => array($domainId, $enameId, $tempType)), 26);
		}
		return true;
	}

	/**
	 * 检测模板是否可以PUSH，返回模板名和模板类型 array('templateId'=>,'templateName'=>,'templateType'=>)
	 *
	 * @param string $domain
	 * @param int $cnTemp
	 * @param int $sysTempId
	 * @throws Exception
	 * @return array('templateId'=>,'templateName'=>,'templateType'=>)
	 */
	public function checkPushTemplateAllowToAccept($cnTemp, $sysTempId, $enameId, 
		\lib\manage\domain\TemplateLib $templateLib)
	{
		$templateName = '临时模板';
		$templateType = 0;
		$templateId = $cnTemp;
		if($sysTempId != $templateId)
		{
			$templateInfo = $templateLib->getTemplateInfo($templateId, $enameId);
			if(!$templateInfo)
			{
				throw new \Exception('你选择的模板不存在');
			}
			if($templateInfo['CnStatus'] != 2)
			{
				throw new \Exception('你选择的模板不是白名单模板,请添加模板');
			}
			$templateName = $templateInfo['TempUserName'];
			$templateType = $templateInfo['TemplateType'];
		}
		return array('templateId' => $templateId, 'templateName' => $templateName, 'templateType' => $templateType);
	}

	/**
	 * 域名加入模板过户队列
	 *
	 * @param int $enameId
	 * @param array $newPushArr
	 * @package bool $isTrade 是否交易过户
	 */
	public function DomainPushTemplate($enameId, $newPushArr, $isTrade = false)
	{
		$data = array('Function' => 'template_push', 'EnameId' => $enameId, 'Data' => $newPushArr);
		if($isTrade)
		{
			$data['Hidden'] = 1;
		}
		try
		{
			$queueLib = new \logic\manage\newqueue\QueueLogic();
			$queueLib->addQueueTask($data);
		}
		catch(\Exception $e)
		{
			DomainLogsLib::addDomainService($enameId, 
				array('memo' => 'temp_push', 'param' => $newPushArr, 'res' => $e->getMessage()), 35);
		}
	}
	
	/**
	 * 接受PUSH 修改数据库域名的用户ID和域名状态
	 * @param int $enameId
	 * @param string $domain
	 * @param int $templateId
	 * @param string $templateName
	 */
	public function pushAcceptDomainChangeOwner($enameId, $domain, $templateId, $templateName, $oldEnameId, 
		$resetHoldStatus, $domainMod)
	{
		// 获取push之前的状态，防止交易限制状态经过push后变正常
		$redis = \core\RedisLib::getInstance('manage');
		$tempDomainMyStatus = $redis->get('tempdomainmystatus_' . $domain);
		$tempDomainMyStatus = $tempDomainMyStatus ? $tempDomainMyStatus : 1;
		// 更新域名所有者信息
		$holdStatusStr = $resetHoldStatus ? ",DomainHoldStatus=0" : "";
		$upStr = "update e_domains set EnameId=?,DomainMyStatus=?,AutoRenew=?,TemplateId=?,TempUserName=?,AddDate=?,DomainGroup=?,PrivacyTemp=?" .
			 $holdStatusStr . " where DomainName=? and EnameId=?";
		$bindType = "iiiissiisi";
		$bindValue = array($enameId, $tempDomainMyStatus, 0, $templateId, $templateName, gmdate("Y-m-d H:i:s"), 0, 0, 
			$domain, $oldEnameId);
		$upResult = $domainMod->update($upStr, $bindType, $bindValue,true,true);
		if(!$upResult)
		{
			\core\Log::write(json_encode(array('接收PUSH域名，修改本地库失败!', $enameId, $templateId, $templateName)), 
				$this->conf->domain->logFolder, 'domainPush');
			return false;
		}
		return true;
	}

	/**
	 * 域名PUSH接受完成，发送站内信，增加域名操作日志
	 *
	 * @param array $pushTemplate
	 * @param int $pushId
	 * @param int $enameId
	 * @param array $domains
	 * @param int $sendId
	 * @param int $num
	 */
	public function pushSuccess($pushTemplate, $pushId, $enameId, $domains, $sendId, $num)
	{
		$domainsArr = $domains;
		$domains = is_array($domains) ? implode(',', $domains) : $domains;
		$smsLogic = new \logic\manage\queue\SmsLogic();
		$domainLogsMod = new \models\manage\domain\DomainLogsMod();
		$smsLogic->sendSiteMsg($sendId, $pushTemplate['accept'], 
			array('enameId' => $sendId, 'domain' => $domains, 'receiveId' => $enameId, 'typeFlag' => 4, 
				'role' => 'seller', 'id' => $pushId));
		if(!is_array($domainsArr))
		{
			$domainsArr = array($domainsArr);
		}
		foreach($domainsArr as $v)
		{
			$domainLogsMod->addOperationLog($v, $enameId, '接收PUSH', 2);
		}
	}

	/**
	 * 域名push更改enameid和push状态
	 */
	public function domainPushMain($enameId, $newPushArr, $pushId, $domainMod, $orderId)
	{
		$acceptResult = TRUE;
		foreach($newPushArr as $k => $v)
		{
			$orderResult = $this->pushAcceptDomainChangeOwner($enameId, $v['domain'], $v['templateId'], 
				$v['newTemplateName'], $v['oldEnameId'], $v['resetHoldStatus'], $domainMod);
			if($orderResult === FALSE)
			{
				$acceptResult = false;
				break;
			}
		}
		// 设置域名状态独立出来，供事务回滚
		if($acceptResult)
		{
			// 域名PUSH接受完成，设置状态
			$upStr = "update e_domain_push set Status=?,ReceiveStatus=?,ReceiveTime=?,SendStatus=?,ReceiveIp=?,OrderId=? where PushId=?";
			$bindType = "iisisii";
			$bindValue = array(1, 1, date("Y-m-d H:i:s"), 0, \common\Common::getRequestIp(), $orderId, $pushId);
			$upResult = $domainMod->update($upStr, $bindType, $bindValue);
			if(!$upResult)
			{
				$acceptResult = false;
				\core\Log::write(json_encode(array('修改域名PUSH状态失败', 'pushid:'. $pushId, 'status:1', 'r:1', 's:0')));
			}
		}
		return $acceptResult;
	}

	/**
	 * 域名push后续操作
	 */
	public function domainPushTrail($enameId, $newPushArr, $pushTemplate, $pushId, $domains, $sendId, $price = 0 ,$pushType=2,$islock = 1)
	{
		$domainExtMod = new \models\manage\domain\DomainExtMod();
		$redis = \core\RedisLib::getInstance('manage');
		// 发送站内信，增加域名操作日志
		$this->pushSuccess($pushTemplate, $pushId, $enameId, $domains, $sendId, count($newPushArr));
		$sendDomains = is_array($domains) ? implode(',', $domains) : $domains;
		$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'domain_push_success')); 
		$amqp->sendMq(
			array('time' => time(), 'isLock'=>$islock ? intval($islock) : 1,'domains' => explode(',', $sendDomains), "sender" => intval($sendId), "uid" => intval($enameId), 
				"price" => $price, "pushType" => intval($pushType), "pushId" => intval($pushId), 'ip' => \common\Common::getRequestIp()));
		foreach($newPushArr as $k => $v)
		{
			// 删除获取push之前的域名缓存状态
			$redis->delete('tempdomainmystatus_' . $v['domain']);
			// 域名密码重置和修改
			$resetPwdRes = $domainExtMod->setDomainPassword($v['domainId']);
			if(!$resetPwdRes)
			{
				\core\Log::write(
					json_encode(array('PUSH域名，重置域名密码失败!', $enameId, $v['domain'], date('Y-m-d H:i:s', time()))), 
					$this->conf->domain->logFolder, 'domainPush');
			}
			else
			{
				// 域名push的时候在扩展表添加一个交易时间和记录隐私保护时间
				$set = array('EnameId' => $enameId, 'TradeTime' => date('Y-m-d H:i:s'));
				if($v['privacyTemp'])
				{
					$set['LastClosePrivacy'] = date('Y-m-d H:i:s');
				}
				$addInfoResult = $domainExtMod->setDomainExt(array('DomainId' => $v['domainId']), $set);
				if(!$addInfoResult)
				{
					\core\Log::write(
						json_encode(array('PUSH域名，添加域名扩展表交易时间失败!', $enameId, $v['domain'], date('Y-m-d H:i:s', time()))), 
						$this->conf->domain->logFolder, 'domainPush');
				}
			}
		}
	}
	

	private function domainSaleSuccessLog($dnMod,$domainListInfo, $status)
	{
		if(empty($domainListInfo))
		{
			return FALSE;
		}
		$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'domain_status_change'));
		$tradeEnameIdArr=array();
		$tradeTemplateIdArr=array();
		foreach($domainListInfo as $checkInfo)
		{
			$tradeEnameIdArr[$checkInfo['EnameId']][] = $checkInfo['TemplateId'];
			$tradeTemplateIdArr[$checkInfo['TemplateId']][] = $checkInfo['DomainName'];
			\core\Log::write($checkInfo['DomainName'] . '|状态：' . $status . '|success', $this->conf->domain->logFolder, 'domainTrade');
			if($status == 3)
			{
				$logMsg = "经纪中介";
			}
			elseif($status != 1)
			{
				$logMsg = "发布交易";
			}
			else
			{
				if($checkInfo['DomainMyStatus'] == 3)
				{
					$logMsg = "取消经纪中介";
				}
				else 
				{
					$logMsg = "交易下架";
				}
			}
			if(!DomainLogsLib::addDomainOperaterLogTransAction($dnMod,$checkInfo['DomainName'], $checkInfo['EnameId'], $logMsg, 8))
			{
				\core\Log::write(
					'写入域名日志失败' . $checkInfo['DomainName'] . '|' . $checkInfo['EnameId'] . '|' . $status == 1 ? '交易下架' : '发布交易' .
						 '|8', $this->conf->domain->logFolder, 'domainTrade');
			}
		}
		if(!empty($tradeEnameIdArr))
		{
			foreach($tradeEnameIdArr as $uid => $templateArr)
			{
				$templateArr =array_unique($templateArr);
				if(!empty($templateArr))
				{
					foreach($templateArr as $tid)
					{
						$tradeTemplateIdArr[$tid] =array_unique($tradeTemplateIdArr[$tid]);
						if(!empty($tradeTemplateIdArr[$tid]))
						{
							$amqp->sendMq(
								array('uid' => $uid, 'dn' => $tradeTemplateIdArr[$tid], 'time' => time(), 
									'source' => 'publish trade', 'ip' => \common\Common::getRequestIp(), 
									'status' => $status, 'templateid' => $tid));
						}
					}
				}
			}
		}
		unset($domainListInfo);
	}
	

	private function checkDomainSaleStatus($domain, $checkInfo)
	{
		if(FALSE == DomainFunLib::checkDomainRegdate($domain, $checkInfo['RegDate'], $checkInfo['ExpDate']))
		{
			if(300014 == Response::getErrCode())
			{
				Response::setErrMsg(322005, $domain.'域名注册未满9天，不能出售');
			}
			if(300015 == Response::getErrCode())
			{
				Response::setErrMsg(322006, $domain.'域名已经过期，不能出售');
			}
			return FALSE;
		}
		if(DomainFunLib::checkIsTempTemplate($checkInfo['TemplateId']) ||
			 DomainFunLib::checkTempType($checkInfo['TemplateId']))
		{
			Response::setErrMsg(322002, $domain . '域名模板为临时模板，不能出售');
			return FALSE;
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'transwhitetemptime');
		$transwhitetime = $conf->endtime;
		if(time() >= strtotime($transwhitetime))
		{
			if(FALSE == DomainFunLib::checkIsWhiteTemp($checkInfo['TemplateId']))
			{
				
				Response::setErrMsg(322020, $domain.'域名模板为非白名单模板，不能出售');
				return FALSE;
			} 
		}   
		if(FALSE == DomainFunLib::checkisRealDomainRenew($domain, $checkInfo['IsRealName'], $checkInfo['RegDate']))
		{
			Response::setErrMsg(322055, $domain.'域名未通过实名，不能出售');
			return FALSE;
		}
		if(FALSE == DomainFunLib::checkIsWhiteTemp($checkInfo['TemplateId']) && (DomainFunLib::isChinaDomain($domain)))
		{
			Response::setErrMsg(322020, $domain.'域名模板为非白名单模板，不能出售');
			return FALSE;
		}
		if($checkInfo['DomainMyStatus'] == 2)
		{
			Response::setErrMsg(322003, $domain.'域名正在交易，不能出售');
			return FALSE;
		}
		if($checkInfo['DomainMyStatus'] == 3)
		{
			Response::setErrMsg(322040, $domain.'域名正在经纪中介状态，无法发布交易');
			return FALSE;
		}
		if($checkInfo['DomainMyStatus'] == 11)
		{
			Response::setErrMsg(300020, $domain.'该域名已经设置了注册商安全锁，不能操作，如果需要操作请先取消注册商安全锁');
			return FALSE;
		}
		if($checkInfo['DomainMyStatus'] == 12)
		{
			Response::setErrMsg(300021, $domain.'该域名已经设置了注册局安全锁，不能操作，如果需要操作请联系客服');
			return FALSE;
		}
		if($checkInfo['DomainMyStatus'] == 13)
		{
			Response::setErrMsg(322017, $domain.'域名正在申请域名安全锁，不能出售');
			return FALSE;
		}
		elseif($checkInfo['DomainMyStatus'] == 9)
		{
			Response::setErrMsg(322021, $domain.'操作失败，请联系客服');
			return FALSE;
		}
		elseif($checkInfo['DomainMyStatus'] == 15 || $checkInfo['DomainMyStatus'] == 7 || $checkInfo['DomainHoldStatus'] == 2)
		{
			Response::setErrMsg(322016, $domain.'域名锁定，不能出售');
			return FALSE;
		}
		elseif($checkInfo['DomainMyStatus'] == 4)
		{
			Response::setErrMsg(322015, $domain.'域名正在push，不能出售');
			return FALSE;
		}
		elseif($checkInfo['DomainMyStatus'] == 5)
		{
			Response::setErrMsg(322014, $domain.'域名正在转出，不能出售');
			return FALSE;
		}
		if(($checkInfo['DomainProperty'] == 4 || $checkInfo['DomainProperty'] == 6) && $checkInfo['ClassName'] == 1)
		{
			Response::setErrMsg(322013, $domain.'腾讯邮箱域名，不能出售');
			return FALSE;
		}
		if($checkInfo['DomainMyStatus'] == 14)
		{
			Response::setErrMsg(322022, $domain.'域名交易限制，不能出售');
			return FALSE;
		}
		return TRUE;
	}

	private function checkDomainUpDownStatus($status, $checkInfo)
	{
		if($status == 2 || $status == 3)
		{
			return $checkInfo['DomainMyStatus'] == 1;
		}
		if($status == 1)
		{
			return $checkInfo['DomainMyStatus'] == 2 || $checkInfo['DomainMyStatus'] == 3;
		}
		return FALSE;
	}
	
	public function checkDomainPushStatus($isNewInter,$domainInfo)
	{
		if($isNewInter)
		{
			return in_array($domainInfo['DomainMyStatus'], array(2, 3));
		}
		if(!$isNewInter)
		{
			return $domainInfo['DomainMyStatus'] == 1;
		}
		return FALSE;
	}
	
	public function getTradeDomainTemp($enameId)
	{ 
		$dnTempalteLib = new \lib\manage\domain\TemplateLib();
		return $dnTempalteLib->getUseTemplates($enameId,"TradeTemplate", TRUE);
	}
	
	private  function domainOtherChange($newId,$allIDs,$privacyIds)
	{
		try
		{
			$queueTasklib = new \lib\manage\newqueue\QueueTaskLib();
			$time = date('Y-m-d H:i:s');
			$params = array('Function' => 'change_domain_owner', 'EnameId' => $newId, 'Priority' => 3, 'Hidden' => 1,
					'Data' => array(
							array('trade_and_pwd' => array('domainIds' => $allIDs, 'TradeTime' => $time),
									'privacy' => array('domainIds' => $privacyIds, 'LastClosePrivacy' => $time))));
			$queueTasklib->addQueue($params);
		}
		catch(\Exception $e)
		{
			DomainLogsLib::addDomainService($newId, array('memo' => 'temp_push', 'param' => array($allIDs, $privacyIds), 'res' => $e->getMessage()), 35);
		}
	}

	/**
	 *
	 * @param string $pushType //PUSH类型 1收到的请求 2发送的请求
	 * @param string $searchType //接受状态
	 */
	public function getDataByPushTypeAndSearchType($pushType, $searchType)
	{
		$return=array();
		if($pushType == 1)  
		{
			if($searchType === 0)
			{
				$return = array('ReceiveId' => $this->enameId, 'ReceiveStatus' => $searchType, 'status' => 0);
			}
			elseif($searchType == 1 || $searchType == 2)
			{
				$return = array('ReceiveId' => $this->enameId, 'ReceiveStatus' => $searchType);
			}
			elseif($searchType == 3)
			{
				$return = array('ReceiveId' => $this->enameId, 'SendStatus' => 3);
			}
			else
			{
				$return = array('ReceiveId' => $this->enameId);
			}
		}
		else
		{
			if($searchType === 0)
			{
				$return = array('SendId' => $this->enameId, 'ReceiveStatus' => $searchType, 'status' => 0);
			}
			elseif($searchType == 1 || $searchType == 2)
			{
				$return = array('SendId' => $this->enameId, 'ReceiveStatus' => $searchType);
			}
			elseif($searchType == 3)
			{
				$return = array('SendId' => $this->enameId, 'SendStatus' => 3);
			}
			else
			{
				$return = array('SendId' => $this->enameId);
			}
		}
		return $return;
	}
}
	
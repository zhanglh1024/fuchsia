<?php
namespace lib\manage\domain;
use lib\manage\common\DomainFunLib as DomainFunLib;
use lib\manage\common\DomainOpenLib as DomainOpenLib;

/**
 * 获取域名注册 续费 转入的价格和模板相关
 */
class DomainPriceTempLib
{
	public $enameId;
	public function __construct($enameId)
	{
		$this->enameId = $enameId;
	}
	/**
	 * 获取价格模板 app专用
	 */
	public function priceTemplate($enameId, $shopType, $domain, $ext = '', $productType = FALSE)
	{
		$queryLib = new \lib\manage\domain\DomainQueryLib($enameId);
		$tempLib = new \lib\manage\domain\TemplateLib($enameId);
		if(FALSE == DomainFunLib::isOkDomain($domain))
		{
			return array('domain' => $domain, 'templateList' => array(), 'msg' => $domain . '域名格式错误', 'code' => 60001);
		}
		if(DomainFunLib::checkIsDownDomain($domain) && in_array($shopType, array(1, 2)))
		{
			return array('domain' => $domain, 'templateList' => array(), 'msg' => '获取域名价格失败', 'code' => 60002);
		}
		//优先珍品域名
		$price = $queryLib->getTopDomainPrice($domain, $shopType);
		if(FALSE === $price)
		{
			$price = $queryLib->getDomainPrice($domain, DomainFunLib::getDomainClassAll($domain), $shopType, $productType);
		}
		else
		{
			$istop = 1;
			$price = sprintf("%.2f", $price);
		}
		if(FALSE === $price)
		{
			return array('domain' => $domain, 'templateList' => array(), 'msg' => '获取域名价格失败', 'code' => 60002);
		}
		$defaultType = $shopType == 1 ? 'RegistTemplate' : ($shopType == 2 ? 'TransferInTemplate' : 'domainRenew');
		$tempList = $tempLib->getUseTemplates($enameId, $defaultType);
		if(isset($istop))
		{
			$year = 1;
		}
		else
		{
			$year = $this->getDomainYear($domain, $shopType);
			//客户端不参与.wang后缀活动，默认用户只能注册一年.......
			if(\common\Common::getRequestUser() == 'api')
			{
				$yearPrice = $queryLib->checkDomainYears($domain, $shopType, $year);
				$year = $yearPrice['year'];
				if($yearPrice['specialPrice'] !== FALSE)
				{
					$price = $yearPrice['specialPrice'];
				}
			}
		}
		//org活动时间：2016.9.1-2016.9.30 首年注册23元
		if(DomainFunLib::getDomainClass($domain) == 'ORG' && $shopType == 1 && time()>=strtotime('2016-09-01 00:00:00') && time()<=strtotime('2016-09-30 23:59:59'))
		{
			$price = '23.00';
			$year = 1;
		}
		return array('domain' => $domain, 'price' => $price, 'year' => $year, 'templateList' => $tempList,
				'ext' => $ext, 'code' => 60000);
	}

	/**
	 * 查看域名注册续费转入的年数
	 */
	public function getDomainYear($domain, $shopType, $throw = TRUE)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domainrenew');
		$renewYear = $conf->domainReneYear;
		if($shopType == 3)//续费
		{
			$dnLib = new \lib\manage\domain\DomainManageLib();
			$domainInfo = $dnLib->getDomainInfo(array('DomainName' => $domain));
			if(empty($domainInfo) || empty($domainInfo['ExpDate']))
			{
				if(!$throw)
				{
					return FALSE;
				}
				throw new \Exception("域名信息获取失败", 311005);
			}
			$expDate = date("Y", strtotime($domainInfo['ExpDate']));
			$expMonth = date("md", strtotime($domainInfo['ExpDate']) + 86400);
			$year = (int) $renewYear - ($expDate - date("Y"));
			if((int) gmdate("md") <= (int) $expMonth)//如果域名在当天后过期 再减去1年
			{
				$year--;
			}
			$year = $year > 0 && $year < 11 ? $year : 1;
			return $year;
		}
		if($shopType == 1)
		{
			$suffix = DomainFunLib::getDomainClass($domain);
			return ($suffix == "PW" || $suffix == "ASIA") ? $conf->domainTransferYear : $renewYear;
		}
		return $conf->domainTransferYear;
	} 

	public function checkIscoopDomain($shopType, $domain, $regid, $expdate, $regdate, $domainMyStatus)
	{
		if($shopType != 3)
		{
			return FALSE;
		}
		try
		{
			$dnLib = new \lib\manage\domain\DomainManageLib();
			return $dnLib->cooperRegidDomainCheck($domain, $regid, $expdate, $regdate, $domainMyStatus);
		}
		catch(\Exception $e)
		{
			return FALSE;
		}
	}
}

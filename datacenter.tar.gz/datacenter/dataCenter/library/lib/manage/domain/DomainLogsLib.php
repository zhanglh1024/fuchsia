<?php
namespace lib\manage\domain;
class DomainLogsLib
{
	/**
	 * 添加域名日志
	 */
	public static function addDomainLog($domain, $enameId, $logType, $sendData, $returnData, $logDesc, $isSuccess = 1)
	{
		$http_host = empty($_SERVER['HTTP_HOST']) ? (isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : '') : (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
		$php_self = !empty($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : (isset($_SERVER['PHP_SELF']) ? $_SERVER['PHP_SELF'] : '');
		$url = $http_host . $php_self;
		$ip = \common\Common::getRequestIp();
		$mod = new \models\manage\domain\DomainLogsMod();
		return $mod->addDomainLog($domain, $enameId, $logType, $sendData, $returnData, $ip, $logDesc, $isSuccess, $url);
	}

	/**
	 * 增加用户操作日志/后台管理员对某个域名的操作日志 域名作为主题
	 * 主记录操作成功的日志
	 */
	public static function addDomainOperaterLog($domain, $enameId, $content, $logType, $adminId = 0, $adminUser = '')
	{
		$mod = new \models\manage\domain\DomainLogsMod();
		return $mod->addOperationLog($domain, $enameId, $content, $logType, $adminUser, $adminId, \common\Common::getRequestIp());
	}

	
	/**
	 * 记录程序执行过程中的一些辅助数据或者执行失败的日志
	 * 给开发人员查询BUG用
	 */
	public static function addDomainService($domain, $content, $serviceType, $user = FALSE, $userId = FALSE)
	{
		$mod = new \models\manage\domain\DomainLogsMod();
		$user = $user ? $user : '系统';
		$userId = $userId ? $userId : 0;
		return $mod->addDomainService($domain, $content, $serviceType, $user, $userId);
	}
	
	/**
	 * 记录程序执行过程中的一些辅助数据
	 */
	public static function addDomainServiceExt($domain, $content, $serviceType, $adminId = FALSE, $enameId = FALSE)
	{
		$mod = new \models\manage\domain\DomainServiceExtMod();
		$adminId = $adminId ? $adminId : 0;
		$enameId = $enameId ? $enameId : 0;
		return $mod->addDomainService($domain, $content, $serviceType, $adminId, $enameId);
	}

	/**
	 * 获取e_domain_service信息
	 */
	public static function getDomainService($params, $isOne = false)
	{
		$mod = new \models\manage\domain\DomainLogsMod();
		return $mod->getDomainService($params, $isOne);
	}

	/**
	 * 更新e_domain_service信息
	 */
	public static function updateDomainService($where, $set)
	{
		$mod = new \models\manage\domain\DomainLogsMod();
		return $mod->updateDomainService($where, $set);
	}
	 
	
	public static function delDomainServiceById($id)
	{
		$mod = new \models\manage\domain\DomainServiceMod();
		return $mod->delDomainserviceById($id);
	}
	/**
	 * 事务专用写数据 防止垃圾数据 
	 */
	public static function addDomainServiceTransAction($transactionMod,$domain, $content, $serviceType, $user = FALSE, $userId = FALSE)
	{
		$addStr = "insert into e_domain_service".date('Y')."(Domain,OperationIp,OperationTime,OperationUser,UserId,Content,ServiceType)values(?,?,?,?,?,?,?)";
		$bindType = "ssssisi";
		$user = $userId ? $userId : '系统';
		$content = is_array($content) ? json_encode($content) : $content;
		$bindValue = array($domain, \common\Common::getRequestIp(), date('Y-m-d H:i:s'), $user, $userId, $content, $serviceType);
		if(!$transactionMod->add($addStr, $bindType, $bindValue))
		{
			\core\Log::write($domain.','.$serviceType.','.(is_array($content) ? json_encode($content) : $content),'domain');
			return FALSE; 
		}
		return TRUE;
	}
	
	/**
	 * 事务专用写数据 操作日志表 防止垃圾数据
	 */
	public static function addDomainOperaterLogTransAction($transactionMod,$domain, $enameId, $content, $logType, $adminId = 0, $adminUser = '')
	{
		$content = is_array($content) ? json_encode($content) : $content;
		$values = array($domain, date("Y-m-d H:i:s"), $enameId, $content, $logType, $adminUser, $adminId, \common\Common::getRequestIp());
		$query = 'insert into e_domain_operation_log'.date('Y') . '(DomainName,CreateTime,EnameId,Content,LogType,AdminUser,AdminId,Ip) values(?,?,?,?,?,?,?,?)';
		if(!$transactionMod->add($query, 'ssisisis', $values))
		{
			\core\Log::write($domain.','.$logType.','.(is_array($content) ? json_encode($content) : $content),'domain','domaintrade');
			return false;
		}
		return true;
	}
}
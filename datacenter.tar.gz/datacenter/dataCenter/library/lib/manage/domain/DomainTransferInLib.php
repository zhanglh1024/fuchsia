<?php
namespace lib\manage\domain;
use core\Response;
use lib\manage\domain\DomainLogsLib as DomainLogsLib;
use lib\manage\common\DomainFunLib;

class DomainTransferInLib
{

	public $enameId;
 
	private $mod;
 
	public $whoisBase;

	public $whoisEmail;

	public function __construct($enameId = '')
	{
		$this->enameId = $enameId;
		$this->mod = new \models\manage\domain\DomainTransferInMod(); 
	} 
 
	/**
	 * 域名转入逻辑
	 */
	public function domainTransferIn($domain, $ext, $orderId, $templateId, $year, $productType, $checkIsOkToAdd=true)
	{
		$domain = strtolower($domain);
		if ( $checkIsOkToAdd )
		{
			$tempInfo = $this->checkIsOkToAdd($domain, FALSE);
			if(is_array($tempInfo))
			{
				return $tempInfo; 
			}
		} 
		$password = empty($ext['password']) ? '' : $ext['password'];
		$dnsType = empty($ext['dnstype']) ? '' : $ext['dnstype'];
		$islock = empty($ext['islock']) ? 1 : $ext['islock'];
		$domainLtd = \lib\manage\common\DomainFunLib::getDomainClassAll($domain);
		// 获取配置文件域名后缀
		$confDomain = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$confLtd = array_flip($confDomain->domainLtd->toArray());
		$confDomainSf = $confDomain->domainLtdSf->toArray();
		$confLtd['中国'] = 24;
		$saveLtd = in_array($domainLtd, $confDomainSf) ? $confLtd['OtherCn'] : $confLtd[$domainLtd];
		// Get RegistrarId
		$queryLib = new \lib\manage\domain\DomainQueryLib($this->enameId);
		$productInfo = $queryLib->getProductInfo($domain, $domainLtd, 1, $productType);
		$registrarId = isset($productInfo['RegistarId']) ? $productInfo['RegistarId'] : 0;
		$insertData = array('DomainName' => $domain, 'EnameId' => $this->enameId, 
				'SubmitIp' => \common\Common::getRequestIp(), 'OrderId' => $orderId, 'TemplateId' => $templateId, 
				'Year' => $year, 'ProductType' => $productType, 'DnsStatus' => $dnsType, 'Password' => $password, 
				'TransferStatus' => - 6, 'CreateTime' => date('Y-m-d H:i:s'), 'DomainLtd' => $saveLtd, 'IsLock'=>$islock,
				'RegistrarId' => $registrarId);//-1->-6
		if(FALSE == $this->mod->addTransferIn($insertData))
		{
			\core\Log::write(json_encode(array('app域名转入，写入转入表失败', $domain, 'orderId:' . $orderId)), 'domain', 
				'transferin');
			return false;
		}
		//$this->setTransferinMessage($domain);
		$logic = new \logic\manage\thrift\VspLogic();
		if(!$logic->getDomainBusinessCode($domain))
		{
			\core\Log::write("app domaintransferin, businesscode error", 'domain','transferin');
		}
		return true;
	}

	/**
	 * 域名转入检查 是否在数据库 是否允许转入
	 */
	public function checkIsOkToAdd($domain, $isThrow = true)
	{
		$domainManageLib = new \lib\manage\domain\DomainManageLib();
		if($domainManageLib->getDomainInfo(array('DomainName' => $domain)))
		{
			$msg = $domain . '域名已经在我司，不能申请转入!';
			if($isThrow)
			{
				throw new \Exception($msg, 320006);
			}
			return array($msg);
		}
		$transferInfo = $this->mod->getTransferInfo(array('DomainName' => $domain , 'EnameId' => $this->enameId , 'order' => 'TransferInId desc'));
		if($transferInfo)
		{
			$msg = $domain . ' 域名已经存在转入域名列表，请勿重复申请!';
			if(($transferInfo['TransferStatus'] < 4 && $transferInfo['TransferStatus'] > -7) ||
				 $transferInfo['TransferStatus'] == 6)
			{
				if($isThrow)
				{
					throw new \Exception($msg, 320005);
				}
				return array($msg);
			}
		}
		return true;
	}

	/**
	 * 通过表e_service_progress的信息修改表e_domain_transfer_in
	 * edit:zougc 为了实现队列效果 默认从购物车写入的转入数据状态 -1 标识：系统正在处理中
	 *
	 * @param string $enameId
	 * @param string $domain
	 * @author linlz@ename.net
	 * @version 2012-03-27
	 * @version 2012-09-03 linlz 使用购物车表ext字段替代e_service_progress记录转入信息
	 */
	private function setTransferinMessage($domain)
	{
		// 如果用选择了模板和密码 默认自动写入到后台队列
		$infoData = $this->getTransferInfoByDomainStatus($domain, - 1);
		$transferIn[0]['transferId'] = $infoData['TransferInId'];
		$transferIn[0]['domain'] = $domain;
		$queueData = array('Function' => 'domain_transfer_in', 'Priority' => 5, 'EnameId' => $this->enameId, 
				'Data' => $transferIn, 'Hidden' => 1);
		try
		{
			$queueTaskLib = new \lib\manage\newqueue\QueueTaskLib();
			$addQueue = $queueTaskLib->addQueue($queueData);
		}
		catch (\Exception $e)
		{
			\core\Log::write(
				json_encode(
					array($domain, $this->enameId, 'msg' => $e->getMessage(), 'code:' . $e->getCode())),
				'domain', 'transferin');
		}
	}

	/**
	 * 域名转入拒绝
	 *
	 * @param array $transInfo
	 */
	public function domainTransferRejected($transInfo)
	{
		$upInfo = $this->setTransferInfo(array('TransferInId' => $transInfo['TransferInId']), 
			array('TransferStatus' => 7, 'UpdateTime' => date('Y-m-d H:i:s')), $transInfo['DomainName']);
		if(! $upInfo)
		{
			\core\Log::write('域名拒绝转入更新失败,transferId:' . $transInfo['TransferInId'] . ',right:7', 'domain', 'transferin');
		}
		$this->delTransferRedis($transInfo['DomainName']);
		$domain = $transInfo['DomainName'];
		$enameId = $transInfo['EnameId'];
		$orderId = $transInfo['OrderId'];
		return $this->cancelOrder($enameId, $orderId, $transInfo, '域名转入clientRejected状态自动退款');
	}

	/**
	 * 域名转入失败
	 *
	 * @param array $transInfo
	 */
	public function domainTransferFail($transInfo, $authErr = FALSE)
	{
		$opTime = strtotime($transInfo['UpdateTime']) ? strtotime($transInfo['UpdateTime']) : strtotime(
			$transInfo['CreateTime']);
		if($authErr == true || time() - $opTime > 691200) // 如果大于8天 验证密码还是失败的
		                                                  // 直接退款处理
		{
			$domain = $transInfo['DomainName'];
			$enameId = $transInfo['EnameId'];
			$upInfo = $this->setTransferInfo(array('TransferInId' => $transInfo['TransferInId']), 
				array('TransferStatus' => 7, 'UpdateTime' => date('Y-m-d H:i:s')));
			if(! $upInfo)
			{
				\core\Log::write('域名转入更新失败,transferId:' . $transInfo['TransferInId'] . ',right:7', 'domain', 
					'transferin');
			}
			$this->delTransferRedis($transInfo['DomainName']);
			$this->cancelOrder($enameId, $transInfo['OrderId'], $transInfo, $authErr ? '转入密码错误' : '时间超过8天，接口返回对象不存在');
			return 1;
		}
		return 2;
	}

	/**
	 * 获取刚添加的转入记录
	 */
	public function getTransferInfoByDomainStatus($domain, $status)
	{
		$info = $this->mod->getTransferInfo(
			array('DomainName' => $domain, 'TransferStatus' => $status, 'EnameId' => $this->enameId, 
					'order' => 'TransferInId desc', 'limit' => 1));
		if($info)
		{
			return $info;
		}
		throw new \Exception("无效的域名转入记录");
	}

	/**
	 * 检测域名是否可以申请转入
	 *
	 * @param array $domains
	 * @param ProductCartLib $productCartLib
	 * @param DomainManageLib $domainManageLib
	 * @return void
	 * @author zougc
	 * @version 2012-04-06
	 */
	public function checkDomainAllowTransferIn($domains)
	{
		foreach($domains as $key => $domainAndPassword)
		{
			$domain = strtolower($domainAndPassword['domain']);
			// 若是黑名单域名禁止转入
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/data.ini', 'rpc');
			$client = new \Yar_Client($conf->manageother . '/BlackList');
			$rpcResult = $client->domainInBlackList($domain);
			if(isset($rpcResult[0]['flag']) && $rpcResult[0]['flag'])
			{
				throw new \Exception($domainAndPassword['domain'] . ' 该域名禁止转入，请联系客服', 320100);
			}
			//取消限制
// 			// 中文.cc 中文.biz 中文.tv限制转入
// 			if(\lib\manage\common\DomainFunLib::isNewDomain($domain) &&
// 				 \lib\manage\common\DomainFunLib::isCnDomain($domain))
// 			{
// 				throw new \Exception($domain . '暂不支持转入');
// 			}
			if(\lib\manage\common\DomainFunLib::isChinaDomain($domain) &&
				 ! \lib\manage\common\DomainFunLib::isWangluoDomain($domain)) // CN域名维护临时关闭2014-05-10
			{
				\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck(); // CN域名维护临时关闭2014-05-10
			}
			$password = $domainAndPassword['password'];
			\lib\manage\common\DomainOpenLib::checkOpen('transfer', $domain);
			$this->checkIsOkToAdd($domain);
			//$isChinaDomain = \lib\manage\common\DomainFunLib::isChinaDomain($domain);
			//if($isChinaDomain || \lib\manage\common\DomainFunLib::isInterDomain($domain) ||
			//	 \lib\manage\common\DomainFunLib::isNewDomain($domain))
			//{
			//	$this->checkDomainIsTransferProhibited($domain, $isChinaDomain); // 验证域名转移状态
			//}
		}
	}

	/**
	 * 查询域名WHOIS信息 的域名状态是否是禁止转移
	 *
	 * @param string $domainName
	 * @param int $transferId
	 * @throws Exception
	 * @author hush
	 */
	public function checkDomainIsTransferProhibited($domainName, $isChinaDomain)
	{
		$whois = new \interfaces\manage\Whois();
		$info = $whois->getWhoisHasMail($domainName);
		if(! $info)
		{
			throw new \Exception($domainName . '域名信息查找失败，请确认域名后再重试!', 320014);
		}
		if(empty($info['Status']) or empty($info['RegistrationDate']) or empty($info['ExpirationDate']))
		{
			throw new \Exception($domainName . '域名信息查找失败，请确认域名后再重试!', 320014);
		}
		// 状态判断
		$status = is_array($info['Status']) ? implode(",", $info['Status']) : $info['Status'];
		if(preg_match("/clientTransferProhibited|serverTransferProhibited/i", $status))
		{
			throw new \Exception(
				$domainName . '域名状态为禁止转移状态：clientTransferProhibited或serverTransferProhibited!,请联系域名注册商更改状态!', 320015);
		}
		$RegistrationDate = $info['RegistrationDate'];
		$ExpirationDate = $info['ExpirationDate'];
		if(strtotime("-61 day") < strtotime($RegistrationDate))
		{
			// 注册时间未满60天
			throw new \Exception($domainName . '域名注册时间未满60天!无法转入!', 320016);
		}
		if($isChinaDomain and strtotime("+15 day") >= strtotime($ExpirationDate))
		{
			// cn 到期前15天内，包括15天。不许转移
			throw new \Exception($domainName . '国内域名到期前15天内包括15天无法转入!', 320017);
		}
		if(\lib\manage\common\DomainFunLib::getDomainClass($domainName) == 'WANG' and
			 strtotime("+15 day") >= strtotime($ExpirationDate))
		{
			// wang 到期前15天内，包括15天。不许转移
			throw new \Exception($domainName . '域名到期前15天内包括15天无法转入!');
		}
		if(\lib\manage\common\DomainFunLib::getDomainClass($domainName) == 'TOP' and
			 strtotime("+15 day") >= strtotime($ExpirationDate))
		{
			// top 到期前15天内，包括15天。不许转移
			throw new \Exception($domainName . '域名到期前15天内包括15天无法转入!');
		}
		return true;
	}

	/**
	 * 设置域名转入成功
	 * 1、是否已经入库
	 * 2、注册局信息
	 * 3、域名入库
	 * 4、模板过户
	 * 5、国际域名添加第一版whois信息
	 * 6、sedo卖家确认
	 * 7、发送站内信
	 *
	 * @param array $transInfo 转入信息
	 * @param array $regisTransInfo 注册局转入信息
	 * @return int
	 */
	public function domainTransferSuccess($transInfo, $regisTransInfo)
	{
		$registrarId = $regisTransInfo['in'];
		$domainMod = new \models\manage\domain\DomainsMod();
		$domainInfo = $domainMod->getDomainInfo(array('DomainName' => $transInfo['DomainName']), 'DomainId');
		$domain = $transInfo['DomainName'];
		$enameId = $transInfo['EnameId'];
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'transferin');
		$tempLib = new \lib\manage\domain\TemplateLib();
		if($domainInfo) // 已经入库
		{
			DomainLogsLib::addDomainService($domain, 
				array('memo' => 'interface_transferin', 'c' => 'domain in datatbase'), 28, $enameId);
			if($enameId == $conf->preregistereduserid)
			{
				$upDomain = $domainMod->upDomainInfo(array('DomainId' => $domainInfo['DomainId']), 
					array('RegistrarId' => $registrarId));
				if(! $upDomain)
				{
					\core\Log::write($domain . 'update_domain_failed:rightrid:' . $registrarId, 'domain', 'transferin');
				}
				$this->setTransferStatusDone($transInfo, $transInfo['Whois'], $domain, $regisTransInfo['out']);
				$from = $this->addTransferRedis($domain);
				$this->msgCenterDone($transInfo['DomainName'],$transInfo['IsLock'],$from);
				return 1;
			}
			// 确认订单和gd审核
			$this->domainTranferTrail($transInfo, $regisTransInfo);
			// 修改域名密码和域名状态
			$this->changeTransferInDomainStatusAndPwd($enameId, $domain, $registrarId);
			$from = $this->addTransferRedis($domain);
			$this->msgCenterDone($transInfo['DomainName'],$transInfo['IsLock'],$from);
			return 1;
		}
		// 入库信息
		DomainLogsLib::addDomainService($domain, 
			array('memo' => 'domain_start_in_database', 'transInfo' => $transInfo, 'reigsTrans' => $regisTransInfo), 28, 
			$enameId);
		$epp = new \lib\manage\domain\DomainEppLib($enameId);
		$domainRegInfo = $epp->getDomainRegInfo($domain, $registrarId, FALSE); // 域名注册局信息
		DomainLogsLib::addDomainService($domain, array('memo' => 'query_dn_regisinfo', 'info' => $domainRegInfo), 28, 
			$enameId);
		if(! $domainRegInfo || ! is_array($domainRegInfo))
		{
			return 2;
		}
		$templateInfo = $tempLib->getTempInfo($transInfo['TemplateId']);
		$templateInfo = $this->checkEmptyTemplate($transInfo['TransferInId'], $templateInfo, $enameId);
		// 入库start_baseTable
		if(! $domainMod->getDomainInfo(array('DomainName' => $transInfo['DomainName']), 'DomainId'))
		{
			$addDomainInfo = $this->transferInDb($transInfo, $domainRegInfo, $regisTransInfo, $templateInfo); // 5025
			if(! $addDomainInfo)
			{
				//添加警报 域名转入成功，入库失败
				$secureWarningMod = new \models\manage\member\SecureWarningMod();
				$addSecRes = $secureWarningMod->addInfo(array('BusinessType' => 7, 'enameid' => $transInfo['EnameId'], 'domain' => $transInfo['DomainName'], 'IP' => $transInfo['SubmitIp'], 
						'CreateDate' => strtotime($transInfo['CreateTime']), 'Content' => '域名转入成功，入库失败', 'Priority' => 4));
				if(!$addSecRes)
				{
					\core\Log::write($domain . '-增加安全警报失败-域名转入成功，入库失败' , 'domain', 'transferin');
				}
				return 3;
			}
			// 确认订单和gd审核
			$this->domainTranferTrail($transInfo, $regisTransInfo);
			$from=$this->addTransferRedis($domain);
			$tempLib->setTempDomainCount($transInfo['TemplateId']);
			$this->msgCenterDone($domain,$transInfo['IsLock'],$from);
			$data = array('domain' => $domain, 'templateId' => $this->checkTemplateIdWhite($templateInfo['TemplateId'], $enameId, $transInfo['TransferInId'], $transInfo['CreateTime']), 'oldTemplateId' => 0, 
					'registrarId' => $registrarId, 'newTemplateName' => $templateInfo['TempUserName'], 
					'tempType' => isset($templateInfo['TemplateType']) ? $templateInfo['TemplateType'] : 0, 
					'oldTemplateName' => '域名转入', 'enameId' => $enameId);
			try
			{
				$queueLib = new \logic\manage\newqueue\QueueLogic();
				$result = $queueLib->addQueueTask( 
					array('Function' => 'template_push', 'EnameId' => $enameId, 'Data' => array($data), 'Priority' => 5));
			}
			catch(\Exception $e)
			{
				DomainLogsLib::addDomainService($domain, 
					array('memo' => 'trans_in_temp_push', 'param' => $data, 'res' => $e->getMessage()), 35);
			}
			$this->addFirstWhois($domain, $templateInfo);
			if(\lib\manage\common\DomainFunLib::getDomainClass($domain) == 'PW') // pw域名转入成功后续费一年
			{
				$interface = new \interfaces\manage\Domains();
				$expDate = empty($domainRegInfo['expireDate']) ? $regisTransInfo['expireDate'] : $domainRegInfo['expireDate'];
				$renewData = array('domain' => $domain, 'year' => 1, 'expDate' => $expDate, 'enameId' => $enameId);
				$renew = $interface->domainRenew($renewData);
				if(! $renew)
				{
					DomainLogsLib::addDomainService($domain, 
						array('memo' => 'transfer_pw_renew', 'c' => 'pw域名转入续费一年,续费失败', 'expDate' => $expDate), 28, 
						$enameId);
				}
			}
			$this->sedoSellerConfirm($domain, $enameId);
			// 修改域名密码和域名状态
			$this->changeTransferInDomainStatusAndPwd($enameId, $domain, $registrarId);
		}
		else
		{
			DomainLogsLib::addDomainService($domain, array('memo' => 'transfer_success', 'c' => '域名入库重复检测---已入库'), 28, 
				$enameId);
		}
		return 1;
	}

	/**
	 * 转入后续处理
	 * 1.先确认订单
	 * 2.gd审核
	 */
	private function domainTranferTrail($transInfo, $regisTransInfo)
	{
		$domain = $transInfo['DomainName'];
		$enameId = $transInfo['EnameId'];
		// 确认订单
		if($transInfo['OrderId'])
		{
			$orderLib = new \interfaces\manage\Finance();
			$confirmData = array('enameId' => $enameId, 'orderId' => $transInfo['OrderId']);
			$result = $orderLib->confirmOrder((object)$confirmData);
			// 确认订单成功后入库
			if($result && \lib\manage\common\DomainFunLib::isTopDomainType($domain) == TRUE)
			{
				$topLib = new \lib\manage\domain\DomainTopLib();
				$topLib->topDomainDone(2, $domain, $enameId); // 消息中心 添加珍品记录
			}
			if(!$result)
			{
				//添加警报 域名转入成功并入库成功，订单未确认
				$secureWarningMod = new \models\manage\member\SecureWarningMod();
				$addSecRes = $secureWarningMod->addInfo(array('BusinessType' => 7, 'enameid' => $enameId, 'domain' => $transInfo['DomainName'], 'IP' => $transInfo['SubmitIp'],
						'CreateDate' => strtotime($transInfo['CreateTime']), 'Content' => '域名转入成功并入库成功，订单未确认', 'Priority' => 4));
				if(!$addSecRes)
				{
					\core\Log::write($domain . '-增加安全警报失败-域名转入成功并入库成功，订单未确认' , 'domain', 'transferin');
				}
			}
			$msg = '域名入库完成，确认订单' . ($result === true ? '成功' : '失败');
			DomainLogsLib::addDomainService($domain, 
				array('memo' => 'confirm_order', 'c' => $msg, 'order' => $transInfo['OrderId'], 'r' => $result), 28, 
				$enameId);
		}
		else
		{
			DomainLogsLib::addDomainService($domain, 
				array('memo' => 'transfer_success', 'c' => '域名入库完成', 'order' => '订单不存在'), 28, $enameId);
		}
		// gd 审核
		$this->setTransferStatusDone($transInfo, $transInfo['Whois'], $domain, $regisTransInfo['out']);
	}

	/**
	 * 更改域名状态和密码
	 *
	 * @param int $enameId
	 * @param string $domain
	 * @param int $registrarId
	 */
	private function changeTransferInDomainStatusAndPwd($enameId, $domain, $registrarId)
	{
		try 
		{
			$queueTaskLib = new \lib\manage\newqueue\QueueTaskLib();
			$queueData = array('Function' => 'tranfer_in_server_status', 'Priority' => 3, 'EnameId' => $enameId, 'Hidden' => 1, 'Data' => array(array('domain' => $domain, 'registrarId' => $registrarId)));
			if(!$queueTaskLib->addQueue($queueData))
			{
				\core\Log::write("domain:{$domain},registrarId:{$registrarId}", 'cronmanage/transferin', 'TransferInAddDomainStatusError');
			}
			$queueData = array('Function' => 'transfer_in_change_pwd', 'Priority' => 3, 'EnameId' => $enameId, 'Hidden' => 1, 'Data' => array(array('domain' => $domain, 'registrarId' => $registrarId)));
			if(!$queueTaskLib->addQueue($queueData))
			{
				\core\Log::write("domain:{$domain},registrarId:{$registrarId}", 'cronmanage/transferin', 'TransferInChangePwdError');
			}
		}
		catch (\Exception $e)
		{
			\core\Log::write("domain:{$domain},registrarId:{$registrarId},{$e->getMessage()},{$e->getCode()}", 'cronmanage/transferin', 'transferinError');
		}
	}

	/**
	 * sedo卖家确认 (seller enameId = 10007 调用)
	 */
	public function sedoSellerConfirm($domain, $enameId)
	{
		\core\Log::write($domain . "," . $enameId, 'domain', 'transferinSedo10007');
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'transferin');
		if($enameId == $conf->sedoid)
		{
			$key = $conf->sedoKey;
			$data = array("times" => time(), 'domain' => $domain, 'seller' => $enameId);
			ksort($data);
			$keystr = '';
			$param = '';
			foreach($data as $k => $v)
			{
				$keystr .= $v;
				$param .= '&' . $k . '=' . $v;
			}
			$sid = md5($keystr . $key);
			$url = $conf->sedoConfirmUlr . "?sid=" . $sid . $param;
			$context = stream_context_create(array('http' => array('timeout' => 30)));
			$content = @file_get_contents($url, null, $context);
			$result = @json_decode($content);
			if(! is_object($result) || $result->code != 1000)
			{
				DomainLogsLib::addDomainService($domain, array('url' => $url, 'appresult' => $result), 28, $enameId);
			}
		}
	}

	/**
	 * 国际域名添加第一版whois信息
	 */
	public function addFirstWhois($domain, $templateInfo)
	{
		if(FALSE == $templateInfo)
		{
			\core\Log::write('域名转入成功后添加第一版whois 空模板', 'domain', 'transferin');
			return FALSE;
		}
		if(\lib\manage\common\DomainFunLib::isInterDomain($domain))
		{
			$templateInfo['DomainName'] = $domain;
			$templateInfo['CreateTime'] = $templateInfo['UpdateTime'] = date('Y-m-d H:i:s');
			unset($templateInfo['TemplateId']);
			unset($templateInfo['RegistrarId']);
			unset($templateInfo['EnameId']);
			unset($templateInfo['Status']);
			unset($templateInfo['TempUserName']);
			unset($templateInfo['TemplateType']);
			unset($templateInfo['CnStatus']);
			unset($templateInfo['CdnStatus']);
			unset($templateInfo['LinkCount']);
			unset($templateInfo['IsShow']);
			unset($templateInfo['IsDefault']);
			unset($templateInfo['CnIdn']);
			unset($templateInfo['UploadCnnic']);
			$mod = new \models\manage\domain\DomainFirstWhoisMod();
			if(! $mod->addFirstWhois($templateInfo))
			{
				DomainLogsLib::addDomainService($domain, 
					array('memo' => 'transfer_add_first_whois', 'c' => '域名转入成功,添加第一版whois失败'), 28);
			}
		}
	}

	/**
	 * 转入入库相关
	 * 1、入库域名基本表e_domains
	 * 2、修改转入表信息
	 * 3、注册局修改域名状态
	 * 4、添加操作日志
	 * 5、修改转移密码
	 * 6、是IIDNS 的话添加IIDNS
	 *
	 * @param array $transferInfo
	 * @param array $templateInfo 模板信息
	 * @param int $registrarId
	 */
	public function transferInDb($transferInfo, $regisInfo, $regisTransInfo, $templateInfo)
	{
		try
		{
			$registrarId = $regisTransInfo['in'];
			$domain = $transferInfo['DomainName'];
			$enameId = $transferInfo['EnameId'];
			$registModule = new \lib\manage\domain\DomainRegistLib($enameId);
			$expireDate = empty($regisInfo['expireDate']) ? $regisTransInfo['expireDate'] : $regisInfo['expireDate'];
			$dnsType = $transferInfo['DnsStatus'] == 1 ? 0 : 3;
			$result = $registModule->domainInDbBaseTable($domain, $registrarId, $regisInfo['createDate'], $expireDate, 
				$regisInfo['createDate'], $enameId, $templateInfo['TempUserName'], $templateInfo['TemplateId'], 
				$transferInfo['ProductType'], $dnsType, '3,4', 0);
			$regisOut = ! empty($regisTransInfo['out']) ? $regisTransInfo['out'] : '';
			if($result && is_numeric($result)) // 扩展
			{
				// 添加ext数据
				$dns = '';
				if(! empty($regisInfo['DNS']))
				{
					$dns = is_array($regisInfo['DNS']) ? implode(',', $regisInfo['DNS']) : $regisInfo['DNS'];
				}
				$dns = isset($transferInfo['DnsStatus']) && $transferInfo['DnsStatus'] == 2 ? ($dns ? strtolower($dns) : '') : '';
				$tempType = isset($templateInfo['TemplateType']) ? $templateInfo['TemplateType'] : 0;
				if(is_null($dns))
				{
					DomainLogsLib::addDomainService($domain, 
						array('dn' => $domain, 'memo' => 'dns_is_null', 'reg' => $regisInfo, 'trans' => $regisTransInfo), 
						28, $enameId);
					$dns = '';
				}
				$extInfo = array('DomainId' => $result, 'EnameId' => $enameId, 'Tooltip' => 1, 'TooltipWay' => '1,2,3', 
						'Dns' => $dns, 'DomainFrom' => 2, 'DomainIcp' => '', 'TemplateType' => $tempType);
				$extAddInfo = $this->addDomainExt($result, $extInfo); // ok
				if(! $extAddInfo)
				{
					DomainLogsLib::addDomainService($domain, 
						array('memo' => 'transInDb_addext_fail', 'params' => $extInfo), 28, $enameId);
				}
				if($transferInfo['DnsStatus'] == 1) // modify iidns
				{
					$this->setDns($domain, $enameId, $registrarId, 0, $result, array(), FALSE);
				}
				return true;
			}
			return false;
		}
		catch(\Exception $e)
		{
			DomainLogsLib::addDomainService($domain, 
				array('memo' => 'domain_transferindb_fail', 'e' => $e->getMessage()), 28, $transferInfo['EnameId']);
			return FALSE;
		}
	}

	/**
	 * 通过转入id获取转入域名列表
	 */
	public function getTransferInfoByIdEnameId($id, $fields = "*", $throw = false)
	{
		$info = $this->mod->getTransferInByIdEnameId($id, $this->enameId, $fields);
		if(! $info)
		{
			if($throw)
			{
				DomainLogsLib::addDomainService($id, $id . ' 查询转入记录失败', 28, $this->enameId);
				throw new \Exception("查询转入记录失败,请稍后重试", 320007);
			}
		}
		return $info;
	}

	/**
	 * 检查转入域名是否被更改过
	 */
	public function checkDomain($newdomain, $olddomain)
	{
		if($newdomain != $olddomain)
		{
			throw new \Exception('转入域名不能更改', 320013);
		}
		return true;
	}

	/**
	 * 更新转入信息
	 */
	public function setTransferInfo($where, $set, $domain = false)
	{
		$domain = $domain ? $domain : 'transfer.in';
		DomainLogsLib::addDomainService($domain, array('memo' => 'update database', 'where' => $where, 'set' => $set), 
			11);
		$return = $this->mod->upTransferInfo($where, $set);
		if(! $return)
		{
			DomainLogsLib::addDomainService($domain, 
				array('memo' => 'update database error', 'where' => $where, 'right set' => $set), 11);
		}
		return $return;
	}

	/**
	 * 获取转入列表
	 */
	public function getTransferList($params, $fields = '*')
	{
		return $this->mod->getTransferInfo($params, $fields, FALSE);
	}

	/**
	 * 域名转入失败退款
	 */
	public function cancelOrder($enameId, $orderId, $transInfo, $cmsg)
	{
		if(! $orderId)
		{
			return FALSE;
		}
		DomainLogsLib::addDomainService($transInfo['DomainName'], 
			array('memo' => 'apprejected_transfer', 'c' => $cmsg, 'orderId' => $orderId), 29, $enameId);
		$orderLib = new \interfaces\manage\Finance();
		$cancel = array('enameId' => $enameId, 'orderId' => $orderId);
		$result = $orderLib->cancelOrder((object)$cancel);
		DomainLogsLib::addDomainService($transInfo['DomainName'], 
			array('memo' => 'appconfirm_order', 'order' => $orderId, 'r' => $result), 28, $enameId);
	}

	/**
	 * 转入成功设置dns
	 */
	public function setDns($domain, $enameId, $registrarId, $dnsType, $domainId, $dns = array(), $throw = FALSE)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'iidns');
		if($dnsType == 0)
		{
			$dns = $conf->iidns->toArray();
		}
		$dnsData = array('domain' => $domain, 'registrarID' => $registrarId, 'dnsType' => $dnsType, 
				'domainId' => $domainId, 'enameId' => $enameId, 'dns' => $dns);
		$domainDns = new \interfaces\manage\Domains();
		$setDnsInfo = $domainDns->setDomainDns($dnsData);
		if(! $setDnsInfo)
		{
			if(FALSE == $throw)
			{
				\core\Log::write('app更新dns失败:' . json_encode($dnsData), 'domain', 'transferin');
				return FALSE;
			}
			$errCode = ($dnsType == 0) ? 8 : 6;
			$errMsg = $conf->errMsg->toArray();
			throw new \Exception($errMsg[$errCode]);
		}
	}

	/**
	 * 域名转入成功通知消息到消息中心和监控中心
	 */
	public function msgCenterDone($domain, $islock,$from=FALSE)
	{
		if(!$from)
		{
			$from = 1;
			if(\common\Common::getRequestUser() == 'api')
			{
				$from = 2;
			}
		}
		$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'transfer_in_success')); 
		$amqp->sendMq(
			array('from'=>$from,'uid' => $this->enameId, 'dn' => $domain, 'time' => time(),'isLock'=>intval($islock) ,'ip' => \common\Common::getRequestIp()));
	}

	/**
	 * 域名扩展表添加或者修改记录
	 */
	public function addDomainExt($domainId, $domainext)
	{
		$extMod = new \models\manage\domain\DomainExtMod();
		$where = array('DomainId' => $domainId);
		$extInfo = $extMod->getOneDomainExt($where);
		if($extInfo)
		{
			unset($domainext['DomainId']);
			$upExt = $extMod->setDomainExt($where, $domainext);
			if(! $upExt)
			{
				\core\Log::write('update domainext failed,msg:' . json_encode($domainext) . ',where:' . $domainId, 
					'domain', 'transferin');
				return false;
			}
			return true;
		}
		$extAddInfo = $extMod->addDomainExt($domainext);
		if(! $extAddInfo)
		{
			\core\Log::write('add domainext failed,msg:' . json_encode($domainext), 'domain', 'transferin');
			return false;
		}
		return true;
	}

	public function addTransferRedis($domain)
	{
		try
		{
			$redisKeyHash = 'appdomaintransferhash_' . date('Y-m-d');
			$redisKey = 'appdomaintransfer_' . date('Y-m-d');
			$redis = new \lib\manage\common\RedisLib(false);
			if($redis->getHashData($redisKeyHash, $domain))
			{
				if(FALSE == $redis->incrData($redisKey))
				{
					\core\Log::write($redisKey . ",addfailed,msg,2,$domain", 'domain', 'domaincountfailed');
				}
				return 2;//app转入flag
			}
			return 1;//PC转入flag
		}
		catch(\Exception $e)
		{
			\core\Log::write("$redisKeyHash,redis error,msg,2,$domain", "domain", "domaincountfailed");
		}
		return 1;
	}

	public function delTransferRedis($domain)
	{
		try
		{
			$redisKeyHash = 'appdomaintransferhash_' . date('Y-m-d');
			$redis = new \lib\manage\common\RedisLib(false);
			if($redis->getHashData($redisKeyHash, $domain))
			{
				if(FALSE == $redis->delHashData($redisKeyHash, $domain))
				{
					\core\Log::write($redisKeyHash . ",deltransferredis,msg,2,$domain", 'domain', 'domaincountfailed');
				}
			}
		}
		catch(\Exception $e)
		{
			\core\Log::write("$redisKeyHash,redis error,msg,2,$domain", "domain", "domaincountfailed");
		}
	}

	/**
	 * 转入成功处理信息
	 */
	public function setTransferStatusDone($tranferInfo, $whois, $domain, $regid)
	{
		$successStatus = 8; // 转入成功
		$transferId = $tranferInfo['TransferInId'];
		$whoiseLib = new \common\WhoisLib();
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'ePlusTransferIn');
		$staticEnameId = $conf->enameId;
		$special = false;
		if($staticEnameId == $tranferInfo['EnameId'])
		{
			$special = true;
		}
		$registerFlag = $whoiseLib->registerByWhoisInfo($whois);
		if($special ==false && $registerFlag)
		{
			$tipMsg = ($registerFlag == 1) ? 'gdapp域名' : (($registerFlag == 2) ? 'enomapp域名' : 'other域名');
			if($this->checkEnameIdIdentity($whois, $domain, $tranferInfo['EnameId'], $tipMsg))
			{
				$note = DomainLogsLib::addDomainServiceExt($domain, '系统判断：whois姓名与ID一致，且身份认证通过。', 2, 21, $tranferInfo['EnameId']);
				if(!$note)
				{
					\core\Log::write($tipMsg . $domain . 'whois姓名与ID一致，且身份认证通过,添加备注失败', 'domaintranferin');
				}
			}
			else
			{
				$successStatus = ($registerFlag == 1) ? 9 : (($registerFlag == 2) ? 10 : 11); // 9=》gd审核
				                                                                              // 10=》enom待审核
				                                                                              // 11=》其他待审核
				$domainmod = new \models\manage\domain\DomainsMod();
				$upDomain = $domainmod->upDomainInfo(array('DomainName' => $domain), array('DomainMyStatus' => 14));
				if($upDomain)
				{
					$note = DomainLogsLib::addDomainServiceExt($domain, $tipMsg . '设置域名为交易锁定 ', 2, 21, $tranferInfo['EnameId']);
					if(! $note)
					{
						\core\Log::write($tipMsg . $domain . '域名入库成功,添加备注失败', 'domaintranferin');
					}
					// 添加交易锁定 成功后发送邮件
					if($whoidEmail = $this->getEmailFromWhoisInfo($whois))
					{
						DomainLogsLib::addDomainService($domain, array('memo' => 'get whois mail:' . $whoidEmail), 28, $tranferInfo['EnameId']);
						try
						{
							$queueLogic = new \logic\manage\newqueue\QueueLogic();
							$mailData = array('Function' => 'sendmail', 'EnameId' => $tranferInfo['EnameId'], 'TemplateName' => 'gdTransferInCheckFailure', 'Target' => $whoidEmail, 'Data' => array('domainName' => $domain, 'enameId' => $tranferInfo['EnameId']), 'Priority' => 5);
							$sendResult = $queueLogic->addQueueNormal($mailData);
						}
						catch (\Exception $e)
						{
							$sendResult = false;
						}
						if(!$sendResult)
						{
							\core\Log::write($tipMsg . $domain . '设置域名为交易锁定 成功，邮件' . $whoidEmail . '发送失败', 'domaintranferin');
						}
						else
						{
							$note = DomainLogsLib::addDomainServiceExt($domain, '资料不一致，已发邮件通知用户提供材料', 2, 21,	$tranferInfo['EnameId']);
						}
					}
					else
					{
						\core\Log::write($tipMsg . $domain . '获取whois邮件失败', 'domaintranferin');
					}
				}
				else
				{
					\core\Log::write($tipMsg . $domain . '入库成功,更改锁定状态失败', 'domaintranferin');
				}
			}
		}
		$setTransfer = $this->setTransferInfo(
			array('DomainName' => $domain, 'TransferStatus' => 6, 'TransferInId' => $transferId), 
			array('TransferStatus' => $successStatus, 'SuccessTime' => date("Y-m-d H:i:s"), 'Registrar' => $regid));
		if(! $setTransfer)
		{
			\core\Log::write('域名' . $domain . '入库成功，更改转入状态失败,' . $successStatus, 'domaintranferin');
		}
	}

	/**
	 * 检查用户的身份认证
	 */
	private function checkEnameIdIdentity($whois, $domain, $enameId, $tipMsg = 'gdappdomain')
	{
		// 查询用户所有审核通过的身份认证
		$idetityMod = new \models\manage\verify\IdentityVerifyMod();
		$identityList = $idetityMod->getVerifyInfo(array('Type' => 1, 'EnameId' => $enameId, 'VerifyStatus' => 2));
		if(! $identityList)
		{
			\core\Log::write($tipMsg . $domain . '查询用户' . $enameId . '身份认证信息失败', 'domaintranferin');
			return false;
		}
		
		// 匹配whois的联系人信息
		if(! $whoisName = $this->getRegistrantNameFromWhoisInfo($whois))
		{
			\core\Log::write($tipMsg . $domain . '匹配whois联系人失败', 'domaintranferin');
			return false;
		}
		
		// 去掉空格
		$whoisName = strtolower(str_replace(' ', '', $whoisName));
		// 将中文转化为拼音
		$pinyinNameArr = $this->getPinyinNames($identityList);
		
		DomainLogsLib::addDomainService($domain, 
			array('memo' => 'dc get whois name:' . $whoisName, 
					'c' => 'get identity check success:' . implode(',', $pinyinNameArr)), 28, $enameId);
		return in_array($whoisName, $pinyinNameArr);
	}

	/**
	 * 获取中文转英文名字
	 *
	 * @param array $identityList
	 * @return array
	 */
	private function getPinyinNames($identityList)
	{
		$result = array();
		foreach($identityList as $value)
		{
			$result[] = $value['Name'];
			preg_match_all('/./u', $value['Name'], $chineseNameArr);
			$chineseNameArr = $chineseNameArr[0];
			switch(count($chineseNameArr))
			{
				case 2:
					$result[] = $chineseNameArr[1] . $chineseNameArr[0];
					break;
				case 3:
					$result[] = $chineseNameArr[1] . $chineseNameArr[2] . $chineseNameArr[0];
					$result[] = $chineseNameArr[2] . $chineseNameArr[0] . $chineseNameArr[1];
					break;
				case 4:
					$result[] = $chineseNameArr[2] . $chineseNameArr[3] . $chineseNameArr[0] . $chineseNameArr[1];
					break;
			}
		}
		$pinyin = new \common\chtopy\PinYin();
		foreach($result as $key => $value)
		{
			$result[] = strtolower($pinyin->toPinyin($value));
		}
		return $result;
	}

	/**
	 * 从whois中匹配获取注册者名称
	 *
	 * @return string
	 */
	private function getRegistrantNameFromWhoisInfo($whois)
	{
		$RegistrantName = '';
		$regs = NUll;
		if(preg_match_all("/Registr[ant]*[\s]*[Contact]*[\s]*Name:[\s]*(.*?)(<br[\s\/]*>|[\r\t\n\f]+)+/i", $whois, 
			$regs))
		{
			$RegistrantName = implode(',', $regs['1']);
		}
		return $RegistrantName;
	}

	/**
	 * 从whois中匹配获取whois邮箱
	 *
	 * @return string
	 */
	private function getEmailFromWhoisInfo($whois)
	{
		$Email = '';
		
		// 优先获取registrant email
		if(preg_match("/Registrant[\s]+E[\-]?mail[\s]?:[\s]*([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $whois, $EmailInfo))
		{
			if(! empty($EmailInfo['1']))
			{
				return $EmailInfo['1'];
			}
		}
		
		// 优先获取admin email
		if(preg_match("/(Admin|Administrative)+[\s]+E[\-]?mail[\s]?:[\s]*([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $whois, 
			$EmailInfo))
		{
			if(! empty($EmailInfo['2']))
			{
				return $EmailInfo['2'];
			}
		}
		
		// 优先获取Email Address
		if(preg_match("/E[\-]?mail[\s]?Address:[\s]*([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $whois, $EmailInfo))
		{
			if(! empty($EmailInfo['1']))
			{
				return $EmailInfo['1'];
			}
		}
		
		if(preg_match("/([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $whois, $EmailInfo))
		{
			$Email = $EmailInfo['1'];
		}
		
		if($Email == 'support@propersupport.com')
		{
			if(preg_match("/[Registrant:](.*)[\(]{1}([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $whois, $EmailInfo))
			{
				$Email = $EmailInfo['2'];
			}
		}
		
		if(stripos($Email, 'abuse@') !== FALSE)
		{
			$Email = '';
		}
		return $Email;
	}

	/**
	 * 提交国际域名FOA 发送邮件
	 *
	 * @param string $domain
	 * @param string $mailCode
	 * @param int $transferId
	 * @param string $submitTime
	 */
	public function submitInternetDomain($domain, $mailCode, $transferId, $enameId, $submitTime, 
		$whoisAndEmail = array())
	{
		if(empty($whoisAndEmail))
		{
			$whoisAndEmail = $this->checkDomainEmailByWhois($domain, $transferId);
		}
		$info = $this->getTransferInfoByIdEnameId($transferId);
		if(empty($info))
		{
			\core\Log::write($domain . '|获取转入信息失败', 'domain', 'transferStatus');
			return FALSE;
		}
		if($info['TransferStatus'] != - 1)
		{
			\core\Log::write($domain . '|状态!-1放弃执行|' . $info['TransferStatus'], 'domain', 'transferStatus');
			return NULL;
		}
		if(! $whoisAndEmail)
		{
			DomainLogsLib::addDomainService($domain, array('memo' => 'get_email_error'), 11);
			$this->setTransferInfo(array('TransferInId' => $transferId), 
				array('TransferStatus' => - 3, 'UpdateTime' => date('Y-m-d H:i:s')), $domain);
			\core\Log::write($domain . '|获取邮件失败|-3', 'domain', 'transferStatus');
			return FALSE;
		}
		$sendCode = rand(1000, 9999);
		$email = $whoisAndEmail['email'];
		$whois = $whoisAndEmail['whois'];
		$submitTime = date("Y-m-d", strtotime($submitTime));
		
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'transferin');
		$url = $conf->siteUrl . '/transfermail/index/' . $mailCode;
		$data = array('url' => $url, 'domainName' => $domain, 'sendCode' => $sendCode, 'name' => $enameId, 
				'submitTime' => $submitTime, 'whois' => $whois, 'foa' => TRUE);
		
		$queue = new \interfaces\manage\Queue();
		if($queue->sendMail($conf->templateId, $email, $data, $enameId, 0, 'sendmail', 5))
		{
			$this->setTransferInfo(array('TransferInId' => $transferId), 
				array('TransferStatus' => 2, 'UpdateTime' => date('Y-m-d H:i:s'), 'WhoIsEmail' => $email), $domain);
			\core\Log::write($domain . '|等待邮件确认|2', 'domain', 'transferStatus');
			return TRUE;
		}
		return FALSE;
	}

	/**
	 * 申请CN域名和WEBCC域名的转入
	 *
	 * @param string $domain
	 * @param int $year
	 * @param int $transferId
	 * @param string $password
	 * @param int $enameId
	 * @throws Exception
	 * @return boolean
	 * @author zougc
	 */
	public function submitChinaDomainAndWebCC($domain, $year, $transferId, $password, $enameId, $regid = FALSE)
	{
		$returnInfo = $this->submitDomainTransferIn($domain, $password, $year, $regid);
		if($returnInfo['resultCode'] == 5000)
		{
			$this->setTransferInfo(array('TransferInId' => $transferId), 
				array('TransferStatus' => 6, 'UpdateTime' => date('Y-m-d H:i:s')), $domain);
			return TRUE;
		}
		$intCode = $this->formatDomainTransferInfo($returnInfo);
		$this->setTransferInfo(array('TransferInId' => $transferId), 
			array('TransferStatus' => $intCode == 1 ? 1 : - 2, 'UpdateTime' => date('Y-m-d H:i:s')), $domain);
		if($intCode == 3)
		{
			return FALSE;
		}
		elseif($intCode == 1) // 密码错误
		{
			return 'Authorization';
		}
		return null;
	}

	/**
	 *
	 * 查询域名WHOIS信息 并更新数据库记录
	 *
	 * @param string $domainName
	 * @param int $transferId
	 * @throws Exception
	 * @author zougc
	 * @return array|boolean
	 */
	public function checkDomainEmailByWhois($domainName, $transferId)
	{
		try
		{
			$whoisLib = new \common\WhoisLib();
			\core\db::closeBeforeConn('domain');
			$whoisInfo = $whoisLib->getWhoisBasicInfoByDomain($domainName, TRUE);
			if(is_numeric($whoisInfo))
			{
				return FALSE;
			}
			$email = $whoisInfo->AdministrativeEmail;
			$whois = $whoisInfo->WhoisInfo;
			if(DomainFunLib::isEmail($email) && ! empty($whois))
			{
				\core\Log::write($domainName . '|' . $email . '|' . $whois, 'domain', 'foa');
				$this->setTransferInfo(array('TransferInId' => $transferId), array('Whois' => $whois));
				return array('email' => $email, 'whois' => $whois);
			}
			return FALSE;
		}
		catch(\Exception $e)
		{
			return FALSE;
		}
	}

	/**
	 * 申请域名转入
	 *
	 * @param string $domain
	 * @param string $password
	 * @return boolean
	 * @author zougc
	 */
	public function submitDomainTransferIn($domain, $password, $period, $regid = FALSE)
	{
		$data = array('domain' => $domain, 'password' => $password, 'period' => $period);
		if($regid)
		{
			$data['registrarID'] = $regid;
		}
		$domainEppLib = new DomainEppLib();
		$info = $domainEppLib->transferInDomain($data);
		DomainLogsLib::addDomainService($domain, array('memo' => 'transfer_in', 'param' => $data, 'return' => $info), 
			11);
		return $info;
	}

	/**
	 * 格式化域名转入的错误信息
	 *
	 * @param array $info
	 * @return int
	 * @author zougc
	 */
	public function formatDomainTransferInfo($info)
	{
		if($info['resultCode'] == 5019)
		{
			if(is_string($info['data']['msg']['resultMsg']))
			{
				$msg = $info['data']['msg']['resultMsg'];
				if(stripos($msg, 'Authorization error') !== false ||
					 stripos($msg, 'Invalid authorization information') !== false ||
					 stripos($msg, 'Authentication error') !== false)
				{
					return 1;
				}
				if(stripos($msg, 'Object status prohibits') !== false)
				{
					return 2;
				}
				if(stripos($msg, 'out of service') !== false)
				{
					return 3;
				}
			}
		}
		return $info['resultCode'];
	}

	/**
	 * 定时任务--更新已经超过15天的转入列表
	 */
	public function updateTransferBackOrderList()
	{
		$time = date("Y-m-d H:i:s", time() - 15 * 24 * 3600);
		$rowData = array(
				'TransferStatus' => '<' . 5, 'CreateTime' => '<' . $time
		);
		$countInfo = $this->mod->getTransferCount($rowData);
		$count = isset($countInfo['total']) && $countInfo['total'] > 0 ? $countInfo['total'] : 0;
		if(! $count)
		{
			echo '没有已经超过15天的转入数据需要更新';
			return false;
		}
		$ps = 200;
		$page = ceil($count / 200);
		$limit = mt_rand(0, $page - 1) * $ps . ',' . $ps;
		$rowData['limit'] = $limit;
		$rowData['order'] = 'TransferInId asc';
		$listInfo = $this->mod->getTransferInfo($rowData, '*', false);
		if($listInfo && is_array($listInfo))
		{ 
			\core\Log::write('tran.cancel,定时任务--转入失败自动退款,总数：' . count($listInfo), 'cronmanage/transfer', 'transferbackorder');
			$this->transferBackOrderLib($listInfo);
		}
	}

	/**
	 * 判断订单时间，如果已经超过15天（含更新时间） 自动退款
	 */
	private function transferBackOrderLib($list)
	{
		$domainsMod = new \models\manage\domain\DomainsMod();
		foreach($list as $k => $v)
		{
			$domain = $v['DomainName'];
			$enameId = $v['EnameId'];
			$orderId = $v['OrderId'];
			$recordTime = strtotime($v['UpdateTime']) > 0 ? strtotime($v['UpdateTime']) : strtotime($v['CreateTime']);
			if(time() - $recordTime > 15 * 24 * 3600)
			{ 
				// 设置域名转入失败
				if(!$this->mod->upTransferInfo(array('TransferInId' => $v['TransferInId']), array('TransferStatus' => 7)))
				{
					continue;
				}
				if($orderId)
				{
					// 判断域名是否在我们公司 如果在直接扣款
					$orderStatus = false;
					$msg = '时间超过15天自动处理退单';
					$domainInfo = $domainsMod->getDomainInfo(array('DomainName' => $domain));
					if($domainInfo && $domainInfo['EnameId'] == $enameId)
					{
						$orderStatus = true;
						$msg = '域名在我司库中,直接扣款';
					}
					$this->transferOutFailedBackOrder($enameId, $orderId, $orderStatus, $domain, $v['TransferStatus'], $msg);
				}
				else
				{
					DomainLogsLib::addDomainService($domain, array('memo' => 'cron_cancel_transfer', 'c' => '订单ID不存在'), 29);
				}
			}
		}
	}
	
	private function transferOutFailedBackOrder($enameId,$orderid,$orderStatus,$domain,$transstatus,$msg)
	{
		try
		{
			$orderlib = new \interfaces\manage\Finance();
			$orderInfo = $orderlib->getOrderInfo($enameId, $orderid);
			if(!$orderInfo || $orderInfo['OrderStatus'] != 3)
			{
				return FALSE;
			}
			// 处理冻结中订单
			if($orderStatus)
			{
				$orderlib->confirmOrder((object)array('orderId' => $orderid, 'enameId' => $enameId));
			}
			else
			{
				$orderlib->cancelOrder((object)array('orderId' => $orderid, 'enameId' => $enameId));
			}
			$return = "order success";
		}
		catch(\Exception $e)
		{
			$return = $e->getMessage();
		}
		DomainLogsLib::addDomainService($domain,
		array('memo' => 'cron_cancel_transfer','msg'=>$msg, 'c' => $return,'action'=>$orderStatus,'oldtransferstatus' => $transstatus, 'orderId' => $orderid), 29);
	}
	
	/**
	 * 获取转入域名数据
	 * @param $tring $startData
	 * @param $string $endData
	 */
	public function getTransferDataAll($startData, $endData)
	{
		$success = $this->getTransferData($startData, $endData, TRUE);
		$failed = $this->getTransferData($startData, $endData, FALSE);
		if(empty($success) && empty($failed))
		{
			return FALSE;
		}
		$return = array();
		if($success) // 转入成功的数据
		{
			foreach($success as $enameId => $domains)
			{
				$status = $failed && array_key_exists($enameId, $failed);
				$return[$enameId] = array('succCount' => count($domains), 'failedCount' => $status ? count($failed[$enameId]) : '', 'succDomains' => implode("<br>", $domains), 'failedDomains' => $status ? implode("<br>", $failed[$enameId]) : '');
			}
			return $return;
		}
		else
		{
			if($failed) // 转入失败的数据
			{
				foreach($failed as $enameId => $domains)
				{
					$return[$enameId] = array('succCount' => '', 'failedCount' => count($failed[$enameId]), 'succDomains' => '', 'failedDomains' => implode("<br>", $domains));
				}
			}
			return $return;
		}
	}
	
	/**
	 * 取地转入数据
	 */
	private function getTransferData($startData, $endData, $succ = true)
	{
		$num = 0;
		$perNum = 500;
		$return = array();
		$param = array('SuccessTime>' => $startData, 'SuccessTime<' => $endData, 'TransferStatus' => 8);
		if(!$succ)
		{
			$param = array('UpdateTime>' => $startData, 'UpdateTime<' => $endData, 'TransferStatus' => 7);
		}
		while(true)
		{
			$offset = $num * $perNum;
			$param['limit'] = $offset . ',' . $perNum;
			$domainList = $this->mod->getTransferInfo($param, $fields = "EnameId,DomainName", false);
			if(empty($domainList))
			{
				break;
			}
			foreach($domainList as $domainInfo)
			{
				$return[$domainInfo['EnameId']][] = $domainInfo['DomainName'];
			}
			$num++;
		}
		return $return;
	}
	
	/**
	 * 域名入库成功失败通知易加
	 * @param unknown $domain
	 * @param unknown $enameId
	 * @param unknown $status
	 */
	public function checkTemplateIdWhite($templateId,$enameId,$transferInId,$createTime)
	{
		if(strtotime($createTime)>=strtotime('2016-07-14 14:00:00'))
		{
			return $templateId;
		}
		$templateLib = new \lib\manage\domain\TemplateLib();
		$templateInfo = $templateLib->getTempInfo($templateId);
		if($templateInfo && $templateInfo['CnStatus'] == 2)
		{
			return $templateId;
		}
		$info = $templateLib->getUseTemplates($enameId,'TransferInTemplate',true);
		if(!empty($info[0]['TemplateId']) && $info[0]['TemplateId']!=$templateId)
		{
			$this->mod->upTransferInfo(array('TransferInId' => $transferInId), array('TemplateId' => $info[0]['TemplateId']));
			return $info[0]['TemplateId'];
		}
		else
		{
			return $templateId;
		}
	}
	
	/**
	 * 处理掉各种转入模板问题的导致不能入库的--历史数据
	 * @param unknown $transferInId
	 * @param unknown $templateInfo
	 * @param unknown $enameId
	 */
	public function checkEmptyTemplate($transferInId,$templateInfo,$enameId)
	{
		if($templateInfo)
		{
			return $templateInfo;
		}
		$templateLib = new \lib\manage\domain\TemplateLib($enameId);
		$info = $templateLib->getUseTemplates($enameId,'TransferInTemplate',true);
		if(!empty($info[0]['TemplateId']))
		{
			$this->mod->upTransferInfo(array('TransferInId' => $transferInId), array('TemplateId' => $info[0]['TemplateId']));
			return $info[0];
		}
		return FALSE;
	}
}

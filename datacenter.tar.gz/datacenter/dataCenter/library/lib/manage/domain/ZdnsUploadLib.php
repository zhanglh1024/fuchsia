<?php
namespace lib\manage\domain;

/**
 * zdns 模板上传
 */
class ZdnsUploadLib
{

	private $conf;

	private $templateLib;

	public function __construct()
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/queue.ini', 'cnnic_upload');
		$this->templateLib = new \lib\manage\domain\TemplateLib();
	}

	/**
	 * 上传zdns信息
	 */
	public function uploadInfoZdnsWithSoap($templateId, $tempInfo = FALSE)
	{
		set_time_limit(0);
		// 获取模板信息
		!$tempInfo && $tempInfo = $this->templateLib->getTempInfo($templateId);
		if(!$tempInfo)
		{
			\lib\manage\domain\DomainLogsLib::addDomainService('temp.err', 
				array('memo' => 'info_null', 'result' => '模板不存在', 'templateId' => $templateId), 22);
			return FALSE;
		}
		if($tempInfo['CnStatus'] == 4 || $tempInfo['CnStatus'] == 0) // 不处理
		{
			return FALSE;
		}
		if($tempInfo['CnStatus'] == 1 || $tempInfo['CreateTime'] < '2012-01-01 00:00:00') // 审核失败，直接设置为zdns审核失败
		{
			$templateLib = new \lib\manage\domain\TemplateLib();
			$templateLib->setTemplateExt(array('templateId' => $templateId), array('newstatus' => '+1'));
			\lib\manage\domain\DomainLogsLib::addDomainService('temp.err', 
				array('memo' => 'info_null', 'result' => '模板CNNIC审核不通过', 'templateId' => $templateId), 22);
			return FALSE;
		}
		$params = array('idCard' => '', 'userImg' => '', 'orgNum' => '', 'orgImg' => '', 'upOrgImg' => '', 
			'orgType' => '');
		// 隐私模板
		if($tempInfo['TemplateType'] == 7)
		{
			$params['idCard'] = $this->conf->ename_id_card;
			$params['userImg'] = $this->conf->ename_user_img_path;
		}
		else
		{
			// 查询用户身份认证
			$verifyLib = new \lib\manage\verify\VerifyLib();
			$name = isset($tempInfo['Name']) ? $tempInfo['Name'] : ($tempInfo['FirstName'] . $tempInfo['LastName']);
			if(!$result = $verifyLib->getVerfifyIdentity($tempInfo['EnameId'], $name))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService('temp.err', 
					array('memo' => 'zdns', 'result' => 'read user IDCard error', 'info' => $tempInfo, 
						'templateId' => $tempInfo['TemplateId']), 22);
				return FALSE;
			}
			$userInfo = $result[0];
			$params['idCard'] = $userInfo['IdCard'];
			$params['userImg'] = $userInfo['NewFrontImg'] ? $userInfo['NewFrontImg'] : $userInfo['OldImg'];
		}
		// 企业模板
		if($tempInfo['TemplateType'] == 1)
		{
			$verifyLib = new \lib\manage\verify\VerifyLib();
			if(!$result = $verifyLib->getVerfifyCompany($tempInfo['EnameId'], $tempInfo['Org']))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService('temp.err', 
					array('memo' => 'zdns', 'result' => 'read user org error', 'templateId' => $tempInfo['TemplateId']), 
					22);
				return FALSE;
			}
			$comInfo = $result[0];
			$params['orgNum'] = $comInfo['License'];
			$params['orgImg'] = $comInfo['LicenseImg'];
			$params['orgType'] = $comInfo['LicenseType'];
			$params['upOrgImg'] = $this->conf->upload_file_path . '/org/' . $params['orgImg'];
			if(empty($params['orgNum']) || empty($params['orgImg']) || empty($params['orgType']))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService('temp.err', 
					array('memo' => 'info_null', 'org' => $tempInfo['Org'], 'tempName' => $tempInfo['TemplateName'], 
						'result' => '公司信息不全'), 22);
				return FALSE;
			}
		}
		else if($tempInfo['TemplateType'] == 3 || $tempInfo['TemplateType'] == 7)
		{
			$params['orgNum'] = $this->conf->ename_org_number;
			$params['upOrgImg'] = $this->conf->ename_org_img_path;
			$params['orgType'] = 2;
		}
		$path = $tempInfo['TemplateType'] == 7 ? $params['userImg'] : $this->conf->upload_file_path . '/sfz/' .
			 $params['userImg'];
		return $this->uploadUserTemplateToZdns($tempInfo, $params['idCard'], $params['orgNum'], $path, 
			$params['upOrgImg'], $params['orgType']);
	}

	/**
	 * 调用ZdnsApiLib的函数提交白名单
	 *
	 * @param array $tempInfo
	 * @param string $idCard
	 * @param string $orgNum
	 * @param string $userImg
	 * @param string $upOrgImg
	 * @param int $orgType
	 */
	private function uploadUserTemplateToZdns($tempInfo, $idCard, $orgNum, $sfzImg, $orgImg, $orgType, $userType = 1)
	{
		$uploadZdns = 0;
		$sfzImg = self::getImgFromImageServer($sfzImg);
		if(FALSE == $sfzImg)
		{
			\lib\manage\domain\DomainLogsLib::addDomainService($tempInfo['TemplateName'], 'read sfz error', 22);
			return FALSE;
		}
		if($orgNum)
		{
			$orgImg = self::getImgFromImageServer($orgImg);
			if(FALSE == $orgImg)
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($tempInfo['TemplateName'], 'read org error', 22);
				return FALSE;
			}
		}
		$uploadZdnsData['RegistrantId'] = $tempInfo['TemplateName']; // 注册人ID
		$uploadZdnsData['RegistrantName'] = $tempInfo['Name']; // 注册人姓名
		$uploadZdnsData['TldName'] = 'WANG'; // 注册联系人所属TLD名称
		$uploadZdnsData['RegistrantType'] = $orgNum ? 2 : 1; // 注册人类型 1:个人、2: 组织
		$uploadZdnsData['IdType'] = 1; // 联系人证件类型 1:身份 证号码,2:军官证号码、3:护照代码
		$uploadZdnsData['IdCode'] = $idCard; // 联系人证件类型对应的证件号码
		$uploadZdnsData['OrgName'] = $tempInfo['Org']; // 企业名称
		$uploadZdnsData['OrgType'] = $orgNum ? 2 : 1; // 企业类型 1:个体,2:工商
		$uploadZdnsData['OrgIdType'] = $orgType == 2 ? 1 : 2; // 组织证明证件类型 1营业执照 2组织机构 3其他
		$uploadZdnsData['OrgIdCode'] = $orgNum; // 组织证明证件类型对应的证件号码
		$uploadZdnsData['UserRegion'] = $userType; // 1:国内用户, 2:海外用户
		$uploadZdnsData['IdImg'] = $sfzImg;
		$uploadZdnsData['OrgIdImg'] = $orgImg;
		$vspLogic = new \logic\manage\thrift\VspLogic();
		$info = $vspLogic->zdnsRegistrantAuditDataUpload($uploadZdnsData);
		if($info === true) // 上传成功
		{
			\core\Log::write($tempInfo['TemplateName'] . ",upsuccess,", 'cronmanage/template', 'zdnsupnew');
			\lib\manage\domain\DomainLogsLib::addDomainService($tempInfo['TemplateName'], 
					array('memo' => 'adddomainservice', 'result' => '上传成功'), 22);
			$set = array('zdnsstatusnew' => '10');
			                           // 0[top未处理] 2[top绑定] 
			                           // 10[top未处理 wang审核中] 11[top未处理 wang审核不通过 ] 12[top未处理 wang审核通过 ] 
			                           // 30[top绑定 wang审核中] 31[top绑定 wang审核不通过 ] 32[top绑定 wang审核通过 ] 
		}
		else
		{
			\core\Log::write($tempInfo['TemplateName'] . ",uperror," . json_encode($info), 'cronmanage/template', 
				'zdnsupnew');
			$set = array('zdnsstatusnew' => '11');
		}
		if(!empty($set))
		{
			if(!$this->templateLib->setTemplateExt(array('registrar' => 86, 'templateId' => $tempInfo['TemplateId']), $set))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($tempInfo['TemplateName'], 
					array('memo' => 'zdns', 'result' => 'submit success,update database error', 'msg' => $set), 22);
			}
			else
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($tempInfo['TemplateName'], 
					array('memo' => 'zdns', 'result' => 'submit success,update database success', 'msg' => $set), 22);
			}
		}
		if($set['zdnsstatusnew']==10)
		{
			return true;
		}
		\lib\manage\domain\DomainLogsLib::addDomainService('temp.err', 
			array('memo' => 'zdns', 'info' => $tempInfo, 'result' => 'submit faile', 'msg' => $set), 22);
		return false;
	}

	/**
	 * 获取图片内容
	 *
	 * @param unknown $url
	 */
	private function getImgFromImageServer($imgFile)
	{
		$fileArr = explode('/', $imgFile);
		$file = end($fileArr);
		$path = str_replace($file, '', $imgFile);
		return \common\ImgServer::getImgUrl($path, $file);
	}
}

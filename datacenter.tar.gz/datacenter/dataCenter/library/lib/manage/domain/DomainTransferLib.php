<?php
namespace lib\manage\domain;
class DomainTransferLib
{
	public $enameId;
	public $transeroutmod;
	public $eppLib;
	public function __construct($enameId)
	{ 
		$this->enameId = $enameId;
		$this->eppLib = new \lib\manage\domain\DomainEppLib(); 
		$this->transeroutmod = new \models\manage\domain\DomainTransferOutMod();
	}   
	/**
	 * 格式化 域名转出列表 
	 * @param array $list 
	 * @param array $status
	 * @param array $tipway  
	 */
	public function actionTranferoutList($list, $status, $tipway)
	{
		if($list)
		{
			$domainModule = new \lib\manage\domain\DomainManageLib();
			foreach($list as $k => $v)
			{
				$list[$k]['DomainName'] = $list[$k]['DomainName'] ? \lib\manage\common\DomainFunLib::showDomainToEnameShow($list[$k]['DomainName']) : '--';
				$list[$k]['UpdateTime'] = strtotime($v['UpdateTime']) > 0 ? date("Y-m-d H:i:s", strtotime($v['UpdateTime'])) : '--';
				$list[$k]['StatusName'] = isset($status[$v['Status']]) ? $status[$v['Status']] : '--/--';
				$list[$k]['TipWay'] = isset($tipway[$v['TipWay']]) ? $tipway[$v['TipWay']] : '';
				$list[$k]['VerifyLink'] = '';
				if($v['Status'] == 1)
				{
					$domainInfo = $domainModule->getDomainInfo(array('DomainName' => $list[$k]['DomainName']));
					if(isset($domainInfo['RegistrarId']) && in_array($domainInfo['RegistrarId'], array(1,6,9,13,16,21,22,81,82))) //可以立即放出的接口
					{
						$list[$k]['VerifyLink'] =''; //md5($this->enameId . '/' . $v['TransferOutId']);
					}
					else if($v['CreateTime'])
					{
						$list[$k]['expectTransTime'] = date("Y-m-d H:i:s", strtotime($v['CreateTime']) + 604800);
					}
				}
			}
		}
		return $list;
	}
	/**
	 * 获取7天内有过转移记录的转出域名列表
	 */
	public function getInSevenDomain($data)
	{
		$return = array();
		foreach($data as $key => $value)
		{
			$value['inseven'] = $this->checkDomainInSeven($value['DomainName']) ? true : false;
			$return[] = $value;
		}
		return $return;
	}

	/**
	 * 查看转出的域名是否是7天内有过转移的域名
	 */
	public function checkDomainInSeven($domain)
	{
		$domainModule = new \lib\manage\domain\DomainManageLib();
		$domainInfo = $domainModule->getDomainInfo(array('DomainName' => $domain));
		$domainExtMod = new \models\manage\domain\DomainExtMod();
		if($domainInfo)
		{
			$domainExt = $domainExtMod->getOneDomainExt(array('DomainId' => $domainInfo['DomainId']));
			if($domainExt)
			{
				return $domainExt['TradeTime'] >= date('Y-m-d H:i:s', time() - 604800);
			}
		}
		return false;
	}
	/**
	 * 域名转出检查
	 * @param array $domainNames
	 * @param int $transferinReg 1新网 2万网 3其他注册商
	 * @throws Exception
	 */
	public function domainTransferOutCheck($domainNames, $transferinReg)
	{
		$domainManageLib = new \lib\manage\domain\DomainManageLib();
		$domainTemplateLib = new \lib\manage\domain\TemplateLib($this->enameId);
		$domainfunLib = new \lib\manage\common\DomainFunLib();
		$domainopenLib = new \lib\manage\common\DomainOpenLib();
		$domainMail = array();
		//return exception message;
		$errorMsg = count($domainNames) > 20 ? '域名数量超过20个!请重新检查后提交' : '';
		if(!empty($errorMsg))
		{
			$domainMail[0] = array('domain' => '', 'email' => '', 'errMsg' => $errorMsg);
			return $domainMail;
		}
		$transferinRegName = '';
		if($transferinReg == 1)
		{
			$transferinRegName = '新网 ';
		}
		elseif($transferinReg == 2)
		{
			$transferinRegName = '万网 ';
		}
		$dnlogic = new \logic\manage\domain\DomainManageLogic();
		foreach($domainNames as $k => $domain)
		{
			try
			{
				if($domainfunLib->isChinaDomain($domain))//CN域名维护临时关闭2014-05-10
				{
					\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck();
				}
				$info = $domainManageLib->getDomainInfo(array('DomainName' => $domain, 'EnameId' => $this->enameId));
				if(!$info)
				{
					throw new \Exception('您无权进行此操作！', 321002);
				}
				$domainfunLib->checkDomainToTransferPassword($info);
				$domainopenLib->domainOpenCN($domain, 'transferout');
				$mod = new \models\manage\domain\DomainTransferOutMod();
				$checkInfo = $mod->getTransferInfo(array('EnameId' => $this->enameId, 'DomainName' => $domain), '', '', true);
				if($checkInfo && $checkInfo['Status'] < 2)
				{
					throw new \Exception($domain . '的转出申请正在处理中，请勿重复申请!', 321013);
				}
				$checkLock = $dnlogic->checkDomainIsLock(array($domain));
				if(!empty($checkLock[$domain]) && time()>=strtotime('2016-12-01 00:00:00'))
				{
					throw new \Exception($domain . '已设置60天内禁止转移注册商锁定，请在锁定期满后再提交转移', 321013);
				}
				$tempInfo = $domainTemplateLib->getTemplateInfo($info['TemplateId']);
				$biaozhi = false;//标志是否设置了隐私保护默认为没有
				if(!empty($info) && !empty($info['PrivacyTemp']) && ($transferinReg == 1 || $transferinReg == 2))
				{
					$biaozhi = true;
					$domainMail[] = array('domain' => $domain, 'email' => $tempInfo['Email'],
							'errMsg' => $domain . '设置了隐私保护，在' . $transferinRegName . '可能无法过户，请取消隐私保护后再申请转出');
				}
				if($tempInfo)
				{
					$errMsg = '';
					if($tempInfo['TemplateType'] == 3 && ($transferinReg == 1 || $transferinReg == 2))
					{
						$errMsg = $domain . '使用了委托模板，在' . $transferinRegName . '可能无法过户，请模板过户后再申请转出';
						$domainMail[] = array('domain' => $domain, 'email' => $tempInfo['Email'],
								'errMsg' => $domain . '使用了委托模板，在' . $transferinRegName . '可能无法过户，请模板过户后再申请转出');
					}
					elseif(!$biaozhi)
					{
						$domainMail[] = array('domain' => $domain, 'email' => $tempInfo['Email'], 'errMsg' => '');
					}
				}
			}
			catch(\Exception $e)
			{
				$domainMail[] = array('domain' => $domain, 'email' => '', 'errMsg' => $e->getMessage());
			}
		}
		return $domainMail;
	}
	/**
	 * 域名申请转出函数 判断条件
	 * @param array $domainNames
	 * @param int $tipWay
	 * @return boolean
	 * @throws Exception
	 */
	public function domainTransferOut($domains, $tipWay)
	{
		$domainArr = explode("\n", trim($domains));
		unset($domains);
		if(count($domainArr) > 20 || empty($domainArr))
		{
			throw new \Exception('一次最多只可以申请20个!', 321014);
		}
		$domains = $allPassword = array();
		$error = '';
		$domains = $this->checkDomainTransferOut($domainArr, $tipWay);
		foreach($domains as $v)
		{
			try
			{
				$outInfo = $this->domainTransferOutLib($v['domain'], $tipWay, $v['registrarId']);//申请密码
				if($outInfo === false)
				{
					throw new \Exception('系统发生错误，' . $v['domain'] . '申请转出失败，请稍后重试!', 321015);
				}
				//这里添加数据应该算最合理的
				$redisKey = 'appdomaintransferouthash_'.date('Y-m-d');
				$redis = new \lib\manage\common\RedisLib(false);
				if(FALSE == $redis->setHashData($redisKey, $v['domain']))
				{
					\core\Log::write($redisKey . "addfailed,msg,4,".$v['domain'], 'domain', 'domaincountfailed');
				}
				$v['trid'] = $outInfo['trid'];
				$v['pwd'] = $outInfo['pwd'];
				$this->changeDomainTranferSuccess($v['domain'], $v['registrarId'], $v['status']);
				$whoisInfo = $this->getDomainWhois($v['domain']);
				if($whoisInfo)
				{
					$v['email'] = $whoisInfo['email'];
					$v['whois'] = $whoisInfo['whois'];
				}
				$allPassword[] = $v;
			}
			catch(\Exception $e)
			{
				\core\Log::write($v['domain'] . '|' . $e->getMessage() . '|' . json_encode($v), 'domain/transferout');
				$error .= $v['domain'] . ' ';
				continue;
			}
		}
		if(empty($allPassword))
		{
			throw new \Exception($error . '提交转出失败，请稍后重试！', 321018);
		}
		if(!$this->sendDomainPasswordToUser($allPassword, $tipWay))//发送给用户
		{
			throw new \Exception('发送域名转移密码失败', 321019);
		}
		$this->setDomainTransferIsSend($allPassword);
		if(empty($error))
			return true;
		throw new \Exception($error . '域名提交转出失败，请稍后重试！', 321018);
	}
	/**
	 * 检查域名是否可正常转出
	 */
	private function checkDomainTransferOut($domainArr, $tipWay)
	{
		$domainManageLib = new \lib\manage\domain\DomainManageLib();
		$domainTemplateLib = new \lib\manage\domain\TemplateLib($this->enameId);
		$domainfunLib = new \lib\manage\common\DomainFunLib();
		$domains = array();
		$dnLogic = new \logic\manage\domain\DomainManageLogic();
		$checkLock = array();
		foreach($domainArr as $k => $domain)
		{
			if($tipWay == 2 && $k > 0)
			{
				break;
			}
			if($domainfunLib->isChinaDomain($domain))//CN域名维护临时关闭2014-05-10
			{
				\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck();
			}
			$info = $domainManageLib->getDomainInfo(array('DomainName' => $domain, 'EnameId' => $this->enameId));
			if(!$info)
			{
				throw new \Exception($domain . '信息查找失败');
			}
			$domainfunLib->checkDomainToTransferPassword($info);
			$checkInfo = $this->transeroutmod->getTransferInfo(array('EnameId' => $this->enameId,
					'DomainName' => $domain), '', '', true);
			if($checkInfo && $checkInfo['Status'] < 2)
			{
				throw new \Exception($domain . '的转出申请正在处理中，请勿重复申请!');
			}
			$tempInfo = $domainTemplateLib->getTemplateInfo($info['TemplateId']);
			if($tempInfo === FALSE)
			{
				\core\Log::write($domain . '申请转出时根据模板ID获取模板信息失败', 'domain/transferout');
				throw new \Exception($domain . '获取模板信息失败!');
			}
			$checkLock[] = $domain;
			$domains[] = array('domain' => $domain, 'email' => $tempInfo['Email'],
					'registrarId' => $info['RegistrarId'], 'status' => $info['DomainStatus']);
		}
		$return = $dnLogic->checkDomainIsLock($checkLock);
		foreach($return as $dn=>$day)
		{
			if($day>0 && time()>=strtotime('2016-12-01 00:00:00'))
			{
				throw new \Exception($dn . '已经设置60天锁定,暂时无法转出');
			}
		}
		return $domains;
	}

	/**
	 * 域名转出核心函数
	 * @param string $domain
	 * @param int $sendType
	 */
	public function domainTransferOutLib($domain, $sendType, $RegistrarId)
	{
		$password = $this->setDomainTransferPassword($domain, $RegistrarId, 'transfer_out');
		if(empty($password) || $password == FALSE || $password == null)
		{
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, '获取转移密码失败', 15, '');
			return false;
		}
		$data = array('domainName' => $domain, 'outRegistrarId' => '0', 'status' => '0', 'remark' => '',
				'enameId' => $this->enameId, 'tipWay' => $sendType, 'createIp' => \common\Common::getRequestIp());
		$mod = new \models\manage\domain\DomainTransferOutMod();
		$addInfo = $mod->addTransferOut($data);
		if(!$addInfo)
		{
			\core\Log::write($domain . '转出添加转出表失败', 'domain/transferout');
			return false;
		}
		
		return array('pwd' => $password, 'trid' => $addInfo);
	}
	/*
	 * 获取转移秘密
	 */
	public function setDomainTransferPassword($domain, $RegistrarId, $memo)
	{
		$data = array();
		if($domain && $RegistrarId && $memo)
		{
			$data['domain'] = $domain;
			$data['registrarId'] = $RegistrarId;
			$data['memo'] = $memo;
			$password = $this->random() . "@" . mt_rand(1, 9);
			$info = $this->eppLib->changeDomainPass($domain,$RegistrarId,$password,$memo);
			if($info)
			{
				return $password;
			}
			throw new \Exception('更改转移密码失败', 321032);
		}
		\lib\manage\domain\DomainLogsLib::addDomainService($domain, json_encode(array('memo' => 'change_password',
				'param' => $data, 'c' => '缺少参数')), 11, '');
		throw new \Exception('更改转移密码失败', 321032);
	}
	private function random($length = 8)
	{
		$chars = 'bcdfghjk@lmn$prstvwxzaeiou';
		$result = '';
		for($p = 0;$p < $length;$p++)
		{
			$result .= ($p % 2) ? $chars[mt_rand(19, 25)] : $chars[mt_rand(0, 18)];
		}
		return $result;
	}
	/**
	 * 如果发送密码成功，到注册局解锁 修改数据库域名状态
	 * @param string $domain
	 * @param int $registrarId
	 * @param string $status
	 */
	private function changeDomainTranferSuccess($domain, $registrarId, $status)
	{
		$domainManageLib = new \lib\manage\domain\DomainManageLib();
		$tmpStatus = $status;
		$status = str_replace(array('3', '4', ',,'), '', $status);
		$status = explode(',', $status);
		$status = array_unique(array_filter($status));

		$where = array('DomainName' => $domain);
		$set = array('DomainMyStatus' => 5, 'DomainStatus' => implode(',', $status));
		if($domainManageLib->setDomainInfo($where, $set) == FALSE)
		{
			throw new \Exception('更新域名状态失败,请稍后重试!', 321016);
		}
		$params= array('domain' => $domain, 'status' => $status, 'registrarID' => $registrarId);
		$info = $this->eppLib->setDomainRegisterStatus($domain,$registrarId,$status);
		\lib\manage\domain\DomainLogsLib::addDomainService($domain, json_encode(array('memo' => 'transfer_out',
				'c' => '域名转出解锁', 'param' => $params, 'return' => $info)), 12);
		if(!$info)
		{
			if(FALSE == $domainManageLib->setDomainInfo($where, array('DomainMyStatus' => 1,
					'DomainStatus' => $tmpStatus)))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($domain, json_encode(array(
						'memo' => 'transfer_out_rebackstatus', 'c' => '域名解锁失败还原状态',
						'param' => array($domain, 1, $tmpStatus), 'return' => 'update failed')), 12);
			}
			throw new \Exception('解锁域名状态失败,请稍后重试!', 321017);
		}
		else
		{
			$mod = new \models\manage\domain\DomainLogsMod();
			return $mod->addOperationLog($domain, $this->enameId, '域名转出', 4, '', 0, \common\Common::getRequestIp());
		}
	}
	/**
	 * 查询域名WHOIS信息
	 * @param string $domainName
	 */
	public function getDomainWhois($domainName)
	{
		$inter = new \interfaces\manage\Whois();
		$info = $inter->getWhoisHasMail($domainName);
		if($info && $info['AdministrativeEmail'])
		{
			return array('email' => $info['AdministrativeEmail'], 'whois' => $info['WhoisInfo']);
		}
		\core\Log::write('transferOutSendEmail,domain:' . $domainName . '失败！', 'domain/transferout');
		return FALSE;
	}
	/**
	 *
	 * 调用队列发送域名密码
	 * @param string $password
	 * @param int $sendType
	 * @author edit:linlz
	 * @version 2012-06-07
	 */
	public function sendDomainPasswordToUser($info, $sendType)//1邮件，2手机
	{
		$flag = true;
		if($sendType == 2)
		{
			$info = $info[0];
			$memberlib = new \lib\manage\member\MemberLib();
			$phone = $memberlib->getMemberInfoByEnameId($this->enameId);
			$phone = $phone['Mobile'];
			try
			{
				$queueLogic = new \logic\manage\newqueue\QueueLogic();
				$smsData = array('Function' => 'send_sms', 'EnameId' => $this->enameId, 'TemplateName' => 'sendDomainPasswordSms', 'Target' => $phone, 'Data' => array('password' => $info['pwd'], 'trid' => $info['trid'], 'domain' => $info['domain']), 'Priority' => 5);
				$rs = $queueLogic->addQueueNormal($smsData);
			}
			catch (\Exception $e)
			{
				$rs = false;
			}
			if(!$rs)
			{
				$flag = false;
				\core\Log::write('发送域名密码加入SMS队列失败,EnameId:' . $this->enameId . 'PHONE:' . $phone, 'domain/transferout');
			}
		}
		else
		{
			$emailArr = array();
			foreach($info as $k => $v)
			{
				$emailArr[$v['email']][] = $v;
			}
			unset($info);
			foreach($emailArr as $v)
			{
				if($v[0]['email'] == 'temp@ename.com')
				{
					continue;
				}
				$this->sendMailToUsre($v, $v[0]['email']);
			}
			unset($emailArr);
		}
		return $flag;
	}
	/**
	 * 发送密码给用户
	 * @param array $info
	 * @param string $email
	 */
	private function sendMailToUsre($info, $email)
	{
		$flag = true;
		//create table
		$table = '<table style=border-collapse:collapse; cellpadding=10 border=1><tr><td width=130>转移ID</td><td width=150>域名</td><td>密码</td></tr>';
		foreach($info as $v)
		{
			$table .= "<tr><td>&nbsp;" . $v['trid'] . "&nbsp;</td><td>&nbsp;" . mb_substr($v['domain'], 0, 3, 'UTF-8') . "****&nbsp;</td><td>&nbsp;
			<strong style=color:#F00>" . $v['pwd'] . "</strong>&nbsp;</td></tr>";
		}
		$table .= '</table>';
		try 
		{
			$queueLogic = new \logic\manage\newqueue\QueueLogic();
			$mailData = array('Function' => 'sendmail', 'EnameId' => $this->enameId, 'TemplateName' => 'sendDomainPasswordMail', 'Target' => $email, 'Data' => array('table' => $table,	'chName' => $this->enameId), 'Priority' => 5);
			$rs = $queueLogic->addQueueNormal($mailData);
		}
		catch (\Exception $e)
		{
			$rs = false;
		}
		if(!$rs)
		{
			$flag = FALSE;
			\core\Log::write('发送域名密码加入队列失败,EnameId:' . $this->enameId . ',email:' . $email, 'domain/transferout');
		}
		return $flag;
	}
	/**
	 * 设置域名转出状态为已经发送密码 2012-03-23
	 * @param array $allDomains
	 * @return void
	 * @author zougc
	 */
	private function setDomainTransferIsSend($allDomains)
	{
		$mod = new \models\manage\domain\DomainTransferOutMod();
		foreach($allDomains as $v)
		{
			$this->transeroutmod->editTransferOut(array('TransferOutId' => $v['trid']), array('Status' => 1));
		}
	}
	/**
	 * 取消域名转出，修改本地库状态，修改注册局状态，修改域名密码
	 * @param array $domainInfo
	 * @param DomainManageLib $domainManageLib
	 * @return void
	 */
	public function cancelDomainTransferOutSetStatus($domainInfo)
	{
		$domainManageLib = new \lib\manage\domain\DomainManageLib();
		$domainStatus = $domainInfo['DomainStatus'] ? $domainInfo['DomainStatus'] . ',3,4' : '3,4';
		$domainStatus = array_unique(explode(',', $domainStatus));
		$setDomainInfo = array('DomainStatus' => implode(',', $domainStatus));
		if($domainInfo['DomainMyStatus'] == 5)
		{
			$setDomainInfo['DomainMyStatus'] = 1;
		}
		$domainManageLib->setDomainInfo(array('DomainId' => $domainInfo['DomainId']), $setDomainInfo);
		//域名加锁
		$this->eppLib->setDomainRegisterStatus($domainInfo['DomainName'], $domainInfo['RegistrarId'], $domainStatus);
		//更改域名密码
		$this->setDomainTransferPassword($domainInfo['DomainName'], $domainInfo['RegistrarId'], 'cancel_transfer');
	}
	/**
	 * 设置域名转出成功，即：备份域名,删除域名
	 * @param unknown_type $domain
	 * @throws Exception
	 * @author linlz
	 * @version 2012-05-22
	 */
	public function setDomainTransferOutSuccess($domain)
	{
		$domainManageLib = new \lib\manage\domain\DomainManageLib();
		$domainInfo = $domainManageLib->getDomainInfo(array('DomainName' => $domain));
		if($domainInfo['RegistrarId'] != 61)
		{
			if($this->eppLib->getDomainRegInfo($domain,$domainInfo['RegistrarId']))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($domain, "域名同意转出,5025接口域名还存在", 15);
				return FALSE;
			}
		}
		//得到域名扩展表信息
		$domainExtMod = new \models\manage\domain\DomainExtMod();
		$domainExt = $domainExtMod->getOneDomainExt(array('DomainId' => $domainInfo['DomainId']));
		if(!$domainExt)
		{
			$domainExt = array('DomainId' => $domainInfo['DomainId'], 'Dns' => '1', 'DomainFrom' => '1',
					'DomainIcp' => '', 'TemplateType' => '1', 'Remark' => '', 'Tooltip' => '1', 'TooltipWay' => '1,2,3','pwd'=>'');
		}
		if(isset($domainExt['EnameId']))
		{
			unset($domainExt['EnameId']);
		}
		if(isset($domainInfo['Roid']))
		{
			unset($domainInfo['Roid']);
		}
		if(!empty($domainInfo) && !empty($domainExt))
		{
			if(!$this->deleteDomain($domain, $domainInfo, $domainExt))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($domain, "写入备份表失败", 15);
				return false;
			}
		}
		$domainmod = new \models\manage\domain\DomainsMod();
		$delInfo = $domainmod->delDomain($domainInfo['DomainId']);
		if($delInfo)
		{
			$domainExtMod->delDomain($domainInfo['DomainId']);
			$redis = new \lib\manage\common\RedisLib(false);
			$redis->delData('tempdomainmystatus_'.$domain);
			$from = 1;
			if(\common\Common::getRequestUser() == 'api')
			{
				$from = 2;
			}
			$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'transfer_out_success')); 
			$amqp->sendMq(array('from'=>$from,'time' => time(), 'dn' => $domain, "uid" => $domainInfo['EnameId']));
			return TRUE;
		}
		else
		{
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, "转出域名时删除域名失败", 15);
		}
		return FALSE;
	}
	
	public function setDomainTransferOutSuccessTmp($domain)
	{
		$domainManageLib = new \lib\manage\domain\DomainManageLib();
		$domainInfo = $domainManageLib->getDomainInfo(array('DomainName' => $domain));
		if($domainInfo['RegistrarId'] != 61)
		{
				//得到域名扩展表信息
				$domainExtMod = new \models\manage\domain\DomainExtMod();
				$domainExt = $domainExtMod->getOneDomainExt(array('DomainId' => $domainInfo['DomainId']));
				if(!$domainExt)
				{
					$domainExt = array('DomainId' => $domainInfo['DomainId'], 'Dns' => '1', 'DomainFrom' => '1',
							'DomainIcp' => '', 'TemplateType' => '1', 'Remark' => '', 'Tooltip' => '1', 'TooltipWay' => '1,2,3','pwd'=>'');
				}
				if(isset($domainExt['EnameId']))
				{
					unset($domainExt['EnameId']);
				}
				if(isset($domainInfo['Roid']))
				{
					unset($domainInfo['Roid']);
				}
				if(!empty($domainInfo) && !empty($domainExt))
				{
					if(!$this->deleteDomain($domain, $domainInfo, $domainExt))
					{
						\lib\manage\domain\DomainLogsLib::addDomainService($domain, "写入备份表失败", 15);
						return false;
					}
				}
				$domainmod = new \models\manage\domain\DomainsMod();
				$delInfo = $domainmod->delDomain($domainInfo['DomainId']);
				if($delInfo)
				{
					$domainExtMod->delDomain($domainInfo['DomainId']);
					$redis = new \lib\manage\common\RedisLib(false);
					$redis->delData('tempdomainmystatus_'.$domain);
					return TRUE;
				}
				else
				{
					\lib\manage\domain\DomainLogsLib::addDomainService($domain, "转出域名时删除域名失败", 15);
				}
				return FALSE;
		}
	}
	/**
	 * 转出删除域名 包括与名表和扩展表 存在则更新 写入域名备份表失败才终止
	 */
	public function deleteDomain($domain, $domainInfo, $domainext, $serviceType = 15)
	{
		$domainManageLib = new \lib\manage\domain\DomainManageLib();
		//域名备份表
		if($this->getExistsDomain($domainInfo['DomainId'], false))//域名备份表存在则更新信息
		{
			if(!$this->updateOutDomainInfo($domainInfo, $domainext, false))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($domain, json_encode(array('memo' => '域名备份表更新失败',
						'needupdate' => $domainInfo)), $serviceType);
			}
		}
		else
		{
			if(!$this->addDomainBakInfo($domain, $domainInfo, $domainext, false, $serviceType))//不存在添加
			{
				return false;
			}
		}
		//域名扩展备份表
		if($this->getExistsDomain($domainInfo['DomainId']))//域名扩展备份表存在则更新信息
		{
			if(!$this->updateOutDomainInfo($domainInfo, $domainext, true))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($domain, json_encode(array('memo' => '域名扩展备份表更新失败',
						'domainid' => $domainInfo['DomainId'], 'needupdate' => $domainext)), $serviceType);
			}
		}
		else
		{
			$this->addDomainBakInfo($domain, $domainInfo, $domainext, true, $serviceType);//不存在则更新
		}
		return true;
	}
	/**
	 * 通过domainId获取域名备份表或者域名扩展备份表信息
	 */
	private function getExistsDomain($domainId, $ext = true)
	{
		if($ext)
		{
			$domainbakMod = new \models\manage\domain\DomainExtBakMod();
			$bak = $domainbakMod->getDomainExtBakOne(array('DomainId' => $domainId));
		}
		else
		{
			$domainbakMod = new \models\manage\domain\DomainBakMod();
			$bak = $domainbakMod->getDomainBakOne(array('DomainId' => $domainId));
		}

		return $bak;
	}
	/**
	 * 更新域名备份表或者域名扩展备份表信息
	 */
	private function updateOutDomainInfo($domainInfo, $domainext, $code = true)
	{
		$set = $code ? $domainext : $domainInfo;
		if(isset($set['TradeTime']))
		{
			unset($set['TradeTime']);
		}
		if($code)
		{
			$domainbakMod = new \models\manage\domain\DomainExtBakMod();
		}
		else
		{
			$domainbakMod = new \models\manage\domain\DomainBakMod();
		}
		$setInfo = $domainbakMod->upDomainInfo(array('DomainId' => $domainInfo['DomainId']), $set);
		return $setInfo;
	}
	/**
	 * 添加备份记录
	 */
	private function addDomainBakInfo($domain, $domainInfo, $domainext, $code = true, $serviceType = 15)
	{
		$addInfo = $code ? $domainext : $domainInfo;
		if(isset($addInfo['TradeTime']))
		{
			unset($addInfo['TradeTime']);
		}
		if($code)
		{
			$domainbakMod = new \models\manage\domain\DomainExtBakMod();
		}
		else
		{
			$domainbakMod = new \models\manage\domain\DomainBakMod();
		}
		$info = $domainbakMod->addDomain($addInfo);
		if(!$info)
		{
			$logInfo = array('memo' => '添加域名备份记录失败', 'needadd' => $domainInfo);
			if($code)
			{
				$logInfo = array('memo' => '添加域名扩展备份记录失败', 'domainid' => $domainInfo['DomainId'], 'needadd' => $domainext);
			}
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, $logInfo, $serviceType);
			return false;
		}
		return true;
	}

	/**
	 * 转入失败后删除redis中关于该域名的信息
	 */
	public function delTransferRedis($domain, $in = true)
	{
		try 
		{
			$type = $in ? 2 : 4;
			$redis = new \lib\manage\common\RedisLib(false);
			$redisKeyHash = $in ? 'appdomaintransferhash_' . date('Y-m-d') : 'appdomaintransferouthash_' . date('Y-m-d');
			if($redis->getHashData($redisKeyHash, $domain))
			{
				if(FALSE == $redis->delHashData($redisKeyHash, $domain))
				{
					\core\Log::write($redisKeyHash . ",deltransferredis,msg,$type,$domain", 'domain', 
						'domaincountfailed');
				}
			}
		}
		catch(\Exception $e)
		{
			\core\Log::write("$redisKeyHash,redis error,msg,$type,$domain", "domain", "domaincountfailed");
		}
	}
}

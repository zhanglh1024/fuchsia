<?php 
namespace lib\manage\domain;

/**
 * cnnic 模板上传
 */
class CnnicUploadLib
{

	private $domainEppLib;

	private $conf;

	private $templateLib;

	public function __construct()
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/queue.ini', 'cnnic_upload');
		$this->domainEppLib = new \lib\manage\domain\DomainEppLib();
		$this->templateLib = new \lib\manage\domain\TemplateLib();
	}

	/**
	 * 上传cnnic信息
	 * code:0658
	 *
	 * @param array $info
	 */
	public function uploadInfoCnnicWithSoap($info)
	{
		set_time_limit(0);
		// 获取模板信息
		if(! $tempInfo = $this->templateLib->getTempInfo($info['templateId']))
		{
			\lib\manage\domain\DomainLogsLib::addDomainService('temp.err', 
				array('memo' => 'info_null', 'result' => '模板不存在', 'templateId' => $info['templateId']), 22);
			return FALSE;
		}
		$params = array('idCard' => '', 'userImg' => '', 'orgNum' => '', 'orgImg' => '', 'upOrgImg' => '', 
				'orgType' => '');
		// 隐私模板
		if($tempInfo['TemplateType'] == 7)
		{
			$params['idCard'] = $this->conf->ename_id_card;
			$params['userImg'] = $this->conf->ename_user_img_path;
		}
		else
		{
			// 查询用户身份认证
			$verifyLib = new \lib\manage\verify\VerifyLib();
			$name = isset($tempInfo['Name']) ? $tempInfo['Name'] : ($tempInfo['FirstName'] . $tempInfo['LastName']);
			if(! $result = $verifyLib->getVerfifyIdentity($tempInfo['EnameId'], $name))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService('temp.err', 
					array('memo' => 'cnnic', 'result' => 'read user IDCard error', 'info' => $temp, 
							'templateId' => $tempInfo['TemplateId']), 22);
				return FALSE;
			}
			$userInfo = $result[0];
			$params['idCard'] = $userInfo['IdCard'];
			$params['userImg'] = $userInfo['NewFrontImg'] ? $userInfo['NewFrontImg'] : $userInfo['OldImg'];
		}
		// 企业模板
		if($tempInfo['TemplateType'] == 1)
		{
			$verifyLib = new \lib\manage\verify\VerifyLib();
			if(! $result = $verifyLib->getVerfifyCompany($tempInfo['EnameId'], $tempInfo['Org']))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService('temp.err', 
					array('memo' => 'cnnic', 'result' => 'read user org error', 'templateId' => $tempInfo['TemplateId']), 
					22);
				return FALSE;
			}
			$comInfo = $result[0];
			$params['orgNum'] = $comInfo['License'];
			$params['orgImg'] = $comInfo['LicenseImg'];
			$params['orgType'] = $comInfo['LicenseType'];
			$params['upOrgImg'] = $this->conf->upload_file_path . '/org/' . $params['orgImg'];
			if(empty($params['orgNum']) || empty($params['orgImg']) || empty($params['orgType']))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService('temp.err', 
					array('memo' => 'info_null', 'org' => $tempInfo['Org'], 'tempName' => $tempInfo['TemplateName'], 
							'result' => '公司信息不全'), 22);
				return FALSE;
			}
		}
		else if($tempInfo['TemplateType'] == 3 || $tempInfo['TemplateType'] == 7)
		{
			$params['orgNum'] = $this->conf->ename_org_number;
			$params['upOrgImg'] = $this->conf->ename_org_img_path;
			$params['orgType'] = 2;
		}
// 		if(! $this->moveUserImgAndOrgImg($params, $tempInfo['TemplateType']))
// 		{
// 			\lib\manage\domain\DomainLogsLib::addDomainService('temp.err', 
// 				array('memo' => 'cnnic', 'result' => '复制文件失败', 'templateId' => $tempInfo['TemplateId']), 22);
// 			return FALSE;
// 		}
		$path = $tempInfo['TemplateType'] == 7 ? $params['userImg'] : $this->conf->upload_file_path . '/sfz/' .
			 $params['userImg'];
		return $this->uploadUserTemplateToCnnic($tempInfo, $params['idCard'], $params['orgNum'], $path, 
			$params['upOrgImg'], $params['orgType']);
	}

	/**
	 * 调用CnnicApiLib的函数提交白名单
	 *
	 * @param ApiSdk $sdk
	 * @param array $tempInfo
	 * @param string $idCard
	 * @param string $orgNum
	 * @param string $userImg
	 * @param string $upOrgImg
	 * @param int $orgType
	 */
	private function uploadUserTemplateToCnnic($tempInfo, $idCard, $orgNum, $sfzImg, $orgImg, $orgType)
	{
		$orgProType = $orgType == 2 ? 'YYZZ' : 'ORG';
		$set = array();
		$uploadCnnic = 0;
		if($tempInfo['CnStatus'] == 0 && $tempInfo['RegistrarId'])
		{
			$sfzImg = self::getImgFromImageServer($sfzImg);
			if(FALSE == $sfzImg)
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($tempInfo['TemplateName'],'read sfz error', 22);
				return FALSE;
			}
			if($orgNum)
			{
				$orgImg = self::getImgFromImageServer($orgImg);
				if(FALSE == $orgImg)
				{
					\lib\manage\domain\DomainLogsLib::addDomainService($tempInfo['TemplateName'],'read org error', 22);
					return FALSE;
				}
			}
			$vspLogic = new \logic\manage\thrift\VspLogic();
			$regtype = $orgNum ? 'E' : 'I';
			$orgType = $orgNum ? 'PU' : 'PR';
			$info = $vspLogic->upLoadRegistrant($tempInfo['TemplateName'], 'SFZ', $idCard, $sfzImg, $regtype,'D',$orgNum,$orgType,$orgImg,$orgProType);
			if($info === true)
			{
				\core\Log::write($tempInfo['TemplateName'].",upsuccess,",'cronmanage/template','cnnicupnew');
				$logRs = \lib\manage\domain\DomainLogsLib::addDomainService('cnnic.check', 
					array('Type' => 'CN', 'TemplateId' => $tempInfo['TemplateId'], 
							'TemplateName' => $tempInfo['TemplateName']), 24);
				if(! $logRs)
				{
					\lib\manage\domain\DomainLogsLib::addDomainService($tempInfo['TemplateName'], 
						array('memo' => 'adddomainservice', 'result' => $logRs), 22);
				}
				$set['CnStatus'] = 3;
				$uploadCnnic = 1;
			}
			else
			{
				\core\Log::write($tempInfo['TemplateName'].",uperror,".json_encode($info),'cronmanage/template','cnnicupnew');
				// 如果提示模板ID不存在 一律设置未注册 2012-02-03
				$this->setTemplateNotRegistrant($info, $tempInfo);
			}
		}
		
		if(! empty($set))
		{
			$set['UploadCnnic'] = $uploadCnnic;
			if(! $this->templateLib->updateTemplateInfo(array('TemplateId' => $tempInfo['TemplateId']), $set))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($tempInfo['TemplateName'], 
					array('memo' => 'cnnic', 'result' => 'submit success,update database error', 'msg' => $set), 22);
			}
			else
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($tempInfo['TemplateName'], 
					array('memo' => 'cnnic', 'result' => 'submit success,update database success', 'msg' => $set), 22);
			}
			return true;
		}
		\lib\manage\domain\DomainLogsLib::addDomainService('temp.err', 
			array('memo' => 'cnnic', 'info' => $tempInfo, 'result' => 'submit faile', 'msg' => $set), 22);
		return true;
	}

	/**
	 * 修改模板信息
	 *
	 * @param $info string
	 * @param array $templateInfo
	 */
	private function setTemplateNotRegistrant($info, $templateInfo)
	{
		\lib\manage\domain\DomainLogsLib::addDomainService('temp.err',
			array('memo' => 'cnnic', 'result' => 'setTemplateNotRegistrant', 'msg' => $info), 22);
		return FALSE;
		if(stripos($info, 'registrantId is not exist') !== FALSE)
		{
			$templateId = $templateInfo['TemplateId'];
			if($templateInfo['RegistrarId'])
			{
				$this->templateLib->updateTemplateInfo(
					array('TemplateId' => $templateId, 'EnameId' => $templateInfo['EnameId']), array('RegistrarId' => 0));
			}
			if($templateInfo['CnIdn'])
			{
				$this->templateLib->updateTemplateInfo(
					array('TemplateId' => $templateId, 'EnameId' => $templateInfo['EnameId']), array('CnIdn' => 0));
			}
		}
		else
		{
			\lib\manage\domain\DomainLogsLib::addDomainService('temp.err', 
				array('memo' => 'cnnic', 'result' => 'setTemplateNotRegistrant', 'msg' => $info), 22);
		}
	}

	/**
	 * 复制图片到临时目录下
	 *
	 * @param array $params
	 * @param int $tempType 模板类型
	 * @throws \Exception
	 */
	private function moveUserImgAndOrgImg($params, $tempType)
	{}

	/**
	 * 创建临时目录文件夹
	 *
	 * @param string $filePath
	 * @param string $type
	 */
	private function createTempPathFolder($filePath, $type = 'sfz')
	{}

	/**
	 * 复制认证图片到临时文件夹下
	 *
	 * @param string $formPath
	 * @param string $localPath
	 * @throws Exception
	 */
	private function copyImgFromVerifyPic($formPath, $localPath)
	{
		try
		{
			if(! file_exists($formPath))
			{
				return FALSE;
			}
			ini_set('memory_limit', '300M');
			$imgObj = @imagecreatefromjpeg($formPath);
			if(! $imgObj)
			{
				$imgObj = @imagecreatefromgif($formPath);
			}
			if(! $imgObj)
			{
				$imgObj = @imagecreatefromwbmp($formPath);
			}
			if(! $imgObj)
			{
				$imgObj = @imagecreatefrompng($formPath);
			}
			$width = imagesx($imgObj) + 1;
			$height = imagesy($imgObj) + 1;
			$tmpimg = @imagecreatetruecolor($width, $height);
			if(function_exists('imagecopyresampled'))
			{
				imagecopyresampled($tmpimg, $imgObj, 0, 0, 0, 0, $width, $height, imagesx($imgObj), imagesy($imgObj));
			}
			else
			{
				imagecopyresized($tmpimg, $imgObj, 0, 0, 0, 0, $width, $height, imagesx($imgObj), imagesy($imgObj));
			}
			imagejpeg($tmpimg, $localPath, 95);
			imagedestroy($imgObj);
			imagedestroy($tmpimg);
			return TRUE;
		}
		catch(Exception $e)
		{
			throw new Exception('img is more system limit,msg:' . $e->getMessage());
		}
	}
	
	/**
	 * 获取图片内容
	 * @param unknown $url
	 */
	private function getImgFromImageServer($imgFile)
	{
		$fileArr = explode('/', $imgFile);
		$file = end($fileArr);
		$path = str_replace($file, '', $imgFile);
		return \common\ImgServer::resizeImg($path, $file);
	}
}

<?php
namespace lib\manage\domain;
use lib\manage\common\DomainFunLib as DomainFunLib;
use lib\manage\common\DomainOpenLib as DomainOpenLib;

class DomainQueryLib
{
	private $sdk;
	private $enameId;
	public $isTop;
	public $remark;
	public $price = null;

	public function __construct($enameId = '')
	{
		$this->enameId = $enameId;
	}

	/**
	 * 检测用户是否频繁操作
	 */
	public function interLimit($func, $timeout = 2)
	{
		$key = $func . ':' . (!empty($_REQUEST['ip']) ? $_REQUEST['ip'] : \common\Client::getIp());
		$redis = \core\RedisLib::getInstance('manage');
		if($redis->get($key))
		{
			throw new \Exception('您的频率太快了，休息一会' ,300032);  
		}
		if($redis->set($key, array_merge(array(), array('lasttime' => $_SERVER['REQUEST_TIME'])), $timeout) === FALSE)
		{
			throw new \Exception('接口暂时不可用，请稍后重试' ,300033);
		}
		return true;
	}

	/**
	 * 查询域名是否可以注册
	 */
	public function domainCheckIsExits($domain, $regid = FALSE)
	{
		try
		{
			include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
			$sdk = new \ApiSdk();
			$param = array('domain' => $domain);
			//取随机接口id，否则走默认接口id
			$regid = $regid ? $regid : $this->getRandRegid($domain);
			if(FALSE != $regid)
			{
				$param['registrarID'] = $regid;
			}
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domainpre');
			foreach(explode(',',$domain) as $dn)
			{
				if(in_array(DomainFunLib::getDomainClass($dn), array("WANG",'TOP'))) // WANG TOP溢价
				{
					$param['extension']['fee'][] = array('name' =>$dn,'currency' =>'CNY','command'=>'create','period'=>1,'period_unit'=>'y');
				}
				if(in_array(DomainFunLib::getDomainClass($dn), array("VIP"))) // VIP溢价
				{
					$param['extension']['fee'][] = array('name' =>$dn,'currency' =>'USD','command'=>'create','period'=>1,'period_unit'=>'y');
				}
				if(in_array(DomainFunLib::getDomainClass($dn), array("TV"))) // tv溢价
				{
					$param["extension"]["premiumdomain"] = array("flag"=>true);
				}
			}
			$registInfo = @$sdk->execSdkFun(5001, $param);
			if(is_array($registInfo) && $registInfo['resultCode'] == 5000)
			{
				if(count(explode(',',$domain)) == 1)
				{
					$status = $registInfo['data']['registered'] == 0 ? true : false;
					if($status === true)
					{
						if(self::checkOverLoadDomain($domain, $registInfo['data']))
						{
							return 'domainpre';//溢价域名不支持app注册
						}
					}
					return $status;
				}
				else
				{
					$return = array();
					if(isset($registInfo['data']['registered']))
					{
						$return['registered'] = $registInfo['data']['registered'];
					}
					if(isset($registInfo['data']['notRegister']))
					{
						$return['notRegister'] = $registInfo['data']['notRegister'];
					}
					return $return;
				}
			}
			else
			{
				return isset($registInfo['resultCode']) ? FALSE : NULL;				
			}
		}
		catch(\Exception $e)
		{
			return NULL;
		}
	}

	private static function checkOverLoadDomain($domain,$returnInfo)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domainpre');
		if(!in_array(DomainFunLib::getDomainClass($domain), explode(",", $conf->overload_domainltd)))
		{
			return FALSE;
		}
		if(empty($returnInfo['fee']) || !is_array($returnInfo['fee']))
		{
			return FALSE;
		}
		$domain = strtolower($domain);
		foreach($returnInfo['fee'] as $feeInfo)
		{
			// TOP溢价
			if(in_array(DomainFunLib::getDomainClass($domain), array("WANG",'TOP','VIP')))
			{
				if($domain == strtolower($feeInfo['name']) && !empty($feeInfo['class']) &&
					 stripos($feeInfo['class'], "premium") !== false && !empty($feeInfo['fee']) &&
					 !empty($feeInfo['fee'][0]['fee']))
				{
					return true;
				}
			}
			// TV溢价
			if(DomainFunLib::getDomainClass($domain) == 'TV')
			{
				if($domain == strtolower($feeInfo['name']) && !empty($feeInfo['class']) && $feeInfo['class'] &&
					 !empty($feeInfo['fee']) && !empty($feeInfo['fee'][0]['fee']))
				{
					return true;
				}
			}
		}
		return FALSE;
	}
	
	
	public function domainBatchCheckExists($domains,$rids)
	{
		try
		{
			include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
			$sdk = new \ApiSdk();
			$registInfo = @$sdk->execSdkFun(5001, array('domain' => $domains,'registrarID'=>$rids));
			if(is_array($registInfo) && $registInfo['resultCode'] == 5000)
			{
				return $registInfo['data']['registered'] == 0 ? true : false;
			}
			return NULL;
		}
		catch(\Exception $e)
		{
			return FALSE;
		}		
	}
	
	
	/**
	 * 获取域名注册续费转入价格
	 */
	public function getDomainPrice($domain, $suffix, $priceType = 1, $productType = false)
	{
		$activiPrice = $this->getActivityPrice($domain, $priceType);
		if($activiPrice !== false)
		{
			return sprintf("%.2f", $activiPrice);
		}
		$productInfo = $this->getProductInfo($domain, $suffix, $priceType, $productType);
		if(!empty($productInfo))
		{
			return sprintf("%.2f", $productInfo['Price']);
		}
		return false;
	}

	/**
	 * 正常活动都是注册价格优惠
	 */
	public function getActivityPrice($domain,$priceType)
	{
		if($priceType ==1 && \common\Common::getRequestUser() =='api')
		{
			//以后其他后缀活动直接往后面加就是了
			if(\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck(FALSE,'cnnet'))
			{
				$ltd = \lib\manage\common\DomainFunLib::getDomainClass($domain);
				if($ltd == 'NET' || $ltd =="CN")
				{
					return $ltd == 'NET' ? 40 : 30;
				}
			}
// 			return $this->checkTwoElevent($domain, $priceType, 18);
		}
		return FALSE;
	}
	
	/**
	 * 得到产品信息
	 * @param int|boolean $priceType 价格类型'1'=>'注册域名','2'=>'转入域名','3'=>'域名续费'
	 * @param int|boolean $productType 产品类型（对应domain表domain_property）
	 */
	public function getProductInfo($domain, $suffix, $priceType = 1, $productType = false)
	{
		$userModule = new \models\manage\member\EmemberMod('');
		$userInfo = $userModule->getMemberInfo($this->enameId);
		$groupId = $userInfo ? $userInfo['UserGroup'] : 2;//未登陆的显示金牌用户组价格
		$productType = ($productType === false) ? \lib\manage\common\DomainFunLib::getDomainProductType($domain) : $productType;
		$suffix = preg_match('/^\./', $suffix) ? $suffix : '.' . $suffix;
		$data = array('ProductName' => $suffix, 'ProductType' => $productType, 'GroupId' => $groupId,
				'PriceType' => $priceType);
		if(8 == $productType)
		{
			$data['ProductName'] = $this->getNameDomainProductName($domain);
		}
		$info = $this->getProductByName($data);
		if(is_array($info) && !empty($info))
		{
			return $info;
		}
		\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('sendData' => $data, 'return' => $info), 13, $this->enameId);
		return false;
	}

	/**
	 * 获取产品名称
	 */
	private function getNameDomainProductName($domain)
	{
		$suffix = \lib\manage\common\DomainFunLib::getDomainClass($domain);
		return (\lib\manage\common\DomainFunLib::isChineseCnDomain($domain) && $suffix == 'CN') ? '.cnidn' : '.' . strtolower($suffix);
	}

	/**
	 * 获取域名信息 查看域名是否在交易
	 */
	public function checkDomainStatus($domain,$dn = FALSE)
	{
		$dnManageLib = new \lib\manage\domain\DomainManageLib();
		$domainInfo = $dnManageLib->getDomainInfo(array('DomainName' => $domain));
		if($domainInfo)
		{
			if($dn)
			{
				return $domainInfo;
			}
			return \lib\manage\common\DomainFunLib::checkIsTradeStatus($domainInfo['DomainMyStatus']);
		}
		return FALSE;
	}

	/**
	 *根据产品名称获取价格
	 */
	private function getProductByName($params)
	{
		$finLog = new \lib\manage\finance\FinanceLogLib();
		try
		{
			if(!isset($params['ProductType']))
			{
				$finLog->log('-3001 参数错误：ProductType', $params, 'empty type');
				return '-3001 参数错误：ProductType';
			}
			$productLib = new \lib\manage\finance\ProductLib();
			$PriceType = isset($params['PriceType']) ? $params['PriceType'] : false;
			$productLib->setPriceType($PriceType);
			return $productLib->getProductByName($params['ProductName'], $params['GroupId'], $params['ProductType']);
		}
		catch(\Exception $e)
		{
			$finLog->log('[0304]根据产品名称获取价格失败', $params, $e->getMessage(), 0, 0);
			return $e->getMessage();
		}
	}

	/**
	 * 获取推荐域名-默认值返回3条推荐记录
	 */
	public function getRecommendDomain($suffix, $domainBody)
	{
		try 
		{

			$postData = array(); 
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/help.ini', 'client');
			$url = $conf->api_ename->url.'recommand/recommand';
			$postData['user'] = $conf->count_audit->user;
			$postData['appkey'] = $conf->count_audit->appkey;
			$recom=array($domainBody=>implode(',', $suffix));
			$postData['domain'] = json_encode($recom);
			$postData['ip'] = \common\Client::getIp();
			$result=\common\Common::requestPost($url,$postData);
			$result=json_decode($result,true);
			if($result && $result['flag'] && $result['code'] == 100000)
			{
				return  $this->formatRecommendData($result['msg']['data']);
			}
			return FALSE;
		} 
		catch(\Exception $e)
		{
			return FALSE;
		}
	}

	private function formatRecommendData($recom)
	{
		if(!$recom)
		{
			return FALSE;
		}
		$return = array(); 
		foreach($recom as $info)
		{
			if(stripos($info['TransTypeCn'], '保留竞价') !== FALSE || stripos($info['TransTypeCn'], '认购域名') !== FALSE)
			{
				continue;
			}
			$info['Type'] = $info['TransType'];
			$info['TransType']=$info['TransTypeCn'];
			$return[] = $info;
		}
		return $return;
	}

	/**
	 * 查看域名是否在推荐域名里
	 */
	public function checkDomainRecommend($domain, $recommendList)
	{
		foreach($recommendList as $recommendInfo)
		{
			if($recommendInfo['DomainName'] == $domain && !empty($recommendInfo['AuditListId']))
			{ 
				return array('type' => $recommendInfo['Type'], 'bidPrice' => $recommendInfo['BidPrice'],
						'buyUrl' => $recommendInfo['Url'],'AuditListId'=>$recommendInfo['AuditListId']);
			}
		}
		return array();
	}

	/**
	 * 格式化查询域名注册列表（可注册的放在前面）
	 */
	public function formatQueryRegistList($data)
	{
		$successData = array();
		foreach($data as $k => $v)
		{
			if(isset($v['code']) && $v['code'] == 60000)
			{
				$successData[] = $v;
				unset($data[$k]);
			}
		}
		return array_merge($successData, $data);
	}

	/**
	 * 查看域名是否是珍品域名 是否已经消费过
	 */
	public function getTopDomainPrice($domain, $shopType)
	{
		// $price = $this->ccDomainDone($domain, $shopType);
		// if(FALSE !== $price)
		// {
		// $this->isTop = 5;
		// $this->remark = '.cc特殊优惠';
		// $this->price = $price;
		// return $price;
		// }
			
		// wang域名活动
		$price = $this->wangDomainDone($domain, $shopType);
		if(FALSE !== $price)
		{
			$this->isTop = 5;
			$this->remark = '.wang续费/转入优惠活动，低至10元';
			$this->price = $price;
			return $price;
		}
		$price = $this->comDomainDone($domain, $shopType);
		if(FALSE !== $price)
		{
			$this->isTop = 5;
			$this->remark = '三声四数以内Com' . ($shopType == 2 ? '转入' : '续费') . '免费';
			$this->price = $price;
			return $price;
		}
		if(!in_array($shopType, array(2, 3)) || \lib\manage\common\DomainFunLib::isTopDomainType($domain) == FALSE)
		{
			return false;
		}
		try
		{
			\lib\manage\common\DomainOpenLib::domainOpen('topdomain');
		}
		catch(\Exception $e)
		{
			return FALSE;
		}
		$topDomainLib = new \lib\manage\domain\DomainTopLib();
		$topInfo = $topDomainLib->checkTopDomain($domain, date('Y'));
		if(!is_array($topInfo))
		{
			return false;
		}
		$this->isTop = 1;
		$this->remark = $topInfo['remark'];
		$this->price = $topInfo['price'];
		return $topInfo['price'];
	}
	
	/**
	 * 查询走随机的接口，cn和com
	 */
	public function getRandRegid($domain)
	{
		$randRegid = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain_register_randregid');
		$ltd = DomainFunLib::getDomainClass($domain);
		if($ltd == 'CN' || $ltd=="中国")
		{
			$eppId = explode(',', $randRegid->dn_query_cn_regid);
			$rand = $randRegid->dn_query_cn_rand;
			return $eppId[mt_rand(0, $rand)];
		}
		elseif($ltd == 'COM' || $ltd == 'NET')
		{
			$eppId = explode(',', $randRegid->dn_query_com_regid);
			$rand = $randRegid->dn_query_com_rand;
			return $eppId[mt_rand(0, $rand)];
		}
		return FALSE;
	}
	
	/**
	 * com net cc tv
	 */
	public function getDomainRoid($domain)
	{
		if(!in_array(\lib\manage\common\DomainFunLib::getDomainClass($domain),array('COM','NET','CC','TV')))
		{
			return '';
		}
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();		
		$sdkInfo = $sdk->execSdkFun(5025, array('domain'=>$domain));
		if($sdkInfo['resultCode'] == 5000)
		{
			return $sdkInfo['data']['roid'];
		}
		return '';
	}
	 
	/**
	 * 可注册域名年份 部分包含特殊价格和特殊备注
	 * 主要活动域名 珍品域名
	 */
	public function checkDomainYears($domain,$shopType,$year,$specialPrice = FALSE)
	{
		$remark = $specialPrice = FALSE;
		$domainClass = DomainFunLib::getDomainClass($domain);
		if($shopType == 1 && $domainClass == 'CN' && DomainFunLib::isCnDomain($domain) && $year > 2) //中文.cn
		{
			$year = 2;
		}
		else if($shopType == 1 && DomainOpenLib::tmpFuncOpenCheck(FALSE,'topActivity') && $domainClass =='TOP')
		{
			$year = 1;
		}
		else if($shopType == 1 && DomainOpenLib::tmpFuncOpenCheck(FALSE,'wangActivity') && $domainClass =='WANG')
		{
			$year = 1;
		}
		else if($shopType == 1 && DomainOpenLib::tmpFuncOpenCheck(FALSE,'netActivity') && $domainClass =='NET')
		{
			$year = 1;
		}
		else if($shopType == 1 && DomainOpenLib::tmpFuncOpenCheck(FALSE,'chinaActivity') && $domainClass =='中国')
		{
			$year = 1;
		}
		else if($shopType == 1 && DomainOpenLib::tmpFuncOpenCheck(FALSE,'companyActivity') && $domainClass =='公司')
		{
			$year = 1;
		}
		else if($shopType == 1 && DomainOpenLib::tmpFuncOpenCheck(FALSE,'internetActivity') && $domainClass =='网络')
		{
			$year = 1;
		}
		else if($shopType == 1 && DomainOpenLib::tmpFuncOpenCheck(FALSE,'cnnet') && ($domainClass =='NET' || $domainClass =='CN'))//已经下架
		{
			$specialPrice = TRUE;
			$remark = $domainClass == 'NET' ? 'app注册NET优惠' : 'app注册CN优惠';
			$year = 1;
		}
		else if($shopType == 1 && DomainOpenLib::tmpFuncOpenCheck(FALSE,'clubActivity') && $domainClass =='CLUB')
		{
			$year = 1;
		}
		//vip只允许注册一年
		else if($shopType == 1 && $domainClass =='VIP')
		{
			$year = 1;
		}
		else
		{
			//光棍节价格跟珍品域名价格只对app
			if(\common\Common::getRequestUser() =='api')
			{
				$specialPrice = $this->checkTwoElevent($domain, $shopType,18);
				if(FALSE !== $specialPrice)
				{
					$remark = 'app注册CN优惠';
					$year = 1;
				}
				else if(FALSE !==$this->getTopDomainPrice($domain, $shopType))
				{
					$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'wangactive');
					if($domainClass!=$conf->huodong_ltd)
					{
						$year = 1;
					}
					$remark = $this->remark;
					$specialPrice = $this->price;
				}
			}		
		}
		return array('year'=>$year,'remark'=>$remark,'specialPrice'=>$specialPrice);
	}
	
	/**
	 * 双11域名优惠价格
	 */
	public  function checkTwoElevent($domain,$shopType,$price)
	{
		if(\lib\manage\common\DomainFunLib::getDomainClass($domain)!='CN' || $shopType!=1)
		{
			return FALSE;
		}
		if(time()>=strtotime('2016-03-31 10:00:00') && time()<=strtotime('2016-06-01 23:59:59'))
		{
			return $price;
		}
		return FALSE;
	}
	
	/**
	 * cc活动域名判断
	 * @param stirng $domain
	 * @param int $shopType
	 * @return boolean|boolean|string
	 */
	private function ccDomainDone($domain, $shopType)
	{
		$domainClass = DomainFunLib::getDomainClass($domain);
		if(!in_array($shopType, array(2, 3)) || !DomainOpenLib::tmpFuncOpenCheck(FALSE,'ccActivity') || $domainClass !='CC')
		{
			return FALSE;
		}
		// cc域名优惠判断
		if(!$level = $this->checkIsCCActivity($domain))
		{
			return FALSE;
		}
		// 判断本年度是否已经优惠过
		if(!$this->checkCCActivityIsCousumption($domain))
		{
			return FALSE;
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'activity');
		$ccActivityPrice = $conf->activityprice->cc->toArray();
		return isset($ccActivityPrice[$level]) ? sprintf("%.2f", $ccActivityPrice[$level]) : FALSE;
	}
	
	/**
	 * 判断是否cc活动域名
	 */
	private function checkIsCCActivity($domain)
	{
		$domainStr = \lib\manage\common\DomainFunLib::getDomainBody($domain);
		if(strlen($domainStr) > 5)
		{
			return FALSE;
		}
		// 4数字、3字母 等级为1
		if(preg_match('/^[0-9]{1,4}$/', $domainStr) || preg_match('/^[a-z]{1,3}$/i', $domainStr))
		{
			return 1;
		}
		// 五数字无 0,4、4声母 等级为2
		else if(preg_match('/^[12356789]{5}$/', $domainStr) || preg_match('/^[BCDFGHJKLMNPQRSTWXYZ]{4}$/i', $domainStr))
		{
			return 2;
		}
		return FALSE;
	}
	
	/**
	 * 检查cc域名本年度是否有消费
	 * @param string $domain
	 * @param  boolean  true未消费 false已经消费
	 */
	private function checkCCActivityIsCousumption($domain)
	{
		$logic = new \logic\manage\finance\OrderLogic();
		$params = array('remark' => '.cc特殊优惠','limit' => 1,'inOrderType' => '2,3', 'domain' => $domain, 'checkYear' => '2016', 'inOrderStatus' => '1,3');
		if($result = $logic->getOrderListByContion($params, false))
		{
			return FALSE;
		}
		return TRUE;
	}
	
	/**
	 * 获取域名的businesscode  提供给app这边域名查询的时候使用
	 */
	public static function getDomainBusinessCode($domain)
	{ 
		if(!$domain)
		{
			return FALSE;
		}
		$logic =new \logic\manage\thrift\VspLogic();
		return $logic->getDomainBusinessCodeBatch(is_array($domain) ? $domain : array($domain));
	}
	
	public static function getDomainBase64Code($domain)
	{ 
		if(!$domain)
		{
			return FALSE;
		}
		$logic =new \logic\manage\thrift\VspLogic();
		return $logic->getDomainBase64CodeBatch($domain);
	}
	
	public static function switchclose()
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'vspdomainltd');
		$switch = $conf->switchclose;
		if($switch)
		{
			return true;
		}
		return FALSE;
	}
	
	/**
	 * com活动域名判断
	 * @param stirng $domain
	 * @param int $shopType
	 * @return boolean|boolean|string
	 */
	private function comDomainDone($domain, $shopType)
	{
		$domainClass = DomainFunLib::getDomainClass($domain);
		if(!in_array($shopType, array(2, 3)) || time() > strtotime('2017-12-31 23:59:59') || $domainClass !='COM')
		{
			return FALSE;
		} 
		//得到域名等级
		if(!$level = $this->checkIsComActivity($domain, $shopType))
		{
			return FALSE;
		}
		if($level==1)
		{
			return sprintf("%.2f", 0);
		}
	}
	
	/**
	 * 判断是否com活动域名
	 */
	private function checkIsComActivity($domain, $shopType)
	{
		$domainStr = \lib\manage\common\DomainFunLib::getDomainBody($domain);
		if(strlen($domainStr) > 5)
		{
			return FALSE;
		}
		// 1-3位声母com 、 1-4数字com 且域名过期时间2016年8月15—2016年12月31日 ==>等级1
		if(preg_match('/^[0-9]{1,4}$/', $domainStr) || preg_match('/^[BCDFGHJKLMNPQRSTWXYZ]{1,3}$/i', $domainStr))
		{
			if($shopType == 3)
			{
				$domainManageLogic = new \logic\manage\domain\DomainManageLogic();
				$result = $domainManageLogic->getDomainInfo(array('DomainName' => $domain));
				$expireDate = empty($result["ExpDate"]) ? false : $result["ExpDate"];
				if($expireDate && $expireDate >= '2017-01-01 00:00:00' && $expireDate <= '2017-12-31 23:59:59')
				{
					return 1;
				}
			}
			else 
			{
				return 1;
			}
		}
		return FALSE;
	}

	/**
	 * wang活动域名判断
	 *
	 * @param stirng $domain
	 * @param int $priceType
	 * @return boolean|boolean|string
	 */
	private function wangDomainDone($domain, $priceType)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'wangactive');
		// wang 续费/转入活动 2017 年1月8日00:00:00-10日23:59:59期间
		if(in_array($priceType, array(2, 3)) &&
			 strtoupper(\lib\manage\common\DomainFunLib::getDomainClassAll($domain)) == $conf->huodong_ltd &&
			 time() >= strtotime($conf->huodong_start_time) && time() <= strtotime($conf->huodong_end_time))
		{
			// 四字母.WANG域名
			$domainStr = \lib\manage\common\DomainFunLib::getDomainBody($domain);
			if(strlen($domainStr) != 4 || !preg_match('/^[A-Z]{4}$/i', $domainStr))
			{
				return false;
			}
			// 续费/转入优惠限1年 =》查2017 年1月8日00:00:00-10日23:59:59是否优惠过==>支持多年可以去掉这个条件
			// require_once SYSTEM_LIB_PATH . 'lib/datacenter/DataCenterIn.php';
			// $dc = new DataCenterIn();
			// $recordList=$dc->getData('manage/order/getOrderList', array(..));
			// 所有注册日期在2016 年1月12日00:00:00-3月5日23:59:59期间的
			$redis = \core\RedisLib::getInstance('common');
			$regDate = $redis->get('domain_exp_' . $domain);
			if(!$regDate)
			{
				if($priceType == 2)
				{
					$userLogic = new \logic\manage\whois\WhoisLogic();
					$domainInfo = $userLogic->getWhois($domain);
					if(!empty($domainInfo['RegistrationDate']))
					{
						$regDate = $domainInfo['RegistrationDate'];
						$redis->set('domain_exp_' . $domain, $regDate, 3 * 24 * 3600); // 活动三天
					}
					else // 转入查询过期时间失败
					{
						\core\Log::write($domain, 'cart/wang', 'whois');
						return false;
					}
				}
				else
				{
		            $domainManageLib = new \lib\manage\domain\DomainManageLib();
			    	$domainInfo = $domainManageLib->getDomainInfo(array('DomainName'=>$domain, 'EnameId'=>$this->enameId),'*', true); // 不抛异常
                    if(!empty($domainInfo['RegDate']))
					{
						$regDate = date('Y-m-d H:i:s', strtotime($domainInfo['RegDate']) + 8 * 3600);
						$redis->set('domain_exp_' . $domain, $regDate, 3 * 24 * 3600); // 活动三天
					}
					else // 转入查询过期时间失败
					{
						return false;
					}
				}
			}
			if(!$regDate || $regDate < $conf->huodong_ltd_reg_start_time || $regDate > $conf->huodong_ltd_reg_end_time) // 不符优惠要求
			{
				return false;
			}
			\core\Log::write($domain, 'cart/wang', 'active');
			// 享受续费/转入优惠价：10 元
			return 10.00;
		}
		return false;
	}
}

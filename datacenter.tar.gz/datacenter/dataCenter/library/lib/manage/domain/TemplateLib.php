<?php 
namespace lib\manage\domain;
use core\Response;
use \lib\manage\domain\DomainLogsLib;
use \lib\manage\common\DomainFunLib;
/**
 *  模板相关
 */
class TemplateLib
{
	private $enameId;
	private $mod;
	private $config; 
	public function __construct($enameId = '')
	{ 
		$this->config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$this->enameId = $enameId;
		$this->mod = new \models\manage\domain\TemplateMod();
	}

	/**
	 * 获取域名可以使用的模板
	 */
	public function getUseTemplates($enameId, $type = 'RegistTemplate', $limitOne = FALSE)
	{ 
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'systemplate');
		$sysTemp = $conf->systemTempId->toArray();
		$sysTemp = array('TemplateId' => $sysTemp[0], 'TemplateName'=> $conf->systemTempName, 'TempUserName' => $conf->systemTempName, 'TemplateType' => 0);
		if(!$enameId)
		{
			return array($sysTemp);
		}
		if($type == 'domainRenew')
		{
			return array();
		}
		$return = array();
		//获取默认模板
		$settingMod = new \models\manage\domain\DomainSettingMod();
		$defaultTemp = $settingMod->getSettingByEnameId(array('EnameId' => $enameId));
		if($defaultTemp && isset($defaultTemp[$type]))
		{
			$defaultTempReturn = explode(',', $defaultTemp[$type]);
			$defaultId = $defaultTempReturn[0];
			$defaultTempInfo = $this->getTemplateInfoById($defaultId);
			if($defaultTempInfo && $defaultTempInfo['CnStatus'] == 2 && $defaultTempInfo['CreateTime']>'2012-01-01 00:00:00') 
			{
				$return[] = array('TemplateId' => $defaultId, 'TemplateName'=> $defaultTempInfo['TemplateName'], 'TempUserName' => $defaultTempInfo['TempUserName'],
						'TemplateType' => $defaultTempInfo['TemplateType']);
				if(TRUE == $limitOne)
				{
					return $return;
				}
			}
		}
		// 获取用户可用于CN域名的模板列表
		$cnTemp = $this->mod->getTemplate(
			array('EnameId' => $enameId, 'IsShow' => 1, 'CnStatus' => 2, 'CreateTime' > '2012-01-01 00:00:00', 
				'in' => array('TemplateType' => array(1, 4))),$limitOne ? 1 : 0);
		if($cnTemp)
		{
			foreach($cnTemp as $value)
			{
				if(!empty($return) && $return[0]['TemplateId'] == $value['TemplateId'])
				{
					continue;
				}
				$return[] = array('TemplateId' => $value['TemplateId'], 'TemplateName' => $value['TemplateName'], 
					'TempUserName' => $value['TempUserName'], 'TemplateType' => $value['TemplateType']);
				if(TRUE == $limitOne)
				{
					return $return;
				}
			}
		}
		else
		{
			// 如果存在默认模版的话则不会到这里
			$return[] = $sysTemp;
		}
		return $return;
	}

	public function getTemplateInfoById($tempId)
	{
		return $this->mod->getTempInfoByTempId($tempId);
	}

	public function getTemplateName($templateId, $enameId)
	{
		$tempInfo = $this->mod->getTemplate(array('EnameId' => $enameId, 'TemplateId' => $templateId, 'IsShow' => 1));
		if($tempInfo)
		{
			return $tempInfo[0]['TempUserName'];
		}
		return $tempInfo;
	}
	/**
	 *
	 * 根据模板ID获取模板信息
	 * @param int $templateId
	 * @return string
	 * @author zougc
	 */
	public function getTemplateInfo($templateId)
	{
		$tempInfo = $this->mod->getTemplate(array('EnameId' => $this->enameId, 'TemplateId' => $templateId,
				'IsShow' => 1));
		if($tempInfo)
		{
			return $tempInfo[0];
		}
		return $tempInfo;
	}
	private function formatTemp($tempArray)
	{
		$return = array();
		foreach($tempArray as $templateInfo)
		{
			$return[] = array('TemplateId' => $templateInfo['TemplateId'],
					'TemplateName' => $templateInfo['TemplateName']);
		}
		return $return;
	}
	//根据条件获取模板总数
	public function getTemplateCount($data)
	{
		$res = $this->mod->getTemplateCount($data);
		if($res)
		{
			return $res['sum'];
		}
		return false;
	}
	/**
	 * 对模板状态以及模板的审核状态进行判断
	 * @author gaob
	 */
	public function formatTemplateList($list, $cnnic, $temp)
	{
		if($list)
		{
			$list['CnnicStatus'] = $list['CnStatus'];
			if($list['TemplateType'] == 2 || $list['TemplateType'] == 6) //国际，状态显示为空
			{
				$list['IsAllowModify'] = '1';
				$list['CnnicStatusName'] = '--';
				$list['TypeName'] = '--';
			}
			elseif($list['TemplateType'] == 5) //腾讯模板状态只显示白名单(中文)
			{
				$list['IsAllowModify'] = '0';
				$list['CnnicStatusName'] = '白名单';
				$list['TypeName'] = $temp['5'];
			}
			else //templatetype为1 3 4
			{
				if(strtotime($list['CreateTime']) < strtotime('2012-01-01 00:00:00')) //2012-01-01之前有分中英文个人企业委托模板，之后没有分中英文
				{
					$list['IsAllowModify'] = '0';
					if($list['CnStatus'] == 2) //CnStatus和CdnStatus中一个为2显示白名单 分中英文
					{
						$list['CnnicStatusName'] = $cnnic['2'];
					}
					else if($list['CnStatus'] == 3)
					{
						$list['CnnicStatusName'] = $cnnic['3']; //CnStatus和CdnStatus中一个为3显示审核中
					}
					else if($list['CnStatus'] == 0) //CnStatus和CdnStatus同时为0是未审核
					{
						$list['CnnicStatusName'] = $cnnic['0'];
					}
					else //CnStatus和CdnStatus为01，10，11组合显示失败
					{
						$list['CnnicStatusName'] = $cnnic['1'];
					}
					if($list['RegistrarId'] > 0) //模板名称企业个人委托分中英文显示
					{
						$list['TypeName'] = $temp[$list['TemplateType']];
					}
					else
					{
						$list['TypeName'] = $temp[$list['TemplateType']];
					}
				}
				else //2012-01-01之后
				{
					if($list['CnStatus'] == 1 || $list['CnStatus'] == 4)
					{
						$list['IsAllowModify'] = '1';
					}
				   else 
				   {
				   	$list['IsAllowModify'] = '0';
				    }
					$list['CnnicStatusName'] = ($list['CnStatus'] == 1 || $list['CnStatus'] == 4) ? $cnnic['1'] : $list['CnStatus'] == 0 ? '审核中' : $cnnic[$list['CnStatus']];
					$list['TypeName'] = $temp[$list['TemplateType']];
				}
			}
			// 如果模板名：em_开头不让修改
			if(strpos($list['TemplateName'], 'em_') !== false)
			{
				$list['IsAllowModify'] = '0';
			}
			return $list;
		}
	}
	/**
	 * 2012-05-09 易名信息技术的模板不允许再修改 zougc
	 * @param array $tempInfo
	 * @throws Exception
	 */
	public function checkStatus($tempInfo, $name = FALSE, $company = FALSE)
	{
		if($tempInfo['CnStatus'] == 3)
		{
			throw new \Exception('模板正在审核中,不能修改!', '330015');
		}
		if($tempInfo['CnStatus'] == 0)
		{
			$this->checkCnStatus($tempInfo, $name, $company);
		}
		if($tempInfo['TemplateType'] == 5)
		{
			throw new \Exception('腾讯邮箱模板不能修改!', '330018');
		}
		if($tempInfo['Org'] == "厦门易名信息技术有限公司")
		{
			throw new \Exception('公司名为厦门易名信息技术有限公司的模板不能修改!', '330020');
		}
	}

	private function checkCnStatus($tempInfo, $name = FALSE, $company = FALSE)
	{
		if(!$name || ($tempInfo['TemplateType'] == 1 && !$company))
		{
			throw new \Exception("更新模板失败，请稍后重试!", '330003');
		}
		$st = TRUE;
		if($tempInfo['TemplateType'] == 4)//个人模板的话 如果名称是已经通过认证的就不让提交修改
		{
			foreach($name as $value)
			{
				if($tempInfo['Name'] == $value['Name'])
				{
					$st = FALSE;
					break;
				}
			}
			if(FALSE == $st)
			{
				throw new \Exception('模板正在处理中,不能修改!', '330017');
			}
		}
		if($tempInfo['TemplateType'] == 1)//company 个人和企业信息都通过认证的才不让提交
		{
			$stId = TRUE;
			$stCom = TRUE;
			foreach($name as $value)
			{
				if($tempInfo['Name'] == $value['Name'])
				{
					$stId = FALSE;
					break;
				}
			}
			foreach($company as $value)
			{
				if($tempInfo['Org'] == $value['CompanyName'])
				{
					$stCom = FALSE;
					break;
				}
			}
			if($stId == FALSE && $stCom == FALSE)
			{
				throw new \Exception('模板正在处理中,不能修改!', '330017');
			}
		}
	}

	/**
	 *	检查用户模板名是否存在
	 *	@param string $TempUserName
	 *	@param int $templateId
	 */
	public function checkUserTempNameIsExists($tempUserName, $enameId, $templateId = false)
	{
		$tempInfo = $this->mod->getTemplate(array('TempUserName' => $tempUserName, 'EnameId' => $enameId, 'IsShow' => 1));
		if($tempInfo)
		{
			if($templateId && $tempInfo[0]['TemplateId'] == $templateId)
			{
				return FALSE;
			}
			else
			{
				throw new \Exception('《' . $tempUserName . '》已经存在', '330014');
			}
		}
		else
		{
			return FALSE;
		}
	}
	public function checkUserTemplate($templateId, $enameId, $throw = true)
	{
		$tempInfo = $this->mod->getTemplate(array('TemplateId' => $templateId, 'EnameId' => $enameId, 'IsShow' => 1));
		if(!$tempInfo)
		{
			if($throw)
			{
				throw new \Exception('模板信息错误', '330010');
			}
			else
			{
				return false;
			}
		}
		return $tempInfo[0];
	}
	/**
	 *
	 * 注册模板
	 * @param array $data
	 * @param array $edata
	 * @param int $tempType
	 * @param int $registrarId 是否知道接口ID
	 * @param int $isQQmail 是否腾讯接口
	 */
	public function regDomainTemplate($data, $edata, $tempType = 2, $registrarId = FALSE, $isQQmail = FALSE)
	{
		
		$templateId = 0;
		if(!is_array($data) || (empty($data['firstname']) && empty($data['org'])))
		{
			return false;
		}
		$templateName = $this->getTemplateNameSystem();
		$data['templateName'] = $templateName;
		$addInfo = $this->mod->addCnTemp($data);
		if($addInfo)
		{
			$templateId = $addInfo;
		}
		if($templateId)
		{
			$edata['templateId'] = $templateId;
			$edata['templateName'] = $templateName;
			$addEnInfo = $this->mod->addEnTemp($edata);
			if($addEnInfo)
			{
				$updateDate = array();
				$cnSet = array();
				$interInfo = $this->interfaceRegTemplate('ename.cn', $templateId, $registrarId,FALSE,$tempType);
				$cnSet['RegistrarId'] = $interInfo ? $interInfo : 0;
				$wangluoInfo = $this->interfaceRegTemplate('ename.公司', $templateId, FALSE, $templateName,$tempType);
				$cnSet['CnIdn'] = $wangluoInfo ? $wangluoInfo : 0;
				$orgInfo = $this->interfaceRegTemplate('ename.org', $templateId,FALSE,FALSE,$tempType);
				$updateDate['OrgId'] = $orgInfo ? $orgInfo : 0;
				$asiaInfo = $this->interfaceRegTemplate('ename.asia', $templateId,FALSE,FALSE,$tempType);
				$updateDate['AsiaId'] = $asiaInfo ? $asiaInfo : 0;
				$pwInfo = $this->interfaceRegTemplate('ename.pw', $templateId,FALSE,FALSE,$tempType);
				$updateDate['PwId'] = $pwInfo ? $pwInfo : 0;
				$regidArr = array();
				$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'systemplate');
				foreach($conf->regidInternet->toArray() as $key => $value)
				{
					array_push($regidArr, $this->interfaceRegTemplate('ename.' . strtolower($key), $templateId,FALSE,FALSE,$tempType));
				}
				$this->addTemplateExt($templateId, $data['enameId'], $regidArr);
				$this->updateTempalte(array('TemplateId' => $templateId), $cnSet, array());
				$this->updateTempalte(array('TemplateId' => $templateId), array(), $updateDate);
				return $templateId;
			}
			else
			{
				$this->mod->delCntemp($templateId);
				\core\Log::write('创建模板失败，删除模板,ID:' . $templateId . ',enameId' . $data['enameId'], $this->config->domain->logFolder);
				return false;
			}
		}
		return FALSE;
	}
	public function updateTempalte($where, $setCn, $setEn)
	{
		if(empty($setCn) && empty($setEn))
		{
			return true;
		}
		if($setCn)
		{
			$info = $this->mod->updateTemplate($where, $setCn);
			if($info)
			{
				return TRUE;
			}
		}
		if($setEn)
		{
			$info = $this->mod->updateTemplate($where, $setEn, true);
			if($info)
			{
				return true;
			}
		}
		$msg = $setCn ? $setCn['RegistrarId'] : '';
		$msg .= $setEn ? implode(',', $set) : '';
		\core\Log::write('模板注册成功, 更新本地库失败,接口地址：' . $msg . ',templateId:' . $where['TemplateId'] . ',file:DomainTemplateLib', $this->config->domain->logFolder, '');
		return false;
	}
	/**
	 *
	 * 获取16位模板名
	 */
	public function getTemplateNameSystem()
	{
		$templateName = $this->config->template->name->rule;
		$chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
		$checkLen = strlen($chars)-1;
		for($i = 0;$i < 10;$i++)
		{
			$templateName .= substr($chars, mt_rand(0, $checkLen), 1);
		}
		return $templateName;
	}

	/**
	 * 汉字转拼音
	 * @param string $chinese
	 */
	public function toPinyin($chinese)
	{
		$chToPy = new \common\chtopy\ChineseToPinyin();
		if(!isset($chinese) || !$chinese)
		{
			return '';
		}
		return $chToPy->toPinyin($chinese);
	}
	/**
	 * 根据模板的类型到对应的接口修改修改模板信息
	 * 如果同时到2个以上的接口修改信息，只要其中一个修改成功，则认为操作成功
	 * @param int $templateType
	 * @param int $templateId
	 * @param int $registrarId
	 * @param int $cnIdn
	 * @return boolean
	 */
	public function updateUserTemplate($templateType, $templateId, $registrarId, $enameid, $name = false,
			$company = false, $CnIdn = false)
	{
		$result = false;
		$enInfo = $this->mod->getEnTemplateByTemplateId($templateId);
		$result = $this->changeUserAllTemplate($enInfo, $enameid);
		if($templateType != 2)
		{
			if($registrarId)
			{
				$result = $this->updateTemplateApi($templateId, 'ename.cn', $registrarId);
			}
			if($CnIdn)
			{
				$resultCom = $this->updateTemplateApi($templateId, 'ename.公司', $registrarId, $name, $company, $CnIdn);
				$result = $result ? $result : ($resultCom ? $resultCom : $result);
			}
			$result = $result ? $result : (isset($resultCom) && $resultCom ? $resultCom : $result);
		}
		return $result;
	}
	
	/**
	 * 根据模板的类型到对应的接口修改修改模板信息
	 * 如果同时到2个以上的接口修改信息，只要其中一个修改成功，则认为操作成功
	 * @param int $templateType
	 * @param int $templateId
	 * @param int $registrarId
	 * @param int $cnIdn
	 * @return boolean
	 */
	public function updateUserTemplateNew($templateType, $templateId, $registrarId, $enameid, $name = false,
		$company = false, $CnIdn = false)
	{
		$enResult = FALSE;
		$cnResult = FALSE;
		$enInfo = $this->mod->getEnTemplateByTemplateId($templateId);
		$enResult = $this->changeUserAllTemplate($enInfo, $enameid);
		if($templateType != 2)
		{
			if($registrarId)
			{
				$cnResult = $this->updateTemplateApi($templateId, 'ename.cn', $registrarId);
			}
			if($CnIdn)//公司网络不管
			{
				$this->updateTemplateApi($templateId, 'ename.公司', $registrarId, $name, $company, $CnIdn);
			}
		}
		return array($enResult,$cnResult);
	}	
	
	public function changeUserAllTemplate($enTemp, $enameId)
	{
		$upSuccess = FALSE;
		if($enTemp['AsiaId'] && $this->updateTemplateApi($enTemp['TemplateId'], 'ename.asia', $enTemp['AsiaId']))
		{
			$upSuccess = true;
		}
		if($enTemp['OrgId'] && $this->updateTemplateApi($enTemp['TemplateId'], 'ename.org', $enTemp['OrgId']))
		{
			$upSuccess = true;
		}
		if($enTemp['PwId'] && $this->updateTemplateApi($enTemp['TemplateId'], 'ename.pw', $enTemp['PwId']))
		{
			$upSuccess = true;
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'systemplate');
		foreach($conf->regidInternet->toArray() as $key => $value)
		{
			if($this->getTemplateExt($enTemp['TemplateId'], $enameId, $value))
			{
				if($this->updateTemplateApi($enTemp['TemplateId'], 'ename.' . strtolower($key), $value))
				{
					$upSuccess = true;
				}
			}
		}
		if($enTemp['Webnic'])
		{
			$domainManageLib = new DomainManageLib();
			if($domainManageLib->getTemplateLinkDomain($enTemp['TemplateId'], $enTemp['Webnic'], $enameId))
			{
				$upSuccess = true;
			}
		}
		return $upSuccess;
	}

	public function updateTemplateApi($templateId, $domain, $resistarId, $identity = FALSE, $company = FALSE,
			$CnIdn = FALSE)
	{
		if(in_array($domain, array('ename.公司', 'ename.网络')) && $CnIdn)
		{
			$resistarId = $CnIdn;
		}
		$tempInfo = $this->getTemplateInfo($templateId);
		$locData = $this->templateExtraUpdate($domain, $templateId, $identity, $company, $tempInfo);
		$locData = array_merge($locData,$this->getUpdateCardCode($domain, !empty($_POST['cnname']) ? $_POST['cnname'] : ''));
		$epplib = new \lib\manage\domain\DomainEppLib();
		if($this->enameId ==618264)
		{
			$locData['specialenameid'] = true;
		}
		return $epplib->updateTemplateApi($templateId, $domain, $resistarId, $locData, $tempInfo['TemplateName']);
	}

	/**
	 * 检查org、asia模板
	 * @param int $templateId
	 * @param string $domain
	 * @return boolean
	 */
	public function checkOrgAndAsiaTemplate($templateId, $domain)
	{
		$tempLib = new \lib\manage\domain\TemplateLib();
		$domainLtd = DomainFunLib::getDomainClass($domain);
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'systemplate');
		if(DomainFunLib::checkIsTempTemplate($templateId) || !in_array($domainLtd, array('ASIA', 'ORG', 'TOP', 'PW','WANG')))
		{
			return TRUE;
		}
		$enTempInfo = $tempLib->getEnTemplate($templateId);
		$updateData = array();
		$flag = TRUE;
		if($domainLtd == 'ASIA')
		{
			if(!$enTempInfo['AsiaId'])
			{
				$epp = $this->interfaceRegTemplate('ename.asia', $enTempInfo['TemplateId']);
				$updateData['AsiaId'] = $epp ? $epp : 0;
				$flag = $epp;
			}
		}
		elseif($domainLtd == 'ORG')
		{
			if(!$enTempInfo['OrgId'])
			{
				$epp = $this->interfaceRegTemplate('ename.org', $enTempInfo['TemplateId']);
				$updateData['OrgId'] = $epp ? $epp : 0;
				$flag = $epp;
			}
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'systemplate');
		foreach($conf->regidInternet->toArray() as $key => $value)
		{
			if($key!=$domainLtd)
			{
				continue;
			}
			if(!$this->getTemplateExt($enTempInfo['TemplateId'], $this->enameId, $value))
			{
				$epp = $this->interfaceRegTemplate('ename.' . strtolower($key), $enTempInfo['TemplateId']);
				if($epp)
				{
					$this->addTemplateExt($enTempInfo['TemplateId'], $this->enameId, array($epp));
				}
				$flag = $epp;
			}
		}
		if(!empty($updateData['AsiaId']) || !empty($updateData['OrgId']))
		{
			return $this->setCnAndEnTemplate(array('TemplateId' => $enTempInfo['TemplateId']), '', $updateData);
		}
		return $flag;
	}

	/**
	 * 注册局接口注册模板
	 * @param string $domain
	 * @param string $templateId
	 * @param int $registrarId
	 * @return boolean
	 */
	public function interfaceRegTemplate($domain, $templateId, $registrarId = FALSE, $templateName = FALSE,$tempType = FALSE)
	{
		$epplib = new \lib\manage\domain\DomainEppLib();
		$locData = $this->templateExtraAdd($domain, $templateId);
		$locData = array_merge($locData,$this->cnInterfaceRegLoc($domain));
		$this->addTemplateLoc($locData, $templateId, $templateName);
		return $epplib->interfaceRegTemplate($domain, $templateId, $registrarId, $locData, $templateName,$tempType);
	}
	
	/**
	 * cdnstatus状态更改 资料上传
	 */
	public function addTemplateLoc($locData,$templateId,$templateName)
	{
		if(!empty($locData) && !empty($locData['locType']) && !empty($locData['locNumber']))
		{
			$tempLib = new \lib\manage\domain\TemplateLib();
			$tempLib->updateTemplateInfo(array('TemplateId' => $templateId), array('CdnStatus' => 3));
		}
		if(!empty($locData) && !empty($locData['locType']) && ($locData['locType'] == 'YYZZ' || $locData['locType'] == 'QT'))
		{
			include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
			$sdk = new \ApiSdk();
			$uploadData = array('registrantId' => $templateName, 'img' => $locData['img']);//图片先防空
			\core\Log::write(json_encode($uploadData), 'cronmanage/template', 'upngbosstemp_origin');
			$redis = \core\RedisLib::getInstance('manage');
			if(!$redis->lPush('uploadngtemp',$uploadData))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($templateId, array('memo' => 'upload data failed','param' => $uploadData), 21);
			}
// 			$uploadInfo = $sdk->execSdkFun(6991, $uploadData);
// 			if($uploadInfo['resultCode'] != 6000)
// 			{
// 				\lib\manage\domain\DomainLogsLib::addDomainService($templateId, array('memo' => 'upload data failed',
// 						'param' => $uploadData, 'return' => $uploadInfo), 21);
// 			}
		}
		return true;
	}
	
	private function cnInterfaceRegLoc($domain)
	{
		$return = array();
		if(in_array($domain,array('ename.cn','ename.中国')))
		{
			$return['postalType']= 'loc';
			$identityLib = new \lib\manage\verify\VerifyLib('identity');
			if(!empty($_POST['idCart']))
			{
				$return['cardCode'] = $_POST['idCart'];
			}
			else if(!empty($_POST['cnname']) && empty($_POST['idCart']))
			{
				$identity = $identityLib->getUserVerifyNameInfoById($_POST['cnname']);
				$return['cardCode'] = $identity ? $identity['IdCard'] : '';
			}
		}
		return $return;
	}
	/**
	 * 获取loc参数和cardCode
	 */
	private function getLocIdCode($domain,$identity)
	{
		$return = array();
		if(in_array($domain,array('ename.cn','ename.中国','ename.top','ename.wang')))
		{
			$return = array('postalType'=>'loc');
		}
		if(in_array($domain,array('ename.cn','ename.中国')))
		{
			$return['cardCode'] = $identity ? $identity['IdCard'] : '';
		}
		return $return;
	}
	
	/**
	 * 更新的时候只能通过已经通过认证的信息来
	 */
	private function getUpdateCardCode($domain,$verifyId)
	{
		if($verifyId && in_array($domain,array('ename.cn','ename.中国')))
		{
			$identityLib = new \lib\manage\verify\VerifyLib('identity');
			$identity = $identityLib->getUserVerifyNameInfoById($verifyId);
			return array('cardCode'=>$identity ? $identity['IdCard'] : '','postalType' => 'loc');
		}
		return array();
	}
		
	/**
	 * 用户自己自己写的或者选择认证的
	 */
	private function getCardCode()
	{
		$cardCode = '';
		$verifyLib = new VerifyInterfaceLib($this->enameId);
		//有认证的以认证为准
		if(!empty($_POST['cnname']) && empty($_POST['firstName1']))
		{
			$identity = $verifyLib->getUserVerifyIdentityInfoById($_POST['cnname']);
			return  $identity ? $identity['IdCard'] : $cardCode;
		}
		if(!empty($_POST['idCart1']))
		{
			return $_POST['idCart1'];
		}
		return $cardCode;
	}	
	
	/**
	 * 添加模版的时候，公司网络后缀联系人实名扩展信息接口
	 */
	private function templateExtraAdd($domain, $templateId)
	{
		if($domain == 'ename.top' || $domain =='ename.wang' || $domain == 'ename.vip' || $domain == 'ename.club')
		{
			return array('postalType'=>'loc');
		}
		if(!in_array($domain, array('ename.公司', 'ename.网络')))
		{
			return array();
		}
		$tempInfo = $this->getTemplateInfo($templateId);
		if(empty($tempInfo) || !in_array($tempInfo['TemplateType'], array(1,4,2)))
		{
			return array();
		}
		$locInfo = array('postalType' => 'loc', 'locNumber' => '', 'locType' => '');//参数必须传
		$companyLib = new \lib\manage\verify\VerifyLib('company');
		$identityLib = new \lib\manage\verify\VerifyLib('identity');
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'verify');
		if($tempInfo['TemplateType'] == 1)//企业
		{
			if(!empty($_POST['cnorg']) && !empty($_POST['cnname']) && empty($_POST['firstName']) && empty($_POST['companyName']))
			{
				$org = $companyLib->getUserVerifyCompanyInfoById($_POST['cnorg']);
				if(!$org)
				{
					\core\Log::write('查找企业或者身份认证失败,' . $tempInfo['TemplateId'] . ',' . $_POST['cnorg'], 'template');
					return $locInfo;
				}
				$imgArr = array($conf->verify->upload_image_org . $org['LicenseImg']);
				return array('postalType' => 'loc',
						'locType' => $org['LicenseType'] == 1 ? 'ORG' : ($org['LicenseType'] == 2 ? 'YYZZ' : 'QT'),
						'locNumber' => $org['License'], 'img' => $imgArr);
			}
		}
		else
		{
			//个人
			if(!empty($_POST['cnname']) && empty($_POST['firstName']))
			{
				$identity = $identityLib->getUserVerifyNameInfoById($_POST['cnname']);
				if(!$identity)
				{
					\core\Log::write('查找企业或者身份认证失败,' . $tempInfo['TemplateId'] . ',' . $_POST['cnname'], 'template');
					return $locInfo;
				}
				return array('postalType' => 'loc', 'locType' => 'SFZ', 'locNumber' => $identity['IdCard']);
			}
		}
		return $locInfo;
	}

	private function templateExtraAddNew($domain, $templateId,$templateInfo = FALSE,$org = FALSE,$identity = FALSE)
	{
		if(!in_array($domain, array('ename.公司', 'ename.网络')))
		{
			return array();
		}
		if(empty($templateInfo))
		{
			$tempInfo = $this->getTempInfo($templateId);
		}
		if(empty($tempInfo) || !in_array($tempInfo['TemplateType'], array(1, 4)))
		{
			return array();
		}
		$locInfo = array('postalType' => 'loc', 'locNumber' => '', 'locType' => '');//参数必须传
		$companyLib = new \lib\manage\verify\VerifyLib('company');
		$identityLib = new \lib\manage\verify\VerifyLib('identity');
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'verify');
		if($tempInfo['TemplateType'] == 1)//企业
		{
			if($org)
			{
				$imgArr = array($conf->verify->upload_image_org . $org['LicenseImg']);
				return array('postalType' => 'loc',
						'locType' => $org['LicenseType'] == 1 ? 'ORG' : ($org['LicenseType'] == 2 ? 'YYZZ' : 'QT'),
						'locNumber' => $org['License'], 'img' => $imgArr);
			}
			\core\Log::write('查找企业或者身份认证失败,' . $tempInfo['TemplateId'] . ',' . $tempInfo['Org'], 'template','shimingzhi_push');
			return $locInfo;
		}
		else if($tempInfo['TemplateType'] == 4)
		{
			if(!$identity)
			{
				\core\Log::write('查找企业或者身份认证失败,' . $tempInfo['TemplateId'] . ',' . $tempInfo['Name'], 'template','shimingzhi_push');
				return $locInfo;
			}
			return array('postalType' => 'loc', 'locType' => 'SFZ', 'locNumber' => $identity['IdCard']);
		}
		return $locInfo;
	}
	
	/**
	 * 设置cn、en Template模板表信息
	 * @param array $where
	 * @param array $setCn
	 * @param array $setEn
	 * @return boolean
	 */
	public function setCnAndEnTemplate($where, $setCn, $setEn)
	{
		if(empty($setCn) && empty($setEn))
		{
			return TRUE;
		}
		if($setCn)
		{
			if($this->mod->updateTemplate($where, $setCn))
			{
				return TRUE;
			}
		}
		if($setEn)
		{
			if($this->mod->updateTemplate($where, $setEn, true))
			{
				return TRUE;
			}
		}
		$msg = $setCn ? $setCn['RegistrarId'] : '';
		$msg .= $setEn ? implode(',', $setEn) : '';
		\lib\manage\domain\DomainLogsLib::addDomainOperaterLog($domain, $this->enameId, '模板注册成功，更新本地库失败,接口地址：' . $msg . ',TemplateId:' . $where['TemplateId'], 21);
		return FALSE;
	}

	
	public function getTempInfo($tempId)
	{ 
		$tempList = $this->mod->getTemplate(array('TemplateId' => $tempId));
		return $tempList ? $tempList[0] : FALSE;
	}

	/**
	 * 根据enameId获取默认模板
	 */
	public function getDefaultTemplate($enameid)
	{ 
		$setMod = new \models\manage\domain\DomainSettingMod();
		$info = $setMod->getSettingByEnameId(array('EnameId' => $enameid));
		if($info)
		{
			$regist = explode(',', $info['RegistTemplate']);
			$transferIn = explode(',', $info['TransferInTemplate']);
			$push = explode(',', $info['PushTemplate']);
			$trade = explode(',', $info['TradeTemplate']);
			return array('regist' => $regist[0], 'transfer' => $transferIn[0], 'push' => $push[0], 'trade' => $trade[0]);
		}
		else
		{
			return array('regist' => '', 'transfer' => '', 'push' => '', 'trade' => '');
		}
	}
	/**
	 * 更新域名对应的用户模板名
	 * @param int $templateId
	 * @param string $newTempUsreName
	 * @return boolean
	 */
	public function updateDomainTempUserName($templateId, $newTempUsreName, $enameId)
	{
		$domainManageLib = new \lib\manage\domain\DomainManageLib();
		return $domainManageLib->setDomainInfo(array('TemplateId' => $templateId, 'EnameId' => $enameId), array(
				'TempUserName' => $newTempUsreName));
	}

	/**
	 *	检查用户模板是否存在，并返回模板名和模板类型
	 *	@param int $templateId
	 *	@param string $domain
	 * @return array|boolean
	 */
	public function checkAndGetTemplate($templateId, $domain)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'systemplate');
		if(DomainFunLib::checkIsTempTemplate($templateId))
		{
			return array('TempUserName' => $conf->systemTempName, 'TemplateType' => 0);
		}
		$params = array('TemplateId' => $templateId, 'IsShow' => 1);
		$tempInfo = $this->mod->getTemplate($params, 1);
		if(!$tempInfo)
		{
			throw new \Exception('模板信息获取失败', 330001);
		}
		return $tempInfo[0];
	}

	/**
	 * 根据模板id获取模板英文信息
	 * @param int $templateId
	 * @throws \Exception
	 * @return array
	 */
	public function getEnTemplate($templateId)
	{
		$info = $this->mod->getEnTemplateByTemplateId($templateId);
		if($info)
		{
			return $info;
		}
		throw new \Exception('获取英文模板信息失败', 330002);
	}

	/**
	 * 注册成功的时候模版域名格式+1
	 * 过户 -1
	 */
	public function setTempDomainCount($templateId, $operation = '+')
	{ 
		if ($operation != '+' && $operation != '-') 
		{
			return false;
		}
		$tempInfo = $this->getTempInfo($templateId);
		if($tempInfo)
		{
			$operation = $operation == '+' ? true : false;
			return $this->mod->setTemplateLinkCount($templateId, $operation);
		}
		return false;
	}

	/**
	 * 查看模版下是否有违规锁定的域名
	 */
	public function checkTemplateEdit($templateId)
	{
		$mod = new \models\manage\domain\DomainsMod();
		$domainList = $mod->getDomainList(array('EnameId' => $this->enameId, 'TemplateId' => $templateId));
		if($domainList)
		{
			foreach($domainList as $domainInfo)
			{
				if($domainInfo['DomainMyStatus'] == 9)
				{
					throw new \Exception("操作失败，请联系客服", "330021");
				}
				if($domainInfo['DomainMyStatus'] == 7)
				{
					throw new \Exception("该模板下有被锁定的域名，暂时无法更改模板信息", "330022");
				}
				if($domainInfo['DomainMyStatus'] == 5)
				{
					throw new \Exception("该模板下有正在转出的域名，暂时无法更改模板信息", "330023");
				}
			}
		}
		return TRUE;
	}

	public function updateTemplateInfo($where, $set)
	{
		$updateInfo = $this->mod->updateTemplate($where, $set);
		if(!$updateInfo)
		{
			$domain = isset($where['TemplateId']) ? $where['TemplateId'] : 'tempid';
			DomainLogsLib::addDomainService($domain, array('memo' => 'update error',
					'param' => array($where, $set)), 21);
		}
		return true;
	}

	/**
	 * 模版更新的时候 公司网络添加信息
	 */
	private function templateExtraUpdate($domain, $templateId, $name, $company, $tempInfo)
	{
		if($domain == 'ename.top' || $domain == 'ename.wang' || $domain == 'ename.club' || $domain == 'ename.vip')
		{
			return array('postalType'=>'loc');
		}
		if(!in_array($domain, array('ename.公司', 'ename.网络')) || empty($tempInfo) || !in_array($tempInfo['TemplateType'], array(
				1, 2,4)))
		{
			return array();
		}
		$locInfo = array('postalType' => 'loc', 'locType' => '', 'locNumber' => '');
		if($this->checkIsUploadWhite($tempInfo, $name, $company) && $tempInfo['CnStatus'] == 0 && $tempInfo['CdnStatus'] == 0)
		{
			$locInfo = $this->getLocInfo($tempInfo, $name, $company);
		}
		return $locInfo;
	}

	/**
	 * 允许提交白名单的情况
	 */
	public function checkIsUploadWhite($tempInfo, $name, $company,$upCnStatus = TRUE)
	{
		if(!$name || ($tempInfo['TemplateType'] == 1 && !$company))
		{
			return FALSE;
		}
		$isUpload = FALSE;
		//个人模板的话 如果都是相同的认证并且状态是叉叉的 并且更新成功的可以提交白名单
		//个人模板的话 如果不是相同的认证 并且状态是 未审核的 则可以提交白名单
		if($tempInfo['TemplateType'] == 4)
		{
			foreach($name as $k => $value)
			{
				if($tempInfo['Name'] != $value['Name'] && $tempInfo['CnStatus'] == 0)//实际上走不到这里一般情况下
				{
					$isUpload = true;
					break;
				}
				if($tempInfo['CnStatus'] == 1)//相同的话是叉叉的也可以提交---叉叉就可以 可以不用管相同不相同 配合更新
				{
					$isUpload = true;
					break;
				}
			}
			return $isUpload && $upCnStatus;//并且接口更新是成功的
		}
		//企业模板的话 类似
		if($tempInfo['TemplateType'] == 1)//两者不能都相同
		{
			$sfzStatus = FALSE;
			foreach($name as $k => $value)
			{
				if($tempInfo['Name'] != $value['Name'] && $tempInfo['CnStatus'] == 0)
				{
					$sfzStatus = true;
					break;
				}
				if($tempInfo['CnStatus'] == 1)//叉叉的可以
				{
					$sfzStatus = true;
					break;
				}
			}
			$qyStatus = FALSE;
			foreach($company as $k => $value)
			{
				if($tempInfo['Org'] != $value['CompanyName'] && $tempInfo['CnStatus'] == 0)
				{
					$qyStatus = true;
					break;
				}
				if($tempInfo['CnStatus'] == 1)//叉叉可以
				{
					$qyStatus = true;
					break;
				}
			}
			if($sfzStatus && $qyStatus && $upCnStatus)
			{
				return true;
			}
			if($upCnStatus && $qyStatus && !$sfzStatus)
			{
				return true;
			}
			if($upCnStatus && !$qyStatus && $sfzStatus)
			{
				return true;
			}
		}
		return FALSE;
	}

	/**
	 * 获取loc数据
	 */
	private function getLocInfo($templateInfo, $name, $company)
	{
		$return = array('postalType' => 'loc', 'locType' => '', 'locNumber' => '');
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'verify');
		if($templateInfo['TemplateType'] == 1)
		{
			foreach($company as $comInfo)
			{
				if($comInfo['CompanyName'] == $templateInfo['Org'] && $comInfo['VerifyStatus'] == 2)
				{
					$img = array($conf->verify->upload_image_org . $comInfo['LicenseImg']);
					$return = array('postalType' => 'loc',
							'locType' => $comInfo['LicenseType'] == 1 ? 'ORG' : ($comInfo['LicenseType'] == 2 ? 'YYZZ' : 'QT'),
							'locNumber' => $comInfo['License'], 'img' => $img);
					break;
				}
			}
		}
		else
		{
			foreach($name as $idInfo)
			{
				if($idInfo['Name'] == $templateInfo['Name'] && $idInfo['VerifyStatus'] == 2)
				{
					$return = array('postalType' => 'loc', 'locType' => 'SFZ', 'locNumber' => $idInfo['IdCard']);
					break;
				}
			}
		}
		return $return;
	}

	public function addTemplateExt($templateId, $enameId, $regidArr)
	{
		if(empty($templateId) || empty($regidArr) || empty($enameId))
		{
			return FALSE;
		}
		$regidArr = !is_array($regidArr) ? explode(",", $regidArr) : $regidArr;
		$st = FALSE;
		foreach($regidArr as $regid)
		{
			if($regid)
			{
				if(!$this->mod->addExtTemplate(array('templateId' => $templateId, 'enameId' => $enameId,
						'registrar' => $regid)))
				{
					DomainLogsLib::addDomainService($templateId, array('memo' => 'add ext failed dc', 'regid' => $regid), 21);
				}
				else
				{
					$st = true;
				}
			}
		}
		return $st;
	}

	/**
	 * 更新域名扩展数据(暂时可能不需要)
	 */
	public function setTemplateExt($where, $set)
	{
		return $this->mod->setExtTemplate($where, $set);
	}

	public function getTemplateExt($templateId, $enameId = FALSE, $regid = FALSE)
	{
		return $this->mod->getExtTemplateById($templateId, $enameId, $regid);
	}

	public function checkRegTemplate($domain, $templateId)
	{
		$templateInfo = $this->mod->getTempInfoByTempId($templateId);
		if(!$templateInfo)
		{
			return FALSE;
		}
		if(\lib\manage\common\DomainFunLib::isChinaDomain($domain))
		{
			return $templateInfo['CnStatus'] == 2;
		}
		return $templateInfo;
	}
	
	/**
	 * 兼容下旧的模板过户的信息
	 * @param unknown $domain
	 * @param unknown $templateId
	 * @param string $registrarId
	 * @param string $templateName
	 */
	public function interfaceRegTemplateNew($domain, $templateId, $registrarId = FALSE, $templateInfo = FALSE)
	{
		$epplib = new \lib\manage\domain\DomainEppLib();
		$verifyInfoArr = $this->getVerifyInfoTemplate($domain,$templateInfo);//获取认证信息
		$locData = $this->templateExtraAddNew($domain, $templateId,$templateInfo,$verifyInfoArr[0],$verifyInfoArr[1]);//公司网络获取loc
		$locData = array_merge($locData,$this->getLocIdCode($domain,$verifyInfoArr[1]));
		return $epplib->interfaceRegTemplate($domain, $templateId, $registrarId, $locData, $templateInfo['TemplateName']);
	}
	
	/**
	 * 获取个人企业认证信息
	 * @param unknown $domain 
	 * @param unknown $templateInfo
	 */
	private function getVerifyInfoTemplate($domain,$templateInfo)
	{
		if(empty($templateInfo) || !in_array($domain,array("ename.cn","ename.top","ename.wang","ename.公司","ename.网络")))
		{
			return array(FALSE,FALSE);
		}
		if($templateInfo['TemplateType'] == 1)
		{
			$companyLib = new \lib\manage\verify\VerifyLib('company');
			$verifyCom = $companyLib->getVerfifyCompany($templateInfo['EnameId'],$templateInfo['Org']);
			$verifyCom = empty($verifyCom[0]) ? array() : $verifyCom[0];
			return array($verifyCom,FALSE);
		}
		else if($templateInfo['TemplateType'] == 4)
		{
			$identityLib = new \lib\manage\verify\VerifyLib('identity');
			$verifyId = $identityLib->getVerfifyIdentity($templateInfo['EnameId'],$templateInfo['Name']);
			$verifyId = empty($verifyId[0]) ? array() : $verifyId[0];
			return array(FALSE,$verifyId);
		}
		return array(FALSE,FALSE);
	}
	
	public function updateTemplateRegid($enameId,$templateId,$regid)
	{
		if(!$regid)
		{
			return FALSE;
		}
		$where = array('TemplateId'=>$templateId);
		$st = FALSE;
		switch ($regid) {
			case 1:
				$st = $this->setCnAndEnTemplate($where, array('RegistrarId'=>1), array());
				break;
			case 71:
				$st = $this->setCnAndEnTemplate($where, array('CnIdn'=>71), array());
				break;
			case 31:
				$st = $this->setCnAndEnTemplate($where, array(),array('AsiaId'=>31));
				break;
			case 41:
				$st = $this->setCnAndEnTemplate($where, array(),array('OrgId'=>41));
				break;
			case 51:
				$st = $this->setCnAndEnTemplate($where, array(),array('PwId'=>51));
				break;
			case 82:
				$st = $this->addTemplateExt($templateId, $enameId, 82);
				break;
			case 86:
				$st = $this->addTemplateExt($templateId, $enameId, 86);
				break;
		}
		\core\Log::write("updatetempinterface,{$enameId},{$templateId},{$regid},{$st},","template","shimingzhi_push_update");
		return $st;
	}
	
	public static function getTemplateNameVsp($templateId)
	{
		$mod = new \models\manage\domain\TemplateMod();
		$tempInfo =$mod->getTemplate(array('TemplateId' => $templateId));
		if($tempInfo)
		{
			return $tempInfo[0]['TemplateName'];
		}
		return '';
	}
}

<?php 
namespace lib\manage\domain;
use lib\manage\domain\DomainLogsLib;
use \lib\manage\newqueue\QueueTaskLib;
class DomainRestoreLib
{
	private $mod;
	public function __construct()
	{
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$this->mod = new \models\manage\domain\DomainRestoreMod();
		$this->sdk = new \ApiSdk();
	}

	/**
	 * 获取详情 
	 */
	public function domainRestoreDetail($id)
	{ 
		return $this->mod->getDomainRestoreDetail($id);
	}

	/**
	 * 更新赎回信息
	 */
	public function domainRestoreUpdate($where, $update)
	{ 
		$st = $this->mod->updateDomainRestore($where, $update);
		if(!$st)
		{
			DomainLogsLib::addDomainService($domain, array('memo' => 'updaterestoreinfo', 'where' => $where,
					'set' => $update), 32);
		}
		return $st;
	}

	/**
	 * 域名还原dns操作 
	 */
	public function domainDnsReback($domain, $registrarId, $domainId, $enameId, $dnsType, $extInfo)
	{
		$infoDnsData = array();
		$infoDnsData['enameId'] = $enameId;
		if($dnsType == 0 || $dnsType == 4)//iidns or ename.net
		{
			$infoDnsData['dnsId'] = 1;
			$infoDnsData['dns'] = array('dns1' => 'dns1.iidns.com');
			$infoDnsData['dnsType'] = 0;
		}
		else
		{
			if($extInfo)
			{
				$dns = explode(',', $extInfo['Dns']);
				$newData = array();
				foreach($dns as $k => $v)
				{
					$newData[$k + 1] = $v;
				}
				unset($dns);
				$infoDnsData['dnsId'] = 0;
				$infoDnsData['dns'] = $newData;
				$infoDnsData['dnsType'] = 3;
			}
		}
		$infoDnsData['domain'] = $domain;
		$infoDnsData['registrarID'] = $registrarId;
		$infoDnsData['domainId'] = $domainId;
		$epp = new \lib\manage\domain\DomainEppLib();
		$epp->setDomainDns($domain, $infoDnsData['dnsId'], $infoDnsData['dns'], $registrarId);
	}

	/**
	 * 保留域名赎回
	 * 1等待入库
	 * 2成功
	 * 赎回成功或者等待赎回的可以操作  成功的看下enameid是否时特殊的几个 等待的可以直接操作
	 */
	public function restorePersistDomain($domain,$enameId,$orderId,$registrarId,$regDate,$expDate,$price,$templateId,$tempName)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domainrestore');
		$confirm = array('orderId' => $orderId, 'enameId' => $enameId);
		$persistMod = new \models\manage\domain\DomainPersistMod();
		$persisInfo = $persistMod->getDomainInfo(array('Domain' => $domain, 'in' => array('Status' => array(1, 2))), "*", true, "StorageTime DESC");
		try
		{
			if(empty($persisInfo) || !in_array($persisInfo['EnameId'], explode(',', $conf->persistEnameId)))
			{
				throw new \Exception("域名不在可赎回的enameid下", 313022);//退款
			}
			$domainMod = new \models\manage\domain\DomainsMod();
			$domainExists = $domainMod->getDomainInfo(array('DomainName' => $domain));
			if($domainExists && !in_array($domainExists['EnameId'], explode(',', $conf->persistEnameId)))
			{
				throw new \Exception("域名不在可赎回的enameid下", 313022);//退款
			}
			$sdkDomainInfo = $this->checkDomainInfo($domain, $registrarId, FALSE);
			$regTime = $sdkDomainInfo['data']['createDate'];
			$expTime = $sdkDomainInfo['data']['expireDate'];
			$bakInfo = $this->getDomainBakInfo($domain, $enameId);
			if(strtotime($bakInfo['ExpDate'])<time()- 3600 * 24 * 183)
			{
				throw new \Exception('域名最新所有者已经变更不可赎回', 313011);
			}
			if($persisInfo['Status'] == 1 && $domainExists == FALSE)//待入库且域名不在域名表里
			{
				$addDomainInfo = $this->restoreInDb($domain, $bakInfo, $enameId, $templateId, $registrarId, $regTime, $expTime, '', 0);
				if($addDomainInfo)
				{
					$this->restoreDirectDb($domain, $enameId, strtotime($regTime), strtotime($expTime), 2, 1, $registrarId, $templateId, $tempName, $orderId, $price, 0, '赎回成功');
					$this->persistDomainTempPush($enameId, $domain, $templateId, $bakInfo);
				}
				$restoreStatus = $this->restoreOrderDone($addDomainInfo, $confirm);
				if($addDomainInfo)
				{
					return true;
				}
				throw new \Exception("赎回入库失败,请手动处理", 313016);
			}
			if($persisInfo['Status'] == 2 && $domainExists)//入库成功且域名在域名表里
			{
				if($this->restoreInDbExist($domainExists,$enameId,$templateId,$bakInfo))
				{
					$this->restoreDirectDb($domain, $enameId, strtotime($regTime), strtotime($expTime), 2, 1, $registrarId, $templateId, $tempName, $orderId, $price, 0, '赎回成功(保留成功)');
					$this->restoreOrderDone(true, $confirm);
					$this->persistDomainTempPush($enameId, $domain, $templateId, $bakInfo,$domainExists['TemplateId'],$domainExists['TempUserName']);
					$this->restoreSendMailMsg($domain, $enameId, TRUE, 1);
					$this->restoreSendMailMsg($domain, $enameId, TRUE, 2);
					$this->restoreRefund($domain,$persisInfo['EnameId'], $registrarId);
					return true;
				}
				throw new \Exception("域名信息更改失败,请重信尝试", 313023);
			}
			throw new \Exception("域名不在保留表或者赎回类型错误", 313024);
		}
		catch(\Exception $e)
		{
			$this->restoreOrderDone(FALSE, $confirm);
			$this->restoreSendMailMsg($domain, $enameId, FALSE, 1);
			$this->restoreSendMailMsg($domain, $enameId, FALSE, 2);
			DomainLogsLib::addDomainService($domain, array('memo' => 'restore failed', 'error' => $e->getMessage(),
					'errorcode' => $e->getCode()), 32);
			throw new \Exception("赎回失败", $e->getCode());//处理的异常不直接显示给用户
		}
	}

	public function restoreRefund($domain,$enameId,$regid)
	{
		$interfaces = new \interfaces\manage\Finance();
		$params = array('enameId'=>$enameId,'domain'=>$domain,'startDate'=>date('Y-m-d H:i:s',strtotime('-3 months')),'endDate'=>date('Y-m-d H:i:s'),'orderStatus'=>1,'orderType'=>13);
		$orderList = $interfaces->getOrderListByContion($params);
		if(!$orderList)
		{
			DomainLogsLib::addDomainService($domain, array('memo' => 'peristorderfailed', 'params' => $params), 32);
			return FALSE;
		}
		$orderInfo = $orderList[0];
		$refund = $interfaces->systemRefund($enameId, $orderInfo['OrderId'],'域名赎回退款');
		DomainLogsLib::addDomainService($domain, array('memo' => 'refund', 'params' => $orderInfo['OrderId'],'return'=>$refund), 32);
		return TRUE;
	}
	
	
	/**
	 * 保留域名模版过户
	 */
	private function persistDomainTempPush($enameId, $domain, $templateId, $domainBak,$oldTemp = FALSE,$oldTempName = FALSE)
	{
		$push = array();
		$push['domain'] = $domain;
		$push['oldTemplateId'] = $oldTemp ? $oldTemp : $domainBak['TemplateId'];//error
		$push['oldTemplateName'] = $oldTempName ? $oldTempName : $domainBak['TempUserName'];
		$push['registrarId'] = $domainBak['RegistrarId'];
		$tempLib = new \lib\manage\domain\TemplateLib();
		$templateInfo = $tempLib->getTempInfo($templateId);
		if(!$templateInfo)
		{
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'systemplate');
			$sysTemp = $conf->systemTempId->toArray();
		}
		$push['tempType'] = $templateInfo ? $templateInfo['TemplateType'] : 0;
		$push['templateId'] = $templateInfo ? $templateId : $sysTemp[0];
		$push['newTemplateName'] = $templateInfo ? $templateInfo['TempUserName'] : '临时模板';
		try
		{
			$queueLib = new \logic\manage\newqueue\QueueLogic();
			$result = $queueLib->addQueueTask(array('Function' => 'template_push', 'EnameId' => $enameId, 'Data' => array($push), 'Priority' => 5));
		}
		catch (\Exception $e)
		{
			DomainLogsLib::addDomainService($domain, array('memo' => 'temp_push_persist', 'param' => $push, 'res' => $e->getMessage()), 32);
			return false;
		}
		DomainLogsLib::addDomainService($domain, array('memo' => 'temp_push_persist', 'param' => $push,
				'res' => $result), 32);
		return $result;
	}

	/**
	 * 域名存在我公司数据库赎回--更改主表扩展表enameid 过户 退款
	 */
	public function restoreInDbExist($domainInfo, $enameId,$tempId,$domainback)
	{
		$domain = $domainInfo['DomainName'];
		$domainId = $domainInfo['DomainId'];
		$tempLib = new \lib\manage\domain\TemplateLib();
		$templateInfo = $tempLib->getTempInfo($tempId);
		if(!$templateInfo)
		{
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'systemplate');
			$systempId = $conf->systemTempId->toArray();
			$tempId = $systempId[0];
			$templateInfo['TempUserName'] = $conf->systemTempName;
			$templateInfo['TemplateType'] = 0;
		}
		$where = array('DomainName' => $domain, 'DomainId' => $domainId);
		$set = array('EnameId' => $enameId, 'TemplateId' => $tempId, 'TempUserName' => $templateInfo['TempUserName']);
		$dmLib = new \lib\manage\domain\DomainManageLib();
		if(FALSE == $dmLib->setDomainInfo($where, $set))//更改数据库信息失败
		{
			throw new \Exception("域名信息更改失败,请重新尝试", 313023);
		}
		DomainLogsLib::addDomainService($domain, array('memo' => 'restore,updatedomaininfo', 'where' => $where,
				'set' => $set, 'oldEname' => $domainInfo['EnameId']), 32);
		if(FALSE == $dmLib->setDomainExtInfo(array('DomainId' => $domainId), array(
				'TemplateType' => $templateInfo['TemplateType'], 'EnameId' => $enameId)))
		{
			DomainLogsLib::addDomainService($domain, array('memo' => 'restore,updatedomainext', 'where' => $domainId,
					'set' => $enameId, 'oldEname' => $domainInfo['EnameId']), 32);
			\core\log::write('domainpersist,update domainext failed,domain:' . $domain . ",enameid:$enameId,domainid:$domainId", "domain", "domainrestore");
		}
		$oldExt = $dmLib->getDomainBakExt(array('DomainId'=>$domainback['DomainId']));
		$inter = new \lib\manage\domain\DomainEppLib();
		$inter->setDomainRegisterStatus($domain, $domainInfo['RegistrarId']);
		$this->domainDnsReback($domain, $domainInfo['RegistrarId'], $domainId, $enameId, $domainback['DnsType'], $oldExt);
		return TRUE;
	}

	public function orderReback($domain, $enameId, $orderId)
	{
		$orderLib = new \interfaces\manage\Finance();
		$orderLib->getOrderInfo($enameId, $orderId);
	}

	public function restoreOrderDone($status, $confirm)
	{
		\core\Log::write("域名赎回开始订单处理,status" . $status . ',params:' . json_encode($confirm), 'domainrestore', 'domainrestore');
		$orderLib = new \interfaces\manage\Finance();
		if($status)
		{
			$st = $orderLib->confirmOrder((object) $confirm);
		}
		else
		{
			$st = $orderLib->cancelOrder((object) $confirm);
		}
		if(!$st)
		{
			\core\Log::write("订单确认失败,status:" . $status . ',params:' . json_encode($confirm), 'domainrestore', 'domainrestore');
		}
		return true;
	}

	/**
	 * 获取域名备份表的信息
	 */
	public function getDomainBakInfo($domain, $enameId)
	{
		$domainBakMod = new \models\manage\domain\DomainBakMod();
		$bakInfo = $domainBakMod->getDomainBakOne(array('DomainName' => $domain, 'order' => 'ExpDate desc'), '*', true);
		if(empty($bakInfo) || $bakInfo['ExpDate'] < gmdate('Y-m-d H:i:s', strtotime('-1 years')))
		{
			throw new \Exception('域名备份信息查找失败', 313010);
		}
		if($bakInfo['EnameId'] != $enameId)
		{
			throw new \Exception('域名最新所有者已经变更不可赎回', 313011);
		}
		return $bakInfo;
	}
	
	/**
	 * 用户从前台赎回国际别国内域名
	 */
	public function restoreDomainDirect($domain,$enameId,$orderId,$price,$expDate,$regDate,$registrarId,$templateId,$tempname,$type)
	{
		$confirm = array('orderId' => $orderId, 'enameId' => $enameId);
		try
		{
			$bakInfo = $this->getDomainBakInfo($domain, $enameId);
			$st = TRUE;
			$sdkDomainInfo = $this->checkDomainInfo($domain, $registrarId,$st);
			$domainLtd = \lib\manage\common\DomainFunLib::getDomainClass($domain);
			// org/asia后缀的域名 人工处理
			if(in_array($domainLtd, array('ORG','ASIA')))
			{
				$remark = 'org/asia后缀的域名  人工处理';
				$this->restoreDirectDb($domain, $enameId, strtotime($sdkDomainInfo['data']['createDate']), strtotime($sdkDomainInfo['data']['expireDate']), 0, $type, 
					$registrarId, $templateId, $tempname, $orderId, $price, 0, $remark);
				if($domainLtd == 'ORG')
				{
					return array('flag'=> true,'msg'=> '提交成功，org域名赎回需要客服人工处理，赎回结果会发送站内短信和邮件通知');
				}
				else
				{
					return array('flag'=> true,'msg'=> '提交成功，asia域名赎回需要客服人工处理，赎回结果会发送站内短信和邮件通知');
				}
			}
			if(FALSE == $this->restoreMain($domain, $sdkDomainInfo['data']['updateDate'],$registrarId))
			{
				throw new \Exception("接口赎回发生错误，请稍后尝试", 313021);
			}
			//赎回实际已经成功，只是再次查域名信息的时候失败的先不处理 用旧的过期时间来更新 遇到问题再手动处理
			$newDomainInfo = $this->sdk->execSdkFun(5025, array('domain' => $domain, 'registrarID' => $registrarId));
			DomainLogsLib::addDomainService($domain, array('memo' => 'restore success,5025', 'return' => $newDomainInfo), 32);
			$regtime =  $newDomainInfo['resultCode'] == 5000 ? $newDomainInfo['data']['createDate'] : $sdkDomainInfo['data']['createDate'];
			$exptime = $newDomainInfo['resultCode'] == 5000 ? $newDomainInfo['data']['expireDate'] : $sdkDomainInfo['data']['expireDate'];
			$restoreStatus = $this->restoreInDb($domain, $bakInfo, $enameId, $templateId, $registrarId,$regtime , $exptime, '', 0);
			if(in_array($domainLtd,array('COM','NET')))
			{
				$this->restoreRenew($domain, $registrarId, $enameId);
			}
			$remark = $restoreStatus ? '赎回成功,入库成功' : '赎回成功,入库失败';//入库失败比较特殊，添加一条数据库信息
			$this->restoreOrderDone(true, $confirm);
			$this->restoreDirectDb($domain, $enameId, strtotime($regtime), strtotime($exptime), 2, $type, $registrarId, $templateId, $tempname, $orderId, $price, 0, $remark);
			return true;//只要底层赎回成功就算成功，出现未入库的在人工查理,订单也需要人工处理下
		}
		catch(\Exception $e)
		{
			DomainLogsLib::addDomainService($domain, array('memo' => 'restore failed', 'error' => $e->getMessage(),'errorcode' => $e->getCode()), 32);
			$this->restoreOrderDone(FALSE, $confirm);
			$this->restoreSendMailMsg($domain, $enameId, FALSE, 1);
			$this->restoreSendMailMsg($domain, $enameId, FALSE, 2);
			throw new \Exception('赎回失败，请稍后重试', $e->getCode());//一些错误信息不好直接给用户看，直接提示赎回失败
		}
	}

	/**
	 * 管理员从后台 赎回org asia域名
	 */
	public function restoreDomainAdmin($domain, $enameId, $orderId, $handle, $expDate, $regDate, $registrarId, 
		$templateId, $tempname, $type, $nowStatus, $operStatus, $id)
	{
		$confirm = array('orderId'=> $orderId,'enameId'=> $enameId);
		// 域名后缀判断
		$domainLtd = \lib\manage\common\DomainFunLib::getDomainClass($domain);
		if(! in_array($domainLtd, array('ORG','ASIA')))
		{
			return array('msg'=> '非org asia后缀域名，无法操作','flag'=> false);
		}
		// 域名赎回状态判断
		if($nowStatus != '0')
		{
			return array('msg'=> '状态错误，无法操作','flag'=> false);
		}
		try
		{
			// 审核 赎回成功操作
			if($operStatus == '2')
			{
				$newDomainInfo = $this->sdk->execSdkFun(5025, array('domain' => $domain, 'registrarID' => $registrarId));
				DomainLogsLib::addDomainService($domain, array('memo' => 'restore orgasia,5025', 'return' => $newDomainInfo), 32);
				if($newDomainInfo['resultCode'] != 5000)
				{
					return array('msg'=> '域名信息查找失败,请稍后重试','flag'=> false);
				}
				$regtime = $newDomainInfo['data']['createDate'];
				$exptime = $newDomainInfo['data']['expireDate'];
				$restoreStatus = $this->restoreInDb($domain, $bakInfo, $enameId, $templateId, $registrarId, $regtime, 
					$exptime, '', $handle);
				$remark = $restoreStatus? '赎回成功,入库成功': '赎回成功,入库失败'; // 入库失败比较特殊，添加一条数据库信息
				$msg='赎回成功操作,操作成功';
				$this->restoreOrderDone(true, $confirm);
				// 域名赎回成功通知消息到监控中心
				$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'domain_restore_success')); 
				$amqp->sendMq(array('uid' => $enameId, 'dn' => $domain, 'time' => time(), 'status' => 1));
			}
			// 审核 赎回失败操作
			if($operStatus == '1')
			{
				$remark = '审核不通过，域名未入库';
				$msg='赎回失败操作,操作成功';
				$this->restoreOrderDone(FALSE, $confirm);
				$this->restoreSendMailMsg($domain, $enameId, FALSE, 1);
				$this->restoreSendMailMsg($domain, $enameId, FALSE, 2);
			}
			// 更新赎回信息
			$where = array('Id'=> $id);
			$set = array('Remark'=> $remark,'Handle'=> $handle,'Status'=> $operStatus,'OperationTime'=> time());
			$domainRestoreLib = new \lib\manage\domain\DomainRestoreLib();
			$domainRestoreLib->domainRestoreUpdate($where, $set);
			return array('msg'=> $msg,'flag'=> true);
		}
		catch(\Exception $e)
		{
			return array('msg'=> '操作失败','flag'=> false);
		}
	}
	/**
	 * 5401 提交赎回请求
	 * 5402 提交赎回报告
	 */
	public function restoreMain($domain,$updateTime,$regid)
	{
		$params = array('domain'=>$domain,'registrarID'=>$regid);
		$request = $this->sdk->execSdkFun(5401,$params);
		DomainLogsLib::addDomainService($domain, array('memo' => '5401,request restore', 'param' => $params,'return' => $request), 32);
		if($request['resultCode']!=5000)
		{
			return FALSE;
		}
		$times = strtotime($updateTime);
		$params = array('domain'=>$domain,'registrarID'=>$regid,'preData'=>date('Y-m-d',$times).'T'.date('H:i:s',$times)."Z");
		$report = $this->sdk->execSdkFun(5402,$params);
		DomainLogsLib::addDomainService($domain, array('memo' => '5402,report restore', 'param' => $params,'return' => $report), 32);
		return $report['resultCode'] ==5000;
	}

	/**
	 * 赎回成功后 过期时间小于当前时间的给续费下
	 */
	public function restoreRenew($domain,$regid,$enameId)
	{
		$params = array('domain' => $domain, 'registrarID' => $regid);
		$domainInfo = $this->sdk->execSdkFun(5025, $params);
		DomainLogsLib::addDomainService($domain, array('memo' => 'restore renew,5025', 'param' => $params,'return' => $domainInfo), 32);
		if($domainInfo['resultCode']!=5000)
		{
			return FALSE;
		}
		if(strtotime($domainInfo['data']['expireDate'])<time())
		{
			$interfaces = new \interfaces\manage\Domains();
			$data = array('domain' => $domain, 'year' => 1, 'expDate' => $domainInfo['data']['expireDate'], 'enameId' => $enameId);
			if(!$interfaces->domainRenew($data))
			{
				DomainLogsLib::addDomainService($domain, array('memo' => 'restore renew failed', 'param' => $data), 32);
			}
		}
		return true;
	}
	
	/**
	 * 更新赎回表信息
	 */
	public function updateRestoreInfo($id, $domain, $handle, $status,$newExpTime = FALSE)
	{
		$where = array('Id' => $id);
		$set = array('Handle' => $handle, 'OperationTime' => time());
		$set['Status'] = $status ? 2 : 1;
		$set['Remark'] = $status ? '赎回成功,入库成功' : '赎回成功,入库失败';
		if($newExpTime)
		{
			$set['ExpTime'] = is_numeric($newExpTime) ? $newExpTime : strtotime($newExpTime);
		}
		$update = $this->domainRestoreUpdate($where, $set);
		DomainLogsLib::addDomainService($domain, array('memo' => 'restore,update dbstatus', 'param' => $set,
				'return' => $update), 32);
		if(!$update)
		{
			$message = $status ? "赎回成功,更改数据库信息失败" : "赎回失败,更改数据库信息失败";
			throw new \Exception($message, $status ? 313018 : 313019);
		}
		return true;
	}

	public function restoreDirectDb($domain,$enameId,$regtime,$exptime,$status,$type,$regid,$tempid,$tempname,$orderid,$price,$handle,$remark)
	{
		$insert = array('domain'=>$domain,'enameId'=>$enameId,'regTime'=>$regtime,'expTime'=>$exptime,
				'status'=>$status,'type'=>$type,'registrarId'=>$regid,'templateId'=>$tempid,'operationTime'=>time(),'remark'=>$remark,
				'templateName'=>$tempname,'orderId'=>$orderid,'price'=>$price,'handle'=>$handle);
		if(!$this->mod->addRestoreRecord($insert))
		{
			DomainLogsLib::addDomainService($domain, array('memo' => 'insert data error', 'param' => $insert), 32);
			if(in_array(\lib\manage\common\DomainFunLib::getDomainClass($domain),array('ORG','ASIA')))//ORG ASIA无法直接五脑提示
			{
				throw new \Exception('赎回失败，请稍后重试', 313019);
			}
		}
	}
	
	/**
	 * 域名赎回入库
	 */
	public function restoreInDb($domain, $bakInfo, $enameId, $templateId, $registrarId, $regDate, $expDate, $restoreId,$handle)
	{
		if($this->domainRestoreByBak($domain, $bakInfo, $enameId, $templateId, $registrarId, $regDate, $expDate))
		{
			DomainLogsLib::addDomainService($domain, array('memo' => 'back_domain_dc', 'c' => '赎回域名入库'), 25);
			$tempLib = new \lib\manage\domain\TemplateLib();
			$tempLib->setTempDomainCount($templateId);
			$this->restoreSendMailMsg($domain, $enameId, TRUE, 1);
			$this->restoreSendMailMsg($domain, $enameId, TRUE, 2);
			return true;
		}
		else
		{
			if(empty($restoreId))
			{
				return FALSE;
			}
			$this->domainRestoreUpdate(array('Id' => $restoreId), array('Remark' => '域名注册局赎回成功,入库失败,请手动处理',
						'Handle' => $handle, 'OperationTime' => time()));
			throw new \Exception("赎回成功,入库失败,请手动处理", 313016);
		}
	}

	/**
	 * 查看域名是否可以赎回
	 * 国际国内国别需要看下是否可以赎回
	 */
	public function checkDomainInfo($domain, $registrarId, $throw = true)
	{
		$params = array('domain' => $domain, 'registrarID' => $registrarId);
		$domainInfo = $this->sdk->execSdkFun(5025, $params);
		DomainLogsLib::addDomainService($domain, $domainInfo, 32);
		if($domainInfo['resultCode'] != 5000)
		{
			if(!empty($domainInfo['resultMsg']) && (stripos($domainInfo['resultMsg'], 'out') || stripos($domainInfo['resultMsg'],'busy')))
			{
				throw new \Exception("域名查询接口超时,请稍后尝试", 313012);
			}
			throw new \Exception("接口查询域名失败", 313013);
		}
		$domainRpgStatus = $this->getRgpStatus($domainInfo['data']);
		if(stripos($domainRpgStatus, 'redemptionPeriod') === FALSE)
		{
			if(!$throw)
			{
				return $domainInfo;
			}
			throw new \Exception("域名不在可赎回状态", 313014);
		}
		$domainLib = new \lib\manage\domain\DomainManageLib();
		if($domainLib->getDomainInfo(array('DomainName' => $domain)) && $throw)
		{
			throw new \Exception("域名已经在我司库中,不可赎回", 313015);
		}
		return $domainInfo;
	}


	/**
	 * 赎回结果邮件通知
	 */
	public function restoreSendMailMsg($domain, $enameId, $status, $type)
	{
		$content = array('title' => "易名中国" . $domain . "域名赎回通知");
		$content['content'] = "您提交的域名：$domain 赎回失败，您可以联系客服查询失败原因，联系电话/QQ：4000044400";
		if($status)
		{
			$content['content'] = "尊敬的用户$enameId:<br>您好！<br>您提交的域名：$domain 赎回成功，您可以在ID帐号下<a href='http://www.ename.net/manage/domainlist'>我的域名</a>列表内查看到您赎回的域名最新的到期时间，请注意关注！";
		}
		$queue = new \interfaces\manage\Queue();
		if($type == 1)//msg
		{
			return $queue->sendSiteMsg($enameId, 'any_template_info', $content, 6);
		}
		$lib = new \lib\manage\member\MemberLib();
		$userInfo = $lib->getMemberBaseInfoByEnameId($enameId);
		if(!empty($userInfo['Email']))
		{
			return $queue->sendMail('any_template_info', $userInfo['Email'], $content, 6);
		}
	}

	/**
	 * 域名赎回入库
	 */
	public function domainRestoreByBak($domain, $bakInfo, $enameId, $templateId, $registrarId, $regDate, $expireDate)
	{
		$tempLib = new \lib\manage\domain\TemplateLib();
		$tempInfo = $tempLib->getTempInfo($templateId);
		if(!$tempInfo)
		{
			DomainLogsLib::addDomainService($domain, array('memo' => 'not find template', 'params' => $templateId), 32);
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'systemplate');
			$system = $conf->systemTempId->toArray();
			$tempInfo = $tempLib->getTempInfo($system[0]);
		}
		$productType = \lib\manage\common\DomainFunLib::getDomainProductType($domain);
		$domainLib = new \lib\manage\domain\DomainRegistLib($enameId);
		$regDate = is_numeric($regDate) ? gmdate('Y-m-d H:i:s', $regDate) : $regDate;
		$expireDate = is_numeric($expireDate) ? gmdate('Y-m-d H:i:s', $expireDate) : $expireDate;
		$addDomainInfo = $domainLib->domainInDbBaseTable($domain, $registrarId, $regDate, $expireDate, gmdate("Y-m-d H:i:s"), $enameId, $tempInfo['TempUserName'], $templateId, $productType);
		if($addDomainInfo && is_numeric($addDomainInfo))//扩展
		{
			$domainExtBakMod = new \models\manage\domain\DomainExtBakMod();
			$newDomainExt = array('DomainId' => $addDomainInfo, 'Tooltip' => 1, 'TooltipWay' => '1,2,3', 'Dns' => '',
					'DomainFrom' => 1, 'EnameId' => $enameId, 'DomainIcp' => '',
					'TemplateType' => $tempInfo['TemplateType']);
			$oldDomainExt = FALSE;
			if($bakInfo)
			{
				$oldDomainExt = $domainExtBakMod->getDomainExtBakOne(array('DomainId' => $bakInfo['DomainId']), "*", true);
			}
			if($oldDomainExt)
			{
				$newDomainExt = array('EnameId' => $enameId, 'DomainId' => $addDomainInfo,
						'Tooltip' => $oldDomainExt['Tooltip'], 'TooltipWay' => $oldDomainExt['TooltipWay'],
						'Dns' => $oldDomainExt['Dns'], 'DomainFrom' => $oldDomainExt['DomainFrom'],
						'DomainIcp' => $oldDomainExt['DomainIcp'], 'pwd' => $oldDomainExt['pwd'],
						'TemplateType' => $oldDomainExt['TemplateType']);
			}
			$extMod = new \models\manage\domain\DomainExtMod();
			$extInfo = $extMod->addDomainExt($newDomainExt);
			if(!$extInfo)
			{
				DomainLogsLib::addDomainService($domain, array('memo' => 'add domainext failed',
						'params' => $newDomainExt), 32);
			}
			$inter = new \lib\manage\domain\DomainEppLib();
			$inter->setDomainRegisterStatus($domain, $registrarId);
			$this->domainDnsReback($domain, $registrarId, $addDomainInfo, $enameId, $bakInfo['DnsType'], $newDomainExt);
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
	
	/**
	 * 用户从前台赎回国内域名
	 */
	public function restoreCnDomainDirect($domain,$enameId,$orderId,$price,$expDate,$regDate,$registrarId,$templateId,$tempname)
	{
		$confirm = array('orderId' => $orderId, 'enameId' => $enameId);
		try
		{
			$bakInfo = $this->getDomainBakInfo($domain, $enameId);//备份表信息
			$sdkDomainInfo = $this->checkDomainInfo($domain, $registrarId,FALSE);
			$params = array('domain' => $domain, 'registrarID' => $registrarId, 'period' => 1,
					'expDate' => date("Y-m-d", $expDate));
			$rebackInfo = $this->sdk->execSdkFun(5003, $params);
			DomainLogsLib::addDomainService($domain, array('memo' => 'admin_restore_dc', 'param' => $params,
			'return' => $rebackInfo), 32);
			if($rebackInfo['resultCode'] != 5000)
			{
				if(!empty($rebackInfo['resultMsg']) && stripos($rebackInfo['resultMsg'], 'out time'))
				{
					throw new \Exception("赎回接口超时,请稍后尝试", 313020);
				}
				throw new \Exception('接口赎回发生错误,' . isset($rebackInfo['resultMsg']) ? $rebackInfo['resultMsg'] : '', 313021);
			}
			//注册时间和过期时间以接口返回的时间为准
			$regtime =  $sdkDomainInfo['data']['createDate'];
			$exptime = $rebackInfo['data']['expireDate'];
			$restoreStatus = $this->restoreInDb($domain, $bakInfo, $enameId, $templateId, $registrarId,$regtime , $exptime, '', 0);
			$remark = $restoreStatus ? '赎回成功,入库成功' : '赎回成功,入库失败';//入库失败比较特殊，添加一条数据库信息
			$this->restoreOrderDone(true, $confirm);
			$this->restoreDirectDb($domain, $enameId, strtotime($regtime), strtotime($exptime), 2, 2, $registrarId, $templateId, $tempname, $orderId, $price, 0, $remark);
			return true;//只要底层赎回成功就算成功，出现未入库的在人工查理,订单也需要人工处理下
		}
		catch(\Exception $e)
		{
			DomainLogsLib::addDomainService($domain, array('memo' => 'restore failed', 'error' => $e->getMessage(),'errorcode' => $e->getCode()), 32);
			$this->restoreOrderDone(FALSE, $confirm);
			$this->restoreSendMailMsg($domain, $enameId, FALSE, 1);
			$this->restoreSendMailMsg($domain, $enameId, FALSE, 2);
			throw new \Exception('赎回失败，请稍后重试', $e->getCode());//一些错误信息不好直接给用户看，直接提示赎回失败
		}
	}
	
	
	public function getRgpStatus($domainInfo)
	{
		if(empty($domainInfo) || !is_array($domainInfo) ||empty($domainInfo['rgpStatus']))
		{
			return '';
		}
		return is_array($domainInfo['rgpStatus']) ? implode(',', $domainInfo['rgpStatus']) : $domainInfo['rgpStatus'];
	}
	
}

<?php 
namespace lib\manage\finance;
use lib\manage\common\FinanceFunLib;
use core;
use common;
class ProductOrderLib
{
	private $enameId;
	private $linkEnameId = 9999;
	private $orderId;
	private $domain;
	private $year = 1;
	private $quantity = 1;//默认一个
	private $type;
	private $productId;
	private $productName;
	private $productType = FALSE;
	private $userGroupId = 1;
	private $productPrice = 0;
	private $price = 0;
	private $promoCode = '';
	private $checkPromoEnable = FALSE; 
	private $productOptions = '';
	private $moneyTpye = 1;
	private $registarId = 0;
	private $adminId = 0;
	private $remarkHide = '';
	private $inTypeSon = 0;
	private $remark = '';
	private $freezeMoneySort = array();
	private $outBankName = 0;

	private $sdk;
	private $productLib;
	private $orderLib;
	private $financeLib;
	private $promoLib;
	private $finLog;

	private $logFile = 'productOrder';

	
	function __construct($enameId)
	{
		if(!is_numeric($enameId))
		{
			throw new \Exception('enameId有误', 410001);
		}
		$this->enameId = $enameId;
		$this->productLib = new ProductLib();
		$this->orderLib = new OrderLib($enameId);
		$this->financeLib = new FinanceLib($enameId);
		$this->finLog = new FinanceLogLib();
	}

	public function setLinkEnameId($linkEnameId)
	{
		$this->linkEnameId = $linkEnameId;
	}

	public function setType($type)
	{
		$this->type = $type;
	}

	public function setProductId($productId)
	{
		$this->productId = $productId;
	}

	public function setProductName($productName)
	{
		$this->productName = $productName;
	}

	public function setProductType($productType)
	{
		$this->productType = $productType;
	}

	public function setDomain($domain)
	{
		$this->domain = $domain;
	}
	
	public function setYear($year)
	{
		$this->year = intval($year);
	}
	
	public function setInTypeSon($inTypeSon)
	{
		$this->inTypeSon = $inTypeSon;
	}
	
	public function setOutBankName($outBankName)
	{
		$this->outBankName = $outBankName;
	}

	public function setQuantity($quantity)
	{
		$this->quantity = $quantity;
	}

	public function setUserGroupId($userGroupId)
	{
		$this->userGroupId = $userGroupId > 0 ? $userGroupId : 1;
	}

	public function setPrice($price)
	{
		$this->price = $price >= 0 ? $price : 0;
	}

	public function setPromoCode($promoCode)
	{
		$this->promoCode = $promoCode;
	}

	public function setMoneyTpye($moneyTpye)
	{
		$this->moneyTpye = $moneyTpye;
	}

	public function setRegistarId($registarId)
	{
		$this->registarId = $registarId;
	}

	public function setAdminId($adminId)
	{
		$this->adminId = $adminId;
	}

	public function setRemarkHide($remarkHide)
	{
		$this->remarkHide = $remarkHide;
	}

	public function setRemark($remark)
	{
		$this->remark = $remark;
	}
	
	public function setFreezeMoneySort($freezeMoneySort)
	{
		$this->freezeMoneySort = $freezeMoneySort;
	}

	public function getOrderId()
	{
		return $this->orderId;
	}
	
	public function getFreezeMoneySort()
	{
		return $this->freezeMoneySort;
	}

	/**
	 * 添加产品订单
	 * @param int $customPrice 自定义价格(珍品域名)
	 * @throws Exception
	 * @return number
	 */
	public function addProductOrder($customPrice = FALSE)
	{
		$this->finLog->setMethod('addProductOrder');
		//获取产品信息和价格
		if(!$this->productId && !$this->productName)
		{
			throw new \Exception('产品id和产品名称必须存在一个', 410059);
		}
		$productInfo = $this->productId ? $this->productLib->getProductById($this->productId, $this->userGroupId) : $this->productLib->getProductByName($this->productName, $this->userGroupId, $this->productType);
		if(!$productInfo)
		{
			throw new \Exception('获取产品信息失败', 410060);
		}
		$this->productType = $this->productLib->getProductType();
		if(FALSE !== $customPrice)
		{
			$this->productPrice = $customPrice;//珍品域名价格
		}
		else
		{
			$this->productPrice = $this->productLib->getPrice($this->type);
		}
		$this->price = $this->productPrice * $this->year;
		if(FALSE !== $customPrice && !$this->productPrice && $this->productType != '10')
		{
			throw new \Exception('获取产品信息失败', 410060);
		}
		//检测并使用优惠券，若优惠码不符合要求，按原价格计算  新增：包括珍品域名的也不算
		if(!$this->checkPromoCode())
		{
			$this->price = $this->productPrice * $this->year;
		}
		//扣款(将预付款转移到冻结字段里)
		$this->financeLib->setDomain($this->domain);
		$this->financeLib->setLinkEnameId($this->linkEnameId);
		if(!$this->financeLib->FinanceOut($this->price, $this->type))
		{
			throw new \Exception('可用余额不足', 410024);
		}
		try
		{
			//添加订单记录
			$this->orderLib->setFreezeMoneySort($this->financeLib->getFreezeMoneySort());
			$this->orderLib->setProductId($this->productLib->getProductId());
			$this->orderLib->setProductName($this->productLib->getProductName());
			$this->orderLib->setPrice($this->price);
			$this->orderLib->setDomain($this->domain);
			$this->orderLib->setProductCost($this->productLib->getProductCost($this->type));
			$isDomain = $this->productLib->getIsDomain();
			$this->productOptions = empty($isDomain) ? '' : array('year' => intval($this->year), 'quantity' => intval($this->quantity),
					'productPrice' => floatval($this->productPrice), 'pType' => intval($this->productType));
			$this->orderLib->setProductOptions($this->productOptions);
			$this->orderLib->setOrderType($this->type);
			$this->orderLib->addRemark($this->remark);
			$this->orderLib->setRemarkHide($this->remarkHide);
			$this->orderLib->setRegistarId($this->registarId ? $this->registarId : $this->productLib->getRegistarId());
			$this->orderId = $this->orderLib->addOrder();
		}
		catch(\Exception $e)
		{
			//创建订单失败时，还款给用户
			$this->financeLib->setFreezeType($this->type);
			$this->financeLib->cancelChangeUserFinance();
			throw new \Exception($e->getMessage(), $e->getCode());
		}
		if(!$this->orderId)
		{
			//创建订单失败时，还款给用户
			$this->financeLib->setFreezeType($this->type);
			$this->financeLib->cancelChangeUserFinance();
			throw new \Exception('添加订单失败!', 410052);
		}
		$this->updateUsePromoCode($this->orderId);
		return $this->orderId;
	}

	/**
	 * 添加无产品订单
	 * @throws Exception
	 * @return number
	 */
	public function addOrder()
	{
		$this->finLog->setMethod('addOrder');
		if($this->price < 0)
		{
			throw new \Exception('金额不能为空', 410061);
		}
		//扣款(将预付款转移到冻结字段里)
		$this->financeLib->setDomain($this->domain);
		$this->financeLib->setLinkEnameId($this->linkEnameId);
		\core\Log::write("1.addorder:begin:" . $this->linkEnameId . "," . $this->domain, 'financeorder', 'track');
		if(!$this->financeLib->FinanceOut($this->price, $this->type))
		{
			throw new \Exception('可用余额不足', 410024);
		}
		\core\Log::write("2.addorder:outend:" . $this->linkEnameId . "," . $this->domain, 'financeorder', 'track');
		try
		{
			$this->orderLib->setFreezeMoneySort($this->financeLib->getFreezeMoneySort());
			$this->setFreezeMoneySort($this->orderLib->getFreezeMoneySort());
			\core\Log::write("3.addorder:setsort:" . $this->linkEnameId . "," . $this->domain, 'financeorder', 'track');
			$this->orderLib->setLinkEnameId($this->linkEnameId);
			$this->orderLib->setPrice($this->price);
			$this->orderLib->setDomain($this->domain);
			$this->orderLib->setOrderType($this->type);
			$this->orderLib->setAdminId($this->adminId);
			$this->orderLib->setRemarkHide($this->remarkHide);
			$this->orderLib->setRemark($this->remark);
			\core\Log::write("3.addorder:addorderbegin:" . $this->linkEnameId . "," . $this->domain, 'financeorder', 'track');
			$this->orderId = $this->orderLib->addOrder();
			\core\Log::write("6.addorder:addorderend:" . $this->linkEnameId . "," . $this->domain, 'financeorder', 'track');
		}
		catch(\Exception $e)
		{
			//创建订单失败时，还款给用户
			$this->financeLib->setFreezeType($this->type);
			$this->financeLib->cancelChangeUserFinance();
			throw new \Exception($e->getMessage(), $e->getCode());
		}
		if(!$this->orderId)
		{
			//创建订单失败时，还款给用户
			$this->financeLib->setFreezeType($this->type);
			$this->financeLib->cancelChangeUserFinance();
			throw new \Exception('添加订单失败', 410052);
		}
		return $this->orderId;
	}

	/**
	 * 检测旧订单余额是否足够
	 * @param int $oldOrderId
	 * @return boolean
	 */
	public function checkOldOrder($oldOrderId)
	{
		$this->orderLib->getOrderInfo($oldOrderId);
		if(FinanceFunLib::moneyFormat($this->orderLib->getPrice()) >= FinanceFunLib::moneyFormat($this->financeLib->getNeedPayMoney()))
		{
			return TRUE;
		}
		return FALSE;
	}

	/**
	 * 确认订单状态
	 * @param int $orderId
	 * @param int $newLinkEnameId 给关联用户的付款比率（0不付款,1付全额）
	 * @throws Exception
	 * @return boolean
	 */
	public function confirmOrder($orderId, $newLinkEnameId = 0)
	{
		$this->finLog->setMethod('confirmOrder');
		$this->orderLib->getOrderInfo($orderId);
		if('3' != $this->orderLib->getOrderStatus())
		{
			throw new \Exception('订单非待处理状态', 410062);
		}
		//使用临时额度|抵押额度的订单需要使用新的接口操作
		$tempFreezeMoneySort = $this->orderLib->getFreezeMoneySort();
		if(!empty($tempFreezeMoneySort['i']))
		{
			throw new \Exception('订单使用临时额度，暂不允许操作', 410063);
		}
		if(!empty($tempFreezeMoneySort['c']))
		{
			throw new \Exception('订单使用抵押额度，暂不允许操作', 410063);
		}
		$this->financeLib->setPromoId($this->orderLib->getPromoId());
		$this->financeLib->setDomain($this->orderLib->getDomain());
		$this->financeLib->setPromoMoney($this->orderLib->getPromoMoney());
		$this->financeLib->setFreezeMoneySort($this->orderLib->getFreezeMoneySort());
		$this->financeLib->setFreezeMoney($this->orderLib->getPrice());
		$this->financeLib->setFreezeType($this->orderLib->getOrderType());
		$this->financeLib->setProductOptions($this->orderLib->getProductOptions());
		$this->financeLib->setRemark($this->orderLib->getRemark());
		$this->financeLib->setRemarkHide($this->orderLib->getRemarkHide());
		$this->financeLib->setAdminId($this->orderLib->getAdminId());
		$this->financeLib->setRegistarId($this->registarId ? $this->registarId : $this->orderLib->getRegistarId());//确认订单有传递则以确认订单为准
		$linkEnameId = $newLinkEnameId ? $newLinkEnameId : $this->orderLib->getLinkEnameId();
		$this->financeLib->setLinkEnameId($linkEnameId);
		if($this->orderLib->getOrderType() == $this->financeLib->getFinanceType('delivery'))//快递费
		{
			$this->financeLib->setTypeSon($this->financeLib->getFinanceType('invoicefin','sonType'));//余额
			$remark = $this->orderLib->getRemark();
			if($remark && stripos($remark,'积分')!==FALSE)
			{
				$this->financeLib->setTypeSon($this->financeLib->getFinanceType('invoicescore','sonType'));//积分
			}
		}
		if($this->inTypeSon)
		{
			$this->financeLib->setTypeSon($this->inTypeSon);
		}
		if($this->outBankName)
		{
			$this->financeLib->setOutBankName($this->outBankName);
		}
		//成功扣款解冻
		$this->orderLib->setLinkEnameId($linkEnameId);
		if(!$this->orderLib->confirmOrder($orderId))
		{
			throw new \Exception('确认订单失败', 410053);
		}
		try 
		{
			$this->financeLib->confirmFinanceOut($orderId);
		}
		catch (\Exception $e)
		{
			core\Log::write("订单id：$orderId,确认订单扣冻结款失败,enameid:$this->enameId,domain:$this->domain,result:".$e->getMessage(), 'Order', 'confirmFinanceOut');
// 			common\Logsystem::addLog(array('enameId'=>$this->enameId,'domain'=>$this->domain,'logType'=>3,'msgType'=>230010,'resultFlag'=>2,'note'=>"订单id：$orderId,确认订单扣冻结款失败",'resultContent'=>$e->getMessage(),'linkId'=>$this->linkEnameId));
			throw new \Exception($e->getMessage(), $e->getCode());
		}
		//涉及交易时，给卖方付款 众筹域名类型排除
		if($linkEnameId != '9999' && $linkEnameId && $this->financeLib->getFreezeType() != $this->financeLib->getFinanceType('domainZC'))
		{
			try
			{
				$financeInLib = new FinanceInLib($linkEnameId);
				$financeInLib->setInMoney($this->financeLib->getFreezeMoney());
				$financeInLib->setMoneyType($this->moneyTpye);
				$financeInLib->setLinkEnameId($this->enameId);
				$financeInLib->setInType($this->financeLib->getFreezeType());
				$financeInLib->setOrderId($orderId);
				$financeInLib->setLinkDomain($this->orderLib->getDomain());
				$financeInLib->setInRemark($this->orderLib->getRemark());
				$financeInLib->setInRemarkHide($this->orderLib->getRemarkHide());
				$financeInLib->setOperator($this->orderLib->getAdminId());
				$financeInLib->setRegistrarId($this->orderLib->getRegistarId());
				$financeInLib->setCreateDate($this->orderLib->getCreateTime());
				if(!$financeInLib->addFinanceIn())
				{
					throw new \Exception('给卖家付款失败', 410065);
				}
			}
			catch(\Exception $e)
			{
				$this->finLog->log($e->getMessage(), array('LinkEnameId' => $linkEnameId, 'EnameId' => $this->enameId,
						'OrderId' => $orderId), $e->getCode(), '1');
				return FALSE;
			}
		}
		//积分大于0则添加积分记录
		if($this->financeLib->getAddScore() > 0)
		{
			try
			{
				$scoreLib = new \lib\manage\finance\ScoreLib($this->enameId);
				$scoreLib->setScore($this->financeLib->getAddScore());
				$currentScore = $this->financeLib->getAddScore() + $this->financeLib->getTotalScore();
				$scoreLib->setCurrentScore($currentScore);
				$scoreLib->setOrderId($orderId);
				$scoreLib->setScoreType($this->orderLib->getOrderType());
				$scoreLib->setScoreRemark($this->orderLib->getDomain());
				if(!$scoreLib->addScoreRecord())
				{
					throw new \Exception('添加积分记录失败', 410066);
				}
			}
			catch(\Exception $e)
			{
				$this->finLog->log($e->getMessage(), array('EnameId' => $this->enameId, 'OrderId' => $orderId), $e->getCode(), '1');
				return FALSE;
			}
		}
		return TRUE;
	}

	/**
	 * 取消订单
	 * @param unknown_type $orderId
	 * @throws Exception
	 * @return boolean
	 */
	public function cancelOrder($orderId, $newOrderId = FALSE, $newOrderFreezeMoneySort = array())
	{
		$this->orderLib->getOrderInfo($orderId);
		if('3' != $this->orderLib->getOrderStatus())
		{
			throw new \Exception('订单非待处理状态', 410062);
		}
		
		//使用临时额度|抵押额度的订单需要使用新的接口操作
		$tempFreezeMoneySort = $this->orderLib->getFreezeMoneySort();
		if(!empty($tempFreezeMoneySort['i']))
		{
			throw new \Exception('订单使用临时额度，暂不允许操作', 410063);
		}
		if(!empty($tempFreezeMoneySort['c']))
		{
			throw new \Exception('订单使用抵押额度，暂不允许操作', 410063);
		}
		
		if(FALSE == $this->orderLib->cancelOrder($orderId))
		{
			throw new \Exception('取消订单失败', 410054);
		}
		
		$result = self::updateFreezeMoneySort($newOrderId, $newOrderFreezeMoneySort);
		$freezeMoneySort = $result['freezeMoneySort']; //旧订单的扣款顺序
		$newFreezeMoneySort = $result['newFreezeMoneySort']; //新订单的扣款顺序
		
		//取消订单后解冻退款
		$this->financeLib->setFreezeType($this->orderLib->getOrderType());
		$this->financeLib->setFreezeMoneySort($freezeMoneySort);
		try
		{
			$this->financeLib->cancelFinanceOut();
		}
		catch (\Exception $e)
		{
			core\Log::write("订单id：$orderId,取消订单返还冻结款失败,enameid:$this->enameId,domain:$this->domain,result:".$e->getMessage(), 'Order', 'cancelOrder');
// 			common\Logsystem::addLog(array('enameId'=>$this->enameId,'domain'=>$this->domain,'logType'=>3,'msgType'=>230009,'resultFlag'=>2,'note'=>"订单id：$orderId,取消订单返还冻结款失败",'resultContent'=>$e->getMessage(),'linkId'=>$this->linkEnameId));
			throw new \Exception($e->getMessage(), $e->getCode());
		}
	
		//取消对应的优惠券使用记录
		$promoId = $this->orderLib->getPromoId();
		if(intval($promoId) > 0)
		{
			$promoLib = new \lib\manage\finance\PromoLib();
			$promoLib->setCheckOrderId($orderId);
			$promoLib->setCheckEnameId($this->enameId);
			$promoLib->setCheckPromoId($promoId);
			$promoLib->cancelPromoUsedSDK();
		}
		
		if(!empty($newOrderId) && !empty($newFreezeMoneySort) && $newOrderFreezeMoneySort != $newFreezeMoneySort)
		{
			if(!$this->orderLib->updateOrderInfoExp($newOrderId, $newFreezeMoneySort))
			{
				core\Log::write("旧订单：$orderId,新订单id：$newOrderId,修改新订单freezeMoneySort失败,enameid:$this->enameId,domain:$this->domain,newFreezeMoneySOrt:".json_encode($newFreezeMoneySort), 'Order', 'cancelOrder');
// 				common\Logsystem::addLog(array('enameId'=>$this->enameId,'domain'=>$this->domain,'logType'=>3,'msgType'=>230008,'resultFlag'=>2,'note'=>"旧订单：$orderId,新订单id：$newOrderId,修改新订单freezeMoneySort失败",'resultContent'=>json_encode($newFreezeMoneySort),'linkId'=>$this->linkEnameId));
			}
			else 
			{
				core\Log::write("旧订单：$orderId,新订单id：$newOrderId,修改新订单freezeMoneySort成功,enameid:$this->enameId,domain:$this->domain,newFreezeMoneySOrt:".json_encode($newFreezeMoneySort), 'Order', 'cancelOrder');
// 				common\Logsystem::addLog(array('enameId'=>$this->enameId,'domain'=>$this->domain,'logType'=>3,'msgType'=>230008,'resultFlag'=>1,'note'=>"旧订单：$orderId,新订单id：$newOrderId,修改新订单freezeMoneySort成功",'resultContent'=>json_encode($newFreezeMoneySort),'linkId'=>$this->linkEnameId));
			}
		}
		
		return TRUE;
	}
	
	/**
	 * 更改扣款排序
	 * @param int $newOrderId
	 * @return array
	 */
	private function updateFreezeMoneySort($newOrderId, $newFreezeMoneySort)
	{
		$freezeMoneySort = $this->orderLib->getFreezeMoneySort();
		$oldOrderId = $this->orderLib->getOrderId();
		if(empty($newOrderId) || empty($newFreezeMoneySort))
		{
			return array('freezeMoneySort' => $freezeMoneySort, 'newFreezeMoneySort' => '');
		}
		$tmpFreezeMoneySort = $newFreezeMoneySort;
		// 新订单冻结到可提现 && 旧订单有不可提现
		if($newFreezeMoneySort['w'] > 0 && $freezeMoneySort['u'] > 0)
		{
			// 旧订单不可提现 大于 新订单的可提现
			if($freezeMoneySort['u'] >= $newFreezeMoneySort['w'])
			{
				// 新订单的可提现金额 转移到就订单的可提现
				$freezeMoneySort['w'] += $newFreezeMoneySort['w'];
				$freezeMoneySort['u'] -= $newFreezeMoneySort['w'];
				$newFreezeMoneySort['u'] += $newFreezeMoneySort['w'];
				$newFreezeMoneySort['w'] = 0;
			}
			else
			{
				$freezeMoneySort['w'] += $freezeMoneySort['u'];
				$newFreezeMoneySort['u'] += $freezeMoneySort['u'];
				$newFreezeMoneySort['w'] -= $freezeMoneySort['u'];
				$freezeMoneySort['u'] = 0;
			}
			$tmpLogArr = array($oldOrderId=>array('old'=>$this->orderLib->getFreezeMoneySort(),'new' => $freezeMoneySort),$newOrderId =>array('old' => $tmpFreezeMoneySort,'new' => $newFreezeMoneySort));
// 			common\Logsystem::addLog(array('enameId'=>$this->enameId,'domain'=>$this->domain,'logType'=>3,'msgType'=>230008,'resultFlag'=>1,'note'=>"旧订单：".$oldOrderId.",新订单：".$newOrderId.",计算扣款顺序",'resultContent'=>json_encode($tmpLogArr),'linkId'=>$this->linkEnameId));
			$this->finLog->log("旧订单：".$oldOrderId.",新订单：".$newOrderId.",计算扣款顺序",array('enameId'=>$this->enameId),$tmpLogArr,0,1);
			core\Log::write("旧订单：".$oldOrderId.",新订单：".$newOrderId.",计算扣款顺序:".json_encode($tmpLogArr), 'Order');
		}
		return array('freezeMoneySort' => $freezeMoneySort, 'newFreezeMoneySort' => $newFreezeMoneySort);
	}

	/**
	 * 检测是否有优惠码，且验证是否可用
	 * @return boolean
	 */
	private function checkPromoCode()
	{
		if(!$this->promoCode)
		{
			return TRUE;
		}

		$this->promoLib = new PromoLib();
		$this->promoLib->setCheckEnameId($this->enameId);
		$this->promoLib->setCheckPromoCode($this->promoCode);
		$this->promoLib->setCheckUserGroupId($this->userGroupId);
		$this->promoLib->setCheckUseType($this->type);
		$this->promoLib->setCheckDomainExp(array('0' => $this->productLib->getProductName()));
		$this->promoLib->setCheckMoney(array('0' => $this->productPrice));
		$this->promoLib->setCheckYear(array('0' => $this->year));
		$this->promoLib->setCheckProductType(array('0' => $this->productLib->getProductType()));
		$this->promoLib->setCheckOkDomains(array('0' => $this->domain));

		//获取域名的接口id用于优惠券限制判断
		$registrarId = 0;
		if($this->domain)
		{
			$dnManageLib = new \lib\manage\domain\DomainManageLib();
			$info = $dnManageLib->getDomainInfo(array('DomainName' => $this->domain, 'EnameId' => $this->enameId), 'RegistrarId');
			$registrarId = FALSE != $info ? $info['RegistrarId'] : FALSE;
		}
		$this->promoLib->setCheckDomainRegId(array('0' => $registrarId));

		$this->checkPromoEnable = $this->promoLib->checkPromo();
		if(!$this->checkPromoEnable)
		{
			return FALSE;
		}
		$PromoSubPrice = $this->promoLib->getPromoSubPrice();
		$this->price = ($this->productPrice * $this->year) - $PromoSubPrice['0'];
		$this->orderLib->setPromoId($this->promoLib->getPromoId());
		$this->orderLib->setPromoMoney($PromoSubPrice['0']);
		$this->orderLib->addRemark($this->promoLib->getPromoTypeName());
		return TRUE;
	}

	/**
	 * 设置优惠券为已用
	 * @param int $checkOrderId
	 * @return boolean
	 */
	private function updateUsePromoCode($checkOrderId)
	{
		if(!$this->promoCode || !$this->checkPromoEnable)
		{
			return TRUE;
		}
		$this->promoLib->setCheckOrderId($checkOrderId);
		if(!$this->promoLib->usePromoSDK())
		{
			return FALSE;
		}
		return TRUE;
	}
	
	/**
	 * 给用户入款
	 */
	public function addFinanceIn($enameId)
	{
		try 
		{  
			$financeInLib = new FinanceInLib($enameId);
			$financeInLib->setInType($this->type);// 注册续费转入中抽等等
			$financeInLib->setLinkDomain($this->domain);//关联域名
			$financeInLib->setInRemark($this->remark);//备注
			$financeInLib->setInTypeSon($this->inTypeSon);//备注
			$financeInLib->setInRemarkHide($this->remarkHide);//备注
			$financeInLib->setOperator($this->adminId);//操作者
			$financeInLib->setMoneyType($this->moneyTpye);//对公 不可体现 可体现 保证金
			$financeInLib->setInMoney($this->price);//入款金额
			if(!$financeInLib->addFinanceIn(FALSE))
			{
				throw new \Exception('给卖家付款失败', 410065);
			}
			return TRUE;
		}
		catch(\Exception $e)
		{
			$this->finLog->log($e->getMessage(), array('type' => $this->type, 'EnameId' => $enameId,'moneType' => $this->moneyTpye,'price'=>$this->price), $e->getCode(), '1');
			return FALSE;
		}
	}
}

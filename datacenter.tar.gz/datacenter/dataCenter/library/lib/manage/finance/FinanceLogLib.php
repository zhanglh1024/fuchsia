<?php
namespace lib\manage\finance;

class FinanceLogLib
{

	private $logType = 0;

	private $operatorId = 9999;

	private $method = '';

	private $financeLog = FALSE;
	/**
	 * 是否批量处理日志
	 */
	private static $batchSet = FALSE;
	/**
	 * 批量日志数据 
	 */
	private static $batchLogData = array();

	public function setOperatorId($operatorId)
	{
		$this->operatorId = $operatorId;
	}

	public function setMethod($method)
	{
		$this->method = $method;
	}

	public function getLogger()
	{
		if($this->financeLog == FALSE)
		{
			$this->financeLog = new FinanceLog();
		}
		return $this->financeLog;
	}

	public function log($logDesc, $sendData, $returnData, $level = 0, $success = 0)
	{
		$http_host = empty($_SERVER['HTTP_HOST']) ? 'HTTP_HOST empty' : $_SERVER['HTTP_HOST'];
		$php_self = empty($_SERVER['PHP_SELF']) ? 'PHP_SELF empty' : $_SERVER['PHP_SELF'];
		$url_this = $http_host . $php_self;
		if(is_object($sendData))
		{
			$sendData = \common\Common::objectToarray($sendData);
		}
		if(isset($sendData['EnameId']) and $sendData['EnameId'] > 0)
		{
			$this->operatorId = $sendData['EnameId'];
		}
		elseif(isset($sendData['enameId']) and $sendData['enameId'] > 0)
		{
			
			$this->operatorId = $sendData['enameId'];
		}
		$sendData = json_encode($sendData);
		$returnData = json_encode($returnData);
		$operatorIp = \common\Common::getRequestIp();
		$logData = array(
				'operatorId' => $this->operatorId, 'logType' => $this->logType, 'method' => $this->method, 
				'sendData' => $sendData, 'returnData' => $returnData, 'operatorIp' => $operatorIp, 'logDesc' => $logDesc, 
				'isSuccess' => $success, 'actionUrl' => $url_this);
		if(self::$batchSet)//走批量处理日志逻辑
		{
			self::$batchLogData[] = $logData;
		}
		else//不批量处理日志(原方法)
		{
			$finLogMod = new \models\manage\finance\FinLogMod();
			if(! $finLogMod->addFinanceLog($logData))
			{
				$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'ext');
				\core\Log::write(json_encode($logData), $conf->logFolder);
			}
		}
	}
	/**
	 * 设置批量处理日志参数
	 * @param \boolean $batchSet
	 */
	public static function logBatchSet($batchSet)
	{
		if (!(self::$batchSet && self::$batchLogData))
		{
			self::$batchSet = $batchSet;
		}
	}
	/**
	 * 批量处理日志
	 */
	public static function batchLog()
	{
		if(self::$batchLogData)
		{
			$finLogMod = new \models\manage\finance\FinLogMod();
			while (count(self::$batchLogData)>0)
			{
				$logData =  array_pop(self::$batchLogData);
				if(! $finLogMod->addFinanceLog($logData))
				{
					$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'ext');
					\core\Log::write(json_encode($logData), $conf->logFolder);
				}
			}
		}
	}  
}

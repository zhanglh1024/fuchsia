<?php
namespace lib\manage\finance;

use core\Response;
use lib\manage\common\DomainFunLib;
use models\manage\finance\FinInMod;

class FinanceGeneralLib
{

	private $generalMod;

	private $finLogLib;

	private $finInMod;

	private $finOutMod;

	private $domainIf;

	private $financeIf;

	public function __construct()
	{
		$this->generalMod = new \models\manage\finance\FinGeneralMod();
		
		$this->finLogLib = new \lib\manage\finance\FinanceLogLib();
		
		$this->finInMod = new \models\manage\finance\FinInMod();
		
		$this->finOutMod = new \models\manage\finance\FinOutMod();
		
		$this->domainIf = new \interfaces\manage\Domains();
		
		$this->financeIf = new \interfaces\manage\Finance();
	}

	public function getGeneralCount($data)
	{
		return $this->generalMod->getFinGeneralCount($data);
	}

	public function getGeneralList($data)
	{
		return $this->generalMod->getFinGeneralList($data);
	}

	public function getFinGeneralStatistics($data)
	{
		return $this->generalMod->getFinGeneralStatistics($data);
	}
	
	public function getStatistics($data)
	{
		return $this->generalMod->getFinGeneralStat($data);
	}

	/**
	 * 添加一条记录
	 */
	public function addRecord($data)
	{
		return $this->generalMod->addFinGeneral($data);
	}

	/**
	 * 把域名从买家账号下转移到卖家账号下，从卖家账号下扣除所得金额，在买家账号下增加所付金额
	 *
	 * @param array $data
	 */
	public function cancelType1(array $data, array $orderInfo)
	{
		$domain = $orderInfo['Domain'];
		$bEnameId = $data['bEnameId']; 
		$sEnameId = $data['sEnameId']; 
		$delSellMoney = $data['deSellMoney'];
		$retBMoney = $data['retBMoney'];
		$remarkhide = isset($data['remarkhide']) ? $data['remarkhide'] : '';
		
		// 相关款项的转移
		if(!$this->financeIf->cancelOrderByAdmin($bEnameId, $orderInfo['OrderId'], $remarkhide))
		{
			Response::error(Response::getErrMsg());
		}
		
// 	if(!$this->domainIf->domainPush($domain, $bEnameId, $sEnameId))
// 		{
// 			throw new \Exception('域名从买家账号下转移到卖家账号,转移失败:' . $domain . '['.Response::getErrMsg().']');
// 		}

		$this->finLogLib->log('取消订单成功' . $orderInfo['OrderId'], $data, array());
		Response::success('取消订单成功!');
	}

	/**
	 * 从卖家账号下扣除所得金额，在买家账号下增加所付金额
	 *
	 * @param array $data
	 */
	public function cancelType2(array $data, array $orderInfo)
	{
		$domain = $orderInfo['Domain'];
		$bEnameId = $data['bEnameId'];
		$sEnameId = $data['sEnameId'];
		$remarkhide = isset($data['remarkhide']) ? $data['remarkhide'] : '';
		
		// 相关款项的转移
		if(!$this->financeIf->cancelOrderByAdmin($bEnameId, $orderInfo['OrderId'], $remarkhide))
		{
			Response::error(Response::getErrMsg());
		}
		$this->finLogLib->log('取消订单成功' . $orderInfo['OrderId'], $data, array());
		Response::success('取消订单成功!');
	}

	/**
	 * 把域名从买家账号下转移到卖家账号下，从卖家账号下扣除所得金额，在买家账号下增加所付金额
	 *
	 * @param array $data
	 */
	public function cancelType3(array $data, array $orderInfo)
	{
		$domain = $orderInfo['Domain'];
		$bEnameId = $data['bEnameId'];
		$sEnameId = $data['sEnameId'];
		$domain = $orderInfo['Domain'];
		$remarkhide = isset($data['remarkhide']) ? $data['remarkhide'] : '';
		
		// 获取域名push信息，判断走哪个流程
// 		$pushMod = new \models\manage\domain\DomainPushMod();
// 		$pushInfo = $pushMod->pushList(
// 			array('DomainName' => $domain, 'ReceiveId' => $orderInfo['EnameId'], 'SendId' => $orderInfo['LinkEnameId']), 
// 			'*', true);
// 		if(!$pushInfo)
// 		{ 
// 			throw new \Exception('获取域名push信息失败:' . $domain);
// 		}

		// 从卖家账号下扣除所得金额，在买家账号下增加所付金额
		if(!$this->financeIf->cancelOrderByAdmin($bEnameId, $orderInfo['OrderId'], $remarkhide))
		{
			Response::error(Response::getErrMsg());
		}
		
// 		// 三种PUSH类型都有域名转移
// 		if(!$this->domainIf->domainPush($domain, $bEnameId, $sEnameId))
// 		{
// 			throw new \Exception(Response::getErrMsg());
// 		}

		$this->finLogLib->log('取消订单成功' . $orderInfo['OrderId'], $data, array());
		Response::success('取消订单成功!');
	}
} 
<?php
namespace lib\manage\finance;
use core\Response;
class PromoLib
{

	private $promoTypeId;
	private $typeName; //'优惠名称',
	private $useType; //'使用类型：空则不限制，多个以“,”区分',
	private $moneyType; //'优惠类型:1、减n元，2、价格变更为n元,3、减n%',
	private $money; //'优惠价格',
	private $sendType; //'送发方式',
	private $minAmount; //'最小金额',
	private $sendStartDate; //'放送开始时间',
	private $sendEndDate; //'放送结束时间',
	private $useStartDate; //'使用开始时间',
	private $useEndDate; //'使用结束时间',
	private $userGroup; //'用户等级id，多个以“,”分开',
	private $domainExp; //'域名后缀，多个以“,”区分',
	private $sendNum; //'放发数量',
	private $usedTimes; //'已使用数量',
	private $year; //'已使用数量',
	private $isShare; //'是否可共享',
	private $useDays;
	private $promoId;
	private $promoCode;
	private $enameId;
	private $usedDate;
	private $orderId;
	private $useTimes;
	private $productId;
	private $promoStatus;
	private $maxUseTimes;
	private $createDate; //'单个优惠券创建时间',
	private $promoEndDate;
	private $promoDomains;//限定只能使用该优惠券的域名
	private $excludings;//限定不允许优惠的产品类型
	private $domainRegId;//限定允许优惠的接口id
	private $domainGroup;//限定允许优惠的域名系统分组
	private $promoSubPriceZHenpin=array();	
	
	private $checkUserGroupId = 1;
	private $checkDomainExp;//array
	private $checkMoney;//array
	private $checkUseType = 1;
	private $checkEnameId;
	private $checkPromoCode;//优惠码和优惠券Id任选一个
	private $checkPromoId;
	private $checkYear;//array
	private $checkOrderId;
	private $checkProductType;//array
	private $checkOkDomains;//array 购物车传过来的域名数组
	private $checkDomainRegId;//array 域名接口id

	private $promoContent;
	private $promoCheckMsg = '';

	private $promoList;
	private $promoSubPrice = array();

	private $finLog;
	private $promoMod;
	private $conf;

	function __construct()
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
		$this->finLog = new FinanceLogLib();
		$this->promoMod = new \models\manage\finance\ProPromoMod();
	}

	public function getPromoCode()
	{
		return $this->promoCode;
	}

	public function getPromoId()
	{
		return $this->promoId;
	}

	public function getEnameId()
	{
		return $this->enameId;
	}

	public function getPromoStatus()
	{
		return $this->promoStatus;
	}

	public function getMoney()
	{
		return $this->money;
	}

	public function getMoneyType()
	{
		return $this->moneyType;
	}

	public function getMinAmount()
	{
		return $this->minAmount;
	}

	public function getDomainExp()
	{
		return $this->domainExp;
	}

	public function getUserGroup()
	{
		return $this->userGroup;
	}

	public function getMaxUseTimes()
	{
		return $this->maxUseTimes;
	}

	public function getUseTimes()
	{
		return $this->useTimes;
	}

	public function getPromoSubPrice()
	{
		return $this->promoSubPrice;
	}

	public function getPromoYear()
	{
		return $this->year;
	}

	public function getPromoTypeName()
	{
		return $this->typeName;
	}

	/**
	 * 获取优惠券信息说明
	 * @return string
	 */
	public function getPromoContent()
	{
		$financeType = $this->conf->type->lang;
		if(count($this->useType) > 0)
		{
			$or = '';
			foreach($this->useType as $var)
			{
				$this->promoContent .= $or . $financeType->{$var};
				$or = '或';
			}
		}
		if(count($this->promoDomains) > 0)
		{
			$this->promoContent .= implode(',', $this->promoDomains);
		}
		elseif(count($this->domainExp) > 0)
		{
			foreach($this->domainExp as $var)
			{
				$this->promoContent .= '[' . $var . ']';
			}
		}
		if($this->moneyType == 1)
			$this->promoContent .= ',立减' . $this->money . '元';
		if($this->moneyType == 2)
			$this->promoContent .= ',价格变更为' . $this->money . '元';
		if($this->moneyType == 3)
		{
			$this->money = $this->money * 100;
			$this->promoContent .= ',立减' . $this->money . '%';
		}

		if($this->minAmount > 0)
			$this->promoContent .= ',最低订单金额' . $this->minAmount . '元';
		$ableUseTimes = $this->maxUseTimes - $this->useTimes;
		if($ableUseTimes >= 0)
			$this->promoContent .= ',剩余可使用次数:' . $ableUseTimes;
		return $this->promoContent;
	}

	public function getPromoCheckMsg()
	{
		return $this->promoCheckMsg;
	}

	public function setCheckEnameId($checkEnameId)
	{
		$this->checkEnameId = $checkEnameId;
	}

	public function setCheckPromoCode($checkPromoCode)
	{
		$this->checkPromoCode = $checkPromoCode;
	}

	public function setCheckPromoId($checkPromoId)
	{
		$this->checkPromoId = $checkPromoId;
	}

	public function setCheckOrderId($checkOrderId)
	{
		$this->checkOrderId = $checkOrderId;
	}

	public function setCheckUserGroupId($checkUserGroupId)
	{
		$this->checkUserGroupId = $checkUserGroupId;
	}

	public function setCheckUseType($checkUseType)
	{
		$this->checkUseType = $checkUseType;
	}

	public function setCheckDomainExp($checkDomainExp)
	{
		$this->checkDomainExp = $checkDomainExp;
	}

	public function setCheckMoney($checkMoney)
	{
		$this->checkMoney = $checkMoney;
	}

	public function setCheckYear($checkYear)
	{
		$this->checkYear = $checkYear;
	}

	public function setCheckProductType($checkProductType)
	{
		$this->checkProductType = $checkProductType;
	}

	public function setCheckOkDomains($okDomains)
	{
		$this->checkOkDomains = $okDomains;
	}

	public function setCheckDomainRegId($registrarId)
	{
		$this->checkDomainRegId = $registrarId;
	}

	/**
	 *  取得用户当前可用优惠券
	 * @param int $offset
	 * @param int $num
	 * @throws Exception
	 * @return array|boolean
	 */
	public function getAvailablePromoListSDK($offset = 0, $num = 8)
	{
		$this->finLog->setMethod('getUserPromoListSDK');
		if(!is_numeric($this->checkEnameId) or $this->checkEnameId <= 0)
		{
			Response::setErrMsg("enameId有误", 410001);
			return FALSE;
		}
		//可用
		$data = array('enameId' => $this->checkEnameId, 'useDate' => date('Y-m-d H-i-s'), 'promoStatus' => 1,
				'useType' => $this->checkUseType, 'userGroup' => $this->checkUserGroupId, 'offset' => $offset,
				'num' => $num);
		$promoList = $this->promoMod->getUserPromoCard($data);
		if(FALSE == $promoList)
		{
			$this->finLog->log('获取优惠券列表失败', $data, $promoList, 1);
			throw new \Exception('获取优惠券列表失败', 410015);
		}
		$this->promoList = $promoList;
		return $this->promoList;
	}

	/**
	 * 取得用户优惠券
	 * @throws Exception
	 * @return array|boolean
	 */
	public function getUserPromoListSDK($params = FALSE)
	{
		$this->finLog->setMethod('getUserPromoListSDK');
		if(!is_numeric($this->checkEnameId) or $this->checkEnameId <= 0)
		{
			Response::setErrMsg("enameId有误", 410001);
			return FALSE;
		}
		$data = array('enameId' => $this->checkEnameId);
		if(!empty($params['promoStatus']))
		{
			$data['promoStatus'] = $params['promoStatus'];
		}
		if(!empty($params['offset']))
		{
			$data['offset'] = $params['offset'];
		}
		if(!empty($params['num']))
		{
			$data['num'] = $params['num'];
		}
		if(!empty($params['useType']))
		{
			$data['useType'] = $params['useType'];
		}
		if(!empty($params['promoType']))
		{
			$data['promoType'] = $params['promoType'];
		}
		$promoList = $this->promoMod->getUserPromoCard($data);
		if(!$promoList)
		{
			$this->finLog->log('获取优惠券列表失败', $data, $promoList, 1);
			throw new \Exception('获取优惠券列表失败', 410015);
		}
		$this->promoList = $promoList;
		return $this->promoList;
	}

	/**
	 *  根据优惠码或者优惠id获取优惠券信息
	 * @throws Exception
	 * @return array
	 */
	public function getPromoInfoSDK()
	{
		$this->finLog->setMethod('getPromoInfoSDK');
		if($this->checkPromoId <= 0 && !$this->checkPromoCode)
		{
			$this->finLog->log('优惠券Id或优惠码不能同时为空', array('checkPromoId' => $this->checkPromoId,
					'checkPromoCode' => $this->checkPromoCode), FALSE);
			throw new \Exception('优惠券不可用', 410004);
		}
		$promoInfo = $this->promoMod->getPromoInfo($this->checkPromoId, $this->checkPromoCode);
		if(FALSE == $promoInfo)
		{
			$this->finLog->log('获取优惠券信息失败', $promoInfo, 'false');
			throw new \Exception('优惠券不可用', 410004);
		}
		$this->typeName = $promoInfo['TypeName'];
		$this->enameId = $promoInfo['EnameId'];
		$this->promoId = $promoInfo['PromoId'];
		$this->promoCode = $promoInfo['PromoCode'];
		$this->promoStatus = $promoInfo['PromoStatus'];
		$this->useType = explode(',', $promoInfo['UseType']);
		$this->money = $promoInfo['Money'];
		$this->moneyType = $promoInfo['MoneyType'];
		$this->minAmount = $promoInfo['MinAmount'];
		$this->userGroup = explode(',', $promoInfo['UserGroup']);
		$this->domainExp = explode(',', $promoInfo['DomainExp']);
		$this->maxUseTimes = $promoInfo['MaxUseTimes'];
		$this->useTimes = $promoInfo['UseTimes'];
		$this->useStartDate = $promoInfo['UseStartDate'];
		$this->useEndDate = $promoInfo['UseEndDate'];
		$this->year = $promoInfo['PromoYear'];
		$this->promoTypeId = $promoInfo['PromoTypeId'];
		$this->isShare = $promoInfo['IsShare'];
		$this->useDays = $promoInfo['UseDays'];
		$this->createDate = $promoInfo['CreateDate'];
		$this->promoEndDate = $promoInfo['PromoEndDate'];
		$this->promoDomains = $promoInfo['Domains'] ? explode(',', $promoInfo['Domains']) : array();
		$this->excludings = $promoInfo['excludings'] ? explode(',', $promoInfo['excludings']) : array();//不参与优惠的产品类型，为空则表示所有都参与
		$this->domainRegId = $promoInfo['DomainRegId'] ? explode(',', $promoInfo['DomainRegId']) : array();//参与优惠的接口id，为空则表示所有都参与
		$this->domainGroup = $promoInfo['DomainGroup'] ? explode(',', $promoInfo['DomainGroup']) : array();//参与优惠的域名系统分组，为空则表示所有都参与
		return $promoInfo;
	}

	/**
	 * 检查优惠券是否可以使用
	 * @return boolean
	 */
	public function checkPromo()
	{ 
		if(!$this->checkEnameId)
		{
			return FALSE;
		}
		//获取优惠券信息
		if(!$this->getPromoInfoSDK())
		{
			return FALSE;
		}
		//是否有效状态
		if($this->promoStatus == '2')
		{
			return FALSE;
		}
		if(!self::checkActivity($this->checkOkDomains, $this->moneyType, $this->domainExp, $this->checkUseType))
		{
			return FALSE;
		}
		//是否在有效时间内
		$nowTime = date('Y-m-d H:i:s');
		$useEndDate = $this->useEndDate > $this->promoEndDate ? $this->promoEndDate : $this->useEndDate;
		$useStartDate = $this->useStartDate > $this->createDate ? $this->useStartDate : $this->createDate;
		if($nowTime > $useEndDate || $nowTime < $useStartDate)
		{
			return FALSE;
		}
		//是否共享与是否用户所属
		if($this->enameId && empty($this->isShare) && $this->checkEnameId != $this->enameId)
		{
			return FALSE;
		}
		//是否是允许的使用类型
		if(is_array($this->useType) && !in_array($this->checkUseType, $this->useType))
		{
			return FALSE;
		}
		//是否在允许的用户组内
		if(is_array($this->userGroup) && !in_array($this->checkUserGroupId, $this->userGroup))
		{
			return FALSE;
		}
		
		//是否限定指定域名使用，是的话优先判断
		if(!empty($this->promoDomains) && is_array($this->promoDomains))
		{
			$checkIsOk = FALSE;
			$i = 0;
			foreach($this->checkOkDomains as $key => $value)
			{
				if($this->useTimes + $i >= $this->maxUseTimes)
				{
					$this->promoSubPrice[$key] = 0;
					continue;
				}
				if(in_array($value, $this->promoDomains))
				{
					$this->promoSubPrice[$key] = $this->getPromoMoney($this->money, $this->moneyType, $this->year, $this->checkMoney[$key], $this->checkYear[$key]);
					if(empty($this->promoSubPrice[$key]))
					{
						continue;
					}
					$checkIsOk = TRUE;
					$i++;
				}
				else
				{
					$this->promoSubPrice[$key] = 0;
					continue;
				}
			}
			$this->promoCheckMsg = $checkIsOk ? '' : '只允许用于[' . implode(',', $this->promoDomains) . ']';
			return $checkIsOk ? TRUE : FALSE;
		}
		//判断域名是否是珍品域名，是的话no允许使用
		foreach($this->checkOkDomains as $key => $value)
		{
			if($this->checkTopDomain($value))
			{
				$this->promoSubPriceZHenpin[$key] = 0;
				continue;
			}
		}
		//是否是允许优惠的域名后缀，是否是允许优惠的接口，及优惠价格计算
		if(is_array($this->checkDomainExp))
		{
			$checkDomainExpIsOk = FALSE;
			$i = 0;
			foreach($this->checkDomainExp as $key => $checkDomainExp)
			{
				if(isset($this->promoSubPriceZHenpin[$key]))//判断域名是否是珍品域名，是的话no允许使用
				{
					$this->promoSubPrice[$key] = 0;
					continue;
				}
				if(!in_array($this->checkProductType[$key], array(1, 2, 3, 11, 12)))//允许使用优惠券的产品类型（1、英文域名，2、中文域名，3、省会域名，11、域名新接口，12、溢价域名）
				{
					$this->promoSubPrice[$key] = 0;
					continue;
				}
				if($this->useTimes + $i >= $this->maxUseTimes)
				{
					$this->promoSubPrice[$key] = 0;
					continue;
				}
				if(is_array($this->domainExp))
				{
					//针对所有cn域名的后缀，都用.cn来检测
					if(strpos($checkDomainExp, '.cn') !== FALSE)
					{
						$checkDomainExp = '.cn';
					}
					if(!in_array($checkDomainExp, $this->domainExp))
					{
						$this->promoSubPrice[$key] = 0;
						continue;
					}
					//指定产品不参与优惠券优惠
					if(!empty($this->excludings) && in_array($this->checkProductType[$key], $this->excludings))
					{
						$this->promoSubPrice[$key] = 0;
						continue;
					}
				}
				//续费时，是否指定接口才可优惠
				if(3 == $this->checkUseType && !empty($this->domainRegId) && is_array($this->domainRegId) && (empty($this->checkDomainRegId[$key]) || !in_array($this->checkDomainRegId[$key], $this->domainRegId)))
				{
					$this->promoSubPrice[$key] = 0;
					continue;
				}
				//是否指定域名分组才可优惠
				if(!empty($this->domainGroup) && is_array($this->domainGroup) && (empty($this->checkOkDomains[$key]) || !$this->checkDomainGroup($this->checkOkDomains[$key], $this->domainGroup)))
				{
					$this->promoSubPrice[$key] = 0;
					continue;
				}
				if(1 == $this->checkUseType && \lib\manage\common\DomainOpenLib::tmpFuncOpenCheck(FALSE,'cnnet') && in_array(\lib\manage\common\DomainFunLib::getDomainClass($this->checkOkDomains[$key]),array('CN','NET')))
				{
					$this->promoSubPrice[$key] = 0;
					continue;
				}
				//是否达到年限限制
				if($this->checkYear[$key] < $this->year and $this->year > 0)
				{
					$this->promoSubPrice[$key] = 0;
					continue;
				}
				$checkMoney = $this->checkMoney[$key] * $this->checkYear[$key];
				//是否是超过最小金额限制
				if($this->minAmount > 0 and $checkMoney < $this->minAmount)
				{
					$this->promoSubPrice[$key] = 0;
					continue;
				}
				//以上都满足则计算优惠价格
				$this->promoSubPrice[$key] = $this->getPromoMoney($this->money, $this->moneyType, $this->year, $this->checkMoney[$key], $this->checkYear[$key]);
				if(empty($this->promoSubPrice[$key]))
				{
					continue;
				}
				$checkDomainExpIsOk = TRUE;
				$i++;
			}
		}
		else
		{
			return FALSE;
		}
		if(!$checkDomainExpIsOk or !$this->checkDomainExp)
		{
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * 获取优惠券所优惠的金额
	 * @param number $promoMoney 优惠额度
	 * @param int $promoMoneyType 优惠金额计算类型1，2，3
	 * @param int $promoYear 优惠年限
	 * @param number $productPrice 产品单价
	 * @param int $productYear 产品消费年限
	 * @return number
	 */
	public function getPromoMoney($promoMoney, $promoMoneyType, $promoYear, $productPrice, $productYear)
	{
		$promoSubPrice = 0;
		switch($promoMoneyType)
		{
			//1、减n元
			case 1:
				$promoSubPrice = $promoMoney;
				break;
			//2、若不限制优惠年限则消费年限的单价变为n元，反之若消费年限达到优惠年限则优惠年限的总价格变更为n元
			case 2:
				$promoSubPrice = $promoYear > 0 ? ($productPrice * $promoYear) - $promoMoney : ($productPrice - $promoMoney) * $productYear;
				if($promoSubPrice < 0)
				{
					$promoSubPrice = 0;
				}
				break;
			case 3:
			//3、减n%
				$promoSubPrice = $productPrice * $promoYear * $promoMoney;
				break;
			default:
				$promoSubPrice = 0;
				break;
		}
		return $promoSubPrice;
	}

	/**
	 * 设置优惠券为已使用
	 * @return  bool
	 */
	public function usePromo()
	{
		$checkPromo = $this->checkPromo();
		if(!$checkPromo)
		{
			Response::setErrMsg("优惠券不可用", 410004);
			return FALSE;
		}
		return $this->usePromoSDK();
	}

	/**
	 * 优惠券设置为已用
	 * @return boolean
	 */
	public function usePromoSDK()
	{
		$this->finLog->setMethod('usePromoSDK');
		$data = array();
		$data['promoId'] = $this->promoId;
		$data['orderId'] = $this->checkOrderId;
		$data['promoTypeId'] = $this->promoTypeId;
		$data['promoCode'] = $this->promoCode;
		$data['enameId'] = $this->checkEnameId;
		$data['useIp'] = \common\Common::getRequestIp();
		if(FALSE == $this->promoMod->usedPromoInfo($data))
		{
			$this->finLog->log('设置优惠券使用状态失败', $data, 'false', 1);
			Response::setErrMsg("设置优惠券使用状态失败", 410016);
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * 生成优惠券
	 * @param array $data
	 * @return boolean|unknown
	 */
	public function addPromoCodeSDK($data)
	{
		$return = $this->promoMod->addPromoCode($data);
		if(FALSE == $return)
		{
			$this->finLog->log('生成优惠券失败', $data, $return, 1);
			Response::setErrMsg("生成优惠券失败", 410017);
			return FALSE;
		}
		return $return;
	}

	/**
	 * 获取优惠券类型基本信息
	 * @param int $promoTypeId
	 * @return array|boolean
	 */
	public function getPromoTypeSDK($promoTypeId)
	{
		$return = $this->promoMod->getPromoTypeInfo($promoTypeId);
		if(FALSE == $return)
		{
			$this->finLog->log('获取优惠券类型信息失败', array('promoTypeId' => $promoTypeId), $return, 1);
			Response::setErrMsg("获取优惠券信息失败", 410003);
			return FALSE;
		}
		return $return;
	}

	/**
	 * 获取某类型的发放数量
	 * @param int $promoTypeId
	 * @return number|boolean
	 */
	public function getPromoCountByType($promoTypeId)
	{
		$return = $this->promoMod->getPromoCountByType($promoTypeId);
		if(FALSE === $return)
		{
			$this->finLog->log('获取某类型的发放数量失败', array('promoTypeId' => $promoTypeId), $return, 1);
			Response::setErrMsg("获取某类型的发放数量失败", 410018);
			return FALSE;
		}
		return $return;
	}

	/**
	 * 检测优惠券是否已经存在
	 * @param int $enameId
	 * @param int $promoType
	 * @return boolean
	 */
	public function checkHavePromo($enameId, $promoType)
	{
		$return = $this->promoMod->getPromoTypeInfo($promoType, $enameId);
		if(FALSE == $return)
		{
			$this->finLog->log('获取优惠券类型信息失败', array('promoTypeId' => $promoType, 'enameId' => $enameId), $return, 1);
			Response::setErrMsg("获取优惠券信息失败", 410003);
			return FALSE;
		}
		return $return;
	}

	/**
	 * 检测uniqueId是否已经存在
	 * @param int $enameId
	 * @param int $promoType
	 * @param int $uniqueId
	 * @return boolean
	 */
	public function checkHaveUniqueId($enameId, $promoType, $uniqueId)
	{
		$return = $this->promoMod->getPromoTypeInfo($promoType, $enameId, $uniqueId);
		if(FALSE !== $return)
		{
			return $return;
		}
		return FALSE;
	}

	/**
	 * 
	 * 取得优惠券统计情况
	 * @param array $params
	 */
	public function getPromoStat($params)
	{
		$return = $this->promoMod->getPromoStat($params);
		if($return)
		{
			return $return;
		}
		return FALSE;
	}
	
	/**
	 * 后台取得优惠券收入统计情况（新）
	 * @param array $params
	 */
	public function getPromoStatNew($month)
	{
		$return = $this->promoMod->getPromoStatNew($month);
		if($return)
		{
			return $return;
		}
		return FALSE;
	}

	/**
	 * 取消使用优惠券(调用SDK)
	 * @return  bool
	 */
	public function cancelPromoUsedSDK()
	{
		$this->finLog->setMethod('cancelPromoUsedSDK');
		if(FALSE == $this->promoMod->cancelUsedPromoInfo($this->checkPromoId, $this->checkEnameId, $this->checkOrderId))
		{
			$this->finLog->log('设置取消优惠券状态失败', array('promoId' => $this->checkPromoId, 'enameId' => $this->checkEnameId,
					'orderId' => $this->checkOrderId), 'false', 1);
			Response::setErrMsg("取消使用优惠券失败", 410019);
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * 获取优惠券总数
	 */
	public function getUserCouponCount($enameId, $promostatus, $useType = '', $promoType = '')
	{
		$this->finLog->setMethod('getUserPromoListSDK');
		if(!is_numeric($this->checkEnameId) or $this->checkEnameId <= 0)
		{
			Response::setErrMsg("enameId有误", 410001);
			return FALSE;
		}
		$data = array('enameId' => $this->checkEnameId, 'userGroup' => $this->checkUserGroupId);
		if(!empty($promostatus))
		{
			$data['promoStatus'] = $promostatus;
		}
		if(!empty($promoType))
		{
			$data['promoType'] = $promoType;
		}
		if($promostatus == 1)
		{
			$data['useDate'] = date('Y-m-d H:i:s');
		}
		if(!empty($useType))
		{
			$data['useType'] = $useType;
		}
		$total = $this->promoMod->getUserPromoCount($data);
		if(!$total)
		{
			$this->finLog->log('获取优惠券列表总数失败', $data, $total, 1);
			throw new \Exception('获取优惠券列表总数失败', 410020);
		}
		return $total['total'];
	}

	/**
	 * 随机字符串,大小写、数字混合
	 * @param int $length
	 * @return string
	 */
	public function getString($length)
	{
		$chars = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,0,1,2,3,4,5,6,7,8,9";
		return $this->generateRandomString($chars, $length);
	}

	private function generateRandomString($chars, $length)
	{
		$chars_array = explode(',', $chars);
		$charsLen = count($chars_array) - 1;
		shuffle($chars_array);
		$output = '';
		for($i = 0;$i < $length;$i++)
		{
			$output .= $chars_array[mt_rand(0, $charsLen)];
		}
		return $output;
	}

	/**
	 * 根据域名判断域名分组是否符合
	 * @param string $domain
	 * @return boolean
	 */
	private function checkDomainGroup($domain, $groups)
	{
		if(empty($domain) or empty($groups))
		{
			return FALSE;
		}
		$dnGroups = array();
		$domainIf = new \interfaces\manage\Domains();
		$dnGroupInfo = $domainIf->getDomainGroup($domain);
		if(is_array($dnGroupInfo))
		{
			switch($dnGroupInfo['domainSysOne'])
			{
				case 1:
					$dnGroups[] = 1;
					if($dnGroupInfo['domainLength'] <= 5)
					{
						$dnGroups[] = 1 + $dnGroupInfo['domainLength'];
					}
					break;
				case 2:
					$dnGroups[] = 1;
					$dnGroups[] = 20;
					if($dnGroupInfo['domainLength'] <= 5)
					{
						$dnGroups[] = 1 + $dnGroupInfo['domainLength'];
					}
					break;
				case 3:
					$dnGroups[] = 1;
					$dnGroups[] = 21;
					break;
				case 101:
					$dnGroups[] = 7;
					if($dnGroupInfo['domainLength'] <= 5)
					{
						$dnGroups[] = 7 + $dnGroupInfo['domainLength'];
					}
					break;
				case 102:
					$dnGroups[] = 19;
					break;
				case 201:
					$dnGroups[] = 13;
					break;
				case 202:
					$dnGroups[] = 14;
					break;
				case 203:
					$dnGroups[] = 15;
					break;
			}
			if($dnGroupInfo['domainSysTwo'])
			{
				switch($dnGroupInfo['domainSysTwo'])
				{
					case 1:
						$dnGroups[] = 16;
						break;
					case 2:
						$dnGroups[] = 17;
						break;
					case 3:
						$dnGroups[] = 18;
						break;
				}
				$dnGroups[] = 7;
				if($dnGroupInfo['domainLength'] <= 5)
				{
					$dnGroups[] = 7 + $dnGroupInfo['domainLength'];
				}
			}
		}
		$mixGroups = array_intersect($dnGroups, $groups);
		if(!empty($mixGroups))
		{
			return TRUE;
		}
		return FALSE;
	}
	
	private function checkTopDomain($domain)
	{
		if(!in_array($this->checkUseType,array(2,3)))
		{
			return FALSE;
		}
		$topDomainLib = new \lib\manage\domain\DomainTopLib();
		$topInfo = $topDomainLib->checkTopDomain($domain, date('Y'));
		if(!is_array($topInfo))
		{
			return FALSE;
		}
		return true;
	}
	

	/**
	 * 获取域名后缀
	 */
	private function getDomainExps($domains)
	{
		$rs = array();
		foreach ($domains as $value)
		{
			$domainSuffix = \lib\manage\common\DomainFunLib::getDomainClass($value);
			$rs[] = '.'.strtolower($domainSuffix);
		}
		return array_unique($rs);
	}
	
	/**
	 * 检测域名是否在做活动
	 * @param array $coupon
	 * @param array $domainExps
	 */
	private function checkActivity($domains, $moneyType, $couponDomainExp, $useType)
	{
		if($moneyType == 2 || $useType != 1)
		{
			return true;
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'activity');
		$activityDomainLtd = $conf->activityDomainltd->toArray();
		// 当前活动
		if(empty($activityDomainLtd))
		{
			//当前无活动
			return true;
		}
		$domainExps = self::getDomainExps($domains);
		// 检测活动
		foreach ($activityDomainLtd as $key => $domainLtd)
		{
			// 检测活动是否开始
			if(!\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck(false, $key))
			{
				return true;
			}
			// 活动开始，判断是否符合活动的后缀
			$result = array_intersect($domainLtd, $domainExps);
			// 活动后缀和购物车域名后缀无交集 或优惠券为“价格变更为n元”(允许使用的)
			if(empty($result))
			{
				return true;
			}
			// 优惠券和活动后缀的差集
			$couponActivityDiff = empty($couponDomainExp) ? true : array_diff($couponDomainExp, $domainLtd);
			// 优惠券能优惠所有后缀，同时购物车有活动外的域名
			if(true === $couponActivityDiff && array_diff($result, $domainExps))
			{
				return true;
			}
			// 优惠券能优惠购物车的且在活动外的域名(必须加is_array判断)
			if($couponActivityDiff && is_array($couponActivityDiff) && array_intersect($domainExps, $couponActivityDiff))
			{
				return true;
			}
		}
		return false;
	}
	
	public function getUsedPromoCode($data)
	{
		return $this->promoMod->getUsedPromoList($data);
	}
	
	public function getPromoList($params)
	{
		if(!empty($params['enameId']))
		{
			$data['enameId'] = $params['enameId'];
		}
		if(!empty($params['promoStatus']))
		{
			$data['promoStatus'] = $params['promoStatus'];
		}
		if(!empty($params['offset']))
		{
			$data['offset'] = $params['offset'];
		}
		if(!empty($params['num']))
		{
			$data['num'] = $params['num'];
		}
		if(!empty($params['promoTypeId']))
		{
			$data['promoType'] = $params['promoTypeId'];
		}
		return $this->promoMod->getUserPromoCard($data);
	}
}

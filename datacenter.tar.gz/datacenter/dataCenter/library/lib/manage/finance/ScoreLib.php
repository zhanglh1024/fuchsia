<?php
namespace lib\manage\finance;
class ScoreLib
{
	private $enameId;
	private $scoreId;
	private $score;
	private $currentScore;
	private $orderId;
	private $createTime;
	private $scoreType;
	private $scoreRemark;

	private $finLog;
	private $scoreMod;
	private $scoreScMod;

	function __construct($enameId = 0)
	{
		$this->enameId = $enameId;
		$this->finLog = new FinanceLogLib();
		$this->scoreMod = new \models\manage\finance\FinScoreMod();
		$this->scoreCsMod = new \models\manage\finance\FinScoreConsumeMod();
	}

	public function setEnameId($enameId)
	{
		$this->enameId = $enameId;
	} 
	
	public function setScoreId($scoreId)
	{
		$this->scoreId = $scoreId;
	}
	
	public function setScore($score)
	{
		$this->score = $score;
	}
	
	public function setCurrentScore($currentScore)
	{
		$this->currentScore = $currentScore;
	}
	
	public function setOrderId($orderId)
	{
		$this->orderId = $orderId;
	}
	
	public function setCreateTime($createTime = FALSE)
	{
		$this->createTime = $createTime === FALSE ? date('Y-m-d H:i:s') : $createTime;
	}
	
	public function setScoreType($scoreType)
	{
		$this->scoreType = $scoreType;
	}
	
	public function setScoreRemark($scoreRemark)
	{
		$this->scoreRemark = $scoreRemark;
	}
	
	/**
	 * 添加积分记录
	 * @throws Exception
	 * @return int
	 */
	public function addScoreRecord()
	{
		$this->finLog->setMethod('addScoreRecord');
		$data = array('enameId' => $this->enameId, 'score' => $this->score, 'currentScore' => $this->currentScore,
				'createTime' => $this->createTime, 'scoreType' => $this->scoreType, 'orderId' => $this->orderId,
				'scoreRemark' => $this->scoreRemark);
		$scoreId = $this->scoreMod->addScore($data);
		if(FALSE == $scoreId)
		{
			$this->finLog->log('添加积分记录失败', $data, $scoreId, 1);
			throw new \Exception('添加积分记录失败', 410066);
		}
		$this->ScoreId = $scoreId;
		return $this->ScoreId;
	}

	/**
	 * 扣除积分
	 * @param int $changeScore
	 * @return boolean
	 */
	public function subScoreNum($changeScore)
	{
		$changeScore = intval($changeScore);
		if($changeScore < 0)
		{
			return FALSE;
		}
		$finMod = new \models\manage\finance\FinancesMod();
		if(FALSE == $finMod->subScore($changeScore, $this->enameId))
		{
			return FALSE;
		}
		return TRUE;
	}

	/**
	 *  添加消费积分记录
	 * @throws \Exception
	 * @return int|boolean
	 */
	public function addScoreConsumerRecord()
	{
		$this->createTime = empty($this->createTime) ? date('Y-m-d H:i:s') : $this->createTime;
		$data = array('enameId' => $this->enameId, 'score' => $this->score,
				'currentScore' => $this->currentScore, 'createTime' => $this->createTime,
				'scoreType' => $this->scoreType, 'orderId' => $this->orderId, 'consumerRemark' => $this->scoreRemark);
		$return = $this->scoreCsMod->addScoreConsumer($data);
		if(FALSE == $return)
		{
			throw new \Exception('添加消费积分记录失败', 410067);
		}
		$this->ScoreId = $return;
		return $return;
	}
	
	public function subScore($enameId, $score, $currentScore, $orderId, $remarkContent, $domain = '')
	{
		if($score<=0)
		{
			return FALSE; 
		}
			try
			{
				$scoreLib = new ScoreLib();
				$excepMsg = '系统退款：消费积分不足:' . "剩" . $currentScore . ",需扣" . $score . "<br>";
				$excepMsg .= "用户id：" . $enameId . "," . $remarkContent . $domain;
				if($score > $currentScore)
				{
					throw new \Exception($excepMsg, 410080);
				}
				$scoreLib->setEnameId($enameId);
				if(!$scoreLib->subScoreNum($score))
				{
					throw new \Exception($excepMsg .',扣除积分失败', 410081);
				}
				$scoreLib->setScore($score);
				$currentScore = $currentScore - $score;
				$scoreLib->setCurrentScore($currentScore);
				$scoreLib->setOrderId($orderId);
				$scoreLib->setScoreType(4);//退款
				$scoreLib->setScoreRemark($remarkContent . $domain);
				if(!$scoreLib->addScoreConsumerRecord())
				{
					throw new \Exception('系统退款：添加扣除积分记录失败!', 410081);
				}
				return true;
			}
			catch(\Exception $e)
			{
				$this->finLog->log('[0404]系统退款扣积分失败', array('score' => $score, 'EnameId' => $enameId), array('returnMsg' => $e->getMessage()), 0, 0);
				return FALSE;
			}
	}	
}

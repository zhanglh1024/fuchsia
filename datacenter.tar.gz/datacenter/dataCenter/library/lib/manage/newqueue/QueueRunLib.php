<?php
namespace lib\manage\newqueue;

/**
 * 队列执行lib
 */
class QueueRunLib
{

	private $queueTaskLib;

	private $queueNormalLib;

	public function __construct()
	{
		$this->queueTaskLib = new \lib\manage\newqueue\QueueTaskLib();
		$this->queueNormalLib = new \lib\manage\newqueue\QueueNormalLib();
	}

	/**
	 * 设置对列执行状态
	 *
	 * @param int $queueId
	 * @param int $taskId (批量任务需要传)
	 * @param string $type
	 */
	public function setRunning($queueInfo)
	{
		if($this->checkIsNormalQueue($queueInfo['Function']))
		{
			$this->queueNormalLib->setRunning($queueInfo['QueueId']);
		}
		else
		{
			if(! $queueInfo['TaskId'])
			{
				throw new \Exception('taskId error');
			}
			$this->queueTaskLib->setRunning($queueInfo['QueueId'], $queueInfo['TaskId']);
		}
	}

	/**
	 * 更新步骤数据
	 *
	 * @param array $data
	 * @param int $queueId
	 */
	public function updateStep($data, $queueInfo)
	{
		if(! $this->checkIsNormalQueue($queueInfo['Function']))
		{
			return $this->queueTaskLib->updateTaskStep($data, $queueInfo['QueueId']);
		}
	}

	/**
	 * 设置队列执行失败
	 *
	 * @param array $queueInfo
	 */
	public function updateFailure($queueInfo)
	{
		// 如果是批量任务(涉及主表和详细表)
		if($this->checkIsNormalQueue($queueInfo['Function']))
		{
			$this->queueNormalLib->updateNormalFailure($queueInfo['QueueId']);
		}
		else
		{
			$this->queueTaskLib->updateTaskFailure($queueInfo);
		}
	}
	
	/**
	 * 设置队列重启
	 *
	 * @param array $queueInfo
	 */
	public function updateResend($queueInfo)
	{
		// 如果是批量任务(涉及主表和详细表)
		if($this->checkIsNormalQueue($queueInfo['Function']))
		{
			$this->queueNormalLib->updateNormalResend($queueInfo['QueueId']);
		}
		else
		{
			$this->queueTaskLib->updateTaskResend($queueInfo['QueueId']);
		}
	}

	/**
	 * 更新队列执行成功
	 */
	public function updateSuccess($queueInfo)
	{
		// 如果是批量任务(涉及主表和详细表)
		if($this->checkIsNormalQueue($queueInfo['Function']))
		{
			$this->queueNormalLib->updateNormalSuccess($queueInfo['QueueId']);
		}
		else
		{
			$this->queueTaskLib->updateTaskSuccess($queueInfo);
		}
	}

	/**
	 * 取消任务
	 *
	 * @param string $function
	 * @param int $queueId
	 */
	public function cancelQueue($queueInfo)
	{
		if($this->checkIsNormalQueue($queueInfo['Function']))
		{
			$this->queueNormalLib->cancelQueue($queueInfo['Function'], $queueInfo['QueueId']);
		}
		else
		{
			$this->queueTaskLib->cancelQueue($queueInfo['Function'], $queueInfo['QueueId'] ,$queueInfo['TaskId'] );
		}
	}

	/**
	 * 添加重启队列
	 *
	 * @param array $queueInfo
	 */
	public function addRestarQueue($queueId, $queueInfo)
	{
		if($this->checkIsNormalQueue($queueInfo['Function']))
		{
			return $this->queueNormalLib->addRestarQueue($queueId, $queueInfo);
		}
		else
		{
			if($this->queueTaskLib->addRestarQueue($queueId, $queueInfo))
			{
				return $this->queueTaskLib->updateTaskDetail(array('Status' => 5), $queueInfo['QueueId']);
			}
		}
		return FALSE;
	}

	/**
	 * 判断是否普通队列(邮件、短信、语音)
	 *
	 * @param string $function
	 */
	private function checkIsNormalQueue($function)
	{
		return in_array($function, array('sendmail', 'send_sms', 'send_audio_sms'));
	}
}

<?php
namespace lib\manage\newqueue;

/**
 * 队列模板lib
 */
class QueueTemplateLib
{
 
	private $templateMod;

	public function __construct()
	{
		$this->templateMod = new \models\manage\newqueue\TemplateMod();
	}

	/**
	 * 通过模板名称获取模板信息
	 *
	 * @param string $templateName
	 * @param boolean $isDefault
	 */
	public function getInfoByTemplateName($templateName)
	{
		return $this->templateMod->getInfoByTemplateName($templateName);
	}

	/**
	 * 获取模板列表
	 *
	 * @param array $templateNames
	 * @return array|boolean
	 */
	public function getTemplateListByTemplateNames($templateNames)
	{
		$params = array('in' => array('TemplateName' => $templateNames), 'IsDefault' => 1);
		$list = array();
		if($result = $this->templateMod->getList($params))
		{
			foreach($result as $value)
			{
				$list[$value['TemplateName']] = $value;
			}
		}
		return $list;
	}

	/**
	 * 替换模板数据
	 *
	 * @param array $templateInfo 模板信息
	 * @param array $data 替换的数据
	 * @return array
	 */
	public function substituteTemplateData($templateInfo, $data, $enameId = '')
	{
		$dataKeys = $dataValues = array();
		if($enameId != '')
		{
			$dataKeys[] = '%enameId%';
			$dataValues[] = $enameId;
		}
		foreach($data as $key => $value)
		{
			$dataKeys[] = '%' . $key . '%';
			$dataValues[] = $value;
		}
		foreach($templateInfo as $key => $value)
		{
			$templateInfo[$key] = str_replace($dataKeys, $dataValues, $value);
		}
		return $templateInfo;
	}
}
<?php
namespace lib\manage\newqueue;

/**
 * 发送邮件
 */
class MailerLib
{

	private $mailer;

	private $mailCommonConfig;

	private $mailerConfig;

	/**
	 * 构造方法
	 *
	 * @param string $mailerName mailQueue(队列邮件)|mailRealTime(实时邮件)
	 */
	public function __construct($mailerName = 'mailQueue')
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/queue.ini', 'queueNormal');
		$this->mailer = new \lib\manage\newqueue\PHPMailerLib();
		$this->mailCommonConfig = $conf->toArray();
		$this->mailerConfig = $this->mailCommonConfig[$mailerName];
	}

	/**
	 * 发送邮件
	 *
	 * @param array $templateData
	 * @param array $data
	 */
	public function sendMail($templateData, $queueData)
	{
		$templateData = $this->getMailCharset($queueData['Target'], $templateData);
		$this->mailer->CharSet = $templateData['CharSet'];
		$this->mailer->IsSMTP();
		$this->mailer->SMTPAuth = $this->mailerConfig['SMTPAuth'];
		$this->mailer->SMTPSecure = $this->mailerConfig['SMTPSecure'];
		$this->mailer->Host = $this->mailerConfig['Host'];
		$this->mailer->Port = $this->mailerConfig['Port'];
		$this->mailer->Username = $this->mailerConfig['Username'];
		$this->mailer->Password = $this->mailerConfig['Password'];
		// 邮件标题
		$this->mailer->Subject = $templateData['TemplateTitle'];
		// 邮件文本内容
		$this->mailer->AltBody = $templateData['AltContent'];
		// 邮件html内容
		$this->mailer->MsgHTML($templateData['HtmlContent']);
		// 设置回复邮件地址Send
		$this->mailer->AddReplyTo($this->mailerConfig['senderMail'], $templateData['Sender']);
		// 设置发信人地址
		$this->mailer->SetFrom($this->mailerConfig['senderMail'], $templateData['Sender']);
		// 设置收件人地址
		$this->mailer->AddAddress($queueData['Target'], $queueData['Target']);
		// 相关模板秘密抄送
		if(in_array($templateData['TemplateName'], $this->mailerConfig['FOATemp']))
		{
			$this->mailer->AddBCC($this->mailerConfig['MailBcc']);
		}
		$result = @ $this->mailer->Send();
		return $result;
	}

	/**
	 * 设置邮件编码
	 *
	 * @param string $email
	 */
	private function getMailCharset($email, $templateData)
	{
		// 默认编码
		$templateData['CharSet'] = 'utf-8';
		$templateData['Sender'] = $this->mailerConfig['sender'];
		$emailArray = explode('@', $email);
		$emailSuffix = str_replace('.', '', $emailArray[1]);
		$mailCodes = $this->mailCommonConfig['mailCodes'];
		if(isset($mailCodes[$emailSuffix]) && $mailCodes[$emailSuffix])
		{
			$templateData['CharSet'] = $mailCodes[$emailSuffix];
			$templateData['Sender'] = iconv("utf-8", $templateData['CharSet'] . "//IGNORE", 
				$this->mailerConfig['sender']);
			$templateData['TemplateTitle'] = iconv('utf-8', $templateData['CharSet'] . "//IGNORE", 
				$templateData['TemplateTitle']);
			$templateData['AltContent'] = iconv('utf-8', $templateData['CharSet'] . "//IGNORE", 
				$templateData['AltContent']);
			$templateData['HtmlContent'] = iconv('utf-8', $templateData['CharSet'] . "//IGNORE", 
				$templateData['HtmlContent']);
		}
		return $templateData;
	}

	/**
	 * 获取邮件内容
	 */
	public function getMailContent($templateData, $queueData)
	{
		// 模板地址
		$templateFileName = $this->mailCommonConfig['mailTemplateHtml'] . $queueData['TemplateName'] . '.html';
		$com_template_fileName = $this->mailCommonConfig['mailTemplateHtml'] . "email.html";
		$filePath = file_exists($templateFileName) ? $templateFileName : $com_template_fileName;
		$content = file_get_contents($filePath);
		// 替换数据
		if(is_array($queueData['Data']) && count($queueData['Data']))
		{
			foreach($queueData['Data'] as $key => $value)
			{
				$dataKeys[] = '%' . $key . '%';
				$dataValues[] = $value;
			}
		}
		$dataKeys[] = "%body%";
		$dataValues[] = $templateData['HtmlContent'];
		$content = str_replace($dataKeys, $dataValues, $content);
		$templateData['HtmlContent'] = $content;
		return $templateData;
	}
}

<?php
namespace lib\manage\cart;
use core\Response;

use core\form\ReturnData;
use lib\manage\common\DomainFunLib;

class CartLib
{
	public $enameId = 0;
	public $cartConf;
	public $recart = true;
	public function __construct($enameId)
	{
		$this->enameId = $enameId;
		$this->cartConf = new \Yaf\Config\Ini(APP_PATH . '/conf/cart.ini', 'cart');
	}
	/**
	 * 获取购物车结算数据
	 */
	public function getResultData($cartData)
	{
		$postData = json_decode($_POST['product'], true);
		if(empty($postData) || !is_array($postData) || count($postData) > 20)
		{
			throw new \Exception($this->cartConf->errorMsg->emptyData, 311010);
		}
		$cart = FALSE;
		if(is_array($postData) && count($postData) == 1)
		{
			$cart = isset($postData[0]['cart']) ? $postData[0]['cart'] : $cart;
		}
		$enameId = $cartData->enameId;
		$questionId = empty($cartData->questionId) ? '' : trim($cartData->questionId);
		$phoneCode = empty($cartData->phonecode) ? '' : trim($cartData->phonecode);
		$answer = empty($cartData->answer) ? '' : trim($cartData->answer);
		$password = empty($cartData->password) ? '' : trim($cartData->password);
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'operate');
		$cartFlag = $conf->member_setting->set_operation->toArray();
		$cartFlag = $cartFlag[0];
		//验证是否通过操作保护或是手机验证
		$operation = new \interfaces\manage\UserCaptcha();
		$sendOp = array('identify' => $cartFlag, 'EnameId' => $this->enameId, 'answer' => $answer, 'pass' => $password,
				'questionId' => $questionId, 'captcha' => $phoneCode, 'cart' => $cart);
		$proInfo = $operation->checkOperateData((object) $sendOp);
		if($proInfo)
		{
			return $postData;
		}
		$errMsg = Response::getErrMsg();
		$code = Response::getErrCode();
		$code = $code ? $code : 100001;
		throw new \Exception(empty($errMsg) ? '系统故障' : $errMsg, $code);
	}

	/**
	 * 单个域名结算
	 * @param array $domainInfo = array('domain' => $domain, 'year' => $year, 'coupon' => '', 'productName' => $productName,
	 'email' => $email, 'userLevel' => $userLevel, 'expDate' => $expDate,
	 'productType' => $productType, 'templateId' => $templateId, 'shopType' => $shopType))
	 * @param DomainRegists $registModule
	 * @param string $tempTemplateId
	 * @param array $domainLtdArray
	 * @throws Webpie_Handler_Exception
	 * @return string
	 */
	public function singleDomainResult($domainInfo, $registLib, $tempTemplateId, $domainLtdArray)
	{
		$errorMsg = '';
		$this->recart = true;
		try
		{
			extract($domainInfo);
			if(!empty($remarkHide))
			{
				$domainInfo['remarkHide'] = $remarkHide;
			}
			$specialYear = $year;
			if($specialYear)
			{
				$domainInfo['year'] = $specialYear;
			}
			$orderStatus = false;
			$orderLib = new \interfaces\manage\Finance();
			\lib\manage\common\DomainOpenLib::checkOpen($type == 1 ? 'create' : 'renew', $domain, TRUE);
			$orderInfo = $orderLib->addProductOrder((object) $domainInfo);
			if(is_array($orderInfo) || $orderInfo === false)
			{
				throw new \Exception($this->cartConf->errorMsg->orderErr, 311008);//订单创建失败
			}
			\core\Log::write('appcreateorder_' . $type . '_' . $orderInfo, 'cart', 'order');
			$result = '';
			$registLib = new \lib\manage\domain\DomainRegistLib($this->enameId);
			$transferInLib = new \lib\manage\domain\DomainTransferInLib($this->enameId);
			if($type == 1) //注册
			{
				try
				{
					$result = $registLib->domainRegist($domain, $templateId, $orderInfo, $year, $productType, $productName, $email, $tempTemplateId, $domainLtdArray);
					if($result['code'] == 1001)
					{
						$this->recart = $result = FALSE;//1001的不让重新注册
						$errorMsg = $this->cartConf->errorMsg->regedErr;
					}
					else if($result['code'] == 1000)
					{
						$orderStatus = true;
					}
					else
					{
						$result = false;
					}
				}
				catch(\Exception $e)
				{
					$errorMsg = $e->getMessage();
					\core\Log::write($e->getMessage(), 'cart', 'reg');
					if(stripos($errorMsg, 'Could not connect') !== false) // 若是返回回超时暂时不处理订单
					{
						$orderStatus = -1;
						$result = false;
					}
					else
					{
						$orderStatus = $result = false;
					}
				}
			}
			else if($type == 2) //  2转入
			{
				$transferStatus = $transferInLib->domainTransferIn($domain, $ext, $orderInfo, $templateId, $year, $productType);//
				$result = $orderStatus = (is_array($transferStatus) || $transferStatus == false) ? false : true;
				if(is_array($transferStatus))//已经存在的不让重新转入
				{
					$this->recart = FALSE;
				}
			} 
			else if($type == 3)//3续费
			{ 
				$dnLib = new \lib\manage\domain\DomainManageLib();
				$oldInfo = $dnLib->getDomainInfo(array('DomainName'=>$domain));
				$orderStatus = $result = $this->domainRenew($domain, $year, $expDate);
				if($orderStatus)
				{
					$redis = \core\RedisLib::getInstance('manage', false);
					$redis->set($this->enameId . strtolower($domain) . 'for_repeate_renewal_mark', '1', 86400);//续费成功写续费记录redis，24h后过期.
				}
			}
			$confirm = array('orderId' => $orderInfo, 'enameId' => $this->enameId);
			if($orderStatus && $type == 3 && DomainFunLib::checkIsVspDomainLtd($domain) && $dnLib->cooperRegidDomainCheckNew($domain,$oldInfo))
			{
				$errorMsg = '';
			}
			else
			{
				if($orderStatus !== -1) // -1请求超时不处理订单
				{
					$this->confirmOrder($orderLib, $orderStatus, $type, $confirm, $domain);
				}
			}
			if(empty($result))
			{
				$throwMsg = $errorMsg ? $errorMsg : $this->cartConf->errorMsg->overCartErr;
				throw new \Exception($throwMsg, 311009); // 域名结算失败
			}
		}
		catch(\Exception $e)
		{
			$errorMsg = $e->getMessage();
		}
		return $errorMsg;
	}

	/**
	 * 确认订单 注册续费直接确认订单 转入失败确认订单
	 */
	private function confirmOrder($orderLib, $orderStatus, $shopType, $confirm, $domain)
	{
		if($shopType == 1 || $shopType == 3)
		{
			if($orderStatus)
			{
				$st = $orderLib->confirmOrder((object) $confirm);
				\core\Log::write('appconfirmorder_' . $shopType . '_' . $confirm['orderId'] . '_' . ($st ? 'success' : 'failed'), 'cart', 'order');
				if($st && $shopType == 3 && \lib\manage\common\DomainFunLib::isTopDomainType($domain) == TRUE)//续费成功后查看是否是珍品域名 是的话添加记录
				{
					$topLib = new \lib\manage\domain\DomainTopLib();
					$topLib->topDomainDone($shopType, $domain, $confirm['enameId']);
				}
				$this->domainCountSet($shopType, $domain);
				return $st;
			}
			$cancelSt = $orderLib->cancelOrder((object) $confirm);
			\core\Log::write('appcancelorder_' . $shopType . '_' . $confirm['orderId'] . '_' . ($cancelSt ? 'success' : 'failed'), 'cart', 'order');
			return $cancelSt;
		}
		if($shopType == 2)
		{
			if($orderStatus == false)
			{
				$cancelSt = $orderLib->cancelOrder((object) $confirm);
				\core\Log::write('appcancelorder_' . $shopType . '_' . $confirm['orderId'] . '_' . ($cancelSt ? 'success' : 'failed'), 'cart', 'order');
				return $cancelSt;
			}
			$this->domainCountSet($shopType, $domain);
		}
	}

	/**
	 * 域名续费
	 * 成功时检查是否是过期20天以上域名
	 * 如果是过期20天以上的域名要进行DNS的还原
	 * 不是的话不操作
	 */
	public function domainRenew($domain, $year, $expDate)
	{
		if(empty($domain) || empty($year) || empty($expDate))
		{
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, json_encode(array($year, $expDate)), 6);
			return FALSE;
		}
		try
		{
			$interfaces = new \interfaces\manage\Domains();
			$data = array('domain' => $domain, 'year' => $year, 'expDate' => $expDate, 'enameId' => $this->enameId);
			$returnData = $interfaces->domainRenew($data);
			if(!$returnData)
			{
				return FALSE;
			}
			$this->renewSuccRestoreDns($domain, $year, $expDate);
			return $returnData;
		}
		catch(\Exception $e)
		{
			\core\Log::write('domainrenewfailed,domain:' . $domain, 'domain', 'domainrenew');
			return FALSE;
		}
	}

	/**
	 * 如果是过期20天以上的域名要进行DNS的还原
	 */
	private function renewSuccRestoreDns($domain, $year, $expDate)
	{
		$dnManage = new \lib\manage\domain\DomainManageLib();
		$dnInfo = $dnManage->getDomainInfo(array('DomainName' => $domain, 'EnameId' => $this->enameId));
		if(empty($dnInfo) || $dnInfo['DomainHoldStatus'] != 2)
		{
			return FALSE;
		}
		try
		{
			$memberLib = new \lib\manage\member\MemberLib();
			$interface = new \interfaces\manage\Domains();
			$userInfo = $memberLib->getMemberInfoByEnameId($this->enameId);
			$email = isset($userInfo['Email']) ? $userInfo['Email'] : FALSE;
			$restoreData = array('domain' => $domain, 'expDate' => $expDate, 'enameId' => $this->enameId,
					'email' => $email, 'extData' => $dnInfo);
			$interface->renewSuccRestoreDns($restoreData);
		}
		catch(\Exception $e)
		{
			\core\Log::write(json_encode(array($domain, 'year:' . $year, 'enameId:' . $this->enameId,
					'msg:' . $e->getMessage())), 'domain', 'domainRenew');
		}
	}

	/**
	 * 1域名注册 3续费 2转入成功后添加统计数据
	 */
	public function domainCountSet($shoptype, $domain)
	{
		if( empty($_REQUEST['user']) || $_REQUEST['user'] != 'api')
		{
			return TRUE;
		}
		\core\Log::write("domainbakinfo,$shoptype,$domain", 'domain', 'domaincountinfo');
		try
		{
			$redisKey = $shoptype == 1 ? 'appdomainreg_' . date('Y-m-d') : ($shoptype == 2 ? 'appdomaintransferhash_' . date('Y-m-d') : 'appdomainrenew_' . date('Y-m-d'));
			$redis = new \lib\manage\common\RedisLib(false);
			if($shoptype == 2)
			{
				if(FALSE == $redis->setHashData($redisKey, $domain))
				{
					\core\Log::write($redisKey . "addfailed,msg,$shoptype,$domain", 'domain', 'domaincountfailed');
				}
			}
			else
			{
				if(FALSE == $redis->incrData($redisKey))
				{
					\core\Log::write($redisKey . "addfailed,msg,$shoptype,$domain", 'domain', 'domaincountfailed');
				}
			}
		}
		catch(\Exception $e)
		{
			\core\Log::write("redis error,msg,$shoptype,$domain", "domain", "domaincountfailed");
		}
	}

}

namespace php user
namespace go user

struct DoBindReturn {
	1: required i32 Code         #100000为绑定成功 100001 为已绑定过 不可重复绑定  100002 为绑定失败
	2: required string Message	 #对应描述
}

struct DoSetOpenedReturn {
	1: required i32 Code         #100000为开启成功 100001 获取不到指定的uid,无法操作  100002 为设定失败
	2: required string Message	 #对应描述
}

struct CreditDetail{
	1:i32 		CreditExtensionId     
	2:i32 		MemberId              
	3:double 	TotalCreditExtension  
	4:double 	UsableCreditExtension 
}

struct PledgeDetail{
	1:i32 		PledgeId   
	2:string 	Domain  
	3:double	UsableAmount 
	4:i32 		TotalNum  
}

struct  GetUserCreditReturn{
	1:required i32 Code
	2:required string Msg
	3:bool IsBind
	4:bool IsOpen
	5:CreditDetail Credit
	6:list<PledgeDetail> PledgeList
	7:i32 MiDaiId
}

struct MemberGoogleParams{
	1:required i32 EnameId
	2:required i64 Ip
	3:required string Sign
	4:required string CapCode
}

struct RebindGoogleAuthParams{
	1:required i32 EnameId
	2:required string Sign
	3:required string CapCode
	4:required i64 IP
}

struct CheckGoogleReturn{
	1:required bool Status
	2:required string Msg
}

service MiDaiApiServer {
	#执行绑定操作 
	DoBindReturn DoBind(1:i32 uid, 2: byte bindType, 3: i32 bindUid)
	#设置开启
	DoSetOpenedReturn SetOpened(1: i32 uid)
	//  detail detail 0:不显示域名授信详情 1:显示域名授信详情
	GetUserCreditReturn GetUserCredit(1:i32 uid, 2:byte detail)
}


service MemberInfoServer {
	string GetMemberEmail(1:i32 uid)
	string GetMemberPhone(1:i32 uid)
}

//管理公告接口
struct GetAnnounceListParam{
    1: byte Purpose //8 ename_net_index 9 ename_member 10 ename_wap_index
    2: i64 BeginTime
    3: i64 EndTime
    4: byte LangType //1中文 2英文
    5: list<map<string,string>> Order
    6: i32 Limit
    7: i32 Offset
	8: i32 AnnounceId
	9: byte ParamType
	10: bool CountFlag
	11: string 	Title
}

struct AnnounceTableParam{
	1:string 		 Title     
	2:string 		 Content    
	3:i64			 BeginTime  
	4:i64 	 	  	 EndTime   
	5:string  		 AdminName  
	6:string         Purpose    
	7:i32			 Sort       
	8:string         Color             
	9:byte			 Type       
	10:string 		 Html5Title 
	11:byte			 LangType   
	12:i32			 ParentId   
	13:i32  		AnnounceId
	14:i64 			CreateTime
}

struct GetAnnounceListReturn{
    1:  i32 Count
    2:  list<AnnounceTableParam> Data
}

struct GetAnnounceInfoReturn{
	1: i32 Code
	2: string Msg
	3: AnnounceTableParam Data
}

//公告服务
service AnnounceService{
    GetAnnounceListReturn GetAnnounceList(1:GetAnnounceListParam params)
	i32 AnnounceAdd(1:AnnounceTableParam params)
	bool UpdataAnnouce(1:AnnounceTableParam params,2:i32 Id)
    GetAnnounceInfoReturn GetAnnounceInfo(1:i32 AnnounceId)
	i32 AnnounceDelete(1:i32 Id)
	GetAnnounceListReturn GetAnnounceTitles()
	GetAnnounceListReturn GetAllList(1:GetAnnounceListParam params)
}
 
//谷歌绑定相关服务
service MemberGoogleAuthService{
    string GetMemberAuthenUrl(1:i32 EnameId)
	CheckGoogleReturn BindMemberAuthen(1:MemberGoogleParams params)
	CheckGoogleReturn RebindMemberAuth(1:RebindGoogleAuthParams params)
	CheckGoogleReturn CheckGoogleAuthCode(1:i32 EnameId,2:string CapCode)
}

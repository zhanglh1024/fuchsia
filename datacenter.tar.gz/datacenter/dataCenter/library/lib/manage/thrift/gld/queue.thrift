namespace php enamequeue
namespace go enamequeue

struct QueueNormalParam {
	1: required string Function
	2: required string Target
	3: required i32 EnameId
	4: required string TemplateName
	5: required byte Priority
	6: required map<string,string> DataMap
}

struct QueueNormalReturn {
	1: required i32 Code
	2: required string Message
	3: required i32 Id
}

struct QueueNormalRebootReturn {
	1: required i32 Code
	2: required string Message
	3: required list<i32> sucArr
	4: required list<i32> failArr
}


struct TemplatePushData {
   1:required string Domain
   2:required string TemplateId
   3:required string OldTemplateId    
   4:required string RegistrarId
   5:required string TempType      
   6:required string NewTemplateName
   7:required string OldTemplateName 
}

struct TemplatePushParam{
	1: required i32 EnameId 
	2: required string Function
	3: required byte Priority 
	4: required byte Hidden
	5: required list<TemplatePushData> TemplatePushDatas
}

struct TemplagePushReturn {
	1: required i32 Code
	2: required string Message
	3: required i32 Id
}

struct DnsData {
	1: required string Domain
	2: required string DomainId
	3: required map<string,string> DNS
	4: required string DnsType
	5: required string RegistrarId
}

struct DnsParam{
	1: required i32 EnameId
	2: required string Function
	3: required byte Priority
	4: required byte Hidden
	5: required list<DnsData> Datas
}


struct DnsReturn {
	1: required i32 Code
	2: required string Message
	3: required i32 Id
}


service Queue{
	QueueNormalReturn AddNormalQueue(1:QueueNormalParam qnp)
	QueueNormalRebootReturn RebootAddNormalQueue(1:list<i32> qnp)
	TemplagePushReturn AddTemplatePushQueue(1:TemplatePushParam param)
	DnsReturn AddDnsQueue(1:DnsParam param)
}


namespace go vsp
namespace php vsp



//idType 身份证明类型 
const  string IDTYPE_SFZ = "SFZ"		//身份证
const  string IDTYPE_HZ = "HZ"		//护照
const  string IDTYPE_JGZ = "JGZ"		//军官证
const  string IDTYPE_QT = "QT"		//其他


//orgProofType 组织证明类型 
const string ORGPTYPE_YYZZ = "YYZZ"	//营业执照
const string ORGPTYPE_ORG = "ORG"	//组织机构代码证
const string ORGPTYPE_QT = "QT"	//其他

//orgType 企业类型
const string ORGTYPE_PR = "PR"		//个体
const string ORGTYPE_PU = "PU"	//工商

//registrantType 注册人类型
const string REGTYPE_E = "E"		//组织
const string REGTYPE_I = "I"		//个人

//userRegion 用户类型
const string USERREG_D = "D"		//国内用户
const string USERREG_F = "F"		//海外用户

//code 
const string CODE_ERROR = "error"
const string CODE_SUCCESS = "success"

//auditStatus 审核结果
const string  AUDSTATUE_AUDITING = "auditing"	//审核中
const string  AUDSTATUE_PASS = "pass"			//审核通过
const string  AUDSTATUE_UNPASS = "unpass"		//审核未通过




//cnRegistrantUpload 的 registrant 结构
struct Registrant{
	1: required string registrantId
	2: required string idType
	3: required string idCode
	4: string orgProofType
	5: string orgCode
	6: string orgType
	7: required string registrantType
	8: string blInfo
	9: required string userRegion
}
//注册人资料上传 结构
struct CnRegistrantUpload{
	1: required Registrant registrant
	2: required string idImg
	3: string orgImg
	4: string otherImg
}


// 注册人资料上传 返回信息 结构
struct RegistrantUploadReturn{
	1: required string code
	2: string description
}

//域名信息上传返回信息 结构
struct DomainUploadReturn{
	1: required string code
	2: string description
	3: string businessCode
}

//域名审核结果查询 返回信息结构
struct DomainQueryReturn{
	1: required string code
	2: string description
	3: string domain
	4: string auditStatus
	5: string dnvc
	6: string rejectReasonSet
}

//注册人审核结果查询 返回信息结构
struct RegistrantQueryReturn{
	1: required string code
	2: string description
	3: string registrantId
	4: string auditStatus
	5: string auditDate
	6: string registrantOrg
	7: string documentType
	8: string documentCode
	9: string rejectReasonSet
	10: string rnvc
}

struct GetDomainCodeReturn{
	1:bool flag
	2:string msg
	3:string businessCode
	4:string rejectReasonSet
}

struct GetRegistrantCodeReturn{
	1:bool flag
	2:string msg
}

// 实名id上传关系参数
struct RegistrantRelUploadParam {
	1:string CnnicRegistrantId
	2:string ContactId
}

// 实名id上传关系返回值
struct RegistrantRelUploadReturn {
	1:string Code
	2:string Description
}

service Vsp{
	RegistrantUploadReturn RegistrantUpload(1:CnRegistrantUpload ru)
	DomainUploadReturn DomainUpload(1:string domain)
	DomainQueryReturn DomainQuery(1:string domain,2:string businessCode)
	RegistrantQueryReturn RegistrantQuery(1:string registrantId)
	map<string,DomainUploadReturn>BatchDomainUpload(1:list<string> domains)
	map<string,DomainQueryReturn>BatchDomainQuery(1:map<string,string> params)
	RegistrantRelUploadReturn RegistrantRelUpload(1:RegistrantRelUploadParam param)
	map<string,RegistrantRelUploadReturn> BatchRegistrantRelUpload(1:map<string,RegistrantRelUploadParam> params)
}

<?php
namespace lib\manage\common;
use core\Response;
class DomainOpenLib
{
	public function __construct()
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domainquery');
	}

	/**
	 * 检查域名相关接口是否开放
	 * @param string $interName
	 * @param string $domain
	 * @param boolean $isShow
	 * @throws \Exception
	 * @return boolean
	 */
	public static function checkOpen($interName, $domain, $isShow = FALSE)
	{
		if(time() < strtotime('2015-08-03 23:30:00') && time() > strtotime('2014-08-03 08:30:00') && \lib\manage\common\DomainFunLib::isChinaDomain($domain))
		{
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domainquery');
			$conf = $conf->openInter->toArray();
			$check = isset($conf[$interName]) && intval($conf[$interName]) !== 1 ? FALSE : TRUE;
			if(FALSE == $check)
			{
				if($isShow)
				{
					throw new \Exception($conf['errMsg'], 399999);
				}
				else
				{
					Response::setErrMsg(399999, $conf['errMsg']);
				}
			}
			return $check;
		}
		return TRUE;
	}

	/**
	 * 域名相关功能临时开关
	 * @param boolean $isThow
	 * @param string $type
	 * @throws \Exception
	 * @return boolean
	 */
	public static function tmpFuncOpenCheck($isThow = TRUE, $type = 'cn')
	{
		$now = time();
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'activity');
		$activitytime = $conf->activitytime->toArray();
		if($type == 'cnActivity')
		{
			if($now <= strtotime($activitytime['cnreg']['end']) && $now >= strtotime($activitytime['cnreg']['start']))
			{
				return TRUE;
			}
			return FALSE;
		}
	    if($type == 'ccActivity')
	    {
	     	if($now <= strtotime($activitytime['cc']['end']) && $now >= strtotime($activitytime['cc']['start']))
	     	{
	      		return TRUE;
	      	}
	      	return FALSE;
	    }
		if($type == 'topActivity') 
		{
			if($now <= strtotime($activitytime['top']['end']))
			{
				return TRUE;
			}
			return FALSE;
		}
		if($type == 'wangActivity')
		{
			if($now <= strtotime($activitytime['wang']['end']))
			{
				return TRUE;
			}
			return FALSE;
		}
		if($type == 'netActivity')   
		{
			if($now >= strtotime($activitytime['net']['start']) && $now <= strtotime($activitytime['net']['end'])) 
			{
				return TRUE;
			}
			return FALSE;
		}
		if($type == 'chinaActivity')
		{
			if($now >= strtotime($activitytime['china']['start']) && $now <= strtotime($activitytime['china']['end']))
			{
				return TRUE;
			}
			return FALSE;
		}
		if($type == 'companyActivity')
		{
			if($now >= strtotime($activitytime['company']['start']) && $now <= strtotime($activitytime['company']['end']))
			{
				return TRUE;
			}
			return FALSE;
		}
		if($type == 'internetActivity')
		{
			if($now >= strtotime($activitytime['internet']['start']) && $now <= strtotime($activitytime['internet']['end']))
			{
				return TRUE;
			}
			return FALSE;
		}
		if($type == 'clubActivity')
		{
			if($now >= strtotime($activitytime['club']['start']) && $now <= strtotime($activitytime['club']['end']))
			{
				return TRUE;
			}
			return FALSE;
		}
		if($now >= strtotime($activitytime['cn']['start']) && $now <= strtotime($activitytime['cn']['end']) && $type == 'cn')
		{
			if($isThow)
			{
				throw new \Exception("CNNIC正在进行CN域名、中文域名系统维护工作，暂停相关服务。", 399999);
			}
			return FALSE;
		}
		if($type == 'cnnet')
		{
			return $now >= strtotime($activitytime['cnnet']['start']) && $now <= strtotime($activitytime['cnnet']['end']);
		}
		if($type == 'comActivity') 
		{
			if($now <= strtotime($activitytime['com']['end']) && $now >= strtotime($activitytime['com']['start']))
			{
				return TRUE;
			}
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * 返回域名的开关控制 0616
	 * @param string $option
	 * @throws Exception
	 */
	public static function domainOpen($option = 'query')
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$domainOpen = $conf->domain->domainopen->toArray();
		if(is_array($domainOpen) && isset($domainOpen[$option]) && $domainOpen[$option] == FALSE)
		{
			switch($option)
			{
				case 'query':
					echo '{"code":99}';//300001
					break;
				case 'register':
					throw new \Exception('注册功能已经关闭', 300002);
					break;
				case 'renew':
					throw new \Exception('续费功能已经关闭', 300003);
					break;
				case 'push':
					throw new \Exception('PUSH功能已经关闭', 300004);
					break;
				case 'queue':
					echo '队列功能已经关闭' . 300005;
					break;
				case 'topdomain':
					throw new \Exception('珍品功能相关已经关闭', 300007);
					break;
				default:
					throw new \Exception('此功能已经关闭', 300006);
					break;
			}
			exit;
		}
	}

	/**
	 * 中文.cn域名功能临时关闭开关
	 * @param string $domain
	 * @param string $option
	 * @return boolean
	 */
	public static function domainOpenCN($domain, $option)
	{
		$stratTime = '2012-10-21 00:00:00';
		$endTime = '2012-10-30 23:59:59';
		if(time() < strtotime($stratTime) || time() > strtotime($endTime))
		{
			return TRUE;
		}
		if(is_string($domain))
		{
			$domains[] = $domain;
			$domain = $domains;
		}
		foreach($domain as $v)
		{
			self::checkSuffixOption($v, $option);
		}
		return TRUE;
	}

	/**
	 * 中文.cn功能临时关闭开关
	 * @param string $domain
	 * @param string $option
	 * @throws Exception
	 */
	private static function checkSuffixOption($domain, $option)
	{
		$suffix = \lib\manage\common\DomainFunLib::getDomainClass($domain);
		if(\lib\manage\common\DomainFunLib::isChineseCnDomain($domain) && $suffix != '公司' && $suffix != '网络')
		{
			switch($option)
			{
				case 'push':
					$error = 'PUSH功能已关闭';
					$code = 300007;
					break;
				case 'renew':
					$error = '续费功能已关闭';
					$code = 300008;
					break;
				case 'batchrenew':
					$error = '批量续费功能已关闭';
					$code = 300009;
					break;
				case 'temppush':
					$error = '模板过户功能已关闭';
					$code = 300010;
					break;
				case 'transferout':
					$error = '转出功能已关闭';
					$code = 300011;
					break;
				case 'transferin':
					$error = '转入功能已关闭';
					$code = 300012;
					break;
				default:
					$error = '域名功能已关闭';
					$code = 300006;
					break;
			}
			throw new \Exception('中文.cn' . $error, $code);
		}
	}

	/**
	 * 检测注册域名是否是公司网络域名
	 */
	public static function checkDomainCompanyNet($domain, $shopType)
	{
		$suffix = \lib\manage\common\DomainFunLib::getDomainClass($domain);
		if($shopType == 1)//注册
		{
			if($suffix == "公司" || $suffix == "网络")
			{
				return FALSE;
			}
		}
		return TRUE;
	}
}

<?php 
namespace lib\manage\common;
use core\Response;
class DomainFunLib
{

	/**
	 * 检测域名注册时间，是否满9天或者是否过期
	 * @param string $domain
	 * @param string $regDate
	 * @param string $expDate
	 * @return boolean
	 */
	public static function checkDomainRegdate($domain, $regDate, $expDate)
	{
		$date = strtotime($regDate);
		$nowTime = strtotime(gmdate("Y-m-d H:i:s"));
		if(self::isChinaDomain($domain) && ($nowTime - $date < 604800))
		{
			Response::setErrMsg(300014, '域名注册未满7天');
			return FALSE;
		}
		if($nowTime >= strtotime($expDate))
		{
			Response::setErrMsg(300015, '域名已经过期');
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * 检查下域名是否是下架域名
	 * @param unknown_type $domain
	 */
	public static function checkIsDownDomain($domain)
	{
		return in_array(self::getDomainClass($domain),array('US','TW','IN','INFO'));
	}
	
	
	/**
	 * 判断域名模板是否为临时模板
	 * @param int $templateId
	 * @return boolean
	 */
	public static function checkIsTempTemplate($templateId)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		return ($conf->template->temp->id == $templateId || in_array($templateId, explode(',', $conf->template->temp->historyid))) ? TRUE : FALSE;
	}

	public static function checkTempType($tempId)
	{
		$tempLib = new \lib\manage\domain\TemplateLib();
		$tempInfo = $tempLib->getTempInfo($tempId);
		return $tempInfo && $tempInfo['TemplateType'] == 0;
	}

	/**
	 * 判断域名状态是否正在申请域名安全锁or已经是注册商or注册局锁定
	 * @param int $status
	 * @param string $type
	 * @return boolean
	 */
	public static function checkSecureStatus($status, $type = FALSE)
	{
		switch($status)
		{
			case 11:
				Response::setErrMsg(300020, '该域名已经设置了注册商安全锁，不能操作，如果需要操作请先取消注册商安全锁');
				break;
			case 12:
				Response::setErrMsg(300021, '该域名已经设置了注册局安全锁，不能操作，如果需要操作请联系客服');
				break;
			case 13:
				if($type == 'push' || $type == 'transout')
				{
					Response::setErrMsg(300022, '该域名安全锁申请中,不能操作');
				}
				else
				{
					return TRUE;
				}
				break;
			case 7:
				Response::setErrMsg(322016, '该域名被锁定，不能执行此操作！');
				break;
			default:
				return TRUE;
		}
		return FALSE;
	}

	/**
	 * 判断域名状态是否腾讯邮箱域名
	 * @param int $domainProperty
	 * @param string $className
	 * @return boolean
	 */
	public static function checkDomainIsQQMail($domainProperty, $className)
	{
		return ($domainProperty == 4 || $domainProperty == 6) && $className == 1 ? TRUE : FALSE;
	}

	/**
	 * 判断域名状态是否被锁定
	 * @param int $status
	 * @param int $holdStatus
	 * @return boolean
	 */
	public static function checkDomainIsLockStatus($status, $holdStatus)
	{
		return ($status > 5 || $holdStatus == 2) ? TRUE : FALSE;
	}

	/**
	 * 判断域名状态是否被是展示页状态
	 * @param int $holdStatus 3HOLD展示页 5展示页
	 * @return boolean
	 */
	public static function checkDomainIsSellPageStatus($holdStatus)
	{
		return ($holdStatus == 3 || $holdStatus == 5) ? TRUE : FALSE;
	}

	/**
	 * 判断域名状态是否可交易
	 * @param array $info DomainName RegDate ExpDate DomainMyStatus DomainHoldStatus DomainProperty ClassName TemplateId
	 * @return boolean
	 */
	public static function checkDomainAllowToTrade($info)
	{
		if(FALSE == self::checkDomainRegdate($info['DomainName'], $info['RegDate'], $info['ExpDate']))
		{
			return FALSE;
		}
		if($info['DomainMyStatus'] == 2)
		{
			Response::setErrMsg(322003, '域名正在交易，不能出售');
			return FALSE;
		}
		if($info['DomainMyStatus'] ==3)
		{
			Response::setErrMsg(322040, '域名正在经纪中介状态，无法发布交易');
			return FALSE;
		}
		if(!self::checkSecureStatus($info['DomainMyStatus'], 'push'))
		{
			return FALSE;
		}
		if($info['DomainMyStatus'] == 9)
		{
			Response::setErrMsg(322021, '操作失败，请联系客服');
			return FALSE;
		}
		elseif($info['DomainMyStatus'] ==15 || $info['DomainMyStatus'] == 7 || $info['DomainHoldStatus'] == 2)
		{
			Response::setErrMsg(322016, '域名锁定，不能出售');
			return FALSE;
		}
		elseif($info['DomainMyStatus'] == 4)
		{
			Response::setErrMsg(322015, '域名正在push，不能出售');
			return FALSE;
		}
		elseif($info['DomainMyStatus'] == 5)
		{
			Response::setErrMsg(322014, '域名正在转出，不能出售');
			return FALSE;
		}
		elseif($info['DomainMyStatus'] == 9 )
		{
			Response::setErrMsg(322041, '操作失败，请联系客服');
			return FALSE;
		}
		elseif($info['DomainMyStatus'] == 13)
		{
			Response::setErrMsg(322017, '域名正在申请域名安全锁，不能出售');
			return FALSE;
		}
		elseif($info['DomainMyStatus'] == 14)
		{
			Response::setErrMsg(322045, '域名交易限制，不能出售');
			return FALSE;
		}		
		if(self::checkDomainIsQQMail($info['DomainProperty'], $info['ClassName']))
		{
			Response::setErrMsg(322013, '腾讯邮箱域名不能交易');
			return FALSE;
		}
		if(self::checkIsTempTemplate($info['TemplateId']))
		{
			Response::setErrMsg(322002, '模板为临时模板，不能出售');
			return FALSE;
		}
		if(self::checkTempType($info['TemplateId']))
		{
			Response::setErrMsg(322002, '模板为临时模板，不能出售');
			return FALSE;
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'transwhitetemptime');
		$transwhitetime = $conf->endtime;
		if(time() >= strtotime($transwhitetime))
		{
			if(FALSE == DomainFunLib::checkIsWhiteTemp($info['TemplateId']))
			{
				Response::setErrMsg(322020,'域名模板为非白名单模板，不能出售');
				return FALSE;
			}
		}
		else
		{
			if(FALSE == self::checkIsWhiteTemp($info['TemplateId']) && self::isChinaDomain($info['DomainName']))
			{
				Response::setErrMsg(322020, '模板为非白名单模板，不能出售');
				return FALSE;
			}
		}
		return TRUE;
	}

	public static function checkIsWhiteTemp($templateId)
	{
		$tmpLib = new \lib\manage\domain\TemplateLib();
		$tmpInfo = $tmpLib->getTempInfo($templateId);
		return $tmpInfo && $tmpInfo['CnStatus'] == 2; 
	}

	public static function checkTopDomainIsWhite($templateId)
	{
		$tmpLib = new \lib\manage\domain\TemplateLib();
		$tmpInfo = $tmpLib->getTemplateExt($templateId,FALSE,86);
		return $tmpInfo && $tmpInfo['Status'] == 2;
	}
	
	/**
	 * 判断域名状态是否是可交易状态
	 * @param int $status
	 * @param int $holdStatus
	 * @return boolean
	 */
	public static function checkIsTradeAvailStatus($status, $holdStatus)
	{
		return (intval($status) > 3 || intval($holdStatus) == 2) ? FALSE : TRUE;
	}

	/**
	 * 判断域名状态是否是交易状态
	 * @param int $status
	 * @return boolean
	 */
	public static function checkIsTradeStatus($status)
	{
		return (2 == $status) ? TRUE : FALSE;
	}

	/**
	 * 判断是否是CNNIC管辖的域名
	 */
	public static function isChinaDomain($domain)
	{
		$ok = FALSE;
		if(strtolower(substr($domain, strlen($domain) - 2)) == 'cn')
		{
			$ok = true;
		}
		elseif(stripos($domain, '.中国') !== FALSE || stripos($domain, '.公司') !== FALSE || stripos($domain, '.网络') !== FALSE)
		{
			$ok = true;
		}
		return $ok;
	}

	/**
	 * 表单过滤调用函数
	 * @param string $domain
	 */
	public static function checkIsOkDomain($domain)
	{
		if(empty($domain))
		{
			return false;
		}
		$domain = str_replace("\n", ',', $domain);
		$arr = explode(',', $domain);
		foreach($arr as $v)
		{
			$v = trim($v);
			if($v && self::isOkDomain($v) === FALSE)
			{
				return FALSE;
				break;
			}
		}
		return true;
	}

	/**
	 * 单个域名判断 域名不能以-开头或者结尾
	 */
	public static function isOkDomainByCross($domainbody)
	{
		if(preg_match("/^-|-$/", $domainbody))
		{
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * cn域名不允许出现两个连续的-
	 */
	public static function isOkCnDomain($domain)
	{
		if(self::isChinaDomain($domain) && strpos($domain, '--') !== false)
		{
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * 判断是否是一个合格的域名,支持中文域名
	 */
	public static function isOkDomain($domain)
	{
		if(preg_match("/^([\x{4e00}-\x{9fa5}]|[a-zA-Z0-9-])+(\.[a-z]{2,4})?\.([a-z]|[\x{4e00}-\x{9fa5}]){2,4}$/ui", $domain))
		{
			if(self::isOkCnDomain($domain) == FALSE)
			{
				return FALSE;
			}
			if(substr($domain, 0, 1) != '-') // 去掉-开头的域名
			{
				$dnBody = explode('.', $domain);
				$dnBody = $dnBody[0];
				if(substr($dnBody, mb_strlen($dnBody) - 1, 1) == '-')//去掉-结尾的域名
				{
					return FALSE;
				}
				return TRUE;
			}
		}
		return FALSE;
	}

	
	/**
	 * 获取产品类型
	 * @param string $domain
	 * @return number
	 */
	public static function getDomainProductType($domain)
	{
		if(in_array(self::getDomainClass($domain),array('CC','TV','BIZ')))
		{
			return 11;
		}
		if(self::isCnDomain($domain))
		{
			return 2;
		}
		$domainNum = explode('.', $domain);
		if(count($domainNum) == 2)
		{
			return 1;
		}
		$domainClassAll = strtoupper(self::getDomainClassAll($domain));
		if($domainClassAll == 'NET.CN' || $domainClassAll == "COM.CN" || $domainClassAll == "ORG.CN" || $domainClassAll == "GOV.CN")
		{
			return 1;
		}
		return 3;
	}

	/**
	 * 判断是否是中文域名 判断是否有汉字
	 *
	 * @param string $domain
	 * @return boolean
	 * @author zougc
	 */
	public static function isCnDomain($domain)
	{
		if(preg_match("/[\x{4e00}-\x{9fa5}]+/u", $domain))
		{
			return TRUE;
		}
		return FALSE;
	}

	/**
	 * 获取域名后缀类型
	 * @param string $domain
	 */
	public static function getDomainClassAll($domain)
	{
		if($domain)
		{
			$domainArr = explode('.', $domain);
			return count($domainArr) == 3 ? ($domainArr[1] . '.' . $domainArr[2]) : $domainArr[1];
		}
	}

	/**
	 * 获取域名最后一级后缀
	 * @param string $domain
	 */
	public static function getDomainClass($domain)
	{
		$domainArr = explode('.', $domain);
		return strtoupper($domainArr[count($domainArr) - 1]);
	}

	/**
	 * 判断是否是中文CN域名
	 * @param string $domain 
	 */
	public static function isChineseCnDomain($domain)
	{
		if(self::isChinaDomain($domain))
		{
			return self::isCnDomain($domain);
		}
		return FALSE;
	}

	/**
	 * 获取域名分组1信息
	 */
	public static function getDomainSystemGroupOne($domain)
	{
		$domain = self::getDomainBody($domain);
		$groupId = self::getDomainSystemGroupOneSub($domain);
		return $groupId;
	}

	/**
	 * 获取域名主体部分
	 * @param string $domain
	 */
	public static function getDomainBody($domain)
	{
		$domainArr = explode('.', $domain);
		return strtoupper($domainArr[0]);
	}

	/**
	 *
	 * 获取域名的系统分组
	 * @param string $domain
	 */
	public static function getDomainSystemGroupOneSub($domain)
	{
		$groupId = 0;
		if(preg_match("/([\x{4e00}-\x{9fa5}])+/ui", $domain))
		{
			return $groupId;//0 中文
		}
		if(preg_match('/^\d+$/', $domain))
		{
			$groupId = 1;//纯数字
		}
		elseif(preg_match('/^[a-zA-Z]+$/', $domain))
		{
			$groupId = 101;//纯字母
		}
		elseif(strlen($domain) == 2)
		{
			$groupId = 202;//两杂
		}
		elseif(strlen($domain) == 3 && FALSE === strripos($domain, '-'))
		{
			
			$groupId = 203;//三杂
		}
		else
		{
			$groupId = 201;//杂米
		}
		return $groupId;
	}

	/**
	 *获取域名类型 
	 */
	public static function getDomainClassName($domainName)
	{
		if(self::isInterDomain($domainName))
		{
			return self::isCnDomain($domainName) ? 4 : 2;
		}
		elseif(self::isChinaDomain($domainName))
		{
			return self::isCnDomain($domainName) ? 3 : 1;
		}
		else
		{
			return 2;
		}
	}

	/**
	 * 是否是国际域名 包含.asia域名
	 * @param string $domain
	 * @author zougc
	 * @return boolean
	 */
	public static function isInterDomain($domain)
	{
		$ok = false;
		$ext = strtolower(substr($domain, strlen($domain) - 3));
		if($ext == 'com' || $ext == 'net' || $ext == 'org' || $ext == 'edu' || $ext == 'sia' || $ext == 'top' || $ext == 'lub' || $ext =='ang' || $ext =='top')
		{
			$ok = true;
		}
		return $ok;
	}

	/**
	 * 主要是换代理商的域名 转入需要验证下whois
	 */
	public static function isNewDomain($domain)
	{
		return in_array(self::getDomainClass($domain),array('CC','TV','BIZ'));
	}
	
	public static function getDomainSystemGroupTwo($domain)
	{
		$domain = strtolower(self::getDomainBody($domain));
		if(self::isCnDomain($domain) || strlen($domain) > 18) //有中文或是超过18个字符，直接返回0
		{
			return 0;
		}
		$pinyin = self::pinyinSplit($domain);
		if(!empty($pinyin) && count($pinyin) < 4)
		{
			return count($pinyin);
		}
		else
		{
			return 0;
		}
	}

	/**
	 * 分割拼音
	 * @param string $pinyin
	 * @return mixed:
	 */
	public static function pinyinSplit($domainBody)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/domaingroup.ini');

		$pyDic = explode('|', $conf->domainPinyin);
		$len = strlen($domainBody);
		$p = array_fill(0, $len + 1, $len);
		$p[$len] = 0;
		$s = array_fill(0, $len, 0);

		for($i = $len - 1;$i >= 0;$i--)
		{
			for($j = 0,$max = $len - $i;$j < $max;$j++)
			{
				if($j == 0 OR array_search(substr($domainBody, $i, $j + 1), $pyDic) !== FALSE AND $p[$i + $j + 1] + 1 < $p[$i])
				{
					$p[$i] = $p[$i + $j + 1] + 1;
					$s[$i] = $j + 1;
				}
			}
		}
		$tmp = 0;
		$result = array();
		while($tmp < $len)
		{
			$py = substr($domainBody, $tmp, $s[$tmp]);
			$tmp += $s[$tmp];
			if(array_search($py, $pyDic) !== FALSE)
			{
				array_push($result, $py);
			}
			else
			{
				return FALSE;
			}
		}
		return $result;
	}

	/**
	 * 获取域名后缀 方便搜索
	 */
	public static function getDomainLtd($config, $domain)
	{
		$domain = strtolower($domain);
		$domainArr = explode('.', $domain);
		$domainLtd = count($domainArr) == 3 ? ($domainArr[1] . '.' . $domainArr[2]) : $domainArr[1];
		$key = array_search(strtolower($domainLtd), $config);
		if($key !== false)
		{
			return $key;
		}
		$domLtd = self::getDomainClass($domain);
		if(self::isCnDomain($domain))
		{
			if(($domLtd == 'CN'))
			{
				return 6;
			}
			else if($domLtd == '中国')
			{
				return 24;
			}
			else if($domLtd == 'COM')
			{
				return 9;
			}
			else if($domLtd == 'NET')
			{
				return 10;
			}
		}
		else
		{
			return 23;//otherCN
		}
	}

	/**
	 * 判断一个域名的主体是否为包含中文
	 */
	public static function isCnBody($domain)
	{
		if(preg_match("/[\x{4e00}-\x{9fa5}]+/u", self::getDomainBody($domain)))
		{
			return TRUE;
		}
		return FALSE;
	}
	/**
	 * 检查域名状态 是否可以申请转移密码
	 * @param array $info
	 * @param string $msg
	 * @throws Exception
	 */
	public static function checkDomainToTransferPassword($info, $msg = '申请转移密码')
	{
		if($info['DomainMyStatus'] == 13)
		{
			throw new \Exception($info['DomainName'] . '域名正在申请安全锁,不能申请转移密码，请先取消安全锁', 321034);
		}
		if($info['DomainMyStatus'] == 12)
		{
			throw new \Exception($info['DomainName'] . '域名开通注册局安全锁,不能申请转移密码，请先取消安全锁', 321035);
		}
		if($info['DomainMyStatus'] == 11)
		{
			throw new \Exception($info['DomainName'] . '域名开通注册商安全锁,不能申请转移密码，请先取消安全锁', 321036);
		}
		if($info['DomainMyStatus'] == 9)
		{
			throw new \Exception($info['DomainName'] . '操作失败，请联系客服', 321033);
		}
		if($info['DomainMyStatus'] == 7)
		{
			throw new \Exception($info['DomainName'] . '域名被锁定,不能申请转移密码，请联系客服', 321037);
		}
		if($info['DomainMyStatus'] == 3)
		{
			throw new \Exception($info['DomainName'] . '域名处于经纪中介状态，不能申请转移密码，请联系经纪人处理', 321038);
		}
		if($info['DomainMyStatus'] == 2)
		{
			throw new \Exception($info['DomainName'] . '域名正在交易,不能申请转移密码，请先取消交易', 321039);
		}
		if(strtotime(gmdate("Y-m-d H:i:s")) - strtotime($info['RegDate']) < 5184000)
		{
			throw new \Exception($info['DomainName'] . '域名注册时间不足2个月,无法转出.', 321003);
		}
		if(self::isChinaDomain($info['DomainName']) && (strtotime($info['ExpDate']) - strtotime(gmdate("Y-m-d H:i:s")) < 15 * 24 * 3600))
		{
			throw new \Exception($info['DomainName'] . 'CN域名过期时间15天内，无法转出.', 321004);
		}
		if(strtotime($info['ExpDate']) < strtotime(gmdate("Y-m-d H:i:s")))
		{
			throw new \Exception($info['DomainName'] . '域名已经过期，不能申请转移密码，请先续费', 321005);
		}
		if(($info['DomainProperty'] == 4 || $info['DomainProperty'] == 6) && $info['ClassName'] == 1)
		{
			throw new \Exception($info['DomainName'] . '腾讯邮箱域名，不能' . $msg, 321006);
		}
		if($info['DomainHoldStatus'] == 2)
		{
			throw new \Exception($info['DomainName'] . '域名被DNS锁定，不能' . $msg, 321007);
		}
		//取消展示页域名不能转出的限制
// 		if($info['DomainHoldStatus'] == 3 || $info['DomainHoldStatus'] == 5)
// 		{
// 			throw new \Exception($info['DomainName'] . '当前为展示页状态，不能' . $msg, 321008);
// 		}
		if($info['DomainMyStatus'] != 1 && $info['DomainMyStatus'] != 14)
		{
			throw new \Exception($info['DomainName'] . '域名状态错误,不能' . $msg, 321009);
		}
		if(self::checkIsTempTemplate($info['TemplateId']))
		{
			throw new \Exception($info['DomainName'] . '域名处于临时模板，不能申请转移密码，请先模板过户', 321010);
		}
		if(stripos($info['DomainStatus'], '5') !== FALSE)
		{
			throw new \Exception($info['DomainName'] . '域名的状态为“禁止修改”，不能' . $msg, 321011);
		}
		if(!self::checkisRealDomainRenew($info['DomainName'], $info['IsRealName'], $info['RegDate']))
		{ 
			throw new \Exception($info['DomainName'] . '域名未实名，不能' . $msg, 321012);
		}
		self::transferOutCheck($info);
	}
	
	/**
	 * 检查域名状态 是否可以PUSH
	 * @param array $info
	 * @param string $msg
	 * @throws Exception
	 */
	public static function checkDomainToPush($info, $msg = 'PUSH')
	{
		//刚注册的CN域名 9天才允许过户 
		$day = ((time() - strtotime($info['RegDate'])) / (24 * 3600));
		$checkDay = time() >= strtotime('2014-08-10 00:00:00') ? 7 : 9;
		if(self::isChinaDomain($info['DomainName']) && ($day <= $checkDay))
		{
			throw new \Exception( '注册未满'.$checkDay.'天的CN域名,不能' . $msg,322025);
		}
		if(time() > strtotime($info['ExpDate']))
		{
			throw new \Exception('域名已经过期，不能' . $msg,322026);
		}
		if(($info['DomainProperty'] == 4 || $info['DomainProperty'] == 6) && $info['ClassName'] == 1)
		{
			throw new \Exception('腾讯邮箱域名，不能' . $msg,322027);
		}
		if($info['DomainHoldStatus'] == 2)
		{
			throw new \Exception('域名被DNS锁定，不能' . $msg,322028);
		}
		if($info['DomainMyStatus'] != 1)
		{
			throw new \Exception('域名状态错误,不能' . $msg,322029);
		}
// 	if($info['DomainMyStatus'] == 4)
// 		{
// 			throw new \Exception('域名已经在PUSH列表中',322030);
// 		}
		if(stripos($info['DomainStatus'], '5') !== FALSE)
		{
			throw new \Exception('域名的状态为“禁止修改”，不能' . $msg,322031);
		}
		if($info['DomainProperty'] == 8 && $day < 8)
		{
			throw new \Exception('姓名域名需要注册局确认，注册未满7天不能' . $msg,322032);
		}
		if(self::checkIsTempTemplate($info['TemplateId']))
		{
			throw new \Exception('域名使用临时模版，不能'.$msg,322033);
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'transwhitetemptime');
		$transwhitetime = $conf->endtime;
		if(time() >= strtotime($transwhitetime))
		{
			if(FALSE == self::checkIsWhiteTemp($info['TemplateId'])) 
			{
					throw new \Exception('域名使用非白名单模版，不能'.$msg,322034);
			}
		} 
		if(FALSE == self::checkisRealDomainRenew($info['DomainName'],$info['IsRealName'],$info['RegDate']))
		{
			throw new \Exception('域名未通过实名，无法 '.$msg,322056);
		}
		//取消webcc域名push限制
// 	if($info['RegistrarId'] == 61)
// 		{
// 			throw new \Exception('域名是webcc接口，不能push',322037);
// 		}
	}
	
	/**
	 * 检测域名是否可以续费交易push等等
	 * @param unknown $domain
	 * @param string $realStatus
	 * @param string $regdate
	 * @return boolean
	 * 3.2.命名（数据库字段isrealname 0未处理  1全白   2命名未通过实名通过  3命名通过实名未通过   4全不白）   
	 */
	public static function checkisRealDomain($domain,$realStatus ,$regdate,$type="renew",$templateId=FALSE)
	{
		return true;
		if(\lib\manage\common\DomainFunLib::getDomainClass($domain)!='TOP')
		{
			return TRUE;
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'transwhitetemptime');
		if(!$conf->switchtop)
		{
			return TRUE;
		}
		$opentime = $conf->topopentime;//top开始的时间
		
		//交易push自动续费续费的限制 --如果是新数据的必须保证域名跟模板都实名--以域名注册时间为准
		if(strtotime($regdate) >= strtotime($opentime))
		{
			if($type=="renew")
			{
				return $realStatus == 1 || $realStatus == 3;
			}
			return DomainFunLib::checkTopDomainIsWhite($templateId) && ($realStatus == 1 || $realStatus == 3);
		}
		
		//交易push自动续费续费的限制 --如果是旧数据的话,续费不限制 自动续费限制白名单 交易push有宽限期
		if(strtotime($regdate) < strtotime($opentime))
		{
			//旧数据允许续费
			if($type=="renew")
			{
				return true;
			}
			if($type=="trade" &&  time() >= strtotime($conf->topendtime))//旧数据的交易跟push有个【时间限制】 超过这个时间必须是关联cn的才可以
			{
				return DomainFunLib::checkTopDomainIsWhite($templateId);
			}
		} 
		return TRUE;
	}
	
	public static function checkisRealDomainRenew($domain,$realStatus ,$regdate)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'transwhitetemptime');
		if(!$conf->switchtop)
		{
			return TRUE;
		}
		if(\lib\manage\common\DomainFunLib::getDomainClass($domain)!='TOP')
		{
			return TRUE;
		} 
		if($realStatus == 1 || $realStatus == 3)
		{
			return TRUE;
		}
		$opentime = $conf->topopentime;//top开始的时间
		//交易push自动续费续费的限制 --如果是新数据的必须保证域名跟模板都实名--以域名注册时间为准
		if(strtotime($regdate) >= strtotime($opentime))
		{
			return $realStatus == 1 || $realStatus == 3;
		}
		return TRUE;
	}	
	
	
	/**
	 * 转出检查
	 * @param string $domain
	 */
	public static function transferOutCheck($domainInfo)
	{
		if($domainInfo['RegistrarId'] == 12 || $domainInfo['RegistrarId'] == 61)
		{
			throw new \Exception($domainInfo['DomainName'] . '不支持在线处理 请联系客服处理！', 321012);
		}
		return true;
	}
	public static function showDomainToEnameShow($domain)
	{
		$domain = strtolower($domain);
		return str_replace('l', 'L', $domain);
	}

	public static function isTopDomainType($domain)
	{
		if(strtolower(substr($domain, strlen($domain) - 3)) == 'com' || strtolower(substr($domain, strlen($domain) - 3)) == 'net')
		{
			return TRUE;
		}
		if(strtolower(substr($domain, strlen($domain) - 2)) == 'cn')
		{
			return TRUE;
		}
		return FALSE;
	}

	public static function checkDomainSuffix($suffix)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		if(mb_strlen($suffix, 'UTF-8') > $conf->maxLen)
		{
			return FALSE;
		}
		if(in_array($suffix, array('中国')))
		{
			return TRUE;
		}
		return in_array(strtolower($suffix), array_merge($conf->domainLtd->toArray(), $conf->domainLtdSf->toArray()));
	}
	
	public static function checkDomainSuffix115($domain)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'cooper');
		return in_array(strtolower(self::getDomainClass($domain)),$conf->domainLtd115->toArray());
	}
	
	public static function checkIsIp($ip)
	{
		return preg_match("/^(\d){1,3}\.(\d){1,3}\.(\d){1,3}\.(\d){1,3}$/", $ip) ? true : false;
	}
	
	/**
	 * 检测域名是否可以设置展示页
	 * @param array $domainInfo
	 * @throws Exception
	 */
	public static function checkDomainToSellPage($domainInfo)
	{
		if($domainInfo['DomainHoldStatus'] == 6)
		{
			throw new \Exception('域名已经设置停放不能设置展示页', 360005);
		}
		if($domainInfo['DomainHoldStatus'] == 2)
		{
			throw new \Exception('域名被DNS锁定不能设置展示页', 360006);
		}
		if($domainInfo['DomainMyStatus'] == 7)
		{
			throw new \Exception('域名被违规锁定不能设置展示页', 360007);
		}
		if($domainInfo['DomainProperty'] == 4 || $domainInfo['DomainProperty'] == 6)
		{
			throw new \Exception('腾讯邮箱合作域名不能设置展示页!', 360008);
		}
		if($domainInfo['DomainMyStatus'] == 9 && $domainInfo['DomainHoldStatus'] == 4)
		{
			throw new \Exception('万购接口域名不能设置展示页!', 360009);
		}
		if($domainInfo['DomainMyStatus'] > 4 && !in_array($domainInfo['DomainMyStatus'], array(10, 14 ,15)))
		{
			throw new \Exception('域名状态错误不能设置展示页', 360010);
		}
		if(time()-strtotime($domainInfo['RegDate']) < 691200)
		{
			if($domainInfo['DomainProperty']==8)
			{
				throw new \Exception('姓名域名必须满8天才可以设置展示页', 360011);
			}
		}
		if(in_array($domainInfo['TemplateId'], array('428291', '413119')))
		{
			throw new \Exception('使用了临时模板，无法添加展示页', 360012);
		}
	}
	
	public static function isWangluoDomain($domain)
	{
		$domainTld = self::getDomainClass($domain);
		if(in_array($domainTld, array('公司','网络'))!==false)
		{
			return true;
		}
		return FALSE;
	}
	
	/**
	 * 需要发送FOA邮件的域名后缀
	 */
	public static function isNeedFoaDomain($domain, $property = FALSE)
	{
		$ok = false;
		$domainArr = explode('.', $domain);
		$ext = strtolower($domainArr[count($domainArr) - 1]);
		if($ext == "com" || $ext == "net" || $ext == "org" || $ext == "asia" || $ext == 'pw' || $ext == 'top' || $ext == 'wang')
		{
			$ok = true;
		}
		if(($ext == "cc" || $ext=="tv" || $ext=="biz") && $property == 11)
		{
			$ok = true;
		}
		return $ok;
	}
	
	/**
	 * 校验是否是电子邮箱
	 * @param string $str
	 * @return boolean
	 */
	public static function isEmail($str)
	{
		return (!preg_match("/^([a-z0-9\+_\-]+)([a-z0-9\+_\-\.]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $str)) ? FALSE : $str;
	}
	
	/**
	 * 校验是否手机号码
	 * @param string $phone
	 * @return boolean
	 */
	public static function IsMobilePhone($phone) 
	{
		return preg_match("/^1(3|4|5|8)[0-9]{9}$/", $phone) ? true : false;
	}
	
	public static function IsPhone($phone) 
	{
		if(self::IsMobilePhone($phone) || preg_match("/^0[0-9]{2,3}-[0-9]{7,8}-([0-9]{0,6}?)$/", $phone))
		{
			return TRUE;
		}
		return FALSE;
	}
	
	public static function checkIsVspDomainLtd($domains)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'vspdomainltd');
		$vpsDomainLtd = $conf->domainltd->toArray();
		if(is_array($domains))
		{
			foreach($domains as $domain)
			{
				if(FALSE == in_array(self::getDomainClass($domain), $vpsDomainLtd))
				{
					return FALSE;
				}
			}
			return true;
		}
		return in_array(self::getDomainClass($domains), $vpsDomainLtd);
	}
	
	/**
	 * 获得域名类型
	 * @param string $domain
	 * @return number  0=>其他 1 =>1-4数com cn net 2=>1-3字母com cn net。。。。
	 */
	public static function getDomainType($domain)
	{
		$ltd = strtoupper(\lib\manage\common\DomainFunLib::getDomainClassAll($domain));
		if(in_array($ltd, array('COM', 'CN', 'NET')))
		{
			$domainStr = \lib\manage\common\DomainFunLib::getDomainBody($domain);
			if(strlen($domainStr) > 5)
			{
				return 0;
			}
			if(preg_match('/^[0-9]{1,4}$/', $domainStr))
			{
				return 1; // 1-4数 com cn net
			}
			elseif(preg_match('/^[a-zA-Z]{1,3}$/', $domainStr))
			{
				return 2; // 1-3字母 com cn net
			}
			elseif(strlen($domainStr) == 2 && $ltd！ = 'NET')
			{
				return 3; // 两杂 com cn
			}
			if(preg_match('/^[BCDFGHJKLMNPQRSTWXYZ]{4}$/i', $domainStr) && $ltd == 'COM')
			{
				return 4; // 4声母com
			}
		}
		return 0;
	}
}

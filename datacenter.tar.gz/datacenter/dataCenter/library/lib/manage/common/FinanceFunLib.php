<?php
namespace lib\manage\common;
use core\Response;
class FinanceFunLib
{
	public function __construct()
	{
	}

	/**
	 * 金额格式化，返回之多两位小数
	 * @param number $money
	 * @return float
	 */
	public static function moneyFormat($money)
	{
		return (float)number_format($money, 2, ".", "");
	}
}
<?php
namespace lib\manage\common;
class RedisLib
{
	private $redis;

	public function __construct($serialize = true)
	{
		$this->redis = \core\RedisLib::getInstance('manage', $serialize);
	}
 
	public function incrData($key, $num = FALSE)
	{
		return $num ? $this->redis->incrBy($key, intval($num)) : $this->redis->incr($key);
	}
	
	public function getData($key)
	{
		return $this->redis->get($key);
	}
	
	public function delData($key)
	{
		return $this->redis->delete($key);
	}
	
	public function setData($key,$value,$time = FALSE)
	{
		return $time ? $this->redis->setex($kye,$time,$value) : $this->redis->set($key,$value);
	}
	
	public function setHashData($key,$domain)
	{
		if($this->getHashData($key, $domain) == FALSE)
		{
			return $this->redis->hset($key,$domain,$domain);
		}
		return true;
	}
	
	public function getHashData($key,$field)
	{
		return $this->redis->hget($key,$field);
	}
	
	public function delHashData($key,$field)
	{
		return $this->redis->hdel($key,$field);	
	}
}

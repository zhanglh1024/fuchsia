<?php
namespace lib\manage\member;
use models\manage\member\OperateMod;

class UserOperateProtectionLib
{
	private $model;
	function __construct()
	{
		$this->model = new \models\manage\member\OperateMod();
	} 
	 
	public function getListByEnameId($enameId)
	{
		$res =$this->model->getListByenameId(array ('EnameId' => $enameId, 'Status' => 1 ));
		return $res;
	}
	public function getQuestionCount($info)
	{
		$res = $this->model->getCountByEnameId($info);
		if($res)
		{
			return $res['sum'];
		}
		return  0;
	}

	public function getListByQuestionId($questionId)
	{
		$res = $this->model->getOneInfo(array('QuestionId' => $questionId));
		return $res;
	}
}

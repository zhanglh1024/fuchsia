<?php
include_once APP_PATH . '/dataCenter/library/lib/manage/eNameSdkApi/SdkApi.php';
include APP_PATH . '/dataCenter/library/lib/manage/eNameSdkApi/publicApi.php';
class ApiSdk
{

	/**
	 * 调用SDK
	 * 
	 * @param int $serviceCode        	
	 * @param array $data        	
	 *
	 */
	public function execSdkFun($serviceCode, $data = NULL)
	{
		$data['serviceCode'] = $serviceCode;
		$data['clientId'] = 1;
		$enameSdk = new SdkApi();
		return $enameSdk->doApplication($data);
	}
/**
 * 批量解析域名等批量任务调用SDK接口
 */
	public function execPublicSdkFun($serviceCode, $data = NULL)
	{
		return PublicApi::infa()->justDoIt($serviceCode, $data);
	}
}
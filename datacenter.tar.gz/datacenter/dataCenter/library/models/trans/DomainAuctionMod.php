<?php
namespace models\trans;
use core\ModBase;

class DomainAuctionMod extends ModBase
{ 

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_domain_auction';
	}

	/**
	 * 通过标签获取正在交易的域名的数量
	 */
	public function getAuctionCntByTag($seller, $value)
	{
		$now = date('Y-m-d H:i:s');
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table .
			 " WHERE Seller =? AND TransStatus=? AND IsShopRecommend&? AND FinishDate>Now()";
		return $this->getOne($sql, 'iii', array(
				$seller,1,$value
		));
	}

	/**
	 * 获取用户正在交易的标签的总数
	 */
	public function getAuctionCntTotal($seller, $statue)
	{
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table .
			 " WHERE Seller=? AND TransStatus=? AND FinishDate>Now()";
		return $this->getOne($sql, 'ii', array(
				$seller,$statue
		));
	}

	/**
	 * 检查下架队列中是否存在在标签
	 *
	 * @param int $seller        	
	 * @param string $transStatus        	
	 * @param int $tag        	
	 * @return array
	 */
	public function checkDownTransTag($seller, $transStatus, $tag)
	{
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table .
			 " WHERE Seller=? AND IsShopRecommend&? AND TransStatus IN ($transStatus)";
		
		return $this->getOne($sql, 'ii', array(
				$seller,$tag
		));
	}

	/**
	 * 取消卖家等待上架交易下的该标签
	 *
	 * @param int $seller        	
	 * @param array $transStatus        	
	 * @param int $tag        	
	 */
	public function cancelDownTransTag($seller, $transStatus, $tag)
	{
		$date = date('Y-m-d H:i:s');
		$sql = "UPDATE " . $this->table .
			 " SET LastChangeDate=?, IsShopRecommend=IsShopRecommend^? WHERE  Seller=? AND IsShopRecommend&? AND TransStatus IN ($transStatus)";
		$data = array(
				$date,$tag,$seller,$tag
		);
		
		return $this->update($sql, 'siii', $data);
	}

	public function getUserbidDomain($auditListId, $transStatus = 0)
	{
		$sql = "SELECT AuditListId,Buyer, BidPrice, AgentBidPrice, BidCount ,TransType,TransStatus, FinishDate FROM " .
			 $this->table . " WHERE AuditListId=?";
		if($transStatus)
		{
			$sql .= " AND TransStatus=?";
		}
		
		return $transStatus? $this->getRow($sql, 'ii', array(
				$auditListId,$transStatus
		)): $this->getRow($sql, 'i', array(
				$auditListId
		));
	}

	public function getSellerOnSale($enameId, $offset, $pageSize, $transType, $domainName)
	{
		$finishdate = date("Y-m-d H:i:s");
		$sql = "SELECT AuditListId,TransType,DomainName,BidPrice,FinishDate,BidCount,SimpleDec,AskingPrice FROM " . $this->table .
			 " WHERE Seller= ? AND FinishDate > ? AND TransStatus=?";
		if($transType)
		{
			$sql .= " AND TransType = ?";
		}
		if($domainName)
		{
			$sql .= " and DomainName like '%$domainName%'";
		}
		$sql .= " ORDER BY FinishDate limit ?,?";
		return $transType? $this->select($sql, 'isiiii', array(
				$enameId,$finishdate,1,$transType,$offset,$pageSize
		)): $this->select($sql, 'isiii', array(
				$enameId,$finishdate,1,$offset,$pageSize
		));
	}

	public function getSellerOnSaleCount($enameId, $transType)
	{
		$finishdate = date("Y-m-d H:i:s");
		$sql = "SELECT count(AuditListId) FROM " . $this->table . " WHERE Seller= ? AND FinishDate > ? AND TransStatus=?";
		if($transType)
		{
			$sql .= " AND TransType = ?";
		}
		return $transType? $this->getOne($sql, 'isii', array(
				$enameId,$finishdate,1,$transType
		)): $this->getOne($sql, 'isi', array(
				$enameId,$finishdate,1
		));
	}

	public function getOnsaleDomainDetail($enameId, $id, $transStatus)
	{
		$finishdate = date("Y-m-d H:i:s");
		$sql = " select AuditListId,TransType,DomainName,AskingPrice,BidPrice,Buyer,FinishDate,NickName,IsShopRecommend from " .
			 $this->table . " where Seller=? and AuditListId=? and TransStatus=?";
		
		return $this->getRow($sql, 'iii', array(
				$enameId,$id,$transStatus
		));
	}

	/**
	 * 获取等待上架交易列表
	 *
	 * @param unknown $enameId        	
	 * @param unknown $transStatus        	
	 * @param unknown $unrefresh        	
	 * @param unknown $inEname        	
	 * @param unknown $offset        	
	 * @param unknown $pageSize        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getPreTradeDomainList($enameId, $transStatus, $unrefresh, $inEname, $offset, $pageSize, $transtype)
	{
		$sql = "SELECT DomainName, TransType, ReservePrice, AskingPrice,SimpleDec FROM " . $this->table .
			 " WHERE Seller=? AND RefreshStatus=?  AND IsDomainInEname=? AND TransStatus IN ($transStatus)";
		
		$sql .= $transtype? " AND TransType IN(?)": "";
		
		$sql .= " ORDER BY AuditListId DESC";
		$sql .= " LIMIT ?,?";
		
		if($transtype)
		{
			return $this->select($sql, 'iiiiii', array(
					$enameId,$unrefresh,$inEname,$transtype,$offset,$pageSize
			));
		}
		else
		{
			return $this->select($sql, 'iiiii', array(
					$enameId,$unrefresh,$inEname,$offset,$pageSize
			));
		}
	}

	/**
	 * 根据主题类型获取域名信息
	 *
	 * @param unknown $transType        	
	 * @param unknown $topic        	
	 * @param unknown $offset        	
	 * @param unknown $pageSize        	
	 * @param unknown $day        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getDomainByTopic($transTopic, $topic, $transStatus, $offset, $pageSize, $day)
	{
		$now = date('Y-m-d H:i:s');
		$sql = "select DomainName,SimpleDec,BidPrice,FinishDate from " . $this->table .
			 " where TransTopic=? and Topic=? and FinishDate >= ? and TransStatus=?";
		if($day)
		{
			$sql .= " and FinishDateFlag=?";
		}
		$sql .= " order by AuditListId desc limit ?,?";
		return $day? $this->select($sql, "iisisii", array(
				$transTopic,$topic,$now,$transStatus,$day,$offset,$pageSize
		)): $this->select($sql, 'iisiii', array(
				$transTopic,$topic,$now,$transStatus,$offset,$pageSize
		));
	}

	/**
	 * 淘域名搜索
	 */
	public function getTransSearch($transTypeArray, $domainName, $sldType, $domainTLD, $sysGroupOne, $sysGroupTwo, 
		$domainLen, $bidPrice, $finishTime, $registrar, $transType, $hidenobider, $sort, $page = 0, $num = 30, 
		$bidPriceEnd = TRUE, $bidStartOne = FALSE, $transtopic = 0, $skip)
	{
		$time = $this->dateFormat(date("Y-m-d H:i:s", time() + 10));
		$domainName = $this->removeCharacter($domainName);
		// 如果要查询的关键字都是表达式字符 搜索结果为空
		if(FALSE === $domainName)
		{
			return (object) array(
					'numFound' => 0,'docs' => array()
			);
		}
		
		$query = new SolrQuery();
		$query->setQuery('*');
		$query->addFilterQuery("TransStatus:1");
		
		// 搜索域名和简介
		$query = $this->queryKeyWord($query, $domainName, $sldType);
		
		// 过滤字符
		$query = $this->querySkipKeyWord($query, $skip['skipword1'], $skip['skipPos1']);
		$query = $this->querySkipKeyWord($query, $skip['skipword2'], $skip['skipPos2']);
		
		// 过滤后缀
		if($domainTLD)
		{
			$domainTLD = implode(",", $domainTLD);
			$tlds = str_replace(',', ' OR ', $domainTLD);
			$query->addFilterQuery("DomainTLD:($tlds)");
		}
		
		// 过滤分类 纯数字、纯字母、杂米...
		if($sysGroupOne)
		{
			if(is_array($sysGroupOne))
			{
				$query->addFilterQuery("SysGroupOne:[{$sysGroupOne[0]} TO {$sysGroupOne[1]}]");
			}
			else
			{
				$query->addFilterQuery("SysGroupOne:{$sysGroupOne}");
			}
		}
		
		if($sysGroupTwo)
			$query->addFilterQuery("SysGroupTwo:{$sysGroupTwo}");
			
			// 一元起拍
		if($bidStartOne)
		{
			$query->addFilterQuery("AskingPrice:1");
		}
		// 有人出价
		if($hidenobider)
			$query->addFilterQuery("BidCount:[1 TO *]");
			
			// 出价
		if($bidPrice)
		{
			if(is_array($bidPrice))
			{
				$query->addFilterQuery("BidPrice:[{$bidPrice[0]} TO {$bidPrice[1]}]");
			}
			elseif($bidPriceEnd)
			{
				$query->addFilterQuery("BidPrice:{$bidPrice}");
			}
			else
			{
				$query->addFilterQuery("BidPrice:[{$bidPrice} TO *]");
			}
		}
		
		// 域名长度
		if($domainLen)
		{
			if(is_array($domainLen))
				$query->addFilterQuery("DomainLen:[{$domainLen[0]} TO {$domainLen[1]}]");
			else
				$query->addFilterQuery("DomainLen:{$domainLen}");
		}
		
		// 结束时间
		$finishTimeFilter = "FinishDate:{{$time} TO *}";
		
		if($finishTime)
		{
			$ft = $this->dateFormat($finishTime);
			$finishTimeFilter = str_replace('*', $ft, $finishTimeFilter);
		}
		$query->addFilterQuery($finishTimeFilter);
		// 注册商
		if($registrar)
			$query->addFilterQuery("IsDomainInEname:{$registrar}");
			
			// 交易类型
		if($transType)
		{
			$query->addFilterQuery("TransType:{$transType}");
		}
		else
		{
			$tpa = str_replace(',', ' OR ', $transTypeArray);
			$query->addFilterQuery("TransType:($tpa)");
		}
		
		if($transTypeArray == 4)
		{
			if($transtopic)
			{
				// sedo一口价
				$query->addFilterQuery("TransTopic:{$transtopic}");
			}
			else
			{
				// 普通的一口价
				$query->addFilterQuery("-TransTopic:100");
			}
		}
		
		// 排序
		if(isset($sort) and (! empty($sort)))
		{
			switch($sort)
			{
				case 1:
					$query->addSortField('FinishDate', SolrQuery::ORDER_ASC);
					break;
				
				case 2:
					$query->addSortField('BidPrice', SolrQuery::ORDER_ASC);
					break;
				
				case 3:
					$query->addSortField('BidCount', SolrQuery::ORDER_DESC);
					break;
				
				default:
					$query->addSortField('FinishDate', SolrQuery::ORDER_ASC);
					break;
			}
		}
		else
		{
			if(4 == $transType) // 一口价默认用Weight排序
			{
				$query->addSortField('FinishDate', SolrQuery::ORDER_ASC);
			}
			else
			{
				$query->addSortField('FinishDate', SolrQuery::ORDER_ASC);
			}
		}
		
		// 要返回的字段
		// IsDomainInEname,FinishDate,FinishDateFlag,BidCount,BidPrice,Seller,TransType,AuditListId,DomainName,SimpleDec,
		// TransTopic, AskingPrice
		$query->addField('IsDomainInEname')
			->addField('FinishDate')
			->addField('FinishDateFlag')
			->addField('BidCount')
			->addField('BidPrice')
			->addField('Seller')
			->addField('TransType')
			->addField('AuditListId')
			->addField('DomainName')
			->addField('SimpleDec')
			->addField('TransTopic')
			->addField('AskingPrice')
			->addField('Weight');
		
		// limit
		$query->setStart((int) $page);
		$query->setRows((int) $num);
		$query_response = $this->query($query);
		$r = $query_response->getResponse();
		if($r->response->docs)
			$r->response->docs = array_map(function ($o)
			{
				return (array) $o;
			}, $r->response->docs);
		return $r->response;
	}

	/**
	 * 根据AuditListIds获取交易信息
	 *
	 * @param string $auditLists        	
	 * @param int $enameId        	
	 * @param int $transStuts        	
	 * @return array
	 */
	public function getTransDataForTag($auditLists, $enameId, $transStatus)
	{
		$sql = " SELECT AuditListId, DomainName, IsShopRecommend  FROM " . $this->table .
			 " WHERE  AuditListId IN ($auditLists) AND Seller=? AND TransStatus=? ";
		return $this->select($sql, 'ii', array(
				$enameId,$transStatus
		));
	}

	/**
	 * 更新交易店铺标签
	 */
	public function setTransTag($auditListId, $tag, $enameId)
	{
		$date = date('Y-m-d H:i:s');
		$sql = "UPDATE " . $this->table .
			 " SET LastChangeDate=?, IsShopRecommend=IsShopRecommend|? WHERE AuditListId=? AND Seller=?";
		return $this->update($sql, 'siii', array(
				$date,$tag,$auditListId,$enameId
		));
	}

	/**
	 * 取消店铺标签
	 */
	public function cancelTransTag($auditListId, $tag, $enameId)
	{
		$date = date('Y-m-d H:i:s');
		$sql = "UPDATE " . $this->table .
			 " SET LastChangeDate=?, IsShopRecommend=IsShopRecommend^? WHERE AuditListId=? AND Seller=?";
		
		return $this->update($sql, 'siii', array(
				$date,$tag,$auditListId,$enameId
		));
	}

	/**
	 * 检查是否是此用户的等待上架域名
	 *
	 * @param unknown $domainName        	
	 * @param unknown $enameId        	
	 * @param unknown $preTradeStatus        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function isYourPreTradeDomain($domainName, $enameId, $preTradeStatus)
	{
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table .
			 " WHERE DomainName=? AND TransStatus IN ($preTradeStatus) AND Seller=? ";
		return $this->getOne($sql, 'si', array(
				$domainName,$enameId
		));
	}

	/**
	 * 删除等待上架的域名
	 */
	public function delPreTradeDomain($enameId, $domainName, $unRefreshStatus, $refreshStatus)
	{
		$now = date('Y-m-d H:i:s');
		$sql = "UPDATE " . $this->table .
			 " SET RefreshStatus=?,LastChangeDate=? WHERE Seller=? AND DomainName=? AND RefreshStatus=?";
		return $this->update($sql, 'isisi', array(
				$refreshStatus,$now,$enameId,$domainName,$unRefreshStatus
		));
	}

	/**
	 *
	 * @param unknown $auditListId        	
	 * @param unknown $enameId        	
	 */
	public function getSellerCanel($auditListId, $enameId)
	{
		$sql = 'SELECT AuditListId,TransStatus,TransTopic,DomainName,TransType,Buyer,Seller,BidCount,SellerOrderId,BuyerOrderId,IsDomainInEname,BidPrice,ReservePrice,IsShopRecommend,SimpleDec,NickName FROM ' .
			 $this->table . ' WHERE AuditListId= ? AND Seller=?';
		
		return $this->getRow($sql, 'ii', array(
				$auditListId,$enameId
		));
	}

	/**
	 * 设置状态
	 *
	 * @param unknown $auditListId        	
	 * @param unknown $status        	
	 * @return boolean
	 */
	public function setTransStatusModel($auditListId, $status)
	{
		$now = date('Y-m-d H:i:s');
		$sql = "UPDATE " . $this->table . " SET TransStatus =?,LastChangeDate=? WHERE AuditListId=?";
		
		return $this->update($sql, "isi", array(
				$status,$now,$auditListId
		));
	}

	/**
	 * 记录是否存在
	 *
	 * @param unknown $auditListId        	
	 */
	public function checkInEname($auditListId)
	{
		$sql = "SELECT AuditListId,DomainName,SellerOrderId,BuyerOrderId,IsDomainInEname FROM " . $this->table .
			 " WHERE AuditListId =?";
		
		return $this->getRow($sql, 'i', array(
				$auditListId
		));
	}

	/**
	 * setSellerAbandon
	 * $TransSellerLogic->setSellerAbandon
	 */
	public function setSellerAbandon($auditListId, $enameId, $SellerAbandonOrderId)
	{
		$now = date('Y-m-d H:i:s');
		$sql = "update " . $this->table . " set SellerAbandonOrderId=?,LastChangeDate=? where AuditListId=? and Seller=?";
		return $this->update($sql, 'isii', array(
				$SellerAbandonOrderId,$now,$auditListId,$enameId
		));
	}

	public function getByAuditListId($auditListId, $fields = '*')
	{
		$sql = 'select ' . $fields . ' from ' . $this->table . " where AuditListId=?";
		return $this->getRow($sql, 'i', array(
				$auditListId
		));
	}

	/**
	 * setSellerCanel
	 * $TransSellerLogic->setSellerCanel
	 */
	public function setSellerCanel($auditListId, $enameId, $status)
	{
		$now = date('Y-m-d H:i:s');
		$sql = 'Update ' . $this->table . ' SET TransStatus =?,LastChangeDate=? WHERE AuditListId =? AND Seller=?';
		
		return $this->update($sql, 'isii', array(
				$status,$now,$auditListId,$enameId
		));
	}

	/**
	 * 通过交易类型获取正在交易的域名的数量
	 */
	public function getAuctionCntByTransType($seller, $transType, $group = '', $tld = '')
	{
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table .
			 " WHERE Seller =? AND TransStatus=? AND FinishDate>NOW()";
		
		$sql .= $transType? " AND TransType IN ('$transType')": " AND TransType NOT IN ('$transType')";
		
		if($group)
		{
			if($group['sysGroupOne'])
			{
				$sql .= " AND SysGroupOne BETWEEN {$group['sysGroupOne'][0]} AND {$group['sysGroupOne'][1]}";
			}
			
			if($group['sysGroupTwo'])
			{
				$sql .= " AND SysGroupTwo={$group['sysGroupTwo']}";
			}
			
			if($group['domainLen'])
			{
				$sql .= " AND DomainLen={$group['domainLen']}";
			}
		}
		
		if($tld)
		{
			$sql .= " AND DomainTLD IN ({$tld})";
		}
		
		return $this->getOne($sql, 'ii', array(
				$seller,1
		));
	}

	/**
	 * 通过交易类型获取正在交易的域名
	 */
	public function getAuctionByTransType($seller, $transType, $limit, $group = '', $tld = '')
	{
		$now = date('Y-m-d H:i:s');
		
		$sql = "SELECT AuditListId, DomainName, TransType,  BidPrice, FinishDate, SimpleDec FROM " . $this->table .
			 " WHERE Seller =? AND TransStatus=? AND FinishDate>? ";
		
		$sql .= $transType? "AND TransType IN ('$transType')": " AND TransType NOT IN ('$transType')";
		
		if($group)
		{
			if($group['sysGroupOne'])
			{
				$sql .= " AND SysGroupOne BETWEEN {$group['sysGroupOne'][0]} AND {$group['sysGroupOne'][1]}";
			}
			
			if($group['sysGroupTwo'])
			{
				$sql .= " AND SysGroupTwo={$group['sysGroupTwo']}";
			}
			
			if($group['domainLen'])
			{
				$sql .= " AND DomainLen={$group['domainLen']}";
			}
		}
		
		if($tld)
		{
			$sql .= " AND DomainTLD IN ({$tld})";
		}
		
		$sql .= " ORDER BY FinishDate ASC LIMIT $limit";
		
		return $this->select($sql, 'iis', array(
				$seller,1,$now
		));
	}

	/**
	 * 店铺首页标签下的交易数量
	 */
	public function getShopDomainsCntByTag($seller, $transStatus, $tag)
	{
		$now = date('Y-m-d H:i:s');
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table;
		$sql .= " WHERE Seller=? AND TransStatus = ? AND IsShopRecommend&? AND FinishDate>?";
		return $this->getOne($sql, 'iiis', array(
				$seller,$transStatus,$tag,$now
		));
	}

	/**
	 * 店铺首页标签下的交易
	 */
	public function getShopDomainsByTag($seller, $transStatus, $tag, $limit)
	{
		$now = date('Y-m-d H:i:s');
		$sql = "SELECT AuditListId, DomainName, TransType, BidPrice, BidCount, SimpleDec, FinishDate FROM " .
			 $this->table;
		$sql .= " WHERE Seller=? AND TransStatus = ? AND IsShopRecommend&? AND FinishDate>?";
		$sql .= " ORDER BY FinishDate ASC LIMIT $limit";
		return $this->select($sql, 'iiis', array(
				$seller,$transStatus,$tag,$now
		));
	}

	/**
	 * 通过标签获取正在交易的域名
	 */
	public function getAuctionByTag($seller, $value, $limit)
	{
		$now = date('Y-m-d H:i:s');
		$sql = "SELECT AuditListId, DomainName, BidPrice, SimpleDec,TransType,FinishDate FROM " . $this->table .
			 " WHERE Seller =? AND TransStatus=? AND IsShopRecommend&? AND FinishDate>?";
		$sql .= " ORDER BY FinishDate ASC LIMIT $limit";
		
		return $this->select($sql, 'iiis', array(
				$seller,1,$value,$now
		));
	}

	public function getShopDomainsCntModel($seller, $transStatus, $domainName, $sldType, $domainTLD, $sysGroupOne, 
		$sysGroupTwo, $domainLen, $bidPrice, $finishTime, $registrar, $transType, $hidenobider, $transTypes, 
		$bidStartOne, $simpleDec, $tag = '', $tt = '', $group = '', $tld = '', $Value = '')
	{
		$now = date('Y-m-d H:i:s');
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table .
			 " WHERE Seller=?  AND TransStatus = ? AND FinishDate>? ";
		
		if($domainName != '')
		{
			switch($sldType)
			{
				case 1:
					$sql .= " AND DomainSLD LIKE '$domainName%'";
					break;
				case 2:
					$sql .= " AND DomainSLD LIKE '%$domainName%'";
					break;
				case 3:
					$sql .= " AND DomainSLD LIKE '%$domainName'";
					break;
				case 4:
					$sql .= " AND (DomainSLD LIKE '$domainName%' OR DomainSLD LIKE '%$domainName')";
					break;
				default:
					$sql .= " AND DomainSLD LIKE '%$domainName%'";
			}
		}
		
		$sql .= $domainTLD? (is_int($domainTLD)? " AND DomainTLD = $domainTLD": " AND DomainTLD IN ($domainTLD)"): '';
		
		if($sysGroupOne)
		{
			if(is_array($sysGroupOne))
			{
				$sql .= " AND SysGroupOne Between " . $sysGroupOne[0] . " AND " . $sysGroupOne[1];
			}
			else
			{
				$sql .= " AND SysGroupOne = " . $sysGroupOne;
			}
		}
		
		$sql .= $sysGroupTwo? " AND SysGroupTwo = " . $sysGroupTwo: '';
		
		if($domainLen)
		{
			if(is_array($domainLen))
			{
				$sql .= " AND DomainLen Between " . $domainLen[0] . " AND " . $domainLen[1];
			}
			else
			{
				$sql .= " AND DomainLen = " . $domainLen;
			}
		}
		
		if($bidPrice)
		{
			if(is_array($bidPrice))
			{
				$sql .= " AND BidPrice Between " . $bidPrice[0] . " AND " . $bidPrice[1];
			}
			else
			{
				$sql .= " AND BidPrice = " . $bidPrice;
			}
		}
		
		$sql .= $simpleDec != ''? " AND SimpleDec LIKE '%$simpleDec%'": "";
		$sql .= $bidStartOne? " AND AskingPrice = 1": "";
		$sql .= $finishTime? " AND FinishDate 	< '" . $finishTime . "'": '';
		$sql .= $registrar? ' AND IsDomainInEname = ' . $registrar: '';
		$sql .= $transType? " AND TransType IN ($transType)": '';
		$sql .= $transTypes? " AND TransType IN ($transTypes)": '';
		$sql .= $hidenobider? ' AND BidCount 	> 0': '';
		$sql .= $tag? " AND IsShopRecommend&$tag": '';
		
		// 新增内容
		$sql .= $tt? " AND TransType IN ($tt)": '';
		$sql .= $tld? " AND DomainTLD IN ($tld)": '';
		$sql .= $Value? " AND IsShopRecommend&$Value": '';
		
		if($group)
		{
			if($group['sysGroupOne'])
			{
				if(is_array($group['sysGroupOne']))
				{
					$sql .= " AND SysGroupOne Between " . $group['sysGroupOne'][0] . " AND " . $group['sysGroupOne'][1];
				}
				else
				{
					$sql .= " AND SysGroupOne = " . $group['sysGroupOne'];
				}
			}
			
			$sql .= $group['sysGroupTwo']? " AND SysGroupTwo = " . $group['sysGroupTwo']: '';
			
			if($group['domainLen'])
			{
				if(is_array($group['domainLen']))
				{
					$sql .= " AND DomainLen Between " . $group['domainLen'][0] . " AND " . $group['domainLen'][1];
				}
				else
				{
					$sql .= " AND DomainLen = " . $group['domainLen'];
				}
			}
		}
		
		return $this->getOne($sql, 'iis', array(
				$seller,$transStatus,$now
		));
	}

	public function getShopDomainsModel($seller, $transStatus, $domainName, $sldType, $domainTLD, $sysGroupOne, 
		$sysGroupTwo, $domainLen, $bidPrice, $finishTime, $registrar, $transType, $hidenobider, $transTypes, $tag, $sort, 
		$limit, $bidStartOne, $simpleDec, $tag = '', $tt = '', $group = '', $tld = '', $Value = '')
	{
		$now = date('Y-m-d H:i:s');
		$sql = "SELECT AuditListId, DomainName, TransType, BidPrice, SimpleDec, FinishDate FROM " . $this->table .
			 " WHERE Seller=? AND TransStatus =? AND FinishDate>? ";
		
		if($domainName != '')
		{
			switch($sldType)
			{
				case 1:
					$sql .= " AND DomainSLD LIKE '$domainName%'";
					break;
				case 2:
					$sql .= " AND DomainSLD LIKE '%$domainName%'";
					break;
				case 3:
					$sql .= " AND DomainSLD LIKE '%$domainName'";
					break;
				case 4:
					$sql .= " AND (DomainSLD LIKE '$domainName%' OR DomainSLD LIKE '%$domainName')";
					break;
				default:
					$sql .= " AND DomainSLD LIKE '%$domainName%'";
			}
		}
		
		$sql .= $domainTLD? (is_int($domainTLD)? " AND DomainTLD = $domainTLD": " AND DomainTLD IN ($domainTLD)"): '';
		
		if($sysGroupOne)
		{
			if(is_array($sysGroupOne))
			{
				$sql .= " AND SysGroupOne Between " . $sysGroupOne[0] . " AND " . $sysGroupOne[1];
			}
			else
			{
				$sql .= " AND SysGroupOne = " . $sysGroupOne;
			}
		}
		
		$sql .= $sysGroupTwo? " AND SysGroupTwo = " . $sysGroupTwo: '';
		
		if($domainLen)
		{
			if(is_array($domainLen))
			{
				$sql .= " AND DomainLen Between " . $domainLen[0] . " AND " . $domainLen[1];
			}
			else
			{
				$sql .= " AND DomainLen = " . $domainLen;
			}
		}
		
		if($bidPrice)
		{
			if(is_array($bidPrice))
			{
				$sql .= " AND BidPrice Between " . $bidPrice[0] . " AND " . $bidPrice[1];
			}
			else
			{
				$sql .= " AND BidPrice = " . $bidPrice;
			}
		}
		
		$sql .= $tt? " AND TransType IN ($tt)": '';
		$sql .= $tld? " AND DomainTLD IN ($tld)": '';
		$sql .= $Value? " AND IsShopRecommend&$Value": '';
		
		if($group)
		{
			if($group['sysGroupOne'])
			{
				if(is_array($group['sysGroupOne']))
				{
					$sql .= " AND SysGroupOne Between " . $group['sysGroupOne'][0] . " AND " . $group['sysGroupOne'][1];
				}
				else
				{
					$sql .= " AND SysGroupOne = " . $group['sysGroupOne'];
				}
			}
			
			$sql .= $group['sysGroupTwo']? " AND SysGroupTwo = " . $group['sysGroupTwo']: '';
			
			if($group['domainLen'])
			{
				if(is_array($group['domainLen']))
				{
					$sql .= " AND DomainLen Between " . $group['domainLen'][0] . " AND " . $group['domainLen'][1];
				}
				else
				{
					$sql .= " AND DomainLen = " . $group['domainLen'];
				}
			}
		}
		
		$sql .= $bidStartOne? " AND AskingPrice = 1": "";
		$sql .= $simpleDec != ''? " AND SimpleDec LIKE '%$simpleDec%'": "";
		$sql .= $finishTime? " AND FinishDate 	< '" . $finishTime . "'": '';
		$sql .= $registrar? ' AND IsDomainInEname = ' . $registrar: '';
		$sql .= $transType? " AND TransType IN ($transType)": '';
		$sql .= $transTypes? " AND TransType IN ($transTypes)": '';
		$sql .= $hidenobider? ' AND BidCount 	> 0': '';
		$sql .= $tag? " AND IsShopRecommend&$tag": '';
		if(isset($sort))
		{
			switch($sort)
			{
				case 1:
					$sql .= " ORDER BY FinishDate ";
					break;
				case 2:
					$sql .= " ORDER BY BidPrice ";
					break;
				case 3:
					$sql .= " ORDER BY BidCount Desc";
					break;
				default:
					$sql .= " ORDER BY FinishDate ";
					break;
			}
		}
		else
		{
			$sql .= " ORDER BY FinishDate ";
		}
		
		if($limit)
		{
			$sql .= " LIMIT $limit";
		}
		
		return $this->select($sql, 'iis', array(
				$seller,$transStatus,$now
		));
	}

	/**
	 * 根据数量判断此域名是否存在
	 *
	 * @param int $auditListId        	
	 * @param unknown $auditListId        	
	 * @return Ambigous <boolean, mixed>
	 */
	public function isDomainExist($auditListId)
	{
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table . " WHERE AuditListId=?";
		return $this->getOne($sql, 'i', array(
				$auditListId
		));
	}

	/**
	 * 获取交易表信息
	 *
	 * @param int $auditListId        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getTransAuctionInfo($auditListId)
	{
		$sql = "SELECT DomainName,Seller,Buyer,TransType,FinishDate,TransStatus,BidCount,BidPrice,AgentBidPrice,TransTopic,IsDomainInEname,SimpleDec,AskingPrice,DomainSLD,CreateDate,NickName,AuditListId,RestrictGrade FROM " .
			 $this->table . " WHERE AuditListId=?";
		return $this->getRow($sql, 'i', array(
				$auditListId
		));
	}

	/**
	 * 获取出价的交易信息
	 *
	 * @param unknown $auditListId        	
	 * @param unknown $transStatus        	
	 * @param unknown $seller        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getTransInfoForBid($auditListId, $transStatus)
	{
		$date = date("Y-m-d H:i:s");
		$sql = "SELECT TransStatus,Seller,Buyer,AskingPrice,DomainName,NickName,BidPrice,AgentBidPrice,BuyerIP,BuyerOrderId,BidCount,FinishDate,TransType,TransTopic,CreateDate from " .
			 $this->table;
		$sql .= " WHERE AuditListId=? AND TransStatus =? AND FinishDate>? ";
		return $this->getRow($sql, 'iis', array(
				$auditListId,$transStatus,$date
		));
	}

	public function updateAuctionFirstBider($auditListId, $buyer, $nickName, $buyerOrderId, $askingPrice, 
		$agentBidPrice = False)
	{
		$buyerIP = \common\Common::getRequestIp(); // 获取买家IP
		$rqTime = empty($_SERVER['REQUEST_TIME'])? time(): $_SERVER['REQUEST_TIME'];
		$lastData = date("Y-m-d H:i:s", $rqTime);
		$sql = 'UPDATE ' . $this->table . " SET
			Buyer=?,
			NickName=?,
			BuyerOrderId=?,
			BuyerIP =?,
			BidCount=BidCount+1,
			LastChangeDate =?,
			LastBidDate=?";
		$sql .= $agentBidPrice? ",AgentBidPrice=?": '';
		$sql .= " WHERE AuditListId=? and BidPrice=? AND Buyer=?";
		
		return $agentBidPrice? $this->update($sql, 'isisssdidi', 
			array($buyer,$nickName,$buyerOrderId,$buyerIP,$lastData,$lastData,$agentBidPrice,$auditListId,$askingPrice,
				0), TRUE) :$this->update($sql, 'isisssidi', 
			array($buyer,$nickName,$buyerOrderId,$buyerIP,$lastData,$lastData,$auditListId,$askingPrice,0), TRUE);
	}

	public function unLeaderUpdatePriceModel($auditListId, $oldBuyer, $oldBidPrice, $buyer, $nickName, $buyerOrderId, 
		$bidPrice, $agentBidPrice, $newFinishDate, $oldAgentBidPrice = false)
	{
		$buyerIP = \common\Common::getRequestIp();
		$rqTime = empty($_SERVER['REQUEST_TIME'])? time(): $_SERVER['REQUEST_TIME'];
		$lastBidDate = date("Y-m-d H:i:s", $rqTime);
		$sql = "UPDATE " . $this->table . " SET
			LastBidDate = ?,
			LastChangeDate =?,
			Buyer = ?,
			NickName =?,
			BuyerOrderId =?,
			BidPrice = ?,
			AgentBidPrice = ?,
			BidCount = BidCount+1,
			FinishDate = ?,
			BuyerIP = ? WHERE AuditListId=? AND Buyer=? AND BidPrice=? ";
		$sql .= $oldAgentBidPrice !== false ? " AND AgentBidPrice=? ": '';
		
		return $oldAgentBidPrice !== false ? $this->update($sql, 'ssisiddssiidd', 
			array($lastBidDate,$lastBidDate,$buyer,$nickName,$buyerOrderId,$bidPrice,$agentBidPrice,$newFinishDate,
				$buyerIP,$auditListId,$oldBuyer,$oldBidPrice,$oldAgentBidPrice), TRUE) :$this->update($sql, 
			'ssisiddssiid', 
			array($lastBidDate,$lastBidDate,$buyer,$nickName,$buyerOrderId,$bidPrice,$agentBidPrice,$newFinishDate,
				$buyerIP,$auditListId,$oldBuyer,$oldBidPrice), TRUE);
	}

	/**
	 * 更新BidCount
	 *
	 * @param int $auditListId        	
	 * @param int $bidCount        	
	 * @return boolean
	 */
	public function updateBidCount($auditListId, $bidCount)
	{
		$now = date('Y-m-d H:i:s');
		$sql = "UPDATE " . $this->table . " SET BidCount=?,LastChangeDate=? WHERE AuditListId=?";
		return $this->update($sql, 'isi', array($bidCount,$now,$auditListId), TRUE);
	}

	/**
	 * 获取交易信息
	 *
	 * @param int $auditListId        	
	 */
	public function getAuctionInfoByAuditListId($auditListId)
	{
		$sql = "SELECT TransStatus,Seller,Buyer,AskingPrice,DomainName,NickName,BidPrice,AgentBidPrice,BuyerIP,BuyerOrderId,BidCount,FinishDate,TransType, TransTopic, SimpleDec " .
			 " FROM " . $this->table . " WHERE AuditListId=?" . " ORDER BY FinishDate ASC";
		return $this->getRow($sql, 'i', array(
				$auditListId
		));
	}

	/**
	 * 更新代理价
	 *
	 * @param int $auditListId        	
	 * @param int $buyer        	
	 * @param float $agentBidPrice        	
	 * @param int $buyerOrderId        	
	 * @param float $postPrice        	
	 */
	public function updateAgentPrice($auditListId, $buyer, $agentBidPrice, $buyerOrderId, $postPrice)
	{
		$rqTime = empty($_SERVER['REQUEST_TIME'])? time(): $_SERVER['REQUEST_TIME'];
		$lastDate = date("Y-m-d H:i:s", $rqTime);
		$sql = 'UPDATE ' . $this->table . " SET AgentBidPrice=?,BuyerOrderId=?,LastChangeDate=? ";
		$sql .= " WHERE AuditListId=? AND Buyer=? AND AgentBidPrice=?";
		return $this->update($sql, 'disiid', 
			array($postPrice,$buyerOrderId,$lastDate,$auditListId,$buyer,$agentBidPrice), TRUE);
	}

	/**
	 * 获取交易信息，写redis（下架）
	 *
	 * @param int $auditListId        	
	 * @param int $seller        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getDelTransInfo($auditListId, $seller)
	{
		$sql = "SELECT AuditListId, DomainName, Seller, Buyer,TransTopic,TransStatus,FinishDate FROM " . $this->table .
			 " WHERE AuditListId=? AND Seller =?";
		return $this->getRow($sql, 'ii', array(
				$auditListId,$seller
		));
	}

	/**
	 * 下架交易
	 */
	public function cancelTransByIds($seller, $auditListId, $del, $trade, $checkBid)
	{
		$now = date('Y-m-d H:i:s');
		$sql = "UPDATE " . $this->table .
			 " SET TransStatus=?, LastChangeDate=? WHERE Seller=? AND TransStatus=? AND AuditListId=?";
		$sql .= $checkBid? " AND BidCount=?" :"";
		return $checkBid? $this->update($sql, 'isiiii', array($del,$now,$seller,$trade,$auditListId,0), TRUE) :$this->update(
			$sql, 'isiii', array($del,$now,$seller,$trade,$auditListId), TRUE);
	}

	/**
	 * 获取交易列表
	 *
	 * @param unknown $auditListIds        	
	 */
	public function getTransListByIds($auditListIds)
	{
		$sql = "SELECT AuditListId,TransType,BidPrice, FinishDate, DomainName FROM " . $this->table .
			 " WHERE AuditListId IN ($auditListIds) ORDER BY FinishDate ASC";
		return $this->select($sql, '', array());
	}

	/**
	 * 获取易拍易卖 正在交易的全部数据
	 */
	public function getEbuyAllModel($topic, $status, $day = '', $offset = 0, $pageSize = 0, $orderby = '', $order = 'ASC')
	{
		$now = date('Y-m-d H:i:s');
		$sql = "SELECT AuditListId,DomainName,TransType,TransTopic,Topic,SysGroupOne,BidPrice,FinishDate,FinishDateFlag,SimpleDec,Seller,BidCount  From " .
			 $this->table . " WHERE TransTopic=? AND TransStatus=? AND FinishDate>? ";
		if($day)
		{
			$sql .= " AND FinishDateFlag =? ";
		}
		if($orderby)
			$sql .= " ORDER BY $orderby $order ";
		else
			$sql .= " Order By FinishDate ";
		
		if($offset || $pageSize)
		{
			$sql .= " LIMIT $offset,$pageSize";
		}
		
		return $day? $this->select($sql, 'iiss', array(
				$topic,$status,$now,$day
		)): $this->select($sql, 'iis', array(
				$topic,$status,$now
		));
	}

	/**
	 * 获取交易数据
	 *
	 * @param int $seller        	
	 * @param string $domainNames        	
	 * @param string $preTradeStatus        	
	 * @param int $refreshStatus        	
	 * @param int $inEname        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getTransOldData($seller, $domainNames, $preTradeStatus, $refreshStatus, $inEname)
	{
		$sql = "SELECT DomainName, AskingPrice, SimpleDec, TransType FROM " . $this->table .
			 " WHERE Seller=? AND RefreshStatus=? AND DomainName IN ($domainNames)" .
			 " AND TransStatus IN ($preTradeStatus) AND IsDomainInEname=?";
		return $this->select($sql, 'iii', array(
				$seller,$refreshStatus,$inEname
		));
	}

	/**
	 * 获取交易中的sedo域名
	 *
	 * @param string $domainName        	
	 * @param int $transStatus        	
	 * @return Ambigous <boolean, mixed>
	 */
	public function getSedoDomainOnSale($domainName, $transStatus)
	{
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table .
			 " WHERE DomainName=? AND TransType=? AND TransTopic=? AND TransStatus =?";
		return $this->getOne($sql, 'siii', array(
				$domainName,4,100,$transStatus
		));
	}

	/**
	 * 设置sedo域名的交易状态
	 *
	 * @param string $domainName        	
	 * @param int $transStatus        	
	 * @param int $status        	
	 * @return boolean
	 */
	public function setSedoDomainStatus($domainName, $transStatus, $status)
	{
		$sql = "UPDATE " . $this->table .
			 " SET TransStatus=? WHERE DomainName=? AND TransType=? AND TransTopic=? AND  TransStatus = ?";
		return $this->update($sql, 'isiii', array(
				$status,$domainName,4,100,$transStatus
		));
	}

	/**
	 * 通过域名名称获取域名数量
	 *
	 * @param string $domainName        	
	 * @param string $transStatus        	
	 * @return Ambigous <boolean, mixed>
	 */
	public function getDomainCountByName($domainName, $transStatus)
	{
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table . " WHERE DomainName=? AND TransStatus IN ($transStatus)";
		return $this->getOne($sql, 's', array(
				$domainName
		));
	}

	/**
	 * 获取等待上架交易信息
	 *
	 * @param int $enameId        	
	 * @param string $domainName        	
	 * @param string $statusStr        	
	 * @param int $refreshStatus        	
	 * @param int $inEname        	
	 * @return array
	 */
	public function getPreTradeInfo($enameId, $domainName, $statusStr, $refreshStatus, $inEname)
	{
		$sql = "SELECT AuditListId, DomainName, IsShopRecommend  FROM " . $this->table .
			 " WHERE DomainName=? AND TransStatus IN ($statusStr) AND Seller=? AND RefreshStatus=? AND IsDomainInEname=?";
		return $this->getRow($sql, 'siii', array(
				$domainName,$enameId,$refreshStatus,$inEname
		));
	}

	/**
	 * 交易数据入库
	 *
	 * @param array $data        	
	 * @return boolean
	 */
	public function addAuctionDomain($data)
	{
		$now = date("Y-m-d H:i:s");
		$data['IsShopRecommend'] = isset($data['IsShopRecommend'])? $data['IsShopRecommend']: 0;
		$sql = "INSERT INTO " . $this->table .
			 " (AuditListId, DomainName, TransStatus, DomainSLD, DomainTLD, DomainLen, SimpleDec,TransDay, TransType, " .
			 "TransTopic, Topic, Seller, AskingPrice, ReservePrice, BidPrice, SellerOrderId, Buyer,BuyerOrderId, " .
			 "SubmitDate, CreateDate, FinishDate, FinishDateFlag, LastChangeDate, IsDomainInEname, SellerIP, " .
			 "ClassName, SysGroupOne, SysGroupTwo, DeadTime, Poundage, BidCount, Weight, IsShopRecommend)" .
			 " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		return $this->add($sql, 'isississiiiidddiiisssssisiiisiiii', 
			array(
					$data['auditListId'],$data['domainName'],$data['transStatus'],$data['domainSLD'],$data['TLDIndex'],
					$data['domainLength'],$data['summary'],$data['forSaleLife'],$data['transType'],
					$data['transTopic'],$data['topic'],$data['seller'],$data['askingPrice'],$data['reservePrice'],
					$data['bidPrice'],$data['sellerOrderId'],$data['buyer'],$data['buyerOrderId'],$data['submitDate'],
					$data['createDate'],$data['finishDate'],$data['finishDateFlag'],$now,$data['isEnameDomain'],
					$data['sellerIP'],$data['className'],$data['sysGroupOne'],$data['sysGroupTwo'],$data['deadTime'],
					$data['poundage'],$data['bidCount'],$data['weight'],$data['IsShopRecommend']
			));
	}

	/**
	 * 获取卖家交易数量
	 *
	 * @param unknown $seller        	
	 * @param string $status        	
	 * @param string $year        	
	 */
	public function getAuctionCnt($seller, $status = false, $year = '')
	{
		$tableName = $year? $this->table . "_" . $year: $this->table;
		$sql = "SELECT COUNT(AuditListId) FROM " . $tableName . " WHERE Seller=?";
		$sql .= $status? " AND TransStatus=?": '';
		return $status? $this->getOne($sql, 'ii', array(
				$seller,$status
		)): $this->getOne($sql, 'i', array(
				$seller
		));
	}

	/**
	 * 获取交易信息
	 *
	 * @param int $auditListId        	
	 * @param int $transStatus        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getTransInfoForBuyNow($auditListId, $transStatus)
	{
		$sql = "SELECT	AuditListId,TransTopic,TransStatus,Seller,Poundage,Buyer,AskingPrice,DomainName,NickName,BidPrice,AgentBidPrice,BuyerIP,BuyerOrderId,BidCount,FinishDate,TransType,IsDomainInEname,CreateDate,SimpleDec from " .
			 $this->table . " WHERE AuditListId=? AND TransStatus = ? AND Buyer = ?";
		return $this->getRow($sql, 'iii', array(
				$auditListId,$transStatus,0
		));
	}

	/**
	 * 设置一口价
	 *
	 * @param int $auditListId        	
	 * @param int $transStatus        	
	 * @param int $buyer        	
	 * @param string $nickName        	
	 * @param int $buyerOrderId        	
	 * @param int $bidPrice        	
	 * @param int $bidCount        	
	 * @param string $buyerIP        	
	 * @return boolean
	 */
	public function setBuyerNow($auditListId, $transStatus, $buyer, $nickName, $buyerOrderId, $bidPrice, $bidCount, 
		$buyerIP)
	{
		$rqTime = empty($_SERVER['REQUEST_TIME'])? time(): $_SERVER['REQUEST_TIME'];
		$lastTime = date('Y-m-d H:i:s', $rqTime);
		$finishDateFlag = date('Y-m-d', $rqTime);
		$bidCount = $bidCount + 1;
		$sql = 'UPDATE ' . $this->table
			. " SET TransStatus=?,Buyer=?,NickName=?,BuyerOrderId=?,BidPrice=?,LastChangeDate=?,LastBidDate=?,BidCount=?,BuyerIP=?,FinishDate=?,FinishDateFlag=?"
			. " WHERE AuditListId =? AND TransStatus=? AND Buyer=? AND AskingPrice = ? AND BidPrice = ?";
		return $this->update($sql, 'iisidssisssiiidd', 
			array($transStatus,$buyer,$nickName,$buyerOrderId,$bidPrice,$lastTime,$lastTime,$bidCount,$buyerIP,
				$lastTime,$finishDateFlag,$auditListId,1,0,$bidPrice,$bidPrice), TRUE);
	}

	/**
	 * 设置交易状态
	 *
	 * @param int $auditListId        	
	 * @param int $status        	
	 * @return boolean
	 */
	public function setTransStatus($auditListId, $status)
	{
		$now = date('Y-m-d H:i:s');
		$sql = 'UPDATE ' . $this->table . " SET TransStatus = ?,LastChangeDate=? WHERE AuditListId =?";
		return $this->update($sql, 'isi', array($status,$now,$auditListId));
	}

	/**
	 * 获取买家昵称
	 *
	 * @param int $auditListId        	
	 * @param string $year        	
	 */
	public function getNickName($auditListId, $year = false)
	{
		$table = $year? $this->table . '_' . $year: $this->table;
		$sql = "SELECT NickName FROM " . $table . " WHERE AuditListId=?";
		return $this->getOne($sql, 'i', array(
				$auditListId
		));
	}

	/**
	 * 检查是否存在该表
	 *
	 * @param int $year        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function checkTable($year)
	{
		$sql = "SHOW TABLES LIKE '" . $this->table . "_$year'";
		return $this->select($sql, '', array());
	}

	/**
	 * 判断是否存在正在交易的记录
	 *
	 * @param int $id        	
	 * @param int $transStatus        	
	 */
	public function getIstrandding($id, $transStatus)
	{
		$types = '';
		$data = array();
		$types .= 'i';
		$data[] = $id;
		$clause = implode(',', array_fill(0, count($transStatus), '?'));
		for($i = 0; $i < count($transStatus); $i ++)
		{
			$types .= 'i';
		}
		$data[] = $transStatus;
		$sql = "select count(AuditListId) from " . $this->table . " where AuditListId=? and TransStatus in($clause)";
		return $this->getOne($sql, $types, $data);
	}

	/**
	 * 获取交易域名信息新接口
	 *
	 * @param array $args        	
	 * @param string $fields        	
	 */
	public function getListNew($args, $fields)
	{
		$data = array();
		$type = '';
		$field = $fields == "count"? 'count(AuditListId)': 'DomainName, TransType, TransStatus, SimpleDec, FinishDate, AuditListId, BidPrice, BidCount';
		$sql = "SELECT {$field} FROM {$this->table} WHERE Seller=?";
		$data[] = $args->uid;
		$type = 'i';
		
		// 域名
		if($args->domainsld)
		{
			$domainsld = $args->domainsld;
			
			switch(array_sum(explode(',', $args->pos)))
			{
				case 1:
					$sql .= " AND DomainSLD LIKE '{$domainsld}%'";
					break;
				case 2:
					$sql .= " AND DomainSLD LIKE '%{$domainsld}'";
					break;
				case 3:
					$sql .= " AND (DomainSLD LIKE '%{$domainsld}' OR DomainSLD LIKE '{$domainsld}%')";
					break;
				default:
					$sql .= " AND DomainSLD LIKE '%{$domainsld}%'";
			}
		}
		
		// 价格区间
		if($args->bidpricestart)
		{
			$sql .= " AND BidPrice >= ?";
			$data[] = $args->bidpricestart;
			$type .= 'i';
		}
		if($args->bidpriceend)
		{
			$sql .= " AND BidPrice <= ?";
			$data[] = $args->bidpriceend;
			$type .= 'i';
		}
		
		// 注册商
		if($args->registrar)
		{
			$sql .= " AND IsDomainInEname=?";
			$data[] = $args->registrar;
			$type .= 'i';
		}
		
		// 简介
		if($args->simpledec)
		{
			$sql .= " AND SimpleDec LIKE ?";
			$data[] = '%' . $args->simpledec . '%';
			$type .= 's';
		}
		
		// 多后缀
		if($args->domaintld)
		{
			$sql .= " AND DomainTLD IN({$args->domaintld})";
		}
		
		// 域名分组
		if($args->SysGroupOne)
		{
			if(is_array($args->SysGroupOne))
			{
				$sql .= " AND SysGroupOne>=? AND SysGroupOne<=?";
				$data[] = $args->SysGroupOne[0];
				$type .= 'i';
				$data[] = $args->SysGroupOne[1];
				$type .= 'i';
			}
			else
			{
				$sql .= " AND SysGroupOne=?";
				$data[] = $args->SysGroupOne;
				$type .= 'i';
			}
		}
		
		if($args->SysGroupTwo)
		{
			$sql .= " AND SysGroupTwo=?";
			$data[] = $args->SysGroupTwo;
			$type .= 'i';
		}
		
		// 域名长度
		if($args->DomainLen)
		{
			$sql .= " AND DomainLen=?";
			$data[] = $args->DomainLen;
			$type .= 'i';
		}
		
		// 域名长度开始位置
		if($args->domainlenstart)
		{
			$sql .= " AND DomainLen>=?";
			$data[] = $args->domainlenstart;
			$type .= 'i';
		}
		// 域名长度结束位置
		if($args->domainlenend)
		{
			$sql .= " AND DomainLen<=?";
			$data[] = $args->domainlenend;
			$type .= 'i';
		}
		
		// 结束时间
		if($args->finishtime)
		{
			$time = time();
			switch($args->finishtime)
			{
				case 1:
				case 2:
				case 3:
					$time = strtotime("+{$args->finishtime} hours");
					break;
				case 4:
					$time = strtotime("+6 hours");
					break;
				case 5:
					$time = strtotime("+12 hours");
					break;
				case 6:
				case 7:
				case 8:
				case 9:
				case 10:
				case 11:
				case 12:
					$to = $args->finishtime - 5;
					$time = strtotime("+{$to} day");
					break;
			}
			$sql .= " AND FinishDate<=?";
			$data[] = date('Y-m-d H:i:s', $time);
			$type .= 's';
		}
		
		// 交易类型
		if($args->shoptag['Value'])
		{
			$sql .= " AND IsShopRecommend&?";
			$data[] = $args->shoptag['Value'];
			$type .= 'i';
			
			// 类型查询
			if($args->transtype)
			{
				$sql .= " AND TransType=?";
				$data[] = $args->transtype;
				$type .= 'i';
			}
		}
		else
		{
			$sql .= " AND TransType=?";
			$data[] = $args->shoptag['TransType'];
			$type .= 'i';
		}
		
		// 竞价有人出价
		if($args->hidenobider)
		{
			$sql .= " AND (BidCount>0 AND TransType=1)";
		}
		
		// 竞价1元起拍
		if($args->bidstartone)
		{
			$sql .= " AND (AskingPrice=1 AND TransType=1)";
		}

		if(!isset($args->isCnnicUser)||!$args->isCnnicUser)
		{
			// 正在交易
			$sql .= " AND transStatus=1";
			// 结束时间
			$sql .= " AND FinishDate>=?";
			$data[] = date('Y-m-d H:i:s');
			$type .= 's';

			// 排序
			switch($args->sort)
			{
				case 2:
					$sql .= " ORDER BY BidPrice ASC";
					break;
				case 3:
					$sql .= " ORDER BY BidCount DESC";
					break;
				default:
					$sql .= " ORDER BY FinishDate ASC";
					break;
			}
		}
		else
		{
			$sql .= " ORDER BY TransStatus ASC, FinishDate ASC";
		}

		// 列表获取分页数量
		if($fields != 'count')
		{
			$num = $args->num? $args->num: 4;
			$offset = $args->p? ($args->p - 1) * $num: 0;
			$sql .= " LIMIT ?,?";
			$data[] = $offset;
			$data[] = $num;
			$type .= "ii";
		}
		
		// 返回数量还是列表
		$func = $fields == 'count'? 'getOne': "select";
		return $this->$func($sql, $type, $data);
	}

	public function getTransdata($domain, $startTime, $endTime)
	{
		$sql = "select SellerIp,CreateDate from " . $this->table .
			 " where DomainName=? and CreateDate between ? and ? order by AuditListId DESC";
		return $this->getRow($sql, 'sss', array(
				$domain,$startTime,$endTime
		));
	}

	public function getTotalCount($transTypeConf)
	{
		$date = date('Y-m-d H:i:s');
		$sql = " SELECT COUNT(AuditListId)  FROM " . $this->table . " WHERE TransStatus= ? AND (TransType = " .
			 $transTypeConf['auction'][0] . " OR TransType =" . $transTypeConf['buynow'][0] . ")  AND FinishDate>=?";
		return $this->getOne($sql, 'is', array(1,$date));
	}

	/**
	 * 竞价大厅域名是否正在交易
	 */
	public function isAuctionIng($auditListId)
	{
		$start = date('Y-m-d H:i:s');
		$end = date('Y-m-d 23:59:59');
		$sql = "SELECT count(AuditListId) FROM {$this->table} WHERE FinishDate BETWEEN '{$start}' AND '{$end}' AND Transtype=1 AND AuditListId=?";
		
		return $this->getOne($sql, 'i', array($auditListId));
	}
	
}
?>
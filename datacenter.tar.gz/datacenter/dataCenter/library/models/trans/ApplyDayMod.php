<?php
namespace models\trans;

use core\ModBase;
class ApplyDayMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_apply_day';
	}
	
	/**
	 * 统计延期申请次数
	 * @param int			$auditListId
	 * @param int			$status			标志位，卖家的申请还是买家的申请，1卖家，2买家
	 * @param int			$type			交易类型，默认1竞价、一口价；5询价
	 * @return int|false					成功时返回申请次数，失败返回false
	 */
	public function countApplyTimes($auditListId,$status,$type=1)
	{
		$sql = 'SELECT COUNT(id) FROM ' . $this->table . ' where AuditListId=?';
		$sql.= ' and Status=? and Type=?';
		return $this->getOne($sql, 'iii', array($auditListId,$status,$type));
	}
	
	/**
	 * 更新延期申请状态
	 * @param int  $id
	 * @param int  $applyStatus		1同意，2拒绝
	 * @param int  $status			标志位，卖家的申请还是买家的申请，1卖家，2买家
	 * @return				
	 */
	public function updateApplyStatus($id,$applyStatus,$status)
	{
		$sql = 'update ' . $this->table .' set ApplyStatus=?,UpdateTime=?';
		$sql.= ' where Id=? and Status=?';
		return $this->update($sql, 'iiii', array($applyStatus,\time(),$id,$status));
	}
	
	/**
	 * 获取延期申请记录
	 * @param int  $auditListId
	 * @param int  $status			标志位，卖家的申请还是买家的申请，1卖家，2买家
	 * @param int  $type			交易类型，默认1竞价、一口价；5询价
	 * @return array|false
	 */
	public function getApplyDay($auditListId,$status=0,$type=1)
	{
		$dataType = 'ii';
		$data = array($auditListId,$type);
		$sql = 'select Id,ApplyDay,ApplyStatus,Status from ' . $this->table .' where AuditListId=?';
		$sql.= ' and Type=?';
		if($status)
		{
			$sql .= ' and Status=?';
			$dataType .= 'i';
			$data[] = $status;
		}
		$sql.=' order by id desc';
		return $this->getRow($sql, $dataType, $data);
	}
	
	/**
	 * 添加延期申请记录
	 * @param  array      $arr
	 * @param  int        $type 交易类型，默认1竞价、一口价；5询价
	 * @return int|false
	 */
	public function addApplyDay($arr,$type=1){
		$arr = array_merge($arr,array(0,time(),0,$type));
		$sql = 'insert into ' . $this->table;
		$sql.= ' (AuditListId,ApplyDay,Status,ApplyStatus,CreateTime,UpdateTime,Type)';
		$sql.= ' values(?,?,?,?,?,?,?)';
		return $this->add($sql, 'iiiiiii', $arr);
	}
	
	/**
	 * 删除指定卖家/买家未被处理的延期申请记录
	 * @param  int $auditListId    $auditListId
	 * @param  int $status		    标志位，卖家的申请还是买家的申请，1卖家，2买家
	 * @param  int $type           交易类型，默认1竞价、一口价；5询价
	 * @return int
	 */
	public function delApplyDayRecord($auditListId,$status,$type=1)
	{
		$sql = 'delete from ' . $this->table . ' where AuditListId = ? and ApplyStatus = 0 and Status = ? and Type = ?';
		return $this->delete($sql, 'iii', array($auditListId, $status, $type));
	}
}
?>

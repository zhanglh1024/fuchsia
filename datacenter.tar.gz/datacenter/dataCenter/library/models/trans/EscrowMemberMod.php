<?php

namespace models\trans;

use core\ModBase;
class EscrowMemberMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'escrow_member';
	}

	public function getAllMember()
	{
		$sql = "SELECT member_adminid, member_nick, member_name, member_role FROM " . $this->table;
		return $this->select($sql, '', array());
	}

	public function getMemberStatusByNick($nick)
	{
		$sql = "SELECT member_accept FROM " . $this->table . " WHERE member_nick=?";
		return $this->getOne($sql, 's', array($nick));
	}
	public function getAgentList($isfabu=1)
	{
		$sql = "SELECT fabuid, member_nick FROM " . $this->table ;
		$sql .= $isfabu ? " WHERE isfabu= ? AND fabuid >0 AND member_work= ? ":" WHERE  fabuid >0 ";
		$type  = $isfabu ? 'ii':'';
		$data = $isfabu ? array(1,1):array();
		return $this->select($sql, $type, $data);
	}
}
?>
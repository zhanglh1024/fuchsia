<?php
namespace models\trans\redis;

use core\RedisLib;
class TransRedisLib extends RedisLib
{

	private $redis;
	private $TIsdk;

	public function __construct()
	{
		$this->redis = parent::getInstance('trans');
		$this->TIsdk = new \models\trans\redis\TransIndex();
	}
	
	/**
	 * 买家一口价交易删除redis
	 * @param int $auditListId
	 * @return boolean
	 */
	public function doRedisBuyNow($auditListId)
	{
		$key = $this->TIsdk->getAuditKeys($auditListId);
		$keys = $this->TIsdk->getKeys($key);
		if($keys && is_array($keys))
		{
			foreach($keys as $val) // 删除详细页及交易redis
			{
				$this->TIsdk->delRedis($val);
			}
			$this->TIsdk->delIndexParityRedis(); // 删除首页平价redis
		}
		return true;
	}
}

?>
<?php
namespace models\trans\redis;
use core\RedisLib;
class TransDetailTrans extends RedisLib
{
	private $redis;
	
	public function __construct()
	{
		$this->redis = parent::getInstance('trans');
	}
	
	/**
	 * 获取详细页易拍易卖 keyName
	 */
	public function getEbuyKeys()
	{
		return $this->redis->keys('trans_index_auditListId_ebuy*');
	}
	public function getEbuyStatus()
	{
		return $this->redis->get('ebuy_status');
	}
	/**
	 * 读取数据库状态
	 */
	public function setEbuyStatus()
	{
		$this->redis->setex('ebuy_status', 10, 1);
	}
	public function delEbuyStatus()
	{
		$this->redis->del('ebuy_status');
	}
	/**
	 * 获得易拍易卖详细页 keyName
	 */
	public function getEbuyDetailKeyName($topic, $day)
	{
		$keyName = $day ? 'trans_index_auditListId_ebuy_*_'.$topic.'_*_'.$day : 'trans_index_auditListId_ebuy_*_'.$topic.'_*';
		return $keyName ;
	}
	/**
	 * 获取详细页专题拍卖 keyName
	 */
	public function getTopicKeys()
	{
		return $this->redis->keys('trans_index_auditListId_topic*');
	}
	public function getTopicStatus()
	{
		return $this->redis->get('topic_status');
	}
	public function setTopicStatus()
	{
		$this->redis->setex('topic_status', 10, 1);
	}
	public function delTopicStatus()
	{
		$this->redis->del('topic_status');
	}
	/**
	 * 获得专题拍卖详细页 keyName
	 */
	public function getTopicDetailKeyName($topic, $day)
	{
		$keyName = $day ? 'trans_index_auditListId_topic_*_'.$topic.'_*_'.$day : 'trans_index_auditListId_topic_*_'.$topic.'_*';
		return $keyName ;
	}
}
?>
<?php
namespace models\trans\redis;

use core\RedisLib;
class TransAuction extends RedisLib
{

	private $redis;

	public function __construct()
	{
		$this->redis = parent::getInstance('trans');
	}

	/**
	 * 获取发布交易FLAG
	 * 
	 * @param int $enameId        	
	 * @return boolean
	 */
	public function getFabuFlag($enameId)
	{
		$keyName = 'trans:fabu:' . $enameId;
		return $this->redis->get($keyName)?  :FALSE;
	}
	/**
	 * 设置发布交易FLAG
	 * @param int $enameId
	 * @return boolean
	 */
	public function setFabuFlag($enameId)
	{
		$keyName = 'trans:fabu:'.$enameId;
		return $this->redis->setex($keyName, 30, 1) ? TRUE : FALSE;
	}
	
	/**
	 * 释放发布交易FLAG
	 * @param int $enameId
	 * @return boolean
	 */
	public function delFabuFlag($enameId)
	{
		$keyName = 'trans:fabu:' . $enameId;
		if($this->redis->exists($keyName))
		{
			return $this->redis->del($keyName);
		}
		return FALSE;
	}
	
	/**
	 * 添加被盗域名
	 * @param unknown $domain
	 */
	public function addStoleDomain($domain)
	{
		$keyName = 'trans:fabu:stolendomain';
		return $this->redis->hSet($keyName, $domain, 1);
	}
	
	/**
	 * 获取被盗域名，判断是否是被盗域名
	 * @param unknown $domain
	 */
	public function getStoleDomain($domain)
	{
		$keyName = 'trans:fabu:stolendomain';
		return $this->redis->hGet($keyName, $domain);
	}
}
?>
<?php
namespace models\trans\redis;
use core\RedisLib;
	class TransSeller extends RedisLib
	{
		private $redis;
		private $listName;
		
		public function __construct()
		{
			$this->redis = parent::getInstance('trans');
			$this->listName = 'list_close_trans';
		}
		public function pushDelTrans($data, $enameId)
		{
			return $this->redis->lpush($this->listName."_".$enameId, json_encode($data));
		}
		public function getSwitchList()
		{
			return $this->redis->lRange('list_switch', 0, -1);
		}
		public function pushSwitch($enameId)
		{
			return $this->redis->lpush('list_switch', $enameId);
		}
	}
?>
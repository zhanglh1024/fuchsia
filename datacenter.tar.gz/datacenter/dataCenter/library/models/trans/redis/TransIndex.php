<?php

	namespace models\trans\redis;
	use core\RedisLib;
	class TransIndex extends RedisLib
	{
		
		private $redis;
		
		public function __construct()
		{
			$this->redis = parent::getInstance('trans');
		}
		/**
		 * 获取交易keyName
		 */
		public function getAuditKeys($auditListId)
		{
			$keyName = '*_index_auditListId*' . $auditListId . '*'; //交易首页|白金首页
			return $keyName;
		}
		
		/**
		 * 获取多个key值
		 */
		public function getKeys($keyName)
		{
			$data = $this->redis->keys($keyName);
			return $data;
		}
		
		/**
		 * 删除单个key redis
		 */
		public function delRedis($keyName)
		{
			$this->redis->del($keyName);
		}
		
		/**
		 * 删除首页易拍易卖
		 */
		public function delIndexEbuyRedis()
		{
			return $this->redis->del('trans_index_ebuy_list');
		}
		
		/**
		 * 删除首页专题拍卖
		 */
		public function delIndexTopicRedis()
		{
			return $this->redis->del('trans_index_topic_list');
		}
		/**
		 * 删除首页 平价域名
		 */
		public function delIndexParityRedis()
		{
			return $this->redis->del('trans_index_parity_list');
		}
		
		/**
		 * 用户出价
		 * @param int $auditListId
		 * @return boolean
		 */
		public function getAuctionInfoAll($auditListId)
		{
			return $this->redis->keys('trans_index_auditListId*' . $auditListId . '*') ? : false;
		}
		
		/**
		 * 获取失效时间
		 * @param string $keyName
		 */
		public function getTtl($keyName)
		{
			return $this->redis->ttl($keyName);
		}
		/**
		 * 设置值
		 * @param string $key
		 * @param string $val
		 * @param string $ttl
		 */
		public function setValue($key, $val, $ttl = false)
		{
			return $ttl ? $this->redis->setex($key, $ttl, $val) : $this->redis->set($key, $val);
		}
		/**
		 * 设置易拍易卖详细页redis
		 */
		public function setEbuyBigRedis($SysGroupOne, $AuditListId, $Topic, $FinishDateFlag, $Domain)
		{
			if($SysGroupOne > 0 && $SysGroupOne < 101)
				$group = 'number';
			elseif($SysGroupOne > 100 && $SysGroupOne < 201)
			$group = 'string';
			else
				$group = 'other';
		
			$keyName = 'trans_index_auditListId_ebuy_' . $AuditListId . '_' . $Topic . '_' . $group . '_' . $FinishDateFlag;
			return $this->setRedis($keyName, $Domain);
		}
		/**
		 * 设置redis
		 */
		public function setRedis($keyName, $val)
		{
			return $this->redis->set($keyName, $val);
		}
		/**
		 * 设置易拍易卖首页redis
		 */
		public function setEbuySamllRedis($timeout, $auditListIds)
		{
			return $this->redis->setex('trans_index_ebuy_list', $timeout, $auditListIds);
		}
		/**
		 * 获取keys对应的值
		 */
		public function getKeysValue($keys)
		{
			if ($keys)
			{
				$data = $this->redis->mget($keys);
				return $data;
			}
			return FALSE;
		}
		/**
		 * 获取推荐域名的keys
		 */
		public function getBestAuditList($transtopicId, $topic, $day)
		{
			$keyName = $day? "bestDomain_" . $transtopicId ."_". $topic . "_*_" . $day :"bestDomain_" . $transtopicId ."_". $topic . "_*_*";
			return $this->getKeys($keyName);
		}
		/**
		 * 获取域名keys
		 */
		public function getAuditList($transTopic, $TopicId)
		{
			$keyName = 'trans_index_auditListId_' . $transTopic . "_" . $TopicId . '*';
			return $this->getKeys($keyName);
		}
		/**
		 * 获取单个值
		 */
		public function getRedis($keyName)
		{
			return $this->redis->get($keyName);
		}
		/**
		 * 设置专题拍卖详细页redis
		 */
		public function setTopicBigRedis($SysGroupOne, $AuditListId, $Topic, $FinishDateFlag, $Domain)
		{
			if($SysGroupOne > 0 && $SysGroupOne < 101)
				$group = 'number';
			elseif($SysGroupOne > 100 && $SysGroupOne < 201)
			$group = 'string';
			else
				$group = 'other';
		
			$keyName = 'trans_index_auditListId_topic_' . $AuditListId . '_' . $Topic . '_' . $group . '_' . $FinishDateFlag;
			return $this->setRedis($keyName, $Domain);
		}
		/**
		 * 设置易拍易卖首页redis
		 */
		public function setTopicSamllRedis($timeout, $auditListIds)
		{
			return $this->redis->setex('trans_index_topic_list', $timeout, $auditListIds);
		}
		
		/**
		 * 设置易拍易卖、专题拍卖的redis
		 */
		public function setSpecialTransRedis($transTopic, $auditListId, $topic, $group, $finishDateFlg, $domain)
		{
			$keyName = 'trans_index_auditListId_' . $transTopic . '_' . $auditListId . '_' . $topic . '_' . $group . '_' . $finishDateFlg;
			return $this->redis->set($keyName, $domain);
		}
		public function delEbuyListIndex()
		{
			return $this->redis->del('trans_index_ebuy_list');
		}
		public function delTopicListIndex()
		{
			return $this->redis->del('trans_index_topic_list');
		}

		/**
		 * 加入出价表、关注表交易结束时间更新队列
		 * @param int $auditListId
		 * @return int
		 */
		public function addFinishDateUpdateQueue($auditListId)
		{
			return $this->redis->sAdd('auction_finishdate_update',$auditListId);
		}
	}
?>
<?php
	namespace models\trans\redis;
	use core\RedisLib;
	class ShopIndex extends RedisLib 
	{
		private $redis;
		
		public function __construct()
		{
			$this->redis = parent::getInstance('trans');
		}
		/**
		 * 论坛店铺推荐域名，信息更新队列
		 */
		public function getShopDomainQueue()
		{
			return $this->redis->lRange('bbs:domain', 0, -1);
		}
		
		/**
		 * 论坛店铺推荐域名，信息更新队列
		 * @param unknown $EnameId
		 */
		public function setShopDomainQueue($EnameId)
		{
			return $this->redis->lPush("bbs:domain", $EnameId);
		}
		
		/**
		 * 获取论坛店铺，信息更新队列
		 */
		public function getShopQueue()
		{
			return $this->redis->lRange('bbs:shop', 0, -1);
		}
		
		/**
		 * 论坛店铺，信息更新队列
		 * @param unknown $EnameId
		 */
		public function setShopQueue($enameId)
		{
			return $this->redis->lPush("bbs:shop", $enameId);
		}
	}
?>
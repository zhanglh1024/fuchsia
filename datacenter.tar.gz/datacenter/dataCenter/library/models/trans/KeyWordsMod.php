<?php
namespace models\trans;

use core\ModBase;
class KeyWordsMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_keywords';
	}
	
	
	public function getAll()
	{
		$sql = "SELECT word FROM " .	$this->table ;
		return $this->select($sql,'',array());
	}
	
	
}
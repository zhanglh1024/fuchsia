<?php 
namespace models\trans;

use core\ModBase;
class BuyerRemind extends ModBase
{
	private $table;
	
	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_buyer_remind';
	}
	
	/**
	 * 批量插入数据
	 * @param array $data array(array('buyer','AuditListId'),array()...)
	 * @return boolean
	 */
	public function insert(array $data)
	{
		$type = '';
		$sqlArr = array();
		$value = array();
		foreach($data as $item)
		{
			array_push($value, $item['Buyer'], $item['AuditListId'], $item['DomainName'], $item['TransMoney'], $item['BuyerDeadline']);
			$sqlArr[] = '(?, ?, ?, ?, ?)';
			$type .= 'iisdi';
		}
		$sqlValue = implode(',', $sqlArr);
		$sql = "INSERT INTO {$this->table} (EnameId, AuditListId, DomainName, Money, EndTime) VALUES{$sqlValue}";
		return $this->add($sql, $type, $value);
	}
	
	/**
	 * 批量设置短信已发送
	 * @param int $id
	 * @return boolean
	 */
	public function batchSetIsSend($ids)
	{
		$count = count($ids);
		$sqlIds = '?';
		$type = 'i';
		for($i=1;$i<$count;$i++)
		{
			$sqlIds .= ',?';
			$type .= 'i';
		}
		$sql = "UPDATE {$this->table} SET isSend = ? WHERE id IN ($sqlIds)";
		array_unshift($ids, 2);
		return $this->update($sql, $type, $ids);
	}
	
	/**
	 * 设置短信已发送
	 * @param int $id
	 * @return boolean
	 */
	public function setIsSend($id, $status = 2)
	{
		$sql = "UPDATE {$this->table} SET isSend = ? WHERE id = ?";
		return $this->update($sql, 'ii', array($status, $id));
	}
	
	/**
	 * 获取未发送短信的数据
	 * @return array
	 */
	public function getNoSendSms()
	{
		$sql = "SELECT id, EnameId, DomainName, Money, EndTime, AuditListId FROM {$this->table} WHERE isSend = ? AND EndTime > ?";
		return $this->select($sql, 'ii', array(1, time()));
	}
	
	/**
	 * 获取单条信息
	 * @param unknown $id
	 * @return array
	 */
	public function getInfo($id)
	{
		$sql = "SELECT id, EnameId, DomainName, Money, EndTime, isSend, isCall FROM {$this->table} WHERE id = ?";
		return $this->select($sql, 'i', array($id));
	}
	
	/**
	 * 判断是否存在记录
	 * @param unknown $AuditListId
	 * @return int
	 */
	public function isHas($AuditListId)
	{
		$sql = "SELECT count(id) FROM {$this->table} WHERE AuditListId = ?";
		return $this->getOne($sql, 'i', array($AuditListId));
	}
}
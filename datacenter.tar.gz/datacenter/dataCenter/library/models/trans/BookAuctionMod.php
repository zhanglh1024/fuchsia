<?php
namespace models\trans;
use core\ModBase;

class BookAuctionMod extends ModBase
{

	private $table; 

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_book_auction';
	}

	/**
	 * 所有正在竞价的预订域名数目
	 */
	public function getBookingTransCnt($transStatus, $domainName, $domainTLD, $sysGroupOne, $sysGroupTwo, $domainLen, 
		$finishTime, $sort, $sldType, $auditListIdStr = '')
	{
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table . " WHERE TransStatus=$transStatus";
		
		if($auditListIdStr)
		{
			$sql .= " AND AuditListId IN ($auditListIdStr)";
		}
		
		if($domainName !== '')
		{
			switch($sldType)
			{
				case 1:
					$sql .= " AND DomainSLD LIKE '$domainName%'";
					break;
				case 2:
					$sql .= " AND DomainSLD LIKE '%$domainName%'";
					break;
				case 3:
					$sql .= " AND DomainSLD LIKE '%$domainName'";
					break;
				case 4:
					$sql .= " AND (DomainSLD LIKE '$domainName%' OR DomainSLD LIKE '%$domainName')";
					break;
				default:
					$sql .= " AND DomainSLD LIKE '%$domainName%'";
			}
		}
		$sql .= $domainTLD? (is_int($domainTLD)? " AND DomainTLD = $domainTLD": " AND DomainTLD IN ($domainTLD)"): '';
		if($sysGroupOne)
		{
			if(is_array($sysGroupOne))
			{
				$sql .= " AND SysGroupOne Between " . $sysGroupOne[0] . " AND " . $sysGroupOne[1];
			}
			else
			{
				$sql .= " AND SysGroupOne = " . $sysGroupOne;
			}
		}
		$sql .= $sysGroupTwo? " AND SysGroupTwo = " . $sysGroupTwo: '';
		$sql .= $domainLen? " AND DomainLen = $domainLen ": '';
		$sql .= $finishTime? " AND FinishDate 	LIKE '" . $finishTime . "%'": '';
		
		return $this->getOne($sql, '', array());
	}

	/**
	 * 所有正在竞价的预订域名列表
	 */
	public function getBookingTransList($transStatus, $domainName, $domainTLD, $sysGroupOne, $sysGroupTwo, $domainLen, 
		$finishTime, $sldType, $sort = "FinishDate DESC", $limit, $auditListIdStr = '', $inOrNot)
	{
		$sql = "SELECT DomainName, BidPrice, FinishDate, AuditListId,SimpleDec FROM " . $this->table .
			 " WHERE TransStatus=$transStatus";
		
		if($auditListIdStr)
		{
			if($inOrNot)
			{
				$sql .= " AND AuditListId IN ($auditListIdStr)";
			}
			else
			{
				$sql .= " AND AuditListId NOT IN ($auditListIdStr)";
			}
		}
		
		if($domainName !== '')
		{
			switch($sldType)
			{
				case 1:
					$sql .= " AND DomainSLD LIKE '$domainName%'";
					break;
				case 2:
					$sql .= " AND DomainSLD LIKE '%$domainName%'";
					break;
				case 3:
					$sql .= " AND DomainSLD LIKE '%$domainName'";
					break;
				case 4:
					$sql .= " AND (DomainSLD LIKE '$domainName%' OR DomainSLD LIKE '%$domainName')";
					break;
				default:
					$sql .= " AND DomainSLD LIKE '%$domainName%'";
			}
		}
		$sql .= $domainTLD? (is_int($domainTLD)? " AND DomainTLD = $domainTLD": " AND DomainTLD IN ($domainTLD)"): '';
		if($sysGroupOne)
		{
			if(is_array($sysGroupOne))
			{
				$sql .= " AND SysGroupOne Between " . $sysGroupOne[0] . " AND " . $sysGroupOne[1];
			}
			else
			{
				$sql .= " AND SysGroupOne = " . $sysGroupOne;
			}
		}
		$sql .= $sysGroupTwo? " AND SysGroupTwo = " . $sysGroupTwo: '';
		$sql .= $domainLen? " AND DomainLen = $domainLen ": '';
		$sql .= $finishTime? " AND FinishDate 	LIKE '" . $finishTime . "%'": '';
		
		if($sort)
		{
			$sql .= " ORDER BY $sort";
		}
		if($limit)
		{
			$sql .= " LIMIT $limit";
		}
		return $this->select($sql, '', array());
	}

	/**
	 * 根据数量判断此域名是否存在(关注域名)
	 *
	 * @param int $auditListId        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function isDomainExist($auditListId)
	{
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table . " WHERE AuditListId=?";
		return $this->getOne($sql, 'i', array(
				$auditListId
		));
	}

	/**
	 * 获取预订表记录
	 *
	 * @param int $auditListId        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getTransAuctionInfo($auditListId)
	{
		$sql = "SELECT AuditListId,DomainName,Seller,Buyer,TransType,FinishDate,TransStatus,BidCount,BidPrice,AgentBidPrice,AskingPrice,DomainSLD,SimpleDec,CreateDate,NickName FROM " .
			 $this->table . " WHERE AuditListId=?";
		return $this->getRow($sql, 'i', array(
				$auditListId
		));
	}

	public function getTransInfoForBid($auditListId, $transStatus)
	{
		$date = date("Y-m-d H:i:s");
		$sql = "SELECT TransStatus,Seller,Buyer,AskingPrice,DomainName,TransType,NickName,BidPrice,AgentBidPrice,BuyerIP,BuyerOrderId,BidCount,FinishDate,CreateDate from " .
			 $this->table;
		$sql .= " WHERE AuditListId=? AND TransStatus =? AND FinishDate>? ";
		return $this->getRow($sql, 'iis', array(
				$auditListId,$transStatus,$date
		));
	}

	/**
	 * 更新BidCount
	 *
	 * @param int $auditListId        	
	 * @param int $bidCount        	
	 * @return boolean
	 */
	public function updateBidCount($auditListId, $bidCount)
	{
		$sql = "UPDATE " . $this->table . " SET BidCount=? WHERE AuditListId=?";
		return $this->update($sql, 'ii', array(
				$bidCount,$auditListId
		));
	}

	/**
	 * 更新价格
	 *
	 * @param int $auditListId        	
	 * @param int $oldBuyer        	
	 * @param float $oldBidPrice        	
	 * @param int $buyer        	
	 * @param string $nickName        	
	 * @param int $buyerOrderId        	
	 * @param float $bidPrice        	
	 * @param float $agentBidPrice        	
	 * @param string $newFinishDate        	
	 * @param string $oldAgentBidPrice        	
	 * @return boolean
	 */
	public function unLeaderUpdatePriceModel($auditListId, $oldBuyer, $oldBidPrice, $buyer, $nickName, $buyerOrderId, 
		$bidPrice, $agentBidPrice, $newFinishDate, $oldAgentBidPrice = false)
	{
		$buyerIP = \common\Common::getRequestIp();
		$rqTime = empty($_SERVER['REQUEST_TIME'])? time(): $_SERVER['REQUEST_TIME'];
		$lastBidDate = date("Y-m-d H:i:s", $rqTime);
		$sql = "UPDATE " . $this->table . " SET
			LastBidDate = ?,
			LastChangeDate =?,
			Buyer = ?,
			NickName =?,
			BuyerOrderId =?,
			BidPrice =?,
			AgentBidPrice =?,
			BidCount = BidCount+1,
			FinishDate = ?,
			BuyerIP = ? WHERE AuditListId=? AND Buyer=? AND BidPrice=? ";
		$sql .= $oldAgentBidPrice !== false ? " AND AgentBidPrice=? ": '';
		
		return $oldAgentBidPrice !== false ? $this->update($sql, 'ssisiddssiidd', 
			array(
					$lastBidDate,$lastBidDate,$buyer,$nickName,$buyerOrderId,$bidPrice,$agentBidPrice,$newFinishDate,
					$buyerIP,$auditListId,$oldBuyer,$oldBidPrice,$oldAgentBidPrice
			), TRUE): $this->update($sql, 'ssisiddssiid', 
			array(
					$lastBidDate,$lastBidDate,$buyer,$nickName,$buyerOrderId,$bidPrice,$agentBidPrice,$newFinishDate,
					$buyerIP,$auditListId,$oldBuyer,$oldBidPrice
			), TRUE);
	}

	/**
	 * 更新代理价
	 *
	 * @param int $auditListId        	
	 * @param int $buyer        	
	 * @param float $agentBidPrice        	
	 * @param int $buyerOrderId        	
	 * @param float $postPrice        	
	 * @return boolean
	 */
	public function updateAgentPrice($auditListId, $buyer, $agentBidPrice, $buyerOrderId, $postPrice)
	{
		$rqTime = empty($_SERVER['REQUEST_TIME'])? time(): $_SERVER['REQUEST_TIME'];
		$lastDate = date("Y-m-d H:i:s", $rqTime);
		$sql = 'UPDATE ' . $this->table . " SET AgentBidPrice=?,BuyerOrderId=? ";
		$sql .= " WHERE AuditListId=? AND Buyer=? AND AgentBidPrice=?";
		return $this->update($sql, 'diiid', array(
				$postPrice,$buyerOrderId,$auditListId,$buyer,$agentBidPrice
		), TRUE);
	}

	/**
	 * 获取交易列表
	 *
	 * @param unknown $auditListIds        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getTransListByIds($auditListIds)
	{
		$sql = "SELECT AuditListId,TransType,BidPrice, FinishDate, DomainName FROM " . $this->table .
			 " WHERE AuditListId IN ($auditListIds) ORDER BY FinishDate ASC";
		return $this->select($sql, '', array());
	}

	/**
	 * 获取交易信息
	 *
	 * @param int $auditListId        	
	 */
	public function getAuctionInfoByAuditListId($auditListId)
	{
		$sql = "SELECT TransStatus,Seller,Buyer,AskingPrice,DomainName,NickName,BidPrice,AgentBidPrice,BuyerIP,BuyerOrderId,BidCount,FinishDate,TransType, TransTopic, SimpleDec " .
			 " FROM " . $this->table . " WHERE AuditListId=?" . " ORDER BY FinishDate ASC";
		return $this->getRow($sql, 'i', array(
				$auditListId
		));
	}

	/**
	 * 交易表的预订竞价域名信息
	 *
	 * @param string $auditListIdsStr        	
	 * @param int $status        	
	 * @param int $num        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getAuctionInfoByAuditListIds($auditListIdsStr, $status, $num)
	{
		$time = date('Y-m-d H:i:s');
		$sql = "select AuditListId,DomainName,BidPrice,FinishDate,Buyer from " . $this->table .
			 " where AuditListId in ( $auditListIdsStr ) AND TransStatus = ? AND AuditListId<>? AND FinishDate > ? limit $num";
		return $this->select($sql, 'iis', array(
				$status,0,$time
		));
	}

	/**
	 * 我参与预订数量
	 *
	 * @param unknown $auditListIdsStr        	
	 * @param unknown $status        	
	 */
	public function getMyBookTransCount($auditListIdsStr, $status)
	{
		$time = date('Y-m-d H:i:s');
		$sql = "SELECT COUNT(*) FROM " . $this->table .
			 " WHERE AuditListId IN ($auditListIdsStr) AND TransStatus=? AND AuditListId<>? AND FinishDate > ?";
		return $this->getOne($sql, 'iis', array(
				$status,0,$time
		));
	}

	/**
	 * 预订竞价的域名数量
	 */
	public function getBookTransCount()
	{
		$time = date('Y-m-d H:i:s');
		$sql = "select count(*) from " . $this->table . " where  TransStatus=? and FinishDate > ?";
		return $this->getOne($sql, 'is', array(
				1,$time
		));
	}
}

?>
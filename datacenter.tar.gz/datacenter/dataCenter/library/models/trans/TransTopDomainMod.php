<?php
namespace models\trans;

use core\ModBase;
class TransTopDomainMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_top_domain';
	}

	/**
	 * 获取白金一口价交易的白金Id
	 * 
	 * @param unknown $auditListId        	
	 * @param unknown $enameId        	
	 * @return string
	 */
	public function getTopBuyNowId($auditListId, $enameId)
	{
		$sql = "SELECT TopDomainId FROM " . $this->table . " WHERE AuditListId=? AND EnameId=?";
		return $this->getOne($sql, 'ii', array($auditListId,$enameId));
	}
	
	/**
	 * 白金一口价交易结束
	 * @param unknown $topId
	 * @return number|boolean
	 */
	public function cancelTopBuyNow($topId)
	{
		$sql = "UPDATE ".$this->table." SET AuditListId=? WHERE TopDomainId=?";
		return $this->update($sql, 'ii', array(0,$topId));
	}
}
?>
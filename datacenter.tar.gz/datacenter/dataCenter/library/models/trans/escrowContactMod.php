<?php
namespace models\trans;

use core\ModBase;
class escrowContactMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'escrow_contact';
	}

	/**
	 * 添加买家卖家联系信息
	 * 
	 * @param array $param        	
	 * @param int $esid        	
	 */
	public function addContact($parm, $esid)
	{
		$userName = $parm['userName'];
		$email = $parm['contactus']['email'];
		$mobile = $parm['contactus']['telPhone'];
		$telphone = $parm['contactus']['phone'];
		$qq = $parm['contactus']['qq'];
		
		$opposite_email = $parm['opposite']['mail'];
		$opposite_name = $parm['opposite']['linkman'];
		$opposite_mobile = $parm['opposite']['mobile'];
		$opposite_id = $parm['opposite']['enameId'];
		$opposite_telphone = $parm['opposite']['phone'];
		$opposite_qq = $parm['opposite']['qq'];
		$sql = "insert into " . $this->table .
			 "(esid,name,mobile,email,telphone,qq,opposite_id,opposite_name,opposite_mobile,opposite_email,opposite_telphone,opposite_qq) values(?,?,?,?,?,?,?,?,?,?,?,?)";
		return $this->add($sql, 'isssssisssss', 
			array($esid,$userName,$mobile,$email,$telphone,$qq,$opposite_id,$opposite_name,$opposite_mobile,
				$opposite_email,$opposite_telphone,$opposite_qq));
	}
	
	/**
	 * 获取买卖家联系方式
	 * @param unknown $esid
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getContact($esid)
	{
		$sql = "SELECT name, mobile, email, telphone, qq, opposite_id, opposite_name, opposite_mobile, opposite_email, opposite_telphone, opposite_qq FROM ".$this->table. " WHERE esid=?";
		return $this->getRow($sql, 'i', array($esid));
	}
}

?>
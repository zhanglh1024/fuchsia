<?php
namespace models\trans;

use core\ModBase;
class KeyWordsAuditMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_keywords_audit';
	}
	
	
	public function sadd($enameId,$shopUrl,$shopName,$shopAnnounce,$link_id,$type)
	{
		$sql ="INSERT INTO trans_keywords_audit(enameId,shopLogUrl,shopName,shopAnnounce,link_id,type,createTime,auditTime) VALUES(?,?,?,?,?,?,?,?)";
		return $this->add($sql, 'isssiiii', array($enameId,$shopUrl,$shopName,$shopAnnounce,$link_id,$type,time(),time()));
	}
	
	public function getAuditCount($enameId ,$link_id)
	{
		$sql = " SELECT COUNT(*) FROM ". $this->table." WHERE enameId =? AND link_id=? AND type=1 ";
		return $this->getOne($sql,'ii',array($enameId ,$link_id));
	}
	
	public function updateAuditInfo($enameId, $shopLogUrl, $shopName, $shopAnnounce, $link_id, $type)
	{
		$sql = " UPDATE " . $this->table . " SET status= 0,shopLogUrl=?,shopName=?,shopAnnounce=? WHERE enameId =? AND link_id=? AND type=1 ";
	  return $this->update($sql, 'sssii', array($shopLogUrl, $shopName, $shopAnnounce,$enameId,$link_id));
	}
	
	
}
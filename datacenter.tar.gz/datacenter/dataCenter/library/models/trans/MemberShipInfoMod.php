<?php
namespace models\trans;

use core\ModBase;
class MemberShipInfoMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_membership_info';
	}

	/**
	 * 获取用户信誉综合表信息
	 * 
	 * @param unknown_type $enameId        	
	 */
	public function getMembershipInfo($enameId)
	{
		$sql = "SELECT  ContactPhone, ContactQQ, RegDate,ContactEmail, ";
		$sql .= "BuyerGoodLevel, BuyerMiddleLevel, BuyerBadLevel, SellerGoodLevel, SellerMiddleLevel, SellerBadLevel,ContactWeixin FROM ";
		$sql .= $this->table . " WHERE EnameId=?";
		return $this->getRow($sql, 'i', array($enameId));
	}

	/**
	 * 获取用户信誉
	 * 
	 * @author Qxh
	 * @param unknown_type $enameId        	
	 */
	public function getUserLevel($enameId)
	{
		$sql = "SELECT EnameId,SellerGoodLevel,SellerMiddleLevel,SellerBadLevel,BuyerGoodLevel,BuyerMiddleLevel,BuyerBadLevel FROM " .
			 $this->table . " WHERE EnameId =? ";
		return $this->getRow($sql, 'i', array($enameId));
	}

	/**
	 * 用户信息更新
	 * 
	 * @param unknown_type $enameId        	
	 * @param unknown_type $email        	
	 * @param unknown_type $qq        	
	 * @param unknown_type $phone        	
	 * @param unknown_type $msn        	
	 * @param unknown_type $address        	
	 */
	public function updateMembershipInfo($enameId, $email, $qq, $phone, $weixin)
	{
		$sql = "UPDATE " . $this->table .
			 " SET ContactEmail=?, ContactPhone=?,ContactQQ=? ,ContactWeixin=? where EnameId=?";
		return $this->update($sql, 'ssssi', array($email,$phone,$qq,$weixin,$enameId));
	}

	/**
	 * 获取用户数目（来检查用户是否已经创建了店铺）
	 * 
	 * @param int $enameId        	
	 */
	public function getUserCnt($enameId)
	{
		$sql = "SELECT COUNT(MemberShipInfoId) FROM " . $this->table . " WHERE EnameId=?";
		return $this->getOne($sql, 'i', array($enameId));
	}

	/**
	 * 初始化用户信息（店铺创建时）
	 * @param int $enameId
	 * @param aray $rate
	 * @param string $email
	 * @param string $phone
	 * @param string $msn
	 * @param string $qq
	 * @param string $address
	 * @return boolean
	 */
	public function createUser($enameId, $rate, $email = '', $phone = '', $msn = '', $qq = '', $address = '')
	{
		$now = date('Y-m-d H:i:s');
		$sql = "INSERT INTO " . $this->table;
		$sql .= " (EnameId, RegDate, ContactEmail, ContactPhone, ContactMsn, ContactQQ, ContactAddress, ";
		$sql .= "BuyerGoodLevel, BuyerMiddleLevel, BuyerBadLevel, SellerGoodLevel, SellerMiddleLevel, SellerBadLevel) ";
		$sql .= " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
		return $this->add($sql, 'issssssiiiiii', 
			array($enameId,$now,$email,$phone,$msn,$qq,$address,$rate['BuyerGoodLevel'],$rate['BuyerMiddleLevel'],
				$rate['BuyerBadLevel'],$rate['SellerGoodLevel'],$rate['SellerMiddleLevel'],$rate['SellerBadLevel']));
	}
}
?>
<?php
namespace models\trans;

use core\ModBase;
class CustomerShopRateMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_customer_shop_rate';
	}

	/**
	 * 用来判断是否已经写入过评价表
	 *
	 * @param unknown_type $auditListId        	
	 */
	public function getCntByAuditListId($auditListId)
	{
		$sql = "SELECT COUNT(CustomerShopRateId) FROM " . $this->table . " WHERE AuditListId=?";
		
		return $this->getOne($sql, 'i', array($auditListId));
	}

	/**
	 * 结束的交易写入待评价列表
	 *
	 * @param unknown_type $buyer        	
	 * @param unknown_type $seller        	
	 * @param unknown_type $auditListId        	
	 * @param unknown_type $transStatus        	
	 * @param unknown_type $domainName        	
	 * @param unknown_type $price        	
	 */
	public function addTransForEvaluate($buyer, $seller, $auditListId, $transStatus, $domainName, $price, $nickName)
	{
		$sql = "INSERT INTO " . $this->table .
			 " (Seller, Buyer, NickName, BuyerRateLevel, SellerRateLevel, AuditListId, Status, DomainName, Price, CreateDate) VALUES " .
			 " (?, ?, ?, ?, ?, ?, ?, ?,?, ?) ";
		$now = date('Y-m-d H:i:s');
		return $this->add($sql, 'iisiiiisds', 
			array($seller,$buyer,$nickName,3,3,$auditListId,$transStatus,$domainName,$price,$now));
	}

	/**
	 * 获取买家评价总数
	 *
	 * @param int $enameId        	
	 */
	public function getBuyerRateCnt($enameId)
	{
		$sql = "SELECT COUNT(CustomerShopRateId) AS Count, SellerRateLevel FROM " . $this->table .
			 " WHERE Buyer=? AND SellerCommentDate<>'0000-00-00 00:00:00' AND SellerRateLevel in (-1,0,1) GROUP BY SellerRateLevel";
		return $this->select($sql, 'i', array($enameId));
	}

	/**
	 * 获取卖家评价总数
	 * 
	 * @param unknown $enameId        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getSellerRateCnt($enameId)
	{
		$sql = "SELECT COUNT(CustomerShopRateId) AS Count, BuyerRateLevel FROM " . $this->table .
			 " WHERE Seller=? AND BuyerCommentDate<>'0000-00-00 00:00:00' AND BuyerRateLevel in (-1,0,1) GROUP BY BuyerRateLevel";
		return $this->select($sql, 'i', array($enameId));
	}
}
?>
<?php
namespace models\trans;

use core\ModBase;
class BookBidRecordMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_book_bid_record';
	}

	/**
	 * 取得记录的出价昵称
	 * 
	 * @param int $auditListId        	
	 * @param int $enameId        	
	 * @return Ambigous <boolean, mixed>
	 */
	public function getNickNameOfRecord($auditListId, $enameId)
	{
		$sql = "SELECT NickName FROM " . $this->table . " WHERE AuditListId =? AND Bider = ?";
		return $this->getOne($sql, 'ii', array($auditListId,$enameId));
	}

	/**
	 * 获取个数
	 * 
	 * @param int $auditListId        	
	 * @return Ambigous <boolean, mixed>
	 */
	public function getBidRecordCount($auditListId)
	{
		$sql = "SELECT COUNT(BidRecordId) FROM " . $this->table . " WHERE AuditListId=?";
		return $this->getOne($sql, 'i', array($auditListId));
	}

	/**
	 * 出价表 设置 该域名最高出价为0
	 * 
	 * @param int $auditListId        	
	 * @return boolean
	 */
	public function setDisplayStatusOff($auditListId)
	{
		$sql = "UPDATE " . $this->table . " SET DisplayStatus =? WHERE AuditListId =?";
		return $this->update($sql, 'ii', array(0,$auditListId));
	}

	/**
	 * 出价表 设置 该域名最高出价为0
	 * 
	 * @param int $auditListId        	
	 * @param int $bider        	
	 * @return boolean
	 */
	public function setFlagOff($auditListId, $bider)
	{
		$sql = "UPDATE " . $this->table . " SET Flag = ? WHERE AuditListId =? AND Bider = ?";
		return $this->update($sql, 'iii', array(0,$auditListId,$bider));
	}
	/**
	 * 添加记录
	 * @param int $auditListId
	 * @param string $domainName
	 * @param int $bider
	 * @param string $nickName
	 * @param float $bidPrice
	 * @param int $isAgentPrice
	 * @param datetime $bidDate
	 * @param int $transType
	 * @param int $displayStatus
	 * @param int $flag
	 * @param string $ip
	 * @param datetime $finishDate
	 * @param int $seller
	 * @return boolean
	 */
	public function addBidRecord($auditListId, $domainName, $bider, $nickName, $bidPrice, $isAgentPrice, $bidDate, 
		$transType, $displayStatus, $flag, $ip, $finishDate, $seller)
	{
		$sql = 'INSERT INTO ' . $this->table . "
			(	AuditListId,DomainName,Bider,NickName,
				BidPrice,IsAgentPrice,BidDate,Seller,TransType,
				DisplayStatus,Flag,IP,FinishDate
			)
			values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		return $this->add($sql, 'isisdisiiiiss', 
			array($auditListId,$domainName,$bider,$nickName,$bidPrice,$isAgentPrice,$bidDate,$seller,$transType,
				$displayStatus,$flag,$ip,$finishDate));
	}
	
	/**
	 * 获取出价记录
	 * @param int $auditListId
	 * @param int $offset
	 * @param int $pageSize
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getBidRecord($auditListId, $offset,$pageSize)
	{
		$sql = "SELECT BidRecordId, Bider, NickName, BidPrice, IsAgentPrice, BidDate FROM ".$this->table." WHERE AuditListId =?";
		$sql .= " ORDER BY BidRecordId DESC LIMIT ?,?";
		
		return $this->select($sql, 'iii', array($auditListId,$offset,$pageSize));
	}
}
?>
<?php
namespace models\trans;
use core\ModBase;
class TopicConditionMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_topic_condition';
	}

	public function getCondition($transTopic, $conditionType, $topicId)
	{
		$sql = "SELECT TopicId, GroupOne, GroupTwo, DomainTld, DomainLen, SkipWords  FROM " . $this->table .
			 " WHERE TransTopic=?  AND TopicType=? AND Status=?";
		$sql .= $topicId? " AND TopicId=?" :"";
		$sql .=" ORDER BY Sort DESC, Tid DESC";
		return $topicId? $this->select($sql, 'iiii', array($transTopic,$conditionType,1,$topicId)) :$this->select($sql, 
			'iii', array($transTopic,$conditionType,1));
	}
	
	public function getTopicCondition($transTopic, $topicId)
	{
		$sql = "SELECT TopicId, GroupOne, GroupTwo, DomainTld, DomainLen, SkipWords  FROM ".$this->table.
		" WHERE TransTopic=? AND TopicId=? AND TopicType=? AND Status=?";
		$sql .= " ORDER BY Sort DESC";
		return $this->select($sql, 'iiii', array($transTopic,$topicId,2,1));
	}
}
?>
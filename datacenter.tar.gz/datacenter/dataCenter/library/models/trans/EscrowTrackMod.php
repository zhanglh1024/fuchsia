<?php
namespace models\trans;

use core\ModBase;
class EscrowTrackMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'escrow_track';
	}

	/**
	 * 添加操作记录
	 * 
	 * @param unknown $esid        	
	 * @param unknown $remark        	
	 * @param unknown $distribution        	
	 * @param unknown $handler        	
	 * @param number $status        	
	 * @return boolean
	 */
	public function addLog($esid, $remark, $distribution, $handler, $status = 1)
	{
		$date = time();
		$sql = "INSERT INTO " . $this->table .
			 "(esid, remark, distribution, handler, createtime, showstatus, status) VALUES";
		$sql .= "(?,?,?,?,?,?,?)";
		return $this->add($sql, 'isssiii', array($esid,$remark,$distribution,$handler,$date,1,$status));
	}

	public function getEscrowLog($esid)
	{
		$sql = "SELECT remark AS Remark, distribution AS Distribution, status, handler AS Handler, createtime AS CreateTime FROM " .
			 $this->table . " WHERE esid=? and showstatus=? and status > ? order by createtime desc";
		return $this->select($sql, 'iii', array($esid,1,1));
	}
}
?>
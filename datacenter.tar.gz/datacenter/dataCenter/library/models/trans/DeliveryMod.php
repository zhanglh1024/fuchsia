<?php 
namespace models\trans;

use core\ModBase;
class DeliveryMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_delivery';
	}

	/**
	 * 获取卖家近30天交易成交数量
	 */
	public function getAuctionCnt($seller, $status = FALSE, $finishDate)
	{
		$types = '';
		$data = array();
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table . " WHERE Seller=?";
		$types .= 'i';
		$data[] = $seller;
		if($status)
		{
			$types .= 'i';
			$data[] = $status;
			$sql .= " AND DeliveryStatus=?";
		}
		if($finishDate)
		{
			$types .= 's';
			$data[] = $finishDate;
			$sql .= " AND DeliveryDateFlag<?";
		}
		return $this->getOne($sql, $types, $data);
	}

	public function checkDelivery($auditListId)
	{
		$sql = "select count(*) from " . $this->table . " where AuditListId = ?";
		return $this->getOne($sql, 'i', array($auditListId));
	}

	/**
	 * 插入交付表
	 *
	 * @param int $AuditListId        	
	 * @param int $TransType        	
	 * @param int $TransTopic        	
	 * @param string $SellerIP        	
	 * @param string $BuyerIP        	
	 * @param int $Seller        	
	 * @param int $Buyer        	
	 * @param string $DomainName        	
	 * @param int $DeliveryStatus        	
	 * @param float $ReservePrice        	
	 * @param datetime $SellerDate        	
	 * @param datetime $SellerDeadline        	
	 * @param int $SellerApply        	
	 * @param datetime $BuyerDate        	
	 * @param datetime $BuyerDeadline        	
	 * @param int $BuyerApply        	
	 * @param datetime $DeliveryDate        	
	 * @param int $CommentFlag        	
	 * @param float $TransMoney        	
	 * @param int $TransOrderId        	
	 * @param int $Poundage        	
	 * @param float $Penalty        	
	 * @param float $Compensation        	
	 * @param int $WithdrawType        	
	 * @param datetime $DeliveryDateFlag        	
	 * @param int $IsDomainInEname        	
	 * @param int $BuyerOrderId        	
	 * @param int $SellerOrderId        	
	 * @param datetime $DeadTime        	
	 * @return boolean
	 */
	public function addTransToDelivery($AuditListId, $TransType, $TransTopic, $SellerIP, $BuyerIP, $Seller, $Buyer, 
		$DomainName, $DeliveryStatus, $ReservePrice, $SellerDate, $SellerDeadline, $SellerApply, $BuyerDate, 
		$BuyerDeadline, $BuyerApply, $DeliveryDate, $CommentFlag, $TransMoney, $TransOrderId, $Poundage, $Penalty, 
		$Compensation, $WithdrawType, $DeliveryDateFlag, $IsDomainInEname, $BuyerOrderId, $SellerOrderId, $DeadTime)
	
	{
		$sql = "INSERT INTO " . $this->table;
		$sql .= "(	AuditListId , TransType , TransTopic , SellerIP , BuyerIP ,
				Seller , Buyer , DomainName ,DeliveryStatus , ReservePrice ,
				SellerDate , SellerDeadline , SellerApply , BuyerDate , BuyerDeadline ,
				BuyerApply , DeliveryDate , CommentFlag , TransMoney , TransOrderId ,
				Poundage , Penalty , Compensation , WithdrawType , DeliveryDateFlag ,
				IsDomainInEname,BuyerOrderId,SellerOrderId,DeadTime) ";
		$sql .= " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		return $this->add($sql, 'iiissiisidssissisidiiddisiiis', 
			array($AuditListId,$TransType,$TransTopic,$SellerIP,$BuyerIP,$Seller,$Buyer,$DomainName,$DeliveryStatus,
				$ReservePrice,$SellerDate,$SellerDeadline,$SellerApply,$BuyerDate,$BuyerDeadline,$BuyerApply,
				$DeliveryDate,$CommentFlag,$TransMoney,$TransOrderId,$Poundage,$Penalty,$Compensation,$WithdrawType,
				$DeliveryDateFlag,$IsDomainInEname,$BuyerOrderId,$SellerOrderId,$DeadTime));
	}

	/**
	 * 设置transOrderId
	 *
	 * @param int $auditListId        	
	 * @param int $transOrderId        	
	 * @return boolean
	 */
	public function setTransOrderId($auditListId, $transOrderId)
	{
		$sql = 'UPDATE ' . $this->table . " SET TransOrderId =? Where AuditListId=?";
		return $this->update($sql, 'ii', array($transOrderId,$auditListId));
	}

	/**
	 * 获取交付表内 过户的信息信息
	 *
	 * @param int $auditListId        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getTransferInfo($auditListId)
	{
		$sql = 'select AuditListId,Seller,Buyer,DomainName,TransType,TransOrderId,TransMoney,DeliveryDate,BuyerDeadline,SellerDeadline,DeliveryStatus,BuyerApply,BuyerApplyDay,SellerApply,SellerApplyDay from ' .
			 $this->table . " where AuditListId=?";
		return $this->getRow($sql, 'i', array($auditListId));
	}

	/**
	 * 设置交付状态
	 *
	 * @param int $auditListId        	
	 * @param int $deliveryStatus        	
	 * @return boolean
	 */
	public function setDeliveryStatus($auditListId, $deliveryStatus)
	{
		$now = date("Y-m-d H:i:s");
		$sql = 'UPDATE ' . $this->table . " SET DeliveryStatus =?, DeliveryDateFlag = ? WHERE AuditListId=?";
		return $this->update($sql, 'isi', array($deliveryStatus,$now,$auditListId));
	}

	/**
	 * 获得卖家交付记录
	 *
	 * @param int $enameId        	
	 * @param string $deliveryStatus        	
	 * @param int $transType        	
	 * @param int $offset        	
	 * @param int $pageSize        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getSellerDelivery($domain, $enameId, $deliveryStatus, $transType, $offset, $pageSize)
	{
		$sql = "SELECT AuditListId,DomainName,TransMoney,DeliveryStatus,SellerDeadline,DeliveryDate From " . $this->table .
			 " WHERE DeliveryStatus IN (" . $deliveryStatus . ") AND Seller =? AND TransType  in(" . $transType . ")";
		$sql .= $domain? " AND DomainName LIKE '%$domain%'" :'';
		$sql .= ' ORDER BY DeliveryDate DESC Limit ?,?';
		return $this->select($sql, 'iii', array($enameId,$offset,$pageSize));
	}

	/**
	 * 获得卖家交付记录数量
	 *
	 * @param int $enameId        	
	 * @param string $deliveryStatus        	
	 * @param int $transType        	
	 * @param int $offset        	
	 * @param int $pageSize        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getSellerDeliveryCount($domain, $enameId, $deliveryStatus, $transType)
	{
		$sql = "SELECT count(DeliveryId) From " . $this->table . " WHERE DeliveryStatus IN (" . $deliveryStatus .
			 ") AND Seller =? AND TransType  =?";
		$sql .= $domain? " AND DomainName LIKE '%$domain%'" :'';
		return $this->getOne($sql, 'ii', array($enameId,$transType));
	}

	/**
	 * 获得买家交付记录
	 *
	 * @param int $enameId        	
	 * @param string $deliveryStatus        	
	 * @param int $transType        	
	 * @param int $offset        	
	 * @param int $pageSize        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getBuyerDelivery($domain, $enameId, $deliveryStatus, $transType, $offset, $pageSize)
	{
		$sql = "SELECT AuditListId,DomainName,TransMoney,DeliveryStatus,BuyerDeadline,DeliveryDate From " . $this->table .
			 " WHERE DeliveryStatus IN (" . $deliveryStatus . ") AND Buyer =? AND TransType  in(" . $transType . ")";
		$sql .= $domain? " AND DomainName LIKE '%$domain%'" :'';
		$sql .= ' ORDER BY DeliveryDate DESC Limit ?,?';
		return $this->select($sql, 'iii', array($enameId,$offset,$pageSize));
	}

	/**
	 * 获得买家交付记录数量
	 *
	 * @param int $enameId        	
	 * @param string $deliveryStatus        	
	 * @param int $transType        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getBuyerDeliveryCount($domain, $enameId, $deliveryStatus, $transType)
	{
		$sql = "SELECT count(DeliveryId) From " . $this->table . " WHERE DeliveryStatus IN (" . $deliveryStatus .
			 ") AND Buyer =? AND TransType  =?";
		$sql .= $domain? " AND DomainName LIKE '%$domain%'" :'';
		return $this->getOne($sql, 'ii', array($enameId,$transType));
	}

	public function getSellerAuctionInfo($enameId, $id, $deliveryStatus)
	{
		$sql = "SELECT AuditListId,DomainName,TransType,TransMoney,DeliveryDate,Buyer,Seller,DeliveryStatus,BuyerApplyDay,SellerApplyDay,TransTopic,SellerApply,IsDomainInEname,BuyerApply,SellerDeadline,BuyerDeadline From " .
			 $this->table . " WHERE DeliveryStatus IN (" . $deliveryStatus . ") AND Seller =? and AuditListId=?";
		return $this->getRow($sql, 'ii', array($enameId,$id));
	}

	public function getBuyerAuctionInfo($enameId, $id, $deliveryStatus)
	{
		$sql = "SELECT AuditListId,DomainName,TransType,TransMoney,DeliveryDate,Buyer,Seller,DeliveryStatus,SellerApplyDay,BuyerApplyDay,TransTopic,BuyerApply,IsDomainInEname,SellerApply,BuyerDeadline,SellerDeadline From " .
			 $this->table . " WHERE DeliveryStatus IN (" . $deliveryStatus . ") AND Buyer =? and AuditListId=?";
		return $this->getRow($sql, 'ii', array($enameId,$id));
	}
	
	/**
	 * 获取可能需要提醒的数据
	 * @param int $transType
	 * @param unknown $deliveryStatus
	 * @param unknown $startTime
	 * @param unknown $endTime
	 * @return array
	 */
	public function getNeedSendSmsData($startTime, $endTime, $transType = 1, $deliveryStatus = 4)
	{
		$sql = "SELECT AuditListId,DomainName,TransMoney,Buyer,BuyerDeadline FROM {$this->table} WHERE TransType = ? AND DeliveryStatus = ? AND BuyerDeadline BETWEEN ? AND ?";
		return $this->select($sql, 'iiss', array($transType, $deliveryStatus, $startTime, $endTime));
	}
	
	/**
	 * 检测此条交易是否发送短信提醒
	 * @param int $enameId
	 * @param int $auditListId
	 * @return number
	 */
	public function checkNeedSendSms($enameId, $auditListId)
	{
		$sql = "SELECT count(*) FROM {$this->table} WHERE TransType = ? AND DeliveryStatus = ? AND AuditListId = ? AND Buyer = ?";
		return $this->getRow($sql, 'iiii', array(1, 4, $auditListId, $enameId));
	}
}
?>
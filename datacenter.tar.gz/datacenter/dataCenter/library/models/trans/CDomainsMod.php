<?php

namespace models\trans;

use core\ModBase;

class CDomainsMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('zc');
		$this->table = 'c_domains';
	}

	/**
	 * 获取最多$limit个众筹结束时间或售完时间小于等于$nowTime，尚未更新状态的域名
	 * @param integer $nowTime 当前时间戳
	 * @param integer $limit 获取记录上限
	 * @param integer $lastId 获取DomainsId大于此值的记录
	 * @return array|false
	 */
	public function getDomainsToEnd($nowTime, $limit, $lastId)
	{
		$sql = "SELECT DomainsId, Domain, Status, Remain, Seller FROM " . $this->table
				. " WHERE Status = ? AND DomainsId > ? AND (EndDate <= ? OR Remain = 0)"
				. " LIMIT ?";
		return $this->select($sql, 'iiii', array(
			2, $lastId, $nowTime, $limit
		));
	}

	/**
	 * 获取最多$limit个$today以前结束或售完，处于等待开奖状态，已有开奖Result，尚无得标用户的域名
	 * @param integer $today 今日00:00:00的时间戳
	 * @param integer $limit
	 * @param integer $lastId 获取DomainsId大于此值的记录
	 * @return array|false
	 */
	public function getDomainsForLottery($today, $limit, $lastId)
	{
		$sql = "SELECT DomainsId, Domain, EnameId, Seller, Money, Status, Result FROM " . $this->table
				. " WHERE Status = 3 AND DomainsId > ? AND EnameId = 0 AND Result != -1"
				. " AND SoldOutDate > 0 AND SoldOutDate < ? LIMIT ?";
		return $this->select($sql, 'iii', array(
			$lastId, $today, $limit
		));
	}

	/**
	 * 
	 * @param integer $domainsId
	 * @param integer $status 1:众筹未开始,2:众筹进行中,3:众筹结束等待开奖,4:众筹失败,5:众筹成功
	 * @param integer $winner 得标用户的EnameId
	 * @return boolean
	 */
	public function setDomainStatus($domainsId, $status, $winner = false)
	{
		$data = array($status);
		$sql = "UPDATE " . $this->table . " SET Status = ?";
		if ($winner)
		{
			$sql .= ", EnameId = ?";
			$data[] = $winner;
		}
		$sql .= " WHERE DomainsId = ?";
		$data[] = $domainsId;
		$typeStr = $winner ? 'iii' : 'ii';
		return $this->update($sql, $typeStr, $data);
	}
}

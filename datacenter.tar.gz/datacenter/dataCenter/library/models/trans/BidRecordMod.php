<?php
namespace models\trans;

use core\ModBase;
class BidRecordMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_bid_record';
	}

	public function getUserRecord($enameId, $offset, $pageSize, $type)
	{
		$sql = "SELECT AuditListId,TransType,DomainName,DisplayStatus,FinishDate,FinalPrice FROM " .
			 $this->table . " WHERE  Flag = ? AND Bider = ?";
		$now = date('Y-m-d H:i:s');
		if($type)
		{
			// 交易结束
			$sql .= " AND FinishDate <= ? ORDER BY FinishDate DESC";
		}
		else
		{
			// 交易进行中
			$sql .= " AND FinishDate > ? ORDER BY FinishDate ASC";
		}
		$sql .= " limit ?,?";
		return $this->select($sql, 'iisii', array(1,$enameId,$now,$offset,$pageSize));
	}
	public function getUserRecordCount($enameId,$type)
	{
		$sql = "SELECT count(AuditListId) FROM " .
			$this->table . " WHERE  Flag = ? AND Bider = ?";
		$now = date('Y-m-d H:i:s');
		if($type)
		{
			// 交易结束
			$sql .= " AND FinishDate <= ? ORDER BY FinishDate DESC";
		}
		else
		{
			// 交易进行中
			$sql .= " AND FinishDate > ? ORDER BY FinishDate ASC";
		}
		return $this->getOne($sql, 'iis', array(1,$enameId,$now));
	}
	/**
	 * 交易结束，相关固定字段值设置
	 */
	public function setAuctionFinish($auditListId, $buyer, $price)
	{
		$now = date("Y-m-d H:i:s");
		$sql = "UPDATE " . $this->table . " SET FinalPrice=?, Buyer=?, FinishDate=? WHERE AuditListId=?";
		
		return $this->update($sql, 'disi', array($price,$buyer,$now,$auditListId));
	}
	
	/**
	 *	getRecordNickName
	 *	取得记录的出价昵称
	 */
	public function getNickNameOfRecord($auditListId, $enameId)
	{
		$sql = "SELECT NickName FROM " . $this->table . " WHERE AuditListId =? AND Bider = ?";
		return $this->getOne($sql, 'ii', array($auditListId,$enameId));
	}
	
	/**
	 * 检查用户是否参与竞价
	 */
	public function checkIsBider($auditListId, $bider)
	{
		$sql = "SELECT COUNT(BidRecordId) FROM " . $this->table . " WHERE AuditListId=? AND Bider=?";
		
		return $this->getOne($sql,'ii',array($auditListId,$bider));
	}
	
	/**
	 * 获取之前的出价记录
	 */
	public function getBidRecord($auditListId, $offset,$pageSize)
	{
		$sql = "SELECT BidRecordId, Bider, NickName, BidPrice, IsAgentPrice, BidDate, DisplayStatus FROM " . $this->table . " WHERE AuditListId =?";
		$sql .= " ORDER BY BidRecordId DESC LIMIT ?,?";
		
		return $this->select($sql, 'iii', array($auditListId,$offset,$pageSize));
	}
	
	/**
	 * 出价表 设置 是否领先设置为0
	 * @param int $auditListId
	 * @return boolean
	 */
	public function setDisplayStatusOff($auditListId)
	{
		$sql = "UPDATE " . $this->table . " SET DisplayStatus = ? WHERE AuditListId =?";
		return $this->update($sql, 'ii', array(0,$auditListId));
	}
	
	/**
	 * 设置用户最后出价
	 * @param unknown $auditListId
	 * @param unknown $bider
	 * @return boolean
	 */
	public function setFlagOff($auditListId, $bider)
	{
		$sql = "UPDATE " . $this->table . " SET Flag = ? WHERE AuditListId = ? AND Bider = ?";
		return $this->update($sql, 'iii', array(0,$auditListId,$bider));
	}
	
	/**
	 * 添加出价信息
	 * @param int $auditListId
	 * @param string $domainName
	 * @param int $bider
	 * @param string $nickName
	 * @param float $bidPrice
	 * @param float $isAgentPrice
	 * @param string $bidDate
	 * @param int $transType
	 * @param int $displayStatus
	 * @param int $flag
	 * @param string $IP
	 * @param string $finishDate
	 * @param int $seller
	 * @return boolean
	 */
	public function addBidRecord($auditListId, $domainName, $bider, $nickName, $bidPrice, $isAgentPrice, $bidDate,
		$transType, $displayStatus, $flag, $IP, $finishDate, $seller)
	{
		$sql = 'INSERT INTO ' . $this->table . "
			(	AuditListId,DomainName,Bider,NickName,
				BidPrice,IsAgentPrice,BidDate,Seller,TransType,
				DisplayStatus,Flag,IP,FinishDate,source
			)
			values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		return $this->add($sql, 'isisdisiiiissi', array($auditListId,$domainName,$bider,$nickName,$bidPrice,$isAgentPrice,$bidDate,$seller,$transType,$displayStatus,$flag,$IP,$finishDate,1));
	}
	/**
	 * 更新交易时间
	 * @param int $auditListId
	 * @param datetime $FinishDate
	 * @return boolean
	 */
	public function setTransFinishDate($auditListId, $FinishDate)
	{
		$sql = "UPDATE " . $this->table . " SET FinishDate=? WHERE AuditListId=?";
		return $this->update($sql, 'si', array($FinishDate,$auditListId), TRUE);
	}
	
	/**
	 * 获取个数
	 * @param int $auditListId
	 * @return Ambigous <boolean, mixed>
	 */
	public function getBidRecordCount($auditListId)
	{
		$sql = "SELECT COUNT(BidRecordId) FROM " . $this->table . " WHERE AuditListId=?";
		return $this->getOne($sql, 'i', array($auditListId));
	}
	
	/**
	 * @param unknown $enameid
	 * @param unknown $id
	 * @return string
	 */
	public function isFirstBidByEnameid($enameid, $id)
	{
		$sql = "SELECT COUNT(BidRecordId) FROM {$this->table} WHERE Bider=? AND AuditListId=?";
		return $this->getOne($sql, 'ii', array($enameid,$id));
	}
}
?>
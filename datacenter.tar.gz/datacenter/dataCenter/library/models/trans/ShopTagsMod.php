<?php
namespace models\trans;
use core\ModBase;
class ShopTagsMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_shop_tags';
	}

	public function checkIsTagInit($enameId)
	{
		$sql = "select count(Id) from " . $this->table . " where EnameId = ?";

		return $this->getone($sql, 'i', array($enameId));
	}

	/**
	 * 添加标签
	 */
	public function addTag($enameId, $tagName, $value, $tagTransType, $displayType, $tagType, $sort = 0,
			$transType = '', $status = 1)
	{
		$now = time();
		$sql = "INSERT INTO " . $this->table . " (TagName, Value, Sort, TagTransType, DisplayType, EnameId, TagType, TransType, Status, CreateTime, UpdateTime)" . " VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		return $this->add($sql, 'siiiiiisiii', array($tagName, $value, $sort, $tagTransType, $displayType, $enameId,
				$tagType, $transType, $status, $now, 0));
	}
	
	/**
	 * 添加系统标签
	 */
	public function addSysTag($data)
	{
		$keys = implode(',', array_keys($data));
		$vals = array_values($data);
		
		$sql = 'INSERT INTO ' . $this->table . ' (' . $keys . ') VALUES (?,?,?,?,?,?,?,?,?,?,?)';
		
		return $this->add($sql, 'siiiiiisiii', $vals);
	}

	/**
	 * 获取用户有效标签
	 */
	public function getAllTagsByEnameId($enameId, $status, $offset, $pageSize)
	{
		$sql = "SELECT Id, TagName, Sort,TagType, Status,Value,TagTransType FROM " . $this->table;
		$sql .= " WHERE EnameId=? AND Status <>?";
		$sql .= " ORDER BY Sort DESC ";
		$sql .= " limit ?,?";
		return $this->select($sql, 'iiii', array($enameId, $status, $offset, $pageSize));
	}

	/**
	 * 获取标签信息
	 */
	public function getShopTag($enameId, $id, $status = '')
	{
		$sql = "SELECT Id, TagName, Value, TagType, TransType, Sort, TagTransType, DisplayType, Status, domaingroup, domainTLD FROM " . $this->table . " WHERE Id=? AND EnameId=?";
		$sql .= $status ? " AND Status IN ($status)" : '';
		return $this->getRow($sql, 'ii', array($id, $enameId));
	}

	/**
	 * 检查标签名是否存在
	 */
	public function checkTagName($enameId, $id, $tagName, $delStatus)
	{
		$sql = "SELECT COUNT(Id) FROM " . $this->table . " WHERE EnameId=? AND TagName=? AND Status<>?";
		$sql .= $id ? " AND Id<>?" : '';

		return $id ? $this->getOne($sql, 'isii', array($enameId, $tagName, $delStatus, $id)) : $this->getOne($sql, 'isi', array(
				$enameId, $tagName, $delStatus));
	}

	/**
	 * 修改标签
	 */
	public function setShopTag($args)
	{
		$sql = "UPDATE {$this->table} SET TagName=?,Status=?,TagTransType={$args['TagTransType']},";
		$data = array($args['tagName'],$args['status']);
		$type = 'si';
		
		// 排列方式
		if($args['displayType'])
		{
			$sql .= "DisplayType=?,";
			$data[] = $args['displayType'];
			$type .= 'i';
		}
		
		if($args['taytype'])
		{
			// 域名分类
			if($args['domaingroup'] !== FALSE)
			{
				$sql .= "domainGroup=?,";
				$data[] = $args['domaingroup'];
				$type .= 'i';
			}
			
			// 域名后缀
			if($args['domaintld'] !== FALSE)
			{
				$sql .= 'domainTld="' . $args['domaintld'] . '",';
			}
			
			// 系统标签类型
			$sql .= "TransType=?,";
		}
		else
		{
			// 自定义标签类型
			$sql .= "TagTransType=?,";
		}
		$data[] = $args['transtype'];
		$type .= 'i';
		
		// 更新时间
		$sql .="UpdateTime=" . time();
		
		//where条件
		$sql .= " WHERE Id=? AND EnameId=?";
		$data[] = $args['tagId'];
		$data[] = $args['enameid'];
		$type .= 'ii';
		
		return $this->update($sql, $type, $data);
	}

	/**
	 * 获取用户有效的标签值
	 */
	public function getTagValues($enameId, $delStatus)
	{
		$sql = "SELECT Value FROM " . $this->table . " WHERE EnameId=? AND Value>1 AND Status<>? ORDER BY Value ASC";
		return $this->select($sql, 'ii', array($enameId,$delStatus));
	}

	/**
	 * 删除标签
	 */
	public function delShopTag($enameId, $id, $delStatus)
	{
		$now = time();
		$sql = "UPDATE " . $this->table . " SET Status= ?, UpdateTime=? WHERE Id=? AND EnameId=?";
		
		return $this->update($sql, 'iiii', array($delStatus, $now, $id, $enameId));
	}

	/**
	 * 根据标签交易类型获取标签
	 */
	public function getShopTagsByUser($enameId, $tagTransType, $status, $num = 0)
	{
		$sql = "SELECT Id,TagName, Value FROM " . $this->table;
		$sql .= " WHERE EnameId=? AND Value<>? AND  Status<>? AND TagTransType =?";
		if($num)
		{
			$sql .= " limit ?";
		}
		return $num ? $this->select($sql, "iiiii", array($enameId, 0, $status, $tagTransType, $num)) : $this->select($sql, 'iiii', array(
				$enameId, 0, $status, $tagTransType));
	}

	/**
	 * 检查是该值是否存在
	 */
	public function checkDiyValue($enameId, $value, $status, $tagTransType)
	{
		$sql = "SELECT COUNT(*) FROM " . $this->table . " WHERE EnameId=? AND Value=? AND Status<>? AND TagTransType=?";
		return $this->getOne($sql, 'iiii', array($enameId, $value, $status, $tagTransType));
	}

	/**
	 * 获取有标签显示方式
	 */
	public function getDisplayByValue($enameId, $tagValue)
	{
		$sql = "SELECT DisplayType FROM " . $this->table . " WHERE EnameId=? AND Value=? AND Status=?";
		return $this->getOne($sql, 'iii', array($enameId, $tagValue, 1));
	}

	/**
	 * 获取有标签显示方式
	 */
	public function getDisplayByTransType($enameId, $transType)
	{
		$sql = "SELECT DisplayType FROM " . $this->table . " WHERE EnameId=? AND TagType=? AND TransType=? AND Status=?";
		return $this->getOne($sql, 'iiii', array($enameId, 2, $transType, 1));
	}
	
	/**
	 * 获取有标签显示方式
	 */
	public function getDisplayById($EnameId, $Id)
	{
		$sql = "SELECT DisplayType FROM ".$this->table." WHERE EnameId=? AND Id=? AND Status=1";
		return $this->getOne($sql, 'ii', array($EnameId, $Id));
	}

	/**
	 * 获取标签
	 */
	public function getShopTags($enameId, $status = '')
	{
		$sql = "SELECT Id, TagName, Value, TransType, TagTransType FROM " . $this->table . " WHERE EnameId=?";
		$sql .= $status ? " AND Status IN ($status)" : '';
		$sql .= " ORDER BY Sort DESC LIMIT 0, 20";
		return $this->select($sql, 'i', array($enameId));
	}

	/**
	 * 获取标签信息
	 */
	public function getShopTagByValue($enameId, $value, $status = '')
	{
		$sql = "SELECT Id, TagName, Value, TagType, TransType, Sort, TagTransType, DisplayType, Status FROM " . $this->table . " WHERE EnameId=? AND Value=?";
		$sql .= $status ? " AND Status IN ($status)" : '';

		return $this->getRow($sql, 'ii', array($enameId, $value));
	}

	/**
	 * 获取有Value的标签
	 */
	public function getShopTagsForSearch($enameId)
	{
		$sql = "SELECT Id, TagName, Value, TagType, TransType, Sort, TagTransType, DisplayType, Status,domaingroup,domainTLD FROM " . $this->table . " WHERE EnameId=? AND Status=? order by Sort Desc";
		return $this->select($sql, 'ii', array($enameId, 1));
	}

	/**
	 * 获取排序标签
	 */
	public function getShopTagsForSort($enameId, $ids, $status)
	{
		$sql = "SELECT Id FROM " . $this->table . " WHERE Id IN ($ids) AND EnameId=? AND Status<>? ORDER BY FIELD	(Id,$ids)";
		return $this->select($sql, 'ii', array($enameId, $status));
	}

	/**
	 * 设置标签排序
	 */
	public function setTagSort($enameId, $id, $sort)
	{
		$now = time();
		$sql = "UPDATE " . $this->table . " SET Sort= ?, UpdateTime=? WHERE Id=? AND EnameId=?";
		return $this->update($sql, 'iiii', array($sort, $now, $id, $enameId));
	}
	
	public function getShopTagsNew($args) 
	{
		$data = array();		//数据数组
		$type = '';				//数据类型
		
		$sql = "SELECT Id,TagName,Value,TransType,TagTransType,TagType,domainGroup,domainTld,DisplayType FROM {$this->table} WHERE EnameId=?";
		$data[] = $args->uid;
		$type   = 'i';
		
		//指定标签
		if($args->tag)
		{
			$sql .= " AND Id=?";
			$data[] = $args->tag;
			$type   .= 'i';
		}
		
		//指定交易类型
		if($args->transtype)
		{
			$noSys = $args->transtype == 5 ? 2 : 1;
			$sql .= " AND (TransType=? OR (TagType=1 AND TagTransType=?))";
			$data[] = $args->transtype;
			$data[] = $noSys;
			$type   .= 'ii';
		}
		
		//指定域名分类
		if($args->domaingroup)
		{
			$data[] = $args->domaingroup;
			$type .= 'i';
			list($rSql, $rValues) = $this->buildRelateGroupSql($args->domaingroup);
			$rSql = $rSql ? ' OR '.$rSql : '';
			$sql .= " AND (domainGroup=? OR domainGroup=0 {$rSql})";
			$data = array_merge($data, $rValues);
			$type .= str_repeat('i', count($rValues));
		}
		
		//指定后缀名
		if($args->domaintld)
		{			
			$sql .= " AND (";
			foreach($args->domaintld as $key=>$val)
			{
				$sql .= " domainTld='{$val}' OR";
			}
			$sql .= " domainTld='0' )";
		}
		
		$sql .= " AND Status=1 ORDER BY Sort DESC";
		return $this->select($sql, $type, $data);
	}


	/**
	 * 生成相关联分组的查询条件
	 * @param type $domainGroupId
	 * @return type
	 */
	public function buildRelateGroupSql($domainGroupId)
	{
		$sql = $values = array();
		list($cid, $pid) = \lib\trans\common\PublicLib::getRelateDomainGroup($domainGroupId);
		if($cid)
		{
			$count = count($cid);
			$sql[] = 'domainGroup in ('. implode(',', array_fill(0, $count, '?')).')';
			$values = $cid;
		}
		if($pid)
		{
			$sql[] = 'domainGroup = ?';
			$values[] = $pid;
		}
		$sqlStr = implode(' OR ', $sql);
		return array($sqlStr, $values);
	}


	/**
	 * 新的添加店铺标签
	 * @param unknown $args
	 */
	public function addShopTagNew($args) 
	{
		$keys = implode(',', array_keys($args));
		$vals = array_values($args);
		$fill = implode(',', array_pad(array(), count($vals), '?'));
		
		$sql = "INSERT INTO {$this->table}({$keys}) VALUES ($fill)";
		
		return $this->add($sql, 'isiiiiiisiiii', $vals);
	}
}
?>
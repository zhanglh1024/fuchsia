<?php
namespace models\trans;

use core\ModBase;
class AuditListMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_audit_list';
	}

	public function getAuditDomainList($enameId, $transTopic, $offset, $pageSize)
	{
		$sql = "SELECT DomainName, TransTopic, SubmitDate, AuditStatus, AuditListId FROM " . $this->table .
			 " WHERE Seller=? AND" . " TransTopic IN (" . $transTopic['ebuy'][0] . ", " . $transTopic['topicshow'][0] .
			 ", " . $transTopic['parity'][0] . ", " . $transTopic['nice'][0] . ", " . $transTopic['beach'][0] . ")" .
			 " AND DomainAuthStatus=? ";
		$sql .= " ORDER BY AuditListId DESC";
		$sql .= " limit ?,?";
		
		return $this->select($sql, 'iiii', array($enameId,1,$offset,$pageSize));
	}

	public function getAuditCount($enameId, $transTopic)
	{
		$sql = "SELECT  COUNT(AuditListId) FROM " . $this->table . " WHERE Seller=? AND" . " TransTopic IN (" .
			 $transTopic['ebuy'][0] . ", " . $transTopic['topicshow'][0] . ", " . $transTopic['parity'][0] . ", " .
			 $transTopic['nice'][0] . ", " . $transTopic['beach'][0] . ")" . " AND AuditStatus=? ";
		return $this->getOne($sql, 'ii', array($enameId,0));
	}

	public function isYourAuditDomain($enameId, $auditListId, $status, $transTopic)
	{
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table . " WHERE Seller=? AND AuditListId=? " .
			 " AND AuditStatus IN ($status) " . " AND DomainAuthStatus=? " . " AND TransTopic IN (" .
			 $transTopic['ebuy'][0] . ", " . $transTopic['topicshow'][0] . ", " . $transTopic['parity'][0] . ", " .
			 $transTopic['nice'][0] . ", " . $transTopic['beach'][0] . ")";
		
		return $this->getone($sql, 'iii', array($enameId,$auditListId,1));
	}

	/**
	 * 设置审核状态
	 *
	 * @param unknown_type $auditListId        	
	 * @param unknown_type $status        	
	 */
	public function setAuditStatus($auditListId, $status)
	{
		$sql = "UPDATE " . $this->table . " set AuditStatus=? where AuditListId=?";
		return $this->update($sql, 'ii', array($status,$auditListId));
	}

	public function getAuditDomainById($auditListId)
	{
		$sql = "SELECT AuditListId, IsEnameDomain, DomainName, Seller, SellerOrderId, AfterAudit, " .
			 "TLDIndex, DomainLength, Summary, Description, ForSaleLife, SellMethod, " .
			 "TransTopic, Topic, BidPrice, SubmitDate, SellerIP, ClassName, SysGroupOne, SysGroupTwo, " .
			 "DeadTime, Poundage, FinishDate FROM " . $this->table . " WHERE AuditListId=?";
		
		return $this->getRow($sql, 'i', array($auditListId));
	}

	/**
	 * 检查是否在等待审核列表
	 *
	 * @param int $seller        	
	 * @param string $domainName        	
	 * @param int $transTopic        	
	 * @param int $noAuditStatus        	
	 * @param int $authStatus        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getWaitAuditDomain($seller, $domainName, $transTopic, $noAuditStatus, $authStatus)
	{
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table .
			 " WHERE Seller=? AND DomainName=? AND TransTopic<>? AND AuditStatus=? AND DomainAuthStatus=?";
		return $this->getOne($sql, 'isiii', array($seller,$domainName,$transTopic,$noAuditStatus,$authStatus));
	}

	/**
	 * 发布交易入库
	 *
	 * @param array $data        	
	 */
	public function addAuditDomain($data)
	{
		$sql = "INSERT INTO " . $this->table .
			 " (DomainName, TLDIndex, Seller, SellMethod, BidPrice, TimeSlot, ForSaleLife, " .
			 " Auditer, AuditDate, AuditStatus, SubmitDate, Summary, Description, DomainLength, AfterAudit, Poundage, " .
			 " ClassName, SysGroupOne, SysGroupTwo, IsEnameDomain, TransTopic, Topic, DomainAuthStatus, SellerIP, " .
			 " DeadTime, FinishDate, SellerOrderId, Weight) VALUES " .
			 " (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		return $this->add($sql, 'ssiiiiississsiiiiiiiiiisssii', 
			array($data['domainName'],$data['TLDIndex'],$data['seller'],$data['transType'],$data['bidPrice'],
				$data['timeSlot'],$data['forSaleLife'],$data['auditer'],$data['auditDate'],$data['auditStatus'],
				$data['submitDate'],$data['summary'],$data['description'],$data['domainLength'],$data['afterAudit'],
				$data['poundage'],$data['className'],$data['sysGroupOne'],$data['sysGroupTwo'],$data['isEnameDomain'],
				$data['transTopic'],$data['topic'],$data['authStatus'],$data['sellerIP'],$data['deadTime'],
				$data['finishDate'],$data['sellerOrderId'],$data['weight']));
	}

	/**
	 * 获取提交的抢滩域名数量
	 * 
	 * @param int $transTopic        	
	 * @return Ambigous <boolean, string>
	 */
	public function getAuditNum($transTopic)
	{
		$sql = "SELECT COUNT(AuditListId) FROM " . $this->table . " WHERE TransTopic=?";
		$data = array($transTopic);
		return $this->getOne($sql, 'i', $data);
	}
}
?>
<?php
namespace models\trans;
use core\ModBase;

class ExpiredDomainMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans'); 
		$this->table = 'trans_expired_domain';
	}

	/**
	 * 获取推荐预订域名
	 */
	public function getRecommendBookDomain($expireDate, $offset, $pageSize)
	{
		$sql = "SELECT ExpiredDomainId, DomainName,DelDate FROM " . $this->table . " WHERE DelDate>?" .
			 " AND (Recommend>? AND Recommend < ?) ";
		$sql .= " ORDER BY ExpiredDomainId DESC";
		$sql .= " limit ?,?";
		return $this->select($sql, 'siiii', array(
				$expireDate,0,100,$offset,$pageSize
		));
	}

	/**
	 * 过期域名高级搜索
	 */
	public function getCnBookDomain($keyWord, $skipKeyWord, $position, $tldArr, $delDay, $sysGroupOne, $sysGroupTwo, 
		$DomainLen, $lengthRange, $offset, $pageSize, $orderSort)
	{
		$sql = "SELECT ExpiredDomainId, DomainName, DelDate FROM " . $this->table . " WHERE 1=1 ";
		
		// 关键字和位置
		if($keyWord !== '')
		{
			switch($position)
			{
				case 1:
					$sql .= " AND DomainName LIKE '%$keyWord%' ";
					$data[] = $keyWord;
					break;
				case 2:
					$sql .= " AND DomainName LIKE '$keyWord%' ";
					break;
				case 3:
					$tempdomain = explode('.', $keyWord);
					$sql .= " AND DomainName LIKE '%" . $tempdomain[0] . ".%'";
					break;
				case 4:
					$tempdomain = explode('.', $keyWord);
					$sql .= " AND (DomainName LIKE '$keyWord%' OR DomainName LIKE '%" . $tempdomain[0] . ".%')";
					break;
			}
		}
		
		// 排除关键字和位置
		if($skipKeyWord !== '')
		{
			switch($position)
			{
				case 1:
					$sql .= " AND DomainName NOT LIKE '%$skipKeyWord%' ";
					break;
				case 2:
					$sql .= " AND DomainName NOT LIKE '$skipKeyWord%' ";
					break;
				case 3:
					$tempdomain = explode('.', $skipKeyWord);
					$sql .= " AND DomainName NOT LIKE '%" . $tempdomain[0] . ".%'";
					break;
				case 4:
					$tempdomain = explode('.', $skipKeyWord);
					$sql .= " AND DomainName NOT LIKE '$skipKeyWord%' AND DomainName NOT LIKE '%" . $tempdomain[0] .
						 ".%'";
					break;
			}
		}
		
		// 域名后缀
		if(! empty($tldArr))
		{
			$tldInStr = "(" . implode(',', $tldArr) . ")";
			$sql .= " AND DomainLtd IN $tldInStr";
		}
		
		// 删除日期
		if($delDay)
		{
			$delDayStr = "(" . implode(',', $delDay) . ")";
			$sql .= " AND DelDate in $delDayStr";
		}
		else
		{
			$now = date("Y-m-d", strtotime("+1 day"));
			$sql .= " AND DelDate >= '$now'";
		}
		
		// sysGroupOne
		if($sysGroupOne)
		{
			if(is_array($sysGroupOne))
			{
				$sql .= " AND SysGroupOne Between " . $sysGroupOne[0] . " AND " . $sysGroupOne[1];
			}
			else
			{
				$sql .= " AND SysGroupOne = " . $sysGroupOne;
			}
		}
		// sysGroupTwo
		$sql .= $sysGroupTwo? " AND SysGroupTwo = " . $sysGroupTwo: '';
		// 域名长度
		if($lengthRange)
		{
			$sql .= " AND (DomainLength BETWEEN $lengthRange[0] AND $lengthRange[1])";
		}
		$sql .= $DomainLen? " AND DomainLength = " . $DomainLen: '';
		
		// 排列方式
		switch($orderSort)
		{
			case 1:
				$sql .= " ORDER BY ClassName ASC,DomainName ASC";
				break;
			case 2:
				$sql .= " ORDER BY ClassName ASC,DomainLength ASC";
				break;
			case 3:
				$sql .= " ORDER BY ClassName ASC,DomainLtd ASC";
				break;
			case 4:
				$sql .= " ORDER BY ClassName ASC,LastRegDate ASC";
				break;
			default:
				$sql .= " ORDER BY ClassName ASC,DomainLength ASC";
				break;
		}
		
		// 每页行数
		$sql .= " LIMIT $offset, $pageSize";
		return $this->select($sql, '', array());
	}

	/**
	 * 通过域名详细信息
	 */
	public function getBookDomainWithCmpTime($domainName, $cmpTime)
	{
		$sql = "SELECT ExpiredDomainId, DomainName,DelDate FROM " . $this->table . " WHERE DomainName=? AND DelDate>?";
		
		return $this->getRow($sql, 'ss', array(
				$domainName,$cmpTime
		));
	}

	/**
	 * 检查是否存在域名 搜索不到，请勿删除
	 * 
	 * @param string $domainName        	
	 * @param string $cmpTime        	
	 * @return string
	 */
	public function checkIsExitDomain($domainName, $cmpTime)
	{
		$sql = "SELECT COUNT(*) FROM " . $this->table . " WHERE DomainName=? ";
		$sql .= is_array($cmpTime)? " AND DelDate BETWEEN ? AND ?": " AND DelDate=?";
		
		return is_array($cmpTime)? $this->getOne($sql, 'sss', array(
				$domainName,$cmpTime[0],$cmpTime[1]
		)): $this->getOne($sql, 'ss', array(
				$domainName,$cmpTime
		));
	}

	/**
	 * 获取可以预订的域名的详细信息列表
	 * 
	 * @param int $domainId        	
	 * @param datetime $today        	
	 */
	public function getDomainDetailById($ids, $today)
	{
		$sql = "SELECT DomainName, DelDate, DomainLength, SysGroupOne, SysGroupTwo, DomainLtd FROM " . $this->table .
			 " WHERE ExpiredDomainId IN (" . $ids . ") AND DelDate>?";
		return $this->select($sql, 's', array(
				$today
		));
	}

	/**
	 * 获取推荐预订域名
	 */
	public function getRecCount($expireDate)
	{
		$sql = "select count(ExpiredDomainId) from {$this->table} where DelDate > ? and Recommend > ? and Recommend < ?";
		return $this->getOne($sql, 'sii', array(
				$expireDate,0,100
		));
	}
}
?>
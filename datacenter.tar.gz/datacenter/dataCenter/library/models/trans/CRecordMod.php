<?php

namespace models\trans;

use core\ModBase;

class CRecordMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('zc');
		$this->table = 'c_record';
	}

	/**
	 * 获取指定众筹DomainsId的OrderId列表
	 * @param integer $domainsId
	 * @return array|false
	 */
	public function getOrders($domainsId)
	{
		$sql = "SELECT RecordId, EnameId, OrderId FROM " . $this->table . " WHERE DomainsId = ? AND Status = 1 GROUP BY OrderId";
		return $this->select($sql, 'i', array($domainsId));
	}

	/**
	 * 为购买记录设置新的Status
	 * @param integer $domainsId DomainsId
	 * @param integer $orderId OrderId
	 * @param integer $status 状态,1:参与众筹 冻结用户金额/正在交易,2:众筹结束 扣除用户金额/交易结束,3:众筹失败 退还用户金额/流拍,4：众筹结束 扣除用户金额 中奖
	 * @return boolean
	 */
	public function setRecordStatusByOrderId($domainsId, $orderId, $status)
	{
		$sql = "UPDATE " . $this->table . " SET Status = ? WHERE DomainsId = ? AND OrderId = ?";
		return $this->update($sql, 'iii', array($status, $domainsId, $orderId));
	}

	/**
	 * 获取指定众筹DomainsId的参与用户列表
	 * @param integer $domainsId
	 * @return array|false
	 */
	public function getBuyerByDomainsId($domainsId)
	{
		$sql = "SELECT EnameId, OrderId FROM " . $this->table . " WHERE DomainsId = ? GROUP BY EnameId";
		return $this->select($sql, 'i', array($domainsId));
	}
	
	/**
	 * 获取指定用户对某个众筹的购买总数
	 * @param integer $domainsId
	 * @param integer $enameId
	 * @return integer|false
	 */
	public function getTotalAmountByEnameId($domainsId, $enameId)
	{
		$sql = "SELECT count(RecordId) FROM " . $this->table . " WHERE DomainsId = ? AND EnameId = ?";
		return $this->getOne($sql, 'ii', array($domainsId, $enameId));
	}

	/**
	 * 根据Result获取指定DomainsId的获奖记录
	 * @param integer $domainsId
	 * @param integer $result
	 * @return array|false
	 */
	public function getWinner($domainsId, $result)
	{
		$sql = "SELECT RecordId, EnameId, DomainsId, RandCode, Status FROM "
				. $this->table . " WHERE DomainsId = ? AND RandCode = ?";
		return $this->getRow($sql, 'ii', array($domainsId, $result));
	}

	/**
	 * 更新中奖状态
	 * @param integer $domainsId
	 * @param integer $winnerRecordId 中奖记录的RecordId
	 * @param integer $status 新的状态 4中奖，5未中奖
	 * @param boolean $isWinner true更新的是中奖记录,false更新的是未中奖记录
	 * @return boolean
	 */
	public function setStatusForLottery($domainsId, $winnerRecordId, $status, $isWinner=true)
	{
		if($isWinner)
		{
			$sql = "UPDATE " . $this->table ." SET Status = ? WHERE DomainsId = ? AND RecordId = ?";
		}
		else
		{
			$sql = "UPDATE " . $this->table ." SET Status = ? WHERE DomainsId = ? AND RecordId != ?";
		}
		return $this->update($sql, 'iii', array($status, $domainsId, $winnerRecordId));
	}
}

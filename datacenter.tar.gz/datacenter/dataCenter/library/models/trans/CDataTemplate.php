<?php
namespace models\trans;

use core\ModBase;
class CDataTemplate extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'custompage_data_template';
	}

	/**
	 * 统计客服处理模版的数量
	 *
	 * @param unknown $adminId        	
	 * @param unknown $status        	
	 * @param unknown $timeRange        	
	 * @return Ambigous <boolean, mixed>
	 */
	public function totalTemplate($status, $timeRange)
	{
		$data = array();
		$types = '';
		$sql = "select count(*) as num,Auditor from " . $this->table . " where ";
		if($status)
		{
			$sql .= " Status=?";
			$data[] = $status;
			$types .= 'i';
		}
		else
		{
			$sql .= " Status in(1,4)";
		}
		$sql .= "  and AuditTime between $timeRange[0] and $timeRange[1] ";
		$sql .= " group by Auditor";
		return $this->select($sql, $types, $data);
	}
}
?>
<?php
namespace models\trans;

use core\ModBase;
class AgentMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_agent';
	}

	/**
	 * 设置审核状态
	 *
	 * @param unknown_type $auditListId        	
	 * @param unknown_type $status        	
	 */
	public function setAuditStatus($auditListId, $status)
	{
		$sql = "UPDATE " . $this->table . " set Status=? where AuditListId=?";
		return $this->update($sql, 'ii', array($status,$auditListId));
	}
	/**
	 * 添加经纪表记录
	 * @param unknown $data
	 * @return boolean
	 */
	public function addAgentDomain($data)
	{
		$sql = "INSERT INTO " . $this->table .
			 " (AuditListId, DomainName, TransType, TransTopic, Seller, Poundage, Agent, Status)" .
			 " VALUES (?,?,?,?,?,?,?,?)";
		return $this->add($sql, 'isiiiiii', 
			array($data['auditListId'],$data['domainName'],$data['transType'],$data['transTopic'],$data['seller'],
				$data['poundage'],$data['agent'],$data['auditStatus']));
	}
}
?>
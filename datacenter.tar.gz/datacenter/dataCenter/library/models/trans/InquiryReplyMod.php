<?php
namespace models\trans;

use core\ModBase;
class InquiryReplyMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_inquiry_reply';
	}

	public function postInquiryOncePostModel($inquiryId, $enameId, $replyStatus)
	{
		$data = array();
		$types = '';
		$types .= 'ii';
		$data[] = $enameId;
		$data[] = $inquiryId;
		$sql = 'SELECT ReplyId,BuyerPrice FROM ' . $this->table .
			 " WHERE Buyer = ? and InquiryId = ? and ReplyStatus in ($replyStatus)";
		return $this->getRow($sql, $types, $data);
	}

	public function addInquiryReplyModel($inquiryId, $domainName, $replyStatus, $seller, $buyer, $nickName, 
		$inquiryPrice, $buyerPrice, $bidDate, $operateDate, $operateIp, $isDomainInEname, $poundage, $sellerDeadLine)
	{
		$sql = 'INSERT INTO ' . $this->table .
			 ' (InquiryId,DomainName,ReplyStatus,Seller,Buyer,NickName,InquiryPrice,BuyerPrice,BidDate,OperateDate,OperateIp,IsDomainInEname,Poundage,SellerDeadLine) VALUE ';
		$sql .= " (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		return $this->add($sql, 'isiiisddsssiii', 
			array($inquiryId,$domainName,$replyStatus,$seller,$buyer,$nickName,$inquiryPrice,$buyerPrice,$bidDate,
				$operateDate,$operateIp,$isDomainInEname,$poundage,$sellerDeadLine));
	}

	public function getSellerReplyList($domain, $enameId, $inquiryStatus, $offset, $pageSize)
	{
		$sql = "Select  ReplyId,DomainName,NickName,BuyerPrice,SellerPrice,ReplyStatus from " . $this->table .
			 "  where Seller = ? AND ReplyStatus in ($inquiryStatus) ";
		$sql .= $domain? " AND DomainName LIKE '%$domain%'" :'';
		$sql .= ' ORDER BY OperateDate DESC LIMIT ?,?';
		return $this->select($sql, 'iii', array($enameId,$offset,$pageSize));
	}

	public function getSellerReplyCount($domain, $enameId, $inquiryStatus)
	{
		$sql = "Select count(ReplyId) from " . $this->table . "  where Seller = ? AND ReplyStatus in ($inquiryStatus) ";
		$sql .= $domain? " AND DomainName LIKE '%$domain%'" :'';
		return $this->getOne($sql, 'i', array($enameId));
	}

	public function getBuyerReplyList($domain, $enameId, $inquiryStatus, $offset, $pageSize)
	{
		$sql = "select ReplyId,DomainName,Seller,BuyerPrice,SellerPrice,ReplyStatus from " . $this->table .
			 " where Buyer=? AND ReplyStatus in ($inquiryStatus)";
		$sql .= $domain? " AND DomainName LIKE '%$domain%'" :'';
		$sql .= ' ORDER BY OperateDate DESC LIMIT ?,?';
		return $this->select($sql, 'iii', array($enameId,$offset,$pageSize));
	}

	public function getBuyerReplyCount($domain, $enameId, $inquiryStatus)
	{
		$sql = "select count(ReplyId) from " . $this->table . " where Buyer=? and  ReplyStatus in ($inquiryStatus)";
		$sql .= $domain? " AND DomainName LIKE '%$domain%'" :'';
		return $this->getOne($sql, 'i', array($enameId));
	}

	public function getSellerInquiryInfo($enameId, $replyId, $inquiryStatus)
	{
		$sql = "select ReplyId,DomainName,IsDomainInEname,Seller,NickName,BuyerPrice,SellerPrice,ReplyStatus from " .
			 $this->table . " where ReplyId=? and Seller=? and ReplyStatus in ($inquiryStatus)";
		return $this->getRow($sql, 'ii', array($replyId,$enameId));
	}

	public function getBuyerInquiryInfo($enameId, $replyId, $inquiryStatus)
	{
		$sql = "select ReplyId,DomainName,IsDomainInEname,Seller,Buyer,BuyerPrice,SellerPrice,ReplyStatus from " .
			 $this->table . " where ReplyId=? and Buyer=? and  ReplyStatus in ($inquiryStatus)";
		return $this->getRow($sql, 'ii', array($replyId,$enameId));
	}

	public function getReplyPremissions($replyId, $enameId)
	{
		$sql = 'SELECT ReplyId,InquiryId,DomainName,BuyerOrderId,SellerOrderId,TransOrderId,Buyer,Seller,NickName,BuyerPrice,SellerPrice,InquiryPrice,IsDomainInEname,TransPrice,ReplyStatus,IsDomainInEname,OperateDate,Poundage,BuyerApply,BuyerApplyDay,SellerApply,SellerApplyDay,BuyerDeadLine,SellerDeadLine From ' .
			 $this->table . " WHERE ReplyId = ? and ( Seller = ? or Buyer = ? ) ";
		return $this->getRow($sql, 'iii', array($replyId,$enameId,$enameId));
	}

	public function checkSellerInquiryModel($agreeInquiryArray, $enameId, $inquiryId, $replyId)
	{
		$data = array();
		$types = '';
		$types .= 'iii';
		$data[] = $enameId;
		$data[] = $inquiryId;
		$data[] = $replyId;
		$agreeInquiry = implode(',', $agreeInquiryArray);
		$sql = 'SELECT count(ReplyId) FROM ' . $this->table .
			 " WHERE Seller = ? and InquiryId = ? and ReplyStatus in ($agreeInquiry) and ReplyId<>?";
		return $this->getOne($sql, $types, $data);
	}

	public function setSellerAgreePriceModel($replyId, $enameId, $replyStatus, $operateDate, $price, $sellerOrderId, 
		$inquiryReg)
	{
		$sql = 'UPDATE ' . $this->table .
			 " SET ReplyStatus=?,OperateDate=?,TransPrice=?,SellerOrderId=?,IsDomainInEname=? WHERE ReplyId=? and Seller=? ";
		return $this->update($sql, 'isdiiii', 
			array($replyStatus,$operateDate,$price,$sellerOrderId,$inquiryReg,$replyId,$enameId));
	}

	public function setBuyerPayAllPriceModel($replyId, $enameId, $replyStatus, $operateDate, $transOrderId)
	{
		$sql = 'UPDATE ' . $this->table .
			 " SET ReplyStatus=?,OperateDate=?,TransOrderId=?,SellerDeadLine=? WHERE ReplyId=? and Buyer=? ";
		
		return $this->update($sql, 'isiiii', 
			array($replyStatus,$operateDate,$transOrderId,strtotime('+10 days'),$replyId,$enameId));
	}

	public function setSellerReplyPriceModel($replyId, $enameId, $replyStatus, $price, $operateDate, $sellerRIO = 0)
	{
		if($sellerRIO)
		{
			$sql = 'UPDATE ' . $this->table .
				 " SET ReplyStatus = ? ,SellerPrice = ? ,OperateDate = ?, SellerOrderId = ? WHERE ReplyId = ? and Seller = ? ";
			return $this->update($sql, 'idsiii', array($replyStatus,$price,$operateDate,$sellerRIO,$replyId,$enameId));
		}
		else
		{
			$sql = 'UPDATE ' . $this->table .
				 " SET ReplyStatus = ? ,SellerPrice = ? ,OperateDate = ? WHERE ReplyId = ? and Seller = ? ";
			return $this->update($sql, 'idsii', array($replyStatus,$price,$operateDate,$replyId,$enameId));
		}
	}

	public function setBuyerReplyPriceModel($replyId, $enameId, $replyStatus, $price, $operateDate)
	{
		$sql = 'UPDATE ' . $this->table .
			 " SET ReplyStatus = ? ,BuyerPrice = ? ,OperateDate = ? WHERE ReplyId = ? and Buyer = ? ";
		return $this->update($sql, 'idsii', array($replyStatus,$price,$operateDate,$replyId,$enameId));
	}

	/**
	 * 卖家转经纪交易
	 */
	public function setSellerToEscrowModel($replyId, $enameId, $replyStatus, $operateDate)
	{
		$sql = 'UPDATE ' . $this->table . " SET ReplyStatus = ? ,OperateDate = ? WHERE ReplyId = ? and Seller = ? ";
		return $this->update($sql, 'isii', array($replyStatus,$operateDate,$replyId,$enameId));
	}

	/**
	 * 买家转经纪交易
	 */
	public function setBuyerToEscrowModel($replyId, $enameId, $replyStatus, $operateDate)
	{
		$sql = 'UPDATE ' . $this->table . " SET ReplyStatus = ? ,OperateDate = ? WHERE ReplyId = ? and Buyer = ? ";
		return $this->update($sql, 'isii', array($replyStatus,$operateDate,$replyId,$enameId));
	}

	public function setSellerRefuseInquiryModel($replyId, $enameId, $replyStatus, $operateDate, $sellerRefuseOrderId)
	{
		$sql = 'UPDATE ' . $this->table .
			 " SET ReplyStatus=?,OperateDate=?,SellerRefuseOrderId=? WHERE ReplyId=? and Seller=? ";
		return $this->update($sql, 'isiii', array($replyStatus,$operateDate,$sellerRefuseOrderId,$replyId,$enameId));
	}

	public function setBuyerRefuseInquiryModel($replyId, $enameId, $replyStatus, $operateDate)
	{
		$sql = 'UPDATE ' . $this->table . " SET ReplyStatus=?,OperateDate=? WHERE ReplyId=? and Buyer=? ";
		return $this->update($sql, 'isii', array($replyStatus,$operateDate,$replyId,$enameId));
	}

	public function setSellerRefusePriceModel($replyId, $enameId, $replyStatus, $operateDate)
	{
		$sql = 'UPDATE ' . $this->table . " SET ReplyStatus = ? ,OperateDate = ? WHERE ReplyId = ? and Seller = ? ";
		return $this->update($sql, 'isii', array($replyStatus,$operateDate,$replyId,$enameId));
	}

	public function setBuyerRefusePriceModel($replyId, $EnameId, $replyStatus, $operateDate)
	{
		$sql = 'UPDATE ' . $this->table . " SET ReplyStatus = ? ,OperateDate = ? WHERE ReplyId = ? and Buyer = ? ";
		return $this->update($sql, 'isii', array($replyStatus,$operateDate,$replyId,$EnameId));
	}

	public function setBuyerApplyModel($replyId, $EnameId, $applyStatus, $day, $operateDate)
	{
		$sql = 'UPDATE ' . $this->table .
			 " SET BuyerApply = ?, BuyerApplyDay = ? ,OperateDate = ? WHERE ReplyId = ? and Buyer = ? ";
		error_log($sql . '--' . $applyStatus . '--' . $day . "\n\r", 3, '/tmp/sf.log');
		return $this->update($sql, 'iisii', array($applyStatus,$day,$operateDate,$replyId,$EnameId));
	}

	public function setSellerApplyModel($replyId, $EnameId, $applyStatus, $day, $operateDate)
	{
		$sql = 'UPDATE ' . $this->table .
			 " SET SellerApply = ?, SellerApplyDay = ? ,OperateDate = ? WHERE ReplyId = ? and Seller = ? ";
		return $this->update($sql, 'iisii', array($applyStatus,$day,$operateDate,$replyId,$EnameId));
	}

	public function setBuyerDeadLineModel($replyId, $deadLine, $buyerApply=0)
	{
		$buyerApply=(int)$buyerApply;
		$sql = 'UPDATE ' . $this->table . " SET BuyerDeadLine = ?, BuyerApply = ?, BuyerApplyDay = ? WHERE ReplyId = ? ";
		return $this->update($sql, 'iiii', array($deadLine,$buyerApply,0,$replyId));
	}

	public function setSellerDeadLineModel($replyId, $deadLine, $sellerApply=0)
	{
		$sellerApply=(int)$sellerApply;
		$sql = 'UPDATE ' . $this->table .
			 " SET SellerDeadLine = ?, SellerApply = ?, SellerApplyDay = ? WHERE ReplyId = ? ";
		return $this->update($sql, 'iiii', array($deadLine,$sellerApply,0,$replyId));
	}

	/**
	 * 判断是否存在正在交易的询价
	 *
	 * @param int $id        	
	 * @param int $transStatus        	
	 * @return Ambigous <boolean, mixed>
	 */
	public function getIsTrandding($id, $transStatus)
	{
		$types = '';
		$data = array();
		$types .= 'i';
		$data[] = $id;
		$clause = implode(',', $transStatus);
		$sql = "select count(ReplyId) from " . $this->table . " where ReplyId=? and ReplyStatus in ($clause)";
		return $this->getOne($sql, $types, $data);
	}
} 
?>

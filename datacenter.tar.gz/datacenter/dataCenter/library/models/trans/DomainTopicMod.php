<?php
namespace models\trans;

use core\ModBase;
class DomainTopicMod extends ModBase
{
	private $table;
	
	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'trans_domain_topic';
	}
	
	/**
	 * 获取可用的专题(用在页面导航和专题页面)
	 */
	public function getVaildTopic($transTopic,$tld=0)
	{
		$sql = "SELECT TopicId, TopicName FROM ".$this->table.
		" WHERE IsVaild<>? AND TransTopic = ? ";
		if($tld)
		{
			$sql .=" and TopicId=?";
		}
		$sql .= " ORDER BY OrderSort DESC";
		return $tld ? $this->select($sql, 'iii', array(2,$transTopic,$tld)) : $this->select($sql, 'ii', array(2,$transTopic));
	}
	
	/**
	 * 获取可用的专题(用在发布)
	 */
	public function getVaildTopicForFb()
	{
		$now = date('Y-m-d H:i:s');
		$sql = "SELECT TopicId, TopicName FROM ".$this->table.
		" WHERE IsVaild=? AND Type=? AND EndDate>? AND TransTopic=? ORDER BY OrderSort DESC";
		return $this->select($sql, 'iisi', array(1,1,$now,3));
	}
}
?>
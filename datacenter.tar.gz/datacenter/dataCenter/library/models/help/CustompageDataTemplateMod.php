<?php

namespace models\help;

use core\ModBase;
class CustompageDataTemplateMod extends ModBase
{
	private $table;
	
	public function __construct()
	{
		parent::__construct('trans');
		$this->table = 'custompage_data_template';
	}
	
	/**
	 * 展示模版列表数量
	 */
	public function getTplCountByStatus()
	{
		$sql = 'SELECT count(*) FROM ' . $this->table." where Status=?";
		return $this->getOne($sql, 'i', array(2));
	}
}

<?php
namespace models\help\redis;

use core\RedisLib;
class TalkRedis extends RedisLib
{

	private $redis;

	public function __construct()
	{
		$this->redis = parent::getInstance('trans');
	}

	/**
	 * 设置聊天记录入库flag
	 *
	 * @param int $enameId        	
	 * @return boolean
	 */
	public function setTalkFlag($enameId)
	{
		$keyName = 'help:talk:' . $enameId;
		return $this->redis->setex($keyName, 30, 1)? TRUE :FALSE;
	}

	/**
	 * 获取聊天记录入库flag
	 *
	 * @param int $enameId        	
	 * @return boolean
	 */
	public function getTalkFlag($enameId)
	{
		$keyName = 'help:talk:' . $enameId;
		return $this->redis->get($keyName)?  :FALSE;
	}

	/**
	 * 释放聊天记录入库flag
	 *
	 * @param int $enameId        	
	 * @return boolean
	 */
	public function delTalkFlag($enameId)
	{
		$keyName = 'help:talk:' . $enameId;
		if($this->redis->exists($keyName))
		{
			return $this->redis->del($keyName);
		}
		return FALSE;
	}
}
?>
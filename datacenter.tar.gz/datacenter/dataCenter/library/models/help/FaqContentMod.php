<?php
namespace models\help;

use core\ModBase;
class FaqContentMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('help');
		$this->table = 'faq_content';
	}

	/**
	 *
	 * @param int $faqId        	
	 * @param int $isQuestion        	
	 * @return string
	 */
	public function getFaqContent($faqId, $isQuestion)
	{
		$types = '';
		$data = array();
		$types .= 'ii';
		$data[] = $faqId;
		$data[] = 0;
		$sql = "SELECT c_id, c_conid, c_title, c_content, c_common FROM " . $this->table .
			 " WHERE c_parentid =? AND c_status=? ";
		if(in_array($isQuestion, array(0,1)))
		{
			$isQue = $isQuestion;
			$sql .= " AND c_common = ?";
			$types .= 'i';
			$data[] = $isQue;
		}
		$sql .= " ORDER BY c_conid ASC";
		
		return $this->select($sql, $types, $data);
	}
}
?>
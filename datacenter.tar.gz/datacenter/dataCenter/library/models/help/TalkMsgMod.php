<?php
namespace models\help;
use core\ModBase;
class TalkMsgMod extends ModBase
{

	private $conf;
	private $table;

	public function __construct()
	{
		parent::__construct('help');
		$this->table = 'app_talkmsg';
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/help.ini', 'client');
	}

	public function getTalkList($enameId, $type, $pageSize, $id, $flag)
	{
		$sql = "SELECT Id, Role, Msg, CreateDate FROM " . $this->table . " WHERE EnameId=? AND Type=?  AND Status <> ? ";
		$sql .= $id ? ($flag ? " AND Id>?" : " AND Id<?") : '';
		$sql .= " ORDER BY Id DESC";
		$sql .= $id ? ($flag ? '' : " LIMIT ?") : " LIMIT ?";
		if($id)
		{
			if($flag)
			{
				return $this->select($sql, 'siii', array($enameId, $type, 9, $id));
			}
			else 
			{
				return $this->select($sql, 'siiii', array($enameId, $type, 9, $id, $pageSize));
			}
		}
		else 
		{
			return $this->select($sql, 'siii', array($enameId, $type, 9, $pageSize));
		}
	}

	public function setTalkRead($enameId)
	{
		$sql = "UPDATE " . $this->table . " SET Status=? WHERE EnameId=? AND Status=?";
		return $this->update($sql, 'isi', array(2, $enameId, 1));
	}

	public function getUnReadMsg($enameId, $type)
	{
		$sql = "SELECT COUNT(Id) as Num, Msg FROM " . $this->table . " WHERE EnameId=? AND Type=?  AND Status=?";
		$sql .= " ORDER BY Id Desc Limit 1";
		return $this->select($sql, 'sii', array($enameId, $type, 1), TRUE);
	}

	public function addTalk($enameId, $type, $msg, $role)
	{
		$sql = "INSERT INTO " . $this->table . " (EnameId, Type, Role, Msg, CreateDate, Status) VALUES (?,?,?,?,?,?)";
		\core\Log::write("$enameId,$type,$msg,$role====== add talk start addTalk=========", 'help', 'talk');
		return $this->add($sql, 'siisii', array($enameId, $type, $role, $msg, time(), 2));
	}

	private function isEnameId($enameId)
	{
		return (is_numeric($enameId) && strlen($enameId) < 8) ? TRUE : FALSE;
	}
}
?>
<?php
namespace models\help;
use core\ModBase;
class CustomerCountMod extends ModBase
{
	private $table;
	public function __construct($db = 'user')
	{
		parent::__construct($db);
		$this->table = 'e_verify_second';
	}

	public function addCustomerCount($vid, $vtype, $adminId, $verifyTime)
	{
		$sql = "INSERT INTO " . $this->table . " (vid,vtype,adminId,verifyTime,addTime) values(?,?,?,?,?)";
		return $this->add($sql, 'iiiii', array($vid, $vtype, $adminId, $verifyTime,time()));
	}

	public function getCustomerCountOne($vid, $vtype, $adminId, $verifyTime)
	{
		$checkDate = is_numeric($verifyTime) ? date('Y-m-d',$verifyTime) : $verifyTime;
		$sql = "select * from " . $this->table . " where vid=? and vtype=? and adminId=? and FROM_UNIXTIME(verifyTime,'%Y-%m-%d')=? ";
		return $this->getRow($sql, 'iiis', array($vid, $vtype, $adminId, $checkDate));
	}

	public function getGroupData($vtype, $verifytime)
	{
		$checkDate = is_numeric($verifytime) ? date('Y-m-d',$verifytime) : $verifytime;
		$sql = "select count(1) as cscount,FROM_UNIXTIME(verifyTime,'%Y-%m-%d') as vtime,adminId as VerifyUser,vtype as cstype from $this->table where vtype = ? and FROM_UNIXTIME(verifyTime,'%Y-%m-%d') = ? group by adminId,vtype,vtime ";
		return $this->select($sql, 'is', array($vtype,$checkDate));
	}

	public FUNCTION getCustomerCountList($vid, $vtype, $adminId, $verifyTime,$limit)
	{
		$sql = "select * from " . $this->table;
		$where = $value = array();
		$bindType = '';
		if($vid)
		{
			$where[] = 'vid=?';
			$value[] = $vid;
			$bindType .= 'i';
		}
		if($vtype)
		{
			$where[] = 'vtype=?';
			$value[] = $vtype;
			$bindType .= 'i';
		}
		if($adminId)
		{
			$where[] = 'adminId=?';
			$value[] = $adminId;
			$bindType .= 'i';
		}
		if($verifyTime)
		{
			$len = strlen($verifyTime);
			if($len>7)
			{
				$where[] = 'FROM_UNIXTIME(verifyTime,"%Y-%m-%d")=?';
			}
			elseif($len==4)
			{
				$where[] = 'FROM_UNIXTIME(verifyTime,"%Y")=?';
			}
			else
			{
				$where[] = 'FROM_UNIXTIME(verifyTime,"%Y-%m")=?';
			}
			$value[] = $verifyTime;
			$bindType .= 's';
		}
		$sql .= ' where ' . implode(' and ', $where);
		if($limit)
		{
			$sql.= ' limit '.$limit;
		}
		return $this->select($sql, $bindType, $value);
	}

	public function updateCustomerCount($vid, $vtype, $adminId, $verifyTime)
	{
		$checkDate = is_numeric($verifyTime) ? date('Y-m-d',$verifyTime) : $verifyTime;
		$setDate = is_numeric($verifyTime) ? $verifyTime : strtotime($verifyTime);
		$sql = "update " . $this->table . " set verifyTime=?,addTime=? where vid=? and vtype=? and adminId=? and FROM_UNIXTIME(verifyTime,'%Y-%m-%d')=?";
		return $this->update($sql, 'iiiiis', array($setDate, time(),$vid, $vtype, $adminId, $checkDate));
	}
}

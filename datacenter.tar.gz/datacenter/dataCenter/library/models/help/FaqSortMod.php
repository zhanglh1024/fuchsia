<?php
namespace models\help;

use core\ModBase;
class FaqSortMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('help');
		$this->table = 'faq_sort';
	}

	public function getSortId($sortName)
	{
		$sql = "select s_id from " . $this->table . " where s_name=?";
		return $this->getOne($sql, 's', array($sortName));
	}
}
?>
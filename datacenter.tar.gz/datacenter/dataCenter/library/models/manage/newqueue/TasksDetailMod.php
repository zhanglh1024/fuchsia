<?php
namespace models\manage\newqueue;
use core\ModBase;
 
/**
 * 任务队列详情
 */
class TasksDetailMod extends ModBase
{

	private $table;

	private $tasksMod;

	public function __construct()
	{
		parent::__construct('newqueue');
		$this->table = 'e_queue_tasks_detail';
		$this->tasksMod = new \models\manage\newqueue\TasksMod();
	}

	/**
	 * 添加批量任务队列(先入批量任务主表,在入详细表)
	 *
	 * @param array $data
	 * FuncType,EnameId,TaskId,Priority,Repeat,Data,Status,Step,StepData,CreateTime
	 * @throws \Exception
	 */
	public function addQueue($data)
	{
		$sql = "insert into {$this->table} (`Function`,`EnameId`,`TaskId`,`Priority`,`Repeat`,`Data`,`Status`,`Step`,`StepData`,`CreateTime`) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		return $this->add($sql, 'siiiisissi', 
			array($data['Function'], $data['EnameId'], $data['TaskId'], $data['Priority'], $data['Repeat'], 
					$data['Data'], $data['Status'], $data['Step'], $data['StepData'], $data['CreateTime']));
	}

	/**
	 * 更新数据
	 *
	 * @param array $data
	 * @param array $where
	 * @throws \Exception
	 */
	public function updateQueue($data, $queueId)
	{
		if(empty($data))
		{
			throw new \Exception('参数错误', 900004);
		}
		$setArr = array();
		$setType = '';
		$setValue = array();
		if(isset($data['Status']))
		{
			$setArr[] = '`Status` = ?';
			$setType .= 'i';
			$setValue[] = $data['Status'];
		}
		if(! empty($data['Repeat']))
		{
			$setArr[] = '`Repeat` = `Repeat` + ?';
			$setType .= 'i';
			$setValue[] = $data['Repeat'];
		}
		if(! empty($data['Step']))
		{
			$setArr[] = '`Step` =  ?';
			$setType .= 's';
			$setValue[] = $data['Step'];
		}
		if(! empty($data['StepData']))
		{
			$setArr[] = '`StepData` =  ?';
			$setType .= 's';
			$setValue[] = $data['StepData'];
		}
		$setArr[] = '`SuccessTime` =  ?';
		$setType .= 'i';
		$setValue[] = empty($data['SuccessTime']) ? time() : $data['SuccessTime'];
		$sql = "update {$this->table} set " . implode(',', $setArr) . " where QueueId = {$queueId}";
		return $this->update($sql, $setType, $setValue, true);
	}

	/**
	 * 设置队列执行状态(status)
	 *
	 * @param int $queueId
	 */
	public function setQueueRunning($queueId)
	{
		$sql = "update {$this->table} set Status = 1,Repeat = Repeat + 1 where QueueId = ?";
		return $this->update($sql, 'i', array($queueId));
	}

	/**
	 * 获取队列详情列表
	 */
	public function getList($params, $limitOne = false)
	{
		$appendStr = '';
		if(isset($params['order']))
		{
			$appendStr .= ' order by ' . $params['order'];
			unset($params['order']);
		}
		if(isset($params['limit']))
		{
			$appendStr .= ' limit ' . $params['limit'];
			unset($params['limit']);
		}
		list($where, $bindType, $values) = $this->getWhereSql($params);
		$sql = "select * from {$this->table} " . (empty($where) ? '' : ' where ' . implode(' and ', $where)) . $appendStr;
		return $this->select($sql, $bindType, $values, $limitOne);
	}

	/**
	 * 获取详情统计
	 */
	public function getCount($params)
	{
		list($where, $bindType, $values) = $this->getWhereSql($params);
		$sql = "select count(*) from {$this->table} " . (empty($where) ? '' : ' where ' . implode(' and ', $where));
		return $this->getOne($sql, $bindType, $values);
	}

	/**
	 * where条件组装
	 *
	 * @param array $where array('DomainId' => 123, 'in' =>
	 * array('DomainMyStatus' => array(2, 3)))
	 * @return array array($whereData, $bindType, $bindValue)
	 */
	private function getWhereSql($where)
	{
		$whereData = $bindValue = array();
		$bindType = '';
		foreach($where as $key => $value)
		{
			if($key == 'in')
			{
				$keys = array_keys($where['in']);
				foreach($keys as $k => $v)
				{
					$wen = trim(str_repeat('?,', count($where['in'][$v])), ',');
					$whereData[] = $v . ' in (' . $wen . ')';
					foreach($where['in'][$v] as $val)
					{
						$bindType .= is_string($val) ? 's' : 'i';
						$bindValue[] = $val;
					}
				}
			}
			else if(preg_match("/(\s|<|>|!|=|is null|is not null)/i", $key))
			{
				$whereData[] = $key . ' ? ';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
			else
			{
				$whereData[] = $key . ' = ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		return array($whereData, $bindType, $bindValue);
	}
}
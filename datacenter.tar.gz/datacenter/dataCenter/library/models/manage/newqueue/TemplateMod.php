<?php
namespace models\manage\newqueue;
use core\ModBase;

/**
 * 队列模板
 */
class TemplateMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('newqueue');
		$this->table = 'e_queue_template';
	}

	/**
	 * 添加队列模板
	 *
	 * @param array $data
	 */
	public function addTemplate($data)
	{
		$sql = "insert into $this->table (`TemplateName`,`TemplateRemark`,`TemplateTitle`,`IsDefault`,`AltContent`,`HtmlContent`,`GroupId`,`CreateTime`,`UpdateTime`,`Sort`) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
		return $this->add($sql, 'sssissiiii', 
			array($data['TemplateName'], $data['TemplateRemark'], $data['TemplateTitle'], $data['IsDefault'], 
					$data['AltContent'], $data['HtmlContent'], $data['GroupId'], $data['CreateTime'], 
					$data['UpdateTime'], $data['Sort']));
	}

	/**
	 * 更新队列模板信息
	 *
	 * @param array $data
	 * @param int $templateId
	 */
	public function updateTemplate($data, $templateId)
	{
		if(empty($data))
		{
			throw new \Exception('参数错误');
		}
		$setArr = array();
		$setType = '';
		$setValue = array();
		if(! empty($data['TemplateName']))
		{
			$setArr[] = '`TemplateName` = ?';
			$setType .= 's';
			$setValue[] = $data['TemplateName'];
		}
		if(! empty($data['TemplateRemark']))
		{
			$setArr[] = '`TemplateRemark` = ?';
			$setType .= 's';
			$setValue[] = $data['TemplateRemark'];
		}
		if(! empty($data['TemplateTitle']))
		{
			$setArr[] = '`TemplateTitle` = ?';
			$setType .= 's';
			$setValue[] = $data['TemplateTitle'];
		}
		if(isset($data['IsDefault']))
		{
			$setArr[] = '`IsDefault` = ?';
			$setType .= 'i';
			$setValue[] = $data['IsDefault'];
		}
		if(! empty($data['AltContent']))
		{
			$setArr[] = '`AltContent` = ?';
			$setType .= 's';
			$setValue[] = $data['AltContent'];
		}
		if(! empty($data['HtmlContent']))
		{
			$setArr[] = '`HtmlContent` = ?';
			$setType .= 's';
			$setValue[] = $data['HtmlContent'];
		}
		if(! empty($data['GroupId']))
		{
			$setArr[] = '`GroupId` = ?';
			$setType .= 'i';
			$setValue[] = $data['GroupId'];
		}
		if(! empty($data['CreateTime']))
		{
			$setArr[] = '`CreateTime` = ?';
			$setType .= 'i';
			$setValue[] = $data['CreateTime'];
		}
		if(! empty($data['UpdateTime']))
		{
			$setArr[] = '`UpdateTime` = ?';
			$setType .= 'i';
			$setValue[] = $data['UpdateTime'];
		}
		if(! empty($data['Sort']))
		{
			$setArr[] = '`Sort` = ?';
			$setType .= 'i';
			$setValue[] = $data['Sort'];
		}
		$setType .= 'i';
		$setValue[] = $templateId;
		$sql = "update {$this->table} set " . implode(' , ', $setArr) . " where TemplateId = ?";
		return $this->update($sql, $setType, $setValue);
	}

	/**
	 * 获取模板列表
	 *
	 * @param array $params
	 */
	public function getList($params)
	{
		$appendStr = '';
		if(isset($params['order']))
		{
			$appendStr .= ' order by ' . $params['order'];
			unset($params['order']);
		}
		if(isset($params['limit']))
		{
			$appendStr .= ' limit ' . $params['limit'];
			unset($params['limit']);
		}
		list($where, $bindType, $values) = $this->getWhereSql($params);
		$sql = "select * from {$this->table} " . (empty($where) ? '' : ' where ' . implode(' and ', $where)) . $appendStr;
		return $this->select($sql, $bindType, $values);
	}

	/**
	 * 根据模板id获取详情
	 *
	 * @param int $templateId
	 */
	public function getInfo($templateId)
	{
		$sql = 'select * from ' . $this->table . ' where templateId = ?';
		return $this->getRow($sql, 'i', array($templateId));
	}

	/**
	 * 根据模板名获取详情
	 *
	 * @param string $templateName
	 */
	public function getInfoByTemplateName($templateName)
	{
		$sql = 'select * from ' . $this->table . ' where TemplateName = ? and IsDefault = 1';
		return $this->getRow($sql, 's', array($templateName));
	}

	/**
	 * 获取统计
	 *
	 * @param array $params
	 */
	public function getCount($params)
	{
		list($where, $bindType, $values) = $this->getWhereSql($params);
		$sql = "select count(*) from {$this->table} " . (empty($where) ? '' : ' where ' . implode(' and ', $where));
		return $this->getOne($sql, $bindType, $values);
	}

	/**
	 * 根据模板id删除模板
	 *
	 * @param int $templateId
	 */
	public function deleteTemplate($templateId)
	{
		$sql = 'delete from ' . $this->table . ' where TemplateId = ?';
		return $this->delete($sql, 'i', array($templateId));
	}

	/**
	 * where条件组装
	 *
	 * @param array $where array('DomainId' => 123, 'in' =>
	 * array('DomainMyStatus' => array(2, 3)))
	 * @return array array($whereData, $bindType, $bindValue)
	 */
	private function getWhereSql($where)
	{
		$whereData = $bindValue = array();
		$bindType = '';
		foreach($where as $key => $value)
		{
			if($key == 'in')
			{
				$keys = array_keys($where['in']);
				foreach($keys as $k => $v)
				{
					$wen = trim(str_repeat('?,', count($where['in'][$v])), ',');
					$whereData[] = $v . ' in (' . $wen . ')';
					foreach($where['in'][$v] as $val)
					{
						$bindType .= is_string($val) ? 's' : 'i';
						$bindValue[] = $val;
					}
				}
			}
			else if($key == 'like')
			{
				foreach($where['like'] as $k => $v)
				{
					$whereData[] = $k . ' like "%' . $v . '%" ';
				}
			}
			else
			{
				$whereData[] = $key . ' = ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		return array($whereData, $bindType, $bindValue);
	}
}
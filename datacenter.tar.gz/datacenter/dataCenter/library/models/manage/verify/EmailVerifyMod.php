<?php
namespace models\manage\verify;
use core\ModBase;
class EmailVerifyMod extends ModBase
{
	private $table;
	function __construct()
	{
		parent::__construct('verify');
		$this->table = 'e_verify_email';
	}

	//根据ID获取认证信息
	public function getVerifyById($fid)
	{
		return $this->select("select * from " . $this->table ." where Id=?", "i", array($fid),true);
	}
	//更新认证状态
	public function setVerifyInfo($data)
	{
		$wherestr = '';
		$bindType = '';
		$where = array();
		$params[] = $data['VerifyStatus'];
		if(isset($data['EnameId']))
		{
			$where[] = ' EnameId=?';
			$params[] = $data['EnameId'];
			$bindType .= 'i';
		}
		if(isset($data['Id']))
		{
			$where[] = ' Id=?';
			$params[] = $data['Id'];
			$bindType .= 'i';
		}
		if($where)
		{
			$wherestr = ' where '. implode(' and ', $where);
		}
		return $this->update("update $this->table set VerifyStatus=? " . $wherestr, "i" . $bindType, $params);
	}
	/**
	 *获取用户邮箱认证信息
	 *
	 * 
	 */
	public function getVerifyInfo($info,$limit = '',$order = '')
	{
		$where = array();
		$wherestr = '';
		$bindType = ''; 
		$params = array();
		if(isset($info['EnameId']))
		{
			$where[] = '  EnameId =?';
			$bindType .= 'i';
			$params['EnameId'] =$info['EnameId'];
		}
		if(isset($info['VerifyStatus']))
		{
			$one = substr($info['VerifyStatus'], 0, 1);
			if($one == '!')
			{
				$where[] = '  VerifyStatus  !=?';
				$params['VerifyStatus'] =substr($info['VerifyStatus'], 2, 1);
			}
			else 
			{
				$where[] = '  VerifyStatus =?';
				$params['VerifyStatus'] =$info['VerifyStatus'];
			}
			$bindType .= 'i';
		}
		if(isset($info['IsBound']))
		{
			$where[] = ' IsBound =?';
			$bindType .= 'i';
			$params['IsBound'] =$info['IsBound'];
		}
		if(isset($info['Email']))
		{
			if(count($info['Email']) > 1)
			{
				$counts = array();
				foreach($info['Email'] as $email)
				{
					$counts[] = '?';
					$bindType .= 's';
					$params[] = $email;
				}
				$where[] = ' Email in(' . implode(',', $counts) . ')';
			}
			else
			{
				$where[] = ' Email =?';
				$bindType .= 's';
				$params['Email'] = $info['Email'];
			}
		}
		if($where )
		{
			$wherestr  =' where' . implode(' and ', $where);
		}
		$orderstr = empty($order) ? " " : ' order by '.$order;
		$limitstr = empty($limit) ? '' : ' limit '.$limit;
		return $this->select("select * from " . $this->table . $wherestr.$orderstr.$limitstr, $bindType, $params);
	}
	/**
	 *获取用户邮箱认证信息条数
	 *
	 * @param array $info
	 */
	public function getVerifyCount($info)
	{
		$wherestr = '';
		$where = array();
		$bindType = '';
		$params = array();
		if(isset($info['EnameId']))
		{
			$where[] = '  EnameId =?';
			$bindType .= 'i';
			$params['EnameId'] =$info['EnameId'];
		}
		if(isset($info['VerifyStatus']))
		{
			$one = substr($info['VerifyStatus'], 0, 1);
			if($one == '!')
			{
				$where[] = '  VerifyStatus  !=?';
				$params['VerifyStatus'] =substr($info['VerifyStatus'], 2, 1);
			}
			else 
			{
				$where[] = '  VerifyStatus =?';
				$params['VerifyStatus'] =$info['VerifyStatus'];
			}
			$bindType .= 'i';
		}
		if(isset($info['IsBound']))
		{
			$where[] = ' IsBound =?';
			$bindType .= 'i';
			$params['IsBound'] =$info['IsBound'];
		}
		if($where )
		{
			$wherestr  =' where' . implode(' and ', $where);
		}
		return $this->select("select count(*) as sum  from " . $this->table . $wherestr, $bindType, $params,true);
	}
	/**
	 * 插入表数据
	 *
	 * @param array $data
;	 */
	public function addInfo($data)
	{
		$sql = "insert into $this->table ";
		$sql .= "(EnameId,Email,CreateTime,CreateIp,VerifyStatus,UpdateTime,IsBound)";
		$sql .= " values(?,?,?,?,?,?,?)";
		return $this->add($sql, 'isssisi', array($data['EnameId'],$data['Email'],$data['CreateTime'],$data['CreateIp'],$data['VerifyStatus'],$data['UpdateTime'],$data['IsBound']));
	}
}

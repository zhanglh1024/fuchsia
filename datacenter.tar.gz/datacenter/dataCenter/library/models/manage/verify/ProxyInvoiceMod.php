<?php
namespace models\manage\verify;
use core\ModBase;
class ProxyInvoiceMod extends ModBase
{
	private $table;
	function __construct()
	{
		parent::__construct('verify');
		$this->table = 'e_verify_invoice';
	}

	/**
	 * 发票授权委托列表
	 */
	public function getProxyInvoiceList($data,$fields="*")
	{
		$query = "select $fields from  " . $this->table;
		$result = $this->getWherePart($data);
		list($where, $bindType, $bindValue) = $result;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		if(isset($data['order']))
		{
			$query .= ' order by ' . $data['order'];
		}
		else 
		{
			$query .= ' order by CreateTime DESC';
		}
		if(isset($data['offset']) && isset($data['num']))
		{
			$offset = $data['offset'];
			$num = $data['num'];
			$limit = $offset . ',' . $num;
			$query .= ' limit ' . $limit;
		}
		return $this->select($query, $bindType, $bindValue);
	}
	
	public function getCustomerCount($startTime,$end)
	{
		$startTime = strtotime($startTime);
		$end = strtotime($end);
		$sql = 'select count(1) as cscount,FROM_UNIXTIME(UpdateTime,\'%Y-%m-%d\') as vtime,AdminId as VerifyUser, 14 as cstype from '.$this->table .' where  AdminId!="" and AdminId!=0  and UpdateTime between ? and ? group by AdminId,vtime';
		return $this->select($sql,'ii',array($startTime, $end));
	}
	
	
	/**
	 * 发票授权委托数
	 */
	public function getProxyInvoiceCount($data)
	{
		$query = "select count(ID) as num from  " . $this->table;
		$result = $this->getWherePart($data);
		list($where, $bindType, $bindValue) = $result;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		return $this->getOne($query, $bindType, $bindValue);
	}
	
	public function addProxyInvoice($data)
	{
		$time = time();
		$Ip = \common\Common::getRequestIp();
		return $this->add("insert into $this->table(EnameId,InvoiceTitle,CreateTime,UpdateTime,Status,ProxyFile,Remark,Type,IP) values(?,?,?,?,?,?,?,?,?)", "isiiissis", array($data['EnameId'], $data['InvoiceTitle'], isset($data['CreateTime']) ? $data['CreateTime'] : $time, isset($data['UpdateTime']) ? $data['UpdateTime'] : $time, isset($data['Status']) ? $data['Status'] : 1, $data['ProxyFile'], isset($data['Remark']) ? $data['Remark'] : '', $data['Type'], $Ip));
	}
	
	public function getProxyInvoiceByID($ID) 
	{
		return $this->select("select * from " . $this->table ." where ID=?", "i", array($ID),true);
	}
	public function delProxyInvoiceByID($ID)
	{
		return $this->delete("delete from " . $this->table ." where ID=?", "i", array($ID),true);
	}
	public function updateProxyInvoice($set, $where)
	{
		$query = "update $this->table set ";
		$setResult = $this->getSetPart($set);
		list($set, $bindSetType, $bindSetValue) = $setResult;
		if($set)
		{
			$query .= implode(' , ', $set);
		}
		$whereResul = $this->getWherePart($where);
		list($where, $bindWhereType, $bindWhereValue) = $whereResul;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		$bindType = $bindSetType . $bindWhereType;
		$bindValue = $bindSetValue;
		if(!empty($bindWhereValue))
		{
			foreach($bindWhereValue as $k => $v)
			{
				$bindValue[] = $v;
			}
		}
		return $this->update($query, $bindType, $bindValue);
	}

	/**
	 * 获取 where部分
	 *
	 * @param array
	 * @return list(array,array,string)
	 */
	private function getWherePart($where)
	{
		$whereTemp = $bindValue = array();
		$bindType = '';
		if(!empty($where['ID']))
		{
			$whereTemp[] = 'ID = ?';
			$bindValue[] = $where['ID'];
			$bindType .= 'i';
		}
		if(!empty($where['EnameId']))
		{
			$whereTemp[] = 'EnameId = ?';
			$bindValue[] = $where['EnameId'];
			$bindType .= 'i';
		}
		if(!empty($where['Status']))
		{
			$fuhao = '=';
			$one = substr($where['Status'], 0, 1);
			if($one == '<' || $one == '>' || $one == '!')
			{
				$fuhao = (stripos($where['Status'], $one . '=') !== FALSE) ? $one . '=' : $one;
				$where['Status'] = str_replace($fuhao, '', $where['Status']);
			}
			$whereTemp[]= 'Status' . $fuhao ." ?";
			$bindType .= is_string($where['Status']) ? 's' : 'i';
			$bindValue[] = $where['Status'];
		}
		if(!empty($where['InvoiceTitle']))
		{
			$whereTemp[] = 'instr(InvoiceTitle,?) > 0';
			$bindValue[] = $where['InvoiceTitle'];
			$bindType .= 's';
		}
		if(!empty($where['Type']))
		{
			$whereTemp[] = 'Type = ?';
			$bindValue[] = $where['Type'];
			$bindType .= 'i';
		}
		if(!empty($where['AdminId']))
		{
			$whereTemp[] = 'AdminId = ?';
			$bindValue[] = $where['AdminId'];
			$bindType .= 'i';
		}
		if(!empty($where['Verifytime']))
		{
			$whereTemp[] = 'UpdateTime>= ?';
			$whereTemp[] = 'UpdateTime<= ?';
			$bindType .= 'ss';
			$verifyTime = $where['Verifytime'];
			$len = strlen($verifyTime);
			if($len == 4 )
			{
				$bindValue[] = strtotime($verifyTime . '-01-01 00:00:00');
				$bindValue[] = strtotime($verifyTime. '-12-31 23:59:59');
			}
			else if(strlen($verifyTime) == 7 )
			{
				$bindValue[] = strtotime($verifyTime . '-01 00:00:00');
				$bindValue[] = strtotime(date("Y-m-d 23:59:59",strtotime($verifyTime.'+1 month -1 day')));
			}
			else
			{
				$bindValue[] = strtotime($verifyTime . ' 00:00:00');
				$bindValue[] = strtotime($verifyTime . ' 23:59:59');
			}
		}
		return array($whereTemp, $bindType, $bindValue);
	}

	private function getSetPart($set)
	{
		$setTemp = $bindValue = array();
		$bindType = '';
		if(!empty($set['Status']))
		{
			$setTemp[] = 'Status = ?';
			$bindValue[] = $set['Status'];
			$bindType .= 'i';
		}
		if(!empty($set['UpdateTime']))
		{
			$setTemp[] = 'UpdateTime = ?';
			$bindValue[] = $set['UpdateTime'];
			$bindType .= 'i';
		}
		if(!empty($set['AdminId']))
		{
			$setTemp[] = 'AdminId = ?';
			$bindValue[] = $set['AdminId'];
			$bindType .= 'i';
		}
		if(!empty($set['Remark']))
		{
			$setTemp[] = 'Remark = ?';
			$bindValue[] = $set['Remark'];
			$bindType .= 's';
		}
		if(!empty($set['Type']))
		{
			$setTemp[] = 'Type = ?';
			$bindValue[] = $set['Type'];
			$bindType .= 'i';
		}
		return array($setTemp, $bindType, $bindValue);
	}
}

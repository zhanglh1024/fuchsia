<?php
namespace models\manage\verify;
use core\ModBase;
class CompanyVerifyMod extends ModBase
{
	private $table;
	function __construct()
	{
		parent::__construct('verify');
		$this->table = 'e_verify_company';
	}

	//根据ID获取认证信息
	public function getVerifyById($fid)
	{
		return $this->select("select * from " . $this->table ." where Id=?", "i", array($fid),true);
	}
	//更新认证信息
	public function setVerifyInfo($data)
	{
		$wherestr = '';
		$bindType = '';
		$where = array();
		$params[] = $data['VerifyStatus'];
		if(isset($data['EnameId']))
		{
			$where[] = ' EnameId=?';
			$params[] = $data['EnameId'];
			$bindType .= 'i';
		}
		if(isset($data['Id']))
		{
			$where[] = ' Id=?';
			$params[] = $data['Id'];
			$bindType .= 'i';
		}
		if($where)
		{
			$wherestr = ' where '. implode(' and ', $where);
		}
		return $this->update("update $this->table set VerifyStatus=? " . $wherestr, "i" . $bindType, $params);
	}
	/**
	 *获取用户公司认证信息
	 *
	 * @param int $enameid       	
	 */
	public function getVerifyInfo($info,$limit = '',$order = 'Id DESC') 
	{
		$where = '';
		$bindTye = '';
		$params = array();
		if(isset($info['EnameId']))
		{
			$where .= empty($where)  ? ' EnameId=?' : ' and EnameId =?';
			$bindTye .= 'i';
			$params['EnameId'] =$info['EnameId'];
		}
		if(isset($info['VerifyStatus']))
		{
			$one = substr($info['VerifyStatus'], 0, 1);
			if($one == '!')
			{
				$where .=  empty($where)  ? ' VerifyStatus  !=?' :' and VerifyStatus  !=?';
				$params['VerifyStatus'] =substr($info['VerifyStatus'], 2, 1);
			}
			else
			{
				$where .= empty($where)  ? ' VerifyStatus  =?' :' and VerifyStatus =?';
				$params['VerifyStatus'] =$info['VerifyStatus'];
			}
			$bindTye .= 'i';
		}
		if(!empty($info['CompanyName']))
		{
			$where .= empty($where)  ? ' CompanyName  =?' :' and CompanyName =?';
			$bindTye .= 's';
			$params['CompanyName'] =$info['CompanyName'];
		}
		if(!empty($info['Id']))
		{
			$where .= empty($where)  ? ' Id  =?' :' and Id =?';
			$bindTye .= 'i';
			$params['Id'] =$info['Id'];
		}
		if(isset($info['IsBound']))
		{
			$where .= empty($where)  ? ' IsBound=?' :' and IsBound =?';
			$bindTye .= 'i';
			$params['IsBound'] =$info['IsBound'];
		}
		if (!empty($info['LicenseType'])) 
		{
			$where .= empty($where) ? ' LicenseType = ?' : ' and LicenseType = ?';
			$bindTye .= 'i';
			$params['LicenseType'] = $info['LicenseType'];
		}
		if (!empty($info['License'])) 
		{
			$where .= empty($where) ? ' License = ?' : ' and License = ?';
			$bindTye .= 's';
			$params['License'] = $info['License'];
		}
		$wherestr = empty($where) ? '' : ' where '.$where;
		$orderstr = empty($order) ? " " : ' order by '.$order;
		$limitstr = empty($limit) ? '' : ' limit '.$limit;
		return $this->select("select * from " . $this->table . $wherestr.$orderstr.$limitstr, $bindTye, $params);
	}
	/**
	 *获取用户邮公司认证信息条数
	 *
	 * @param array $info
	 */
	public function getVerifyCount($info)
	{
		$where = array();
		$wherestr = '';
		$bindTye = '';
		$params = array();
		if(isset($info['EnameId']))
		{
			$where[] = '  EnameId =?';
			$bindTye .= 'i';
			$params['EnameId'] =$info['EnameId'];
		}
		if(isset($info['VerifyStatus']))
		{
			$one = substr($info['VerifyStatus'], 0, 1);
			if($one == '!')
			{
				$where[] = '  VerifyStatus  !=?';
				$params['VerifyStatus'] =substr($info['VerifyStatus'], 2, 1);
			}
			else
			{
				$where[] = '  VerifyStatus =?';
				$params['VerifyStatus'] =$info['VerifyStatus'];
			}
			$bindTye .= 'i';
		}
		if(isset($info['CompanyName']))
		{
			$where[] = ' CompanyName  =?';
			$bindTye .= 's';
			$params['CompanyName'] =$info['CompanyName'];
		}
		if(isset($info['IsBound']))
		{
			$where[] = ' IsBound =?';
			$bindTye .= 'i';
			$params['IsBound'] =$info['IsBound'];
		}
		if($where )
		{
			$wherestr  =' where' . implode(' and ', $where);
		}
		return $this->select("select count(*) as sum  from " . $this->table . $wherestr, $bindTye, $params,true);
	}
	/**
	 * 插入表数据
	 *
	 * @param array $data
	 */
	public function addInfo($data)
	{
		$sql = "insert into $this->table ";
		$sql .= "(EnameId,CompanyName,LicenseType,LicenseImg,License,CreateTime,CreateIp,VerifyStatus,UpdateTime,IsBound,VerifyMessage)";
		$sql .= " values(?,?,?,?,?,?,?,?,?,?,?)";
		return $this->add($sql, 'isissssisis', array($data['EnameId'],$data['CompanyName'],$data['LicenseType'],$data['LicenseImg'],$data['License'],$data['CreateTime'],$data['CreateIp'],$data['VerifyStatus'],$data['UpdateTime'],$data['IsBound'],$data['VerifyMessage']));
	}
	
	/**
	 * 获取统计数据
	 */
	public function getVerifyCountGroup($type,$time)
	{
		$sql = "select count(1) as cscount,substr(UpdateTime,1,10) as vtime,VerifyUser,$type as cstype from ".$this->table .' where CreateTime>="2014-01-01 00:00:00" and VerifyStatus!=?  and VerifyUser!="" and substr(UpdateTime,1,10)=? group by VerifyUser, vtime,cstype';
		return $this->select($sql,'is',array(0,$time));
	}

	/**
	 * 获取未处理认证数量
	 */
	public function getTodoCount()
	{
		$sql = 'select count(Id) as count from ' . $this->table . ' where VerifyStatus = 1';
		return $this->select($sql,'i',array());
	}
	
}

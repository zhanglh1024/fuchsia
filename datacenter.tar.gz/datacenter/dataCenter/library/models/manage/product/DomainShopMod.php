<?php
namespace models\manage\product;
use core\ModBase;

class DomainShopMod extends ModBase
{
	public function __construct($dbName = 'product')
	{
		parent::__construct($dbName);
		$this->tableName = 'e_domain_shop';
	}

	public function getCartCount($enameId) 
	{
		return $this->select('select count(ShopId) as count from ' . $this->tableName . ' where EnameId = ?','i', array($enameId));
	}
	
	public function updateCartByShopId($where, $set)
	{
		if(empty($where) || empty($set))
		{ 
			return false;
		}
		if(isset($set['ShopId']))
		{
			unset($set['ShopId']);
		}
		if(isset($set['EnameId']))
		{
			unset($set['EnameId']);
		}
		if(isset($set['DomainName']) && !$set['DomainName'])
		{
			unset($set['DomainName']);
		} 
		if(isset($set['Ext']))
		{
			// 类型转换
			if(isset($set['allowRegister']))
			{
				$set['allowRegister'] = (int)$set['allowRegister'];
			}
			$set['Ext'] = json_encode($set['Ext']);
		}
		$whereData = $upData = $bindValue = array();
		$bindType = '';
		foreach($set as $key => $value)
		{
			$upData[] = $key . ' = ? ';
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		foreach($where as $key => $value)
		{
			$whereData[] = $key . ' = ? ';
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		$query = 'update ' . $this->tableName . ' set ' . implode(',', $upData) . ' where ' .
			 implode(' and ', $whereData);
		return $this->update($query, $bindType, $bindValue);
	}

}
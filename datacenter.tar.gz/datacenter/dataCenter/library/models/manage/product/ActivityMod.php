<?php
namespace models\manage\product;
use core\ModBase;

class ActivityMod extends ModBase
{
	private $tableName;
	
	public function __construct($dbName = 'product')
	{
		parent::__construct($dbName);
		$this->tableName = 'e_products_activity';
	}
	
	public function addActivity($params)
	{
		$acType = empty($params['acType']) ? 1 : $params['acType'];
		$acPurpose = empty($params['acPurpose']) ? 0 : $params['acPurpose'];
		$acCoupon = empty($params['acCoupon']) ? 0 : $params['acCoupon'];
		$acYear = empty($params['acYear']) ? 0 : $params['acYear'];
		$acShowIndex = empty($params['acShowIndex']) ? 0 : $params['acShowIndex'];
		$acContent = empty($params['acContent']) ? '' : $params['acContent'];
		$acContentAdmin = empty($params['acContentAdmin']) ? '' : $params['acContentAdmin'];
		$acPrice = empty($params['acPrice']) ? '' : $params['acPrice'];
		$cost = empty($params['cost']) ? '' : $params['cost'];
		$costDollar = empty($params['costDollar']) ? '' : $params['costDollar'];
		$acBeginTime = empty($params['acBeginTime']) ? 0 : $params['acBeginTime'];
		$acEndTime = empty($params['acEndTime']) ? 0 : $params['acEndTime'];
		$acBusinessType = $params['acBusinessType'];
		$dnLtd = empty($params['dnLtd']) ? 0 : $params['dnLtd'];
		$dnLength = empty($params['dnLength']) ? 0 : $params['dnLength'];
		$productType = $params['productType'];
		$dnFirstClass = empty($params['dnFirstClass']) ? 0 : $params['dnFirstClass'];
		$dnSecondClass = empty($params['dnSecondClass']) ? 0 : $params['dnSecondClass'];
		$dnTimeLimit = empty($params['dnTimeLimit']) ? '' : $params['dnTimeLimit'];
		$acPriority = empty($params['acPriority']) ? 0 : $params['acPriority'];
		$acTotal = empty($params['acTotal']) ? 0 : $params['acTotal'];
		$adminId = empty($params['adminId']) ? 0 : $params['adminId'];
		$oriIp = ip2long(\common\Common::getRequestIp());
		return $this->add("insert into $this->tableName(
			ac_status, ac_type, ac_purpose, ac_coupon, ac_year_limit, ac_show_index, ac_content, ac_content_admin, ac_price, ac_cost, ac_cost_dollar, ac_create_time, ac_begin_time, ac_end_time,
			ac_business_type, ac_dn_ltd, ac_dn_length, ac_product_type, ac_dn_first_class, ac_dn_second_class, ac_dn_time_limit, ac_total, ac_total_rest, ac_priority, ac_last_ip, ac_last_time, ac_last_admin)
			values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", "iiiiiisssssiiiiiiiiisiiiiii", 
			array(1, $acType, $acPurpose, $acCoupon, $acYear, $acShowIndex, $acContent, $acContentAdmin, $acPrice, $cost, $costDollar, time(), $acBeginTime, $acEndTime, 
				$acBusinessType, $dnLtd, $dnLength, $productType, $dnFirstClass, $dnSecondClass, $dnTimeLimit, $acTotal, $acTotal, $acPriority, $oriIp, time(), $adminId));
	}
	
	public function getActivityCount($data)
	{
		list($wherestsr, $bindType, $params) = $this->getWhereData($data);
		return $this->getOne("select count(*) as sum from $this->tableName " . $wherestsr, $bindType, $params, true);
	}
	
	public function getActivityList($data, $isOne = false)
	{
		$whereData = $this->getWhereData($data);
		if(!$whereData)
		{
			return false;
		}
		list($wherestsr, $bindType, $params) = $whereData;
		$orderstr = ' ORDER BY ' . (!empty($data['order']) ? $data['order'] : 'ac_create_time desc');
		$limitstr = !empty($data['limit']) ? ' LIMIT ' . $data['limit'] : '';
		return $this->select("select * from $this->tableName " . $wherestsr . $orderstr . $limitstr, $bindType, $params, $isOne);
	}
	
	public function setActivity($data)
	{
		if(empty($data['ac_id']))
		{
			return false;
		}
		$acId = $data['ac_id'];
		unset($data['ac_id']);
		if(empty($data))
		{
			return false;
		}
		$setData = $this->getSetData($data);
		if(!$setData)
		{
			return false;
		}
		list($setStr, $setType, $setValue) = $setData;
		$sql = "update ". $this->tableName . $setStr . " where ac_id = ".$acId;
		return $this->update($sql, $setType, $setValue, true);
	}
	
	private function getWhereData($params)
	{
		if(!is_array($params))
		{
			return false;
		}
		$where = array();
		$bindValue = array();
		$bindType = '';
		if(!empty($params['ac_id']))
		{
			$where[] = 'ac_id = ?';
			$bindValue[] = $params['ac_id'];
			$bindType .= 'i';
		}
		if(!empty($params['acStatus']))
		{
			$where[] = 'ac_status = ?';
			$bindValue[] = $params['acStatus'];
			$bindType .= 'i';
		}
		if(!empty($params['acType']))
		{
			$where[] = 'ac_type = ?';
			$bindValue[] = $params['acType'];
			$bindType .= 'i';
		}
		if(!empty($params['acCoupon']))
		{
			$where[] = 'ac_coupon = ?';
			$bindValue[] = $params['acCoupon'];
			$bindType .= 'i';
		}
		if(!empty($params['acYear']))
		{
			$where[] = 'ac_year_limit = ?';
			$bindValue[] = $params['acYear'];
			$bindType .= 'i';
		}
		if(isset($params['acShowIndex']))
		{
			$where[] = 'ac_show_index = ?';
			$bindValue[] = $params['acShowIndex'];
			$bindType .= 'i';
		}
		if(!empty($params['dnLtd']))
		{
			$where[] = 'ac_dn_ltd = ?';
			$bindValue[] = $params['dnLtd'];
			$bindType .= 'i';
		}
		if(!empty($params['acBeginTimeFrom']))
		{
			$where[] = 'ac_begin_time >= ?';
			$bindValue[] = $params['acBeginTimeFrom'];
			$bindType .= 'i';
		}
		if(!empty($params['acBeginTimeTo']))
		{
			$where[] = 'ac_begin_time <= ?';
			$bindValue[] = $params['acBeginTimeTo'];
			$bindType .= 'i';
		}
		if(!empty($params['acEndTimeFrom']))
		{
			$where[] = 'ac_end_time >= ?';
			$bindValue[] = $params['acEndTimeFrom'];
			$bindType .= 'i';
		}
		if(!empty($params['acEndTimeTo']))
		{
			$where[] = 'ac_end_time <= ?';
			$bindValue[] = $params['acEndTimeTo'];
			$bindType .= 'i';
		}
		if(!empty($params['productType']))
		{
			$where[] = 'ac_product_type & '.$params['productType'].'= ?';
			$bindValue[] = $params['productType'];
			$bindType .= 'i';
		}
		if(!empty($params['acPurpose']))
		{
			$where[] = 'ac_purpose & '.$params['acPurpose'].'= ?';
			$bindValue[] = $params['acPurpose'];
			$bindType .= 'i';
		}
		if(!empty($params['acBusinessType']))
		{
			$where[] = 'ac_business_type & '.$params['acBusinessType'].'= ?';
			$bindValue[] = $params['acBusinessType'];
			$bindType .= 'i';
		}
		$where = $where ? ' where ' . implode(' and ', $where) : '';
		return array($where, $bindType, $bindValue);
	}
	
	private function getSetData($params)
	{
		if(!is_array($params))
		{
			return false;
		}
		$set = array();
		$setType = '';
		$setValue = array();
		if(!empty($params['acStatus']))
		{
			$set[] = 'ac_status = ?';
			$setValue[] = $params['acStatus'];
			$setType .= 'i';
		}
		if(!empty($params['acType']))
		{
			$set[] = 'ac_type = ?';
			$setValue[] = $params['acType'];
			$setType .= 'i';
		}
		if(!empty($params['acCoupon']))
		{
			$set[] = 'ac_coupon = ?';
			$setValue[] = $params['acCoupon'];
			$setType .= 'i';
		}
		if(!empty($params['acPurpose']))
		{
			$set[] = 'ac_purpose = ?';
			$setValue[] = $params['acPurpose'];
			$setType .= 'i';
		}
		if(!empty($params['acYear']))
		{
			$set[] = 'ac_year_limit = ?';
			$setValue[] = $params['acYear'];
			$setType .= 'i';
		}
		if(isset($params['acShowIndex']))
		{
			$set[] = 'ac_show_index = ?';
			$setValue[] = $params['acShowIndex'];
			$setType .= 'i';
		}
		if(!empty($params['dnLtd']))
		{
			$set[] = 'ac_dn_ltd = ?';
			$setValue[] = $params['dnLtd'];
			$setType .= 'i';
		}
		if(!empty($params['dnTimeLimit']))
		{
			$set[] = 'ac_dn_time_limit = ?';
			$setValue[] = $params['dnTimeLimit'];
			$setType .= 's';
		}
		if(!empty($params['productType']))
		{
			$set[] = 'ac_product_type= ?';
			$setValue[] = $params['productType'];
			$setType .= 'i';
		}
		if(!empty($params['acBusinessType']))
		{
			$set[] = 'ac_business_type = ?';
			$setValue[] = $params['acBusinessType'];
			$setType .= 'i';
		}
		if(!empty($params['acContent']))
		{
			$set[] = 'ac_content = ?';
			$setValue[] = $params['acContent'];
			$setType .= 's';
		}
		if(!empty($params['acContentAdmin']))
		{
			$set[] = 'ac_content_admin = ?';
			$setValue[] = $params['acContentAdmin'];
			$setType .= 's';
		}
		if(!empty($params['acPrice']))
		{
			$set[] = 'ac_price = ?';
			$setValue[] = $params['acPrice'];
			$setType .= 's';
		}
		if(!empty($params['cost']))
		{
			$set[] = 'ac_cost = ?';
			$setValue[] = $params['cost'];
			$setType .= 's';
		}
		if(!empty($params['costDollar']))
		{
			$set[] = 'ac_cost_dollar = ?';
			$setValue[] = $params['costDollar'];
			$setType .= 's';
		}
		if(!empty($params['acBeginTime']))
		{
			$set[] = 'ac_begin_time = ?';
			$setValue[] = $params['acBeginTime'];
			$setType .= 'i';
		}
		if(!empty($params['acEndTime']))
		{
			$set[] = 'ac_end_time = ?';
			$setValue[] = $params['acEndTime'];
			$setType .= 'i';
		}
		if(!empty($params['dnLength']))
		{
			$set[] = 'ac_dn_length = ?';
			$setValue[] = $params['dnLength'];
			$setType .= 'i';
		}
		if(!empty($params['dnFirstClass']))
		{
			$set[] = 'ac_dn_first_class = ?';
			$setValue[] = $params['dnFirstClass'];
			$setType .= 'i';
		}
		if(!empty($params['dnSecondClass']))
		{
			$set[] = 'ac_dn_second_class = ?';
			$setValue[] = $params['dnSecondClass'];
			$setType .= 'i';
		}
		if(!empty($params['acPriority']))
		{
			$set[] = 'ac_priority = ?';
			$setValue[] = $params['acPriority'];
			$setType .= 'i';
		}
		if(!empty($params['acTotal']))
		{
			$set[] = 'ac_total = ?';
			$setValue[] = $params['acTotal'];
			$setType .= 'i';
		}
		if(!empty($params['adminId']))
		{
			$set[] = 'ac_last_admin = ?';
			$setValue[] = $params['adminId'];
			$setType .= 's';
		}
		$oriIp = ip2long(\common\Common::getRequestIp());
		$set[] = 'ac_last_ip = ?';
		$setValue[] = $oriIp;
		$setType .= 'i';
		$set[] = 'ac_last_time = ?';
		$setValue[] = time();
		$setType .= 'i';
		$set = $set ? ' set ' . implode(' , ', $set) : '';
		return array($set, $setType, $setValue);
	}

}

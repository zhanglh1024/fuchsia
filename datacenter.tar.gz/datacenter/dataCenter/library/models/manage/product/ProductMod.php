<?php
namespace models\manage\product;
use core\ModBase;

class ProductMod extends ModBase
{
	public function __construct($dbName = 'product')
	{
		parent::__construct($dbName);
		$this->tableName = 'e_products';
		$this->jionTableName = 'e_products_price';
	}

	/**
	 * 	根据产品类型获取产品列表
	 */
	public function getProductsByType($params)
	{
		if(empty($params['productType']))
		{
			$params['productType'] = FALSE;
		}
		$bindType = '';
		$bindValue = array();
		$where = array();
		$productType = $params['productType'];
		$userGroupId = empty($params['userGroupId']) ? 1 : $params['userGroupId'];
		$where[] = 'b.GroupId = ?';
		$bindValue[] = $userGroupId;
		$bindType .= is_string($userGroupId) ? 's' : 'i';
		if(is_array($productType))
		{
			$wen = trim(str_repeat('?,', count($productType), ','));
			$where[] = 'a.ProductType in (' . $wen . ')';
			foreach($productType as $val)
			{
				$bindType .= is_string($val) ? 's' : 'i';
				$bindValue[] = $val;
			}
		}
		else if(is_numeric($productType))
		{
			$where[] = 'a.ProductType = ? ';
			$bindValue[] = $productType;
			$bindType .= is_string($productType) ? 's' : 'i';
		}
		$where = implode(' and ', $where);
		$query = "select * from $this->tableName a,$this->jionTableName b where  a.ProductId =b.ProductId and a.ProductStatus = 1 and " . $where;
		$query .= ' order by ProductSort DESC';
		return $this->select($query, $bindType, array_values($bindValue));
	}

	/**
	 * 根据产品id获取产品信息
	 */
	public function getProductById($params)
	{
		if(!is_numeric($params['productId']) || empty($params['productId']))
		{
			return false;
		}
		$productId = $params['productId'];
		$userGroupId = empty($params['userGroupId']) ? 1 : $params['userGroupId'];
		$productStatus = isset($params['productStatus']) ? $params['productStatus'] : FALSE;
		$bindType = '';
		$bindValue = array();
		$bindType .= is_string($productId) ? 's' : 'i';
		$bindValue[] = $productId;
		$bindType .= is_string($userGroupId) ? 's' : 'i';
		$bindValue[] = $userGroupId;
		if($productStatus)
		{
			$bindType .= is_string($productStatus) ? 's' : 'i';
			$bindValue[] = $productStatus;
		}
		$query = "select * from $this->tableName a,$this->jionTableName b  where  a.ProductId = b.ProductId  ";
		$query .= " and a.ProductId = ?  and b.GroupId = ? ";
		if($productStatus !== FALSE)
		{
			$query .= " and a.ProductStatus = ? ";
		}
		return $this->select($query, $bindType, $bindValue);
	}

	/**
	 * 获取产品名称和类型
	 */
	public function getProductByNameAndType($params)
	{
		if(empty($params['productName']))
		{
			//logs
			return false;
		}
		$userGroupId = empty($params['userGroupId']) ? 1 : $params['userGroupId'];
		$type = '';
		$bindValue = array();
		$type .= 's';
		$type .= is_string($userGroupId) ? 's' : 'i';
		$bindValue[] = $params['productName'];
		$bindValue[] = $userGroupId;
		if(!empty($params['productType']))
		{
			$type .= is_string($params['productType']) ? 's' : 'i';
			$bindValue[] = $params['productType'];
		}
		$query = "select * from $this->tableName a,$this->jionTableName b  where  a.ProductId = b.ProductId  and a.ProductStatus = 1 ";
		$query .= " and a.ProductName=? and b.GroupId = ? ";
		$query .= !empty($params['productType']) ? ' and a.ProductType = ?' : '';
		return $this->select($query, $type, $bindValue);
	}
}

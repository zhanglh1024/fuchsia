<?php
namespace models\manage\template;
use \core\ModBase;
class TemplateMod extends ModBase
{

	public $tableName = 'e_template_zh';
	function __construct()
	{
		parent::__construct('domain');
	}

	/**
	 * 根据获取模板信息 
	 */
	public function getTemplate($params,$limit = FALSE)
	{
		$where = array();
		$bindParams = array();
		$bindType = '';
		if(isset($params['TemplateId']))
		{
			$where[] = 'TemplateId = ?';
			$bindType .= 's';
			$bindParams[] = $params['TemplateId'];
		}
		if(isset($params['TemplateName']))
		{
			$where[] = 'TemplateName = ?';
			$bindParams[] = $params['TemplateName'];
			$bindType .= 's';
		}
		if(isset($params['EnameId']) && !empty($params['EnameId']))
		{
			$where[] = 'EnameId = ?';
			$bindParams[] = $params['EnameId'];
			$bindType .= 'i';
		}
		if(isset($params['Status']))
		{
			$where[] = 'Status = ?';
			$bindParams[] = $params['Status'];
			$bindType .= 'i';
		}
		if(isset($params['TemplateUserName']))
		{
			$where[] = 'TemplateUserName = ?';
			$bindParams[] = $params['TemplateUserName'];
			$bindType .= 's';
		}		
		if(isset($params['TemplateType']))
		{
			$where[] = 'TemplateType = ?';
			$bindParams[] = $params['TemplateType'];
			$bindType .= 'i';
		}		
		if(isset($params['CnStatus']))
		{
			$where[] = 'CnStatus = ?';
			$bindParams[] = $params['CnStatus'];
			$bindType .= 'i';
		}
		if(isset($params['IsShow']))
		{
			$where[] = 'IsShow = ?';
			$bindParams[] = $params['IsShow'];
			$bindType .= 'i';
		}		
		if(isset($params['in']))
		{
			$key = array_keys($params['in']);
			$wen = trim(str_repeat('?,',count($params['in'][$key[0]])),',');
			$where[] = $key[0].' in (' . $wen.')';
			foreach($params['in'][$key[0]] as $val)
			{
				$binType .= is_string($val) ? 's': 'i';
				$bindParams[] = $val;
			}
		}
		$where = implode(' and ',$where);
		$where .= $limit ? ' limit '.$limit : '';
		$query = 'select * from ' . $this->tableName . ' where '.$where;
		return $this->select($query, $bindType, array_values($bindParams));
	}

}

<?php
namespace models\manage\queue;
use \core\ModBase;
class TaskMod extends ModBase
{
	private $tableName;

	function __construct($queType = 'sms')
	{
		parent::__construct('queue');
		$this->tableName = 'e_tasks';
	}

	/**
	 * 添加批量任务
	 * @param array $data function enameId title data priority total status created hidden
	 * @return int|boolean
	 */
	public function addTasks($data)
	{
		$data['data'] = json_encode($data['data']);
		return $this->add('insert into ' . $this->tableName . '(`function`,`enameId`,`title`,`data`,`priority`,`total`,`cancelTotal`,`successfulTotal`,`failedTotal`,`status`,`created`,`hidden`) values(?,?,?,?,?,?,?,?,?,?,?,?)', "sissiiiiiisi", array(
				$data['function'], $data['enameId'], $data['title'], $data['data'], $data['priority'], $data['total'],
				0, 0, 0, $data['status'], $data['created'], $data['hidden']));
	}
}

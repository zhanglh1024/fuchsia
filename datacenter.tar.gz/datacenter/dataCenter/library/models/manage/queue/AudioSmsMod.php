<?php
namespace models\manage\queue;
use \core\ModBase;
class AudioSmsMod extends ModBase
{
	private $tableName;

	function __construct($queType = 'audiosms')
	{
		parent::__construct('queue');
		$this->tableName = 'e_queue_' . $queType . '_details';
	}
	
	/**
	 * 添加语音队列信息
	 * @param array $data
	 * @return int|boolean
	 */
	public function newQueue($data)
	{
		$query = 'insert into ' . $this->tableName . '(`function`,`enameId`,`taskId`,`priority`,`repeat`,`templateId`,`phone`,`data`,`status`,`created`,`completed`) values(?,?,?,?,?,?,?,?,?,?,?)';
		return $this->add($query, "siiiisssiss", array($data['function'], $data['enameId'], $data['taskId'],
				$data['priority'], $data['repeat'], $data['templateId'], $data['phone'], $data['data'],
				$data['status'], $data['created'], $data['completed']));
	}
}

<?php
namespace models\manage\queue;
use \core\ModBase;
class SmsMod extends ModBase
{
	private $tableName;

	function __construct($queType = 'sms')
	{
		parent::__construct('queue');
		$this->tableName = 'e_queue_' . $queType . '_details';
	}
	
	/**
	 * 添加实时发送短信信息
	 * @param array $data
	 * @return int|bollean
	 */
	public function addSms($data)
	{
		$createTime = empty($data['createTime']) ? date('Y-m-d H:i:s') : $data['createTime'];
		$receiveTime = empty($data['receiveTime']) ? '0000-00-00 00:00:00' : $data['receiveTime'];
		$status = empty($data['status']) ? '0' : $data['status'];
		$msgid = empty($data['msgid']) ? '0' : $data['msgid'];
		$orderno = empty($data['orderno']) ? '0' : $data['orderno'];
		$query = 'insert into e_sms(`EnameId`,`TemplateId`,`Phone`,`Data`,`Status`,`CreateTime`,`ReceiveTime`,`Msgid`,`Orderno`) values(?,?,?,?,?,?,?,?,?)';
		return $this->add($query, "isssissss", array($data['enameId'], $data['templateId'], $data['phone'],
				$data['data'], $status, $createTime, $receiveTime, $msgid, $orderno));
	}
	
	/**
	 * 添加短信队列信息
	 * @param array $data
	 * @return int|bollean
	 */
	public function newQueue($data)
	{
		$query = 'insert into ' . $this->tableName . '(`function`,`enameId`,`taskId`,`priority`,`repeat`,`templateId`,`phone`,`data`,`status`,`created`,`completed`) values(?,?,?,?,?,?,?,?,?,?,?)';
		return $this->add($query, "siiiisssiss", array($data['function'], $data['enameId'], $data['taskId'],
				$data['priority'], $data['repeat'], $data['templateId'], $data['phone'], $data['data'],
				$data['status'], $data['created'], $data['completed']));
	}
}

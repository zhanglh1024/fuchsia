<?php
namespace models\manage\queue;
use \core\ModBase;
class TaskDetMod extends ModBase
{
	private $tableName;

	function __construct($queType = 'sms')
	{
		parent::__construct('queue');
		$this->tableName = 'e_queue_tasks_details';
	}

	/**
	 * 添加批量任务详情
	 * @param array $data
	 * @return int|boolean
	 */
	public function newQueue($data)
	{
		return $this->add('insert into ' . $this->tableName . '(`function`,`enameId`,`taskId`,`priority`,`repeat`,`data`,`status`,`created`,`completed`,`step`,`stepData`) values(?,?,?,?,?,?,?,?,?,?,?)', "siiiisissss", array(
				$data['function'], $data['enameId'], $data['taskId'], $data['priority'], $data['repeat'],
				$data['data'], $data['status'], $data['created'], $data['completed'], '', ''));
	}
}

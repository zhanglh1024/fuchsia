<?php
namespace models\manage\queue;
use \core\ModBase;
class MailMod extends ModBase
{
	private $tableName;

	function __construct($queType = 'mail')
	{
		parent::__construct('queue');
		$this->tableName = 'e_queue_' . $queType . '_details';
	}

	public function newQueue($data)
	{
		$query = 'insert into ' . $this->tableName . '(`function`,`enameId`,`taskId`,`priority`,`repeat`,`templateId`,`email`,`data`,`status`,`created`,`completed`,`fromMail`) values(?,?,?,?,?,?,?,?,?,?,?,?)';
		return $this->add($query, "siiiisssiiis", array($data['function'], $data['enameId'], $data['taskId'],
				$data['priority'], $data['repeat'], $data['templateId'], $data['email'], $data['data'],
				$data['status'], $data['created'], $data['completed'],
				isset($data['frommail']) ? $data['frommail'] : ''));
	}
}

<?php
namespace models\manage\finance;
use \core\ModBase;
class FinancesMod extends FinMod
{
	private $tableName;

	function __construct()
	{
		parent::__construct();
		$this->tableName = 'e_finances';
	}

	/**
	 * 初始化用户财务信息
	 * @param int $enameId
	 * @return int|boolean
	 */
	public function addFinanceInfo($enameId)
	{
		return $this->add("insert into $this->tableName(EnameId) values(?)", 'i', array($enameId));
	}

	/**
	 * 获取用户财务信息
	 * @param int $enameId
	 * @return array
	 */
	public function getFinanceInfo($enameId)
	{
		return $this->getRow("select * from $this->tableName where EnameId = ?", "i", array($enameId));
	}

	/**
	 * 扣款时先冻结款项，如果是0元直接返回true表示已经处理了, 
	 * @param int $enameId
	 * @param array $data p对公款 u不可提现 w可提现 m保证金
	 * @param boolean $isForFreezes 为false则直接扣款（不放入冻结记录）
	 * @return boolean
	 */
	public function subFinanceInMoney($enameId, $data, $isForFreezes = TRUE)
	{
		$p = empty($data['p']) ? 0 : $data['p'];
		$u = empty($data['u']) ? 0 : $data['u'];
		$w = empty($data['w']) ? 0 : $data['w'];
		$m = empty($data['m']) ? 0 : $data['m'];
		$allMoney = $p + $w + $u + $m;
		if(empty($allMoney))
		{
			return TRUE;
		}
		$this->clear();
		$this->finWhereSql("EnameId = ?", $enameId);
		if(!empty($p))
		{
			$this->finSetSql("PublicMoney = PublicMoney - ?", $p, "d");
			$this->finWhereSql("PublicMoney >= ?", $p, "d");
		}
		if(!empty($u))
		{
			$this->finSetSql("UnWithdrawalMoney = UnWithdrawalMoney - ?", $u, "d");
			$this->finWhereSql("UnWithdrawalMoney >= ?", $u, "d");
		}
		if(!empty($w))
		{
			$this->finSetSql("WithdrawalMoney = WithdrawalMoney - ?", $w, "d");
			$this->finWhereSql("WithdrawalMoney >= ?", $w, "d");
		}
		if(!empty($m))
		{
			$this->finSetSql("MarginMoney = MarginMoney - ?", $m, "d");
			$this->finWhereSql("MarginMoney >= ?", $m, "d");
		}
		if(TRUE === $isForFreezes)
		{
			$this->finSetSql("FreezeMoney = FreezeMoney + ?", $allMoney, "d");
		}
		return $this->update("update $this->tableName set " . implode(',', $this->setSql['set']) . " where " . implode(' and ', $this->whereSql['where']), $this->setSql['setExt'] . $this->whereSql['whereExt'], array_merge($this->setSql['setVal'], $this->whereSql['whereVal']),true);
	}

	/**
	 * 退回冻结中的款项，如果是0元直接返回true表示已经处理了
	 * 注意：保证金退款特殊情况：退款到可提现金额里
	 * @param int $enameId
	 * @param array $data p对公款 u不可提现 w可提现 m保证金
	 * @return boolean
	 */
	public function setFinanceInfoForFreezesBack($enameId, $data)
	{
		$p = empty($data['p']) ? 0 : $data['p'];
		$u = empty($data['u']) ? 0 : $data['u'];
		$w = empty($data['w']) ? 0 : $data['w'];
		$m = empty($data['m']) ? 0 : $data['m'];
		$allMoney = $p + $w + $u + $m;
		if(empty($allMoney))
		{
			return TRUE;
		}
		$this->clear();
		$this->finWhereSql("EnameId = ?", $enameId);
		if(!empty($p))
		{
			$this->finSetSql("PublicMoney = PublicMoney + ?", $p, "d");
		}
		if(!empty($u))
		{
			$this->finSetSql("UnWithdrawalMoney = UnWithdrawalMoney + ?", $u, "d");
		}
		if(!empty($w) || !empty($m))
		{
			$this->finSetSql("WithdrawalMoney = WithdrawalMoney + ? + ?", array($w, $m), 'dd');
		}
		$this->finSetSql("FreezeMoney = FreezeMoney - ?", $allMoney, "d");
		$this->finWhereSql("FreezeMoney >= ?", $allMoney, "s");//d类型时会产生浮点精度异常 比如472.65 。
		return $this->update("update $this->tableName set " . implode(',', $this->setSql['set']) . " where " . implode(' and ', $this->whereSql['where']), $this->setSql['setExt'] . $this->whereSql['whereExt'], array_merge($this->setSql['setVal'], $this->whereSql['whereVal']),true);
	}

	/**
	 * 扣款成功时,释放冻结款,将消费统计到用户财务信息，如果是0元直接返回true表示已经处理了
	 * @param int $enameId
	 * @param array $data p u w m consumeMoney tradingPayMoney totalScore
	 * @return boolean
	 */
	public function setFinanceInfoForFreezesClear($enameId, $data)
	{
		$p = empty($data['p']) ? 0 : $data['p'];
		$u = empty($data['u']) ? 0 : $data['u'];
		$w = empty($data['w']) ? 0 : $data['w'];
		$m = empty($data['m']) ? 0 : $data['m'];
		$allMoney = $p + $w + $u + $m;
		if(empty($allMoney))
		{
			return TRUE;
		}
		$this->clear();
		//update e_finances set FreezeMoney = FreezeMoney - ?,TradingPayMoney = TradingPayMoney + ? where EnameId = ? and FreezeMoney >= ?
		$consumeMoney = empty($data['consumeMoney']) ? 0 : $data['consumeMoney'];
		$tradingPayMoney = empty($data['tradingPayMoney']) ? 0 : $data['tradingPayMoney'];
		$totalScore = empty($data['totalScore']) ? 0 : $data['totalScore'];
		$setSql = array();
		$whereSql[] = "EnameId = " . $enameId;
		if(!empty($allMoney))
		{
			$setSql[] = "FreezeMoney = FreezeMoney - " . $allMoney;
			$whereSql[] = "FreezeMoney >= " . $allMoney;
		}
		if(!empty($consumeMoney))
		{
			$setSql[] = "ConsumeMoney = ConsumeMoney + " . $consumeMoney;
		}
		if(!empty($tradingPayMoney))
		{
			$setSql[] = "TradingPayMoney = TradingPayMoney + " . $tradingPayMoney;
		}
		if(!empty($totalScore))
		{
			$setSql[] = "TotalScore = TotalScore + " . $totalScore;
		}
		if(!empty($totalScore))
		{
			$setSql[] = "AllScore = AllScore + " . $totalScore;
		}
		return $this->update("update $this->tableName set " . implode(',', $setSql) . " where " . implode(' and ', $whereSql), "", array(), true);
	}

	/**
	 * 添加入款金额（包括交易收入和用户充值），如果是0元直接返回true表示已经处理了
	 * @param int $enameId
	 * @param array $data p u w m depositMoney充值入款金额 tradingIncomeMoney交易收入金额 invoiceAmount可开发票金额
	 * @return boolean
	 */
	public function addFinanceInMoney($enameId, $data)
	{
		$p = empty($data['p']) ? 0 : $data['p'];
		$u = empty($data['u']) ? 0 : $data['u'];
		$w = empty($data['w']) ? 0 : $data['w'];
		$m = empty($data['m']) ? 0 : $data['m'];
		$allMoney = $p + $w + $u + $m;
		if(empty($allMoney))
		{
			return TRUE;
		} 
		$this->clear();
		$depositMoney = empty($data['depositMoney']) ? 0 : $data['depositMoney'];
		$tradingIncomeMoney = empty($data['tradingIncomeMoney']) ? 0 : $data['tradingIncomeMoney'];
		$invoiceAmount = empty($data['invoiceAmount']) ? 0 : $data['invoiceAmount'];
		$this->finWhereSql("EnameId = ?", $enameId);
		if(!empty($p))
		{
			$this->finSetSql("PublicMoney = PublicMoney + ?", $p, "d");
		}
		if(!empty($w))
		{
			$this->finSetSql("WithdrawalMoney = WithdrawalMoney + ?", $w, "d");
		}
		if(!empty($u))
		{
			$this->finSetSql("UnWithdrawalMoney = UnWithdrawalMoney + ?", $u, "d");
		}
		if(!empty($m))
		{
			$this->finSetSql("MarginMoney = MarginMoney + ?", $m, "d");
		}
		if(!empty($depositMoney))
		{
			$this->finSetSql("DepositMoney = DepositMoney + ?", $depositMoney, "d");
		}
		if(!empty($tradingIncomeMoney))
		{
			$this->finSetSql("TradingIncomeMoney = TradingIncomeMoney + ?", $tradingIncomeMoney, "d");
		}
		if(!empty($invoiceAmount))
		{
			$this->finSetSql("InvoiceAmount = InvoiceAmount + ?", $invoiceAmount, "d");
		}
		return $this->update("update $this->tableName set " . implode(',', $this->setSql['set']) . " where " . implode(' and ', $this->whereSql['where']), $this->setSql['setExt'] . $this->whereSql['whereExt'], array_merge($this->setSql['setVal'], $this->whereSql['whereVal']),true);
	}
	
	/**
	 * 扣积分数
	 * @param int $scoreNum
	 * @param int $enameId
	 * @return boolean
	 */
	public function subScore($scoreNum, $enameId)
	{
		if(empty($scoreNum))
		{
			return FALSE;
		}
		$scoreNum = intval($scoreNum);
		if($scoreNum <= 0)
		{
			return FALSE;
		}
		return $this->update("update $this->tableName set TotalScore = TotalScore - ? where `EnameId` = ?", "ii", array($scoreNum, $enameId));
	}
	
	/**
	 * 增加积分数
	 * @param int $scoreNum
	 * @param int $enameId
	 * @return boolean
	 */
	public function addScore($scoreNum, $enameId)
	{
		if(empty($scoreNum))
		{
			return FALSE;
		}
		$scoreNum = intval($scoreNum);
		if($scoreNum <= 0)
		{
			return FALSE;
		}
		return $this->update("update $this->tableName set TotalScore = TotalScore + ?, AllScore = AllScore + ? where `EnameId` = ?", "iii", array($scoreNum, $scoreNum, $enameId));
	}

	/**
	 * 前台-联合查询入款和消费总数数
	 * @param string $sqlWhere
	 * @return int
	 */
	public function getFinanceAllCount($data)
	{
		$total = 0;
		$sqlWherein = $this->getSqlWhereIn($data);
		$sqlWhereout = $this->getSqlWhereOut($data);
		$byYear = !empty($data['byYear']) && is_numeric($data['byYear']) ? $data['byYear'] : false;
		$byYear = $this->setTableName($byYear);
		$tableNameOut = 'e_finance_out' . $byYear;
		$tableNameIn = 'e_finance_in' . $byYear;
		$sql = "select count(*) as total from $tableNameIn ".$sqlWherein['sqlwhere'] ;
		$sql .= " UNION ALL select count(*) as total from $tableNameOut ".$sqlWhereout['sqlwhere'];
		$bindType = $sqlWherein['bindType'] . $sqlWhereout['bindType'];
		$params = array_merge($sqlWherein['param'],$sqlWhereout['param']);
		$return = $this->select($sql,$bindType,$params);
		foreach($return as $value)
		{
			$total += $value['total'];
		}
		return $total;
	}
	/**
	 * 前台-联合查询入款和消费记录
	 * @param string $sqlWhere
	 * @return int
	 */
	public function getFinanceAll($data)
	{
		$total = 0;
		$sqlWherein = $this->getSqlWhereIn($data);
		$sqlWhereout = $this->getSqlWhereOut($data);
		$byYear = !empty($data['byYear']) && is_numeric($data['byYear']) ? $data['byYear'] : false;
		$byYear = $this->setTableName($byYear);
		$tableNameOut = 'e_finance_out' . $byYear;
		$tableNameIn = 'e_finance_in' . $byYear;
		$offset = empty($data['offset']) ? 0 : $data['offset'];
		$num = empty($data['num']) ? 10 : $data['num'];
		$sql = "select OutId as fid,CreateDate,OutMoney as Money,CurrentMoney,OutType as Type,LinkDomain,OutRemark as Remark,1 as FeeMoney,PromoMoney,ProductOptions,1 as recordType from $tableNameOut ".$sqlWhereout['sqlwhere'];
		$sql .= " UNION select InId as fid,CreateDate,InMoney as Money,CurrentMoney,InType as Type,LinkDomain,InRemark as Remark,FeeMoney,2 as PromoMoney,2 as ProductOptions,2 as recordType from $tableNameIn ".$sqlWherein['sqlwhere']." order by CreateDate DESC,fid desc limit $offset,$num";
		$bindType = $sqlWherein['bindType'] . $sqlWhereout['bindType'];
		$params = array_merge($sqlWherein['param'],$sqlWhereout['param']);
		$return = $this->select($sql,$bindType,$params);
		return $return;
	}
	/**
	 * 前台-获取入款SQL条件
	 */
    private function getSqlWhereIn($data)
	{
		$sqlWhere = array();
		$bindType = '';
		$sqlWherestsr = '';
		$params = array();
		if(isset($data['enameId']) && !empty($data['enameId']))
		{
			$sqlWhere[] = 'EnameId = ?';
			$bindType .= 'i';
			$params[] = $data['enameId'];
		}
		if(isset($data['startDate']) && !empty($data['startDate']))
		{
			$sqlWhere[] = 'CreateDate >= ?';
			$bindType .= 's';
			$params[] = $data['startDate'].'00:00:00';
		}
		if(isset($data['endDate']) && !empty($data['endDate']))
		{
			$sqlWhere[] = 'CreateDate <= ?';
			$bindType .= 's';
			$params[] = $data['endDate']. " 23:59:59";
		}
		if(isset($data['type']) && !empty($data['type']))
		{
			$sqlWhere[] = 'InType = ?';
			$bindType .= 'i';
			$params[] = $data['type'];
		}
		if(isset($data['moneyType']) && !empty($data['moneyType']))
		{
			$sqlWhere[] = 'MoneyType = ?';
			$bindType .= 'i';
			$params[] = $data['moneyType'];
		}
		if(isset($data['orderId']) && !empty($data['orderId']))
		{
			$sqlWhere[] = 'CreateDate <= ?';
			$bindType .= 's';
			$params[] = $data['endDate']. " 23:59:59";
			$this->finWhereSql("OrderId = ?", $data['orderId']);
		}
		if(isset($data['uniqueId']) && !empty($data['uniqueId']))
		{
			$sqlWhere[] = 'uniqueId = ?';
			$bindType .= 'i';
			$params[] = $data['searchKey'];
			$this->finWhereSql("", $data['uniqueId']);
		}
		if(isset($data['searchKey']) && !empty($data['searchKey']))
		{
			$sqlWhere[] = "  (InRemark like '%" . $data['searchKey'] . "%' or LinkDomain like '%" . $data['searchKey'] . "%')";
		}
		$sqlWherestsr = ' where '. implode(' and ', $sqlWhere);
		$this->isHistory = !empty($data['byYear']) && is_numeric($data['byYear']) ? $data['byYear'] : FALSE;
		return array('bindType'=>$bindType,'param'=>$params,'sqlwhere'=>$sqlWherestsr);
	}
	/**
	 * 前台-获取消费SQL条件
	 */
	private function getSqlWhereOut($data)
	{
		$sqlWhere = array();
		$bindType = '';
		$sqlWherestsr = '';
		$params = array();
		if(isset($data['enameId']) && !empty($data['enameId']))
		{
			$sqlWhere[] = 'EnameId = ?';
			$bindType .= 'i';
			$params[] = $data['enameId'];
		}
		if(isset($data['startDate']) && !empty($data['startDate']))
		{
			$sqlWhere[] = 'CreateDate >= ?';
			$bindType .= 's';
			$params[] = $data['startDate'].'00:00:00';
		}
		if(isset($data['endDate']) && !empty($data['endDate']))
		{
			$sqlWhere[] = 'CreateDate <= ?';
			$bindType .= 's';
			$params[] = $data['endDate']. " 23:59:59";
		}
		if(isset($data['type']) && !empty($data['type']))
		{
			$sqlWhere[] = 'OutType = ?';
			$bindType .= 'i';
			$params[] = $data['type'];
		}
		if(isset($data['moneyType']) && !empty($data['moneyType']))
		{
			$sqlWhere[] = 'MoneyType = ?';
			$bindType .= 'i';
			$params[] = $data['moneyType'];
		}
		if(isset($data['orderId']) && !empty($data['orderId']))
		{
			$sqlWhere[] = 'CreateDate <= ?';
			$bindType .= 's';
			$params[] = $data['endDate']. " 23:59:59";
			$this->finWhereSql("OrderId = ?", $data['orderId']);
		}
		if(isset($data['uniqueId']) && !empty($data['uniqueId']))
		{
			$sqlWhere[] = 'uniqueId = ?';
			$bindType .= 'i';
			$params[] = $data['searchKey'];
			$this->finWhereSql("", $data['uniqueId']);
		}
		if(isset($data['searchKey']) && !empty($data['searchKey']))
		{
			$sqlWhere[] = "  (LinkDomain like '%" . $data['searchKey'] . "%' or OutRemark like '%" . $data['searchKey'] . "%')";
		}
		$sqlWherestsr = ' where '. implode(' and ', $sqlWhere);
		$this->isHistory = !empty($data['byYear']) && is_numeric($data['byYear']) ? $data['byYear'] : FALSE;
		return array('bindType'=>$bindType,'param'=>$params,'sqlwhere'=>$sqlWherestsr);
	}
	
	/**
	 * 处理表后缀
	 * @param int|string $byYear
	 * @return string
	 */
	private function setTableName($byYear = false)
	{
		$history = '';
		if($byYear && $byYear <= date('Y'))
		{
			$history = $history.$byYear;
		}
		else 
		{
			$history = $history.date('Y');
		}
		return $history;
	}
}

<?php
namespace models\manage\finance;
use \core\ModBase;
class FinMod extends ModBase
{
	public $setSql = array('set' => '', 'setVal' => array(), 'setExt' => '');
	public $whereSql = array('where' => '', 'whereVal' => array(), 'whereExt' => '');
	
	private static $instances;
	
	private $beginTrans = false;

	function __construct($db = 'finance')
	{
		parent::__construct($db);
	}

	function __destruct()
	{
		//防止程序中途退出事务还开启，还在锁表
		$this->transRollback();
		parent::__destruct();
	}
	
	/**
	 * set语句组装
	 * @param string $set
	 * @param string|number|array $setVal
	 * @param string $setType
	 */
	public function finSetSql($set, $setVal, $setType = 'i')
	{
		$this->setSql['set'][] = $set;
		if(is_array($setVal))
		{
			$this->setSql['setVal'] = array_merge($this->setSql['setVal'], $setVal);
		}
		else
		{
			$this->setSql['setVal'][] = $setVal;
		}
		$this->setSql['setExt'] .= $setType;
	}

	/**
	 * where语句组装
	 * @param string $where
	 * @param string|number|array $whereVal
	 * @param string $whereType
	 */
	public function finWhereSql($where, $whereVal, $whereType = 'i')
	{
		$this->whereSql['where'][] = $where;
		if(is_array($whereVal))
		{
			$this->whereSql['whereVal'] = array_merge($this->whereSql['whereVal'], $whereVal);
		}
		else
		{
			$this->whereSql['whereVal'][] = $whereVal;
		}
		$this->whereSql['whereExt'] .= $whereType;
	}
	
	/**
	 * 清除语句组装
	 */
	public function clear()
	{
		$this->setSql = array('set' => '', 'setVal' => array(), 'setExt' => '');
		$this->whereSql = array('where' => '', 'whereVal' => array(), 'whereExt' => '');
	}
	/**
	 * 获取连接DB
	 */
	public static function getDB()
	{
		if(!(isset(self::$instances) && is_object(self::$instances)))
		{
			self::$instances = new self();
		}
		return self::$instances;
	} 
	/**
	 * 开启事务
	 */
	public function transBegin()
	{
		
		if ( $this ==self::$instances && !$this->beginTrans )
		{
			$this->beginTrans = TRUE;
			$this -> query( 'SET AUTOCOMMIT=0');
			$this -> query( 'START TRANSACTION');
		}
	}
	/**
	 * 提交事务
	 */
	public function transCommit()
	{
		if( $this ==self::$instances && $this->beginTrans )
		{
			$this -> query('COMMIT');
			$this -> query('SET AUTOCOMMIT=1');
			$this->beginTrans = false;
		}
	}
	/**
	 * 回滚事务
	 */
	public function transRollback()
	{
		if( $this ==self::$instances && $this->beginTrans )
		{
			$this -> query('ROLLBACK');
			$this -> query('SET AUTOCOMMIT=1');
			$this->beginTrans = false;
		}
	}
	/**
	 * 简单查询  开启事务才查询，用于事务和锁表
	 */
	public function query($sql)
	{
		if( $this ==self::$instances && $this->beginTrans )
		{
			$this->db->query($sql);
		}
	}
}
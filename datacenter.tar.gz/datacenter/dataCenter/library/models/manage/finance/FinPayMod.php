<?php
namespace models\manage\finance;
use \core\ModBase;
class FinPayMod extends FinMod
{
	private $tableName;
	private $isHistory = FALSE;

	public function __construct()
	{
		parent::__construct('finance');
		$this->tableName = "e_finance_paycenter";
	}

	private function setTableName($year = false)
	{
		$this->tableName = "e_finance_paycenter";
		if($year && $year <= date('Y'))
		{
			$this->tableName = $this->tableName.$year;
		}
		else
		{
			$this->tableName = $this->tableName.date('Y');
		}
	}
	
	/**
	 * 根据data组装where 
	 * @param array $data
	 */
	public function getSqlWhere($data)
	{
		if(isset($data['enameId']) && !empty($data['enameId']))
		{
			$this->finWhereSql("EnameId = ?", $data['enameId']);
		}
		if(isset($data['startDate']) && !empty($data['startDate']))
		{
			$this->finWhereSql("BeginTime >= ?", $data['startDate'], 's');
		}
		if(isset($data['endDate']) && !empty($data['endDate']))
		{
			$this->finWhereSql("BeginTime <= ?", $data['endDate'], 's');
		}
		if(isset($data['isSuccess']) && $data['isSuccess'] >= 1)
		{
			$this->finWhereSql("IsSuccess = ?", $data['isSuccess']);
		}
		if(isset($data['randId']) && !empty($data['randId']))
		{
			$this->finWhereSql("RandId = ?", $data['randId']);
		}
		if(isset($data['payId']) && !empty($data['payId']))
		{
			$this->finWhereSql("PayId = ?", $data['payId']);
		}
		if(isset($data['linkName']) && !empty($data['linkName']))
		{
			$this->finWhereSql("LinkName = ?", $data['linkName'], 's');
		}
		$this->isHistory = !empty($data['byYear']) && is_numeric($data['byYear']) ? $data['byYear'] : FALSE;
	}

	/**
	 * 获取用户的在线充值信息
	 * @param array $data
	 * @return array|boolean
	 */
	public function getPayInfo($data, $isHistory = false)
	{
		$this->clear();
		$this->getSqlWhere($data);
		$data['offset'] = empty($data['offset']) ? 0 : $data['offset'];
		$data['num'] = empty($data['num']) ? 1 : $data['num'];
		$year = is_numeric($isHistory) ? $isHistory : $this->isHistory;
		self::setTableName($year);
		return $this->select("select * from $this->tableName " . (!empty($this->whereSql['where']) ? "where " . implode(' and ', $this->whereSql['where']) : "") . " order by PayId desc limit ?,?", $this->whereSql['whereExt'] . "ii", array_merge($this->whereSql['whereVal'], array(
				$data['offset'], $data['num'])));
	}

	/**
	 * 获取用户的在线充值信息
	 * @param int $payId
	 * @param int $isHistory
	 * @return array|boolean
	 */
	public function getPayInfoPayId($payId, $isHistory = FALSE)
	{
		$year = is_numeric($isHistory) ? $isHistory : false;
		self::setTableName($year);
		return $this->getRow("select * from $this->tableName where PayId = ?", "i", array($payId));
	}

	/**
	 * 获取用户的在线充值记录数
	 * @param array $data
	 * @return int|boolean
	 */
	public function getPayCount($data)
	{
		$this->clear();
		$this->getSqlWhere($data);
		self::setTableName($this->isHistory);
		$rs = $this->getRow("select count(*) as num from $this->tableName " . (!empty($this->whereSql['where']) ? "where " . implode(' and ', $this->whereSql['where']) : ""), $this->whereSql['whereExt'], $this->whereSql['whereVal']);
		if(FALSE !== $rs)
		{
			return $rs['num'];
		}
		return FALSE;
	}

	/**
	 * 添加用户在线充值记录信息
	 * @param array $data
	 * @return boolean
	 */
	public function addPayInfo($data)
	{
		self::setTableName();
		$transId = empty($data['transId']) ? 0 : $data['transId'];
		$domain = empty($data['domain']) ? '' : $data['domain'];
		$tradeNo = empty($data['tradeNo']) ? '' : $data['tradeNo'];
		$linkName = empty($data['linkName']) ? '' : $data['linkName'];
		$endTime = empty($data['endTime']) ? '' : $data['endTime'];
		$responseUrl = empty($data['responseUrl']) ? '' : $data['responseUrl'];
		$requestUrl = empty($data['requestUrl']) ? '' : $data['requestUrl'];
		$clientIp = empty($data['clientIp']) ? '' : $data['clientIp'];
		return $this->add("insert into $this->tableName(RandId,TradeNo,RechargeMoney,PayType,BeginTime,
				EnameId,LinkName,IsSuccess,EndTime,MoneyType,ResponseUrl,RequestUrl,ClientIp,TransId,Domain) 
				values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", "isdisisisisssis", array($data['randId'], $tradeNo,
				$data['rechargeMoney'], $data['payType'], $data['beginTime'], $data['enameId'], $linkName,
				$data['isSuccess'], $endTime, $data['moneyType'], $responseUrl, $requestUrl,
				$clientIp, $transId, $domain));
	}

	/**
	 * 更新在线充值信息
	 * @param array $data
	 * @return boolean
	 */
	public function setPayInfo($data, $isHistory = false)
	{
		if(count($data) > 2)
		{
			if(!isset($data['tradeNo']) && !isset($data['isSuccess']) && !isset($data['requestUrl']) && !isset($data['endTime']))
			{
				return FALSE;
			}
			$this->clear();
			if(isset($data['tradeNo']))
			{
				$this->finSetSql("TradeNo = ?", $data['tradeNo'], "s");
			}
			if(isset($data['isSuccess']))
			{
				if($data['isSuccess'] == 1)
				{
					$this->finWhereSql("IsSuccess != ?", 1);
				}
				$this->finSetSql("IsSuccess = ?", $data['isSuccess']);
			}
			if(isset($data['requestUrl']))
			{
				$this->finSetSql("RequestUrl = ?", $data['requestUrl'], "s");
			}
			if(isset($data['endTime']))
			{
				$this->finSetSql("EndTime = ?", $data['endTime'], "s");
			}
			if(! empty($data['linkName']))
			{
				$this->finSetSql("LinkName = ?", $data['linkName'], "s");
			}
			$this->finWhereSql("PayId = ?", $data['payId']);
			$year = is_numeric($isHistory) ? $isHistory : false;
			self::setTableName($year);
			return $this->update("update $this->tableName set " . implode(',', $this->setSql['set']) . " where " . implode(' and ', $this->whereSql['where']), $this->setSql['setExt'] . $this->whereSql['whereExt'], array_merge(
					$this->setSql['setVal'], $this->whereSql['whereVal']),true);
		}
		return FALSE;
	}

	/**
	 * 更新在线充值信息(返回影响集)viyatodo
	 * @param array $data
	 * @return boolean
	 */
	public function setPayInfoReturnRows($data)
	{
		$this->setPayInfo($data);
	}

	/**
	 * 更新在线充值信息（保证金充值）
	 * @param array $data
	 * @return boolean
	 */
	public function setMarginPayInfo($data, $isHistory = false)
	{
		if(count($data) > 2)
		{
			if(!isset($data['payId']) && !isset($data['enameId']) && !isset($data['payType']) && !isset($data['linkName']))
			{
				return FALSE;
			}
			$this->clear();
			$payId = empty($data['payId']) ? 0 : $data['payId'];
			$enameId = empty($data['enameId']) ? 0 : $data['enameId'];
			$payType = is_numeric($data['payType']) ? $data['payType'] : '0';
			$this->finSetSql("PayType = ?", $payType, "i");
			if(isset($data['linkName']))
			{
				$this->finSetSql("LinkName = ?", $data['linkName'], "s");
			}
			if(!empty($data['rechargeMoney']))
			{
				$this->finSetSql("RechargeMoney = ?", $data['rechargeMoney'], "d");
			}
			if(!empty($data['isSuccess']))
			{
				$this->finSetSql("IsSuccess = ?", $data['isSuccess']);
			}
			$this->finWhereSql("EnameId = ?", $enameId);
			$this->finWhereSql("PayId = ?", $payId);
			$year = is_numeric($isHistory) ? $isHistory : false;
			self::setTableName($year);
			return $this->update("update $this->tableName set " . implode(',', $this->setSql['set']) . " where " . implode(' and ', $this->whereSql['where']), $this->setSql['setExt'] . $this->whereSql['whereExt'], array(
					$this->setSql['setVal'], $this->whereSql['whereVal']));
		}
		return FALSE;
	}
	/**
	 * 更新在线支付记录(更新订单信息接口用)
	 * @param array $data
	 * @return boolean
	 */
	public function updateRecharge($data)
	{
		if(count($data) > 2)
		{
			if(!isset($data['tradeNo']) && !isset($data['isSuccess']) && !isset($data['requestUrl']) && !isset($data['endTime']) && !isset($data['randId']))
			{
				return FALSE;
			}
			$this->clear();
			$payId = empty($data['payId']) ? 0 : $data['payId'];
			$enameId = empty($data['enameId']) ? 0 : $data['enameId'];
			//$payType = is_numeric($data['payType']) ? $data['payType'] : '0';
			if(isset($data['tradeNo']))
			{
				$this->finSetSql("TradeNo = ?", $data['tradeNo'], "s");
			}
			if(isset($data['isSuccess']))
			{
				$this->finSetSql("isSuccess = ?", $data['isSuccess']);
			}
			if(isset($data['requestUrl']))
			{
				$this->finSetSql("RequestUrl = ?", $data['requestUrl'], "s");
			}
			if(isset($data['endTime']))
			{
				$this->finSetSql("EndTime = ?", $data['endTime'], "s");
			}
			if(isset($data['randId']))
			{
				$this->finSetSql("RandId = ?", $data['randId']);
			}
			$this->finWhereSql("PayId = ?", $data['payId']);
			self::setTableName();
			return $this->update("update $this->tableName set " . implode(',', $this->setSql['set']) . " where " . implode(' and ', $this->whereSql['where']), $this->setSql['setExt'] . $this->whereSql['whereExt'], array(
					$this->setSql['setVal'], $this->whereSql['whereVal']));
		}
		return FALSE;
	}
	
	/**
	 * 根据结束时间获取支付列表
	 * @param string $endTime
	 * @return array|boolean
	 */
	public function getPayListByEndTime($endTime)
	{
		self::setTableName();
		return $this->select("select * from $this->tableName where IsSuccess=1 and EndTime like '" . $data['endTime'] . "%'");
	}
	
	/**
	 * 根据交易号获取充值的订单
	 * @param int $enameId
	 * @param int $transId
	 * @param int $isSuccess
	 * @return array
	 * array|boolean
	 */
	public function getInfoByTransId($data, $isHistory = FALSE)
	{
		$this->clear();
		$this->finWhereSql("EnameId = ?", empty($data['enameId']) ? 0 : $data['enameId']);
		$this->finWhereSql("TransId = ?", empty($data['transId']) ? 0 : $data['transId']);
		if(!empty($data['isSuccess']))
		{
			$this->finWhereSql("IsSuccess = ?", $data['isSuccess']);
		}
		$year = is_numeric($isHistory) ? $isHistory : false;
		self::setTableName($year);
		return $this->select("select * from $this->tableName where " . implode(' and ', $this->whereSql['where']), $this->whereSql['whereExt'], $this->whereSql['whereVal']);
	}

	/**
	 * 根据用户的payId获取充值的订单
	 * @param array $data EnameId PayId isSuccess
	 * @return array|boolean
	 */
	public function getInfoByPayId($data, $isHistory = false)
	{
		$this->clear();
		if(!empty($data['enameId']))
		{
			$this->finWhereSql("EnameId = ?", $data['enameId']);
		}
		$this->finWhereSql("PayId = ?", empty($data['payId']) ? 0 : $data['payId']);
		if(!empty($data['isSuccess']))
		{
			$this->finWhereSql("IsSuccess = ?", $data['isSuccess']);
		}
		$year = is_numeric($isHistory) ? $isHistory : false;
		self::setTableName($year);
		return $this->select("select * from $this->tableName where " . implode(' and ', $this->whereSql['where']), $this->whereSql['whereExt'], $this->whereSql['whereVal']);
	}

	/**
	 * 根据PayId列表获取payList
	 * @param string $payIdArr
	 * @return array
	 */
	public function getPayListByPayIdArr($payIdArr, $isHistory = FALSE)
	{
		$year = is_numeric($isHistory) ? $isHistory : false;
		self::setTableName($year);
		$this->select("select PayId,RandId,TradeNo,BeginTime,PayType from $this->tableName where PayId in (?)", "s", $payIdArr);
	}
	
	/**
	 * 根据mobile和payId更新充值订单EnameId
	 */
	public function setPayInfoByMobile($data, $isHistory = false)
	{
		if(count($data) > 2)
		{
			if(!isset($data['payId']) || !isset($data['mobile']) || !isset($data['enameId']))
			{
				return FALSE;
			}
			$this->clear();
			$this->finSetSql("EnameId = ?", $data['enameId']);
			$this->finSetSql("LinkName = ?", "", "s");
			
			$this->finWhereSql("PayId = ?", $data['payId']);
			$this->finWhereSql("IsSuccess = ?", 1);
			$this->finWhereSql("LinkName = ?", $data['mobile'], 's');
			$year = is_numeric($isHistory) ? $isHistory : false;
			self::setTableName($year);
			return $this->update("update $this->tableName set " . implode(',', $this->setSql['set']) . " where " . implode(' and ', $this->whereSql['where']), $this->setSql['setExt'] . $this->whereSql['whereExt'], array_merge(
				$this->setSql['setVal'], $this->whereSql['whereVal']),true);
		}
		return FALSE;
	}
}

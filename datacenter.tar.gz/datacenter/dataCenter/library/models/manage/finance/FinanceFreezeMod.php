<?php
namespace models\manage\finance;
use \core\ModBase;
class FinanceFreezeMod extends FinMod
{
	private $tableName;

	function __construct()
	{
		parent::__construct();
		$this->tableName = 'e_finance_freezes';
	}
	
	public function getFinanceFreezeList($data,$limit=false)
	{
		$sql = self::getSql($data);
		list($where,$bindValue,$bindType) = $sql;
		$query = "select `Remark`,`FreezeMoney`,`FreezeTime` from  " . $this->tableName;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		$query .=' order by FreezeTime DESC';
		if($limit)
		{
			$query .=' limit '.$limit;
		}
		return $this->select($query, $bindType, $bindValue);
	}
	
	public function getFinanceFreezeCount($data)
	{
		$sql = self::getSql($data);
		list($where,$bindValue,$bindType) = $sql;
		$query = "select count(1) as total from  " . $this->tableName;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		return $this->getRow($query, $bindType, $bindValue);
	}
	
	private function getSql($params)
	{
		$where = $bindValue = array();
		$bindType = '';
		if(!empty($params['EnameId']))
		{
			$where[] = 'EnameId = ?';
			$bindValue[] = $params['EnameId'];
			$bindType .= 'i';
		}
		return array($where,$bindValue,$bindType);
	}
}
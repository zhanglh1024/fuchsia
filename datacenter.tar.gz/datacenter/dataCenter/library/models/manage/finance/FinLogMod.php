<?php
namespace models\manage\finance;
use \core\ModBase;
class FinLogMod extends FinMod
{
	private $tableName;

	function __construct()
	{
		parent::__construct();
		$this->tableName = 'e_finance_log';
	}

	/**
	 * 添加财务日志记录信息
	 * @param array $data
	 * @return boolean
	 */
	public function addFinanceLog($data)
	{
		$operatorId = empty($data['operatorId']) ? '9999' : $data['operatorId'];
		$logType = empty($data['logType']) ? '1' : $data['logType'];
		$isSuccess = empty($data['isSuccess']) ? '0' : $data['isSuccess'];
		$sendData = empty($data['sendData']) ? '' : $data['sendData'];
		$returnData = empty($data['returnData']) ? '' : $data['returnData'];
		$logDesc = empty($data['logDesc']) ? '' : $data['logDesc'];
		$method = empty($data['method']) ? '' : $data['method'];
		$level = empty($data['level']) ? '0' : $data['level'];
		$operatorIp = empty($data['operatorIp']) ? '' : $data['operatorIp'];
		$createTime = empty($data['createTime']) ? date('Y-m-d H:i:s') : $data['createTime'];
		$actionUrl = empty($data['actionUrl']) ? '' : $data['actionUrl'];
		return $this->add("insert into $this->tableName(LogType,OperatorId,LogDesc,Level,Method,CreateTime,SendData,ReturnData,OperatorIp,isSuccess,ActionUrl) values(?,?,?,?,?,?,?,?,?,?,?)", "iisisssssis", array(
				$logType, $operatorId, $logDesc, $level, $method, $createTime, $sendData, $returnData, $operatorIp,
				$isSuccess, $actionUrl));
	}
}

<?php
namespace models\manage\finance;
use \core\ModBase;
class FinInMod extends FinMod
{
	private $tableName;
	private $isHistory = FALSE;

	public function __construct()
	{
		parent::__construct();
		$this->tableName = "e_finance_in";
	}

	private function setTableName($year = false)
	{
		$this->tableName = "e_finance_in";
		if($year && $year <= date('Y'))
		{
			$this->tableName = $this->tableName.$year;
		}
		else
		{
			$this->tableName = $this->tableName.date('Y');
		}
	}
	
	/** 
	 * 获取用户的入款信息
	 * @param string $sqlWhere
	 * @param int $offset
	 * @param int $num
	 * @return array
	 */
	public function getFinanceIn($data)
	{
		$this->clear(); 
		$sqlWhere = $this->getSqlWhere($data);
		self::setTableName($this->isHistory);
		return $this->select("select * from $this->tableName where " . implode(' and ', $this->whereSql['where']) . $sqlWhere . " order by InId desc limit ?,?", $this->whereSql['whereExt'] . "ii", array_merge($this->whereSql['whereVal'], array(
				$data['offset'], $data['num'])));
	}

	public function getFinanceIn2($data)
	{
		$this->clear(); 
		$sqlWhere = $this->getSqlWhere($data);
		self::setTableName($this->isHistory);
		if(empty($this->whereSql['where']) && $sqlWhere)
		{
			return $this->select("select * from $this->tableName where " . $sqlWhere . " order by InId asc ", '',array());
		}
		if(!empty($this->whereSql['where']))
		{
			return $this->select("select * from $this->tableName where " . implode(' and ', $this->whereSql['where']) . $sqlWhere . " order by InId desc limit ?,?", $this->whereSql['whereExt'].'ii' , array_merge($this->whereSql['whereVal'], array(
				$data['offset'], $data['num'])));
		}
	}
	
	public function getMaxId()
	{
		self::setTableName();
		return $this->getRow("select max(InId) as maxid from ".$this->tableName, '', array());
	}
	
	public function getMixId()
	{ 
		self::setTableName();
		return $this->getRow("select min(InId) as minid from ".$this->tableName, '', array());
	}
	
	
	/**
	 * 添加用户入款记录信息
	 * @param array $data
	 * @return int|boolean
	 */
	public function addFinanceIn($data)
	{
		self::setTableName();
		$operator = empty($data['operator']) ? '' : $data['operator'];
		$enameId = empty($data['enameId']) ? '0' : $data['enameId'];
		$inMoney = empty($data['inMoney']) ? '0' : $data['inMoney'];
		$currentMoney = empty($data['currentMoney']) ? '0' : $data['currentMoney'];
		$moneyType = empty($data['moneyType']) ? '0' : $data['moneyType'];
		$inType = empty($data['inType']) ? '0' : $data['inType'];
		$payId = empty($data['payId']) ? '0' : $data['payId'];
		$linkEnameId = empty($data['linkEnameId']) ? '0' : $data['linkEnameId'];
		$orderId = empty($data['orderId']) ? '0' : $data['orderId'];
		$feeMoney = empty($data['feeMoney']) ? '0' : $data['feeMoney'];
		$inStatus = empty($data['inStatus']) ? '1' : $data['inStatus'];
		$inRemark = empty($data['inRemark']) ? '' : $data['inRemark'];
		$bankName = isset($data['bankName']) ? $data['bankName'] : 0;
		$inRemarkHide = isset($data['inRemarkHide']) ? $data['inRemarkHide'] : '';
		$linkDomain = isset($data['linkDomain']) ? $data['linkDomain'] : '';
		$taxPoint = empty($data['taxPoint']) ? '0' : $data['taxPoint'];
		$bankFeeMoney = empty($data['bankFeeMoney']) ? '0' : $data['bankFeeMoney'];
		$inTypeSon = empty($data['inTypeSon']) ? '0' : $data['inTypeSon'];
		$uniqueId = empty($data['uniqueId']) ? '0' : $data['uniqueId'];
		$registrarId = empty($data['registrarId']) ? '0' : $data['registrarId'];
		$createDate = date('Y-m-d H:i:s');
		return $this->add("insert into $this->tableName(EnameId,InMoney,CurrentMoney,MoneyType,InType,CreateDate,Operator,InStatus,InRemark,
				PayId,LinkEnameId,OrderId,FeeMoney,BankName,InRemarkHide,TaxPoint,BankFeeMoney,LinkDomain,inTypeSon,UniqueId,RegistarId) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", "iddiisiisiiidssddsiii", array(
				$enameId, $inMoney, $currentMoney, $moneyType, $inType, $createDate, $operator, $inStatus, $inRemark,
				$payId, $linkEnameId, $orderId, $feeMoney, $bankName, $inRemarkHide, $taxPoint, $bankFeeMoney,
				$linkDomain, $inTypeSon, $uniqueId, $registrarId));
	}
	
	/**
	 * 根据InId删除用户入款流水
	 * 充值失败的时候
	 */
	public function delFinanceIn($inId)
	{
		if(empty($inId))
		{
			return false;
		}
		return $this->delete("delete from $this->tableName where InId=?", 'i', array($inId));
	}
	
	
	/**
	 * 根据条件获取记录条数
	 */
	public function getFinanceInCount($data)
	{
		$this->clear();
		$sqlWhere = $this->getSqlWhere($data);
		self::setTableName($this->isHistory);
		return $this->select("select count(*) as sum from $this->tableName where " . implode(' and ', $this->whereSql['where']) . $sqlWhere , $this->whereSql['whereExt'], $this->whereSql['whereVal'],true);
	}
	/**
	 * 根据data组装where，如果时特殊sql则直接sql不做语法绑定
	 * @param array $data
	 * @return string
	 */
	private function getSqlWhere($data)
	{
		$sqlWhere = '';
		//目前财务定时使用到
		if(!empty($data['InId>']))
		{
			$sqlWhere .= " InId>= {$data['InId>']} ";;
		}
		if(!empty($data['InId<']))
		{
			$sqlWhere .= " and InId<= {$data['InId<']} ";;
		}
		if(!empty($data['enameId']))
		{
			$this->finWhereSql("EnameId = ?", $data['enameId']);
		}
		if(isset($data['startDate']) && !empty($data['startDate']))
		{
			$this->finWhereSql("CreateDate >= ?", $data['startDate'] . " 00:00:00", 's');
		}
		if(isset($data['endDate']) && !empty($data['endDate']))
		{
			$this->finWhereSql("CreateDate <= ?", $data['endDate'] . " 23:59:59", 's');
		}
		if(isset($data['type']) && !empty($data['type']))
		{
			$this->finWhereSql("InType = ?", $data['type']);
		}
		if(isset($data['moneyType']) && !empty($data['moneyType']))
		{
			$this->finWhereSql("MoneyType = ?", $data['moneyType']);
		}
		if(isset($data['orderId']) && !empty($data['orderId']))
		{
			$this->finWhereSql("OrderId = ?", $data['orderId']);
		}
		if(isset($data['uniqueId']) && !empty($data['uniqueId']))
		{
			$this->finWhereSql("uniqueId = ?", $data['uniqueId']);
		}
		if(isset($data['searchKey']) && !empty($data['searchKey']))
		{
			$sqlWhere .= " and (InRemark like '%" . $data['searchKey'] . "%' or LinkDomain like '%" . $data['searchKey'] . "%')";
		}
		if(isset($data['inRemark']) && !empty($data['inRemark']))
		{
			$sqlWhere .= " and inRemark = '" . $data['inRemark'] . "'";
		}
		if(isset($data['inRemark!=']) && !empty($data['inRemark!=']))
		{
			$sqlWhere .= " and inRemark != '" . $data['inRemark!='] . "'";
		}
		if(!empty($data['payId']))
		{
			$this->finWhereSql("PayId = ?", $data['payId']);
		}
		$this->isHistory = !empty($data['byYear']) && is_numeric($data['byYear']) ? $data['byYear'] : FALSE;
		return $sqlWhere;
	}
}

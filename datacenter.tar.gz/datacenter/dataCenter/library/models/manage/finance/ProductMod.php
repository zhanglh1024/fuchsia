<?php
namespace models\manage\finance;
use \core\ModBase;
class ProductMod extends FinMod
{
	private $tableName;
	private $jionTableName;

	function __construct()
	{
		parent::__construct('product');
		$this->tableName = 'e_products';
		$this->jionTableName = "e_products_price";
	}

	/**
	 * 根据产品类型获取产品信息
	 * @param int $productType
	 * @param int $userGroupId
	 * @return array|boolean
	 */
	public function getProductsByType($productType = FALSE, $userGroupId = 1)
	{
		$this->clear();
		if(is_array($productType))
		{
			$this->finWhereSql("a.ProductType in (?)", implode(',', $productType), 's');
		}
		elseif(is_numeric($productType))
		{
			$this->finWhereSql("a.ProductType = ?", $productType);
		}
		return $this->select("select * from $this->tableName a, $this->jionTableName b where a.ProductId = b.ProductId and a.ProductStatus = 1 and b.GroupId = ?" . ($this->whereSql['where'] ? ' and ' . implode(' and ', $this->whereSql['where']) : '') . " order by ProductSort DESC", 
				'i' . $this->whereSql['whereExt'], array_merge(array($userGroupId), $this->whereSql['whereVal']));
	}

	/**
	 * 根据产品ID获取产品信息
	 * @param int $productId
	 * @param int $userGroupId
	 * @param int $productStatus
	 * @return array|boolean
	 */
	public function getProductById($productId, $userGroupId = 1, $productStatus = FALSE)
	{
		$ext = '';
		$value = array();
		$sql = "select * from $this->tableName a, $this->jionTableName b where a.ProductId = b.ProductId ";
		if(FALSE !== $productStatus)
		{
			$sql .= " and a.ProductStatus = ? ";
			$ext .= 'i';
			$value[] = $productStatus;
		}
		$sql .= " and a.ProductId = ?  and b.GroupId = ?";
		$ext .= 'ii';
		$value[] = $productId;
		$value[] = $userGroupId;
		return $this->getRow($sql, $ext, $value);
	}

	/**
	 * 根据产品名和类型获取产品信息
	 * @param string $productName
	 * @param int $productType
	 * @param int $userGroupId
	 * @return array|boolean
	 */
	public function getProductByNameAndType($productName, $productType = FALSE, $userGroupId = FALSE)
	{
		$ext = '';
		$value = array();
		$userGroupId = $userGroupId ? $userGroupId : 1;
		$sql = "select * from $this->tableName a, $this->jionTableName b where a.ProductId = b.ProductId and a.ProductStatus = 1";
		$sql .= " and a.ProductName = ? and b.GroupId = ?";
		$ext .= 'si';
		$value[] = $productName;
		$value[] = $userGroupId;
		if($productType)
		{
			$sql .= " and a.ProductType = ? ";
			$ext .= 'i';
			$value[] = $productType;
		}
		return $this->getRow($sql, $ext, $value);
	}
}

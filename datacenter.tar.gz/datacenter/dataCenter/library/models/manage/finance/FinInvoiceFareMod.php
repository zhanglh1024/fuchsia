<?php
namespace models\manage\finance;
use \core\ModBase;

/**
 * 用户可用发票金额
 */
class FinInvoiceFareMod extends FinMod
{
	private $tableName;
	function __construct()
	{
		parent::__construct();
		$this->tableName = 'e_finance_invoicefare';
	}
	 
	/**
	 * 添加用户可用发票金额
	 * @param unknown_type $data
	 * @return boolean
	 */
	public function addInvoiceFare($data) 
	{
		if(empty($data['enameId']) || empty($data['canUse']))
		{
			return FALSE;
		}
		$sql = "insert into $this->tableName(EnameId,Year,canUse,UpdateTime) values(?,?,?,?)";
		return $this->add($sql,'iidi',array($data['enameId'],$data['year'],$data['canUse'],time()));
	}
	
	/**
	 * 更新用户可用发票信息
	 * @return number|boolean
	 */
	public function updateInvoiceFare($set, $where)
	{
		if(empty($set) || empty($where))
		{
			return FALSE;
		}
		$query = "update $this->tableName set ";
		$setResult = $this->getSetPart($set);
		list($set, $bindSetType, $bindSetValue) = $setResult;
		if($set)
		{
			$query .= implode(' , ', $set);
		}
		$whereResul = $this->getWherePart($where);
		list($where, $bindWhereType, $bindWhereValue) = $whereResul;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		$bindType = $bindSetType . $bindWhereType;
		$bindValue = $bindSetValue;
		if(! empty($bindWhereValue))
		{
			foreach($bindWhereValue as $k => $v)
			{
				$bindValue[] = $v;
			}
		}
		return $this->update($query, $bindType, $bindValue);
	}
	
	public function updateInvoiceFareOnly($where,$set)
	{
		if(empty($set) || empty($where))
		{
			return FALSE;
		}
		$query = "update $this->tableName set ";
		$setResult = $this->getSetPartOnly($set);
		list($set, $bindSetType, $bindSetValue) = $setResult;
		if($set)
		{
			$query .= implode(' , ', $set);
		}
		$whereResul = $this->getWherePart($where);
		list($where, $bindWhereType, $bindWhereValue) = $whereResul;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		$bindType = $bindSetType . $bindWhereType;
		$bindValue = $bindSetValue;
		if(! empty($bindWhereValue))
		{
			foreach($bindWhereValue as $k => $v)
			{
				$bindValue[] = $v;
			}
		}
		return $this->update($query, $bindType, $bindValue);		
	}
	
	
	/**
	 * 根据条件获取用户可用发票
	 * @return array
	 */
	public function getInvoiceFare($data,$one = FALSE)
	{
		$query = "select * from  " . $this->tableName;
		$result = $this->getWherePart($data);
		list($where, $bindType, $bindValue) = $result;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		} 
		$query .=' order by Year DESC';
		return $this->select($query, $bindType, $bindValue,$one);
	}
	
	/**
	 * 获取到更新部分数据
	 */
	private function getSetPart($set)
	{
		$return = $bindValue = array();
		$bindType = '';
		if(isset($set['enameId']))
		{
			$return[] = 'EnameId = ?';
			$bindValue[] = $set['enameId'];
			$bindType .= 'i';
		}
		if(isset($set['canUse']))
		{
			$return[] = 'Canuse = Canuse + ?';
			$bindValue[] = $set['canUse'];
			$bindType .= 'd';
		}
		if(isset($set['used']))
		{
			$return[] = 'Used = Used + ?';
			$bindValue[] = $set['used'];
			$bindType .= 'd';
		}
		if(isset($set['freezes']))
		{
			$return[] = 'Freezes = Freezes + ?';
			$bindValue[] = $set['freezes'];
			$bindType .= 'd';
		}
		$return[] = 'UpdateTime = ?';
		$bindValue[] = time();
		$bindType .= 'i';
		return array($return,$bindType,$bindValue);
	}

	private function getSetPartOnly($set)
	{
		$return = $bindValue = array();
		$bindType = '';
		if(isset($set['canUse']))
		{
			$return[] = 'Canuse =  ?';
			$bindValue[] = $set['canUse'];
			$bindType .= 'd';
		}
		if(isset($set['used']))
		{
			$return[] = 'Used =  ?';
			$bindValue[] = $set['used'];
			$bindType .= 'd';
		}
		if(isset($set['freezes']))
		{
			$return[] = 'Freezes =  ?';
			$bindValue[] = $set['freezes'];
			$bindType .= 'd';
		}
		if(isset($set['updateTime']))
		{
			$return[] = 'UpdateTime = ?';
			$bindValue[] = $set['updateTime'];
			$bindType .= 'i';
		}
		return array($return,$bindType,$bindValue);
	}	
	
	/**
	 * 获取 where部分
	 */
	private function getWherePart($where)
	{
		$return = $bindValue = array();
		$bindType = '';
		if(! empty($where['id']))
		{
			$return[] = 'Id = ?';
			$bindValue[] = $where['id'];
			$bindType .= 'i';
		}
		if(! empty($where['enameId']))
		{
			$return[] = 'EnameId = ?';
			$bindValue[] = $where['enameId'];
			$bindType .= 'i';
		}
		if(! empty($where['updateTime']))
		{
			$return[] = 'UpdateTime = ?';
			$bindValue[] = $where['updateTime'];
			$bindType .= 'i';
		}
		if(! empty($where['year']))
		{
			$return[] = 'Year = ?';
			$bindValue[] = $where['year'];
			$bindType .= 'i';
		}
		if(isset($where['canUse']))
		{
			$return[] = 'Canuse = ?';
			$bindValue[] = $where['canUse'];
			$bindType .= 'd';
		}
		if(isset($where['used']))
		{
			$return[] = 'Used = ?';
			$bindValue[] = $where['used'];
			$bindType .= 'd';
		}
		if(isset($where['freezes']))
		{
			$return[] = 'Freezes = ?';
			$bindValue[] = $where['freezes'];
			$bindType .= 'd';
		}
		return array($return,$bindType,$bindValue);
	}
}
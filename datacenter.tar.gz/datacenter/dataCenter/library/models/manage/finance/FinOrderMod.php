<?php
namespace models\manage\finance;
use \core\ModBase;
class FinOrderMod extends FinMod
{
	private $tableName;

	function __construct()
	{
		parent::__construct();
		$this->tableName = 'e_finance_orders';
	}

	/**
	 * 添加订单,status默认为3处理中
	 * @param array $data  enameId linkEnameId productId orderType productCost promoId promoMoney productName price 
	 * domain timePeriod productOptions freezeMoneySort registarId remark adminId remarkHide
	 * @return number|boolean
	 */
	public function addOrderInfo($data)
	{
		$createTime = date('Y-m-d H:i:s');
		$updateTime = $createTime;
		return $this->add("insert into $this->tableName(EnameId,ProductId,Price,Domain,ProductCost,OrderStatus,CreateTime,UpdateTime,ProductName,
				ProductOptions,OrderType,PromoId,PromoMoney,LinkEnameId,FreezeMoneySort,RegistarId,Remark,RemarkHide,AdminId) 
				values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", "iidsdissssiidisissi", array($data['enameId'],
				empty($data['productId']) ? '0' : $data['productId'], $data['price'],
				empty($data['domain']) ? '' : $data['domain'], empty($data['productCost']) ? '' : $data['productCost'], 3, $createTime, $updateTime,
				empty($data['productName']) ? '' : $data['productName'], $data['productOptions'], $data['orderType'],
				empty($data['promoId']) ? '0' : $data['promoId'],
				empty($data['promoMoney']) ? '' : $data['promoMoney'],
				empty($data['linkEnameId']) ? '9999' : $data['linkEnameId'],
				empty($data['freezeMoneySort']) ? '' : $data['freezeMoneySort'],
				empty($data['registarId']) ? '0' : $data['registarId'], empty($data['remark']) ? '' : $data['remark'],
				empty($data['remarkHide']) ? '' : $data['remarkHide'],
				empty($data['adminId']) ? '0' : $data['adminId']));
	}

	/**
	 * 获取用户单条订单信息
	 * @param int $orderId
	 * @param int $enameId
	 * @return array|boolean
	 */
	public function getOrderById($orderId, $enameId)
	{ 
		return $this->getRow("select * from $this->tableName where OrderId = ? and EnameId = ?", "ii", array($orderId,
				$enameId));
	}
 
	/**
	 * 直接根据订单号获取订单信息 
	 * @param int $orderId
	 * @return array|boolean
	 */
	public function getOrderByOrderId($orderId)
	{ 
		return $this->getRow("select * from $this->tableName where OrderId = ? ", "i", array($orderId));
	}
	
	/**
	 * 根据条件获取订单列表信息
	 * @param unknown_type $params
	 * @param unknown_type $limit
	 * @return Ambigous <multitype:, boolean, unknown>
	 */
	public function getOrderList($params,$limit = FALSE)
	{
		$sql = self::getSql($params);
		list($where,$bindValue,$bindType) = $sql;
		$query = "select * from  " . $this->tableName;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		$query .=' order by CreateTime DESC';
		if($limit)
		{
			$query .=' limit '.$limit;
		}
		return $this->select($query, $bindType, $bindValue);		
	}	
	
	/**
	 * 更新订单信息，返回影响行数todoviya
	 * @param int $orderId
	 * @param int $enameId
	 * @param array $data 非必须updateTime orderStatus price linkEnameId freezeMoneySort adminId remark remarkHide
	 * @return boolean
	 */
	public function setOrderInfoReturnNum($orderId, $enameId, $data = array())
	{ 
		$this->clear();
		$this->finSetSql("UpdateTime = ?", empty($data['updateTime']) ? date('Y-m-d H:i:s') : $data['updateTime'], 's');
		if(isset($data['orderStatus']))
		{
			$this->finSetSql("orderStatus = ?", $data['orderStatus']);
		}
		if(isset($data['price']))
		{
			$this->finSetSql("Price = ?", $data['price']);
		}
		if(isset($data['linkEnameId']) and is_numeric($data['linkEnameId']))
		{
			$this->finSetSql("LinkEnameId = ?", $data['linkEnameId']);
		}
		if(isset($data['freezeMoneySort']))
		{ 
			$this->finSetSql("freezeMoneySort = ?", $data['freezeMoneySort'], 's');
		}
		if(isset($data['adminId']) && $data['adminId'])
		{
			$this->finSetSql("AdminId = ?", $data['adminId']);
		}
		if(isset($data['remark']))
		{
			$this->finSetSql("Remark = ?", $data['remark'], 's');
		}
		if(isset($data['remarkHide']))
		{
			$this->finSetSql("RemarkHide = ?", $data['remarkHide'], 's');
		}
		if(isset($data['registarId']))
		{
			$this->finSetSql("RegistarId = ?", $data['registarId'], 'i');
		}
		if(isset($data['productCost']))
		{
			$this->finSetSql("ProductCost = ?", $data['productCost']);
		}
		return $this->update("update $this->tableName set " . implode(',', $this->setSql['set']) . " where OrderId = ? and EnameId = ?", $this->setSql['setExt'] . "ii", array_merge($this->setSql['setVal'], array(
				$orderId, $enameId)));
	}
	
	/**
	 * 更新订单信息
	 * @param int $orderId
	 * @return array
	 */
	public function setOrderInfo($orderId, $enameId, $data = array())
	{
		return $this->setOrderInfoReturnNum($orderId, $enameId, $data);
	}
	
	/**
	 * 获取财务冻结列表
	 * @param unknown $data
	 * @param string $limit
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getFinanceFreezeList($data,$limit=false)
	{
		$sql = self::getSql($data);
		list($where,$bindValue,$bindType) = $sql;
		$query = "select `Domain`,`OrderType`,`Price`,`CreateTime` from  " . $this->tableName;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		$query .=' order by CreateTime DESC';
		if($limit)
		{
			$query .=' limit '.$limit;
		}
		return $this->select($query, $bindType, $bindValue);
	}
	
	/**
	 * 获取财务冻结数目
	 * @param unknown $data
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getFinanceFreezeCount($data)
	{
		$sql = self::getSql($data);
		list($where,$bindValue,$bindType) = $sql;
		$query = "select count(1) as total from  " . $this->tableName;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		return $this->getRow($query, $bindType, $bindValue);
	}
	
	//获取财务冻结信息sql处理
	private function getSql($params)
	{
		$where = $bindValue = array();
		$bindType = '';
		if(!empty($params['EnameId']))
		{
			$where[] = 'EnameId = ?';
			$bindValue[] = $params['EnameId'];
			$bindType .= 'i';
		}
		if(isset($params['orderStatus']) && $params['orderStatus'] !== "")
		{
			$where[] = 'OrderStatus = ?';
			$bindValue[] = $params['orderStatus'];
			$bindType .= 'i';
		}
		if(isset($params['OrderType']) && $params['OrderType'] !== "")
		{
			$where[] = 'OrderType = ?';
			$bindValue[] = $params['OrderType'];
			$bindType .= 'i';
		}
		if(!empty($params['Domain']))
		{
			$where[] = 'Domain = ?';
			$bindValue[] = $params['Domain'];
			$bindType .= 's';
		}
		if(isset($params['RegistarId']) && $params['RegistarId'] !== "")
		{
			$where[] = 'RegistarId = ?';
			$bindValue[] = $params['RegistarId'];
			$bindType .= 'i';
		}
		if(!empty($params['StartDate']))
		{
			$where[] = 'CreateTime >= ?';
			$bindValue[] = $params['StartDate'];
			$bindType .= 's';
		}
		if(!empty($params['EndDate']))
		{
			$where[] = 'CreateTime <= ?';
			$bindValue[] = $params['EndDate'];
			$bindType .= 's';
		}
		if(!empty($params['Remark']))
		{
			$where[] = 'Remark = ?';
			$bindValue[] = $params['Remark'];
			$bindType .= 's';
		}
		if(!empty($params['checkYear']))
		{
			$where[] = 'year(UpdateTime) = ?';
			$bindValue[] = $params['checkYear'];
			$bindType .= 's';
		}
		if(!empty($params['inOrderType']))
		{
			$inOrderType = explode(",", $params['inOrderType']);
			$count = count($inOrderType);
			$where[] = 'OrderType in ('.trim(str_repeat('?,', $count) ,',').')';
			$bindValue = array_merge($bindValue, $inOrderType);
			$bindType .= str_repeat('i', $count);
		}
		if(!empty($params['inOrderStatus']))
		{
			$inOrderType = explode(",", $params['inOrderStatus']);
			$count = count($inOrderType);
			$where[] = 'OrderStatus in ('.trim(str_repeat('?,', $count) ,',').')';
			$bindValue = array_merge($bindValue, $inOrderType);
			$bindType .= str_repeat('i', $count);
		}
		if(!empty($params['RemarkHide']))
		{
			$where[] = 'RemarkHide = ?';
			$bindValue[] = $params['RemarkHide'];
			$bindType .= 's';
		}
		return array($where,$bindValue,$bindType);
	}
}

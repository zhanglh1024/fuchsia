<?php
namespace models\manage\finance;
use core\ModBase;

class FinGeneralMod extends FinMod
{

	/**
	 * 财务流水总表
	 *
	 * @var string
	 */
	private $tableName = 'e_finance_general';

	/**
	 * params 可传用于查询的key
	 *
	 * @var array
	 */
	private $params;

	/**
	 * zongh
	 * param type decimal
	 *
	 * @var array
	 */
	private $paramDecimal = array('InOutMoney', 'CurrentMoney', 'FeeMoney', 'ProductCost', 'PromoMoney', 'ProductPrice');

	/**
	 * param type string
	 *
	 * @var string
	 */
	private $paramString = array('LinkDomain', 'ProductName', 'FreezeMoneySort', 'Remark', 'RemarkHide');

	/**
	 * param type int
	 *
	 * @var array
	 */
	private $paramInt = array('GeneralId', 'EnameId', 'RegistrarId', 'DomainLtd', 'Type', 'InOutType', 'PayId', 
			'MoneyType', 'LinkEnameId', 'OrderId', 'LinkOrderId', 'ProductId', 'PromoId', 'BankName', 'TypeSon', 
			'UniqueId', 'AdminId', 'UpdateTime', 'IsCancelOrder', 'DomainYear');

	/**
	 * construct
	 */
	public function __construct()
	{
		parent::__construct();
		$this->params = array_merge($this->paramDecimal, $this->paramInt, $this->paramString);
	}

	/**
	 * 根据条件查询记录
	 *
	 * @param array $data
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getFinGeneralList(array $data)
	{
		$this->clear();
		$this->tableName = 'e_finance_general' .
			 (isset($data['byYear']) && $data['byYear'] ? $data['byYear'] : date('Y'));
		$result = $this->getSqlWhere($data);
		$fields = !empty($data['fields']) ? $data['fields'] : "*";
		$query = 'select '.$fields .' from ' . $this->tableName . $result['where'] . ' order by UpdateTime desc limit ?,?;';
		return $this->select($query, $result['type'] . 'ii', 
			array_merge($result['val'], array($data['offset'], $data['num'])));
	}
	
	/**
	 * 根据InOutMoney InOutType TypeSon 获取财务流水账统计信息InOutMoney InOutType必须  TypeSon可选
	 * 具体传入数据参考getGeneralCount
	 */
	public function getFinGeneralStatistics(array $data)
	{
		$this->clear();
		$this->tableName = 'e_finance_general' .
			(isset($data['byYear']) && $data['byYear'] ? $data['byYear'] : date('Y'));
		$result = $this->getSqlWhere($data);
		$query = "select InOutMoney,count(*) as Num ,InOutType,DomainYear,DomainLtd,FROM_UNIXTIME(UpdateTime, '%Y-%m-%d') as CreateTime from " . $this->tableName . $result['where']; 
		$query .=' group by InOutMoney,InOutType,DomainLtd';
		if($data['TypeSon'])
		{
			$query .= ',TypeSon';
		}
		//按按天分组 时间存得是时间戳
		$query .= ",FROM_UNIXTIME(UpdateTime, '%Y%m%d')";
		$query .=' order by InOutMoney asc limit ?,?;';
		return $this->select($query, $result['type'] . 'ii',
			array_merge($result['val'], array($data['offset'], $data['num'])));
	}
	
	/**
	 * 根据条件查询记录条数
	 *
	 * @param string $data
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getFinGeneralCount(array $data)
	{
		$this->clear();
		$this->tableName = 'e_finance_general' .
			 (isset($data['byYear']) && $data['byYear'] ? $data['byYear'] : date('Y'));
		$result = $this->getSqlWhere($data);
		$query = 'select count(*) from ' . $this->tableName . $result['where'];
		return $this->getOne($query, $result['type'], $result['val']);
	}

	/**
	 * 根据条件删除制定条数的流水纪录－－临时脚本是用
	 *
	 * @param array $data
	 * @param unknown $limit
	 */
	public function delGeneral(array $data, $limit)
	{
		$this->clear();
		$result = $this->getSqlWhere($data);
		$query = "delete from e_finance_general2015 " . $result['where'] . ' limit ' . $limit;
		return $this->delete($query, $result['type'], $result['val']);
	}

	/**
	 * 根据条件更新指定条数的流水纪录－－临时脚本是用
	 *
	 * @param array $data
	 * @param array $info
	 */
	public function updateGeneral(array $data, $info)
	{
		$this->clear();
		$result = $this->getSqlWhere($data);
		$upData = array();
		$upData[] = "RemarkHide='" . $info['RemarkHide'] . "'";
		$upData[] = 'TypeSon=' . $info['TypeSon'];
		if(isset($info['DomainYear']))
		{
			$upData[] = 'DomainYear=' . $info['DomainYear'];
		}
		$upData[] = "FreezeMoneySort='" . $info['FreezeMoneySort'] . "'";
		$upData[] = "ProductName='" . $info['ProductName'] . "'";
		$upData[] = 'ProductId=' . $info['ProductId'];
		$upData[] = 'AdminId=' . $info['AdminId'];
		$upData[] = 'RegistrarId=' . $info['RegistrarId'];
		$upData[] = 'ProductCost=' . $info['ProductCost'];
		$data[] = 'ProductPrice=' . $info['ProductPrice'];
		$query = "update e_finance_general2015 set " . implode(',', $upData) . $result['where'];
		return $this->update($query, $result['type'], $result['val']);
	}

	/**
	 * 获取出入款总金额
	 *
	 * @param array $data
	 * @return int
	 */
	public function getFinGeneralStat(array $data)
	{
		$this->tableName = 'e_finance_general' .
			 (isset($data['byYear']) && $data['byYear'] ? $data['byYear'] : date('Y'));
		$result = $this->getSqlWhere($data);
		$query = 'SELECT SUM(`InOutMoney`) AS sum ,sum(FeeMoney) as feeSum  FROM ' . $this->tableName . $result['where'];
		return $this->select($query, $result['type'], $result['val'], TRUE);
	}

	/**
	 * 添加一条记录到表中，自动过滤非数据库字段
	 *
	 * @param array $data
	 * @return boolean
	 */
	public function addFinGeneral(array $data)
	{
		$this->tableName = 'e_finance_general' .
			 (isset($data['byYear']) && $data['byYear'] ? $data['byYear'] : date('Y'));
		$sql = 'insert into ' . $this->tableName . '(';
		$paramsType = '';
		foreach($data as $key => $val)
		{
			if(!in_array($key, $this->params))
			{
				unset($data[$key]);
				continue;
			}
			$sql .= $key . ',';
			$paramsType .= in_array($key, $this->paramString) ? 's' : (in_array($key, $this->paramInt) ? 'i' : 'd');
		}
		$sql = rtrim($sql, ',') . ') values(' . str_repeat('?,', count($data));
		$sql = rtrim($sql, ',') . ');';
		return $this->add($sql, $paramsType, $data);
	}

	/**
	 * 更新数据库，where 必须
	 *
	 * @param array $set
	 * @param array $where
	 * @return boolean
	 */
	public function upFinGeneral(array $set, array $where)
	{
		if(!is_array($where) || !$where)
		{
			return false;
		}
		$this->clear();
		$paramType = '';
		$this->tableName = 'e_finance_general' .
			 (isset($data['byYear']) && $data['byYear'] ? $data['byYear'] : date('Y'));
		$sql = 'update ' . $this->tableName . ' set ';
		foreach($set as $key => $val)
		{
			if(!in_array($key, $this->params))
			{
				unset($set[$key]);
				continue;
			}
			$sql .= $key . ' = ?,';
			$paramType .= in_array($key, $this->paramInt) ? 'i' : (in_array($key, $this->paramString) ? 's' : 'd');
		}
		$sql = rtrim($sql, ',') . ' where ';
		foreach($where as $key => $val)
		{
			$paramType .= in_array($key, $this->paramInt) ? 'i' : (in_array($key, $this->paramString) ? 's' : 'd');
			if(strpos($key, '>') !== false || strpos($key, '<') !== false)
			{
				$sql .= $key . '? and ';
				continue;
			}
			$sql .= $key . ' = ? and ';
		}
		return $this->update(rtrim($sql, 'and '), $paramType, array($set, $where));
	}

	/**
	 * 收入统计
	 *
	 * @param array $data
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getFinanceInStat($data)
	{
		$table = $this->tableName . $data['year'];
		$where = self::getFinanceWhere($data);
		$result = $sqlConfig = array();
		// 注册,转入,续费,赎回,转接口(1,2,3,4,14)
		$sqlConfig[1] = 'SELECT count(*) as Num,Type, sum(InOutMoney) as MoneyCount, sum(DomainYear) as YearCount,InOutType,DomainLtd from '.$table.' where InOutType in(1, 2, 3, 4, 14) and Type in(1,2) ' .
		$where . ' group by Type,DomainLtd,InOutType,Type ORDER BY InOutType ASC,DomainLtd ASC,Type ASC';
		// 充值和退款的(只需要统计入款的,只需要统计203,202)
		$sqlConfig[2] = 'SELECT count(*) as Num, sum(InOutMoney) as MoneyCount, InOutType, Type from ' . $table .
		' where Type = 2 and InOutType in(202,203) ' . $where .
		' group by InOutType ';
		// 经济交易,中介交易(111, 112)
		$sqlConfig[3] = 'SELECT count(*) as Num, sum(InOutMoney) as MoneyCount, TypeSon, InOutType, Type from ' . $table .
		' where InOutType in(111, 112) and Type in(1,2) and TypeSon = 3 ' . $where .
		' group by InOutType, TypeSon , Type ORDER BY  InOutType ASC, TypeSon ASC,Type ASC';
		// 抽奖205 返款 206
		$sqlConfig[4] = 'SELECT count(*) as Num, sum(InOutMoney) as MoneyCount, TypeSon, InOutType,2 as Type from ' . $table .
		' where InOutType in(205, 206) and Type in(2, 3) ' . $where .
		' group by InOutType, TypeSon ORDER BY  InOutType ASC, TypeSon ASC ';
		// 快递费 32  人工扣款 11  手续费 34
		$sqlConfig[5] = 'SELECT count(*) as Num, sum(InOutMoney) as MoneyCount, TypeSon, InOutType, Type from ' . $table .
		' where InOutType in(32,34,11) and Type in(1,2) ' . $where .
		' group by InOutType, TypeSon , Type ORDER BY  InOutType ASC, TypeSon ASC,Type ASC';
		// 手续费(101,102,103,104,105,106,107,108,109,110,113,114,115,116,117,118,119,121,122,123,124,125,126,127,128,129,39,130,131,132,135)
		$sqlConfig[6] = 'SELECT count(*) as Num, sum(FeeMoney) as MoneyCount, InOutType,if(Type =2, 1,2) as Type  from ' . $table .
		' where InOutType in(101,102,103,104,105,106,107,108,109,110,113,114,115,116,117,118,119,121,122,123,124,125,126,127,128,129,39,130,131,132,135) and ((Type = 2 and IsCancelOrder = 0) or (Type = 1 and IsCancelOrder=1)) ' .
		$where . ' group by InOutType,Type ORDER BY  InOutType ASC,Type ASC';
		// 普通统计(其他,出款-入款)
		$sqlConfig[7] = 'SELECT count(*) as Num, sum(InOutMoney) as MoneyCount, sum(DomainYear) as YearCount, InOutType, Type from ' . $table .
		' where InOutType in(5,8,9,10,13,16,17,18,19,24,25,26,27,28,29,41,99) and Type in(1,2) ' . $where .
		' group by InOutType,Type ORDER BY  InOutType ASC,Type ASC';
		// 普通消费(出款)
		$sqlConfig[8] = 'SELECT count(*) as Num, sum(InOutMoney) as MoneyCount, sum(DomainYear) as YearCount, InOutType, 1 as Type from ' . $table .
		' where InOutType=40 and Type=1 ' . $where .
		' group by InOutType ORDER BY InOutType ASC';
		foreach ($sqlConfig as $v)
		{
			$temp = $this->select($v, '', array());
			if($temp && !empty($temp[0]['Num']))
			{
				$result = array_merge($result, $temp);
			}
		}
		return $result;
	}

	/**
	 * 收入统计
	 *
	 * @param array $data
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getFinanceInStatDetail($data, $typeArrDn = array(), $typeArrFee = array())
	{
		$table = $this->tableName . $data['year'];
		$where = self::getFinanceWhere($data);
		$result = array();
		if(!empty($typeArrDn))
		{
			//注册,转入,续费,赎回,转接口详细统计(注册局和单价)
			$sql = 'SELECT count(*) as Num,Type, sum(InOutMoney) as MoneyCount, sum(DomainYear) as YearCount, InOutMoney,RegistrarId,InOutType,DomainLtd from ';
			$sql .=	$table . ' where InOutType in('.implode(',', $typeArrDn).') and Type in(1,2) ';
			$sql .= $where . ' group by Type,DomainLtd,InOutType,RegistrarId,InOutMoney,Type ORDER BY InOutType ASC,DomainLtd ASC,Type ASC';
			$temp =  $this->select($sql, '', array());
			$temp = empty($temp[0]['Num']) ? array() : $temp;
			$result = array_merge($result, $temp);
		}
		if(!empty($typeArrFee))
		{
			//手续费
			$sql = 'SELECT count(*) as Num,sum(FeeMoney) as MoneyCount,InOutType,if(Type =2, 1,2) as Type,InOutMoney,RegistrarId from ';
			$sql .=	$table . ' where InOutType in('.implode(',', $typeArrFee).') and FeeMoney > 0 and ((Type = 2 and IsCancelOrder = 0) or (Type = 1 and IsCancelOrder=1))';
			$sql .=	$where . ' group by InOutType,Type,InOutMoney,RegistrarId ORDER BY InOutType ASC,Type ASC';
			$temp =  $this->select($sql, '', array());
			$temp = empty($temp[0]['Num']) ? array() : $temp;
			$result = array_merge($result, $temp);
		}
		return $result;
	}
	
	/**
	 * 获取详情
	 * @param unknown $id
	 * @param string $year
	 * @return boolean|Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getInfoById($id ,$year = false)
	{
		if(empty($id))
		{
			return false;
		}
		$table =  $this->tableName.(!empty($year) ? $year : date('Y'));
		$sql = "select * from ".$table." where GeneralId = ?";
		return $this->getRow($sql, 'i', array($id));
	}
	
	/**
	 * 修改财务类型
	 * @param array $data
	 * @return boolean
	 */
	public function updateFinanceTypeById($data)
	{
		if(empty($data['GeneralId']) || $data['FinanceType'] === '' && $data['SonType'] === '')
		{
			return false;
		}
		$setString = '';
		$bingType = '';
		$params = array();
		if($data['FinanceType']!=='')
		{
			$setString .= ' InOutType = ? ';
			$bingType .= 'i';
			$params[] = $data['FinanceType'];
		}
		if(isset($data['Type']) && $data['Type'] !=='')
		{
			$setString .= (empty($setString) ? '' : ',').' Type = ? ';
			$bingType .= 'i';
			$params[] = $data['Type'];
		}
		$table =  $this->tableName.(isset($data['byYear']) && $data['byYear'] ? $data['byYear'] : date('Y'));
		if($data['SonType'] !== '')
		{
			$setString .= (empty($setString) ? '' : ',').' TypeSon = ? ';
			$bingType .= 'i';
			$params[] = $data['SonType'];
		}
		$sql = "update $table set $setString where GeneralId = ? ";
		$params[] = $data['GeneralId'];
		return $this->update($sql, $bingType.'i', $params);
	}

	/**
	 * 获取统计的条件
	 */
	private function getFinanceWhere($data)
	{
		$where = '';
		if(!empty($data['startTime']))
		{
			$where .= ' AND UpdateTime >=  ' . $data['startTime'];
		}
		if(!empty($data['endTime']))
		{
			$where .= ' AND UpdateTime <=  ' . $data['endTime'];
		}
		return $where;
	}

	/**
	 * 根据data组装where，
	 *
	 * @param array $data
	 */
	private function getSqlWhere(array $data)
	{
		$sql = '';
		$params['val'] = array();
		$params['type'] = '';
		if(!empty($_REQUEST['in']))
		{
			$data['in'] = $_REQUEST['in'];
		}
		if(!empty($_REQUEST['or']))
		{
			$data['or'] = $_REQUEST['or'];
		}
		$this->params = array_merge($this->params, array('startDate', 'endDate', 'typeArr', 'in', 'or','inOutMoneyArr'));
		foreach($data as $key => $val)
		{
			if($val === '' || !in_array($key, $this->params))
			{
				continue;
			}
			$paramType = in_array($key, $this->paramInt) ? 'i' : (in_array($key, $this->paramDecimal) ? 'd' : 's');
			if($key == 'startDate')
			{
				$sql .= 'UpdateTime >=? and ';
				$params['val'][] = $val;
				$params['type'] .= $paramType;
				continue;
			}
			if($key == 'endDate')
			{
				$sql .= 'UpdateTime <=? and ';
				$params['val'][] = $val;
				$params['type'] .= $paramType;
				continue;
			}
			if($key == 'Remark')
			{
				$sql .= 'instr(Remark,?)>0 and ';
				$params['val'][] = $val;
				$params['type'] .= $paramType;
				continue;
			}
			if($key == 'RemarkHide')
			{
				$sql .= 'instr(RemarkHide,?)>0 and ';
				$params['val'][] = $val;
				$params['type'] .= $paramType;
				continue;
			}
			if($key == 'inOutMoneyArr')
			{
				$inOutMoneyArr = explode('-', $val);
				if(count($inOutMoneyArr) == 1)
				{
					$sql .= 'InOutMoney >=? and InOutMoney < ? and ';
					$params['val'][] = $inOutMoneyArr[0];
					$params['val'][] = intval($inOutMoneyArr[0])+1;
					$params['type'] .= 'dd';
				}
				if(count($inOutMoneyArr) == 2)
				{
					$sql .= 'InOutMoney >=? and InOutMoney <=? and ';
					$params['val'][] = $inOutMoneyArr[0];
					$params['val'][] = $inOutMoneyArr[1];
					$params['type'] .= 'dd';
				}
				continue;
			}
			if($key == 'typeArr')
			{
				$typeArr = explode(',', $val);
				$sql .= 'InOutType in (' . rtrim(str_repeat('?,', count($typeArr)), ',') . ') and ';
				foreach($typeArr as $k => $v)
				{
					$params['val'][] = $v;
				}
				$params['type'] .= str_repeat($paramType, count($typeArr));
				continue;
			}
			if($key == 'in')
			{
				$keys = array_keys($data['in']);
				foreach($keys as $k => $v)
				{
					$wen = trim(str_repeat('?,', count($data['in'][$v])), ',');
					$sql .= $v . ' in (' . $wen . ') and ';
					foreach($data['in'][$v] as $valIn)
					{
						$params['type'] .= is_string($valIn) ? 's' : 'i';
						$params['val'][] = $valIn;
					}
				}
				continue;
			}
			if($key == 'or')
			{
				$keys = array_keys($data['or']);
				$tempSqlArray = array();
				foreach($keys as $k => $v)
				{
					if($v == 'Remark')
					{
						$tempSqlArray[] = 'instr(Remark,?)>0';
						$params['val'][] = $data['or'][$v];
						$params['type'] .= 's';
						continue;
					}
					if($v == 'RemarkHide')
					{
						$tempSqlArray[] = 'instr(RemarkHide,?)>0';
						$params['val'][] = $data['or'][$v];
						$params['type'] .= 's';
						continue;
					}
					$tempSqlArray[] = $v . '=?';
					$params['type'] .= is_string($data['or'][$v]) ? 's' : 'i';
					$params['val'][] = $data['or'][$v];
				}
				if($tempSqlArray)
				{
					$sql .= "(".implode(" or ", $tempSqlArray).") and ";
				}
				continue;
			}
			$sql .= $key . '=? and ';
			$params['val'][] = $val;
			$params['type'] .= $paramType;
		}
		$params['where'] = $sql ? ' where ' . rtrim($sql, 'and ') : '';
		return $params;
	}

	/**
	 * 域名消费统计
	 */
	public function domainCostStat($beginYear, $endYear, $beginMonthStr, $endMonthStr, $typeArr = false, $registrarId = false, $isRegistrar = false)
	{
		if(empty($typeArr))
		{
			return false;
		}
		$sql = "select ";
		foreach($typeArr as $type)
		{
			$sql .= "sum(if(InOutType={$type} and Type=1,1,0)) - sum(if(InOutType={$type} and Type=2,1,0)) as Count{$type},";
			$sql .= "sum(if(InOutType={$type} and Type=1,DomainYear,0)) - sum(if(InOutType={$type} and Type=2,DomainYear,0)) as Year{$type},";
			$sql .= "sum(if(InOutType={$type} and Type=1,InOutMoney,0)) - sum(if(InOutType={$type} and Type=2,InOutMoney,0)) as Money{$type},";
			$sql .= $isRegistrar ? "sum(if(InOutType={$type} and Type=1,DomainYear*ProductCost,0)) - sum(if(InOutType={$type} and Type=2,DomainYear*ProductCost,0)) as CostTotal{$type}," : "";
			$sql .= "sum(if(InOutType={$type} and Type=1,InOutMoney-DomainYear*ProductCost,0)) - sum(if(InOutType={$type} and Type=2,InOutMoney-DomainYear*ProductCost,0)) as Profit{$type},";
		}
		$sql .= "DomainLtd,from_unixtime(UpdateTime,'%Y-%m') as Month ";
		$sql .= "from " . $this->tableName . $endYear;
		$sql .= " where UpdateTime>=" . $beginMonthStr . " and UpdateTime <" . $endMonthStr .
			 " and InOutType in(".implode(',', $typeArr).")";
		$sql .= $isRegistrar && $registrarId ?  " and RegistrarId=".$registrarId : "";
		$sql .= " group by DomainLtd";
		$result = $this->select($sql, '', array());
		return $result;
	}

	/**
	 * 交易统计,有手续费部分
	 */
	public function tradeFeeStat($beginYear, $endYear, $beginMonthStr, $endMonthStr, $typeArr)
	{
		if(empty($typeArr))
		{
			return false;
		}
		$sql = "select InOutType,";
		$sql .= "DomainLtd,from_unixtime(UpdateTime,'%Y-%m') as Month,";
		$sql .= "sum(if(Type=1 and IsCancelOrder=0,1,0)) - sum(if(Type=2 and IsCancelOrder=1,1,0)) as Count,"; // FeeMoney不为0的是正常入款数据不能减
		$sql .= "sum(if(Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(Type=2 and IsCancelOrder=1,InOutMoney,0)) as Money,";
		$sql .= "sum(if(Type=2 and IsCancelOrder=0 and FeeMoney>0,FeeMoney,0)) - sum(if(Type=1 and IsCancelOrder=1 and FeeMoney>0,FeeMoney,0)) as Profit ";
		$sql .= "from " . $this->tableName . $endYear;
		$sql .= " where UpdateTime>=" . $beginMonthStr . " and UpdateTime <" . $endMonthStr .
			 " and DomainLtd>0 and ";
		$sql .= "InOutType in(".implode(',', $typeArr).")";
		$sql .= " group by DomainLtd,InOutType";
		$result = $this->select($sql, '', array());
		return $result;
	}

	/**
	 * 交易统计,纯收入部分
	 */
	public function tradeProStat($beginYear, $endYear, $beginMonthStr, $endMonthStr, $typeArr)
	{
		if(empty($typeArr))
		{
			return false;
		}
		$sql = "select InOutType,";
		$sql .= "DomainLtd,from_unixtime(UpdateTime,'%Y-%m') as Month,";
		$sql .= "sum(if(Type=1,1,0)) - sum(if(Type=2,1,0)) as Count,";
		$sql .= "sum(if(Type=1,InOutMoney,0)) - sum(if(Type=2,InOutMoney,0)) as Money,";
		$sql .= "sum(if(Type=1,InOutMoney,0)) - sum(if(Type=2,InOutMoney,0)) as Profit ";
		$sql .= "from " . $this->tableName . $endYear;
		$sql .= " where UpdateTime>=" . $beginMonthStr . " and UpdateTime <" . $endMonthStr .
			 " and InOutMoney>0 and DomainLtd>0 and ";
		$sql .= "InOutType in(".implode(',', $typeArr).")";
		$sql .= " group by DomainLtd,InOutType";
		$result = $this->select($sql, '', array());
		return $result;
	}

	/* 域名消费额排名 */
	public function domainCostRankingStat($beginYear, $endYear, $beginMonthStr, $endMonthStr)
	{
		$sql = "select ";
		// 注册
		$sql .= "sum(if(InOutType=1 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=1 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as RegisMoney,";
		// 转入
		$sql .= "sum(if(InOutType=2 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=2 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as TraninMoney,";
		// 续费
		$sql .= "sum(if(InOutType=3 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=3 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as RenewMoney,";
		// 赎回
		$sql .= "sum(if(InOutType=4 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=4 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as RestoreMoney,";
		// 转接口
		$sql .= "sum(if(InOutType=14 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=14 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as TraninterMoney,";
		// 总计
		$sql .= "sum(if(InOutType=1 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=1 and Type=2 and IsCancelOrder=1,InOutMoney,0)) + ";
		$sql .= "sum(if(InOutType=2 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=2 and Type=2 and IsCancelOrder=1,InOutMoney,0)) + ";
		$sql .= "sum(if(InOutType=3 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=3 and Type=2 and IsCancelOrder=1,InOutMoney,0)) + ";
		$sql .= "sum(if(InOutType=4 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=4 and Type=2 and IsCancelOrder=1,InOutMoney,0)) + ";
		$sql .= "sum(if(InOutType=14 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=14 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as Total,";
		$sql .= "EnameId ";
		$sql .= "from " . $this->tableName . $endYear;
		$sql .= " where UpdateTime>=" . $beginMonthStr . " and UpdateTime <" . $endMonthStr .
			 " and InOutType in(1,2,3,4,14)";
		$sql .= " group by EnameId Order by Total desc limit 200";
		$result = $this->select($sql, '', array());
		return $result;
	}

	/* 域名交易额排名 */
	public function tradeRankingStat($beginYear, $endYear, $beginMonthStr, $endMonthStr)
	{
		$sql = "select ";
		// 带价push
		$sql .= "sum(if(InOutType=101 and Type=1 and InOutMoney>0 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=101 and Type=2 and InOutMoney>0 and IsCancelOrder=1,InOutMoney,0)) as PushMoney,";
		// 易拍易卖
		$sql .= "sum(if(InOutType=103 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=103 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as EasybuyMoney,";
		// 专题拍卖
		$sql .= "sum(if(InOutType=104 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=104 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as SpecialMoney,";
		// 普通竞价
		$sql .= "sum(if(InOutType=102 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=102 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as BidMoney,";
		// 一口价 and 定向出售
		$sql .= "sum(if((InOutType=106 or InOutType=132 or InOutType=135) and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if((InOutType=106 or InOutType=132 or InOutType=135) and Type=2 and IsCancelOrder=1,InOutMoney,0)) as OnepriceMoney,";
		// 询价
		$sql .= "sum(if(InOutType=115 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=115 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as InquiryMoney,";
		// 统计
		$sql .= "sum(if(InOutType=101 and Type=1 and InOutMoney>0 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=101 and Type=2 and InOutMoney>0 and IsCancelOrder=1,InOutMoney,0)) +";
		$sql .= "sum(if(InOutType=103 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=103 and Type=2 and IsCancelOrder=1,InOutMoney,0)) +";
		$sql .= "sum(if(InOutType=104 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=104 and Type=2 and IsCancelOrder=1,InOutMoney,0)) +";
		$sql .= "sum(if(InOutType=102 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=102 and Type=2 and IsCancelOrder=1,InOutMoney,0)) +";
		$sql .= "sum(if((InOutType=106 or InOutType=132 or InOutType=135) and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if((InOutType=106 or InOutType=132 or InOutType=135) and Type=2 and IsCancelOrder=1,InOutMoney,0)) +";
		$sql .= "sum(if(InOutType=115 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=115 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as Total,";
		$sql .= "EnameId ";
		$sql .= "from " . $this->tableName . $endYear;
		$sql .= " where UpdateTime>=" . $beginMonthStr . " and UpdateTime <" . $endMonthStr .
			 " and InOutType in(101,103,104,102,106,115,132,135)";
		$sql .= " group by EnameId Order by Total desc limit 200";
		$result = $this->select($sql, '', array());
		return $result;
	}

	/* 域名交易额排名（去掉push） */
	public function tradeRankingNoPushStat($beginYear, $endYear, $beginMonthStr, $endMonthStr)
	{
		$sql = "select ";
		// 易拍易卖
		$sql .= "sum(if(InOutType=103 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=103 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as EasybuyMoney,";
		// 专题拍卖
		$sql .= "sum(if(InOutType=104 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=104 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as SpecialMoney,";
		// 普通竞价
		$sql .= "sum(if(InOutType=102 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=102 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as BidMoney,";
		// 一口价 and 定向出售
		$sql .= "sum(if((InOutType=106 or InOutType=132 or InOutType=135) and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if((InOutType=106 or InOutType=132 or InOutType=135) and Type=2 and IsCancelOrder=1,InOutMoney,0)) as OnepriceMoney,";
		// 询价
		$sql .= "sum(if(InOutType=115 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=115 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as InquiryMoney,";
		// 统计
		$sql .= "sum(if(InOutType=103 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=103 and Type=2 and IsCancelOrder=1,InOutMoney,0)) +";
		$sql .= "sum(if(InOutType=104 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=104 and Type=2 and IsCancelOrder=1,InOutMoney,0)) +";
		$sql .= "sum(if(InOutType=102 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=102 and Type=2 and IsCancelOrder=1,InOutMoney,0)) +";
		$sql .= "sum(if((InOutType=106 or InOutType=132 or InOutType=135) and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if((InOutType=106 or InOutType=132 or InOutType=135) and Type=2 and IsCancelOrder=1,InOutMoney,0)) +";
		$sql .= "sum(if(InOutType=115 and Type=1 and IsCancelOrder=0,InOutMoney,0)) - sum(if(InOutType=115 and Type=2 and IsCancelOrder=1,InOutMoney,0)) as Total,";
		$sql .= "EnameId ";
		$sql .= "from " . $this->tableName . $endYear;
		$sql .= " where UpdateTime>=" . $beginMonthStr . " and UpdateTime <" . $endMonthStr .
			 " and InOutType in(103,104,102,106,115,132,135)";
		$sql .= " group by EnameId Order by Total desc limit 200";
		$result = $this->select($sql, '', array());
		return $result;
	}

	/* 入款方式统计 */
	public function financeInTypeStat($beginYear, $endYear, $beginMonthStr, $endMonthStr)
	{
		$sql = "select from_unixtime(UpdateTime,'%Y-%m') as Month, ";
		$sql .= "sum(1) as OnlineCount,sum(InOutMoney) as OnlineMoney,BankName ";
		$sql .= "from " . $this->tableName . $endYear;
		$sql .= " where UpdateTime>=" . $beginMonthStr . " and UpdateTime <" . $endMonthStr .
			 " and BankName != 0 and Type in(2,3) group by BankName";
		$result = $this->select($sql, '', array());
		return $result;
	}
	
	/**
	 * 获取财务新表流水信息
	 * 预收款分类详情专用
	 */
	public function getFinancePrepayList($data)
	{
		$this->clear();
		$this->tableName = 'e_finance_general'.(isset($data['byYear']) && $data['byYear'] ? $data['byYear'] : date('Y'));
		$column = "InOutType,BankName,TypeSon,IsCancelOrder,sum(InOutMoney) as InOutMoney,sum(FeeMoney) as FeeMoney,Type";//取总额
		$result = $this->getSqlWhere($data);
		$query = 'select '.$column.' from ' . $this->tableName . $result['where'] . ' group by InOutType,TypeSon,BankName';
		return $this->select($query, $result['type'] , $result['val']);
	}
}

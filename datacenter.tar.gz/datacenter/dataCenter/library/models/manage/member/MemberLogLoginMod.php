<?php 
namespace models\manage\member;
use core\ModBase;

class MemberLogLoginMod extends ModBase
{
	private $table;

	function __construct()
	{
		parent::__construct('user');
		$this->table = 'e_member_log_login2015';
	}

	public function getInfo($params, $fields = '*', $isOne = false)
	{
		list($where, $bindType, $bindValue) = $this->getWhereSql($params);
		$order = isset($params['order']) ? ' order by ' . $params['order'] : '';
		$limit = isset($params['limit']) ? ' limit ' . $params['limit'] : '';
		return $this->select("select $fields from " . $this->table . ' where ' . $where . $order . $limit, $bindType, $bindValue, $isOne);
	}
   public function getCount($params)
    {
    	list($where, $bindType, $bindValue) = $this->getWhereSql($params);
    	return $this->getOne("select count(Id) from " . $this->table . ' where ' . $where , $bindType, $bindValue);
    }
	public function addInfo($params)
	{
		$sql = "insert into $this->table ";
		$enameId = isset($params['EnameId']) ? $params['EnameId'] : 0;
		$email = isset($params['Email']) ? $params['Email'] : '';
		$ip = isset($params['Ip']) ? $params['Ip'] : '';
		$remark = isset($params['Remark']) ? $params['Remark'] : '';
		$status = isset($params['Status']) ? $params['Status'] : 0;
		$loginTime = isset($params['LoginTime']) ? $params['LoginTime'] : '';
		$openId = empty($params['OpenId']) ? '' : $params['OpenId'];
		$openType = empty($params['OpenType']) ? '' : $params['OpenType'];
		$browser = isset($params['Browser']) ? $params['Browser'] : '';
		$loginFrom = isset($params['LoginFrom']) ? $params['LoginFrom'] : 0;
		$safeAdd = isset($params['SafeAdd']) ? $params['SafeAdd'] : '';
		$sql .= "(EnameId,Email,Ip,Status,LoginTime,Remark,Browser,OpenId,OpenType,LoginFrom,SafeAdd)";
		$sql .= " values (?,?,?,?,?,?,?,?,?,?,?)";
		return $this->add($sql, 'issiisssiis', array($enameId, $email, $ip, $status, $loginTime, $remark, $browser, $openId, $openType, $loginFrom, $safeAdd));
	}
	
	private function getWhereSql($params)
	{
		if(!is_array($params)) 
		{
			return false;
		}
		$where = array();
		$bindValue = array();
		$bindType = '';
		foreach($params as $key => $value) 
		{
			if($key == 'limit' || $key == 'order') 
			{
				continue;
			}
			if($key == 'LoginTimeStart')
			{
				if(!empty($value))
				{
					$where[] = ' LoginTime >= ?';
					$bindValue[] = $value;
					$bindType .= is_string($value) ? 's' : 'i';
				}
				continue;
			}
			if($key == 'LoginTimeEnd')
			{
				if(!empty($value))
				{
					$where[] = ' LoginTime <= ?';
					$bindValue[] = $value;
					$bindType .= is_string($value) ? 's' : 'i';
				}
				continue;
			}
			$fuhao = substr(trim($key), -1);
			if($fuhao == '>') 
			{
				$key = str_replace('>', '', $key);
				$where[] = $key . ' >= ?';
				$bindValue[] = $value;
				$bindType .= is_string($value) ? 's' : 'i';
			}
			else if($fuhao == '<') 
			{
				$key = str_replace('<', '', $key);
				$where[] = $key . ' >= ?';
				$bindValue[] = $value;
				$bindType .= is_string($value) ? 's' : 'i';
			}
			else
			{
				$where[] = $key . ' = ?';
				$bindValue[] = $value;
				$bindType .= is_string($value) ? 's' : 'i';
			}
		}
		$where = implode(' and ', $where);
		return array($where, $bindType, $bindValue);
	}

}
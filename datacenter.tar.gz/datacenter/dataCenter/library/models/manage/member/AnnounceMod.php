<?php
namespace models\manage\member;
use core\ModBase;
class AnnounceMod extends ModBase
{
	private $table;
	function __construct()
	{
		parent::__construct('user');
		$this->table = 'e_announce';
	}
	public function getList($data, $limit = '', $order = '')
	{
		$where = array();
		$wherestr = '';
		$bindType = '';
		$params = array();
		//只取中文公告
		$where[] = 'LangType = ?';
		$bindType .= 'i';
		$params[] = 1;
		if(isset($data['BeginTime']))
		{
			$where[] = 'BeginTime <=?';
			$bindType .= 's';
			$params[] = $data['BeginTime'];
		}
		if(isset($data['EndTime']))
		{
			$where[] = 'EndTime >=?';
			$bindType .= 's';
			$params[] = $data['EndTime'];
		}
		if(isset($data['Purpose']))
		{
			$where[] = "Purpose like '%".$data['Purpose']."%' ";
		}
		if($where)
		{
			$wherestr = ' where ' . implode(' and ', $where);
		}
		$orderstr = empty($order) ? " " : ' order by '.$order;
		$limitstr = empty($limit) ? '' : ' limit '.$limit;
		$query = 'select AnnounceId,Title,CreateTime  from ' . $this->table . $wherestr .$orderstr . $limitstr;
		return $this->select($query, $bindType, $params);
	}
	public function getAnnounceCount($data)
	{
		$where = array();
		$wherestr = '';
		$bindType = '';
		$params = array();
		//只取中文公告
		$where[] = 'LangType = ?';
		$bindType .= 'i';
		$params[] = 1;
		if(isset($data['BeginTime']))
		{
			$where[] = 'BeginTime <=?';
			$bindType .= 's';
			$params[] = $data['BeginTime'];
		}
		if(isset($data['EndTime']))
		{
			$where[] = 'EndTime >=?';
			$bindType .= 's';
			$params[] = $data['EndTime'];
		}
		if(isset($data['Purpose']))
		{
			$where[] = "Purpose like '%".$data['Purpose']."%' ";
		}
		if(isset($data['maxId']))
		{
			$where[] = 'AnnounceId >?';
			$bindType .= 'i';
			$params[] = $data['maxId'];
		}
		if($where)
		{
			$wherestr = ' where ' . implode(' and ', $where);
		}
		$query = 'select count(*) as sum from ' . $this->table . $wherestr;
		return $this->select($query, $bindType, $params,true);
	}
	public function getAnnounceDetail($announceId)
	{
		$query = 'select *  from ' . $this->table . ' where AnnounceId=? and LangType=?';
		return $this->select($query, 'ii', array($announceId, 1),true);
	}
	/**
	 *获取最新消息数量
	 *
	 * @param int $maxid
	 */
	public function getInfoCount($maxid)
	{
		return $this->select("select count(*) as sum from " . $this->table . " where AnnounceId >? and LangType=?" , 'ii', array($maxid, 1),true);
	}
}

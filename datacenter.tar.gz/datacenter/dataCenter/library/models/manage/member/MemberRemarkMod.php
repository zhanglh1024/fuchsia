<?php
namespace models\manage\member;
use core\ModBase;

/**
 * 后台备注模型
 */
class MemberRemarkMod extends ModBase
{

	private $table;

	function __construct()
	{
		parent::__construct('user');
		$this->table = 'e_member_remark';
	}

	/**
	 * 增加有后台备注
	 *
	 * @param array $data        	
	 */
	public function addData($data)
	{
		$sql = "insert into $this->table(EnameId,OperatorId,OperatorName,CreateTime,Ip,RemarkType,Content)";
		$sql .= "values(?,?,?,?,?,?,?)";
		$bindType = 'iisssis';
		$params = array($data['EnameId'], $data['OperatorId'], $data['OperatorName'], $data['CreateTime'], $data['Ip'], 
				$data['RemarkType'], $data['Content']);
		return $this->add($sql, $bindType, $params);
	}
}
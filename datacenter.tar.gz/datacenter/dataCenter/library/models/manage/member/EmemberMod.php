<?php
namespace models\manage\member;
use core\ModBase;

class EmemberMod extends ModBase
{
	private $table;
	private $ext;
	private $regtable;
	function __construct($tableExt = '')
	{
		parent::__construct('user');
		$this->table = $tableExt ? 'e_member_' . $tableExt : 'e_member';
		$this->ext = 'e_member_ext';
		$this->regtable = 'e_member_log_register';
	}

	/**
	 * 根据手机获取用户ID
	 *
	 * @param string $mobile       	
	 */
	public function getInfoBymobile($mobile)
	{
		return $this->select("select EnameId from " . $this->table . " where Mobile=?", 's', array($mobile));
	}
	/**
	 * 根据邮箱获取用户ID
	 *
	 * @param string $mobile
	 */
	public function getInfoByemail($email)
	{
		return $this->select("select EnameId from " . $this->table . " where Email=?", 's', array($email));
	}
	/**
	 * 根据用户Id获取用户邮箱
	 * @param int $enameId
	 * @return string
	 */
	public function getEmailById($enameId)
	{
		return $this->getOne("select Email from " . $this->table . " where EnameId=?", 'i', array($enameId));
	}
	/**
	 * 获取用户ID
	 *
	 * @param string $mobile
	 */
	public function getAllInfo($info)
	{
		return $this->select("select EnameId from " . $this->table . " where IsBanned=? and EnameId>=? and EnameId<?", 'iii', array(0,$info['starId'],$info['endId']));
	}
	public function setMemberInfoByEnameId($enameid,$fields,$key)
	{		
		$sql = "update ". $this->table . " set `".$fields."`=? where EnameId = ?";
		return $this->update($sql, 'ii', array($key,$enameid));
	}
	
	/**
	 * 暂时只有充值时设置用户组和过期时间
	 */
	public function setUserInfoByEnameId($data)
	{
		if(empty($data['enameId']))
		{
			return false;
		}
		$set = array();
		$setType = '';
		$setValue = array();
		if(!empty($data['userGroup']))
		{
			$set[] = 'UserGroup=?';
			$setType .= 'i';
			$setValue[] = $data['userGroup'];
		}
		if(!empty($data['groupDueTime']))
		{
			$set[] = 'GroupDueTime=?';
			$setType .= 's';
			$setValue[] = $data['groupDueTime'];
		}
		if(empty($set))
		{
			return false;
		}
		$sql = "update ". $this->table . " set ".implode(",", $set)." where EnameId = ".$data['enameId'];
		return $this->update($sql, $setType, $setValue, true);
	}
	public function setByEnameId($data,$enameId)
	{
		$sql = "update $this->table ";
		$sql .= "set EnameId=?,Email=?,ChName=?,Password=?,PasswordCode=?,Language=?,IsEmailVerified=?,";
		$sql .= "IsMobileVerified=?,IsIdentityVerified=?,IsCompanyVerified=?,IsSetOperateProtect=?,";
		$sql .= "IsBanned=?,IsCreateTemplate=?,IsGetTransferByMobile=?,UserGroup=?,TencentInfo=?,AlipayInfo=?,WeiBoInfo=?,TaoBaoInfo=?,GroupDueTime=?,RegisterTime=?,ActiveTime=?,LastLoginTime=?,LastLoginIp=?,AcceptType=?,PushAcceptType=?,ProjectId=? where EnameId=?";
		return $this->update($sql, 'issssiiiiiiiiiisssssssssiiii', array($data['EnameId'], $data['Email'], $data['ChName'],
				$data['Password'], $data['PasswordCode'], $data['Language'], $data['IsEmailVerified'], $data['IsMobileVerified'], $data['IsIdentityVerified'], 
				   $data['IsCompanyVerified'], $data['IsSetOperateProtect'], $data['IsBanned'], $data['IsCreateTemplate'], $data['IsGetTransferByMobile'],
				$data['UserGroup'], $data['TencentInfo'], $data['AlipayInfo'], $data['WeiBoInfo'], $data['TaoBaoInfo'], $data['GroupDueTime'], $data['RegisterTime'],
				$data['ActiveTime'], $data['LastLoginTime'], $data['LastLoginIp'], $data['AcceptType'], $data['PushAcceptType'], $data['ProjectId'],$enameId));
	}
	public function setExtByEnameId($data,$enameId)
	{
		$sql = "update $this->table ";
		$sql .= "set EnameId=?,ChFirstName=?,ChLastName=?,EngFirstName=?,EngLastName=?,";
		$sql .= "PhoneC=?,Phone=?,PhoneExt=?,FaxC=?,Fax=?,FaxExt=?,Country=?,ChProvince=?,ChCity=?,ChStreet=?,ChCompanyName=?,";
		$sql .= "EngProvince=?,EngCity=?,EngStreet=?,EngCompanyName=?,PostCode=?,Mobile=?,";
		$sql .= "MemberMenu=?,PermissionExt=?,PhoneA=?,FaxA=? where EnameId=?";
		return $this->update($sql, 'isssssssssssssssssssssssssi', array($data['EnameId'], $data['ChFirstName'],
				$data['ChLastName'], $data['EngFirstName'], $data['EngLastName'], $data['PhoneC'], $data['Phone'],
				$data['PhoneExt'], $data['FaxC'], $data['Fax'], $data['FaxExt'], $data['Country'], $data['ChProvince'],
				$data['ChCity'], $data['ChStreet'], $data['ChCompanyName'], $data['EngProvince'], $data['EngCity'],
				$data['EngStreet'], $data['EngCompanyName'], $data['PostCode'], $data['Mobile'], $data['MemberMenu'], $data['PermissionExt'],
				$data['PhoneA'], $data['FaxA'],$enameId));
	}
	/**
	 * 验证用户是否绑定手机
	 *
	 * @param string $mobile，int ismobile
	 */
	public function getMinfoByEnameid($enameid, $ismobile)
	{
		return $this->select("select IsMobileVerified from " . $this->table . " where EnameId=? and IsMobileVerified=?", 'ii', array(
				$enameid, $ismobile));
	}
	/**
	 * 根据用户ID获取用户是否绑定手机的信息
	 *
	 * @param string $mobile，int ismobile
	 */
	public function getIsMobile($enameid)
	{
		return $this->select("select EnameId, IsMobileVerified from " . $this->table . " where EnameId=?", 'i', array(
				$enameid),true);
	} 
	public function getMemberInfo($enameId, $column = '*')
	{
		$column = is_array($column) ? implode(',', $column) : $column;
		return $this->getRow("select $column from $this->table where EnameId = ?", 'i', array($enameId));
	}
	public function getMemberExtInfo($enameId, $column = '*')
	{
		$column = is_array($column) ? implode(',', $column) : $column;
		return $this->select("select $column from $this->ext where EnameId = ?", 'i', array($enameId),true);
	}
	public function registerMember($data)
	{
		//注册用户直接成为金牌会员
		$data['UserGroup'] = 2;
		$data['GroupDueTime'] = '2099-07-20 00:00:00';
		$isEmailVerified = empty($data['IsEmailVerified']) ? 0 : 1;
		$sql = "insert into $this->table ";
		$sql .= "(EnameId,Email,ChName,Password,PasswordCode,Language,IsEmailVerified,";
		$sql .= "IsMobileVerified,IsIdentityVerified,IsCompanyVerified,IsSetOperateProtect,";
		$sql .= "IsBanned,IsCreateTemplate,IsGetTransferByMobile,UserGroup,TencentInfo,AlipayInfo,WeiBoInfo,TaoBaoInfo,GroupDueTime,RegisterTime,ActiveTime,LastLoginTime,LastLoginIp,AcceptType,PushAcceptType,ProjectId,RegFrom)";
		$sql .= " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		return $this->add($sql, 'issssiiiiiiiiiisssssssssiiii', array($data['EnameId'], $data['Email'], $data['ChName'],
				$data['Password'], $data['PasswordCode'], 0, $isEmailVerified, $data['IsMobileVerified'], 0, 0, 0, 0, 0, 0,
				$data['UserGroup'], '0', '0', '0', '0', $data['GroupDueTime'], $data['RegisterTime'],
				$data['ActiveTime'], '', '', $data['AcceptType'], $data['PushAcceptType'], 0,$data['RegFrom']));
	}
	public function registerMemberExt($data)
	{
		$sql = "insert into $this->table (";
		$sql .= "EnameId,ChFirstName,ChLastName,EngFirstName,EngLastName,";
		$sql .= "PhoneC,Phone,PhoneExt,FaxC,Fax,FaxExt,Country,ChProvince,ChCity,ChStreet,ChCompanyName,";
		$sql .= "EngProvince,EngCity,EngStreet,EngCompanyName,PostCode,Mobile,";
		$sql .= "MemberMenu,PermissionExt,PhoneA,FaxA";
		$sql .= ")values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		return $this->add($sql, 'isssssssssssssssssssssssss', array($data['EnameId'], $data['ChFirstName'],
				$data['ChLastName'], $data['EngFirstName'], $data['EngLastName'], '86', $data['Phone'],
				$data['PhoneExt'], '86', $data['Fax'], $data['FaxExt'], $data['Country'], $data['ChProvince'],
				$data['ChCity'], $data['ChStreet'], $data['ChCompanyName'], $data['EngProvince'], $data['EngCity'],
				$data['EngStreet'], $data['EngCompanyName'], $data['PostCode'], $data['Mobile'], '', '',
				$data['PhoneA'], $data['FaxA']));
	}
	public function getMaxEnameId()
	{
		$sql = "select max(EnameId) as maxenameid from $this->table";
		return $this->getRow($sql, '', array());
	}
	
	//修改信息
	public  function editInfo($info)
	{
		$query = "";
		$where = '';
		$bindtype = '';
		$params = array();
		if(isset($info['IsSetOperateProtect']))
		{
			$query .= !empty($query) ? ' , IsSetOperateProtect = ?': ' set IsSetOperateProtect = ?';
			$params[] = $info['IsSetOperateProtect'];
			$bindtype .= 'i';
		}
		if(isset($info['PasswordCode']))
		{
			$query .= !empty($query) ? ' , PasswordCode = ?': ' set PasswordCode = ?';
			$params[] = $info['PasswordCode'];
			$bindtype .= 's';
		}
		if(isset($info['Password']))
		{
			$query .= !empty($query) ? ' , Password = ?': ' set Password = ?';
			$params[] = $info['Password'];
			$bindtype .= 's';
		} 
		if (isset($info['EnameId']))
		{
			$where = " where EnameId = ?";
			$bindtype .= 'i';
			$params[] = $info['EnameId'];
		}
		
		$sql = "update $this->table".$query .$where;
		return $this->update($sql, $bindtype, $params);
	}
	public function addRegisterLog($data)
	{ 
		$sql = "insert into $this->regtable (";
		$sql .= "Ip,RegisterTime,Content,Browser";
		$sql .= ")values(?,?,?,?)";
		return $this->add($sql, 'ssss', array($data['Ip'], $data['RegisterTime'],
				$data['Content'], $data['Browser']));
	}
	/**
	 * 根据用户id获取密码信息
	 */
	public function getPasswordInfo($enameid)
	{
		$where = $bindValue = array();
		$bindType = '';
		$where[] = 'EnameId = ?';
		$bindValue[] = $enameid;
		$bindType .= 'i';
		$query = "select `Password`,`PasswordCode` from  " . $this->table. ' where ' . implode(' and ', $where);
		return $this->getRow($query, $bindType, $bindValue);
	}
}

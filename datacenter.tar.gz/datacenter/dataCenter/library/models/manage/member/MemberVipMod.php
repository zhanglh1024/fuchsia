<?php
namespace models\manage\member;
use core\ModBase;

class MemberVipMod extends ModBase
{

	private $table;

	function __construct()
	{
		parent::__construct('user');
		$this->table = 'e_member_vip';
	}

	public function delMemberVip($data)
	{
		$query = "delete from  " . $this->table;
		$result = $this->getWherePart($data);
		list($where, $bindType, $bindValue) = $result;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		return $this->delete($query, $bindType, $bindValue);
	}

	public function getVipListAll($type = false)
	{
		$query = "select Content,Type from ".$this->table;
		$bindValue = array();
		$bindType = '';
		if($type)
		{
			$query .= " where Type=?";
			$bindType .= 'i';
			$bindValue[] = $type;
		}
		return $this->select($query, $bindType, $bindValue);
	}

	public function getVipList($data) 
	{
		$query = "select Content,Type from " . $this->table;
		$bindValue = $where = array();
		$bindType = '';
		if(!empty($data['type']))
		{
			$where[] = " Type=?";
			$bindType .= 'i';
			$bindValue[] = $data['type'];
		}
		if(!empty($data['content']))
		{
			$where[] = " Content=?";
			$bindType .= 's';
			$bindValue[] = $data['content'];
		}
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		if(!empty($data['limit']))
		{
			$query .= ' limit ' . $data['limit'];
		}
		return $this->select($query, $bindType, $bindValue);
	}

	/**
	 * 获取 where部分
	 *
	 * @param array
	 * @return list(array,array,string)
	 */
	private function getWherePart($where)
	{
		$whereTemp = $bindValue = array();
		$bindType = '';
		if(! empty($where['Content']) && is_array($where['Content'])){
			$counts = array();
			foreach ($where['Content'] as $val)
			{
				$counts[] = '?';
				$bindType .= 's';
				$bindValue[] = $val;
			}
			$whereTemp[] = ' Content in('.implode(',', $counts).')';
		}
		return array($whereTemp,$bindType,$bindValue);
	}
}

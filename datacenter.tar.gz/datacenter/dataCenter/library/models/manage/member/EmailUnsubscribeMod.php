<?php
namespace models\manage\member;
use core\ModBase;

class EmailUnsubscribeMod extends ModBase
{

	private $table;

	function __construct()
	{
		parent::__construct('user');
		$this->table = 'e_email_unsubscribe';
	}
    /**
     * 
     * @param array  EnameId Email必须 Reason可选
     * @return boolean 
     */ 
	public function addUserUnsubscribe($data)
	{
		$reason=isset($data['Reason'])?$data['Reason']:'';
		$createTime = time();
		$Ip = \common\Common::getRequestIp();
		$sql = "insert into $this->table(EnameId,Email,Reason,CreateTime,IP)";
		$sql .= "values(?,?,?,?,?)";
		return $this->add($sql, 'issis', array($data['EnameId'],$data['Email'],$reason,$createTime,$Ip));
	}

	public function getUserUnsubscribeByEmail($email)
	{
		return $this->getRow("select * from $this->table where Email = ?", 's', array($email));
	}

	public function getUserUnsubscribeEmail($data)
	{
		$query = "select * from  " . $this->table;
		$result = $this->getWherePart($data);
		list($where, $bindType, $bindValue) = $result;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where); 
		} 
		$query .= ' order by CreateTime DESC';
		$offset = $data['Offset'];
		$num = $data['Num'];
		$limit = $offset . ',' . $num;
		$query .= ' limit ' . $limit;
		return $this->select($query, $bindType, $bindValue);
	}

	public function getUnsubscribeEmailCount($data)
	{
		$query = "select count(Id) as Count from  " . $this->table;
		$result = $this->getWherePart($data);
		list($where, $bindType, $bindValue) = $result;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		return $this->getOne($query, $bindType, $bindValue);
	}

	/**
	 * 获取 where部分
	 *
	 * @param array
	 * @return list(array,array,string)
	 */
	private function getWherePart($where)
	{
		$whereTemp = $bindValue = array();
		$bindType = '';
		if(! empty($where['EnameId']))
		{
			$whereTemp[] = 'EnameId = ?';
			$bindValue[] = $where['EnameId'];
			$bindType .= 'i';
		}
		if(! empty($where['Email']))
		{
			$whereTemp[] = 'Email = ?';
			$bindValue[] = $where['Email'];
			$bindType .= 's';
		}
		if(! empty($where['StartDate']))
		{
			$whereTemp[] = 'CreateTime >= ?';
			$bindValue[] = strtotime($where['StartDate'] . '00:00:00');
			$bindType .= 'i';
		}
		if(! empty($where['EndDate']))
		{
			$whereTemp[] = 'CreateTime <= ?';
			$bindValue[] = strtotime($where['EndDate'] . '23:59:59');
			$bindType .= 'i';
		}
		if(! empty($where['IdArr']) && is_array($where['IdArr'])){
			$counts = array();
			foreach ($where['IdArr'] as $Id)
			{
				$counts[] = '?';
				$bindType .= 'i';
				$bindValue[] = $Id;
			}
			$whereTemp[] = ' Id in('.implode(',', $counts).')';
		}
		return array($whereTemp,$bindType,$bindValue);
	}
}

<?php
namespace models\manage\member;
use core\ModBase;
class OperateMod extends ModBase
{
	private $table;
	function __construct()
	{
		parent::__construct('user');
		$this->table =  'e_member_operate_protection';
	}

	//添加数据
	public function addInfo($data)
	{
		$sql = "insert into $this->table(EnameId,Question,QuestionType,Answer,CreateTime,Status)";
		$sql .= "values(?,?,?,?,?,?)";
		return $this->add($sql, 'isissi', array($data['EnameId'], $data['Question'],
				$data['QuestionType'], $data['Answer'], $data['CreateTime'], $data['Status']));
	}
	//删除数据
	public function editStatusInfo($data,$enameid = FALSE)
	{
		$params = array();
		$params['Status'] = $data['Status'];
		$params['QuestionId'] = $data['QuestionId'];
		if(isset($data['EnameId']))
		{
			$enameid = $data['EnameId'];
			$params['EnameId'] = $data['EnameId'];
		}
		$sql = "update  ".$this->table ." set Status = ? where QuestionId = ? " . ($enameid === FALSE ? "  ": " and EnameId = ?") . " limit 1";
		return $this->update($sql, 'ii' . ($enameid === FALSE ? '': 'i') , $params);
	}
	//获取总数
	public function getCountByEnameId($info)
	{
		$sql = "select count(*) as sum from $this->table  where EnameId = ? and Status = ? ";
		return $this->getRow($sql, 'ii', array($info['EnameId'],$info['Status']));
	}
	//获取全部信息
	public function getListByenameId($info)
	{
		$sql = "select * from $this->table  where EnameId = ? and Status = ? ";
		return $this->select($sql, 'ii', array($info['EnameId'],$info['Status']));
	}
	
	//获取全部信息
	public function getOneInfo($info)
	{
		$sql = "select * from $this->table  where  QuestionId=? limit 1";
		return $this->select($sql, 'i', array($info['QuestionId']),TRUE);
	}
}

<?php
namespace models\manage\member;
use core\ModBase;
class AppMemberextMod extends ModBase
{
	private $table;
	function __construct()
	{
		parent::__construct('user');
		$this->table = 'e_member_appext';
	}

	/**
	 * 根据Id获取用户信息
	 *
	 * @param int $enameid       	
	 */
	public function getInfoByEnameId($enameid)
	{
		return $this->getRow("select * from " . $this->table . " where EnameId=?", 'i', array($enameid));
	}
	/**
	 *获取用户信息
	 *
	 * @param int $info 
	 */
	public function getMemberInfo($info)
	{
		$wherestr = '';
		$where = array();
		$bindTye = '';
		$params = array();
		if(isset($info['EnameId']))
		{
			$where[] = '  EnameId =?';
			$bindTye .= 'i';
			$params[] = $info['EnameId'];
		}
		if(isset($info['NickName']))
		{
			$where[] = "NickName like '%".$info['NickName']."%' ";
		}
		if($where)
		{
			$wherestr = ' where '. implode(' and ', $where) . ' and AddFriendSet =?';
		}
		else 
		{
			$wherestr = " where AddFriendSet=?";
		}
		$bindTye .='i';
		$params[] = 1;
		return $this->select("select * from " . $this->table . $wherestr , $bindTye, $params);
	}
	/**
	 *获取用户Id
	 *
	 * @param int $enameid
	 */
	public function getAllMemberInfo($enameid)
	{
		return $this->select("select EnameId from " . $this->table . " where EnameId <>? order by EnameId desc limit 100" , 'i', array($enameid));
	}
	/**
	 * 插入表数据
	 *
	 * @param array $data
	;	 */
	public function registerMember($data)
	{
		$sql = "insert into $this->table ";
		$sql .= "(EnameId,Avatar,NickName,CreateTime)";
		$sql .= " values(?,?,?,?)";
		return $this->add($sql, 'issi', array($data['EnameId'], '', '', $data['CreateTime']));
	}

	public function editInfo($data)
	{
		$setStr = '';
		$bindType = '';
		$params = array();
		if(!empty($data['NickName']))
		{
			$setStr .= 'NickName=?';
			$bindType .= 's';
			$params[] = $data['NickName'];
		}
		if(!empty($data['Avatar']))
		{
			$setStr .= empty($setStr) ? ' Avatar=?' : ' ,Avatar=? ';
			$bindType .= 's';
			$params[] = $data['Avatar'];
		}
		if(!empty($data['UpdateTime']))
		{
			$setStr .= empty($setStr) ? ' UpdateTime=?' : ' ,UpdateTime=? ';
			$bindType .= 'i';
			$params[] = $data['UpdateTime'];
		}
		if(!empty($data['ifPushMess']))
		{
			$setStr .= empty($setStr) ? ' IfPushMess=?' : ' ,IfPushMess=? ';
			$bindType .= 'i';
			$params[] = $data['ifPushMess'];
		}
		if(!empty($data['reMessSet']))
		{
			$setStr .= empty($setStr) ? ' ReMessSet=?' : ' ,ReMessSet=? ';
			$bindType .= 'i';
			$params[] = $data['reMessSet'];
		}
		if(!empty($data['addFriendSet']))
		{
			$setStr .= empty($setStr) ? ' AddFriendSet=?' : ' ,AddFriendSet=? ';
			$bindType .= 'i';
			$params[] = $data['addFriendSet'];
		}
		if(!empty($data['domainFlag']))
		{
			$setStr .= empty($setStr) ? ' domainFlag=?' : ' ,domainFlag=? ';
			$bindType .= 'i';
			$params[] = $data['domainFlag'];
		}
		if(!empty($data['TransFlag']))
		{
			$setStr .= empty($setStr) ? ' TransFlag=?' : ' ,TransFlag=? ';
			$bindType .= 'i';
			$params[] = $data['TransFlag'];
		}
		if(!empty($data['DetailFlag']))
		{
			$setStr .= empty($setStr) ? ' DetailFlag=?' : ' ,DetailFlag=? ';
			$bindType .= 'i';
			$params[] = $data['DetailFlag'];
		}
		if(!empty($data['ChatFlag']))
		{
			$setStr .= empty($setStr) ? ' ChatFlag=?' : ' ,ChatFlag=? ';
			$bindType .= 'i';
			$params[] = $data['ChatFlag'];
		}
		if(!empty($data['DeviceToken']))
		{
			$setStr .= empty($setStr) ? ' DeviceToken=?' : ' ,DeviceToken=? ';
			$bindType .= 's';
			$params[] = $data['DeviceToken'];
		}
		if(!empty($data['Sign']))
		{
			$setStr .= empty($setStr) ? ' Sign=?' : ' ,Sign=? ';
			$bindType .= 's';
			$params[] = $data['Sign'];
		}
		if(!empty($data['LoginStatus']))
		{
			$setStr .= empty($setStr) ? ' LoginStatus=?' : ' ,LoginStatus=? ';
			$bindType .= 'i';
			$params[] = $data['LoginStatus'];
		}
		$params[] = intval($data['EnameId']);
		return $this->update("update $this->table set " . $setStr . " where EnameId=?", $bindType . 'i', $params);
	}
}

<?php
namespace models\manage\member;
use core\ModBase;

class AccountReportMod extends ModBase
{
	private $tableName;
	
	function __construct()
	{
		parent::__construct('user');
		$this->tableName = 'e_member_account_report';
	}
	
	/**
	 * 获取报告记录
	 */
	public function getReport($data, $isOne = false)
	{
		$where = array();
		$bindType = '';
		$params = array();
		if(!empty($data['EnameId']))
		{
			$where[] = 'EnameId = ?';
			$bindType .= 'i';
			$params[] = $data['EnameId'];
		}
		if(!empty($data['Month']))
		{
			$where[] = 'Month = ?';
			$bindType .= 'i';
			$params[] = $data['Month'];
		}
		if($where)
		{
			$wherestsr = ' where ' . implode(' and ', $where);
		}
		$query = "select * from " . $this->tableName;
		if($where)
		{
			$query .= " where " . implode(' and ', $where);
		}
		if($isOne)
		{
			return $this->getRow($query, $bindType, $params);
		}	
		else 
		{
			return $this->select($query, $bindType, $params);
		}
	}
	
	/**
	 * 添加账户报告
	 * @param unknown $data
	 */
	public function addReport($data)
	{
		if(empty($data['enameId']) || empty($data['month']) || empty($data['accountInfo']) || empty($data['domainInfo']) || empty($data['expenses']) || empty($data['incomes']) || empty($data['tradeInfo']))
		{
			return false;
		}
		$query = "insert into ".$this->tableName."(`EnameId`,`Month`,`AccountInfo`,`DomainInfo`,`TradeInfo`,`Expenses`,`Income`) values(?,?,?,?,?,?,?)";
		return $this->add($query, 'issssss', array($data['enameId'],$data['month'],$data['accountInfo'],$data['domainInfo'],$data['tradeInfo'],$data['expenses'],$data['incomes']));
	}
	
	
}
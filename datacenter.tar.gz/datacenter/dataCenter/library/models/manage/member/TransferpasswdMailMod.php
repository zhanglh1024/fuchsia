<?php
namespace models\manage\member;
use core\ModBase;

class TransferpasswdMailMod extends ModBase
{

	private $table;

	function __construct()
	{
		parent::__construct('user');
		$this->table = 'e_member_transferpasswd_mail_phone';
	}

	/**
	 *
	 * @name addInfo 添加新信息到表
	 */
	public function addInfo($data)
	{
		$sql = 'insert into ' . $this->table . '(	enameId,newEmail,
												sfz,org,oldEmail,createDate,
												updateDate,checkStatus,createIp,handle,
												remark,telphone,userName,company,newTelphone,type,verifyUser,idcard,license,licenseType)
			values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
		return $this->add($sql, 'issssiiisssssssisssi', 
			array($data['enameId'], $data['newEmail'], $data['sfz'], $data['org'], $data['oldEmail'], 
					$data['createDate'], $data['updateDate'], $data['checkStatus'], $data['createIp'], '', 
					$data['remark'], $data['telphone'], $data['userName'], $data['company'], $data['newTelphone'], 
					$data['type'], '', '', '', ''));
	}

	/**
	 * 统计用户信息修改情况(注册邮箱 转移密码 绑定手机)
	 */
	public function getUsersetCount($type, $time)
	{
		$checkType = 1;
		if($type == 1)
		{
			$checkType = 1;
		}
		else if($type == 2)
		{
			$checkType = 3;
		}
		else if($type == 3)
		{
			$checkType = 2;
		}
		else if($type == 9)
		{
			$checkType = 4; // passwd
		}
		else if($type == 10)
		{
			$checkType = 5; // op
		}
		$sql = "select count(1) as cscount,FROM_UNIXTIME(verifyDate,'%Y-%m-%d') as vtime,handle as VerifyUser, $type as cstype from " .
			 $this->table . ' where  handle!="" and handle!=0 and type=' . $checkType .
			 ' and FROM_UNIXTIME(verifyDate,"%Y-%m-%d")=? group by handle, cstype,vtime';
		$return = $this->select($sql, 's', array($time));
		return $return ? $return : array();
	}

	public function getTodoCount($type)
	{
		$sql = 'select count(id) as count from ' . $this->table . ' where type = ? && checkStatus = 1';
		return $this->select($sql, 'i', array($type));
	}

	/**
	 * 获取列表
	 *
	 * @param array $data        	
	 * @param string $limit        	
	 * @param string $order        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getList($data, $limit = '', $order = '')
	{
		$where = array();
		$bindType = '';
		$params = array();
		if(! empty($data['id']))
		{
			$where['id'] = ' id = ? ';
			$bindType .= 'i';
			$params[] = $data['id'];
		}
		if(! empty($data['enameid']))
		{
			$where['enameid'] = ' enameid = ? ';
			$bindType .= 'i';
			$params[] = $data['enameid'];
		}
		if(! empty($data['type']))
		{
			$where['type'] = ' type = ? ';
			$bindType .= 'i';
			$params[] = $data['type'];
		}
		if(! empty($data['startDate']))
		{
			$where['startDate'] = ' verifyDate >= ? ';
			$bindType .= 'i';
			$params[] = $data['startDate'];
		}
		if(! empty($data['endDate']))
		{
			$where['endDate'] = ' verifyDate <= ? ';
			$bindType .= 'i';
			$params[] = $data['endDate'];
		}
		if(! empty($data['checkStatus']))
		{
			$where['checkStatus'] = ' checkStatus = ? ';
			$bindType .= 'i';
			$params[] = $data['checkStatus'];
		}
		$wherestr = empty($where) ? '' : ' where ' . implode(' and ', $where);
		$order = empty($order) ? '' : ' order by ' . $order;
		$limit = empty($limit) ? '' : ' limit ' . $limit;
		$query = "select * from $this->table $wherestr $order $limit";
		return $this->select($query, $bindType, $params);
	}

	/**
	 * 根据id更新数据
	 *
	 * @param array $data        	
	 * @param int $id        	
	 * @return Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function updateData($data, $id)
	{
		$setArr = array();
		$bindType = '';
		$params = array();
		$intFields = array('licenseType', 'type', 'checkStatus', 'verifyDate', 'updateDate', 'createDate', 'enameId');
		foreach($data as $key => $value)
		{
			$setArr[] = " $key = ?";
			$params[] = $value;
			$bindType .= in_array($key, $intFields) ? 'i' : 's';
		}
		$query = "UPDATE $this->table SET " . implode(',', $setArr) . " WHERE id = ?";
		$bindType .= 'i';
		$params[] = $id;
		return $this->update($query, $bindType, $params);
	}
}

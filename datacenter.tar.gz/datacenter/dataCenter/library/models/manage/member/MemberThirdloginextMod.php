<?php
namespace models\manage\member;
use core\ModBase;
class MemberThirdloginextMod extends ModBase
{
	private $table;
	function __construct()
	{
		parent::__construct('user');
		$this->table = 'e_member_thirdlogin_ext';
	}
	/**
	 * 插入表数据
	 *
	 * @param array $data
	 */
	public function addInfo($data)
	{
		$data['Status'] = isset($data['Status']) ? $data['Status'] : 0;
		$query = 'insert into ' . $this->table . '(EnameId,Type,Status) values(?,?,?)' ;
		return $this->add($query, 'iii', array($data['EnameId'],$data['Type'],$data['Status']));
	}

	public function getInfo($data,$fields = '*',$isOne = true)
	{
		if(empty($data['EnameId']) || empty($data['type']))
		{
			return FALSE;
		}
		return $this->select("select $fields from " . $this->table . " where EnameId=? and Type=?", 'ii', array($data['EnameId'],$data['type']), $isOne);
	}
	public  function setInfo($data)
	{
		if(empty($data['EnameId']))
		{
			return FALSE;
		}
		$setStr = '';
		$bindType = '';
		$params = array();
		if(isset($data['Status']))
		{
			$setStr .= empty($setStr) ? ' Status=?' : ' ,Status=? ';
			$bindType .= 'i';
			$params[] = $data['Status'];
		}
		$params[] = $data['EnameId'];
		$params[] = $data['type'];
		return $this->update("update $this->table set " . $setStr . " where EnameId=? and Type=?", $bindType . 'ii', $params);
	}
}

<?php 
namespace models\manage\member;
use core\ModBase; 

class MemberFriendMod extends ModBase
{

	private $table;

	private $blacktable;

	function __construct()
	{
		parent::__construct('user');
		$this->table = 'e_member_friend';
		$this->blacktable = 'e_member_friend_black';
	}

	/**
	 * 根据好友Id获取用户列表
	 *
	 * @param int $enameid
	 */
	public function getInfoByEnameId($enameid)
	{
		return $this->select("select * from " . $this->table . " where EnameId=? and Status=?", 'ii', 
			array($enameid, 3));
	}

	/**
	 * 根据好友Id获取数量
	 *
	 * @param int $enameid
	 */
	public function getCountByEnameId($enameid)
	{
		return $this->select("select count(*) as sum from " . $this->table . " where EnameId=? and Status=?", 'ii', 
			array($enameid, 3), true);
	}

	/**
	 * @getUnFriendTotal 获取用户未处理好友请求
	 *
	 * @param int $enameid $topnum
	 *       
	 * @return array
	 */
	public function getUnFriendTotal($data, $limit)
	{
		$wheree = empty($data['EnameId']) ? " " : " and EnameId = ?";
		$bindtype = empty($data['EnameId']) ? "i" : "ii";
		$params = array(2);
		$limits = empty($limit) ? '' : 'limit ' . $limit;
		if(!empty($data['EnameId']))
		{
			$params[] = $data['EnameId'];
		}
		$sql = "select count(*) as num , EnameId  from " . $this->table . " where Status = ? " . $wheree .
			 " group by EnameId order by num desc " . $limits;
		return $this->select($sql, $bindtype, $params);
	}

	/**
	 * @getUnFriendTotal 获取用户未处理好友请求总数
	 *
	 * @param int $enameid $topnum
	 *       
	 * @return array
	 */
	public function getUnFriendcount()
	{
		$sql = "select count(*)  from " . $this->table . " where Status = ?  group by EnameId";
		$rs = $this->select($sql, 'i', array(2));
		if($rs)
		{
			return count($rs);
		}
		return 0;
	}

	/**
	 * 获取好友关系
	 *
	 * @param arrray data
	 */
	public function getFriendShip($data)
	{
		return $this->select("select * from " . $this->table . " where  EnameId=? and  FriendId=?  and  Status=?", 
			'iii', array($data['EnameId'], $data['friendId'], 3), true);
	}

	/**
	 * 根据用户ID获取发送请求过来的好友列表
	 *
	 * @param int $enameid
	 */
	public function getRequestInfo($info, $limit = '', $order = '')
	{
		$where = array();
		$bindTye = '';
		$wherestr = '';
		$params = array();
		if(isset($info['EnameId']))
		{
			$where[] = '  EnameId =?';
			$bindTye .= 'i';
			$params['EnameId'] = $info['EnameId'];
		}
		if(isset($info['Status']))
		{
			$where[] = '  Status =?';
			$bindTye .= 'i';
			$params['Status'] = $info['Status'];
		}
		$orderstr = empty($order) ? " " : ' order by ' . $order;
		$limitstr = empty($limit) ? '' : ' limit ' . $limit;
		if($where)
		{
			$wherestr = ' where ' . implode(' and ', $where);
		}
		return $this->select("select * from " . $this->table . $wherestr . $orderstr . $limitstr, $bindTye, $params);
	}

	/**
	 * 根据用户ID获取发送请求过来的好友数
	 *
	 * @param array $info
	 */
	public function getRequestCount($info)
	{
		$where = array();
		$bindTye = '';
		$wherestr = '';
		$params = array();
		if(isset($info['EnameId']))
		{
			$where[] = '  EnameId =?';
			$bindTye .= 'i';
			$params['EnameId'] = $info['EnameId'];
		}
		if(isset($info['Status']))
		{
			$where[] = '  Status =?';
			$bindTye .= 'i';
			$params['Status'] = $info['Status'];
		}
		if($where)
		{
			$wherestr = ' where ' . implode(' and ', $where);
		}
		return $this->select("select count(*) as sum  from " . $this->table . $wherestr, $bindTye, $params, true);
	}

	/**
	 * 获取二者ID获取单条好友信息
	 *
	 * @param int $data
	 */
	public function getInfo($data)
	{
		if(isset($data['status']))
		{
			return $this->select("select * from " . $this->table . " where EnameId=? and FriendId=? and Status=?", 
				'iii', array($data['EnameId'], $data['friendId'], $data['status']), true);
		}
		else
		{
			return $this->select("select * from " . $this->table . " where EnameId=? and FriendId=?", 'ii', 
				array($data['EnameId'], $data['friendId']), true);
		}
	}
	// 删除数据
	public function delInfo($data)
	{
		$sql = "delete  from  $this->table where EnameId=? AND FriendId=?";
		$rs = $this->delete($sql, 'ii', array($data['EnameId'], $data['friendId']));
		if($rs)
		{
			$sql = "delete from  $this->table where EnameId=? AND FriendId=?";
			return $this->delete($sql, 'ii', array($data['friendId'], $data['EnameId']));
		}
	}

	/**
	 * 获取黑名单信息
	 *
	 * @param int $data
	 */
	public function getBlackInfo($data)
	{
		return $this->select("select * from " . $this->blacktable . " where EnameId=? and FriendId=?", 'ii', 
			array($data['EnameId'], $data['friendId']), true);
	}
	/**
	 * 获取禁言列表
	 *
	 * @param array $data
	 */
	public function getBanInfo($data, $count=true,$limit = '', $order = '')
	{
		$where = array();
		$bindTye = '';
		$wherestr = '';
		$params = array();
		foreach ($data as $key => $value)
		{
			if(isset($value))
			{
				if(preg_match("/[<>](=)?$/", $key))
				{
					$where[] =$key . ' ? ';
					$bindTye .= 'i';
					$params[$key] = $value;
				}else{
					$where[] = '`' . $key . '` =  ?';
					$bindTye .= 'i';
					$params[$key] = $value;
				}
			}
		}
		$orderstr = empty($order) ? " " : ' order by ' . $order;
		$limitstr = empty($limit) ? '' : ' limit ' . $limit;
		if($where)
		{
			$wherestr = ' where ' . implode(' and ', $where);
		}
		if($count)
		{
			return $this->getOne("select count(*) as sum from " . $this->blacktable . $wherestr . $orderstr . $limitstr, $bindTye, $params);
		}
		return $this->select("select * from " . $this->blacktable . $wherestr . $orderstr . $limitstr, $bindTye, $params);
	}
	
	/**
	 * 手动插入好友
	 *
	 * @param array $data ;
	 */
	public function addAutoInfo($data)
	{
		$sql = "insert into $this->table ";
		$sql .= "(EnameId,FriendId,Status,RequestTime)";
		$sql .= " values(?,?,?,?)";
		$rs = $this->add($sql, 'iiii', array($data['EnameId'], $data['friendId'], 3, $data['RequestTime']));
		if($rs)
		{
			$sql = '';
			$sql = "insert into $this->table ";
			$sql .= "(EnameId,FriendId,Status,RequestTime)";
			$sql .= " values(?,?,?,?)";
			return $this->add($sql, 'iiii', array($data['friendId'], $data['EnameId'], 3, $data['RequestTime']));
		}
		return FALSE;
	}

	/**
	 * 插入表数据
	 *
	 * @param array $data ;
	 */
	public function addInfo($data)
	{
		$sql = "insert into $this->table ";
		$sql .= "(EnameId,FriendId,Status,RequestTime)";
		$sql .= " values(?,?,?,?)";
		$rs = $this->add($sql, 'iiii', array($data['EnameId'], $data['friendId'], 1, $data['RequestTime']));
		if($rs)
		{
			$sql = '';
			$sql = "insert into $this->table ";
			$sql .= "(EnameId,FriendId,Status,RequestTime)";
			$sql .= " values(?,?,?,?)";
			return $this->add($sql, 'iiii', array($data['friendId'], $data['EnameId'], 2, $data['RequestTime']));
		}
		return FALSE;
	}

	/**
	 * 插入表数据
	 *
	 * @param array $data ;
	 */
	public function addSingleInfo($data)
	{
		$sql = "insert into $this->table ";
		$sql .= "(EnameId,FriendId,Status,RequestTime)";
		$sql .= " values(?,?,?,?)";
		return $this->add($sql, 'iiii', 
			array($data['EnameId'], $data['friendId'], $data['Status'], $data['RequestTime']));
	}

	/**
	 * 插入黑名单数据
	 *
	 * @param array $data ;
	 */
	public function addBlackInfo($data)
	{
		$sql = "insert into $this->blacktable ";
		$sql .= "(EnameId,FriendId,Status,CreateTime)";
		$sql .= " values(?,?,?,?)";
		return $this->add($sql, 'iiii', 
			array($data['EnameId'], $data['friendId'], $data['Status'], $data['CreateTime']));
	}

	/**
	 * 设置星级用户
	 *
	 * @param array $data ;
	 */
	public function editStarInfo($data)
	{
		if(empty($data['EnameId']) || empty($data['friendId']))
		{
			return FALSE;
		}
		$setStr = '';
		$bindType = '';
		$params = array();
		
		if(!empty($data['UpdateTime']))
		{
			$setStr .= empty($setStr) ? ' UpdateTime=?' : ' ,UpdateTime=? ';
			$bindType .= 'i';
			$params[] = $data['UpdateTime'];
		}
		if(!empty($data['starStatus']))
		{
			$setStr .= empty($setStr) ? ' StarStatus=?' : ' ,StarStatus=? ';
			$bindType .= 'i';
			$params[] = $data['starStatus'];
		}
		$params[] = $data['EnameId'];
		$params[] = $data['friendId'];
		return $this->update("update $this->table set " . $setStr . " where EnameId=? AND FriendId=? ", 
			$bindType . 'ii', $params);
	}

	/**
	 * 设置黑名单
	 *
	 * @param array $data ;
	 */
	public function editBlackInfo($data)
	{
		if(empty($data['EnameId']) || (string) $data['friendId'] == '')//禁言操作时候FriendId=0
		{
			return FALSE;
		}
		$setStr = '';
		$bindType = '';
		$params = array();
		if(isset($data['CreateTime']))
		{
			$setStr .= empty($setStr) ? ' CreateTime=?' : ' ,CreateTime=? ';
			$bindType .= 'i';
			$params[] = $data['CreateTime'];
		}
		if(isset($data['Status']))
		{
			$setStr .= empty($setStr) ? ' Status=?' : ' ,Status=? ';
			$bindType .= 'i';
			$params[] = $data['Status'];
		}
		$params[] = $data['EnameId'];
		$params[] = $data['friendId'];
		return $this->update("update $this->blacktable set " . $setStr . " where EnameId=? AND FriendId=? ", 
			$bindType . 'ii', $params);
	}

	/**
	 * 编辑数据
	 *
	 * @param array $data ;
	 */
	public function editInfo($data)
	{
		if(empty($data['EnameId']) || empty($data['FriendId']))
		{
			return FALSE;
		}
		$setStr = '';
		$bindType = '';
		$params = array();
		
		if(!empty($data['UpdateTime']))
		{
			$setStr .= empty($setStr) ? ' UpdateTime=?' : ' ,UpdateTime=? ';
			$bindType .= 'i';
			$params[] = $data['UpdateTime'];
		}
		if(!empty($data['RequestTime']))
		{
			$setStr .= empty($setStr) ? ' RequestTime=?' : ' ,RequestTime=? ';
			$bindType .= 'i';
			$params[] = $data['RequestTime'];
		}
		if(!empty($data['CreatTime']))
		{
			$setStr .= empty($setStr) ? ' CreatTime=?' : ' ,CreatTime=? ';
			$bindType .= 'i';
			$params[] = $data['CreatTime'];
		}
		if(!empty($data['Status']))
		{
			$setStr .= empty($setStr) ? ' Status=?' : ' ,Status=? ';
			$bindType .= 'i';
			$params[] = $data['Status'];
		}
		$params[] = $data['EnameId'];
		$params[] = $data['FriendId'];
		$rs = $this->update("update $this->table set " . $setStr . " where FriendId=? AND EnameId=? ", $bindType . 'ii', 
			$params);
		if($rs)
		{
			return $this->update("update $this->table set " . $setStr . " where EnameId=? and FriendId=? ", 
				$bindType . 'ii', $params);
		}
	}

	public function editInfoSingle($data)
	{
		if(empty($data['EnameId']) || empty($data['friendId']))
		{
			return FALSE;
		}
		$setStr = '';
		$bindType = '';
		$params = array();
		if(!empty($data['RequestTime']))
		{
			$setStr .= empty($setStr) ? ' RequestTime=?' : ' ,RequestTime=? ';
			$bindType .= 'i';
			$params[] = $data['RequestTime'];
		}
		if(!empty($data['Status']))
		{
			$setStr .= empty($setStr) ? ' Status=?' : ' ,Status=? ';
			$bindType .= 'i';
			$params[] = $data['Status'];
		}
		if(isset($data['Remark']))
		{
			$setStr .= empty($setStr) ? ' Remark=?' : ' ,Remark=? ';
			$bindType .= 's';
			$params[] = $data['Remark'];
		}
		$params[] = $data['EnameId'];
		$params[] = $data['friendId'];
		return $this->update("update $this->table set " . $setStr . " where EnameId=? AND FriendId=? ", 
			$bindType . 'ii', $params);
	}
}

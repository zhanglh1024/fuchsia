<?php
namespace models\manage\member;
use core\ModBase;
class MemberSafeMod extends ModBase
{
	private $address;
	private $device;
	function __construct($user = 'user')
	{
		parent::__construct($user);
		$this->address = 'e_member_safeadress';
		$this->device = 'e_member_safedevice';
	}
	
	/**
	 * 添加安全地址
	 * @param unknown_type $params
	 * @return boolean
	 */
	public function addSafeAdress($params)
	{
		if(empty($params))
		{
			return FALSE;
		}
		$enameId = empty($params['enameId']) ? '' : $params['enameId'];
		$ip = empty($params['ip']) ? '' : $params['ip'];
		$uptime = empty($params['updateTime']) ? '' : $params['updateTime'];
		$address= empty($params['address']) ? '' : $params['address'];
		return $this->add("insert into $this->address(EnameId,Ip,UpdateTime,SafeAdd) values(?,?,?,?)", 'ssis', array($enameId,$ip,$uptime,$address));
	}
	
	/**
	 * 添加安全设备
	 * @param unknown_type $params
	 * @return boolean
	 */
	public function addSafeDevice($params)
	{
		if(empty($params))
		{
			return FALSE;
		}
		$enameId = empty($params['enameId']) ? '' : $params['enameId'];
		$deviceIdentifier = empty($params['deviceIdentifier']) ? '' : $params['deviceIdentifier'];
		$deviceName = empty($params['deviceName']) ? '' : $params['deviceName'];
		$uptime = empty($params['updateTime']) ? '' : $params['updateTime'];
		return $this->add("insert into $this->device(EnameId,DeviceIdentifier,DeviceName,UpdateTime) values(?,?,?,?)", 'issi', array($enameId,$deviceIdentifier,$deviceName,$uptime));
	}
	
	/**
	 * 根据id获取安全信息
	 * @param unknown_type $id
	 * @param unknown_type $field
	 * @param unknown_type $type
	 * @return multitype:
	 */
	public function getSafeInfoById($id,$field="*",$type = 1)
	{
		$table = $type == 1 ? $this->address : $this->device;
		return $this->getRow("select $field from $table where Id = ? ", 'i', array($id));
	}
	
	/**
	 * 获取安全地址列表
	 * @param unknown_type $where
	 * @param unknown_type $fields
	 * @return Ambigous <multitype:, boolean, unknown>
	 */
	public function getSafeAdressList($where,$fields = "*",$order = FALSE,$limit = FALSE)
	{
		$whereDatas = $this->getWhereSql($where);
		if(empty($whereDatas[0]))
		{
			$sql = "select $fields from $this->address";
		}
		else {
			$sql = "select $fields from $this->address where " . implode(' and ', $whereDatas[0]);
		}
		if($order)
		{
			$sql .= ' order by '.$order;
		}
		else {
			$sql .= ' order by Id desc';
		}
		if($limit)
		{
			$sql .= ' limit '.$limit;
		}
		return $this->select($sql, $whereDatas[1], $whereDatas[2]);
	}
	
	/**
	 * 获取安全设备列表
	 * @param unknown_type $params
	 * @return Ambigous <multitype:, boolean, unknown>
	 */
	public function getSafeDeviceList($where,$fields = "*",$order = FALSE,$limit = FALSE)
	{
		$whereDatas = $this->getWhereSql($where);
		$sql = "select $fields from $this->device where " . implode(' and ', $whereDatas[0]);
		if($order)
		{
			$sql .= ' order by '.$order;
		}
		if($limit)
		{
			$sql .= ' limit '.$limit;
		}
		return $this->select($sql, $whereDatas[1], $whereDatas[2]);
	}
	
	/**
	 * 删除安全信息
	 * @param unknown_type $id
	 * @param unknown_type $type
	 * @return boolean
	 */
	public function delSafeInfoById($id,$enameId,$type = 1)
	{
		$table = $type == 1 ? $this->address : $this->device;
		return $this->delete("delete from $table where Id=? and EnameId =?", 'ii', array($id,$enameId));
	}
	
	public function getSafeCount($params,$type = 1 )
	{
		$table = $type == 1 ? $this->address : $this->device;
		$whereDatas = $this->getWhereSql($params);
		if(empty($whereDatas[0]))
		{
			return $this->getRow("select count(*) as total from $table ",array(),array());
		}
		else {
			return $this->getRow("select count(*) as total from $table where " . implode(' and ', $whereDatas[0]), $whereDatas[1], $whereDatas[2]);
		}
	}
	
	
	/**
	 * 更新安全设备信息
	 * @param unknown_type $id
	 * @param unknown_type $set
	 * @param unknown_type $type
	 */
	public function updateSafeDevice($where ,$set)
	{
		if(empty($where) || empty($set))
		{
			return FALSE;
		}
		$upData = $bindValue = array();
		$bindType = '';
		foreach($set as $key => $value)
		{
			$upData[] = $key . '= ? ';
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		$whereDatas = $this->getWhereSql($where);
		return $this->update("update $this->device set " . implode(',', $upData) . ' where ' . implode(' and ', $whereDatas[0]), $bindType . $whereDatas[1], array_merge($bindValue, $whereDatas[2]));
	}
	
	/**
	 * 更新安全地址信息
	 * @param unknown_type $where
	 * @param unknown_type $set
	 * @return boolean
	 *
	 */
	public function updateSafeAdress($where,$set)
	{
		if(empty($where) || empty($set))
		{
			return FALSE;
		}
		$upData = $bindValue = array();
		$bindType = '';
		foreach($set as $key => $value)
		{
			$upData[] = $key . '= ? ';
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		$whereDatas = $this->getWhereSql($where);
		return $this->update("update $this->address set " . implode(',', $upData) . ' where ' . implode(' and ', $whereDatas[0]), $bindType . $whereDatas[1], array_merge($bindValue, $whereDatas[2]));
	}
	
	/**
	 * where条件组装
	 * @param array $where array('DomainId' => 123, 'in' => array('DomainMyStatus' => array(2, 3)))
	 * @return array  array($whereData, $bindType, $bindValue)
	 */
	private function getWhereSql($where)
	{
		$whereData = $bindValue = array();
		$bindType = '';
		foreach($where as $key => $value)
		{
			if(stripos($key,'order')!==FALSE||stripos($key,'limit')!==FALSE ||stripos($key,'pagesize')!==FALSE ||stripos($key,'offset')!==FALSE )
			{
				continue;
			}
			if($key == 'in')
			{
				$keys = array_keys($where['in']);
				foreach($keys as $k => $v)
				{
					$wen = trim(str_repeat('?,', count($where['in'][$v])), ',');
					$whereData[] = $v . ' in (' . $wen . ')';
					foreach($where['in'][$v] as $val)
					{
						$bindType .= is_string($val) ? 's' : 'i';
						$bindValue[] = $val;
					}
				}
			}
			elseif(substr(trim($key), -1) == '<')
			{
				$key = str_replace('<', '', $key);
				$whereData[] = $key . ' <= ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
			elseif(substr(trim($key), -1) == '>')
			{
				$key = str_replace('>', '', $key);
				$whereData[] = $key . ' >= ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
			else
			{
				$whereData[] = $key . ' = ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		return array($whereData, $bindType, $bindValue);
	}	
}

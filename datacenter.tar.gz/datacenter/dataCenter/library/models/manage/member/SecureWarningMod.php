<?php
namespace models\manage\member;
use core\ModBase;
class SecureWarningMod extends ModBase
{
	private $table;
	function __construct($tableExt = '')
	{
		parent::__construct('user');
		$this->table = 'e_member_secure_warning';
	}
	
	 //添加安全警报信息	
	public function addInfo($data)
	{
		$sql = "insert into $this->table ";
		$ext = isset($data['Ext']) ? $data['Ext'] : '';
		$status = isset($data['Status'])  && $data['Status'] != 0 ? $data['Status'] : 1;
		$handlestatus = isset($data['HandleStatus']) ? $data['HandleStatus'] : 0;
		$remark = isset($data['Remark']) ? $data['Remark'] : '';
		$handle = isset($data['Handle']) ? $data['Handle'] : 0;
		$updatedate = isset($data['UpdateDate']) ? $data['UpdateDate'] : 0;
		$deviceToken = isset($data['DeviceToken']) ? $data['DeviceToken'] : ''; 
		$dealWay= !empty($data['DealWay']) ? $this->makeTag($data['DealWay']) : '1';  
		$sql .= "(EnameId,BusinessType,Domain,Content,Ext,IP,Priority,CreateDate,AddDate,Status,Remark,Handle,UpdateDate,HandleStatus,DealWay)";
		$sql .= " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		$result = $this->add($sql, 'iissssiiiisiiii', array($data['enameid'], $data['BusinessType'], $data['domain'], $data['Content'], $ext, $data['IP'], $data['Priority'], $data['CreateDate'], time(), $status, $remark, $handle, $updatedate,$handlestatus,$dealWay));
		if($result)
		{
			$this->amqb($data['enameid'], $data['domain'], $data['BusinessType'],0,$status,time());//写mq
		}
		return $result;
	}

	//管理员更新信息

	public function updateInfo($data)
	{
		$setStr = array();
		$types = '';
		$where = '';
		$params = array();
		if (isset($data['Remark']) && !empty($data['Remark'])) 
		{
			$setStr[] = 'Remark = ?';
			$types .= 's';
			$params[] = $data['Remark'];
		}
		if (isset($data['Status']) && !empty($data['Status'])) 
		{
			$setStr[] = 'Status = ?';
			$types .= 'i';
			$params[] = $data['Status'];
		}
		if (isset($data['Handle']) && !empty($data['Handle'])) 
		{
			$setStr[] = 'Handle = ?';
			$types .= 'i';
			$params[] = $data['Handle'];
		}
		if (isset($data['HandleStatus']) && !empty($data['HandleStatus']))
		{
			$setStr[] = 'HandleStatus = ?';
			$types .= 'i';
			$params[] = $data['HandleStatus'];
		}
		if(!empty($data['DealWay']))
		{
			$setStr[] = 'DealWay = ?';
			$types .= 's';
			$params[] = $this->makeTag($data['DealWay']);
		}
		$setStr[] = 'UpdateDate = ?';
		$types .= 'i';
		$params[] = time();
		if (isset($data['Id']) && !empty($data['Id'])) 
		{
			if (count($data['Id']) == 1) 
			{
				$where = ' where Id = ?';
				$types .= 'i';
				$params[] = $data['Id'];
				$datas[] = $data['Id'];
			}
			else
			{
				$where = ' where Id in()';
				$counts = array();
				foreach ($data['Id'] as $id) 
				{
					$counts[] = '?';
					$types .= 'i';
					$params[] = $id;
				}
				$where = ' where Id in('.implode(',', $counts).')';
				$datas = $data['Id'];
			}
			
		}
		else 
		{
			return false;
		}
		if(isset($data['Status']) && !empty($data['Status']))
		{
			foreach ($datas as $id)
			{
				$secureinfoArr[]=$this->getWarningInfoById($id);
			}
		}
		$result = $this->update("update $this->table set " . implode(',', $setStr) . $where, $types, $params);
		if(isset($data['Status']) && !empty($data['Status']) && $result)
		{
			foreach ($secureinfoArr as $secureinfo)
			{
				$this->amqb($secureinfo['EnameId'], $secureinfo['Domain'],$secureinfo['BusinessType'],$secureinfo['Status'], $data['Status'],$secureinfo['CreateDate']);
			}
		}
		return $result;
	}
	
	//通过id获取信息
	public function getWarningInfoById($id)
	{
		return $this->getRow("select * from $this->table where Id = ?", "i", array($id));
	}
	
	//获取信息列表
	public function getWarningList($data, $fields = '*', $isOne = FALSE)
	{
		list($wherestsr, $bindType, $params) = $this->getWhereData($data);
		$orderstr = isset($data['order']) && $data['order'] ? ' ORDER BY ' . $data['order'] : '';
		$limitstr = isset($data['limit']) && $data['limit'] ? ' LIMIT ' . $data['limit'] : '';
		return $this->select("select $fields from $this->table " . $wherestsr . $orderstr . $limitstr, $bindType, $params, $isOne);
	}
	
	//获取消息总数
	public function getCount($data)
	{
		list($wherestsr, $bindType, $params) = $this->getWhereData($data);
		return $this->select("select count(*) as sum from $this->table " . $wherestsr, $bindType, $params,true);
	}
	public function getUnormalWarningList($data, $fields = '*', $isOne = FALSE)
	{
		list($wherestsr, $bindType, $params) = $this->getWhereData($data);
		$orderstr = ' ORDER BY SUM DESC';
		$limitstr = isset($data['limit']) ? ' LIMIT ' . $data['limit'] : '';
		return $this->select("select COUNT(*) AS SUM ,EnameId from $this->table " . $wherestsr . " group by EnameId " . $orderstr . $limitstr , $bindType, $params, $isOne);
	}
	public function getUnormalWarningListCount($data, $fields = '*', $isOne = FALSE)
	{
		list($wherestsr, $bindType, $params) = $this->getWhereData($data);
		return $this->select("select COUNT(*) AS SUM ,EnameId from $this->table " . $wherestsr. " group by EnameId ", $bindType, $params, $isOne);
	}
	private function getWhereData($params)
	{
		if(!is_array($params)) 
		{
			return false;
		}
		$where = array();
		$bindValue = array();
		$bindType = '';
		foreach($params as $key => $value) 
		{
			if(!$value || $key == 'order' || $key == 'limit') 
			{
				continue;
			}
			else if($key == 'BusinessType' && is_array($value)){
				$counts = array();
				foreach ($value as $businessType)
				{
					$counts[] = '?';
					$bindType .= 'i';
					$bindValue[] = $businessType;
				}
				$where[] = ' BusinessType in('.implode(',', $counts).')';
			}
			else if($key == 'EnameId'&&  is_array($value)){
			   $counts = array();
				foreach ($value as $enameId)
				{
					$counts[] = '?';
					$bindType .= 'i';
					$bindValue[] = $enameId;
				}
				$where[] = ' EnameId in('.implode(',', $counts).')';
			}
			else if($key == 'HandleStatus' && $value==9)
			{
				$where[] = 'HandleStatus = ?';
				$bindValue[] = 0;
				$bindType .= 'i';
			}
			else if($key == 'createbegin') 
			{
				$where[] = 'CreateDate >= ?';
				$bindValue[] = strtotime($value);
				$bindType .= 's';
			}
			else if($key == 'createend') 
			{
				$where[] = 'CreateDate <= ?';
				$bindValue[] = strtotime($value);
				$bindType .= 's';
			}
			else if($key == 'updatebegin') 
			{
				$where[] = 'UpdateDate >= ?';
				$bindValue[] = strtotime($value);
				$bindType .= 's';
			}
			else if($key == 'updateend') 
			{
				$where[] = 'UpdateDate <= ?';
				$bindValue[] = strtotime($value);
				$bindType .= 's';
			}
			else if($key == 'Handle') 
			{
				//管理员与非管理员搜索，管理员ID:21 0的也记录成管理员
				if ($value == 1)//管理员
				{
					$where[] = 'Handle in(?,?)';
					$bindValue[] = 0;
					$bindValue[] = 21;
					$bindType .= 'ii';
				}
				else if ($value == 2) //非管理员
				{
					$where[] = 'Handle not in(?,?)';
					$bindValue[] = 0;
					$bindValue[] = 21;
					$bindType .= 'ii';
				} 
				else
				{
					//查询修改过的adminId
					$where[] = 'Handle = ?';
					$bindValue[] = $value;
					$bindType .= 'i';
				}
				continue;
			}
			elseif($key == 'DealWay')
			{
				$value = $this->makeTag($value);
				$where[] = " DealWay & $value = ? ";
				$bindValue[] = $value;
				$bindType .= 'i';
			}
			elseif($key == 'Remark')
			{
				if(is_numeric($value))
				{
					$config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'securewarning');
					$remark = $config->user->remark->toArray();
					//是否查其他备注
					if($value==6)
					{
						foreach($remark["type"] as $k => $v)
						{
							if($k != 6)
							{
								$value = $v;
								$where[] = ' Remark not like ?';
								$bindValue[] = $value;
								$bindType .= 's';
							}
						}
					}
					else 
					{
						$value=$remark["type"][$value];
						$where[] = ' Remark like ?';
						$bindValue[] = $value;
						$bindType .= 's';
					}
				}
				else 
				{
					$where[] = ' instr(Remark,?) >0';
					$bindValue[] = $value;
					$bindType .= 's';
				}
			}
			else
			{
				$where[] = $key . ' = ?';
				$bindValue[] = $value;
				$bindType .= is_string($value) ? 's' : 'i';
			}
		}
		$where = $where ? ' where ' . implode(' and ', $where) : '';
		return array($where, $bindType, $bindValue);
	}

	
	public function updateInfoBySystem($info)
	{
		$secureinfoArr=$this->getWarningList(array('EnameId'=>$info['enameid'],'BusinessType'=>$info['BusinessType']));
		$params = array($info['Remark'], $info['Handle'], time(), $info['enameid'], $info['BusinessType']);
		$result = $this->update("update $this->table set Status=3,Remark=?,Handle=?,UpdateDate=? where EnameId=? and BusinessType=? order by CreateDate DESC limit 1", 'siiii', $params);
		if($result)
		{
			foreach ($secureinfoArr as $secureinfo)
			{
				$this->amqb($secureinfo['EnameId'], $secureinfo['Domain'],$secureinfo['BusinessType'],$secureinfo['Status'], 3,$secureinfo['CreateDate']);
			}
		}
		return $result;
	}
	
	
	public function getSecureWarningCount($type, $startTime, $endTime)
	{
		$sql = 'select count(1) as cscount,FROM_UNIXTIME(UpdateDate,\'%Y-%m-%d\') as vtime,Handle as VerifyUser, '.$type.' as cstype from '.$this->table .' where  Handle!="" and Handle!=0  and UpdateDate between ? and ? group by Handle,vtime,cstype';
		return $this->select($sql,'ii',array($startTime, $endTime));
	}
	
	private function parseTags($tag)
	{
		$articleTags = array();
		for($i = 1; $i <= 4; $i ++)
		{
			$k = pow(2, $i - 1);
			if($tag & $k)
			{
				$articleTags[] = $i;
			}
		}
		return implode(',', $articleTags);
	}
	
	private function makeTag($tags)
	{
		$tags = explode(',', $tags);  
		$tag = 0;
		for($i = 1; $i <= 4; $i ++)
		{
			if(in_array($i, $tags))
			{
				$tag += pow(2, $i - 1);
			}
		}
		return $tag;
	}
	private function amqb($enameId='',$domain='',$businessType='',$oldStatus = 1,$newStatus = 1,$createTime)
	{
		$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'member_secure_warning'));
		$amqp->sendMq(
			array('name' => 'member_secure_warning', 'enameId' => $enameId, 'businessType' => $businessType, 
				'oldStatus' => $oldStatus, 'newStatus' => $newStatus, 'domain' => $domain, 'time' => time(), 
				'createTime' => $createTime));
		return true;
	}
}

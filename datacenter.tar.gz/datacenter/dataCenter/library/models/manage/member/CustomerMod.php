<?php
namespace models\manage\member;
use core\ModBase;

class CustomerMod extends ModBase
{
	private $table;
	function __construct($db = 'admin')
	{
		$this->table = 'cs_user_list';
		parent::__construct($db);
	}

	public function getCustomerByName($name, $fields)
	{
		return $this->getRow("select $fields from $this->table where UserName = ? or RealName = ?", "ss", array(
				$name, $name));
	}
}

<?php
namespace models\manage\member;
use core\ModBase;
class CancelOperateLogMod extends ModBase
{
	private $table;
	function __construct()
	{
		parent::__construct('user');
		$this->table =  'e_member_log_cancel_operate';
	}

	//添加数据
	public function addInfo($data)
	{
		$sql = "insert into $this->table(EnameId,QuestionId,CancelTime)";
		$sql .= " values(?,?,?)";
		return $this->add($sql, 'iis', array($data['EnameId'], $data['QuestionId'], $data['CancelTime']));
	}
	
}

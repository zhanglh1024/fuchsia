<?php
namespace models\manage\member;
use core\ModBase;
class EcommonSetMod extends ModBase
{
	private $tableName;
	function __construct()
	{
		parent::__construct('user');
		$this->tableName = 'e_common_setting';
	}
	
	public function  addInfo($data)
	{
		$sql = "insert into $this->tableName (";
		$sql .= "Identifier,IdentifierName,IdentifierType,Sort,IsProtect,IsMobile,IsMessage,IsEmail,IsPhone,IsCenter,Remark";
		$sql .= ")value(?,?,?,?,?,?,?,?,?,?,?)";
		return $this->add($sql, 'isiiiiii', array($data['Identifier'],$data['IdentifierName'],$data['IdentifierType'], $data['Sort'],$data['IsProtect'],
				$data['IsMobile'], $data['IsMessage'], $data['IsEmail'], $data['IsPhone'],  $data['IsCenter']));
	}
	
	public function editInfo($data)
	{
		$sql = "update $this->tableName set";
		$sql .= "IsProtect=?,IsMobile=?,IsMessage=?,IsEmail=?,IsPhone=?,IsCenter=? where Identifier=?";
		return $this->add($sql, 'iiiiiiS', array($data['IsProtect'],
				$data['IsMobile'], $data['IsMessage'], $data['IsEmail'], $data['IsPhone'],  $data['IsCenter'],$data['Identifier']));
	}
	/**
	 * 查询提醒/验证方式
	 * @param int $identifier
	 * @return 一行数提醒/验证数组
	 */
	public function getCommonSettingByIdentifier($identifier)
	{
		$sql = "select * from $this->tableName where Identifier=? ";
		return $this->getRow($sql, 's', array($identifier));
	}
	
	public function getList($data)
	{
		$where = '';
		$bindType = '';
		$params = array();
		
		if(isset($data['Identifier']))
		{
			$where =  ' where Identifier =?  ';
			$bindType =  's';
			$params['Identifier'] =  $data['Identifier'];
		}
		$query = 'select * from ' . $this->tableName .$where ;
		return $this->select($query, $bindType, $params);
	}
}
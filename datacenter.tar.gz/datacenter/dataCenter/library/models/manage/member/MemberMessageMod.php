<?php
namespace models\manage\member;

use core\ModBase;
class MemberMessageMod extends ModBase
{
 
	private $table;

	function __construct()
	{
		parent::__construct('user');
		$this->table = 'e_member_message';
	}

	private function setTableName($year = false)
	{
		$this->table = 'e_member_message';
		if($year && $year <= date('Y'))
		{
			$this->table = $this->table . $year;
		}
		else
		{
			$this->table = $this->table . date('Y');
		}
	}

	/**
	 * 添加站內信
	 *
	 * @param array $data
	 * @return boolean
	 */
	public function addInfo($data)
	{
		self::setTableName();
		$sql = "insert into $this->table ";
		$sql .= "(EnameId,SendId,Title,Content,MessageType,Status,TemplateId,SendTime,ParamsCode)";
		$sql .= " values(?,?,?,?,?,?,?,?,?)";
		return $this->add($sql, 'iissiisss', 
			array($data['EnameId'], $data['SendId'], $data['Title'], $data['Content'], $data['MessageType'], 0, 
				$data['TemplateId'], date('Y-m-d H:i:s'), 
				is_array($data['Data']) ? json_encode($data['Data']) : $data['Data']));
	}

	/**
	 * 获取站內信列表
	 *
	 * @param array $data
	 * @param string $orderstr
	 * @param string $limitstr
	 * @return array boolean
	 */
	public function getList($data, $limit, $order)
	{
		list($wherestsr, $bindType, $params) = $this->getWhereData($data);
		$orderstr = empty($order) ? " " : ' order by ' . $order;
		$limitstr = empty($limit) ? ' ' : ' limit ' . $limit;
		$year = isset($data['byYear']) ? $data['byYear'] : false;
		self::setTableName($year);
		return $this->select("select * from $this->table " . $wherestsr . $orderstr . $limitstr, $bindType, $params);
	}

	/**
	 * 获取站內信数量
	 *
	 * @param array $data
	 * @return number
	 */
	public function getCount($data)
	{
		list($wherestsr, $bindType, $params) = $this->getWhereData($data);
		$year = isset($data['byYear']) ? $data['byYear'] : false;
		self::setTableName($year);
		return $this->select("select count(*) as sum  from $this->table " . $wherestsr, $bindType, $params, true);
	}

	/**
	 * 获取站內信详情
	 *
	 * @param int $Id
	 * @return array boolean
	 */
	public function getMessageDetail($Id)
	{
		self::setTableName();
		$query = 'select *  from ' . $this->table . ' where MessageId=?';
		return $this->getRow($query, 'i', array($Id), true);
	}

	/**
	 * 更改站内信状态
	 *
	 * @param int $Id
	 * @param int $status 默认1已读
	 * @return array boolean
	 */
	public function updateMessageStatus($id, $status = 1)
	{
		self::setTableName();
		$query = 'update  ' . $this->table . ' set Status=? where MessageId=?';
		return $this->update($query, 'ii', array($status, $id));
	}

	/**
	 * 批量更改站内信的状态（MessageId,EnameId）
	 *
	 * @param $data['MessageId']
	 * @param $data['EnameId']
	 * @param $data['Status'] 1已读，2回收站
	 * @param $data['byYear'] 查询年份
	 * @return msg
	 */
	public function updateStatusBatch($data, $setStatus)
	{
		$year = empty($data['byYear']) ? false : $data['byYear'];
		self::setTableName($year);
		list($wherestsr, $bindType, $params) = $this->getWhereData($data);
		if($setStatus == 1)
		{
			$query = 'update  ' . $this->table . ' set Status=1 , ViewTime="' . date('Y-m-d H:i:s') . '"' . $wherestsr;
		}
		else
		{
			$query = 'update  ' . $this->table . ' set Status=' . $setStatus . $wherestsr;
		}
		return $this->update($query, $bindType, $params);
	}

	/**
	 * 更改站内信状态
	 *
	 * @param int $Id
	 * @param int $status 默认1已读
	 * @return array boolean
	 */
	public function updateMessageStatusFenXiao($id, $enameId, $status = 1)
	{
		self::setTableName();
		$query = 'update  ' . $this->table . ' set Status=? where MessageId=? and EnameId=?';
		return $this->update($query, 'iii', array($status, $id, $enameId));
	}

	/**
	 * 更改全部站内信的状态（EnameId）
	 *
	 * @param $data['EnameId']
	 * @param $data['Status'] 1已读
	 * @param $data['byYear'] 查询年份
	 * @return msg
	 */
	public function updateAllStatus($data)
	{
		$year = empty($data['byYear']) ? false : $data['byYear'];
		self::setTableName($year);
		list($wherestsr, $bindType, $params) = $this->getWhereData($data);
		$query = 'update  ' . $this->table . ' set Status=1 , ViewTime="' . date('Y-m-d H:i:s') . '"' . $wherestsr .
			 '  and Status =0';
		return $this->update($query, $bindType, $params);
	}

	/**
	 * 获取最新站內信列表
	 *
	 * @param array $data
	 * @return array boolean
	 */
	public function getMessageMax($data)
	{
		self::setTableName();
		list($wherestsr, $bindType, $params) = $this->getWhereData($data);
		return $this->select(
			"select MessageId,Title,SendTime,Content, ParamsCode,TemplateId from $this->table " . $wherestsr .
				 ' order by MessageId desc limit 1', $bindType, $params, true);
	}

	/**
	 * 获取还没有push 的列表
	 */
	public function getAppPushList($data)
	{
		self::setTableName();
		$params = array();
		$wherestr = $bindType = '';
		$status = isset($data['status']) ? $data['status'] : '';
		$messId = isset($data['messId']) ? $data['messId'] : 0;
		$params[] = $status;
		$params[] = $messId;
		if(!empty($data['MessageTypeIn']))
		{
			$wherestr = ' and  MessageType  in (' . implode(',', array_fill(0, count($data['MessageTypeIn']), '?')) . ')';
			$bindType .= implode('', array_fill(0, count($data['MessageTypeIn']), 'i'));
			$params[] = $data['MessageTypeIn'];
		}
		// 站内短信存在的时候
		if($messId)
		{
			$sql = "select  MessageId,Title,EnameId,MessageType,ParamsCode ,TemplateId  from " . $this->table .
				 " where Status = ? and MessageId > ? " . $wherestr . "  order by MessageId asc ";
			return $this->select($sql, 'ii' . $bindType, $params);
		}
		else
		{
			$sql = "select  MessageId,Title,EnameId,MessageType,ParamsCode , TemplateId from " . $this->table .
				 " where Status = ? " . $wherestr . " order by MessageId asc ";
			
			return $this->select($sql, 'i' . $bindType, $params);
		}
	}

	/**
	 * 获取站内信搜索条件
	 *
	 * @param array $data
	 * @return array
	 */
	private function getWhereData($data)
	{
		$where = array();
		$wherestsr = '';
		$bindType = '';
		$params = array();
		
		if(!empty($data['EnameId']))
		{
			$where[] = 'EnameId = ?';
			$bindType .= 'i';
			$params[] = $data['EnameId'];
		}
		if(!empty($data['SendId']))
		{
			$where[] = 'SendId = ?';
			$bindType .= 'i';
			$params[] = $data['SendId'];
		}
		if(!empty($data['limittime']))
		{
			$where[] = 'SendTime > ?';
			$bindType .= 's';
			$params[] = $data['limittime'];
		}
		if(!empty($data['StatusIn']))
		{
			$where[] = 'Status  in (' . implode(',', array_fill(0, count($data['StatusIn']), '?')) . ')';
			$bindType .= implode('', array_fill(0, count($data['StatusIn']), 'i'));
			$params[] = $data['StatusIn'];
		}
		if(!empty($data['Keywords']))
		{
			$where[] = '(instr(Title,?) > 0 or instr(Content,?)>0)';
			$bindType .= 's';
			$bindType .= 's';
			$params[] = $data['Keywords'];
			$params[] = $data['Keywords'];
		}
		if(!empty($data['MessageType']) && empty($data['MessageTypeNotIn']) && empty($data['MessageTypeIn']))
		{
			$where[] = 'MessageType = ?';
			$bindType .= 'i';
			$params[] = $data['MessageType'];
		}
		if(!empty($data['MessageTypeNotIn']))
		{
			$where[] = 'MessageType not in (' . implode(',', array_fill(0, count($data['MessageTypeNotIn']), '?')) . ')';
			$bindType .= implode('', array_fill(0, count($data['MessageTypeNotIn']), 'i'));
			$params[] = $data['MessageTypeNotIn'];
		}
		if(!empty($data['MessageTypeIn']))
		{
			$where[] = 'MessageType  in (' . implode(',', array_fill(0, count($data['MessageTypeIn']), '?')) . ')';
			$bindType .= implode('', array_fill(0, count($data['MessageTypeIn']), 'i'));
			$params[] = $data['MessageTypeIn'];
		}
		if(isset($data['Status']))
		{
			$where[] = 'Status = ?';
			$bindType .= 'i';
			$params[] = $data['Status'];
		}
		if(!empty($data['MessageId']) && empty($data['MessageIdIn']))
		{
			$where[] = 'MessageId = ?';
			$bindType .= 'i';
			$params[] = $data['MessageId'];
		}
		if(!empty($data['MessageIdIn']))
		{
			$where[] = 'MessageId  in (' . implode(',', array_fill(0, count($data['MessageIdIn']), '?')) . ')';
			$bindType .= implode('', array_fill(0, count($data['MessageIdIn']), 'i'));
			$params[] = $data['MessageIdIn'];
		}
		if($where)
		{
			$wherestsr = ' where ' . implode(' and ', $where);
		}
		return array($wherestsr, $bindType, $params);
	}

	/**
	 * 批量添加站内信
	 *
	 * @param array $data
	 */
	public function addBatchSiteMessage($data)
	{
		self::setTableName();
		$bindType = '';
		$placeHolds = array();
		$sql = "insert into $this->table (EnameId,SendId,Title,Content,MessageType,Status,TemplateId,SendTime,ParamsCode) values ";
		foreach($data as $value)
		{
			$sql .= '(?,?,?,?,?,?,?,?,?),';
			$bindType .= 'iissiisss';
			$placeHolds[] = $value['EnameId'];
			$placeHolds[] = $value['SendId'];
			$placeHolds[] = $value['Title'];
			$placeHolds[] = $value['Content'];
			$placeHolds[] = $value['MessageType'];
			$placeHolds[] = 0;
			$placeHolds[] = $value['TemplateId'];
			$placeHolds[] = date('Y-m-d H:i:s');
			$placeHolds[] = is_array($value['Data']) ? json_encode($value['Data']) : $value['Data'];
		}
		$sql = rtrim($sql, ',');
		return $this->add($sql, $bindType, $placeHolds);
	}
}

<?php
namespace models\manage\stat;

use core\ModBase;

class StatMod extends ModBase
{
	
	private $dnCountTable;
	
	private $userCountTable;
	
	private $financePrepayCountTable;
	
	function __construct($db = 'stat')
	{
		parent::__construct($db);
		$this->dnCountTable = "e_domain_count";
		$this->userCountTable = "e_member_count";
		$this->financePrepayCountTable = "e_finance_prepay";
	}
	
	function getUserTotal($beginTime, $endTime)
	{
		$sql = "select * from ".$this->userCountTable;
		$sql .= " where endTime>='".$beginTime."' and endTime <'".$endTime."' and statId=99";
		$result = $this->select($sql, '', array());
		return $result;
	}
	
	function getDnLtdSysGroupTotal($beginTime, $endTime)
	{
		$sql = "select * from ".$this->dnCountTable;
		$sql .= " where endTime>='".$beginTime."' and endTime <'".$endTime."' and statType=99";
		$result = $this->select($sql, '', array());
		return $result;
	}
	
	function getPrePayTotal($beginTime, $endTime, $isTotal)
	{
		$sql = "select * from ".$this->financePrepayCountTable;
		$sql .= " where dayTime>='".strtotime($beginTime)."' and dayTime <'".strtotime($endTime)."' ";
		$sql .= $isTotal ? "and typeId in(93,94,95,96,97,99)" : "and typeId not in(93,94,95,96,97)";
		$sql .= " order by dayTime desc";
		$result = $this->select($sql, '', array());
		return $result;
	}
	
	/**
	 * 预付款总额更新
	 */
	public function updatePrepayTotal($data)
	{
		$time = $data['time'];
		$returnMsg = date('Y-m-d',$time);
		$msg = "";
		//更新可提现
		if(!empty($data['withdrawal']))
		{
			$query = $this->getRow("select * from ".$this->financePrepayCountTable ." where typeId=93 and dayTime=".$time, '', array());
			$update = $this->update("update ".$this->financePrepayCountTable ." set price=".$data['withdrawal']." where typeId=93 and dayTime=".$time, '', array());
			if($update)
			{
				$msg .= "可提现更新成功".(empty($query['price']) ? "" : $query['price'])."=>".$data['withdrawal'];
			}
			else
			{
				$msg .= "可提现更新失败";
			}
		}
		//更新不可提现
		if(!empty($data['unwithdrawal']))
		{
			$query = $this->getRow("select * from ".$this->financePrepayCountTable ." where typeId=94 and dayTime=".$time, '', array());
			$update = $this->update("update ".$this->financePrepayCountTable ." set price=".$data['unwithdrawal']." where typeId=94 and dayTime=".$time, '', array());
			if($update)
			{
				$msg .= "不可提现更新成功".(empty($query['price']) ? "" : $query['price'])."=>".$data['unwithdrawal'];
			}
			else
			{
				$msg .= "不可提现更新失败";
			}
		}
		//更新对公款
		if(!empty($data['pub']))
		{
			$query = $this->getRow("select * from ".$this->financePrepayCountTable ." where typeId=95 and dayTime=".$time, '', array());
			$update = $this->update("update ".$this->financePrepayCountTable ." set price=".$data['pub']." where typeId=95 and dayTime=".$time, '', array());
			if($update)
			{
				$msg .= "对公款更新成功".(empty($query['price']) ? "" : $query['price'])."=>".$data['pub'];
			}
			else
			{
				$msg .= "对公款更新失败";
			}
		}
		//更新保证金
		if(!empty($data['margin']))
		{
			$query = $this->getRow("select * from ".$this->financePrepayCountTable ." where typeId=96 and dayTime=".$time, '', array());
			$update = $this->update("update ".$this->financePrepayCountTable ." set price=".$data['margin']." where typeId=96 and dayTime=".$time, '', array());
			if($update)
			{
				$msg .= "保证金更新成功".(empty($query['price']) ? "" : $query['price'])."=>".$data['margin'];
			}
			else
			{
				$msg .= "保证金更新失败";
			}
		}
		//更新冻结
		if(!empty($data['freeze']))
		{
			$query = $this->getRow("select * from ".$this->financePrepayCountTable ." where typeId=97 and dayTime=".$time, '', array());
			$update = $this->update("update ".$this->financePrepayCountTable ." set price=".$data['freeze']." where typeId=97 and dayTime=".$time, '', array());
			if($update)
			{
				$msg .= "冻结更新成功".(empty($query['price']) ? "" : $query['price'])."=>".$data['freeze'];
			}
			else
			{
				$msg .= "冻结更新失败";
			}
		}
		//更新期末总额
		if(!empty($data['total']))
		{
			$query = $this->getRow("select * from ".$this->financePrepayCountTable ." where typeId=99 and dayTime=".$time, '', array());
			$update = $this->update("update ".$this->financePrepayCountTable ." set price=".$data['total']." where typeId=99 and dayTime=".$time, '', array());
			if($update)
			{
				$msg .= "期末总额更新成功".(empty($query['price']) ? "" : $query['price'])."=>".$data['total'];
			}
			else
			{
				$msg .= "期末总额更新失败";
			}
		//更新期初总额
			$nextMonth = strtotime('+1day',$time);
			$query = $this->getRow("select * from ".$this->financePrepayCountTable ." where typeId=1 and dayTime=".$nextMonth, '', array());
			$update = $this->update("update ".$this->financePrepayCountTable ." set price=".$data['total']." where typeId=1 and dayTime=".$nextMonth, '', array());
			if($update)
			{
				$msg .= "期初总额更新成功".(empty($query['price']) ? "" : $query['price'])."=>".$data['total'];
			}
			else
			{
				$msg .= "期初总额更新失败";
			}
		}
		$msg = empty($msg) ? $returnMsg."没有数据更新" : $returnMsg.$msg;
		\core\Log::write($msg, 'manage/stat', 'updateprepaytotal');
		return $msg;
	}
	
}
<?php
namespace models\manage\domain;
use core\ModBase;
class DomainRegDnsMod extends ModBase
{
	private $tableName;
	function __construct($dbName = 'domain')
	{
		parent::__construct($dbName);
		$this->tableName = 'e_domain_reg_dns';
	}

	public function addRegDns($params)
	{
		$bindType = '';
		$bindValue = array();
		$keyArr = array();
		foreach($params as $key => $value)
		{
			$keyArr[] = $key;
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		$fieldStr = implode(',', $keyArr);
		$query = 'insert into '.$this->tableName.'(' . $fieldStr . ')';
		$query .= ' values(' . trim(str_repeat('?,', count($keyArr)), ',') . ')';
		return $this->add($query, $bindType, $bindValue);
	}
	
	public function queryRegDns($params, $fields = "*", $isOne = FALSE)
	{
		$where = $bindValue = array();
		$bindType = '';
		foreach($params as $key => $value)
		{
			if(strtolower($key) == 'limit')
			{
				continue;
			}
			if(strtolower($key) == 'order')
			{
				continue;
			}
			if(strtolower($key) == 'in')
			{
				$key = array_keys($params['in']);
				$wen = trim(str_repeat('?,', count($params['in'][$key[0]])), ',');
				$where[] = $key[0] . ' in (' . $wen . ')';
				foreach($params['in'][$key[0]] as $val)
				{
					$bindType .= is_string($val) ? 's' : 'i';
					$bindValue[] = $val;
				}
				continue;
			}
			if(!empty($value))
			{
				$where[] = $key . '= ?';	//单引号与等号之间不能加空格，否则<>搜索会失效
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		$query = "select $fields from $this->tableName where " . implode(' and ', $where);
		$query = empty($params['order']) ? $query : $query . ' order by ' . $params['order'];
		$query = empty($params['limit']) ? $query : $query . ' limit ' . $params['limit'];
		return $this->select($query, $bindType, $bindValue, $isOne);
	}
	
	public function updateRegDns($params)
	{
		$where = $upData = $bindValue = array();
		$bindType = '';
		foreach ($params['set'] as $k =>$v)
		{
			$upData[] = $k . '= ?';
			$bindType .= is_string($v) ? 's' : 'i';
			$bindValue[] = $v;
		}
		foreach($params as $key => $value)
		{
			if(strtolower($key) == 'in')
			{
				$key = array_keys($params['in']);
				$wen = trim(str_repeat('?,', count($params['in'][$key[0]])), ',');
				$where[] = $key[0] . ' in (' . $wen . ')';
				foreach($params['in'][$key[0]] as $val)
				{
					$bindType .= is_string($val) ? 's' : 'i';
					$bindValue[] = $val;
				}
				continue;
			}
			if($key == 'set')
			{
				continue;
			}
			if(!empty($value))
			{
				$where[] = $key . '= ?';	
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		$query = 'update ' . $this->tableName ;
		$query.= ' set ' . implode(',', $upData);
		$query = empty($where)?$query:$query . ' where ' . implode(' and ', $where);
		return $this->update($query, $bindType, $bindValue);
	}
	
	public function getRegDnsCounts($params)
	{
		$where = $bindValue = array();
		$bindType = '';
		foreach($params as $key => $value)
		{
			if(strtolower($key) == 'in')
			{
				$key = array_keys($params['in']);
				$wen = trim(str_repeat('?,', count($params['in'][$key[0]])), ',');
				$where[] = $key[0] . ' in (' . $wen . ')';
				foreach($params['in'][$key[0]] as $val)
				{
					$bindType .= is_string($val) ? 's' : 'i';
					$bindValue[] = $val;
				}
			}
			elseif(!empty($value))
			{
				$where[] = $key . '= ?';	
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		$query = "select count(RegDnsId) as sum from $this->tableName where " . implode(' and ', $where);
		return $this->getRow($query, $bindType, $bindValue);
	}
	
}

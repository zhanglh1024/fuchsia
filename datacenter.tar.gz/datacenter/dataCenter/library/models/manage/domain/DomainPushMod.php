<?php
namespace models\manage\domain;
use core\ModBase;

class DomainPushMod extends ModBase
{

	private $table;

	function __construct($dbName = 'domain')
	{
		parent::__construct($dbName);
		$this->table = 'e_domain_push';
		$this->tableDetails = 'e_domain_push_details';
	}
	 
	/**
	 * 根据条件获取个数 
	 */ 
	public function pushCount($params)
	{
		if(empty($params))
		{
			return false;
		}
		$whereDatas = $this->getWhereSql($params);
		$query = "select count(*) from $this->table where " . implode(' and ', $whereDatas[0]);
		return $this->getOne($query, $whereDatas[1], $whereDatas[2]);
	}

	/**
	 * 根据条件获取列表
	 */
	public function pushList($params, $fields = "*", $isOne = FALSE)
	{
		if(empty($params))
		{
			return false;
		}
		$whereDatas = $this->getWhereSql($params);
		$query = "select $fields from $this->table where " . implode(' and ', $whereDatas[0]);
		$query .= " order by CreateTime desc";
		$query = empty($params['limit']) ? $query : $query . ' limit ' . $params['limit'];
		return $this->select($query, $whereDatas[1], $whereDatas[2], $isOne);
	}
	
	public function getWhereSql($params)
	{
		$where = $bindValue = array();
		$bindType = '';
		foreach($params as $key => $value)
		{
			if(strtolower($key) == 'limit')
			{
				continue;
			}
			if(strtolower($key) == 'in')
			{
				$inkey = array_keys($params['in']);
				$wen = trim(str_repeat('?,', count($params['in'][$inkey[0]])), ',');
				$where[] = $inkey[0] . ' in (' . $wen . ')';
				foreach($params['in'][$inkey[0]] as $val)
				{
					$bindType .= is_string($val) ? 's' : 'i';
					$bindValue[] = $val;
				}
			}
			else if(strtolower($key) == 'or')
			{
				$owhere = '(';
				foreach($value as $okey => $ovalue)
				{
					if(is_array($ovalue))
					{
						foreach($ovalue as $vv)
						{
							$owhere .= $okey . ' = ? or ';
							$bindValue[] = $vv;
							$bindType .= is_string($vv) ? 's' : 'i';
						}
					}
					else
					{
						$owhere .= $okey . ' = ? or ';
						$bindValue[] = $ovalue;
						$bindType .= is_string($ovalue) ? 's' : 'i';
					}
				}
				$owhere = trim($owhere);
				$owhere = trim($owhere, 'or');
				$owhere .= ')';
				$where[] = $owhere;
			}
			else if($key == 'domain')
			{
				$where[] = 'instr(DomainName,?) > 0';
				$bindType .= 's';
				$bindValue[] = $value;
			}
			else if($key == 'startTime')
			{
				$where[] = 'CreateTime >=?';
				$bindType .= 's';
				$bindValue[] = $value;
			}
			else if($key == 'endTime')
			{
				$where[] = 'CreateTime <=?';
				$bindType .= 's';
				$bindValue[] = $value;
			}
			elseif(substr(trim($key), -1) == '<')
			{
				$key = str_replace('<', '', $key);
				$where[] = $key . ' <= ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
			elseif(substr(trim($key), -1) == '>')
			{
				$key = str_replace('>', '', $key);
				$where[] = $key . ' >= ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
			else
			{
				$where[] = $key . '= ?'; // 单引号与等号之间不能加空格，否则<>搜索会失效
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		return array($where, $bindType, $bindValue);
	}

	/**
	 * 更新域名信息
	 */
	public function upDomainInfo($where, $set)
	{
		if(empty($where) || empty($set))
		{
			return false;
		}
		$whereData = $upData = $bindValue = array();
		$bindType = '';
		foreach($set as $key => $value)
		{
			$upData[] = $key . ' = ? ';
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		foreach($where as $key => $value)
		{
			$whereData[] = $key . ' = ? ';
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		$query = 'update ' . $this->table . ' set ' . implode(',', $upData) . ' where ' . implode(' and ', $whereData);
		return $this->update($query, $bindType, $bindValue);
	}

	/**
	 * 安全警报查询符合条件的push域名
	 */
	public function checkPush($where)
	{
		$whereData = array();
		$bindType = '';
		$sql = '';
		$bindValue = array();
		if(isset($where['ReceiveTime']))
		{
			$whereData[] = 'ReceiveTime > ?';
			$bindValue[] = $where['ReceiveTime'];
			$bindType = 's';
		}
		$sql .= 'select * from ' . $this->table . ' where Ip=ReceiveIp and ReceiveStatus=1 ' .
			 (!empty($where) ? ' and ' . implode(' and ', $whereData) : '');
		$sql .= isset($where['order']) ? ' order by ' . $where['order'] : '';
		$sql .= isset($where['limit']) ? ' limit ' . $where['limit'] : '';
		return $this->select($sql, $bindType, $bindValue);
	}

	/**
	 * 获取转入分表信息
	 *
	 * @param array $params
	 * @param string $fields
	 * @return boolean
	 */
	public function pushDetail($params, $fields = "*")
	{
		if(empty($params))
		{
			return FALSE;
		}
		$where = $bindValue = array();
		$bindType = '';
		foreach($params as $key => $value)
		{
			$where[] = $key . '= ?';
			$bindType .= is_string($value) ? 's' : 'i';
			$bindValue[] = $value;
		}
		$query = "select $fields from $this->tableDetails where " . implode(' and ', $where);
		return $this->getOne($query, $bindType, $bindValue);
	}

	/**
	 * 增加域名PUSH记录
	 * @param array $data
	 */
	public function addPush($receiveId, $sendId, $receiveStatus, $sendStatus, $domainName, $money, $pushType, $content, $orderId, $pushTime, $ip ,$status=0,$islock = 0)
	{
		$sql = "insert into " . $this->table . "(ReceiveId,SendId,ReceiveStatus,SendStatus,DomainName,PushPrice,PushType,Content,
			OrderId,CreateTime,Ip,Status,IsLock)values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		return $this->add($sql, 'iiiisdisissii', 
			array($receiveId, $sendId, $receiveStatus, $sendStatus, $domainName, $money, $pushType, $content, $orderId, 
					$pushTime, $ip,$status,$islock));
	}

	public function setPushInfo($para)
	{
		if(empty($para['where']) || empty($para['set']))
		{
			return false;
		}
		$whereData = $upData = $bindValue = array();
		$bindType = '';
		foreach($para['set'] as $key => $value)
		{
			$upData[] = $key . ' = ? ';
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		foreach($para['where'] as $key => $value)
		{
			$whereData[] = $key . ' = ? ';
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		$query = 'update ' . $this->table . ' set ' . implode(',', $upData) . ' where ' . implode(' and ', $whereData);
		return $this->update($query, $bindType, $bindValue);
	}

	/**
	 * 警报匹配push域名
	 */
	public function pushListForSecwarning($successTime, $fields = "*")
	{
		if(empty($successTime))
		{
			return false;
		}
		$query = "select $fields from $this->table where CreateTime >= '" . $successTime .
			 "' and status in(0,1) and ReceiveStatus in(0,1) order by CreateTime desc";
		return $this->select($query, '', array(), FALSE);
	}

	public function getDb()
	{
		return $this->db;
	}

	/**
	 * 域名push(事物处理)
	 */
	public function domainPush($params, $ip, $domainNameArr)
	{
		$pushTime = date("Y-m-d H:i:s");
		$result = array();
		try
		{
			// 开启事物
			$this->db->autocommit(false);
			// 插入push表
			if(!$push = self::addPush($params['ReceiveId'], $params['SendId'], $params['ReceiveStatus'], 
				$params['SendStatus'], $params['DomainName'], $params['PushPrice'], $params['PushType'], 
				$params['Content'], $params['OrderId'], $pushTime, $ip,0,$params['IsLock']))
			{
				throw new \Exception('添加PUSH记录失败，请稍后重试' ,322053);
			}
			// 域名加锁
			$count = count($domainNameArr);
			$in = rtrim(str_repeat('?,', $count), ',');
			$bindType = str_repeat('s', $count);
			$sql = "select DomainId,DomainName,DomainMyStatus from e_domains where DomainName in({$in}) for update";
			if(!$result = $this->select($sql, $bindType, $domainNameArr))
			{
				throw new \Exception('PUSH失败，请稍后重试' ,322054);
			}
			// 添加操作日志
// 		$redis = \core\RedisLib::getInstance('manage');
			$serviceSql = 'insert into e_domain_service' . date('Y') .
				 ' (Domain,OperationIp,OperationTime,OperationUser,UserId,Content,ServiceType) values ';
			$serviceType = '';
			$serviceValue = array();
			$operaterLogSql = 'insert into e_domain_operation_log'.date('Y').' (DomainName,CreateTime,EnameId,Content,LogType,AdminUser,AdminId,Ip) values ';
			$operaterLogType = '';
			$operaterLogValue = array();
			foreach($result as $v)
			{
				if($v['DomainMyStatus'] == 4)
				{
					throw new \Exception('PUSH失败，请稍后重试' ,322054);
				}
// 			$redis->set('tempdomainmystatus_' . $v['DomainName'], $v['DomainMyStatus']);
				// 组装日志sql
				$serviceSql .= '(?,?,?,?,?,?,?),';
				$serviceType .= 'ssssisi';
				$tmp = array($v['DomainName'], \common\Common::getRequestIp(), date('Y-m-d H:i:s'), '系统', 0, 
						"APP域名PUSH[{$params['SendId']}->{$params['ReceiveId']}]后台状态修改操作", 12);
				$serviceValue = array_merge($serviceValue, $tmp);
				// 组装日志sql
				$operaterLogSql .= '(?,?,?,?,?,?,?,?),';
				$tmp = array($v['DomainName'], date("Y-m-d H:i:s"), $params['SendId'], "PUSH给{$params['ReceiveId']}", 2, 
						'', 0, $ip);
				$operaterLogType .= 'ssisisis';
				$operaterLogValue = array_merge($operaterLogValue, $tmp);
			}
			$serviceSql = rtrim($serviceSql, ',');
			$operaterLogSql = rtrim($operaterLogSql, ',');
			// 更新域名状态
			$sql = "update e_domains set DomainMyStatus = 4 where DomainName in({$in})";
			if(!$this->update($sql, $bindType, $domainNameArr, true))
			{
				throw new \Exception('PUSH失败，请稍后重试' ,322054);
			}
			if(!$this->add($operaterLogSql, $operaterLogType, $operaterLogValue))
			{
				\core\Log::write('domainpushaddoplgfailed,' . json_encode(array($params['SendId'],$params['ReceiveId'],$v['DomainName'])));
			}
			// 提交事务
			$this->db->commit();
			$result = array('flag' => true, 'msg' => 'PUSH提交成功', 'pushid' => $push, 'pushtime' => $pushTime);
		}
		catch(\Exception $e)
		{
			$this->db->rollback();
			$result = array('flag' => false, 'msg' => $e->getMessage());
		}
		$this->db->autocommit(true);
		return $result;
	}
}

<?php
namespace models\manage\domain;
use core\ModBase;
class DomainCountMod extends ModBase
{
	private $tableName;
	function __construct($dbName = 'stat')
	{
		parent::__construct($dbName);
		$this->tableName = 'e_domain_count';
	}

	public function getCountList($data)
	{
		if(empty($data))
		{
			return FALSE;
		}
		$whereDatas = $this->getWhereSql($data);
		return $this->getRow("select * from $this->tableName where " . implode(' and ',$whereDatas[0]), $whereDatas[1], $whereDatas[2]);
	}
	
	public function addCount($params)
	{
		if(empty($params) || empty($params['statType']) || empty($params['firstType']))
		{
			return FALSE;
		}
		$query = "insert into $this->tableName(enameId,statType,firstType,secondType,allCount,beginTime,endTime,remark)";
		$query .=" values(?,?,?,?,?,?,?,?)";
		$bindValue = array(0,$params['statType'],$params['firstType'],$params['firstType'],$params['allCount'],$params['beginTime'],$params['endTime'],'');
		return $this->add($query, 'iiiiisss', $bindValue);
	}	
	
	/**
	 * 更新域名信息
	 * @param array $where array('DomainId' => 123, 'in' => array('DomainMyStatus' => array(2, 3)))
	 * @param array $set array('DomainMyStatus' => $status)
	 * @return boolean
	 */
	public function updateCountInfo($where, $set)
	{
		if(empty($where) || empty($set))
		{
			return FALSE;
		}
		$upData = $bindValue = array();
		$bindType = '';
		foreach($set as $key => $value)
		{
			$upData[] = $key . ' = ? ';
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		$whereDatas = $this->getWhereSql($where);
		return $this->update('update ' . $this->tableName . ' set ' . implode(',', $upData) . ' where ' . implode(' and ', $whereDatas[0]), $bindType . $whereDatas[1], array_merge($bindValue, $whereDatas[2]));
	}

	/**
	 * where条件组装
	 * @param array $where array('DomainId' => 123, 'in' => array('DomainMyStatus' => array(2, 3)))
	 * @return array  array($whereData, $bindType, $bindValue)
	 */
	private function getWhereSql($where)
	{
		$whereData = $bindValue = array();
		$bindType = '';
		foreach($where as $key => $value)
		{
			if($key == 'in')
			{
				$keys = array_keys($where['in']);
				foreach($keys as $k => $v)
				{
					$wen = trim(str_repeat('?,', count($where['in'][$v])), ',');
					$whereData[] = $v . ' in (' . $wen . ')';
					foreach($where['in'][$v] as $val)
					{
						$bindType .= is_string($val) ? 's' : 'i';
						$bindValue[] = $val;
					}
				}
			}
			else
			{
				$whereData[] = $key . ' = ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		return array($whereData, $bindType, $bindValue);
	}

}

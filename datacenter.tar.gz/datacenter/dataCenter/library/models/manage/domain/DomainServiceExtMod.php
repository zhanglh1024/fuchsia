<?php
namespace models\manage\domain;
use \core\ModBase;

class DomainServiceExtMod extends ModBase
{
	public $tableName;
	
	function __construct($db = 'domain')
	{
		parent::__construct($db);
		$this->tableName = "e_domain_service_ext";
	}

	/**
	 * 添加域名记录
	 */
	public function addDomainService($domain, $content, $serviceType, $adminId = 0, $enameId = 0)
	{
		$content = is_array($content) ? json_encode($content) : $content;
		$query = 'insert into ' . $this->tableName . '(Domain,OperateIp,OperateTime,AdminId,Content,ServiceType,EnameId)values(?,?,?,?,?,?,?)';
		return $this->add($query, "ssiisii", array($domain, \common\Common::getRequestIp(), time(), $adminId, $content, $serviceType, $enameId));
	}

	/**
	 * 获取域名记录信息
	 */
	public function getDomainService($data, $isOne)
	{
		$whereData = self::getSqlWhere($data);
		$sql = "select * from $this->tableName where ".implode(' and ', $whereData[0]);
		if(isset($data['order']))
		{
			$sql .= " order by ".$data['order'];
		}
		if($isOne)
		{
			return $this->getRow($sql, $whereData[1], $whereData[2]);
		}
		return $this->select($sql, $whereData[1], $whereData[2]);
	}
	
	/**
	 * 获取域名记录信息数量
	 */
	public function getDomainServiceCount($data)
	{
		$whereData = self::getSqlWhere($data);
		return $this->getOne("select count(*) from $this->tableName where ".implode(' and ', $whereData[0]), $whereData[1], $whereData[2]);
	}
	
	private function getSqlWhere($data)
	{
		$bindValue = $where = array();
		$bindType = '';
		if(!empty($data['domain']))
		{
			$where[] = "Domain = ?";
			$bindValue[] = $data['domain'];
			$bindType .= 's';
		}
		if(!empty($data['serviceType']))
		{
			$where[] = "ServiceType = ?";
			$bindValue[] = $data['serviceType'];
			$bindType .= 'i';
		}
		if(!empty($data['enameId']))
		{
			$where[] = "EnameId = ?";
			$bindValue[] = $data['enameId'];
			$bindType .= 'i';
		}
		return array($where, $bindType, $bindValue);
	}

}

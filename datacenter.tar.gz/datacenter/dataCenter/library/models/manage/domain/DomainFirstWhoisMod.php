<?php
namespace models\manage\domain;
use core\ModBase;

class DomainFirstWhoisMod extends ModBase
{
	public function __construct($dbName = 'domain')
	{
		parent::__construct($dbName);
	}
	
	public function addFirstWhois($params)
	{
		if(empty($params))
		{
			return FALSE;
		}
		$bindType = '';
		$keyArr = $bindValue = array();
		foreach($params as $key => $value)
		{
			$keyArr[] = $key;
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		$fieldStr = implode(',', $keyArr);
		$query = 'insert into e_domain_first_whois(' . $fieldStr . ')';
		$query .= ' values(' . trim(str_repeat('?,', count($keyArr)), ',') . ')';
		return $this->add($query, $bindType, $bindValue);
	}
}
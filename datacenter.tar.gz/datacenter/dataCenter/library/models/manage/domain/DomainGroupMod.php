<?php
namespace models\manage\domain;
use \core\ModBase;

class DomainGroupMod extends ModBase
{
	private $table;
	public function __construct($db = 'domain')
	{
		parent::__construct($db);
		$this->table = 'e_domain_group';
	}

	/**
	 * 主要是通过enameid获取域名分组
	 */
	public function getDomainGroupByEnameId($enameId,$fields = "*")
	{
		return $this->select("select $fields from ".$this->table. " where CreateUser = ? order by Sort desc,DomainCount desc ",'s',array($enameId));		
	}
	
	/**
	 * 主要是通过groupid获取域名分组
	 */
	public function getDomainGroupByGroupid($groupid,$fields = "*")
	{
		return $this->select("select $fields from ".$this->table. " where GroupId = ?  ",'i',array($groupid),true);
	}
	
	/**
	 *设置域名分组信息
	 */
	public function setDomainGroup($groupid,$add = true)
	{
		$setstr = $add ? ' DomainCount = DomainCount+1' : ' DomainCount = DomainCount-1';
		return $this->update("update $this->table set $setstr  where GroupId = ? ", 'i', array($groupid));
	}

}
<?php
namespace models\manage\domain;
use core\ModBase;
class DomainsMod extends ModBase
{

	function __construct($dbName = 'domain')
	{
		parent::__construct($dbName);
	}

	/** 
	 * 根据条件获取域名信息
	 * @param array $params
	 * @param string $fields
	 * @param boolean $isOne
	 * @return array|boolean 
	 */ 
	public function getDomainInfo($where, $fields = "*", $isOne = TRUE)
	{
		if(empty($where))
		{
			return FALSE;
		}
		$whereDatas = $this->getWhereSql($where);
		return $this->select("select $fields from e_domains where " . implode(' and ', $whereDatas[0]), $whereDatas[1], $whereDatas[2], $isOne);
	}//implode将元素合为字符串

	/**
	 * 域名入库
	 * @param array $params
	 * @return boolean
	 */
	public function addDomain($params)
	{
		$bindType = '';
		$bindValue = array();
		$keyArr = array();
		foreach($params as $key => $value)
		{
			$keyArr[] = $key;
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		if(empty($bindType))
		{
			return FALSE;
		}
		//添加3级分类
		list($firstClass,$secondClass,$thirdClass,$domainBody) = \lib\manage\domain\DomainsClass::getClasses($params['domainName']);
		$keyArr[] = 'FirstClass';
		$bindValue[] = $firstClass;
		$bindType .= 'i';
		$keyArr[] = 'SecondClass';
		$bindValue[] = $secondClass;
		$bindType .= 'i';
		$keyArr[] = 'ThirdClass';
		$bindValue[] = $thirdClass;
		$bindType .= 'i';
		$keyArr[] = 'DomainBody';
		$bindValue[] = $domainBody;
		$bindType .= 's';
		 
		$keyArr[] = 'AddDate';
		$bindValue[] = gmdate("Y-m-d H:i:s");
		$bindType .= 's';
		$fieldStr = implode(',', $keyArr);
		$query = 'insert into e_domains(' . $fieldStr . ')';
		$query .= ' values(' . trim(str_repeat('?,', count($keyArr)), ',') . ')';
		return $this->add($query, $bindType, $bindValue);
	}

	/**
	 * 根据条件获取域名条数
	 * @param array $where EnameId TemplateId
	 * @return mnumber|boolean
	 */
	public function getDomainCount($where)
	{
		$wherestr = '';
		$whereDatas = $this->getWhereSql($where);
		if(!empty($whereDatas[0]))
		{
			$wherestr = ' where ' . implode(' and ', $whereDatas[0]);
		}
		return $this->getRow("select count(*) as sum from e_domains " . $wherestr, $whereDatas[1], $whereDatas[2]);
	}

	/**
	 * 根据域名id删除域名
	 * @param int $domainId 
	 * @return boolean
	 */
	public function delDomain($domainId)
	{ 
		return $this->delete("delete from e_domains where DomainId=?", 'i', array($domainId));
	}

	/**
	 * 根据条件获取域名列表
	 * @param array $where
	 * @param string $limit
	 * @param string $order
	 * @return array|boolean
	 */
	public function getDomainList($where, $limit = '', $order = '', $fields = "*")
	{
		$orderstr = empty($order) ? " " : ' order by ' . $order;
		$limitstr = empty($limit) ? '' : ' limit ' . $limit; 
		$whereDatas = $this->getWhereSql($where);
		return $this->select("select $fields from e_domains " . ' where ' . implode(' and ', $whereDatas[0]) . $orderstr . $limitstr, $whereDatas[1], $whereDatas[2]);
	}

	/**
	 * 更新域名信息
	 * @param array $where array('DomainId' => 123, 'in' => array('DomainMyStatus' => array(2, 3))) 
	 * @param array $set array('DomainMyStatus' => $status)
	 * @return boolean
	 */
	public function upDomainInfo($where, $set,$nums = FALSE,$force = true)
	{ 
		if(empty($where) || empty($set))
		{
			return FALSE;
		}
		$upData = $bindValue = array(); 
		$bindType = '';
		foreach($set as $key => $value)
		{ 
			$upData[] = $key . '= ? ';
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		$whereDatas = $this->getWhereSql($where);
		return $this->update('update e_domains set ' . implode(',', $upData) . ' where ' . implode(' and ', $whereDatas[0]), $bindType . $whereDatas[1], array_merge($bindValue, $whereDatas[2]),$force,$nums);
	}

	/**
	 * 根据高级搜索条件搜索域名
	 */
	public function getDomainByAdvance($params, $fields = '*')
	{
		$where = $bindValue = array();
		$bindType = '';
		if(!empty($params['DomainMyStatus']))
		{
			if($params['DomainMyStatus'] == 1)
			{
				$where[] = 'DomainMyStatus in (1,9,14) ';
			}
			else
			{
				$where[] = 'DomainMyStatus = ? ';
				$bindType .= 'i';
				$bindValue[] = $params['DomainMyStatus'];
			}
		}
		if(!empty($params['DomainGroup']))
		{
			$where[] = 'DomainGroup = ? ';
			$bindType .= 'i';
			$bindValue[] = $params['DomainGroup'] == -1 ? 0 : $params['DomainGroup'];
		}
		if(!empty($params['EnameId']))
		{
			$where[] = 'EnameId = ? ';
			$bindType .= 'i';
			$bindValue[] = $params['EnameId'];
		}
		if(!empty($params['StartLength']))
		{
			$where[] = 'DomainLength > ? ';
			$bindType .= 'i';
			$bindValue[] = $params['StartLength'] - 1;
		}
		if(!empty($params['EndLength']))
		{
			$where[] = 'DomainLength < ? ';
			$bindType .= 'i';
			$bindValue[] = $params['EndLength'] + 1;
		}
		if(!empty($params['DomainLtd']))
		{
			$ltdSql = ' (';
			foreach($params['DomainLtd'] as $v)
			{
				if($v == 6)
				{
					$ltdSql .= 'DomainLtd not in(1,2,3,4,5) or ';
					continue;
				}
				elseif($v == 2)
				{
					$ltdSql .= ' DomainLtd = ? or ';
					$bindValue[] = 6;
					$bindType .= 'i';
				}
				elseif($v == 3)
				{
					$ltdSql .= ' DomainLtd = ? or ';
					$bindValue[] = 9;
					$bindType .= 'i';
				}
				elseif($v == 4)
				{
					$ltdSql .= ' DomainLtd = ? or ';
					$bindValue[] = 10;
					$bindType .= 'i';
				}
				$ltdSql .= ' DomainLtd = ? or ';
				$bindValue[] = $v;
				$bindType .= 'i';
			}
			$where[] = rtrim(trim($ltdSql), 'or') . ') ';
		}
		if(!empty($params['TemplateId']))
		{
			$ltdSql = ' (';
			foreach($params['TemplateId'] as $v)
			{
				$ltdSql .= ' TemplateId = ? or ';
				$bindValue[] = $v;
				$bindType .= 'i';
			}
			$where[] = rtrim(trim($ltdSql), 'or') . ') ';
		}
		if(!empty($params['KeyWord']))
		{
			$where[] = 'instr(DomainName,?) > 0';
			$bindType .= 's';
			$bindValue[] = $params['KeyWord'];
		}
		if(!empty($params['SysGroup']))
		{
			$sysSql = $this->getSysGroupSql($params['SysGroup']);
			$where[] = $sysSql;
		}
		$firstClass = !empty($params['FirstClass']) ? $params['FirstClass'] : false;
		if($firstClass)
		{
			$secondClass = !empty($params['SecondClass']) ? $params['SecondClass'] : false;
			$thirdClass = !empty($params['ThirdClass']) ? $params['ThirdClass'] : false;
			$sysSql = $this->getTSysGroupThirdSql($firstClass, $secondClass, $thirdClass);
			$where[] = $sysSql;
		}
		$query = "select $fields from e_domains where " . implode(' and ', $where);
		if($params['IsLock'] == 1)//未设置
		{
			$query.=" and not exists(select dl_id from e_domain_lock where e_domains.DomainName = e_domain_lock.dl_domain and dl_unlock_time=0 and dl_out_time>".time().")";
		}
		elseif($params['IsLock'] == 2)//已设置
		{
			$query = "select $fields from e_domains where " . implode(' and ', $where);
			$query.=" and exists(select dl_id from e_domain_lock where e_domains.DomainName = e_domain_lock.dl_domain and dl_unlock_time=0 and dl_out_time>".time().")";
		}
		if(!empty($params['order']))
		{
			$query .= ' order by ' . $params['order'];
		}
		if(!empty($params['limit']))
		{
			$query .= ' limit ' . $params['limit'];
		}
		return $this->select($query, $bindType, $bindValue);

	}

	/**
	 * 高级搜索域名分组sql
	 * @param number $sysgroup
	 * @return string
	 */
	private function getSysGroupSql($sysgroup)
	{
		switch($sysgroup)
		{
			case 1:
				return ' FirstClass=1 ';
			case 2:
				return ' FirstClass=1 and DomainLength=1 ';
			case 3:
				return ' FirstClass=1 and DomainLength=2 ';
			case 4:
				return ' FirstClass=1 and DomainLength = 3';
			case 5:
				return ' FirstClass=1 and DomainLength = 4';
			case 6:
				return ' FirstClass=1 and DomainLength = 5';
			case 20:
				return ' FirstClass=1 and DomainLength = 6';
			case 7:
				return ' FirstClass=2';
			case 8:
				return ' FirstClass=2 and DomainLength = 1';
			case 9:
				return ' FirstClass=2 and DomainLength = 2';
			case 10:
				return ' FirstClass=2 and DomainLength = 3';
			case 11:
				return ' FirstClass=2 and DomainLength = 4';
			case 12:
				return ' FirstClass=2 and DomainLength = 5';
			case 13:
				return ' FirstClass=3';
			case 14:
				return ' FirstClass=3 and DomainLength=2';
			case 15:
				return ' FirstClass=3  and DomainLength=3';
			case 16:
				return ' FirstClass=2 and SecondClass in (1)';
			case 17:
				return ' FirstClass=2 and SecondClass in (2,12)';
			case 18:
				return ' FirstClass=2 and SecondClass in (3)';
			case 19:
				return ' FirstClass=4';
			default:
				return '';
		}
	}

	/**
	 * 域名三级分类
	 * 
	 * @param $firstClass 第一级分类
	 * @param $secondClass 第二级分类
	 * @param $thirdClass 第三级分类
	 */
	private function getTSysGroupThirdSql($firstClass, $secondClass, $thirdClass)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domainsgroup');
		$domainsgroup = $conf->domainsgroup->code->toArray();
		$classArr = explode("_", $domainsgroup[$firstClass]);
		$searchSql['firstClass'] = $classArr[0];
		$searchSql['classDomainLen'] = $classArr[3];
		if($thirdClass)
		{
			$thirdClass = is_array($thirdClass) ? $thirdClass : array($thirdClass);
		}
		if($thirdClass && $thirdClass[0] != '0')
		{
			if(in_array(5010, $thirdClass))
			{
				$classArr[1] = 10;
				$thirdClass = array_diff($thirdClass, [5010]);
			}
			$searchSql['thirdClass'] = $thirdClass;
		}
		switch($secondClass)
		{
			case 5001:
				$classArr[1] = 6;
				break;
			case 5002:
				$classArr[1] = array(0, 1, 2, 3, 4);
				break;
			case 6001:
				$classArr[1] = 15;
				break;
			case 6002:
				$classArr[1] = 14;
				break;
			case 6003:
				$classArr[1] = 13;
				break;
		}
		if($classArr[1])
		{
			if(10 == $classArr[1])
			{
				$classArr[1] = array(10, 12);
			}
			elseif(2 == $classArr[1])
			{
				$classArr[1] = array(2, 12);
			}
			elseif(!is_array($classArr[1]))
			{
				$classArr[1] = array($classArr[1]);
			}
		}
		$searchSql['secondClass'] = $classArr[1];
		$sql = '';
		if(!empty($searchSql['firstClass']))
		{
			$sql .= ' and FirstClass =' . $searchSql['firstClass'];
			if(!empty($searchSql['classDomainLen']))
			{
				$sql .= ' and DomainLength =' . $searchSql['classDomainLen'];
			}
		}
		if(!empty($searchSql['secondClass']))
		{
			$sql .= ' and SecondClass in (' . implode(',', $searchSql['secondClass']) . ')';
		}
		if(!empty($searchSql['thirdClass']))
		{
			$sql .= ' and ThirdClass in (' . implode(',', $searchSql['thirdClass']) . ')';
		}
		return ltrim($sql, ' and');
	}
	/**
	 * where条件组装
	 * @param array $where array('DomainId' => 123, 'in' => array('DomainMyStatus' => array(2, 3))) 
	 * @return array  array($whereData, $bindType, $bindValue)
	 */
	private function getWhereSql($where)
	{
		$whereData = $bindValue = array();
		$bindType = '';
		foreach($where as $key => $value)
		{
			if($key=='regStartDate')
			{ 
				$whereData[] = 'RegDate > ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
				continue;
			}
			if($key=='regEndDate')
			{
			  $whereData[] = 'RegDate <= ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
				continue;
			}
			if($key == 'in')
			{
				$keys = array_keys($where['in']);
				foreach($keys as $k => $v)
				{
					$wen = trim(str_repeat('?,', count($where['in'][$v])), ',');
					$whereData[] = $v . ' in (' . $wen . ')';
					foreach($where['in'][$v] as $val)
					{
						$bindType .= is_string($val) ? 's' : 'i';
						$bindValue[] = $val;
					}
				}
			}
			elseif(substr(trim($key), -1) == '<')
			{
				$key = str_replace('<', '', $key);
				$whereData[] = $key . ' <= ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
			elseif(substr(trim($key), -1) == '>')
			{
				$key = str_replace('>', '', $key);
				$whereData[] = $key . ' >= ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
			else
			{
				$whereData[] = $key . ' = ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		return array($whereData, $bindType, $bindValue);
	}
}

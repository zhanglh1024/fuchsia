<?php
namespace models\manage\domain;

use core\ModBase;
class DomainCheckMod extends ModBase
{

	function __construct()
	{
		parent::__construct('manage');
	}

	public function addLog($domain, $tld, $time, $enameId)
	{
		$query = "insert into e_domain_check_log(DomainBody,DomainLtd,CheckTime,EnameId)values(?,?,?,?)";
		return $this->add($query, "sssi", array($domain,$tld,$time,$enameId));
	}

}
<?php
namespace models\manage\domain;
use core\ModBase;

class DomainTransferOutMod extends ModBase
{
	private $tableName;
	public function __construct($db = 'domain')
	{
		parent::__construct($db);
		$this->tableName = 'e_domain_transfer_out';
	}

	/**
	 * 根据条件获取转出信息
	 */
	public function getTransferInfo($params, $order = false, $limit = false, $isOne = false)
	{
		if(empty($params))
		{
			return false;
		}
		$where = $bindValue = array();
		$bindType = '';
		foreach($params as $key => $value)
		{
			if($key == 'in')
			{
				$keys = array_keys($params['in']);
				foreach($keys as $k => $v)
				{
					$wen = trim(str_repeat('?,', count($params['in'][$v])), ',');
					$where[] = $v . ' in (' . $wen . ')';
					foreach($params['in'][$v] as $val)
					{
						$bindType .= is_string($val) ? 's' : 'i';
						$bindValue[] = $val;
					}
				}
			}
			else
			{
				$fuhao = '=';
				$one = substr($value, 0, 1);
				if($one == '<' || $one == '>' || $one == '!')
				{
					$fuhao = (stripos($value, $one . '=') !== FALSE) ? $one . '=' : $one;
					$value = str_replace($fuhao, '', $value);
				}
				$where[] = $key . $fuhao . " ?";
				$bindValue[] = $value;
				$bindType .= is_string($value) ? 's' : 'i';
			}
		}
		$query = 'select * from '.$this->tableName.' where ' . implode(' and ', $where);
		$orderstr = empty($order) ? '' : ' order by '.$order;
		$limitsr = empty($limit) ? '' : ' limit '.$limit;
		return $this->select($query.$orderstr.$limitsr, $bindType, $bindValue, $isOne);
	}
	/**
	 * 根据条件获取转出记录条数
	 */
	public function getTransferCount($params)
	{
		if(empty($params))
		{ 
			return false;
		}
		$where = $bindValue = array();
		$bindType = '';
		foreach($params as $key => $value)
		{
			if($key == 'in')
			{
				$keys = array_keys($params['in']);
				foreach($keys as $k => $v)
				{
					$wen = trim(str_repeat('?,', count($params['in'][$v])), ',');
					$where[] = $v . ' in (' . $wen . ')';
					foreach($params['in'][$v] as $val)
					{
						$bindType .= is_string($val) ? 's' : 'i';
						$bindValue[] = $val;
					}
				}
			}
			else
			{
				$fuhao = '=';
				$one = substr($value, 0, 1);
				if($one == '<' || $one == '>' || $one == '!')
				{
					$fuhao = (stripos($value, $one . '=') !== FALSE) ? $one . '=' : $one;
					$value = str_replace($fuhao, '', $value);
				}
				$where[]= $key . $fuhao ." ?";
				$bindValue[] = $value;
				$bindType .= is_string($value) ? 's' : 'i';
			}
		}
		$query = 'select count(*) as sum from  '.$this->tableName .' where '. implode(' and ', $where);
		return $this->select($query, $bindType, $bindValue, true);
	}
	public function addTransferOut($data)
	{
		@extract($data);
		$sql="insert into ".$this->tableName."(DomainName,CreateTime,OutRegistrarId,Status,Remark,EnameId,TipWay,CreateIP)values(?,?,?,?,?,?,?,?)";
		return $this->add($sql,'sssisiis',array($domainName,date("Y-m-d H:i:s"),$outRegistrarId,$status,$remark,$enameId,$tipWay,$createIp));
	}
	public function editTransferOut($where , $set)
	{
		$setInfo = array();
		$upInfo = array(); 
		$bindType = '';
		$bindValue = array();
		foreach($set as $key => $value)
		{
			$setInfo[] = $key . ' = ?';
			$bindType .= is_string($value) ? 's' : 'i';
			$bindValue[] = $value;
		}
		foreach($where as $key => $value)
		{
			if($key == 'in')
			{
				$keys = array_keys($where['in']);
				foreach($keys as $k => $v)
				{
					$wen = trim(str_repeat('?,', count($where['in'][$v])), ',');
					$upInfo[] = $v . ' in (' . $wen . ')';
					foreach($where['in'][$v] as $val)
					{
						$bindType .= is_string($val) ? 's' : 'i';
						$bindValue[] = $val;
					}
				}
			}
			else
			{
				$upInfo[] = $key . ' = ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		$query = 'update '. $this->tableName .' set ' . implode(',', $setInfo) . ' where ' . implode(' and ', $upInfo);
		return $this->update($query, $bindType, $bindValue);
	}

	/**
	 * 警报查表用
	 */
	public function getTransferInfoByTime($params)
	{
		if (!isset($params['CreateTime'])) 
		{
			return false;
		}
		$sql = 'select *,count(TransferOutId) as sum from ' . $this->tableName . ' where CreateTime > ? group by EnameId';
		return $this->select($sql,'s',$params);
	}
}

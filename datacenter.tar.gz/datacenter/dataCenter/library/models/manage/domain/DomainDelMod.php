<?php
namespace models\manage\domain;
use core\ModBase;

class DomainDelMod extends ModBase
{
	private $tableName = 'e_domain_delete';
	
	public function __construct($dbName = 'domain')
	{
		parent::__construct($dbName);
	}
	
	/**
	 * 添加域名扩展记录 
	 */
	public function addDomainDel($params)
	{
		$domainId = $params['domainId'];
		$domain = $params['domain'];
		$status = empty($params['status']) ? 0 : $params['status'];
		$result = is_array($params['result']) ? json_encode($params['result']) : $params['result'];
		$query = 'insert into ' . $this->tableName . '(DomainId, Domain, Time, Status, Result) values(?, ?, ?, ?, ?)';
		return $this->add($query, 'issis', array($domainId, $domain, gmdate('Y-m-d H:i:s'), $status, $result));
	}

} 

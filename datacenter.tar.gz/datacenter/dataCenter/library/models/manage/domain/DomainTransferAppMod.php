<?php
namespace models\manage\domain;
use \core\ModBase;
class DomainTransferAppMod extends ModBase
{

	public $tableName = 'e_domain_transfer_app';
	function __construct($db = 'domain')
	{
		parent::__construct('domain');
	}

	/**
	 * 添加转接口记录 
	 */
	public function addTransferApp($domain, $old, $new, $oldExp, $newExp,$year,$money,$ip,$orderId,$status,$enameId)
	{ 
		$query = 'insert into ' . $this->tableName . '(Domain,OldApp,NewApp,OldExpDate,NewExpDate,AddYear,Operator,OperateTime,Money,Ip,OrderId,Status)values(?,?,?,?,?,?,?,?,?,?,?,?)';
		return $this->add($query, "siissiisdsii", array($domain, $old, $new, $oldExp, $newExp,$year,$enameId,date('Y-m-d H:i:s'),$money,$ip,$orderId,$status));
	}
	
	public function updateTransferApp($where,$set)
	{
		if(empty($where) || empty($set))
		{
			return FALSE;
		}
		$upData = $bindValue = array();
		$bindType = '';
		foreach($set as $key => $value)
		{
			$upData[] = $key . '= ? ';
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		$whereDatas = $this->getWhereSql($where);
		return $this->update("update {$this->tableName} set " . implode(',', $upData) . ' where ' . implode(' and ', $whereDatas[0]) .' order by AppId desc', $bindType . $whereDatas[1], array_merge($bindValue, $whereDatas[2]),true);
		
	}
	
	public function getTransferApp($params,$field = "*",$order = false,$limit = FALSE)
	{
		$whereData = array(); 
		$bindValue = array();
		$bindType = '';
		foreach($params as $key=>$value)
		{
			if(substr(trim($key), -1) == '<')
			{
				$key = str_replace('<', '', $key);
				$whereData[] = $key . ' <= ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
			elseif(substr(trim($key), -1) == '>')
			{
				$key = str_replace('>', '', $key);
				$whereData[] = $key . ' >= ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			} 
			else if($key =='in')
			{
				$keys = array_keys($params['in']);
				foreach($keys as $k => $v)
				{
					$wen = trim(str_repeat('?,', count($params['in'][$v])), ',');
					$whereData[] = $v . ' in (' . $wen . ')';
					foreach($params['in'][$v] as $val)
					{
						$bindType .= is_string($val) ? 's' : 'i';
						$bindValue[] = $val;
					}
				}
			}
		}
		if(!empty($params['domain']))
		{
			$whereData[] = 'Domain = ? ';
			$bindValue[] = $params['domain'];
			$bindType .= 's';
		}
		if(!empty($params['oldApp']))
		{
			$whereData[] = 'OldApp = ? ';
			$bindValue[] = $params['oldApp'];
			$bindType .= 'i';
		}
		if(!empty($params['newApp']))
		{
			$whereData[] = 'NewApp = ? ';
			$bindValue[] = $params['newApp'];
			$bindType .= 'i';
		}
		if(!empty($params['oldExpDate']))
		{
			$whereData[] = 'OldExpDate = ? ';
			$bindValue[] = $params['oldExpDate'];
			$bindType .= 's';
		}
		if(!empty($params['newExpDate']))
		{
			$whereData[] = 'NewExpDate = ? ';
			$bindValue[] = $params['newExpDate'];
			$bindType .= 's';
		}
		if(!empty($params['orderId']))
		{
			$whereData[] = 'OrderId = ? '; 
			$bindValue[] = $params['orderId'];
			$bindType .= 'i';
		}
		if(!empty($params['status']))
		{
			$whereData[] = 'Status = ? ';
			$bindValue[] = $params['status'];
			$bindType .= 'i';
		}
		if(!empty($params['enameId']))
		{
			$whereData[] = 'Operator = ? ';
			$bindValue[] = $params['enameId'];
			$bindType .= 'i';
		}
		$sql = "select $field from $this->tableName";
		if($whereData)
		{
			$sql .= ' where ' . implode(' and ', $whereData);
		}
		if($order)
		{
			$sql .= ' order by ' .$order;
		}
		if($limit)
		{
			$sql .= " limit $limit";
		}
		return $this->select($sql, $bindType, $bindValue);
	}
	
	private function getWhereSql($where)
	{
		$whereData = $bindValue = array();
		$bindType = '';
		foreach($where as $key => $value)
		{
			if($key == 'in')
			{
				$keys = array_keys($where['in']);
				foreach($keys as $k => $v)
				{
					$wen = trim(str_repeat('?,', count($where['in'][$v])), ',');
					$whereData[] = $v . ' in (' . $wen . ')';
					foreach($where['in'][$v] as $val)
					{
						$bindType .= is_string($val) ? 's' : 'i';
						$bindValue[] = $val;
					}
				}
			}
			elseif(substr(trim($key), -1) == '<')
			{
				$key = str_replace('<', '', $key);
				$whereData[] = $key . ' <= ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
			elseif(substr(trim($key), -1) == '>')
			{
				$key = str_replace('>', '', $key);
				$whereData[] = $key . ' >= ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
			else 
			{
				$whereData[] = $key . ' = ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		return array($whereData, $bindType, $bindValue);
	}	
	
	
}

<?php
namespace models\manage\domain;
use core\ModBase;

class DomainTransferInMod extends ModBase
{
	public $table;
	public function __construct($db = 'domain')
	{
		$this->table = 'e_domain_transfer_in';
		parent::__construct($db);
	}

	/**
	 * 根据条件获取转入信息 
	 */
	public function getTransferInfo($params, $fields = "*", $isOne = true)
	{
		if(empty($params))
		{
			return false;
		}
		$where = $bindValue = array();
		$bindType = '';
		foreach($params as $key => $value)
		{
			if($key == 'order' || $key == 'limit' || $key == 'like')
			{
				continue;
			}
			if(preg_match("/[<>](=)?$/", $key))
			{
				$where[] = $key . ' ? ';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
			else if($key =='in')
			{
				$keys = array_keys($params['in']);
				foreach($keys as $k => $v)
				{
					$wen = trim(str_repeat('?,', count($params['in'][$v])), ',');
					$where[] = $v . ' in (' . $wen . ')';
					foreach($params['in'][$v] as $val)
					{
						$bindType .= is_string($val) ? 's' : 'i';
						$bindValue[] = $val;
					}
				}
			}
			else
			{
				$fuhao = '=';
				$one = substr($value, 0, 1);
				if($one == '<' || $one == '>' || $one == '!')
				{ 
					$fuhao = (stripos($value, $one . '=') !== FALSE) ? $one . '=' : $one;
					$value = str_replace($fuhao, '', $value);
				}
				$where[]= $key . $fuhao ." ?";
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		$query = "select $fields from $this->table where " . implode(" and ", $where);
		if(!empty($params['like']))
		{
			foreach($params['like'] as $key => $value)
			{
				$query .= " and $key like '%$value%' ";					
			}
		}
		if(!empty($params['order']))
		{
			$query .= ' order by ' . $params['order'];
		}
		if(!empty($params['limit']))
		{
			$query .= ' limit ' . $params['limit'];
		}
		return $this->select($query, $bindType, $bindValue,$isOne);
	}

	/**
	 * 添加域名转入记录
	 */
	public function addTransferIn($params)
	{
		if(empty($params) || empty($params['DomainName']))
		{
			return false;
		}
		if(!isset($params['Password']))
		{
			$params['Password'] = '';
		}
		if(!isset($params['DnsStatus']))
		{
			$params['DnsStatus'] = '2';
		}
		$keyArr = $bindValue = array();
		$types = '';
		foreach($params as $key => $value)
		{
			$keyArr[] = $key;
			$bindValue[] = $value;
			$types .= is_string($value) ? 's' : 'i';
		}
		$query = 'insert into ' . $this->table . '(' . implode(',', $keyArr) . ') values(' . trim(str_repeat('?,', count($keyArr)), ',') . ')';
		return $this->add($query, $types, $bindValue);
	}

	/**
	 * 根据enameID或者转入总数
	 */
	public function getTransferCountByEnameId($enameId)
	{
		return $this->getRow("select count(1) as total from " . $this->table . " where EnameId = ? ", 's', array(
				$enameId));
	}

	/**
	 * 根据转入id enameid获取转入记录
	 */

	public function getTransferInByIdEnameId($id, $enameId = FALSE, $fields = "*")
	{
		if($enameId)
		{
			return $this->getRow("select $fields from " . $this->table . ' where TransferInId = ? and EnameId = ? ', 'ss', array(
					$id, $enameId));
		}
		return $this->getRow("select $fields from " . $this->table . ' where TransferInId = ? ', 'i', array($id));
	}

	public function upTransferInfo($where, $set)
	{
		$setInfo = array();
		$upInfo = array();
		$bindType = '';
		$bindValue = array();
		foreach($set as $key => $value)
		{
			$setInfo[] = $key . ' = ?';
			$bindType .= is_string($value) ? 's' : 'i';
			$bindValue[] = $value;
		}
		foreach($where as $key => $value)
		{
			if($key == 'in')
			{
				$keys = array_keys($where['in']);
				foreach($keys as $k => $v)
				{
					$wen = trim(str_repeat('?,', count($where['in'][$v])), ',');
					$upInfo[] = $v . ' in (' . $wen . ')';
					foreach($where['in'][$v] as $val)
					{
						$bindType .= is_string($val) ? 's' : 'i';
						$bindValue[] = $val;
					}
				}
			}
			else
			{
				$upInfo[] = $key . ' = ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		$query = 'update ' . $this->table . ' set ' . implode(',', $setInfo) . ' where ' . implode(' and ', $upInfo);
		return $this->update($query, $bindType, $bindValue);
	}
	
	/**
	 * 根据提件获取转入总数
	 */
	public function getTransferCount($param)
	{
		$sql="select count(1) as total from " . $this->table;
		$where = $bindValue = array();
		$bindType = '';
		foreach($param as $key => $value)
		{
			if($key == 'in')
			{
				$keys = array_keys($param['in']);
				foreach($keys as $k => $v)
				{
					$keys = array_keys($param['in']);
					foreach($keys as $k => $v)
					{ 
						$wen = trim(str_repeat('?,', count($param['in'][$v])), ',');
						$where[] = $v . ' in (' . $wen . ')';
						foreach($param['in'][$v] as $val)
						{
							$bindType .= is_string($val) ? 's' : 'i';
							$bindValue[] = $val;
						}
					}
				}
			}
			else
			{
				$fuhao = '=';
				$one = substr($value, 0, 1);
				if($one == '<' || $one == '>' || $one == '!')
				{
					$fuhao = (stripos($value, $one . '=') !== FALSE) ? $one . '=' : $one;
					$value = str_replace($fuhao, '', $value);
				}
				$where[]= $key . $fuhao ." ?";
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		return $this->getRow($sql.' where ' . implode(' and ', $where), $bindType, $bindValue);
	}
}

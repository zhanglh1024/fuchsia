<?php
namespace models\manage\domain;
use core\ModBase;
class DomainProtectionMod extends ModBase
{
	private $table = 'e_domain_protection';
	public function __construct($dbName = 'domain')
	{
		parent::__construct($dbName);
	}

	public function getTodoCount()
	{
		$sql = 'select count(Id) as count from ' . $this->table . ' where Status = 1';
		return $this->select($sql,'',array());
	}
	
	public function getDomainSecureCount($type,$status = 1)
	{
		$sql = 'select count(Id) as count from ' . $this->table . ' where Status = ? and Type = ?';
		return $this->select($sql,'ii',array($status,$type));
	}
}
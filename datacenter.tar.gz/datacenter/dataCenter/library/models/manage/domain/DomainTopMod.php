<?php
namespace models\manage\domain;
use \core\ModBase;
class DomainTopMod extends ModBase
{

	public $tableName = 'e_topdomain_consume';
	function __construct($db = 'domain')
	{
		parent::__construct('domain');
	}

	/**
	 * 添加珍品记录 
	 */
	public function addTopDomain($domain, $enameId, $topType, $remark, $price)
	{
		$query = 'insert into ' . $this->tableName . '(Domain,EnameId,CreateTime,TopType,Price,Remark)values(?,?,?,?,?,?)';
		return $this->add($query, "sisiis", array($domain, $enameId, date('Y-m-d H:i:s'), $topType, $price, $remark));
	}

	/**
	 * 获取总数
	 */
	public function getTopDomainCount($params)
	{
		$return = $this->getSqlPart($params);
		list($where,$bindValue,$bindType) = $return;
		$query = "select count(1) as total from  " . $this->tableName;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		return $this->getRow($query, $bindType, $bindValue);
	}
	
	/**
	 * 获取部分sql
	 */
	private function getSqlPart($params)
	{
		$where = $bindValue = array();
		$bindType = '';
		if(!empty($params['domain']))
		{
			$where[] = 'Domain = ?';
			$bindValue[] = $params['domain'];
			$bindType .= 's';
		}
		if(!empty($params['enameId']))
		{
			$where[] = 'EnameId = ?';
			$bindValue[] = $params['enameId'];
			$bindType .= 'i';
		}
		if(!empty($params['topType']))
		{
			$where[] = 'TopType = ?';
			$bindValue[] = $params['topType'];
			$bindType .= 'i';
		}
		if(!empty($params['price']))
		{
			$where[] = 'Price = ?';
			$bindValue[] = $params['price'];
			$bindType .= 's';
		}
		if(!empty($params['id']))
		{
			$where[] = 'Id = ?';
			$bindValue[] = $params['id'];
			$bindType .= 'i';
		}
		if(!empty($params['createTime']))
		{
			$where[] = 'year(CreateTime) = ?';
			$bindValue[] = $params['createTime'];
			$bindType .= 's';
		}
		if(!empty($params['startTime']))
		{
			$where[] = 'CreateTime >= ?';
			$bindValue[] = $params['startTime'].' 00:00:00';
			$bindType .= 's';
		}
		if(!empty($params['endTime']))
		{
			$where[] = 'CreateTime <= ?';
			$bindValue[] = $params['endTime'] .' 23:59:59';
			$bindType .= 's';
		}
		return array($where,$bindValue,$bindType);
	}

	/**
	 * 根据条件获取珍品记录 通常只要域名跟时间
	 */
	public function getTopDomainByDomain($params, $manage = TRUE,$limit = FALSE)
	{
		$return = $this->getSqlPart($params);
		list($where,$bindValue,$bindType) = $return;
		if(empty($where) && $manage)//管理平台调用的话 不允许直接查找所有的
		{
			return FALSE;
		}
		$query = "select * from  " . $this->tableName;
		if($where)
		{
			$query .= ' where ' . implode(' and ', $where);
		}
		$query .=' order by CreateTime DESC';
		if($limit)
		{
			$query .=' limit '.$limit;
		}
		return $this->select($query, $bindType, $bindValue);
	}
}

<?php
namespace models\manage\domain;
use core\ModBase;
class DomainBakMod extends ModBase
{

	private $tableName;
	function __construct($dbName = 'domain')
	{
		parent::__construct($dbName);
		$this->tableName='e_domains_bak';
	}

	/**
	 * 根据条件获取域名信息
	 * @param array $params
	 * @param string $fields
	 * @param boolean $isOne
	 * @return array|boolean
	 */
	public function getDomainBakOne($params, $fields = "*", $isOne = true)
	{
		if(empty($params))
		{
			return false;
		}
		$where = $bindValue = array();
		$bindType = '';
		$order = $limit = '';
		if (isset($params['order'])) 
		{
			$order = ' order by ' . $params['order'];
			unset($params['order']);
		}
		if (isset($params['limit']))
		{
			$limit = ' limit ' . $params['limit'];
			unset($params['limit']);
		}
		foreach($params as $key => $value)
		{
			$where[] = $key . '= ?';	//单引号与等号之间不能加空格，否则<>搜索会失效  
			$bindType .= is_string($value) ? 's' : 'i';
			$bindValue[] = $value;
		}
		$query = "select $fields from $this->tableName where " . implode(' and ', $where) . $order . $limit;
		return $this->select($query, $bindType, $bindValue, $isOne);
	}
	/**
	 * 更新域名信息
	 */
	public function upDomainInfo($where, $set)
	{
		if(empty($where) || empty($set))
		{
			return false;
		}
		if(isset($set['Roid']))
		{
			unset($set['Roid']);
		}
		if(isset($set['roid']))
		{
			unset($set['roid']);
		}
		unset($set['FirstClass']);
		unset($set['SecondClass']);
		unset($set['ThirdClass']);
		unset($set['DomainBody']);
		unset($set['firstclass']);
		unset($set['secondclass']);
		unset($set['thirdclass']);
		unset($set['domainbody']);
		if(isset($set['RegYear']))
		{
			unset($set['RegYear']);
		}
		if(isset($set['RegMonth']))
		{
			unset($set['RegMonth']);
		}
		if(isset($set['RegDay']))
		{
			unset($set['RegDay']);
		}
		if(isset($set['ExpYear']))
		{
			unset($set['ExpYear']);
		}
		if(isset($set['ExpMonth']))
		{
			unset($set['ExpMonth']);
		}
		if(isset($set['ExpDay']))
		{
			unset($set['ExpDay']);
		}
		if(isset($set['KExpDate']))
		{
			unset($set['KExpDate']);
		}
		if(isset($set['KRegId']))
		{
			unset($set['KRegId']);
		}
		$whereData = $upData = $bindValue = array();
		$bindType = '';
		foreach($set as $key => $value)
		{
			$upData[] = $key . ' = ? ';
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		foreach($where as $key => $value)
		{
			$whereData[] = $key . ' = ? ';
			$bindValue[] = $value;
			$bindType .= is_string($value) ? 's' : 'i';
		}
		$query = 'update '. $this->tableName .' set ' . implode(',', $upData) . ' where ' . implode(' and ', $whereData);
		return $this->update($query, $bindType, $bindValue);
	}
	
	public function addDomain($data)
	{
		if(!isset($data['Status']))
		{
			$data['Status']=0;
		}
		@extract($data);
		$sql="insert into $this->tableName(DomainId,DomainName,RegistrarId,RegDate,ExpDate,UpdateDate,EnameId,TempUserName,TemplateId
		,DomainLength,DomainStatus,DomainMyStatus,DomainHoldStatus,DomainGroup,ClassName,DnsType,AutoRenew,DomainLtd,DomainProperty,SysUpdateTime,DomainPassword,AddDate,PrivacyTemp,Status,IsRealName)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		return $this->add($sql, 'isisssisiiiiiiiiiiisssiii', array($DomainId,$DomainName,$RegistrarId,
				$RegDate,$ExpDate,$UpdateDate,$EnameId,$TempUserName,$TemplateId,$DomainLength,$DomainStatus,$DomainMyStatus,$DomainHoldStatus,$DomainGroup,
				$ClassName,$DnsType,$AutoRenew,$DomainLtd,$DomainProperty,
				$SysUpdateTime,$DomainPassword,$AddDate,$PrivacyTemp,$Status,$IsRealName));
	}
	
	public function getDomainBakList($where, $fields = "*",$limit = '', $order = '')
	{
		$orderstr = empty($order) ? " " : ' order by ' . $order;
		$limitstr = empty($limit) ? '' : ' limit ' . $limit;
		$whereDatas = $this->getWhereSql($where);
		return $this->select("select $fields from {$this->tableName} " . ' where ' . implode(' and ', $whereDatas[0]) . $orderstr . $limitstr, $whereDatas[1], $whereDatas[2]);
	}	
	
	private function getWhereSql($where)
	{
		$whereData = $bindValue = array();
		$bindType = '';
		foreach($where as $key => $value)
		{
			if($key=='regStartDate')
			{
				$whereData[] = 'RegDate > ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
				continue;
			}
			if($key=='regEndDate')
			{
				$whereData[] = 'RegDate <= ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
				continue;
			}
			if($key == 'in')
			{
				$keys = array_keys($where['in']);
				foreach($keys as $k => $v)
				{
					$wen = trim(str_repeat('?,', count($where['in'][$v])), ',');
					$whereData[] = $v . ' in (' . $wen . ')';
					foreach($where['in'][$v] as $val)
					{
						$bindType .= is_string($val) ? 's' : 'i';
						$bindValue[] = $val;
					}
				}
			}
			elseif(substr(trim($key), -1) == '<')
			{
				$key = str_replace('<', '', $key);
				$whereData[] = $key . ' <= ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
			elseif(substr(trim($key), -1) == '>')
			{
				$key = str_replace('>', '', $key);
				$whereData[] = $key . ' >= ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
			else
			{
				$whereData[] = $key . ' = ?';
				$bindType .= is_string($value) ? 's' : 'i';
				$bindValue[] = $value;
			}
		}
		return array($whereData, $bindType, $bindValue);
	}	
}

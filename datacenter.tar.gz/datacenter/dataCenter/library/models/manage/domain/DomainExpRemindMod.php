<?php
namespace models\manage\domain;
use core\ModBase;
class DomainExpRemindMod extends ModBase
{
	private $table = 'e_domain_exp_remind';
	public function __construct($dbName = 'domain')
	{
		parent::__construct($dbName);
	}

	/**
	 * 获取提醒列表待处理数
	 */
	public function getTodoCount()
	{
		$sql = 'select count(Id) as count from ' . $this->table . ' where Status = 3 and Month= "' . date('Y-m') . '"';
		return $this->select($sql, '', array());
	}

	public function getExpRemindCount($date, $type)
	{
		$sql = "select count(1) as cscount,date(UpdateTime) as vtime,AdminId as VerifyUser,$type as cstype from " . $this->table . " where AdminId!='' and date(UpdateTime)= ? and Month = ? group by Telephone order by FirstExpTime Asc";
		return $this->select($sql, 'ss', array($date, date('Y-m', strtotime($date))));
	}
}

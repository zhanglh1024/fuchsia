<?php
namespace models\manage\redis;

use core\RedisLib;
class ApppushMod extends RedisLib
{

	private $redis;

	private $messId;

	public function __construct()
	{
		$this->redis = parent::getInstance('manage');
	}

	public function getAppMessId()
	{
		return $this->redis->get("AppStartMessId");
	}

	public function setAppMessId($messId)
	{
		return $this->redis->set("AppStartMessId", $messId);
	}
}
<?php
namespace models\bbs;

use core\ModBase;
class PreForumPostMod extends ModBase
{

	private $table;

	public function __construct()
	{
		parent::__construct('bbs');
		$this->tableName = 'pre_forum_post';
	}

	/**
	 *
	 */
	public function deletePostByTid($id)
	{
		$sql = "DELETE FROM {$this->tableName} WHERE tid=? LIMIT 1";
		
		return $this->delete($sql, 'i', array($id));
	}
	
	/**
	 * 插入帖子
	 * @param array $info
	 */
	public function addPost($data)
	{
		$param['pid']				= $data['pid'];
		$param['fid']	 			= 5;
		$param['tid'] 				= $data['tid'];
		$param['first'] 			= 1;
		$param['author']			= $data['author'];			// 作者
		$param['authorid']		= $data['enameId'];			// 作者id
		$param['subject']       = $data['title'];				// 标题
		$param['dateline']      = $data['createTime'];		// 发表时间
		$param['message']			= $data['message'];			//
		$param['useip']			= 0;
		$param['invisible']		= 0;
		$param['usesig']     	= 1;
		$param['htmlon']     	= 0;
		$param['bbcodeoff']     = 0;
		$param['smileyoff']     = 0;
		$param['parseurloff']   = 0;
		$param['attachment']		= 0;
		$param['replycredit']   = 0;
		$param['status']  		= 0;
		
		$keys = implode(',', array_keys($param));
		$vals = implode(',', array_fill(0, count($param), '?'));
		
		$sql = "INSERT INTO {$this->tableName}({$keys}) VALUES({$vals})";
		
		return $this->add($sql, 'iiiisisisiiiiiiiiii', $param);
	}
}
?>
<?php
namespace models\bbs;

use core\ModBase;
class PreEnamePluginMod extends ModBase
{
	private $table;

	public function __construct()
	{
		parent::__construct('bbs');
		$this->table = 'pre_ename_plugin';
	}
	
	/**
	 * 获取用户的论坛uid
	 */
	public function getUid($enameid)
	{
		$sql = "SELECT uid FROM {$this->table} WHERE enameId=?";
		return $this->getOne($sql, 'i', array($enameid));
	}
}
?>
<?php
namespace models\bbs;

use core\ModBase;
class PreForumPostTableidMod extends ModBase
{
	private $table;

	public function __construct()
	{
		parent::__construct('bbs');
		$this->table = 'pre_forum_post_tableid';
	}
	
	/**
	 * 获取用户的论坛uid
	 */
	public function addPid()
	{
		$sql = "INSERT {$this->table}(pid) VALUES(NULL)";
		return $this->add($sql, '', array());
	}
}
?>
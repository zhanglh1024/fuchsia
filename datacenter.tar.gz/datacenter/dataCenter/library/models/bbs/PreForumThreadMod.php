<?php
namespace models\bbs;

use core\ModBase;
class PreForumThreadMod extends ModBase
{

	private $tableName;

	public function __construct()
	{
		parent::__construct('bbs');
		$this->tableName = 'pre_forum_thread';
	}

	/**
	 * 删除帖子
	 */
	public function deleteThreadByTid($id)
	{
		$sql = "DELETE FROM {$this->tableName} WHERE tid=? LIMIT 1";
		
		return $this->delete($sql, 'i', array($id));
	}
	
	/**
	 * 生成帖子
	 */
	public function addThread($data)
	{
		$sql = "INSERT INTO {$this->tableName}(fid, posttableid, readperm, price, typeid, sortid, author, authorid, subject, dateline, lastpost, lastposter, displayorder, digest, special, attachment, moderated, status, isgroup, replycredit, closed) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		$param['fid'] 				= 5;								// 上级论坛
		$param['posttableid'] 	= 0; 					 			// 帖子表ID
		$param['readperm'] 		= 0;  							// 阅读权限
		$param['price'] 			= 0;  							// 价格
		$param['typeid']			= 60; 							// 6投稿，7原创，8转载，9爆料，60编辑已阅，11活动
		$param['sortid']			= 0;  							// 分类信息id
		$param['author']			= $data['author'];			// 作者
		$param['authorid']		= $data['enameId'];			// 作者id
		$param['subject']       = $data['title'];				// 标题
		$param['dateline']      = $data['createTime'];		// 发表时间
		$param['lastpost']		= $data['createTime'];		// 最后发表
		$param['lastposter']		= $data['author'];			// 最后发表人id
		$param['displayorder']  = 0;								// 显示顺序
		$param['digest']			= 0;								// 是否精华
		$param['special']       = 0;								// 特殊主题,1:投票;2:商品;3:悬赏;4:活动;5:辩论贴;127:插件相关
		$param['attachment']    = 0;								// 附件,0无附件 1普通附件 2有图片附件
		$param['moderated']     = 0;								// 是否被管理员改动
		$param['status']        = 0;								//
		$param['isgroup']       = 0;								// 是否为群组帖子
		$param['replycredit']   = 0;								// 回帖奖励积分主题记录积分值
		$param['closed']			= 0;								// 是否关闭		
		
		return $this->add($sql,'iiiiiisisiisiiiiiiiii', $param);
	}
}
?>
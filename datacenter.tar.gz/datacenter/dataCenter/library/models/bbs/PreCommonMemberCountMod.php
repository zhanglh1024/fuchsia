<?php
namespace models\bbs;

use core\ModBase;
class PreCommonMemberCountMod extends ModBase
{

	private $tableName;

	public function __construct()
	{
		parent::__construct('bbs');
		$this->tableName = 'pre_common_member_count';
	}

	/**
	 * @getCredits 通过作者ID获取用户玉米数
	 * @param $uid 用户ID（必须）
	 *
	 * @return
	 */
	public function getCredits($uid)
	{
		$sql = "SELECT extcredits2 FROM {$this->tableName} WHERE uid=?";
		return $this->getOne($sql, 'i', array($uid));
	}
	
	/**
	 * @updateCredits 变更玉米数
	 *
	 * @param $uid 必需登录ID
	 *
	 * @return
	 */
	public function updateCredits($credit, $uid)
	{
		$sql = "UPDATE " . $this->tableName . " set extcredits2 = extcredits2 + ? WHERE uid = ?";
		return $this->update($sql, 'ii', array($credit,$uid));
	}
}
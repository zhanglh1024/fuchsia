<?php
namespace models\bbs;
use core\ModBase;

class PreEnameCreditLogMod extends ModBase
{

	private $tableName;

	public function __construct()
	{
		parent::__construct('bbs');
		$this->tableName = 'pre_ename_credit_log';
	}
	
	/**
	 * @addCreditsLog 添加玉米变更记录
	 *
	 * @param $uid 必需登录ID
	 *
	 * @return
	 */
	public function addCreditsLog($operation, $credit, $uid, $tid)
	{
	
		$param['uid']	 			= $uid;
		$param['operation'] 	= $operation;
		$param['relatedid'] 	= $tid;
		$param['dateline']		= time();
		$param['extcredits1']		= 0;
		$param['extcredits2']		= $credit;
		$param['extcredits3']		= 0;
		$param['extcredits4']		= 0;
		$param['extcredits5']		= 0;
		$param['extcredits6']		= 0;
		$param['extcredits7']		= 0;
		$param['extcredits8']		= 0;
		$keys = implode(',', array_keys($param));
		$vals = implode(',', array_fill(0, count($param), "?"));
	
		$sql = "INSERT INTO {$this->tableName}({$keys}) VALUES({$vals})";
	
		return $this->add($sql, 'isiiiiiiiiii', $param);
	}
}
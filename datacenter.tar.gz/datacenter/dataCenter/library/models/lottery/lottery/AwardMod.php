<?php
namespace models\lottery\lottery;
use core\ModBase;

class AwardMod extends ModBase
{

	private $tableName;

	function __construct($dbName = 'lottery')
	{
		parent::__construct($dbName);
		$this->tableName = 'e_lottery_award';
	}

	public function addAward($params)
	{
		if(empty($params) || empty($params['remark']) || empty($params['remark']))
		{
			return FALSE;
		}
		$query = "insert into $this->tableName(aw_activity_type,aw_amount,aw_money,aw_type,aw_percent,aw_remark,aw_promoid,aw_prompt,aw_start_time,aw_end_time)";
		$query .= " values(?,?,?,?,?,?,?,?,?,?)";
		$bindValue = array(intval($params['awtypeid']), intval($params['amount']), $params['money'], 
				intval($params['type']), $params['percent'], $params['remark'], intval($params['promoid']), 
				$params['prompt'], $params['starttime'], $params['endtime']);
		return $this->add($query, 'iididsisii', $bindValue);
	}

	public function upAward($data)
	{
		if(empty($data['awid']))
		{
			return FALSE;
		}
		$setStr = '';
		$bindType = '';
		$params = array();
		
		if($data['amount'] !== '')
		{
			$setStr .= empty($setStr) ? 'aw_amount =?' : ' ,aw_amount=? ';
			$bindType .= 'i';
			$params[] = $data['amount'];
		}
		if($data['percent'] !== '')
		{
			$setStr .= empty($setStr) ? ' aw_percent=?' : ' ,aw_percent=? ';
			$bindType .= 'd';
			$params[] = $data['percent'];
		}
		if(!empty($data['remark']))
		{
			$setStr .= empty($setStr) ? ' aw_remark=?' : ' ,aw_remark=? ';
			$bindType .= 's';
			$params[] = $data['remark'];
		}
		if($data['promoid'] !== '')
		{
			$setStr .= empty($setStr) ? ' aw_promoid=?' : ' ,aw_promoid=? ';
			$bindType .= 'i';
			$params[] = $data['promoid'];
		}
		if($data['money'] !== '')
		{
			$setStr .= empty($setStr) ? ' aw_money=?' : ' ,aw_money=? ';
			$bindType .= 'd';
			$params[] = $data['money'];
		}
		if(!empty($data['type']))
		{
			$setStr .= empty($setStr) ? ' aw_type=?' : ' ,aw_type=? ';
			$bindType .= 'i';
			$params[] = $data['type'];
		}
		if(!empty($data['prompt']))
		{
			$setStr .= empty($setStr) ? ' aw_prompt=?' : ' ,aw_prompt=? ';
			$bindType .= 's';
			$params[] = $data['prompt'];
		}
		if($data['starttime'] != '')
		{
			$setStr .= empty($setStr) ? ' aw_start_time=?' : ' ,aw_start_time=? ';
			$bindType .= 'i';
			$params[] = $data['starttime'];
		}
		if($data['endtime'] != '')
		{
			$setStr .= empty($setStr) ? ' aw_end_time=?' : ' ,aw_end_time=? ';
			$bindType .= 'i';
			$params[] = $data['endtime'];
		}
		$params[] = $data['awid'];
		return $this->update("update $this->tableName set " . $setStr . " where aw_id=? ", $bindType . 'i', $params);
	}

	/**
	 * 获取列表
	 */
	public function getAwardList($data, $limit = '', $order = '')
	{
		$setStr = '';
		$bindType = '';
		$params = array();
		
		if(!empty($data['awtypeid']))
		{
			$setStr .= empty($setStr) ? ' where aw_activity_type =?' : ' ,aw_activity_type=? ';
			$bindType .= 'i';
			$params[] = $data['awtypeid'];
		}
		$orderstr = empty($order) ? " " : ' order by ' . $order;
		$limitstr = empty($limit) ? '' : ' limit ' . $limit;
		return $this->select("select * from " . $this->tableName . $setStr . $orderstr . $limitstr, $bindType, $params);
	}

	/**
	 * 获取数量
	 *
	 * @param array $info
	 */
	public function getCodeCount($data)
	{
		$setStr = '';
		$bindType = '';
		$params = array();
		
		if(!empty($data['awtypeid']))
		{
			$setStr .= empty($setStr) ? ' where aw_activity_type =?' : ' ,aw_activity_type=? ';
			$bindType .= 'i';
			$params[] = $data['awtypeid'];
		}
		return $this->select("select count(*) as sum  from  " . $this->tableName . $setStr, $bindType, $params, true);
	}

	/**
	 * 获取
	 *
	 * @param array $info
	 */
	public function getAwardDetail($awid)
	{
		return $this->select("select *  from " . $this->tableName . " where aw_id = ?", 'i', array($awid), true);
	}

	public function delAward($awid)
	{
		$sql = "delete  from  $this->tableName where aw_id=?";
		$rs = $this->delete($sql, 'i', array($awid));
	}

	public function getAward($awid)
	{
		$sql = "select *  from  $this->tableName where aw_id=?";
		$rs = $this->select($sql, 'i', array($awid));
	}
}

<?php
namespace models\lottery\lottery;
use core\ModBase;

class ChanceMod extends ModBase
{

	private $table;

	function __construct($dbName = 'lottery')
	{
		parent::__construct($dbName);
		$this->table = 'e_lottery_chance';
	}

	/**
	 * 添加机会
	 */
	public function addChance($params)
	{
		if(empty($params) || empty($params['enameid']))
		{
			return FALSE;
		}
		$query = "insert into $this->table(ch_enameid,ch_expire_time,ch_domain,ch_status,ch_createtime,ch_type)";
		$query .= " values(?,?,?,?,?,?)";
		$bindValue = array($params['enameid'], $params['expiretime'], $params['domain'], 0, $params['createtime'], 
				$params['type']);
		return $this->add($query, 'iisiii', $bindValue);
	}

	/**
	 * 统计抽奖次数
	 *
	 * @param int $enameid
	 * @param int $chstatus
	 * @param number $type
	 * @return boolean|Ambigous <boolean, mixed, multitype:, unknown,
	 *         multitype:multitype: >
	 */
	public function getChanceCount($enameid, $chstatus, $type = 1)
	{
		$whereStr = ' ch_type = ? ';
		$bingType = 'i';
		$params = array($type);
		if(!empty($enameid))
		{
			$whereStr .= ' and ch_enameid = ? ';
			$bingType .= 'i';
			$params[] = $enameid;
		}
		if($chstatus !== '')
		{
			$whereStr .= ' and ch_status = ? ';
			$bingType .= 'i';
			$params[] = $chstatus;
		}
		return $this->getOne("select count(*) as sum  from " . $this->table . ' where ' . $whereStr, $bingType, $params, 
			true);
	}

	/**
	 * 更新机会
	 *
	 * @param unknown $data
	 * @return boolean
	 */
	public function upChance($data)
	{
		if(empty($data['chid']))
		{
			return FALSE;
		}
		$setStr = '';
		$bindType = '';
		$params = array();
		if(!empty($data['chstatus']))
		{
			$setStr .= empty($setStr) ? ' ch_status=?' : ' ,ch_status=? ';
			$bindType .= 'i';
			$params[] = $data['chstatus'];
		}
		$params[] = $data['chid'];
		return $this->update("update $this->table set " . $setStr . " where ch_id=? ", $bindType . 'i', $params);
	}

	public function getChance($parmas, $order = FALSE)
	{
		if(empty($parmas))
		{
			return false;
		}
		$where = array();
		$bindType = '';
		$values = array();
		if(isset($parmas['Id']))
		{
			$where[] = ' ch_id= ? ';
			$bindType .= 'i';
			$values[] = $parmas['Id'];
		}
		if(isset($parmas['EnameId']))
		{
			$where[] = ' ch_enameid = ? ';
			$bindType .= 'i';
			$values[] = $parmas['EnameId'];
		}
		if(isset($parmas['Type']))
		{
			$where[] = ' ch_type = ? ';
			$bindType .= 'i';
			$values[] = $parmas['Type'];
		}
		if(isset($parmas['Status']))
		{
			$where[] = ' ch_status = ? ';
			$bindType .= 'i';
			$values[] = $parmas['Status'];
		}
		$wherestr = empty($where) ? '' : ' where ' . implode(' and ', $where);
		$order = empty($order) ? '' : ' order by ' . $order;
		return $this->getRow('select * from ' . $this->table . $wherestr . $order, $bindType, $values);
	}
}

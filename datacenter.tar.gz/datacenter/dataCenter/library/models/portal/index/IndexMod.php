<?php
namespace models\portal\index;

use core\ModBase;

class IndexMod extends ModBase
{
	private $tableName;
	
	function __construct($dbName = 'portal')
	{
		parent::__construct($dbName);
		$this->tableName='p_notice';
	}
	
	public function getList()
	{
		$query = "select * from $this->tableName";
		return $this->select($query, array(), array());
	}
}
<?php
namespace models\portal\card;

use core\ModBase;

class CardMod extends ModBase
{
	private $tableName;

	function __construct($dbName = 'portal')
	{
		parent::__construct($dbName);
		$this->tableName='p_card';
	}

	public function getCardCount($param)
	{
		if(empty($param))
		{
			return false;
		}
		$keys = array();
		$codes = array();
		$types = array();
		$values = array();
		foreach($param as $key => $value)
		{
			if(!empty($value))
			{
				if($key == 'pc_nic_name')
				{
					$codes[] = $key . ' LIKE ?';
					$types[] = $value[0];
					$values[] = "%".$value[1]."%";
				}
				elseif($key == 'excludeCardId' && strrpos($value[1],','))
				{
					$codes[] = 'pc_id NOT IN (?,?)';
					$types[] = 'i';
					$types[] = 'i';
					$list = explode (',', $value[1]);
					$values[] = $list[0];
					$values[] = $list[1];
				}
				elseif($key == 'excludeCardId' && !strrpos($value[1],','))
				{
					$codes[] = 'pc_id NOT IN (?)';
						$types[] = $value[0];
						$values[] = $value[1];
				}
				elseif($key == 'excludeStatus')
				{
					$codes[] = 'pc_status NOT IN (?)';
					$types[] = $value[0];
					$values[] = $value[1];
				}	
				else
				{
					$codes[] = $key . ' = ?';
					$types[] = $value[0];
				   $values[] = $value[1];
				}
			}
		}
		if(!empty($codes))
		{
			$sql = "SELECT COUNT(*) AS COUNT FROM $this->tableName WHERE ".implode(' AND ', $codes);
		}
		else
		{
			$sql = "SELECT COUNT(*) AS COUNT FROM $this->tableName " ;
		}
			
		$types =	implode('', $types);
		
		
		return $this->getRow($sql, $types, $values);
	}

	public function getList($offset,$pagesize,$param,$orderType)
	{
		$keys = array();
		$codes = array();
		$types = array();
		$values = array();
		
		foreach($param as $key => $value)
		{
			if(!empty($value))
			{	
				if($key == 'pc_nic_name')
				{
					$codes[] = $key . ' LIKE ? ';
					$types[] = $value[0];
					$values[] = "%".$value[1]."%";
				}
				elseif($key == 'excludeCardId' && strrpos($value[1],','))
				{
					$codes[] = 'pc_id NOT IN (?,?)';
					$types[] = 'i';
					$types[] = 'i';
					$list = explode (',', $value[1]);
					$values[] = $list[0];
					$values[] = $list[1];
				}
				elseif($key == 'excludeCardId' && !strrpos($value[1],','))
				{
					$codes[] = 'pc_id NOT IN (?)';
					$types[] = $value[0];
					$values[] = $value[1];
				}
				elseif($key == 'excludeStatus')
				{
					$codes[] = 'pc_status NOT IN (?)';
					$types[] = $value[0];
					$values[] = $value[1];
				}
				else
				{
					$codes[] = $key . ' = ? ';
					$types[] = $value[0];
					$values[] = $value[1];
				}
			}
		}
		
		$sql = "SELECT pc_id AS cardId , pc_ename_id AS enameId, pc_shop_name AS shopName, pc_type AS type, pc_public AS isPublic, pc_status AS status,
		pc_recommend AS isRecommend, pc_real_name AS realName, pc_nic_name AS nickname, pc_job AS job, pc_title AS title, pc_address AS address, pc_domain AS domain,
		pc_site AS site, pc_weibo AS weibo, pc_domain_success AS domainSuccess, pc_pic AS pic, pc_qq AS qq, pc_phone AS phone, pc_introduction AS introduction,
		pc_public_phone AS isPhonePublic, pc_create_time AS createTime, pc_check_time AS checkTime, pc_rec_time AS recTime, pc_street AS street, pc_price AS price
		FROM $this->tableName";
		
		if(!empty($codes))
		{
			$sql .= ' WHERE ' . implode(' AND ', $codes);
		}
		
		$types =	implode('', $types);
		$types .= 'ii';
		
		$values[] = $offset;
		$values[] = $pagesize;
		if($orderType == 2)
		{
			$sql .= " ORDER BY pc_check_time desc LIMIT ?,?";
		}
		elseif($orderType == 3)
		{
			$sql .= " ORDER BY pc_create_time desc LIMIT ?,?";
		}
		elseif($orderType == 4)
		{
			$sql .= " ORDER BY pc_create_time LIMIT ?,?";
		}
		elseif($orderType == 1)
		{
			$sql .= " ORDER BY  pc_rec_time desc, pc_check_time desc LIMIT ?,?";
		}
		else
		{
			$sql .= " ORDER BY  pc_rec_time desc, pc_check_time desc, pc_create_time desc LIMIT ?,?";
		
		}
 		return $this->select($sql, $types, $values);
	}

	public function addCard($param)
	{
		if(empty($param))
		{
			return false;
		}
		$keys = array();
		$codes = array();
		$types = array();
		$values = array();
		$param['pc_create_time'] = array('i', $_SERVER['REQUEST_TIME']);
		foreach($param as $key => $value)
		{
			$keys[] = $key;
			$codes[] = '?';
			$types[] = $value[0];
			$values[] = $value[1];
		}
		$sql = "INSERT INTO $this->tableName (" . implode(',', $keys) . ") VALUES (" . implode(',', $codes) . ")";

		return $this->add($sql, implode('', $types), $values);
	}

	public function editCard($param, $cardId)
	{

		if(empty($param))
		{
			return false;
		}
		$codes = array();
		$types = array();
		$values = array();
		foreach($param as $key => $value)
		{
			$codes[] = $key . '=?';
			$types[] = $value[0];
			$values[] = $value[1];
		}
		$types[] = 'i';
		$values[] = $cardId;
		$sql = "UPDATE $this->tableName SET " . implode(',', $codes) . " WHERE pc_id = ?";
		return $this->update($sql, implode('', $types), $values);
	}

	public function deleteCard($cardId)
	{
		$sql = "DELETE FROM $this->tableName WHERE pc_id = ?";
		return $this->delete($sql, 'i', array($cardId));
	}

	public function getOneCard($cardId)
	{
		$sql = "SELECT pc_id AS cardId , pc_ename_id AS enameId, pc_shop_name AS shopName, pc_type AS type, pc_public AS isPublic, pc_status AS status, 
			pc_recommend AS isRecommend, pc_real_name AS realName, pc_nic_name AS nickname, pc_job AS job, pc_title AS title, pc_address AS address, pc_domain AS domain, 
			pc_site AS site, pc_weibo AS weibo, pc_domain_success AS domainSuccess, pc_pic AS pic, pc_qq AS qq, pc_phone AS phone, pc_introduction AS introduction,
			pc_public_phone AS isPhonePublic, pc_create_time AS createTime, pc_check_time AS checkTime, pc_rec_time AS recTime, pc_street AS street, pc_price AS price 
			FROM $this->tableName WHERE pc_id = ? order by createTime DESC";

		return $this->getRow($sql, 'i', array($cardId));
	}

}
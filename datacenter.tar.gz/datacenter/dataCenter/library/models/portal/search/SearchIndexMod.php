<?php
namespace models\portal\search;

use core\ModBase;
class SearchIndexMod extends ModBase
{

	private $tableName;

	function __construct($dbName = 'portal')
	{
		parent::__construct($dbName);
		$this->tableName = 'p_search_index';
	}

	public function getSeachIndex($keyword)
	{
		$sql = "SELECT si_id FROM $this->tableName WHERE si_keyword = ? AND si_expired_time > ?";
		return $this->getOne($sql, 'si', array($keyword,$_SERVER['REQUEST_TIME']));
	}

	public function addSearchIndex($data)
	{
		$keys = array();
		$codes = array();
		$types = array();
		$values = array();
		foreach($data as $key => $value)
		{
			if(!empty($value))
			{
				$keys[] = $key;
				$codes[] = '?';
				$types[] = $value[0];
				$values[] = $value[1];
			}
		}
		$sql = "INSERT INTO $this->tableName (" . implode(',', $keys) . ") VALUES (" . implode(',', $codes) . ")";
		return $this->add($sql, implode('', $types), $values);
	}
	
	public function getSeachIndexById($searchId)
	{
		$sql = "SELECT si_keyword,si_num,si_ids FROM $this->tableName WHERE si_id = ?";
		return $this->getRow($sql, 'i', array($searchId));
	}
}
<?php
namespace models\portal\category;

use core\ModBase;

class CategoryMod extends ModBase
{
	private $tableName;

	function __construct($dbName = 'portal')
	{
		parent::__construct($dbName);
		$this->tableName='p_category';
	}

	public function getCategoryCount($param)
	{
		if(empty($param))
		{
			return false;
		}
		$keys = array();
		$codes = array();
		$types = array();
		$values = array();
		foreach($param as $key => $value)
		{
			if(!empty($value))
			{
					$codes[] = $key . ' = ?';
					$types[] = $value[0];
					$values[] = $value[1];
			}
		}
		if(!empty($codes))
		{
			$sql = "SELECT COUNT(*) AS COUNT FROM $this->tableName WHERE ".implode(' AND ', $codes);
		}
		else
		{
			$sql = "SELECT COUNT(*) AS COUNT FROM $this->tableName " ;
		}
			
		$types =	implode('', $types);
		return $this->getRow($sql, $types, $values);
	}

	public function getList($offset,$pagesize,$param)
	{
		$keys = array();
		$codes = array();
		$types = array();
		$values = array();
		foreach($param as $key => $value)
		{
			if(!empty($value))
			{	
					$codes[] = $key . ' = ? ';
					$types[] = $value[0];
					$values[] = $value[1];
			}
		}
		
		$sql = "SELECT ca_id AS categoryId , ca_name AS name, ca_displayorder AS displayOrder, ca_url AS caUrl, ca_create_time AS createTime, 
		 ca_closed AS closed, ca_allow_nav AS allowNav, ca_allow_publish AS allowPublish, ca_allow_comment AS allowComment,
		ca_allow_summary AS allowSummary, ca_allow_index AS allowIndex FROM $this->tableName ";
		
		if(!empty($codes))
		{
			$sql .= " WHERE " . implode(' AND ', $codes) ;
		}
		
		$types =	implode('', $types);
		$types .= 'ii';
		$values[] = $offset;
		$values[] = $pagesize;
		$sql .= " ORDER BY ca_id desc  LIMIT ?,?";
	
 		return $this->select($sql, $types, $values);
	}

	public function addCategory($param)
	{
		if(empty($param))
		{
			return false;
		}
		$keys = array();
		$codes = array();
		$types = array();
		$values = array();
		$param['ca_create_time'] = array('i', $_SERVER['REQUEST_TIME']);
		foreach($param as $key => $value)
		{
			if(!empty($value))
			{
				$keys[] = $key;
				$codes[] = '?';
				$types[] = $value[0];
				$values[] = $value[1];
			}
		}
		$sql = "INSERT INTO $this->tableName (" . implode(',', $keys) . ") VALUES (" . implode(',', $codes) . ")";
		return $this->add($sql, implode('', $types), $values);
	}

	public function editCategory($param, $categoryId)
	{

		if(empty($param))
		{
			return false;
		}
		$codes = array();
		$types = array();
		$values = array();
		foreach($param as $key => $value)
		{
			if(!empty($value))
			{
				$codes[] = $key . '=?';
				$types[] = $value[0];
				$values[] = $value[1];
			}
		}
		$types[] = 'i';
		$values[] = $categoryId;
		$sql = "UPDATE $this->tableName SET " . implode(',', $codes) . " WHERE ca_id = ?";
		return $this->update($sql, implode('', $types), $values);
	}

	public function deleteCategory($categoryId)
	{
		$sql = "DELETE FROM $this->tableName WHERE ca_id = ?";
		return $this->delete($sql, 'i', array($categoryId));
	}

	public function getOneCategory($categoryId)
	{
		$sql = "SELECT ca_id AS categoryId, ca_name AS name, ca_displayorder AS displayOrder, ca_url AS caUrl, ca_create_time AS createTime,
		  ca_closed AS closed, ca_allow_nav AS allowNav, ca_allow_publish AS allowPublish, 
			ca_allow_comment AS allowComment, ca_allow_summary AS allowSummary, ca_allow_index AS allowIndex FROM $this->tableName WHERE ca_id = ?";

		return $this->getRow($sql, 'i', array($categoryId));
	}

}
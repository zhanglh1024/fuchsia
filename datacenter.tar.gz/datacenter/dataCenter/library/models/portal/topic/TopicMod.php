<?php
namespace models\portal\topic;

use core\ModBase;
class TopicMod extends ModBase
{

	private $tableName;

	function __construct($dbName = 'portal')
	{
		parent::__construct($dbName);
		$this->tableName = 'p_topic';
	}

	public function getTopicCount($param, $bigPicNotNull)
	{
		$keys = array();
		$codes = array();
		$types = array();
		$values = array();
		foreach($param as $key => $value)
		{
			if(!empty($value))
			{
				if($key == 'to_show_index' || $key == 'to_title')
				{
					$codes[] = $key . ' LIKE ?';
					$types[] = $value[0];
					$values[] = "%" . $value[1] . "%";
					continue;
				}
				$codes[] = $key . ' = ?';
				$types[] = $value[0];
				$values[] = $value[1];
			}
		}
		if(!empty($bigPicNotNull))
		{
			$codes[] = "to_big_pic <> ''";
		}
		$sql = "SELECT COUNT(*) AS COUNT FROM $this->tableName";
		if(!empty($codes))
		{
			$sql .= " WHERE " . implode(' AND ', $codes);
		}
		
		return $this->getOne($sql, implode('', $types), $values);
	}

	public function getList($offset, $pagesize, $param, $bigPicNotNull)
	{
		$keys = array();
		$codes = array();
		$types = array();
		$values = array();
		foreach($param as $key => $value)
		{
			if(!empty($value))
			{
				if($key == 'to_show_index' || $key == 'to_title')
				{
					$codes[] = $key . ' LIKE ?';
					$types[] = $value[0];
					$values[] = "%" . $value[1] . "%";
					continue;
				}
				$codes[] = $key . ' = ?';
				$types[] = $value[0];
				$values[] = $value[1];
			}
		}
		if(!empty($bigPicNotNull))
		{
			$codes[] = "to_big_pic <> ''";
		}
		$sql = "SELECT to_id AS topicId , to_title AS title, to_url AS toUrl,to_summary AS summary, to_pic AS pic,to_big_pic AS bigPic,
		to_show_index AS showIndex, to_status AS status, to_create_time AS createTime FROM $this->tableName";
		if(!empty($codes))
		{
			$sql .= " WHERE " . implode(' AND ', $codes);
		}
		$sql .= " ORDER BY to_create_time desc";
		$types = implode('', $types);
		if(!empty($pagesize))
		{
			$types .= 'ii';
			$values[] = $offset;
			$values[] = $pagesize;
			$sql .= " LIMIT ?,?";
		}
		return $this->select($sql, $types, $values);
	}

	public function addTopic($param)
	{
		if(empty($param))
		{
			return false;
		}
		$keys = array();
		$codes = array();
		$types = array();
		$values = array();
		$param['to_create_time'] = array('i', $_SERVER['REQUEST_TIME']);
		foreach($param as $key => $value)
		{
			if(!empty($value))
			{
				$keys[] = $key;
				$codes[] = '?';
				$types[] = $value[0];
				$values[] = $value[1];
			}
		
		}
		$sql = "INSERT INTO $this->tableName (" . implode(',', $keys) . ") VALUES (" . implode(',', $codes) . ")";
		return $this->add($sql, implode('', $types), $values);
	}

	public function editTopic($param, $toId)
	{
		if(empty($param))
		{
			return false;
		}
		$codes = array();
		$types = array();
		$values = array();
		foreach($param as $key => $value)
		{
			$codes[] = $key . '=?';
			$types[] = $value[0];
			$values[] = $value[1];
		
		}
		$types[] = 'i';
		$values[] = $toId;
		$sql = "UPDATE $this->tableName SET " . implode(',', $codes) . " WHERE to_id = ?";
		return $this->update($sql, implode('', $types), $values);
	}

	public function deleteTopic($topicId)
	{
		$sql = "DELETE FROM $this->tableName WHERE to_id = ?";
		return $this->delete($sql, 'i', array($topicId));
	}

	public function getOneTopic($topicId)
	{
		$sql = "SELECT to_id AS topicId , to_title AS title, to_url AS toUrl, to_summary AS summary, to_pic AS pic,to_big_pic AS bigPic,
		to_show_index AS showIndex, to_status AS status, to_create_time AS createTime FROM $this->tableName WHERE to_id = ?";
		
		return $this->getRow($sql, 'i', array($topicId));
	}
}
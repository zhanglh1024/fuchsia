<?php
namespace models\portal\articles;

use core\ModBase;

class ArticleAttachmentMod extends ModBase
{
	private $tableName;
	
	function __construct($dbName = 'portal')
	{
		parent::__construct($dbName);
		$this->tableName='p_article_attachment';
	}
	
	public function addAttachment($data)
	{
		$keys = array();
		$codes = array();
		$types = array();
		$values = array();
		foreach($data as $key => $value)
		{
			if(!empty($value))
			{
				$keys[] = $key;
				$codes[] = '?';
				$types[] = is_int($value) ? 'i' : 's';
				$values[] = $value;
			}
		}
		$sql = "INSERT INTO $this->tableName (" . implode(',', $keys) . ") VALUES (" . implode(',', $codes) . ")";
		return $this->add($sql, implode('', $types), $values);
	}
	
	public function getAttachment($atId, $aaId)
	{
		$sql = "SELECT aa_id as aaId,at_id as atId,aa_url as url,aa_file_type as fileType,aa_file_size as fileSize,aa_is_image as isImage FROM $this->tableName WHERE";
		if(!empty($atId))
		{
			$sql .= " at_id=?";
			$id = $atId;
		}
		elseif(!empty($aaId))
		{
			$sql .= " aa_id=?";
			$id = $aaId;
		}
		else
		{
			return array();
		}
		return $this->select($sql, 'i', array($id));
	}
	
	public function delAttachment($aaId)
	{
		$sql = "DELETE FROM $this->tableName WHERE aa_id = ?";
		return $this->delete($sql, 'i', array($aaId));
	}
	
	public function upAttachment($aaId, $atId)
	{
		$values = array($atId);
		$types = 'i';
		$codes = array();
		foreach($aaId as $value)
		{
			$values[] = $value;
			$types .= 'i';
			$codes[] = '?';
		}
		$sql = "UPDATE $this->tableName SET at_id = ? WHERE aa_id IN (" . implode(',', $codes) . ")";
		return $this->update($sql, $types, $values);
	}
}
<?php
namespace models\portal\articles;

use core\ModBase;
class ArticleTitleMod extends ModBase
{

	private $tableName;

	function __construct($dbName = 'portal')
	{
		parent::__construct($dbName);
		$this->tableName = 'p_article_title';
	}

	public function getArticleTitleCount($data)
	{
		$sqlData = $this->setSql($data);
		$sql = "SELECT COUNT(*) AS count FROM $this->tableName";
		if(!empty($sqlData['codes']))
		{
			$sql .= " WHERE " . implode(' AND ', $sqlData['codes']);
		}
		return $this->getOne($sql, implode('', $sqlData['types']), $sqlData['values']);
	}

	public function getArticleTitleList($data, $offset, $pagesize, $orderBy)
	{
		$sqlData = $this->setSql($data);
		$codes = $sqlData['codes'];
		$types = $sqlData['types'];
		$values = $sqlData['values'];
		$sql = "SELECT * FROM $this->tableName";
		if(!empty($codes))
		{
			$sql .= " WHERE " . implode(' AND ', $codes);
		}
		if(!empty($pagesize))
		{
			$sql .= " ORDER BY $orderBy LIMIT ?,?";
			$types[] = 'ii';
			$values[] = $offset;
			$values[] = $pagesize;
		}
		return $this->select($sql, implode('', $types), $values);
	}

	public function addArticleTitle($data)
	{
		$keys = array();
		$codes = array();
		$types = array();
		$values = array();
		foreach($data as $key => $value)
		{
			if(!empty($value))
			{
				$keys[] = $key;
				$codes[] = '?';
				$types[] = $value[0];
				$values[] = $value[1];
			}
		}
		$sql = "INSERT INTO $this->tableName (" . implode(',', $keys) . ") VALUES (" . implode(',', $codes) . ")";
		return $this->add($sql, implode('', $types), $values);
	}

	public function addArticleTrashTitle($data)
	{
		$keys = array();
		$codes = array();
		$types = array();
		$values = array();
		foreach($data as $key => $value)
		{
			$keys[] = $key;
			$codes[] = '?';
			$types[] = is_int($value)? 'i' :'s';
			$values[] = $value;
		}
		$sql = "INSERT INTO $this->tableName (" . implode(',', $keys) . ") VALUES (" . implode(',', $codes) . ")";
		return $this->add($sql, implode('', $types), $values);
	}

	public function updateArticleTitle($data, $atId)
	{
		$codes = array();
		$types = array();
		$values = array();
		foreach($data as $key => $value)
		{
			if(!empty($value))
			{
				if(in_array($key, array('at_com_num','at_view_num','at_credit')))
				{
					$codes[] = $key . "=$key+?";
					$types[] = $value[0];
					$values[] = $value[1];
					continue;
				}
				$codes[] = $key . '=?';
				$types[] = $value[0];
				$values[] = $value[1];
			}
		}
		$types[] = 'i';
		$values[] = $atId;
		$sql = "UPDATE $this->tableName SET " . implode(',', $codes) . " WHERE at_id = ?";
		return $this->update($sql, implode('', $types), $values);
	}

	public function getArticleTitleById($atId)
	{
		$atId = intval($atId);
		$sql = "SELECT * FROM {$this->tableName} WHERE at_id = {$atId}";
		return $this->getRow($sql, '', array());
	}
	
	public function getArticleTitleByTid($tid)
	{
		$sql = "SELECT at_id FROM $this->tableName WHERE at_tid = ?";
		return $this->getOne($sql, 'i', array($tid));
	}

	public function getArticleTitleByIds($ids, $limit = '')
	{
		$codes = array();
		$values = array();
		$types = array();
		foreach($ids as $value)
		{
			$codes[] = '?';
			$values[] = $value;
			$types[] = 'i';
		}
		$sql = "SELECT at_create_time,ca_id,at_short_title,at_title_style,at_id,at_title FROM $this->tableName WHERE at_id in (" .
			 implode(',', $codes) . ") AND at_status = 0 ORDER BY at_create_time DESC";
		if(!empty($limit))
		{
			$sql .= ' LIMIT ' . $limit;
		}
		return $this->select($sql, implode('', $types), $values);
	}

	public function getSearchArticleByIds($ids, $orderBy, $sort)
	{
		$codes = array();
		$values = array();
		$types = '';
		foreach($ids as $value)
		{
			$codes[] = '?';
			$values[] = $value;
			$types .= 'i';
		}
		$time = $_SERVER['REQUEST_TIME'];
		$sql = "SELECT ca_id,at_id,at_title,at_ename_id,at_summary,at_create_time,at_com_num,at_view_num,at_username FROM $this->tableName WHERE at_id in (" .
			 implode(',', $codes) . ") AND at_create_time < $time AND at_status = 0 ORDER BY $orderBy $sort";
		return $this->select($sql, $types, $values);
	}

	public function delArticleTitleById($atId)
	{
		$sql = "DELETE FROM $this->tableName WHERE at_id = ?";
		return $this->delete($sql, 'i', array($atId));
	}

	public function getSearchArticle($keyword)
	{
		$keywords = explode(' ', $keyword);
		$titleValues = array();
		$summaryValues = array();
		$values = array();
		$types = '';
		$codesTitle = array();
		$codesSummary = array();
		foreach($keywords as $value)
		{
			if(!empty($value))
			{
				$titleValues[] = '%' . $value . '%';
				$summaryValues[] = '%' . $value . '%';
				$codesTitle[] = 'at_title LIKE ?';
				$codesSummary[] = 'at_summary LIKE ?';
				$types .= 'ss';
			}
		}
		$sql = "SELECT at_id FROM $this->tableName WHERE at_status = 0 AND at_create_time < " . $_SERVER['REQUEST_TIME'] . " AND ((" . implode(' AND ', $codesTitle) .
			 ") OR (" . implode(' AND ', $codesSummary) . ")) ORDER BY at_create_time DESC";
		return $this->select($sql, $types, array_merge($titleValues, $summaryValues));
	}
	
	public function getArticleTitleMaxCount($params)
	{
		$where = array();
		$data = array();
		$bindType = '';
		$wherestr = '';
		if(isset($params['createTime']))
		{
			$where[] = 'at_create_time > ?';
			$bindType .= 'i';
			$data[] = $params['createTime'];
		}
		$where[] = 'at_create_time < ?';
		$bindType .= 'i';
		$data[] = $_SERVER['REQUEST_TIME'];
		$where[] = 'at_ios_tag = ?';
		$bindType .= 'i';
		$data[] = 1;
		$where[] = "at_ios_new_img <> ''";
		$wherestr = " where " . implode(' and ', $where);
		return $this->select("select count(*) as sum from " . $this->tableName . $wherestr, $bindType, $data,true);
	}
	
	public function getArticleTitleMaxInfo()
	{
		$where = " where at_ios_tag = ? and at_create_time < ? and at_ios_new_img <> ''";
		return $this->select("select at_title as title,at_create_time as createTime,at_id as atId from " . $this->tableName . $where . " order by at_create_time desc limit 1 " , 'ii', array(1,$_SERVER['REQUEST_TIME']), true);
	}

	public function getIndexPublish($tag, $limit)
	{
		$sql = "SELECT PC.pc_id AS cardId,PC.pc_type AS cardType,PC.pc_shop_name AS shopName,PC.pc_real_name AS realName,
		PC.pc_nic_name AS nicName,AT.at_id AS atId,AT.ca_id AS caId,AT.at_create_time as createTime,AT.at_title AS title,AT.at_short_title AS shortTitle,AT.at_ename_id AS enameId,AT.at_title_style AS titleStyle FROM
		 $this->tableName AS AT LEFT JOIN p_card AS PC ON(AT.at_ename_id = PC.pc_ename_id) 
		WHERE AT.at_ename_id <> '' AND AT.at_status = 0 AND AT.at_username NOT IN('编辑整理', '唐小宁', '虫儿飞', 'ename') AND PC.pc_nic_name <> '' AND PC.pc_status = 1 AND (AT.at_tag & ?) = ? AND AT.at_create_time < ".$_SERVER['REQUEST_TIME']." ORDER BY AT.at_create_time DESC LIMIT ?";
		return $this->select($sql, 'iii', array($tag,$tag,$limit));
	}
	
	private function setSql($data)
	{
		$codes = array();
		$types = array();
		$values = array();
		foreach($data as $key => $value)
		{
			if(!empty($value))
			{
				if(in_array($key, array('at_title','at_author','at_summary','at_username')))
				{
					$codes[] = $key . ' LIKE ?';
					$types[] = $value[0];
					$values[] = '%' . $value[1] . '%';
					continue;
				}
				if($key == 'at_tag')
				{
					$codes[] = "($key & $value[1]) = ?";
					$types[] = $value[0];
					$values[] = $value[1];
					continue;
				}
				if($key == 'orTag'){
					$str = '';
					foreach ($value as $v){
						$str .= "(at_tag & $v[1]) = ? or";
						$types[] = $v[0];
						$values[] = $v[1];
					}
					$codes[] = rtrim($str,'or');
					continue;
				}
				if($key == 'at_create_time')
				{
					$f = substr($value[1], 0, 4) == '&gt;' ? '>' : '<';
					$val = substr($value[1], 0, 4) == '&gt;' ? substr($value[1], 4) : $value[1];
					$codes[] = "at_create_time " . $f . " ?";
					$types[] = $value[0];
					$values[] = $val;
					continue;
				}
				if($key == 'ca_id')
				{
					$codes[] = "ca_id in (" . implode(',', array_map('intval', $value)) . ")";
					continue;
				}
				if($key == 'noIds')
				{
					foreach($value as $atId)
					{
						$codes[] = 'at_id <> ?';
						$types[] = 'i';
						$values[] = $atId;
					}
					continue;
				}
				if($key == 'idLess')
				{
					$codes[] = 'at_id < ?';
					$types[] = 'i';
					$values[] = $value;
					continue;
				}
				if($key == 'idThan')
				{
					$codes[] = 'at_id > ?';
					$types[] = 'i';
					$values[] = $value;
					continue;
				}
				if($key == 'noUser')
				{
					foreach($value as $username)
					{
						$codes[] = 'at_username <> ?';
						$types[] = 's';
						$values[] = $username;
					}
					continue;
				}
				if($key == 'enameIdNotNull')
				{
					$codes[] = "at_ename_id <> ''";
					break;
				}
				if($key == 'iosNewImgNotNull')
				{
					$codes[] = "at_ios_new_img <> ''";
					break;
				}
				if($key == 'iosTopImgNotNull')
				{
					$codes[] = "at_ios_top_img <> ''";
					break;
				}
				if($key == 'zxImgNotNull')
				{
					$codes[] = "at_zx_img <> ''";
						break;
				}
				if($key == 'hdImgNotNull')
				{
					$codes[] = "at_hd_img <> ''";
					break;
				}
				if($key == 'comNumNotNull')
				{
					$codes[] = "at_com_num > 0";
					break;
				}
				if($key == 'atIds')
				{
					$codes[] = "at_id in (" . implode(',', array_map('intval', $value)) . ")";
					continue;
				}
				if($key == 'caIds')
				{
					$codes[] = "ca_id in (" . implode(',', array_map('intval', $value)) . ")";
					continue;
				}
				$codes[] = $key . '=?';
				$types[] = $value[0];
				$values[] = $value[1];
			}
		}
		return array('codes' => $codes, 'values' => $values, 'types' => $types);
	}
	
	public function deleteTitleByTid($aid)
	{
		$sql = "UPDATE {$this->tableName} SET at_tid='' WHERE at_id=? LIMIT 1";
		
		$this->update($sql, 'i', array($aid));
	}
	
	public function createTheadUpdateTitle($aid, $tid)
	{
		$sql = "UPDATE {$this->tableName} SET at_tid=? WHERE at_id=? LIMIT 1";
	
		$this->update($sql, 'ii', array($tid, $aid));
	}
}
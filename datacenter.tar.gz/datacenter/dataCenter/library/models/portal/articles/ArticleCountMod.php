<?php
namespace models\portal\articles;

use core\ModBase;

class ArticleCountMod extends ModBase
{
	private $tableName;
	
	function __construct($dbName = 'portal')
	{
		parent::__construct($dbName);
		$this->tableName='p_article_count';
	}
	
	public function delArticleCount($atId)
	{
		$sql = "DELETE FROM $this->tableName WHERE at_id = ?";
		return $this->delete($sql, 'i', array($atId));
	}
	
	public function addArticleCount($atId, $caId)
	{
		$sql = "INSERT INTO $this->tableName (at_id,ca_id) VALUES (?,?)";
		return $this->add($sql, 'ii', array($atId, $caId));
	}
	
	public function getArticleCountById($atId, $caId)
	{
		$sql = "SELECT ao_id FROM $this->tableName WHERE at_id = ? AND ca_id = ?";
		return $this->getRow($sql, 'ii', array($atId, $caId));
	}
	
	public function updateArticleCount($data, $atId)
	{
		$codes = array();
		$types = array();
		$values = array();
		foreach($data as $key => $value)
		{
			if($key == 'ca_id')
			{
				$codes[] = $key . '=?';
				$types[] = $value[0];
				$values[] = $value[1];
				continue;
			}
			$codes[] = $key . '=' . $key . '+?';
			$types[] = $value[0];
			$values[] = $value[1];
		}
		$types[] = 'i';
		$values[] = $atId;
		$sql = "UPDATE $this->tableName SET " . implode(',', $codes) . " WHERE at_id = ?";
		return $this->update($sql, implode('', $types), $values);
	}
	
	public function getArticleCountCount()
	{
		$sql = "SELECT COUNT(*) FROM $this->tableName";
		return $this->getOne($sql, '', array());
	}
	
	public function getArticleCountList($sort, $offset, $pagesize)
	{
		$sql = "SELECT * FROM $this->tableName ORDER BY $sort LIMIT ?,?";
		return $this->select($sql, 'ii', array($offset, $pagesize));
	}
}
<?php
namespace models\portal\articles;

use core\ModBase;

class ArticleTrashMod extends ModBase
{
	private $tableName;
	
	function __construct($dbName = 'portal')
	{
		parent::__construct($dbName);
		$this->tableName='p_article_trash';
	}
	
	public function addArticleTrash($info)
	{
		$sql = "INSERT INTO $this->tableName (ar_content) VALUES (?)";
		return $this->add($sql, 's', array($info));
	}
	
	public function delArticleTrash($trashId)
	{
		$sql = "DELETE FROM $this->tableName WHERE ar_id = ?";
		return $this->delete($sql, 'i', array($trashId));
	}
	
	public function getArticleTrash($trashId)
	{
		$sql = "SELECT ar_content FROM $this->tableName WHERE ar_id = ?";
		return $this->getRow($sql, 'i', array($trashId));
	}
	
	public function getArticleTrashCount()
	{
		$sql = "SELECT COUNT(*) AS count FROM $this->tableName";
		return $this->getOne($sql, '', array());
	}
	
	public function getArticleTrashList($offset, $pagesize)
	{
		$sql = "SELECT * FROM $this->tableName ORDER BY ar_id DESC LIMIT ?,?";
		return $this->select($sql, 'ii', array($offset, $pagesize));
	}
}
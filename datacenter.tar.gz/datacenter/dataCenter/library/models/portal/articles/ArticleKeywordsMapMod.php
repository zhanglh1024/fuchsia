<?php
namespace models\portal\articles;

use core\ModBase;

class ArticleKeywordsMapMod extends ModBase
{
	private $tableName;
	
	function __construct($dbName = 'portal')
	{
		parent::__construct($dbName);
		$this->tableName='p_article_keywords_map';
	}
	
	public function addArticleKeywordsMap($akId, $atId)
	{
		$sql = "INSERT INTO $this->tableName (ak_id, at_id) VALUES (?, ?)";
		return $this->add($sql, 'ii', array($akId, $atId));
	}
	
	public function delArticleKeywordMap($atId)
	{
		$sql = "DELETE FROM $this->tableName WHERE at_id = ?";
		return $this->delete($sql, 'i', array($atId));
	}
	
	public function getArticleKeywordsMap($atId)
	{
		$sql = "SELECT ak_id FROM $this->tableName WHERE at_id = ?";
		return $this->select($sql, 'i', array($atId));
	}
	
	public function getArticleIdsByIds($ids, $limit='',$order='')
	{
		$codes = array();
		$types = '';
		$values = array();
		foreach($ids as $value)
		{
			$codes[] = '?';
			$types .= 'i';
			$values[] = (int)$value;
		}
		$sql = "SELECT distinct(at_id) FROM $this->tableName WHERE ak_id in (" . implode(',', $codes) . ")";
		if(!empty($order))
		{
			$sql .= ' ORDER BY '.$order;
		}
		if(!empty($limit))
		{
			$sql .= ' LIMIT ' . $limit;
		}
		return $this->select($sql, $types, $values);
	}
}
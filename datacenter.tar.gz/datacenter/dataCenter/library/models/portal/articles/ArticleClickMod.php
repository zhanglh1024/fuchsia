<?php
namespace models\portal\articles;

use core\ModBase;

class ArticleClickMod extends ModBase
{
	private $tableName;
	
	function __construct($dbName = 'portal')
	{
		parent::__construct($dbName);
		$this->tableName='p_article_click';
	}
	
	public function addArticleClick($data)
	{
		$keys = array();
		$codes = array();
		$types = array();
		$values = array();
		foreach($data as $key => $value)
		{
			if(!empty($value))
			{
				$keys[] = $key;
				$codes[] = '?';
				$types[] = is_int($value) ? 'i' : 's';
				$values[] = $value;
			}
		}
		$sql = "INSERT INTO $this->tableName (" . implode(',', $keys) . ") VALUES (" . implode(',', $codes) . ")";
		return $this->add($sql, implode('', $types), $values);
	}
	
	public function getArticleClickById($atId, $enameId, $username)
	{
		$sql = "SELECT * FROM $this->tableName WHERE at_id = ? AND";
		if(!empty($enameId))
		{
			$sql .= " ai_ename_id = ?";
			$values = array($atId, $enameId);
			$types = 'ii';
		}
		else 
		{
			$sql .= " ai_username = ?";
			$values = array($atId, $username);
			$types = 'is';
		}
		return $this->getRow($sql, $types, $values);
	}
	
	public function getArticleClick($atId, $limit)
	{
		$sql = "SELECT * FROM $this->tableName WHERE at_id = ? AND ai_ename_id <> '' ORDER BY ai_id DESC LIMIT ?";
		return $this->select($sql, 'ii', array($atId, $limit));
	}
}
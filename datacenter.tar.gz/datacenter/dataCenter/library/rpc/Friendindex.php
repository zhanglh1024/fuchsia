<?php
namespace rpc;

use core\RpcResponse;
use logic\manage\information\FriendIndexLogic;

/**
 * app4.0 首页
 */
class Friendindex 
{
	/**
	 * 获取app首页新消息流
	 */
	public function getFriendIndex($params = array())
	{
		try
		{
			$friendIndexLogic = new FriendIndexLogic();
			$result = $friendIndexLogic->getFriendIndex($params);
			if($result['flag'])
			{
				return RpcResponse::success($result['msg']);
			}
			return RpcResponse::msg($result['msg']);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
}
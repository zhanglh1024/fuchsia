<?php
namespace rpc;
use core\RpcResponse;
use core\Response;

/**
 * 域名交易
 */
class Domaintrade
{ 
	/**
	 * 批量获取域名信息
	 *
	 * @param array $domains
	 */
	public function getDomainInfo($params)
	{
		try
		{
			$domains = $params['domains'];
			if(empty($domains))
			{
				throw new \Exception('域名错误', 360001);
			}
			$domainTradeLogic = new \logic\manage\domain\DomainTradeLogic();
			$result = $domainTradeLogic->getDomainInfo($domains);
			return RpcResponse::success($result);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 查看域名是否可以交易  可以的话返回域名信息 不可以的话返回错误信息
	 */
	public function checkDomainInfo($params)
	{
		try
		{ 
			$domains = $params['domains'];
			if(empty($domains))
			{
				throw new \Exception('域名错误', 360001);
			}
			$domainTradeLogic = new \logic\manage\domain\DomainTradeLogic();
			return RpcResponse::success($domainTradeLogic->checkDomainInfo($domains));
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	public function qiangzhuInsert($params)
	{
		try
		{
			$domainTradeLogic = new \logic\manage\domain\DomainTradeLogic();
			if(empty($params) ||empty($params['domain'])||empty($params['registrarName']))
			{
				throw new \Exception('参数错误', 360001);
			}
			return RpcResponse::success($domainTradeLogic->domainInsertLogic($params));
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}		
	}
	

	/**
	 * 中介专用PUSH接口 code:0645
	 *
	 * @param array $data array('domain'=>,'oldId'=>,'newId'=>,'systemUserId'=>,'sysToMemo'=>,'ip'=>)
	 */
	public function domainPushForEname($data)
	{
		try
		{	
			$domains = new \interfaces\manage\Domains();
			$rs = $domains->domainPushForEname($data);
			if($rs)
			{
				return RpcResponse::success($rs);
			}
			return RpcResponse::error($rs);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 查看域名是否在易名
	 */
	public function getDomainIsUs($domain)
	{
		try
		{
			$dnManageLogic = new \logic\manage\domain\DomainManageLogic();
			$rs = $dnManageLogic->getDomainUs($domain);
			if($rs)
			{
				return RpcResponse::success($rs);
			}
			return RpcResponse::error($rs);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 经纪中介交易PUSH
	 */
	public function domainPushBroker($param)
	{
		try
		{
			$dnTradeLogic = new \logic\manage\domain\DomainTradeLogic();
			$rs = $dnTradeLogic->domainPushBroker($param['domain'], $param['status']);
			if($rs)
			{
				return RpcResponse::success($rs);
			}
			return RpcResponse::msg(Response::$errMsg,Response::$errCode);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取域名的enameId
	 */
	public function getDomainEnameId($domain)
	{
		try
		{
			$dnManageLogic = new \logic\manage\domain\DomainManageLogic();
			$rs = $dnManageLogic->getDomainEnameId($domain);
			if($rs)
			{
				return RpcResponse::success($rs);
			}
			return RpcResponse::error($rs);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取域名的过期时间 0630
	 */
	public function getDomainExpdate($domain)
	{
		try
		{
			$dnManageLogic = new \logic\manage\domain\DomainManageLogic();
			$rs = $dnManageLogic->getDomainExpdate($domain);
			if($rs)
			{
				return RpcResponse::success($rs);
			}
			return RpcResponse::error(Response::$errMsg);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
}
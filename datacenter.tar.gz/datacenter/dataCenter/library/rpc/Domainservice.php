<?php
namespace rpc;
use core\RpcResponse;

/**
 * e_domain_service_ext信息
 */
class Domainservice
{
	/**
	 * 获取域名记录信息
	 * @param domain 
	 * @param serviceType
	 * @param enameId
	 * @param order 排序
	 */
	public function getDomainService($data)
	{
		try
		{
			$dnServiceLogic = new \logic\manage\domain\DomainServiceLogic();
			$result = $dnServiceLogic->getDomainService($data);
			if($result)
			{
				return RpcResponse::success($result);
			}
			return RpcResponse::msg();
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取域名记录信息
	 * @param domain
	 * @param serviceType
	 * @param enameId
	 * @param order 排序
	 */
	public function getOneDomainService($data)
	{
		try
		{
			$dnServiceLogic = new \logic\manage\domain\DomainServiceLogic();
			$result = $dnServiceLogic->getDomainService($data, true);
			if($result)
			{
				return RpcResponse::success($result);
			}
			return RpcResponse::msg();
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取域名记录数量
	 * @param domain
	 * @param serviceType
	 * @param enameId
	 */
	public function getDomainServiceCount($data)
	{
		try
		{
			$dnServiceLogic = new \logic\manage\domain\DomainServiceLogic();
			$result = $dnServiceLogic->getDomainServiceCount($data);
			if($result)
			{
				return RpcResponse::success($result);
			}
			return RpcResponse::msg();
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 增加域名记录信息
	 * @param content
	 * @param domain
	 * @param serviceType
	 * @param adminId
	 * @param enameId
	 */
	public function addDomainService($data)
	{
		try
		{
			$dnServiceLogic = new \logic\manage\domain\DomainServiceLogic();
			$result = $dnServiceLogic->addDomainService($data);
			if($result)
			{
				return RpcResponse::success($result);
			}
			return RpcResponse::msg();
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
}
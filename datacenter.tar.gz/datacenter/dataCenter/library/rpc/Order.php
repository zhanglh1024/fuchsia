<?php
namespace rpc;
use core\RpcResponse;
 
/**
 * 订单接口
 */
class Order
{ 
	/**
	 * 处理订单：功能包含（批量取消订单,生成新订单,同时取消订单和更新订单）
	 */
	public function processOrder($params)
	{
		try
		{
			// 必要参数过滤
			if(empty($params['enameId']))
			{
				throw new \Exception('enameId有误!', 410201);
			}
			if(isset($params['price']) && $params['price'] < 0)
			{
				throw new \Exception('price必须大于0', 410202);
			}
			// 订单修改参数过滤
			if(!empty($params['orderId']))
			{
				if(empty($params['price']))
				{
					throw new \Exception('price参数错误', 410203);
				}
				if(empty($params['type']))
				{
					throw new \Exception('type错误', 410204);
				}
			}
			// 添加订单参数过滤
			if(empty($params['orderId']) && !empty($params['price']))
			{
				if(empty($params['type'])) 
				{
					throw new \Exception('type错误', 410204);
				}
				if(empty($params['domain']))
				{
					throw new \Exception('domain错误', 410205);
				}
			} 
			$logic = new \logic\manage\finance\NewOrderLogic();
			$result = $logic->processOrder($params);
			return RpcResponse::success($result);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 交易委托买入接口，更新冻结金额，创建新的订单
	 * 
	 * @var funType 1:更新金额和创建订单(默认） 2:更新备注
	 */
	public function entrustOrder($params)
	{
		try 
		{
			if(empty($params['enameId']))
			{
				throw new \Exception('enameId有误!', 410201);
			}
			if(empty($params['orderId']))
			{
				throw new \Exception('orderId有误', 410026);
			}
			//更新金额和创建订单的时候price和type必传
			if(empty($params['funType']) || $params['funType'] == 1)
			{
				if(empty($params['price']) || $params['price'] < 0)
				{
					throw new \Exception('price必须大于0', 410202);
				}
				if(empty($params['type']))
				{
					throw new \Exception('type错误', 410204);
				}
			}
			elseif($params['funType'] == 2)
			{
				if(empty($params['remark']) && empty($params['remarkHide']))
				{
					throw new \Exception('传入的参数错误', 410043);
				}
			}
			$logic = new \logic\manage\finance\NewOrderLogic();
			$result = $logic->entrustOrder($params);
			return RpcResponse::success($result);
		}
		catch (\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 批量扣款(0405)--经纪后台
	 * @param array $params
	 * @param int $EnameId
	 * @param array $AllMoney=>('p'=>'20','u'=>'30','w'=>'20')
	 * @param array $MoneyList=>('中介费'=>'10','税点'=>'10','转入费'=>'20')
	 * @param array $MoneyListRemark=>('中介费'=>'10','税点'=>'10','转入费'=>'20')
	 */
	public function batchSubMoney($params)
	{
		try
		{
			if(!isset($params['UniqueId']) or empty($params['UniqueId']))
			{
				throw new \Exception('参数错误:UniqueId!', '410043');
			}
			if(!isset($params['Type']) or empty($params['Type']))
			{
				throw new \Exception('参数错误:Type!', '410043');
			}
			if(!isset($params['EnameId']) or empty($params['EnameId']))
			{
				throw new \Exception('参数错误:EnameId!', '410043');
			}
			if(!isset($params['AllMoney']) or !is_array($params['AllMoney']))
			{
				throw new \Exception('参数错误:AllMoney!', '410043');
			}
			if(!isset($params['MoneyList']) or !is_array($params['MoneyList']))
			{
				throw new \Exception('参数错误:MoneyList!', '410043');
			}
			if(!isset($params['AllMoney']['p']) or !isset($params['AllMoney']['u']) or !isset($params['AllMoney']['w']))
			{
				throw new \Exception('传入的金额参数不正确', '410041');
			}
			$logic = new \logic\manage\finance\NewOrderLogic();
			$result = $logic->batchSubMoney($params);
			return RpcResponse::success($result);
		}
		catch(\Exception $e)
		{
			$finLogLib = new \lib\manage\finance\FinanceLogLib();
			$finLogLib->log('批量扣款失败', $params, array($e->getCode(), $e->getMessage()));
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 批量入款（0406）--经纪后台
	 * @param int $enameId
	 * @author hush by 2012-06-27
	 */
	public function batchAddMoney($params)
	{
		try
		{
			if(!isset($params['UniqueId']) or empty($params['UniqueId']))
			{
				throw new \Exception('参数错误:UniqueId!', '410043');
			}
			if(!isset($params['Type']) or empty($params['Type']))
			{
				throw new \Exception('参数错误:Type!', '410043');
			}
			if(!isset($params['EnameId']) or empty($params['EnameId']))
			{
				throw new \Exception('参数错误:EnameId!', '410043');
			}
			if(!isset($params['AllMoney']) or !is_array($params['AllMoney']))
			{
				throw new \Exception('参数错误:AllMoney!', '410043');
			}
			if(!isset($params['MoneyList']) or !is_array($params['MoneyList']))
			{
				throw new \Exception('参数错误:MoneyList!', '410043');
			}
			if(!isset($params['AllMoney']['p']) or !isset($params['AllMoney']['u']) or !isset($params['AllMoney']['w']))
			{
				throw new \Exception('传入的金额参数不正确', '410041');
			}
			$logic = new \logic\manage\finance\NewOrderLogic();
			$result = $logic->batchAddMoney($params);
			return RpcResponse::success($result);
		}
		catch(\Exception $e)
		{
			$finLogLib = new \lib\manage\finance\FinanceLogLib();
			$finLogLib->log('批量入款失败', $params, array($e->getCode(), $e->getMessage()));
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
}
<?php
namespace rpc;

use core\RpcResponse;
use core\Response;
class Finance
{
	/**
	 * 域名分销入款接口，默认不可提现
	 * @param int $enameId
	 * @param float $price
	 * @param int $type
	 */
	public function addMoney($data)
	{
		try
		{
			$userLogic = new \logic\manage\finance\FinanceLogic();
			$rs = $userLogic->manualRecharge((object) $data);
			if($rs)
			{
				return RpcResponse::success();
			}
			return RpcResponse::msg();
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 获取用户财务信息
	 * @param int $enameId
	 */
	public function getUserFinance($enameId)
	{
		try
		{
			$finLogic = new \logic\manage\finance\FinanceLogic();
			$rs = $finLogic->getUserFinance($enameId);
			if($rs)
			{
				return RpcResponse::success($rs);
			}
			return RpcResponse::msg(Response::$errMsg,Response::$errCode);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 返款列表
	 */
	public function getRepayMentList($data)
	{
		try
		{
			if(empty($data))
			{
				throw new \Exception('参数错误', 360001);
			}
			$logic = new \logic\manage\thrift\FinanceLogic();
			$result = $logic->getRepayMentList($data);
			if($result)
			{
				return RpcResponse::success($result);
			}
			return RpcResponse::msg();
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 还款操作
	 */
	public function repayment($data)
	{
		try
		{
			if(empty($data['enameId']) || empty($data['fcId']))
			{
				throw new \Exception('参数错误', 360001);
			}
			$logic = new \logic\manage\thrift\FinanceLogic();
			$result = $logic->repayment($data['enameId'], $data['fcId']);
			if($result)
			{
				return RpcResponse::success($result);
			}
			return RpcResponse::msg();
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 用户还款信息
	 */
	public function getCreditRepayInfo($enameId)
	{
		try
		{
			if(empty($enameId))
			{
				throw new \Exception('参数错误', 360001);
			}
			$logic = new \logic\manage\thrift\FinanceLogic();
			$result = $logic->getCreditNotRepayInfos($enameId);
			if($result)
			{
				return RpcResponse::success($result);
			}
			return RpcResponse::msg();
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
}
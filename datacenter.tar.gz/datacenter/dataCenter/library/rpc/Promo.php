<?php
namespace rpc;

use core\RpcResponse;
use core\Response;

class Promo
{
	/**
	 * 后台优惠券收入统计
	 */
	public function getPromoListByMonth($month = '')
	{
		try
		{
			$promoLogic = new \logic\manage\finance\PromoLogic();
			$rs = $promoLogic->getAdminPromoStatLogic($month);
			return RpcResponse::success($rs);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 发放优惠券
	 */
	public function addPromoCode($data)
	{
		try
		{
			$promoLogic = new \logic\manage\finance\PromoLogic();
			$rs = $promoLogic->addPromoLogic((object)$data);
			if($rs)
			{
				return RpcResponse::success($rs);
			}
			return RpcResponse::msg(Response::getErrMsg(), Response::getErrCode());
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取已使用的优惠码
	 * @param promoTypeId
	 * @param enameId
	 * @param beginUsedDate
	 * @param endUsedDate
	 */
	public function getUsedPromoCode($data)
	{
		try
		{
			$promoLogic = new \logic\manage\finance\PromoLogic();
			$rs = $promoLogic->getUsedPromoCode((object)$data);
			if($rs)
			{
				return RpcResponse::success($rs);
			}
			return RpcResponse::msg(Response::getErrMsg(), Response::getErrCode());
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取优惠券列表
	 * @param promoTypeId
	 * @param enameId
	 * @param promoStatus
	 * @param offset
	 * @param num
	 */
	public function getPromoList($data)
	{
		try
		{
			$promoLogic = new \logic\manage\finance\PromoLogic();
			$rs = $promoLogic->getPromoList((object)$data);
			return RpcResponse::success($rs);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
}
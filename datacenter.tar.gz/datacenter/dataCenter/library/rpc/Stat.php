<?php
namespace rpc;

use core\RpcResponse;

class Stat
{
	/**
	 * 预收款总额统计更新
	 */
	public function updatePrepayTotal($data)
	{
		try
		{
			$generalLogic = new \logic\manage\finance\FinanceGeneralLogic();
			$result = $generalLogic->updatePrepayTotal($data);
			return RpcResponse::success($result);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取财务新表流水信息
	 * 预收款分类详情专用
	 */
	public function getFinanceList($data)
	{
		try
		{
			$generalLogic = new \logic\manage\finance\FinanceGeneralLogic();
			$result = $generalLogic->getFinanceList($data);
			return RpcResponse::success($result);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
}
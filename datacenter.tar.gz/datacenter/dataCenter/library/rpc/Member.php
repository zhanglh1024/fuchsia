<?php
namespace rpc;
use core\RpcResponse;
use core\Response;
class Member
{

	/**
	 * 获取域名分销站内信列表
	 *
	 * @param number $enameId
	 * @param number $status 3未读，4已读，5回收站
	 * @param number $messageType 99为域名分销
	 * @param number $pagenum
	 * @param number $pageSize
	 * @return array
	 */
	public function distriMsgList($data)
	{
		try
		{
			$userLogic = new \logic\manage\information\InformationLogic();
			$rs = $userLogic->distriMsgList($data['enameId'], $data['status'], $data['messageType'], 
				empty($data['pagenum']) ? 0 : $data['pagenum'], empty($data['pageSize']) ? 0 : $data['pageSize']);
			if($rs['flag'])
			{
				return RpcResponse::success($rs['msg']);
			}
			return RpcResponse::msg($rs['msg']);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取域名分销站内信详情并设置已读
	 *
	 * @param int $messageId
	 * @return array
	 */
	public function getDistriMsg($data)
	{
		try
		{
			$userLogic = new \logic\manage\information\InformationLogic();
			$rs = $userLogic->getDistriMsg($data['messageId'], $data['enameId']);
			if($rs['flag'])
			{
				return RpcResponse::success($rs['msg']);
			}
			return RpcResponse::msg($rs['msg']);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 域名分销设置站内信
	 *
	 * @param int $messageId
	 * @return array
	 */
	public function setDistriMsg($data)
	{
		try
		{
			$userLogic = new \logic\manage\information\InformationLogic();
			$rs = $userLogic->setDistriMsg($data['messageId'], $data['enameId'], 
				!empty($data['status']) ? $data['status'] : 5);
			if($rs['flag'])
			{
				return RpcResponse::success($rs['msg']);
			}
			return RpcResponse::msg($rs['msg']);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 添加域名分销站内信
	 *
	 * @param int $enameId
	 * @param array $data 自定义content 和 titile必须
	 * @param string $templateId 域名分销自定义默认模板id distritutionAnyTpl
	 * @param number $type 域名分销站内信类型99
	 */
	public function addSiteMessage($data)
	{
		try
		{
			$smsLogic = new \logic\manage\queue\SmsLogic();
			$rs = $smsLogic->sendSiteMsg($data['enameId'], 
				empty($data['templateId']) ? 'distritutionAnyTpl' : $data['templateId'], $data['data'], 
				empty($data['type']) ? 99 : $data['type'], 3);
			if($rs)
			{
				return RpcResponse::success();
			}
			return RpcResponse::msg();
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 域名分销发送邮件，传enameid接口自己获取用户邮箱
	 *
	 * @param int $enameId
	 * @param string $tplData 自定义content 和 titile必须
	 * @param string $email
	 * @param string $templateId 域名分销自定义默认模板id distritutionAnyTpl
	 * @param int $taskId
	 * @param string $function 默认sendmail即可
	 * @param int $priority 默认优先级4不直接发送
	 */
	public function sendEmail($sendData)
	{
		try
		{
			$queueLogic = new \logic\manage\newqueue\QueueLogic();
			$mailData = array('Function' => 'sendmail', 'EnameId' => $sendData['enameId'], 'TemplateName' => empty($sendData['templateId']) ? 'distritutionAnyTpl' : $sendData['templateId'], 'Target' => !empty($sendData['email']) ? $sendData['email'] : false, 'Data' => $sendData['tplData'], 'Priority' => empty($sendData['priority']) ? 4 : $sendData['priority']);
			$result = $queueLogic->addQueueNormal($mailData);
			if($result)
			{
				return RpcResponse::success();
			}
			return RpcResponse::msg();
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 传enameid传enameid接口自己获取用户手机号
	 *
	 * @param string $enameId
	 * @return string phone
	 */
	public function getMemberPhone($enameId)
	{
		try
		{
			$memberLogic = new \logic\manage\member\UserMemberLogic();
			$memberInfo = $memberLogic->getMemberExtInfo($enameId, 'Mobile');
			if(!empty($memberInfo['Mobile']))
			{
				$phone = $memberInfo['Mobile'];
				return RpcResponse::success($phone);
			}
			return RpcResponse::msg('用户信息获取失败');
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}

	public function getUserEmail($enameId)
	{
		try
		{
			$memberLogic = new \logic\manage\member\UserMemberLogic();
			$memberInfo = $memberLogic->getMemberInfo($enameId, 'Email');
			if(!empty($memberInfo['Email']))
			{
				return RpcResponse::success($memberInfo['Email']);
			}
			return RpcResponse::msg('用户邮件获取失败');
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取用户详细信息资料
	 */
	public function getMemberInfoByEnameId($enameId)
	{
		try
		{
			$memberLogic = new \logic\manage\member\UserMemberLogic();
			$memberInfo = $memberLogic->getMemberBaseInfo($enameId,
				'EnameId,Email,ChName,IsMobileVerified,UserGroup,IsEmailVerified,IsSetOperateProtect,IsIdentityVerified,IsCompanyVerified,IsBanned,IsGetTransferByMobile,GroupDueTime,AcceptType,PushAcceptType',
				'Mobile,ChCompanyName,Phone,PhoneC,FaxC,Fax');
			if($memberInfo['msg'] && $memberInfo['flag'])
			{
				return RpcResponse::success($memberInfo['msg']);
			}
			return RpcResponse::msg(Response::$errMsg, Response::$errCode);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 验证用户的认证邮箱 E+
	 *
	 * @param EnameId
	 * @param Email
	 */
	public function checkUserEmail($params)
	{
		try
		{
			$checkLogic = new \logic\manage\verify\VerifyLogic('email');
			$check = $checkLogic->queryEmailVerify($params['Email'], $params['EnameId']);
			if($check)
			{
				return RpcResponse::success('邮箱验证通过．');
			}
			return RpcResponse::msg('邮箱验证失败．');
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取vip用户和vip域名列表
	 * @param int $type 1:vip域名   2:vip用户  不传或其他：获取两者
	 */
	public function getVipListAll($type = 0)
	{
		try
		{
			$memberLogic = new \logic\manage\member\UserVipLogic();
			$result = $memberLogic->getVipListAll($type);
			return RpcResponse::success($result);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 通过EnameId获取用户头像
	 *
	 * @param $enameid
	 */
	public function getMemberAvatarByEnameId($enameId)
	{
		try
		{
			$memberLogic = new \logic\manage\member\UserMemberLogic();
			$memberInfo = $memberLogic->getMemberAvatar($enameId);
			if($memberInfo['msg'] && $memberInfo['flag'])
			{
				return RpcResponse::success($memberInfo['msg']);
			}
			return RpcResponse::msg(Response::$errMsg, Response::$errCode);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 根据EnameId得到关联EnameId
	 *
	 * @param string $enameId
	 */
	public function getLinkEnameId($enameId) 
	{
		try
		{
			if(empty($enameId))
			{
				throw new \Exception('参数错误', 360001);
			}
			$userMemberInfo = new \logic\manage\member\UserMemberLogic();
			$result = $userMemberInfo->getLinkEnameId($enameId);
			if($result)
			{
				return RpcResponse::success($result);
			}
			return RpcResponse::msg();
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
}

<?php
namespace rpc;

use core\RpcResponse;

class Product
{
	/**
	 * 手动更新美金汇率
	 */
	public function updateProductRate($rate)
	{
		try
		{
			$acLogic = new \logic\manage\product\ActivityLogic();
			$proRate = $acLogic->updateProductRate($rate);
			if($proRate)
			{
				return RpcResponse::success();
			}
			return RpcResponse::error('product rate update fail');
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取美金汇率
	 */
	public function getProductRate()
	{
		try
		{
			$acLogic = new \logic\manage\product\ActivityLogic();
			$proRate = $acLogic->getProductRate();
			return RpcResponse::success($proRate);
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 添加产品活动
	 */
	public function addActivity($params)
	{
		try
		{
			$acLogic = new \logic\manage\product\ActivityLogic();
			$rs = $acLogic->addActivity($params);
			if($rs)
			{
				return RpcResponse::success($rs);
			}
			return RpcResponse::error('添加失败.');
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取产品活动数量
	 */
	public function getActivityCount($params)
	{
		try
		{
			$acLogic = new \logic\manage\product\ActivityLogic();
			$rs = $acLogic->getActivityCount($params);
			if($rs)
			{
				return RpcResponse::success($rs);
			}
			return RpcResponse::error('获取产品活动数量失败.');
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取产品活动列表
	 */
	public function getActivityList($params)
	{
		try
		{
			$acLogic = new \logic\manage\product\ActivityLogic();
			$rs = $acLogic->getActivityList($params);
			if($rs)
			{
				return RpcResponse::success($rs);
			}
			return RpcResponse::error('获取产品活动列表失败.');
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取产品活动信息
	 */
	public function getActivityInfo($params)
	{
		try
		{
			$acLogic = new \logic\manage\product\ActivityLogic();
			$rs = $acLogic->getActivityInfo($params);
			if($rs)
			{
				return RpcResponse::success($rs);
			}
			return RpcResponse::error('获取产品活动信息失败.');
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 修改产品活动
	 */
	public function setActivity($params)
	{
		try
		{
			$acLogic = new \logic\manage\product\ActivityLogic();
			$rs = $acLogic->setActivity($params);
			if($rs)
			{
				return RpcResponse::success($rs);
			}
			return RpcResponse::error('产品活动更新失败.');
		}
		catch(\Exception $e)
		{
			return RpcResponse::msg($e->getMessage(), $e->getCode());
		}
	}
	
}
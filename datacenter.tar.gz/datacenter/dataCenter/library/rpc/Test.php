<?php
namespace rpc;

class Test
{
	/**
	 * aaaaaa
	 * @return number
	 */
	public function abc()
	{
		$a = new \Common\Client();
		return $a->getIp();
	}
}
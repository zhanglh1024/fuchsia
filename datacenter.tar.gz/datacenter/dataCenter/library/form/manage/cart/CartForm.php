<?php
namespace form\manage\cart;
use core\form as form;
class CartForm
{
	/**
	 * 购物车结算数据
	 */
	public static function overCart()
	{
		$fs = array();
		$fs[] = new form\FormField('product', "POST", array(1,2400, '购物车数据错误'));
		$fs[] = new form\FormField('enameId', "POST", array(1, 99999999999, 'enameId错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('notRepeateRenew', "POST#", array(0, 1, '不重复续费标记错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('couponContent1', 'POST#', array(1, 32, '注册域名优惠券长度错误'));
		$fs[] = new form\FormField('couponContent2', 'POST#', array(1, 32, '续费域名优惠券长度错误'));
		$fs[] = new form\FormField('couponContent3', 'POST#', array(1, 32, '转入域名优惠券长度错误'));
		$fs[] = new form\FormField('password', 'POST#', array(1, 32, '用户密码不能为空', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('questionId', 'POST#', array(1, 32, '操作保护不能为空', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('answer', 'POST#', array(1, 32, '问题答案不能为空', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('phonecode', 'POST#', array(1, 32, '手机验证码不能为空', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, TRUE, TRUE);
	}
	
	/**
	 * 获取域名注册价格
	 */
	public static function getDomainPrice()
	{
		$fs[] = new form\FormField('domains', "GET", array(1, 7200, '域名长度错误'));
		$fs[] = new form\FormField('enameId', "GET", array(0, 99999999999, 'enameId错误'));
		$fs[] = new form\FormField('shopType', "GET", array(1, 10, '购物类型错误'));
		$fs[] = new form\FormField('ext', "GET", array(0, 100, '域名转入密码和dns错误'));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 获取购物车数量
	 */
	public static function getCartCount() 
	{
		$fs = array();
		$fs[] = new form\FormField('enameId', "GET", array(1, 99999999999, 'EnameId格式错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 *更新购物车
	 */
	public static function updateCartByShopId() 
	{
		$fs = array();
		$fs[] = new form\FormField('ShopId', "GET#", array(0, 99999999999, 'ShopId格式错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('DomainName', "GET#", array(0, 7200, '域名长度错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('EnameId', "GET", array(0, 99999999999, 'EnameId格式错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Ext', "GET#", array(0, 10, 'Ext格式错误', form\FormField::$VAR_STRING_ARRAY));
		form\FormParser::parse($fs, true);
	}
}

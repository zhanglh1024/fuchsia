<?php
namespace form\manage\promo;
use core\form as form;

class PromoForm
{
	/**
	 * 获取可使用的优惠券
	 */
	public static function getCouponlist()
	{
		$fs[] = new form\FormField('useType', "GET", array(0, 4, '操作类型错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('enameId', "GET", array(5, 11, 'enameID错误'));
		$fs[] = new form\FormField('promoStatus', "GET", array(0, 4, '查找类型错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pageNum', "GET", array(0, form\FormField::$MAX_INT, '页码错误'));
		$fs[] = new form\FormField('pageSize', "GET", array(0, form\FormField::$MAX_INT, '每页数量错误'));
		form\FormParser::parse($fs, true);
	}
	
	public static function getCouponCountApp()
	{
		$fs[] = new form\FormField('enameId', "GET", array(5, 11, 'enameID错误'));
		$fs[] = new form\FormField('promoStatus', "GET", array(1, 4, '查找类型错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('noticeDay', "GET", array(0, 100, '提醒天数错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * 获取用户的优惠券
	 */
	public static function getUserCouponListForm()
	{
		$fs[] = new form\FormField('useType', "GET", array(1, 3, '操作类型错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('enameId', "GET", array(5, form\FormField::$MAX_INT, 'enameID错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('promoType', "GET#", array(1, form\FormField::$MAX_INT, '优惠券类型ID',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('promoStatus', "GET#", array(1, 3, '查找类型错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 检查优惠券是否可以使用
	 */
	public static function checkCoupon()
	{
		$fs[] = new form\FormField('domains', "POST", array(4, 7200, '一次最多20个域名'));
		$fs[] = new form\FormField('enameId', "POST", array(5, 11, 'enameID错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('promoCode', "POST", array(10, 18, '优惠券错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('useType', "POST", array(1, 4, '类型错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('money', "POST", array(1, 1000, '购物总金额错误'));
		$fs[] = new form\FormField('year', "POST", array(1, 500, '域名年限错误'));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 获取优惠券信息
	 */
	public static function getCoupon()
	{
		$fs[] = new form\FormField('enameId', "GET", array(5, 11, 'enameID错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('promoId', "GET", array(0, form\FormField::$MAX_INT, '优惠券ID错误',
				form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * 获取优惠券信息
	 */
	public static function getCouponDetail()
	{
		$fs[] = new form\FormField('promoCode', "GET", array(0, 32, '优惠码错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	
	public static function getPromoCodeCount()
	{
		$fs[] = new form\FormField('promoTypeId', "GET#", array(0, form\FormField::$MAX_INT, '优惠券ID',	form\FormField::$VAR_INT));
		$fs[] = new form\FormField('enameId', "GET#", array(0, form\FormField::$MAX_INT, '用户id',	form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}

}

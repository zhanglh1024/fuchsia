<?php
namespace form\manage\verify;
use core\form\ReturnData;

use core\form as form;
class VerifyForm
{
	public static function checkListParam()
	{
		$fs = array();
		$fs[] = new form\FormField('verifyflag', "GET", array(1, 20, '认证标示有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pagenum', 'GET#', array(1, 9999, '分页格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pagesize', 'GET#', array(0, 9999, '页码格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('EnameId', 'GET', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Type', 'GET#', array(1, 3, '认证类型错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	public static function checkPassListParam()
	{
		$fs = array();
		$fs[] = new form\FormField('verifyflag', "GET", array(1, 5, '认证标示有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('EnameId', 'GET', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('type', 'GET#', array(1, 2, '获取类型有误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	public static function checkUserInfo()
	{
		$fs = array();
		$fs[] = new form\FormField('verifyflag', "GET", array(1, 20, '认证标示有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('EnameId', 'GET', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	public static  function checkEmailVerify()
	{
		$fs = array();
		$fs[] = new form\FormField('target',"POST",array(6,200,'邮箱长度有误!',form\FormField::$VAR_STRING),array('common\FormCheck::isEmail'=>'邮箱格式有误!'));
		$fs[] = new form\FormField('EnameId', 'POST', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('sendflag', 'POST#', array(0, 10, '发送类型有误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	public static  function checkCompanyVerify()
	{
		$fs[] = new form\FormField('EnameId', 'POST', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[]= new form\FormField( 'companyName',  'POST', array (1, 100, '企业名称',));
		$fs[]= new form\FormField( 'licenseImg',  'POST', array (1, 100, '图片路径有误',));
		$fs[]= new form\FormField( 'licenseType',  'POST', array (1,  2, '证件类型有误',form\FormField::$VAR_INT));
		$fs[]= new form\FormField( 'license',  'POST', array (5, 30, '证件号长度有误,5-30个字符', form\FormField::$VAR_STRING), array('common\FormCheck::checkCompanyLicense'=>'证件号格式错误'));
		form\FormParser::parse($fs,true);
	}
	public static function checkIdentityVerify()
	{
		$fs = array ();
		$fs[] = new form\FormField('firstName', 'POST', array (1, 32, '姓输入错误', form\FormField::$VAR_STRING ), array(
				'common\FormCheck::isChinese' => "请填写中文姓"));
		$fs[] = new form\FormField('lastName', 'POST', array (1, 32, '名输入错误',form\FormField::$VAR_STRING ), array(
				'common\FormCheck::isChinese' => "请填写中文名"));
		$fs[] = new form\FormField('idCard', 'POST', array (1, 19, '身份证号错误', form\FormField::$VAR_STRING ), array(
				'common\FormCheck::isIdentify' => "身份证号错误"));
		$fs[] = new form\FormField('idCard2', 'POST', array (1, 19, '重复身份证号错误', form\FormField::$VAR_STRING ));
		$fs[]= new form\FormField( 'identityimg',  'POST', array (1, 100, '图片路径有误',));
		$fs[] = new form\FormField('EnameId', 'POST', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Type', 'POST#', array(1, 3, '认证类型错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Address', 'POST#', array(1, 200, '联系地址错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('Company', 'POST#', array(1, 60, '联系单位错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('Phone', 'POST#', array(1, 20, '联系电话错误', form\FormField::$VAR_STRING));
		form\FormParser::parse ( $fs,true);
		if(ReturnData::$info->idCard != ReturnData::$info->idCard2)
		{
			throw new \Exception('两次输入的身份证号码不一致!');
		}
	}
	public static function checkfailureId()
	{
		$fs = array ();
		$fs[] = new form\FormField('verifyflag', "POST", array(1, 20, '认证标示有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField ('failureId',  "POST", array(1,form\Formfield::$MAX_INT,'ID错误',form\Formfield::$VAR_INT));
		$fs[] = new form\FormField ('failureName',  'POST', array(1, 255, '名称错误',form\ FormField::$VAR_STRING));
		$fs[] = new form\FormField('isUsed',  "POST", array(0, 1, '参数错误!',form\ FormField::$VAR_INT));
		$fs[] = new form\FormField('EnameId', 'POST', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('identify', "POST", array(1, 6, '操作保护标示有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('answer', 'POST#', array(1, 64, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pass', 'POST#', array(1, 32, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('questionId', 'POST#', array(0, 99999999, '问题类型选择有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('captcha', 'POST#', array(1, 99999999, '验证码长度有误', form\FormField::$VAR_INT), array(
				'common\FormCheck::isNumber' => '验证码格式有误'));
		$fs[] = new form\FormField('Type', 'POST#', array(1, 3, '认证类型错误', form\FormField::$VAR_INT));
		form\FormParser::parse ( $fs,TRUE );
	}

	public static function getTodoCount()
	{
		$fs = array();
		$fs[] = new form\FormField('type',"GET#",array(0,2,'类型有误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs,TRUE);
	}

	public static function queryIdentity()
	{
		$st = false;
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'cooper');
		if(in_array($_REQUEST['enameId'],explode(',', $conf->enameIdOther)) && \common\Common::getRequestUser() == 'apicom')
		{
			$st = true;
		}
		$fs = array();
		$fs[] = new form\FormField('enameId', 'POST', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('firstName', 'POST', array ($st ? 0 : 1, 32, '姓输入错误', form\FormField::$VAR_STRING ), array(
				'common\FormCheck::isChinese' => "请填写中文姓"));
		$fs[] = new form\FormField('lastName', 'POST', array ($st ? 0 : 1, 32, '名输入错误',form\FormField::$VAR_STRING ), array(
				'common\FormCheck::isChinese' => "请填写中文名"));
		$fs[] = new form\FormField('idCard', 'POST', array ($st ? 0 : 1, 19, '身份证号错误', form\FormField::$VAR_STRING ), array(
				'common\FormCheck::isIdentify' => "身份证号错误"));
		$fs[] = new form\FormField('Type', 'POST#', array(1, 3, '认证类型错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('id', 'POST#', array(0, form\FormField::$MAX_INT, '记录id错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs,TRUE);
	}

	public static function queryCompany()
	{
		$st = false;
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'cooper');
		if(in_array($_REQUEST['enameId'],explode(',', $conf->enameIdOther)) && \common\Common::getRequestUser() == 'apicom')
		{
			$st = true;
		}		
		$fs = array();
		$fs[] = new form\FormField('enameId', 'POST', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[]= new form\FormField( 'companyName',  'POST', array ($st ? 0 : 1, 100, '企业名称有误',form\FormField::$VAR_STRING));
		$fs[]= new form\FormField( 'licenseType',  'POST', array ($st ? 0 : 1,  2, '证件类型有误',form\FormField::$VAR_INT));
		$fs[]= new form\FormField( 'license',  'POST', array ($st ? 0 : 5, 30, '证件号长度有误,5-30个字符', form\FormField::$VAR_STRING), array('common\FormCheck::checkCompanyLicense'=>'证件号格式错误'));
		$fs[] = new form\FormField('id', 'POST#', array(0, form\FormField::$MAX_INT, '记录id错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs,true);
	}
	
	public static function queryDnbbs()
	{
		$fs = array();
		$fs[] = new form\FormField('enameId', 'get', array(1, form\FormField::$MAX_INT, 'EnameId格式有误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs,true);
	}
	
	public static function proxyInvoice()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', 'POST#', array(1, form\FormField::$MAX_INT, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Status', 'POST#', array(1, 6, 'Status有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('InvoiceTitle', "POST#", array(1, 60, '发票抬头有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('AdminId', "POST#", array(0, 60, '审核人错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('num', 'POST#', array(0,form\FormField::$MAX_INT,'分页有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Verifytime', 'POST#', array(0,20,'搜索时间错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('offset', 'POST#', array(0,form\FormField::$MAX_INT,'分页有误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}

	public static function addProxyInvoice()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', 'POST', 
			array(1, form\FormField::$MAX_INT, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Type', "POST", array(1, 2, '委托方选择出错', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('InvoiceTitle', "POST", array(1, 60, '发票抬头填写有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('ProxyFile', "POST", array(4, 65, '委托书有误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs,true);
	}
	
	public static function delProxyInvoice()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', 'POST',
			array(1, form\FormField::$MAX_INT, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('ID', 'POST',
			array(1, form\FormField::$MAX_INT, 'ID格式有误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs,true);
	}
	
	public static function getProxyInvoiceById()
	{
		$fs = array();
		$fs[] = new form\FormField('ID', 'POST',
			array(1, form\FormField::$MAX_INT, 'ID格式有误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs,true);
	}
	public static function updateProxyInvoiceById()  
	{
		$fs = array();
		$fs[] = new form\FormField('ID', 'POST', array(1, form\FormField::$MAX_INT, 'ID格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Status', 'POST#', array(1, 6, 'Status有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('AdminId', 'POST', 
			array(1, form\FormField::$MAX_INT, 'AdminId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Remark', "POST#", array(0, 200, '备注有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('Type', 'POST#', array(0, 2, 'Type有误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs,true);
	}
}

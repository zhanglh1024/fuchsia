<?php
namespace form\manage\verify;
use core\form\ReturnData;

use core\form as form;
class CustomerCountForm
{
	public static function addCustomerCount()
	{
		$fs = array();
		$fs[] = new form\FormField('vid', 'post', array(1, form\FormField::$MAX_INT, '认证id错误',));
		$fs[] = new form\FormField('vtype', 'post', array(1, 10, '认证类型错误'));
		$fs[] = new form\FormField('adminId', 'post', array(1, 30, 'adminId错误'));
		$fs[] = new form\FormField('verifyTime', 'post', array(5, 30, '认证时间错误'));
		form\FormParser::parse($fs, true);
	}

	public static function getCustomerCount()
	{
		$fs = array();
		$fs[] = new form\FormField('vid', 'post', array(0, form\FormField::$MAX_INT, '认证id错误',));
		$fs[] = new form\FormField('vtype', 'post', array(1, 10, '认证类型错误'));
		$fs[] = new form\FormField('adminId', 'post', array(0, 30, 'adminId错误'));
		$fs[] = new form\FormField('verifyTime', 'post', array(0, 30, '认证时间错误'));
		$fs[] = new form\FormField('limit', 'post', array(0, 30, 'limit参数错误'));
		form\FormParser::parse($fs, true);
	}
}

<?php 
namespace form\manage\member;
use core\form\ReturnData; 

use core\form as form;
class MemberForm
{
 
	public static function checkIdentify()
	{
		$fs[] = new form\FormField('identify', "GET", array(1, 6, '操作保护标识有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('EnameId', "GET", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('price', "GET#", array(1,form\FormField::$MAX_INT,'出价大小错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pushId', "GET#", array(1,form\FormField::$MAX_INT,'pushid错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('version', 'GET#', array(0, 99999999, 'version错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	public static function checkSendSms()
	{
		$fs[] = new form\FormField('smsconfig', "POST", array(1, 255, '验证码标识有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('EnameId', "POST", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('purpose', 'POST', array(1, 64, '验证码用途标识有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('Mobile', 'POST#', array(11, 11, '手机号码长度有误'), array('common\FormCheck::isMobile' => '手机参数有误'));
		form\FormParser::parse($fs, true);
	}
	public static function checkOperateProtectGet()
	{
		$fs[] = new form\FormField('identify', "GET", array(1, 6, '操作保护标识有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('EnameId', "GET", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('answer', 'GET#', array(1, 64, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pass', 'GET#', array(1, 32, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('questionId', 'GET#', array(0, 99999999, '问题类型选择有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('captcha', 'GET#', array(1, 99999999, '验证码长度有误', form\FormField::$VAR_INT), array(
				'common\FormCheck::isNumber' => '验证码格式有误'));
		form\FormParser::parse($fs, true);
	}
	public static function checkOperateProtectPost()
	{
		$fs[] = new form\FormField('identify', "POST", array(1, 6, '操作保护标识有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('EnameId', "POST", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('answer', 'POST#', array(1, 64, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pass', 'POST#', array(1, 32, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('questionId', 'POST#', array(0, 99999999, '问题类型选择有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('captcha', 'POST#', array(1, 99999999, '验证码长度有误', form\FormField::$VAR_INT), array(
				'common\FormCheck::isNumber' => '验证码格式有误')); 
		form\FormParser::parse($fs, true);
	}
	public static function checkEnameId()
	{
		$fs[] = new form\FormField('EnameId', "GET", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('searchId', "GET#", array(1, 99999999999, 'searchId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('flag', "GET#", array(0, 1, '类型有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('ver', "GET#", array(0, 10, '版本有误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	public static function checkGetEnameId()
	{
		$fs[] = new form\FormField('startid', "GET", array(0, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('endid', "GET", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	public static function setOperateProtection()
	{
		$fs = array();
		$fs[] = new form\FormField('questionId', 'POST', array(0, 64, '问题类型选择有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('question', 'POST#', array(1, 32, '自定义问题格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('answer', 'POST', array(1, 64, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('EnameId', 'POST', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	public static function checkOperateProtection()
	{
		$fs = array(); 
		$fs[] = new form\FormField('identify', "POST#", array(1, 6, '操作保护标识有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('onlycheck', "POST#", array(1, 1, '是否只是验证操作保护类型有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('EnameId', "POST", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('answer', 'POST#', array(1, 64, '密码格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pass', 'POST#', array(1, 32, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('questionId', 'POST#', array(0, 99999999, '问题类型选择有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('version', 'POST#', array(0, 99999999, 'version错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('captcha', 'POST#', array(1, 99999999, '验证码长度有误', form\FormField::$VAR_INT), array('common\FormCheck::isNumber' => '验证码格式有误'));
		form\FormParser::parse($fs, true);
	}
	public static function cancelOperateProtection()
	{
		$fs = array();
		$fs[] = new form\FormField('qid', 'POST', array(1, form\FormField::$MAX_INT, '未选择操作保护',
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('identify', "POST", array(1, 6, '操作保护标识有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('EnameId', "POST", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('answer', 'POST#', array(1, 64, '密码格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pass', 'POST#', array(1, 32, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('questionId', 'POST#', array(0, 99999999, '问题类型选择有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('captcha', 'POST#', array(1, 99999999, '验证码长度有误', form\FormField::$VAR_INT), array(
				'common\FormCheck::isNumber' => '验证码格式有误'));
		form\FormParser::parse($fs, true);
	}

	public static function checkInfo()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', 'POST', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Mobile', 'POST#', array(11, 11, '手机号码长度有误'), array(
					'common\FormCheck::isMobile' => '手机参数有误'));
		$fs[] = new form\FormField('ChFirstName', "POST#", array(1, 16, "中文姓长度错误"), array(
				'common\FormCheck::isChinese' => "请填写中文姓名"));
		$fs[] = new form\FormField('ChLastName', "POST#", array(1, 16, "中文名长度错误"), array(
				'common\FormCheck::isChinese' => "请填写中文姓名"));
		$fs[] = new form\FormField('Phone', 'POST#', array(6, 9, '电话号码长度为6-9位!'), array(
				'common\FormCheck::isNumber' => '电话号码格式错误!'));
		$fs[] = new form\FormField('PhoneA', 'POST#', array(3, 4, '电话区号长度为3-4位!'), array(
				'common\FormCheck::isNumber' => '电话区号格式错误!'));
		$fs[] = new form\FormField('PhoneExt', 'POST#', array(0, 6, '电话分机号最长6位!'), array(
					'common\FormCheck::isNumber' => '电话分机号格式错误!'));

		$fs[] = new form\FormField('EngFirstName', 'POST#', array(1, 32, '用户姓（英文/拼音）长度为1-32位!'), array(
				'common\FormCheck::isEnglishAndSpace' => '用户姓名（英文/拼音）格式错误!'));
		$fs[] = new form\FormField('EngLastName', 'POST#', array(1, 32, '用户名（英文/拼音）长度为1-32位!'), array(
				'common\FormCheck::isEnglishAndSpace' => '用户姓名（英文/拼音）格式错误!'));

		$fs[] = new form\FormField('ChCompanyName', 'POST#', array(2, 22, '公司名称长度为2-22位!'), array(
				'common\FormCheck::isContainChinese' => '公司名称格式错误!'));
		$fs[] = new form\FormField('EngCompanyName', 'POST#', array(2, 64, '英文公司名称（英文/拼音）长度为2-64位!'), array(
				'common\FormCheck::isPinYin' => '英文公司名称（英文/拼音）格式错误!'));

		$fs[] = new form\FormField('Fax', 'POST#', array(6, 9, '传真号码长度为6-9位!'), array(
				'common\FormCheck::isNumber' => '传真号码格式错误!'));
		$fs[] = new form\FormField('FaxA', 'POST#', array(3, 4, '传真区号长度为3-4位!'), array(
				'common\FormCheck::isNumber' => '传真区号格式错误!'));
		$fs[] = new form\FormField('FaxExt', 'POST#', array(0, 6, '传真分机号最长6位!'), array(
						'common\FormCheck::isNumber' => '传真分机号格式错误!'));
		$fs[] = new form\FormField('ChStreet', 'POST#', array(3, 64, '详细地址长度为3-64位!'), array(
				'common\FormCheck::isContainChinese' => '详细地址格式错误!'));
		$fs[] = new form\FormField('PostCode', 'POST#', array(6, 6, '邮政编码长度为6位!'), array(
				'common\FormCheck::isPostcode' => '邮政编码格式错误!'));
		$fs[] = new form\FormField('Country', 'POST#', array(2, 2, "国家格式错误"));
		$fs[] = new form\FormField('ChProvince', 'POST#', array(1, 100, "省份格式错误"));
		$fs[] = new form\FormField('ChCity', 'POST#', array(1, 100, "城市格式错误"));
		$fs[] = new form\FormField('EngProvince', 'POST#', array(1, 100, "省份格式错误"));
		$fs[] = new form\FormField('EngCity', 'POST#', array(1, 100, "城市格式错误"));
		$fs[] = new form\FormField('EngStreet', 'POST#', array(1, 64, '详细地址（英文/拼音）长度为1-64位!'), array(
				'common\FormCheck::isPinYin' => '详细地址（英文/拼音）格式错误!'));
		$fs[] = new form\FormField('identify', "POST", array(1, 6, '操作保护标识有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('answer', 'POST#', array(1, 64, '密码格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pass', 'POST#', array(1, 32, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('questionId', 'POST#', array(0, 99999999, '问题类型选择有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('captcha', 'POST#', array(1, 99999999, '验证码长度有误', form\FormField::$VAR_INT), array(
				'common\FormCheck::isNumber' => '验证码格式有误'));
		form\FormParser::parse($fs,true);
	}
	public static function checkAppInfo()
	{
		$fs = array();
		$fs[] = new form\FormField('avatar', 'POST#', array(1, 255, '头像路径有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('nickName', 'POST#', array(1, 32, '昵称最长10个字', form\FormField::$VAR_STRING), array(
				'common\FormCheck::checkStringByte' => '昵称最长10个字'));
		$fs[] = new form\FormField('Sign', 'POST#', array(1, 255, '个性签名有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('EnameId', 'POST', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('addFriendSet', 'POST#', array(1, 10, '是否允许加好友有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('ifPushMess', 'POST#', array(1, 10, '是否推送有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('reMessSet', 'POST#', array(1, 10, '是否发送消息有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('chatflag', 'POST#', array(1, 10, '是否聊天推送设置有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('domainflag', 'POST#', array(1, 10, '是否域名到期提醒推送有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('transflag', 'POST#', array(1, 10, '是否交易确认推送有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('detailflag', 'POST#', array(1, 10, '是否信息详情推送有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('devicetoken', 'POST#', array(1, 255, '设备号有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('loginstatus', 'POST#', array(1, form\FormField::$MAX_INT, '状态有误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	public static function checkFriend()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', 'POST', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('friendId', 'POST', array(1, 99999999999, '好友ID有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('starStatus', 'POST#', array(1, 4, 'starStatus有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Status', 'POST#', array(1, 4, 'Status有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('BlackStatus', 'POST#', array(1, 4, '黑名单设置有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Title', 'POST#', array(0, 50, '验证消息有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('Content', 'POST#', array(1, 2000, '验证消息有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('typeid', 'POST#', array(1, 10, '操作类型有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('operateid', 'POST#', array(1, form\FormField::$MAX_INT, '对应操作ID有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('isSetRead', 'POST#', array(0, 1, '是否好友消请求为已读!', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true); 
	}
	
	/**
	 * 设置好友备注
	 */
	public static function setFriendRemark()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', 'POST', array(1, form\FormField::$MAX_INT, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('friendId', 'POST', array(1, form\FormField::$MAX_INT, '好友ID有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('remark', 'POST', array(0, 20, '备注长度错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkFriendGet()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', 'GET', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('friendId', 'GET', array(1, 99999999999, '好友ID有误!', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	public static function checkReadMessage()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', 'GET', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('fromId', 'GET', array(1, 99999999999, '好友ID有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('maxid', 'GET#', array(1, 99999999, '消息ID有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('num', 'GET#', array(1, 9999, '获取数量有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('flag', 'GET#', array(1, 2, '消息类型!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('cleardate', 'GET#', array(1, 255, '清除时间有误!', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	public static function checkGetMessage()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', 'GET#', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('page', 'GET#', array(1, 99999999, '分页有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pageSize', 'GET#', array(1, 99999999, '每页数量有误!', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	public static function checkNewFriend()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', 'GET', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pagesize', 'GET#', array(1, 9999, '分页条数有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pagenum', 'GET#', array(1, 9999, '页数有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('flag', "GET#", array(0, 1, 'flag有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('ver', "GET#", array(0, 10, '版本有误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	public static function checkSearchFriend()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', 'POST', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('friendId', 'POST', array(1, 255, '好友ID有误!', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iffriend', 'POST#', array(1, 2, '好友类型有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('mid', 'POST#', array(1, 999999999, '消息ID有误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	public static function checkPassword()
	{
		$fs = array ();
		$fs[] = new form\FormField('EnameId', 'POST', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Password', "POST", array(6, 32, '密码长度必须在6-32位之间', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('RePassword', "POST", array(6, 32, '密码长度必须在6-32位之间', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	public static function checkCaptcha()
	{
		$fs = array ();
		$fs[] = new form\FormField('identify', "POST", array(1, 6, '操作保护标识有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('EnameId', "POST", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('answer', 'POST#', array(1, 64, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pass', 'POST#', array(1, 32, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('questionId', 'POST#', array(0, 99999999, '问题类型选择有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('purpose', "POST", array(1, 10, 'purpose格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Mobile', 'POST', array(11, 11, '手机号码长度有误'), array(
				'common\FormCheck::isMobile' => '手机参数有误'));
		$fs[] = new form\FormField ('captcha', 'POST', array (1, 6, '验证码长度有误', form\FormField::$VAR_STRING ),array('common\FormCheck::isNumber'=>'验证码格式有误') );
		form\FormParser::parse ( $fs, TRUE );
	}
	public static function checkCaptchaEdit()
	{
		$fs = array ();
		$fs[] = new form\FormField('identify', "POST", array(1, 6, '操作保护标识有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('EnameId', "POST", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('answer', 'POST#', array(1, 64, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pass', 'POST#', array(1, 32, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('purpose', "POST", array(1, 10, 'purpose格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('questionId', 'POST#', array(0, 99999999, '问题类型选择有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Mobile', 'POST', array(11, 11, '手机号码长度有误'), array(
				'common\FormCheck::isMobile' => '手机参数有误'));
		$fs[] = new form\FormField ('captcha', 'POST#', array (1, 6, '验证码长度有误', form\FormField::$VAR_STRING ),array('common\FormCheck::isNumber'=>'验证码格式有误') );
		$fs[] = new form\FormField ('code', 'POST', array (1, 6, '验证码长度有误', form\FormField::$VAR_STRING ),array('common\FormCheck::isNumber'=>'验证码格式有误') );
		form\FormParser::parse ( $fs, TRUE );
	}
	public static function addSecureWarning()
	{
		$fs = array();
		$fs[] = new form\FormField('enameid', "POST", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('BusinessType','POST',array(1,10,'业务类型有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('domain','POST#',array(0,72,'域名格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('Content','POST',array(1,255,'内容格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('IP','POST',array(1,16,'IP地址格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('Priority','POST',array(1,10,'优先权格式有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('CreateDate','POST',array(10,11,'创建时间格式有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('Status','POST#',array(1,10,'状态值有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('HandleStatus','POST#',array(1,10,'状态值有误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs);
	}
	public static function getSecureWarningList()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', "POST#", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Domain', "POST#", array(1,72,'域名长度错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('BusinessType','POST#',array(1,20,'业务类型有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Priority','POST#',array(1,10,'优先权格式有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Status','POST#',array(1,10,'状态值有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Handle', "POST#", array(0,form\FormField::$MAX_INT,'审核人有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('createbegin','POST#',array(1,19,'日期格式有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('createend','POST#',array(1,19,'日期格式有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('updatebegin','POST#',array(1,19,'日期格式有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('updateend','POST#',array(1,19,'日期格式有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('HandleStatus','POST#',array(1,10,'状态值有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('order','POST#',array(0,255,'排序有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('IP',"POST#", array(0,15,'IP格式错误',form\FormField::$VAR_STRING)); 
		$fs[] = new form\FormField('limit', 'POST#', array(1,form\FormField::$MAX_INT,'limit格式有误',form\FormField::$VAR_STRING)); 
		$fs[] = new form\FormField('DealWay','POST#',array(0,20,'处理方式选择有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Remark','POST#',array(0,72,'备注有误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs);
	}
	public static function updateSecureWarning()
	{
		$fs = array();
		$fs[] = new form\FormField('Id','POST#',array(1,form\FormField::$MAX_INT,'Id格式有误',form\FormField::$VAR_INT_ARRAY));
		$fs[] = new form\FormField('enameid', "POST#", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('domain','POST#',array(0,72,'域名格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('Status','POST#',array(1,10,form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Remark','POST#',array(1,255,'备注格式有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('BusinessType','POST#',array(1,10,'业务类型有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Handle','POST#',array(0,form\FormField::$MAX_INT,'处理人有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('IsSystem','POST#',array(0,1,'状态有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('HandleStatus','POST#',array(1,10,'状态值有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('DealWay','POST#',array(0,50,'警报处理方式设置有误',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs);
	}
	public static function getSecureWarning()
	{
		$fs = array();
		$fs[] = new form\FormField('Id','POST',array(1,form\FormField::$MAX_INT,'Id格式有误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs);
	}

	public static function getTodoCount()
	{
		$fs = array();
		$fs[] = new form\FormField('type', 'GET#',array(0,5,'查询类型有误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs);
	}

	public static function getTransInfo()
	{
		$fs = array();
		$fs[] = new form\FormField('enameId', 'GET', array(1, 99999999999, 'enameId格式有误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs,true);
	}

	public static function getAdminInfo()
	{
		$fs = array();
		$fs[] = new form\FormField('adminName', 'GET', array(1,255,'admin有误',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs,true);
	}
	public static function checkUnfriendStat()
	{
		$fs = array();
		$fs[] = new form\FormField('enameid', 'get#', array(1, 99999999999, 'enameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('topnum', 'get#', array(1,form\FormField::$MAX_INT, '数量有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pagesize','get#',array(1,form\FormField::$MAX_INT,'每页显示数有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('offset', 'get#', array(1, 9999, '页数有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('exportflag', 'get#', array(1, 5, '格式有误!', form\FormField::$VAR_INT));
		form\FormParser::parse($fs,true);
	}
	public static function appCheckPassword()
	{
		$fs = array ();
		$fs[] = new form\FormField('EnameId', 'POST', array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('password', "POST", array(6, 32, '密码长度必须在6-32位之间', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * 添加安全地址
	 */
	public static function addMemberSafedressForm()
	{
		$fs = array ();
		$fs[] = new form\FormField('enameId', "get", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('ip', 'get#', array (1, 30, 'ip长度有误', form\FormField::$VAR_STRING ));
		$fs[] = new form\FormField ('address', 'get', array (1, 30, '地址长度有误', form\FormField::$VAR_STRING ));
		$fs[] = new form\FormField ('updateTime', 'get#', array (1, form\FormField::$MAX_INT, '更新时间有错误', form\FormField::$VAR_INT));
		form\FormParser::parse ( $fs, TRUE );
	}	

	/**
	 * 添加安全设备
	 */
	public static function addMemberSafedeviceForm()
	{
		$fs = array ();
		$fs[] = new form\FormField('enameId', "get", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('updateTime', 'get#', array (1, form\FormField::$MAX_INT, '更新时间有错误', form\FormField::$VAR_INT));	
		$fs[] = new form\FormField ('deviceIdentifier', 'get#', array (1, 36, '设备唯一标识错误', form\FormField::$VAR_STRING ));
		$fs[] = new form\FormField ('deviceName', 'get#', array (1, 100, '设备名称错误', form\FormField::$VAR_STRING ));
		form\FormParser::parse ( $fs, TRUE );
	}
	
	/**
	 * 删除安全设备或者安全地址
	 */
	public static function delMemberInfoByIdForm()
	{
		$fs = array ();
		$fs[] = new form\FormField('enameId', "get", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('id', 'get', array (1, form\FormField::$MAX_INT, 'id错误', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ('type', 'get', array (1, form\FormField::$MAX_INT, 'type错误', form\FormField::$VAR_INT ));
		form\FormParser::parse ( $fs, TRUE );
	}
	
	/**
	 * 获取用户安全地址
	 */
	public static function getMemberSafeAdressForm()
	{
		$fs = array ();
		$fs[] = new form\FormField('enameId', "post#", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('id', 'post#', array (1, form\FormField::$MAX_INT, 'id错误', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ('updateTime', 'post#', array (1, form\FormField::$MAX_INT, '更新时间有错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pagesize','post#',array(1,form\FormField::$MAX_INT,'每页显示数有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('offset', 'post#', array(0, form\FormField::$MAX_INT, 'offset错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('ip', 'post#', array (1, 30, 'ip长度有误', form\FormField::$VAR_STRING ));
		$fs[] = new form\FormField ('SafeAdd', 'post#', array (1, 30, '地址长度有误', form\FormField::$VAR_STRING ));
		form\FormParser::parse ( $fs, TRUE );
	}
	
	/**
	 * 获取用户安全设备
	 */
	public static function getMemberSafeDeviceForm()
	{
		$fs = array ();
		$fs[] = new form\FormField('enameId', "post", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('id', 'post#', array (1, form\FormField::$MAX_INT, 'id错误', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ('updateTime', 'post#', array (1, form\FormField::$MAX_INT, '更新时间有错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('deviceIdentifier', 'post#', array (1, 36, '设备号错误', form\FormField::$VAR_STRING ));
		$fs[] = new form\FormField ('deviceName', 'post#', array (1, 100, '设备名称错误', form\FormField::$VAR_STRING ));
		$fs[] = new form\FormField('pagesize','post#',array(1,form\FormField::$MAX_INT,'每页显示数有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('offset', 'post#', array(0, form\FormField::$MAX_INT, 'offset错误', form\FormField::$VAR_INT));
		form\FormParser::parse ( $fs, TRUE );
	}
	
	/**
	 * 更新用户安全设备
	 */
	public static function updateMemberSafeDeviceForm()
	{
		$fs = array ();
		$fs[] = new form\FormField('where', "get", array(1, form\FormField::$MAX_INT, '参数错误', form\FormField::$VAR_STRING_ARRAY));
		$fs[] = new form\FormField ('set', 'get', array (1, form\FormField::$MAX_INT, '更新参数错误', form\FormField::$VAR_STRING_ARRAY ));
		form\FormParser::parse ( $fs, TRUE );		
	}
	
	/**
	 * 根据条件获取安全设备或者地址总数
	 */
	public static function getMemberSafeAdCountForm()
	{
		$fs = array ();
		$fs[] = new form\FormField('enameId', "post#", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('id', 'post#', array (1, form\FormField::$MAX_INT, 'id错误', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ('updateTime', 'post#', array (1, form\FormField::$MAX_INT, '更新时间有错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('ip', 'post#', array (1, 30, 'ip长度有误', form\FormField::$VAR_STRING ));
		form\FormParser::parse ( $fs, TRUE );		
	}

	/**
	 * 根据条件获取安全设备或者地址总数
	 */
	public static function getMemberSafeDeCountForm()
	{
		
		$fs = array ();
		$fs[] = new form\FormField('enameId', "post", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('id', 'post#', array (1, form\FormField::$MAX_INT, 'id错误', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ('updateTime', 'post#', array (1, form\FormField::$MAX_INT, '更新时间有错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('deviceIdentifier', 'post#', array (1, 36, '设备唯一标识错误', form\FormField::$VAR_STRING ));
		$fs[] = new form\FormField ('deviceName', 'post#', array (1, 100, '设备名称错误', form\FormField::$VAR_STRING ));
		form\FormParser::parse ( $fs, TRUE );
	}	
	
	/**
	 * 
	 */
	public static function setThirdLoginForm()
	{
	
		$fs = array ();
		$fs[] = new form\FormField('EnameId', "post", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('type', 'post', array (1,10, '设置数据有错误', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ('status', 'post', array (0, 5, '数据有错误', form\FormField::$VAR_INT));
		form\FormParser::parse ( $fs, TRUE );
	}
	/**
	 *
	 */
	public static function getThirdLoginForm()
	{
	
		$fs = array ();
		$fs[] = new form\FormField('EnameId', "get", array(1, 99999999999, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('type', 'get', array (1,10, '设置数据有错误', form\FormField::$VAR_INT ));
		form\FormParser::parse ( $fs, TRUE );
	}
	
	/**
	 * 检测是否第一次异地登录
	 */
	public static function checkIsFirstLoginForm()
	{
		$fs = array ();
		$fs[] = new form\FormField('EnameId', "GET", array(1, form\FormField::$MAX_INT, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('deviceIdentifier', "GET", array(1, 36, '设备号唯一标识错误', form\FormField::$VAR_STRING));
		form\FormParser::parse ( $fs, TRUE );
	}
	
	/**
	 * app推送
	 */
	public static function appPushForm()
	{
		$fs = array ();
		$fs[] = new form\FormField('EnameId', "POST", array(1, form\FormField::$MAX_INT, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('title', "POST", array(1, 100, '消息标题错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('content', "POST", array(1, 200, '消息内容错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('deviceToken', "POST#", array(1, 80, '设备号错误', form\FormField::$VAR_STRING));
		form\FormParser::parse ( $fs, TRUE );
	}
	
	/**
	 * 用户异地登录验证设置
	 */
	public static function setRemoteLoginSettingForm()
	{
		$fs = array ();
		$fs[] = new form\FormField('EnameId', "POST", array(1, form\FormField::$MAX_INT, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('status', "POST", array(0, 1, '异地登录验证状态有误', form\FormField::$VAR_INT));
		form\FormParser::parse ( $fs, TRUE );
	}
	 
	/**
	 * 用户活动邮件退订
	 */ 
	public static function 	unsubscribeEmail()
	{
		$fs = array ();
		$fs[] = new form\FormField('enameId', "POST", array(1, form\FormField::$MAX_INT, 'EnameId格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('email', "POST", array(4, 64, '邮箱有误'));
		$fs[] = new form\FormField('reason', "POST", array(0, 200, '退订原因有误'));
		form\FormParser::parse($fs, TRUE);
	}

	/**
	 * 获取用户活动邮件退订记录
	 */
	public static function getUnsubscribeEmail()
	{
		$fs[] = new form\FormField('enameId', "POST", 
			array(0,form\FormField::$MAX_INT,'enameId有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('email', "POST", array(0,64,'邮箱有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('num', 'POST', array(0,form\FormField::$MAX_INT,'分页有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('offset', 'POST', array(0,form\FormField::$MAX_INT,'分页有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('startDate', "POST", array(0,10,'日期格式有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('endDate', "POST", array(0,10,'日期格式有误',form\FormField::$VAR_STRING));
		$fs[]= new  form\FormField('IdArr',"POST",array(0, form\FormField::$MAX_INT, 'id错误', form\FormField::$VAR_STRING_ARRAY));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * 取消VIP设置
	 */
	public static function cancelMemberVip()
	{
		$fs[]= new  form\FormField('content',"POST",array(1, form\FormField::$MAX_INT, 'Content错误', form\FormField::$VAR_STRING_ARRAY));
		form\FormParser::parse($fs, true);
	}
	
	public static function getUserLogin()
	{
		$fs[] = new form\FormField('EnameId', "POST",
			array(0,form\FormField::$MAX_INT,'enameId有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Status', "POST", array(0, 1, '状态有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('LoginTimeStart', "POST#", array(0,10,'日期格式有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('LoginTimeEnd', "POST#", array(0,10,'日期格式有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('limit', "POST", array(0,30, '分页有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('order', "POST", array(0,30, '排序有误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	public static function getAppchatBanlist()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', 'POST#',array(1,form\FormField::$MAX_INT,'enameId有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('BanStatus', 'POST#', array(0, 1, '禁言状态有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('StartTime', "POST#", array(0,10,'日期格式有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('EndTime', "POST#", array(0,10,'日期格式有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('limit', "POST#", array(0,30, '分页有误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	public static function operateAppchatBan()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', 'POST',array(1,form\FormField::$MAX_INT,'enameId有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('BanStatus', 'POST', array(0, 1, '禁言状态有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('AdminName', 'POST',array(0,100,'管理员名有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('BanRemark', 'POST',array(0,100,'备注内容长度有误',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
}

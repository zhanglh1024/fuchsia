<?php
namespace form\manage\queue;
use core\form\FormField;
use core\form\FormParser;
class QueueForm
{
	/**
	 * 发送邮件
	 */
	public static function checkSendMailForm()
	{
		$fs[] = new FormField('templateId', "POST", array(1, 200, '模板ID有误', FormField::$VAR_STRING));
		$fs[] = new FormField('email', "POST#", array(1, 64, '邮箱有误'));
		$fs[] = new FormField('fromEmail', "POST#", array(1, 64, '来源邮箱有误'));
		$fs[] = new FormField('data', "POST#", array(0, FormField::$MAX_INT, '模板变量data有误'));//json_encode
		$fs[] = new FormField('enameId', "POST#", array(0, 99999999999, 'enameId有误', FormField::$VAR_INT));
		$fs[] = new FormField('taskId', "POST#", array(0, FormField::$MAX_INT, 'taskId有误',
				FormField::$VAR_INT));
		$fs[] = new FormField('function', "POST#", array(1, 32, 'function有误', FormField::$VAR_STRING));
		$fs[] = new FormField('priority', "POST#", array(1, 5, '优先级有误', FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	/**
	 * 发送短信/语音短信
	 */
	public static function checkSendSmsForm()
	{
		$fs[] = new FormField('templateId', "POST", array(1, 200, '模板ID有误', FormField::$VAR_STRING));
		$fs[] = new FormField('phone', "POST", array(1, 64, '手机号码有误'));
		$fs[] = new FormField('data', "POST#", array(0, FormField::$MAX_INT, '模板变量data有误'));//json_encode
		$fs[] = new FormField('enameId', "POST", array(0, 99999999999, 'enameId有误', FormField::$VAR_INT));
		$fs[] = new FormField('taskId', "POST#", array(0, FormField::$MAX_INT, 'taskId有误',
				FormField::$VAR_INT));
		$fs[] = new FormField('function', "POST#", array(1, 32, 'function有误', FormField::$VAR_STRING));
		$fs[] = new FormField('priority', "POST#", array(1, 5, '优先级有误', FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
	
	/**
	 * 添加批量任务
	 */
	public static function checkAddTaskForm()
	{
		$fs[] = new FormField('data', "POST#", array(0, FormField::$MAX_INT, '模板变量data有误'));
		$fs[] = new FormField('enameId', "POST", array(0, 99999999999, 'enameId有误', FormField::$VAR_INT));
		$fs[] = new FormField('function', "POST#", array(1, 32, 'function有误', FormField::$VAR_STRING));
		$fs[] = new FormField('priority', "POST#", array(1, 5, '优先级有误', FormField::$VAR_INT));
		$fs[] = new FormField('hidden', "POST#", array(0, 1, 'hidden标识有误', FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
}

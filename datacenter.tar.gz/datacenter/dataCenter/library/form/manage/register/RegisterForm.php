<?php
namespace form\manage\register;
use core\form\ReturnData;

use core\form as form;
class RegisterForm
{

	public static function checkPhone()
	{
		$fs[] = new form\FormField('Mobile', "POST", array(11, 11, '手机号码长度错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('flag', "POST#", array(0, 1, '手机号码长度错误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	public static function checkPhoneGet()
	{
		$fs[] = new form\FormField('Mobile', "GET", array(11, 11, '手机号码长度错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('Password',"GET#",array(6,32,'密码长度必须在6-32位之间',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('PasswordCode',"GET#",array(3,3,'code无效',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('regflag',"GET#",array(1,2,'注册类型有误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	public static function checkCapta()
	{
		$fs[] = new form\FormField('Mobile', "POST", array(11, 11, '手机号码长度错误',form\FormField::$VAR_STRING));
		$fs [] = new form\FormField ('captcha','POST', array (1, 6, '验证码长度有误', form\FormField::$VAR_STRING ),array('common\FormCheck::isNumber'=>'验证码格式有误') );
		$fs[] = new form\FormField('brower', "POST#", array(0, 255, '浏览器信息错误',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	public static function register()
	{
		$fs = array();
		$fs[] = new form\FormField('Email',"POST#",array(6,200,'邮箱长度有误!',form\FormField::$VAR_STRING),array('common\FormCheck::isEmail'=>'邮箱格式有误!'));
		if(isset($_POST['MobileType']))
		{
			if ($_POST['MobileType'] == 2 || $_POST['MobileType'] == 1)
			{
				$fs[] = new form\FormField('Mobile',"POST",array(11,11,'请输入正确的手机号码',form\FormField::$VAR_STRING),array('common\FormCheck::isMobile'=>'请输入正确的手机号码'));
			}
			if($_POST['MobileType'] == 2 || $_POST['MobileType'] == 0)
			{
				$fs[] = new form\FormField('PhoneA',"POST",array(3,4,'请输入正确的区号',form\FormField::$VAR_STRING),array('common\FormCheck::isPhoneAC'=>'请输入正确的区号'));
				$fs[] = new form\FormField('Phone',"POST",array(6,8,'请输入正确的电话号码',form\FormField::$VAR_STRING),array('common\FormCheck::isNumber'=>'请输入正确的电话号码'));
				$fs[] = new form\FormField('PhoneExt',"POST#",array(0,6,'请输入正确的分机号码',form\FormField::$VAR_STRING),array('common\FormCheck::isNumber'=>'请输入正确的分机号码'));
			}
		}
		$fs[] = new form\FormField('Password',"POST",array(6,32,'密码长度必须在6-32位之间',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('RePassword',"POST",array(6,32,'密码长度必须在6-32位之间',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('ChCompanyName',"POST#",array(2,22,'请输入正确的企业名称或个人姓名',form\FormField::$VAR_STRING),array('common\FormCheck::isContainChinese'=>'公司名称必须含有汉字'));
		$fs[] = new form\FormField('ChFirstName',"POST#",array(1,16,'请填写您的真实姓名',form\FormField::$VAR_STRING),array('common\FormCheck::isChinese'=>'请填写汉字'));
		$fs[] = new form\FormField('ChLastName',"POST#",array(1,16,'请填写您的真实姓名',form\FormField::$VAR_STRING),array('common\FormCheck::isChinese'=>'请填写汉字'));
		$fs[] = new form\FormField('FaxA',"POST#",array(3,4,'请输入正确的传真区号',form\FormField::$VAR_STRING),array('common\FormCheck::isPhoneAC'=>'请输入正确的传真区号'));
		$fs[] = new form\FormField('Fax',"POST#",array(6,9,'请输入正确的传真号码',form\FormField::$VAR_STRING),array('common\FormCheck::isNumber'=>'请输入正确的传真号码'));
		$fs[] = new form\FormField('FaxExt',"POST#",array(0,6,'请输入正确的传真分机号',form\FormField::$VAR_STRING),array('common\FormCheck::isNumber'=>'请输入正确的传真分机号'));
		$fs[] = new form\FormField('Country',"POST#",array(2,2,'国家选择有误!',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('ChProvince',"POST#",array(1,6,'中文省长度有误!',form\FormField::$VAR_STRING),array('common\FormCheck::isContainChinese'=>'中文省必须含有汉字!'));
		$fs[] = new form\FormField('ChCity',"POST#",array(1,15,'中文城市长度有误!',form\FormField::$VAR_STRING),array('common\FormCheck::isContainChinese'=>'中文城市必须含有汉字!'));
		$fs[] = new form\FormField('ChStreet',"POST#",array(1,22,'中文详细地址长度有误!',form\FormField::$VAR_STRING),array('common\FormCheck::isContainChinese'=>'中文详细地址必须含有汉字!'));
		$fs[] = new form\FormField('PostCode',"POST#",array(100000,999999,'邮编长度有误!',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('EngCompanyName',"POST#",array(2,64,'英文公司名长度有误!',form\FormField::$VAR_STRING),array('common\FormCheck::isEnglishAndSpaceAndNum'=>'Please enter the correct English Company Name!'));
		$fs[] = new form\FormField('EngFirstName',"POST#",array(1,32,'英文姓长度有误!',form\FormField::$VAR_STRING),array('common\FormCheck::isEnglishAndSpace'=>'Please enter the correct English First Name!'));
		$fs[] = new form\FormField('EngLastName',"POST#",array(1,32,'英文名长度有误!',form\FormField::$VAR_STRING),array('common\FormCheck::isEnglishAndSpace'=>'Please enter the correct English Last Name!'));
		$fs[] = new form\FormField('EngProvince',"POST#",array(1,20,'英文省长度有误!',form\FormField::$VAR_STRING),array('common\FormCheck::isEnglishAndSpaceAndNum'=>'Please enter the correct English Province!'));
		$fs[] = new form\FormField('EngCity',"POST#",array(1,20,'英文城市长度有误!',form\FormField::$VAR_STRING),array('common\FormCheck::isEnglishAndSpaceAndNum'=>'Please enter the correct English City!'));
		$fs[] = new form\FormField('EngStreet',"POST#",array(1,64,'英文详细地址长度有误!',form\FormField::$VAR_STRING),array('common\FormCheck::isOkAddress'=>'Please enter the correct English Street!'));
		form\FormParser::parse($fs, FALSE,FALSE);
		if($_POST)
		{
			if(!(ReturnData::$error->Password || ReturnData::$error->RePassword))
			{
				if(!preg_match("/^[^\"\'<>&]+$/", ReturnData::$info->Password))
				{
					throw new form\FormException("密码不可包含 &amp; &lt; &gt; '等字符");
				}
				elseif(!trim(ReturnData::$info->Password) || preg_match("/^[0-9]+$/", ReturnData::$info->Password) || preg_match("/^[a-zA-Z]+$/", ReturnData::$info->Password) || preg_match('/^([\S])\1{5,31}$/', ReturnData::$info->Password))
				{
					throw new form\FormException('您的密码过于简单，请不要使用纯数字、纯字母或连续相同字符');
				}
				if(ReturnData::$info->Password != ReturnData::$info->RePassword)
				{
					throw new form\FormException('两次密码输入不一致,请重新输入.');
				}
			}
			if(empty(ReturnData::$info->Mobile)&&empty(ReturnData::$info->Phone))
			{
				throw new form\FormException('请输入手机号码(手机和电话至少填一项)');
			}
			if(isset($_POST['MobileType']))
			{
				if($_POST['MobileType'] == 1)
				{
					ReturnData::$info->PhoneA = '';
					ReturnData::$info->Phone = '';
					ReturnData::$info->PhoneExt = '';
					ReturnData::$error->PhoneA = '';
					ReturnData::$error->Phone = '';
					ReturnData::$error->PhoneExt = '';
				}
				if($_POST['MobileType'] == 0)
				{
					ReturnData::$info->Mobile = '';
					ReturnData::$error->Mobile = '';
				}
			}
			if(isset($_POST['MoreinforType']) && !$_POST['MoreinforType'] && !ReturnData::$error->Email && !ReturnData::$error->Mobile && !ReturnData::$error->Phone && !ReturnData::$error->PhoneExt && !ReturnData::$error->Password && !ReturnData::$error->RePassword)
			{
				ReturnData::$info->ChCompanyName='';
				ReturnData::$info->ChFirstName='';
				ReturnData::$info->ChLastName='';
				ReturnData::$info->FaxA='';
				ReturnData::$info->Fax='';
				ReturnData::$info->FaxExt='';
				ReturnData::$info->Country='';
				ReturnData::$info->ChProvince='';
				ReturnData::$info->ChCity='';
				ReturnData::$info->ChStreet='';
				ReturnData::$info->PostCode='';
				ReturnData::$info->EngCompanyName='';
				ReturnData::$info->EngFirstName='';
				ReturnData::$info->EngLastName='';
				ReturnData::$info->EngProvince='';
				ReturnData::$info->EngCity='';
				ReturnData::$info->EngStreet='';
				ReturnData::$success = true;
			}
		}
		else
		{
			ReturnData::$info->PhoneA = '';
			ReturnData::$info->Phone = '';
			ReturnData::$info->PhoneExt = '';
			ReturnData::$error->PhoneA = '';
			ReturnData::$error->Phone = '';
			ReturnData::$error->PhoneExt = '';
			ReturnData::$info->Mobile = '';
			ReturnData::$error->Mobile = '';
		}
	}
	
	public static function addEnameId()
	{
		$fs = array();
		$fs[] = new form\FormField('Email',"POST",array(6,200,'邮箱长度有误!',form\FormField::$VAR_STRING),array('common\FormCheck::isEmail'=>'邮箱格式有误!'));
		$fs[] = new form\FormField('EnameId', "POST#", array(5,form\FormField::$MAX_INT,'enameId有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Mobile',"POST",array(11,11,'请输入正确的手机号码',form\FormField::$VAR_STRING),array('common\FormCheck::isMobile'=>'请输入正确的手机号码'));
		form\FormParser::parse($fs, FALSE, FALSE);
		ReturnData::$info->PhoneA = '';
		ReturnData::$info->Phone = '';
		ReturnData::$info->PhoneExt = '';
		ReturnData::$error->PhoneA = '';
		ReturnData::$error->Phone = '';
		ReturnData::$error->PhoneExt = '';
		ReturnData::$info->ChCompanyName='';
		ReturnData::$info->ChFirstName='';
		ReturnData::$info->ChLastName='';
		ReturnData::$info->FaxA='';
		ReturnData::$info->Fax='';
		ReturnData::$info->FaxExt='';
		ReturnData::$info->Country='';
		ReturnData::$info->ChProvince='';
		ReturnData::$info->ChCity='';
		ReturnData::$info->ChStreet='';
		ReturnData::$info->PostCode='';
		ReturnData::$info->EngCompanyName='';
		ReturnData::$info->EngFirstName='';
		ReturnData::$info->EngLastName='';
		ReturnData::$info->EngProvince='';
		ReturnData::$info->EngCity='';
		ReturnData::$info->EngStreet='';
	}

}

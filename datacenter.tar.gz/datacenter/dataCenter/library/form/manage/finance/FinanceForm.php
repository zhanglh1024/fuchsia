<?php
namespace form\manage\finance;
use core\form\FormField;
use core\form\FormParser;
use core\form\ReturnData;
use core\form as form;
class FinanceForm
{

	/**
	 * 消费记录列表
	 */
	public static function checkFinance()
	{
		$fs[] = new form\FormField('EnameId', "GET", array(1, 99999999999, 'enameId有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('financetype', "GET", array(1, 3, '记录类型有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pagesize', 'GET#', array(1, 9999, '分页条数有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pagenum', 'GET#', array(1, 9999, '页数有误!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('type', "GET#", array(0 , FormField::$MAX_INT , '类型格式有误' , FormField::$VAR_INT));
		$fs[] = new form\FormField('startDate', 'GET#', array(0 , 10 , '日期格式有误' , FormField::$VAR_STRING));
		$fs[] = new form\FormField('endDate','GET#', array(0 , 10 , '日期格式有误' , FormField::$VAR_STRING));
		$fs[] = new form\FormField('searchKey', "GET#", array(0 , 15 , '搜索关键词至多15个字符' , FormField::$VAR_STRING));
		$fs[] = new form\FormField('TypeSon', "GET#", array(0 , 200 , '子类型错误' , FormField::$VAR_INT));
		form\FormParser::parse($fs, TRUE);
	}
	
	/**
	 * 获取用户财务信息
	 */
	public static function getUserFinance()
	{
		$fs[] = new form\FormField('EnameId', "GET", array(1, 99999999999, 'enameId有误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, TRUE);
	}

	/**
	 * 更新用户积分
	 */
	public static function updateFinanceScore()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', "POST", array(1, 99999999999, 'enameId有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Score', "POST", array(1,999999, '积分有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('ScoreType', "POST", array(0 , FormField::$MAX_INT , '类型格式有误' , FormField::$VAR_INT));
		$fs[] = new form\FormField('PortalId', "POST", array(0 , FormField::$MAX_INT , 'PortalId格式有误' , FormField::$VAR_INT));
		$fs[] = new form\FormField('OrderId', "POST", array(0 , FormField::$MAX_INT , 'OrderId格式有误' , FormField::$VAR_INT));
		$fs[] = new form\FormField('Remark', "POST", array(0,255, '备注有误', FormField::$VAR_STRING));
		$fs[] = new form\FormField('Status', "POST", array(0,1, '状态有误', FormField::$VAR_INT));
		form\FormParser::parse($fs, TRUE);
	}
	/**
	 * 获取用户余额是否足够创建无产品订单
	 */
	public static function checkbalance()
	{
		$fs[] = new form\FormField('EnameId', "GET", array(1, 99999999999, 'enameId有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('outtype', "GET", array(1, 3, '记录类型有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('price', "GET", array(0 , FormField::$MAX_INT , '类型格式有误' , FormField::$VAR_INT));
		form\FormParser::parse($fs, TRUE);
	}
	/**
	 * 获取财务冻结明细
	 */
	public static function getfreezedetail()
	{
		$fs[] = new form\FormField('EnameId', "GET", array(1, 99999999999, 'enameId有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pagesize', "GET#", array(0, FormField::$MAX_INT, '每页显示条数有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pagenum', "GET#", array(0 , FormField::$MAX_INT , '当前页数有误' , FormField::$VAR_INT));
		form\FormParser::parse($fs, TRUE);
	}

	/**
	 * 财务扣款
	 */
	public static function charge()
	{
		$fs = array();
		$fs[] = new form\FormField('enameId', "POST", array(1, 99999999999, 'enameId有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('price', "POST", array(0 , FormField::$MAX_INT , '价格格式有误' , FormField::$VAR_INT));
		$fs[] = new form\FormField('type', "POST", array(1, 1000, '财务类型格式有误', FormField::$VAR_INT));
		$fs[] = new form\FormField('sonType', "POST#", array(1, 1000, '财务子类型格式有误', FormField::$VAR_INT));
		$fs[] = new form\FormField('remark', "POST", array(0 , 7200 , '备注有误' , FormField::$VAR_STRING));
		$fs[] = new form\FormField('domain', "POST", array(0, 7200, '域名错误', FormField::$VAR_STRING));
		form\FormParser::parse($fs, TRUE);
	}

	/**
	 * 查询余额接口
	 */
	public static function getBalance()
	{
		$fs = array();
		$fs[] = new form\FormField('enameId', "POST", array(1, 99999999999, 'enameId有误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs, TRUE);
	}

	/**
	 * 添加发票
	 */
	public static function addInvoice()  
	{
		$fs = array(); 
		$fs[] = new form\FormField('enameId', "POST", 
			array(1,form\FormField::$MAX_INT,'enameId有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('invoiceType', "POST", array(1,3,'发票类型格式有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('invoiceTitle', "POST", array(1,60,'发票抬头填写不符合要求',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('invoiceAmout', "POST", array(1,15,'所要求开发票金额不符合要求',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('invoiceContent', "POST", array(1,15,'发票内容选择出错',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('taxRegistNumber', "POST", array(0,30,'税务登记号填写有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('taxRegistFile', "POST#", array(1,255,'税务登记证复印件上传有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('taxQualiFile', "POST#", array(1,255,'一般纳税人资格认定复印件上传有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('companyAddress', "POST#", array(1,100,'公司注册地址填写有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('companyPhone', "POST#", array(1,15,'公司注册电话填写有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('bank', "POST#", array(1,30,'开户行填写有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('bankAccount', "POST#", array(6,35,'银行账号填写有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('chProvince', "POST#", array(1,100,'邮寄地址（省份选择）有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('invoiceAddress', "POST#", array(1,100,'邮寄地址填写有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('invoiceRecipient', "POST#", array(1,30,'收件人填写有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('linkPhone', "POST", array(1,15,'收件人联系电话填写有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('invoiceZipCode', "POST#", array(0,6,'邮政编码格式有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('deliveryType', "POST", array(1,5,'用户选择的快递类型选择有误',form\FormField::$VAR_INT));//5为邮件时的快递类型
		$fs[] = new form\FormField('payWay', "POST", array(2,4,'付费方式选择有误',form\FormField::$VAR_INT));//4为邮件时的付费方式
		$fs[] = new form\FormField('deliveryFare', "POST", array(0,10000,'需付快递费用或者消费积分数格式有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('invoiceRemarks', "POST", array(0,100,'发票备注填写不合要求',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('dealWay', "POST", array(1,5,'请勿非法提交表单',form\FormField::$VAR_INT));// 1 混合  2 今年   3 去年（特殊通道） 4 为后台混合(去年和今年)额度开发票，5为后台今年额度开票
		$fs[] = new form\FormField('isDefault', "POST", array(0,1,'发票默认设在选择有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('userType', "POST", array(1,2,'用户类型有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('linkEmail', "POST#", array(6,200,'收件人联系邮箱填写有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('year', "POST#", array(2005,2099,'用户选择年份有误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs, TRUE);
	}
	
	/**
	 * 获取发票记录
	 */
	public static function getInvoice()
	{
		$fs[] = new form\FormField('enameId', "POST", 
			array(0,form\FormField::$MAX_INT,'enameId有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('invoiceId', "POST", 
			array(0,form\FormField::$MAX_INT,'发票ID有误',form\FormField::$VAR_INT));
		$fs[] = new FormField('num', 'POST', array(0,form\FormField::$MAX_INT,'分页有误',form\FormField::$VAR_INT));
		$fs[] = new FormField('offset', 'POST', array(0,form\FormField::$MAX_INT,'分页有误',form\FormField::$VAR_INT));
		$fs[] = new FormField('status', "POST", array(0,6,'类型格式有误',form\FormField::$VAR_INT));
		$fs[] = new FormField('startDate', "POST", array(0,10,'日期格式有误',form\FormField::$VAR_STRING));
		$fs[] = new FormField('endDate', "POST", array(0,10,'日期格式有误',form\FormField::$VAR_STRING));
		$fs[] = new FormField('updateStartDate', "POST", array(0,10,'日期格式有误',form\FormField::$VAR_STRING));
		$fs[] = new FormField('updateEndDate', "POST", array(0,10,'日期格式有误',form\FormField::$VAR_STRING));
		$fs[] = new FormField('invoiceType', "POST", array(0,5,'类型格式有误',form\FormField::$VAR_INT));
		$fs[] = new FormField('deliveryType', "POST", array(0,5,'类型格式有误',form\FormField::$VAR_INT));
		$fs[] = new FormField('dealWay', "POST#", array(0,3,'dealWay error',form\FormField::$VAR_STRING));
		$fs[] = new FormField('isDefault', "POST", array(0,1,'发票默认信息获取错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('linkPhone', "POST#", array(0,15,'收件人联系电话填写有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('chProvince', "POST#", array(0,100,'邮寄地址（省份）有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('invoiceRecipient', "POST#", array(0,30,'收件人填写有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('invoiceTitle', "POST#", array(0,60,'发票抬头填写不符合要求',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 取消发票申请
	 */
	public static function cancleInvoice()
	{
		$fs[] = new form\FormField('enameId', "POST", 
			array(1,form\FormField::$MAX_INT,'enameId有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('invoiceId', "POST", 
			array(0,form\FormField::$MAX_INT,'发票ID有误',form\FormField::$VAR_INT));
		FormParser::parse($fs, true);
	}

	/**
	 * 发票审核
	 */
	public static function dealInvoice()
	{
		$fs[] = new form\FormField('invoiceId', 'POST', 
			array(0,form\FormField::$MAX_INT,'发票ID有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('enameId', "POST", 
			array(0,form\FormField::$MAX_INT,'enameId有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('adminId', "POST", 
			array(0,form\FormField::$MAX_INT,'adminId有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('status', 'POST', array(0,6,'发票状态有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('deliveryType', "POST", array(0,5,'选择的快递类型选择有误',form\FormField::$VAR_INT));//
		$fs[] = new form\FormField('deliveryNumber', "POST", array(0,45,'无效的快递单号',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('invoiceNumber', "POST", array(0,45,'无效的发票号码',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('operateRemarks', "POST", array(0,100,'发票备注填写不合要求',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('conformOrder', 'POST#', array(0,1,'状态有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('payWay', 'POST#', array(0,1,'状态有误',form\FormField::$VAR_STRING));
		FormParser::parse($fs, true);
	} 
	
	/**
	 * 根据条件获取e_finance_general数据
	 */
	public static function getGeneralCount()
	{  
		$fs = array();
		$fs[] = new form\FormField('fields', 'POST#', array(0, form\FormField::$MAX_INT, 'fields Error!', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('startDate', 'POST#', array(0, form\FormField::$MAX_INT, 'CreateTime Format Error!', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('endDate', 'POST#', array(0, form\FormField::$MAX_INT, 'CreateTime Format Error!', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('per_page', 'POST#', array(0, 50, 'PerPage Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('EnameId', 'POST#', array(0, form\FormField::$MAX_INT, 'EnameId Format Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('DomainLtd', 'POST#', array(0, 100, 'DomainLtd Format Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('LinkDomain', 'POST#', array(0, form\FormField::$MAX_INT, 'DomainLtd Format Error!', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('Remark', 'POST#', array(0, form\FormField::$MAX_INT, 'LinkDomain Format Error!', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('AdminId', 'POST#', array(0, form\FormField::$MAX_INT, 'AdminId Format Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('InOutMoney', 'POST#', array(0, form\FormField::$MAX_INT, 'InOutMoney Format Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('InOutType', 'POST#', array(0, form\FormField::$MAX_INT, 'InOutType Format Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('MoneyType', 'POST#', array(0, form\FormField::$MAX_INT, 'MoneyType Format Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('offset', 'POST#', array(0, form\FormField::$MAX_INT, 'offset Format Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('num', 'POST#', array(0, form\FormField::$MAX_INT, 'num Format Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('Type', 'POST#', array(0, 20, 'Type Format Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('typeArr', 'POST#', array(0, form\FormField::$MAX_INT, 'TypeArr Format Error!', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('byMonth', 'POST#', array(0, 2, 'byMonth Format Error!', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('byYear', 'POST#', array(0, 4, 'byYear Format Error!', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('RegistrarId', 'POST#', array(0, form\FormField::$MAX_INT, 'RegistrarId Format Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('TypeSon', 'POST#', array(0, form\FormField::$MAX_INT, 'TypeSon Format Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('BankName', 'POST#', array(0, form\FormField::$MAX_INT, 'BankName Format Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('IsCancelOrder', 'POST#', array(0, 1, 'TypeSon Format Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('inOutMoneyArr', 'POST#', array(0, 20, 'inOutMoneyArr Format Error!', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, TRUE);
	}
	
	public static function orderCancelInfo()  
	{
		$fs = array();
		$fs[] = new form\FormField('orderId', 'POST', array(0, form\FormField::$MAX_INT, 'OrderId Format Error!', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('enameId', 'POST', array(0, form\FormField::$MAX_INT, 'EnameId Format Error!', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, TRUE);
	}
	
	public static function cancelOrder()
	{ 
		$fs = array();
		$fs[] = new form\FormField ( 'orderId', 'POST', array (0, form\FormField::$MAX_INT, '格式有误', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'domain', 'POST', array (0, form\FormField::$MAX_INT, '域名格式有误!', form\FormField::$VAR_STRING ));
		$fs[] = new form\FormField ( 'bEnameId', 'POST#', array (0, form\FormField::$MAX_INT, 'BuyerEnameId格式有误!', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'sEnameId', 'POST#', array (0, form\FormField::$MAX_INT, 'SellEnameId格式有误!', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'deSellMoney', 'POST#', array (0, form\FormField::$MAX_INT, '应该扣除卖家金额格式有误!', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'breakType', 'POST#', array (0, 2, '违约类型格式有误!', FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'bBreakMoney', 'POST#', array (0, form\FormField::$MAX_INT, '买家违约金格式有误!', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'sBreakMoney', 'POST#', array (0, form\FormField::$MAX_INT, '卖家违约金格式有误!', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'deFee', 'POST#', array (0, form\FormField::$MAX_INT, '手续费金额格式有误!', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'retBMoney', 'POST#', array (0, form\FormField::$MAX_INT, '应该退还买家金额格式有误!', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'retSMoney', 'POST#', array (0, form\FormField::$MAX_INT, '应该退还卖家金额格式有误!', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'remarkhide', 'POST#', array (0, form\FormField::$MAX_INT, '备注格式有误!', form\FormField::$VAR_STRING ));
		$fs[] = new form\FormField ( 'adminId', 'POST#', array (0, form\FormField::$MAX_INT, 'adminId格式有误', form\FormField::$VAR_INT ));
		form\FormParser::parse($fs, TRUE);
	}
	
	/**
	 * 获取用户可用发票金额
	 */
	public static function getInvoiceFareForm()
	{
		$fs = array();
		$fs[] = new form\FormField ( 'enameId', 'GET', array (10000, form\FormField::$MAX_INT, 'EnameId格式有误!', form\FormField::$VAR_INT ));
		form\FormParser::parse($fs, TRUE);		
	}

	/**
	 * 更新/添加用户可用发票金额
	 */
	public static function setInvoiceFareForm()
	{
		$fs = array();
		$fs[] = new form\FormField ( 'enameId', 'post', array (10000, form\FormField::$MAX_INT, 'EnameId格式有误!', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'year', 'post#', array (1, form\FormField::$MAX_INT, 'year格式有误!', form\FormField::$VAR_STRING ));
		$fs[] = new form\FormField ( 'invoiceFare', 'post', array (1, form\FormField::$MAX_INT, 'fare格式有误!', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'action', 'post', array (1, 3, '更新类型错误', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'type', 'post', array (1, 3, '类型错误', form\FormField::$VAR_INT ));
		form\FormParser::parse($fs, TRUE);
	}
	
	/**
	 * 修改用户前年开票额度
	 */
	public static function setUserInvoiceForm()
	{
		$fs = array();
		$fs[] = new form\FormField ( 'enameId', 'post', array (10000, form\FormField::$MAX_INT, 'EnameId格式有误!', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'year', 'post', array (1, form\FormField::$MAX_INT, 'year格式有误!', form\FormField::$VAR_STRING ));
		$fs[] = new form\FormField ( 'fare', 'post', array (0, form\FormField::$MAX_INT, 'fare格式有误!', form\FormField::$VAR_INT ));
		form\FormParser::parse($fs, TRUE);
	}
		
	/**
	 *  新财务统计按月统计
	 */
	public static function statByMonth()
	{
		$fs = array();
		$fs[] = new form\FormField ( 'beginMonth', 'GET', array (1, 10, '开始时间格式有误', form\FormField::$VAR_STRING ));
		$fs[] = new form\FormField ( 'endMonth', 'GET', array (1, 10, '结束时间格式有误', form\FormField::$VAR_STRING ));
		$fs[] = new form\FormField ( 'monthType', 'GET#', array (0, 2, '搜索类型有误', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'registrarId', 'GET#', array (0, 99, '接口类型有误', form\FormField::$VAR_INT ));
		$fs[] = new form\FormField ( 'typeArr', 'GET#', array (0, form\FormField::$MAX_INT, '财务类型有误', form\FormField::$VAR_INT_ARRAY ));
		$fs[] = new form\FormField ( 'typeArrFee', 'GET#', array (0, form\FormField::$MAX_INT, '手续费财务类型有误', form\FormField::$VAR_INT_ARRAY ));
		$fs[] = new form\FormField ( 'typeArrPro', 'GET#', array (0, form\FormField::$MAX_INT, '纯收入财务类型有误', form\FormField::$VAR_INT_ARRAY ));
		form\FormParser::parse($fs, TRUE);
	}
	
	/**
	 * 收入统计
	 */
	public static function getFinanceInStatForm()
	{  
		$fs = array();  
		$fs[] = new form\FormField ('startTime', 'GET', array (1, form\FormField::$MAX_INT, '开始时间错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('endTime', 'GET', array (1, form\FormField::$MAX_INT, '结束时间错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, TRUE);
	}
	
	/**
	 * 收入统计
	 */
	public static function getFinanceInStatDetailForm()
	{
		$fs = array();  
		$fs[] = new form\FormField ('startTime', 'GET', array (1, form\FormField::$MAX_INT, '开始时间错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('endTime', 'GET', array (1, form\FormField::$MAX_INT, '结束时间错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('typeArrFee', 'GET#', array (0, form\FormField::$MAX_INT, '手续费财务类型有误', form\FormField::$VAR_INT_ARRAY ));
		$fs[] = new form\FormField ('typeArrDn', 'GET#', array (0, form\FormField::$MAX_INT, '域名收入财务类型有误', form\FormField::$VAR_INT_ARRAY ));
		form\FormParser::parse($fs, TRUE);
	}
	
	/**
	 * 收入统计
	 */
	public static function updateFinanceTypeForm()
	{
		$fs = array();  
		$fs[] = new form\FormField ('GeneralId', 'POST', array (1, form\FormField::$MAX_INT, 'id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField ('FinanceType', 'POST#', array (1, form\FormField::$MAX_INT, '财务类型错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField ('SonType', 'POST#', array (1, form\FormField::$MAX_INT, '财务子类型错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('byYear', 'POST#', array(0, 4, 'byYear Format Error!',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, TRUE);
	}

	/**
	 * 修改用户发票信息
	 */
	public static function updateInvoiceForm()
	{
		$fs = array();
		$fs[] = new form\FormField('adminId', "POST", 
			array(0,form\FormField::$MAX_INT,'adminId有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('invoiceId', 'POST', 
			array(0,form\FormField::$MAX_INT,'发票Id有误!',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('deliveryNumber', "POST#", array(0,45,'无效的快递单号',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('invoiceNumber', "POST#", array(0,45,'无效的发票号码',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, TRUE);
	}
}

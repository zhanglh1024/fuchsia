<?php
namespace form\manage\domain;
use core\form as form;

class DomainTransferInForm
{
	/**
	 * 添加转入记录
	 */
	public static function addTransferIn() 
	{
		$fs[] = new form\FormField('enameId', "POST", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('transferPassword', "POST", array(1, 72, '域名密码错误'));
		$fs[] = new form\FormField('islock', "POST#", array(1, 10, '设置60天锁定错误'));
		$fs[] = new form\FormField('dnsType', "POST", array(1, 2, 'DNS类型错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('transferDomain', "POST", array(3, 72, '域名错误', form\FormField::$VAR_STRING), array(
				"\lib\manage\common\DomainFunLib::checkIsOkDomain" => '域名格式错误'));
		form\FormParser::parse($fs, true);
	} 

	/**
	 * 转入列表
	 */
	public static function transferInList()
	{
		$fs[] = new form\FormField('enameId', "GET", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pageNum', "GET", array(0, form\FormField::$MAX_INT, "页码错误",
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pageSize', "GET", array(0, form\FormField::$MAX_INT, "每页大小错误",
				form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 取消域名转入
	 */
	public static function transferInCancel()
	{
		$fs[] = new form\FormField('enameId', "POST", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('transferInId', "POST", array(1, form\FormField::$MAX_INT, "转入id错误",
				form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 查询域名转入状态
	 */
	public static function checkTransferStatus()
	{
		$fs[] = new form\FormField('enameId', "GET", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('transferInId', "GET", array(1, form\FormField::$MAX_INT, "转入id错误",
				form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 获取域名转入信息--根据transferId
	 */
	public static function getTransferInfo()
	{
		$fs[] = new form\FormField('enameId', "GET", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('transferInId', "GET", array(1, form\FormField::$MAX_INT, "转入id错误",
				form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 更新域名转入信息
	 */
	public static function setTransferInfo()
	{
		$fs[] = new form\FormField('enameId', "POST", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('transferInId', "POST", array(1, form\FormField::$MAX_INT, "转入id错误",
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('domain', "POST", array(3, 72, "转入域名错误", form\FormField::$VAR_STRING), array(
				"\lib\manage\common\DomainFunLib::checkIsOkDomain" => '域名格式错误'));
		$fs[] = new form\FormField('dnsType', "POST", array(1, 3, "dns类型错误", form\FormField::$VAR_INT));
		$fs[] = new form\FormField('password', "POST", array(1, 20, "转移密码错误"));
		$fs[] = new form\FormField('templateId', "POST#", 
			array(0, form\FormField::$MAX_INT, "模板id错误", form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 更新域名转入信息
	 */
	public static function resendTransferMail()
	{
		$fs[] = new form\FormField('enameId', "POST", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('transferInId', "POST", array(1, form\FormField::$MAX_INT, "转入id错误",
				form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
}


<?php
namespace form\manage\domain;
use core\form as form;

class DomainManageForm
{
	/**
	 * 域名管理
	 */
	public static function admin() 
	{
		$fs[] = new form\FormField('domain', "GET", array(1, 72, '域名长度错误'));
		$fs[] = new form\FormField('enameId', "GET", array(5, 11, 'enameID错误'));
		form\FormParser::parse($fs, true);
	}
  
	/**
	 * 自动续费 
	 */
	public static function autoRenew() 
	{
		$fs[] = new form\FormField('domain', "GET", array(1, 72, '域名长度错误'));
		$fs[] = new form\FormField('enameId', "GET", array(5, 11, 'enameID错误'));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 自动续费设置
	 */
	public static function setAutoRenew()
	{
		$fs[] = new form\FormField('domain', "POST", array(3, 72, '域名长度错误'));
		$fs[] = new form\FormField('enameId', "POST", array(5, 11, 'enameId错误'));
		$fs[] = new form\FormField('autoRenew', "POST", array(0, 1, '续费设置错误'));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 取的域名分组列表
	 */
	public static function getDomainGroup()
	{
		$fs[] = new form\FormField('enameId', "GET", array(5, 11, 'enameId错误'));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 域名高级搜索
	 */
	public static function advanceSearch()
	{
		$fs[] = new form\FormField('keyword', "GET", array(0, 32, '域名关键字错误'));
		$fs[] = new form\FormField('domainLtd', "GET", array(0, 100, '域名后缀错误'));
	   $fs[] = new form\FormField('sysGroup', "GET", array(0, 100, '域名分类错误'));
		$fs[] = new form\FormField('firstClass', "GET", array(0, 100, '域名分类错误'));
		$fs[] = new form\FormField('secondClass', "GET#", array(0, 100, '域名分类错误'));
		$fs[] = new form\FormField('thirdClass', "GET#", array(0, 100, '域名分类错误'));
		$fs[] = new form\FormField('group', "GET", array(0, 100, '域名分组错误'));
		$fs[] = new form\FormField('status', "GET", array(0, 100, '域名状态错误'));
		$fs[] = new form\FormField('startDomainLength', "GET", array(0, 72, '域名开始长度错误'));
		$fs[] = new form\FormField('endDomainLength', "GET", array(0, 72, '域名结算长度错误'));
		$fs[] = new form\FormField('enameId', "GET", array(5, form\FormField::$MAX_INT, 'enameid错误'));
		$fs[] = new form\FormField('pagenum', "GET", array(0, form\FormField::$MAX_INT, '页码错误'));
		$fs[] = new form\FormField('pagesize', "GET", array(0, form\FormField::$MAX_INT, '分页大小错误'));
		$fs[] = new form\FormField('templateId', "GET", array(0, form\FormField::$MAX_INT, 'templateId错误'));
		$fs[] = new form\FormField('islock', "GET#", array(0, form\FormField::$MAX_INT, '60天锁定设置错误'));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 模板过户（单个）
	 */
	public static function templatePushOnce()
	{
		$fs = array();
		$fs[] = new form\FormField('domain', "POST", array(3,1440, '域名长度错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('templateId', "POST", array(0, form\FormField::$MAX_INT, 'templateId错误'));
		$fs[] = new form\FormField('oldTemplateId', "POST", array(0, form\FormField::$MAX_INT, 'oldTemplateId错误'));
		$fs[] = new form\FormField('registrarId', "POST",array(1, form\FormField::$MAX_INT, 'registrarId错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('newTemplateName', 'POST', array(0, 100, 'newTemplateName错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('tempType','POST',array(0, 4, 'tempType错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('oldTemplateName', 'POST', array(0, 100, 'oldTemplateName错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('enameId', "POST", array(1, form\FormField::$MAX_INT, "enameID错误",form\FormField::$VAR_INT));
		$fs[] = new form\FormField('islock', "POST#", array(1, form\FormField::$MAX_INT, "是否设置60天锁定错误",form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * 修改dns
	 */
	public static function setDomainDns()
	{
		$fs = array();
		$fs[] = new form\FormField('enameId', "POST", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('domain', "POST", array(3,1440, '域名长度错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('dns', "POST#", array(1,form\FormField::$MAX_INT,'dns格式有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('dnsType', 'POST#', array(0,4, 'DNS类型有误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	/**
	 * 修改dns--队列
	 */
	public static function setDomainDnsByQueue()
	{
		$fs = array();
		$fs[] = new form\FormField('EnameId', "POST", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('domain', "POST", array(3,1440, '域名长度错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('dns', "POST#", array(1,form\FormField::$MAX_INT,'dns格式有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('dnsType', 'POST#', array(0,4, 'DNS类型有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('identify', "POST", array(1, 6, '操作保护标识有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('answer', 'POST#', array(1, 64, '答案格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pass', 'POST#', array(1, 32, '密码长度有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('questionId', 'POST#', array(0, 99999999, '问题类型选择有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('captcha', 'POST#', array(1, 99999999, '验证码长度有误', form\FormField::$VAR_INT), array(
				'common\FormCheck::isNumber' => '验证码格式有误'));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * 自动续费设置
	 */
	public static function domainRenew()
	{
		$fs[] = new form\FormField('domain', "POST", array(3, 72, '域名长度错误'));
		$fs[] = new form\FormField('enameId', "POST", array(5, 11, 'enameId错误'));
		$fs[] = new form\FormField('period', "POST", array(1, 10, '续费年限错误'));
		$fs[] = new form\FormField('expDate', "POST#", array(15, 22, '域名过期时间错误'));
		form\FormParser::parse($fs, true);
	}

	public static function templatePush()
	{   
		$fs = array();
		$fs[] = new form\FormField('enameId', "POST", array(5, 11, 'enameId错误'));
		$fs[] = new form\FormField('domain', "POST", array(3,1440, '域名长度错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('tempname', 'POST#', array(3,72, '模板长度错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('islock', 'POST#', array(1,10, '设置60天锁定错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	} 
	
	public static function templatePushByQueue()
	{
		$fs = array();
		$fs[] = new form\FormField('enameId', "POST", array(5, 11, 'enameId错误'));
		$fs[] = new form\FormField('domain', "POST#", array(3,1440, '域名长度错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('cnTempId', 'POST#', array(1,10, '模板ID错误'));
		$fs[] = new form\FormField('islock', 'POST#', array(1,10, '是否设置60天锁定错误'));
		form\FormParser::parse($fs, true);
	}
	/**
	 * 批量设置域名分组
	 */
	public static function domainSetGroup()
	{
		$fs[] = new form\FormField('domain', "POST", array(3, form\FormField::$MAX_INT, '域名长度错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('enameId', "POST", array(5, 11, 'enameId错误'));
		$fs[] = new form\FormField('groupId', "POST",  array(0, 100, '域名分组错误'));
		form\FormParser::parse($fs, true);
	}
	
	public static function setPrivacy()
	{ 
		$fs[] = new form\FormField('enameId',"post", array(1, form\FormField::$MAX_INT, "enameID错误",form\FormField::$VAR_INT));
		$fs[]= new form\FormField('domains','post',array(3, form\FormField::$MAX_INT,'域名长度有误', form\FormField::$VAR_STRING));
		$fs[]= new form\FormField('isPrivacy','post',array(0, 1,'没有选择开启取消隐私保护', form\FormField::$VAR_INT));
		$fs[]= new form\FormField('islock','post#',array(1, 10,'60锁定设置错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs,TRUE);
	}
	 
	public static function cooperRegidRenewForm()
	{
		$fs[] = new form\FormField('enameId',"post", array(1, form\FormField::$MAX_INT, "enameID错误",form\FormField::$VAR_INT));
		$fs[]= new form\FormField('orderId','post#',array(3, form\FormField::$MAX_INT,'orderid有误', form\FormField::$VAR_STRING));
		$fs[]= new form\FormField('domain','post',array(3, form\FormField::$MAX_INT,'域名长度有误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs,TRUE);
	}	
	
}

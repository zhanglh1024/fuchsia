<?php
namespace form\manage\domain;
use core\form as form;
class DomainForm
{

	public static function checkLogForm()
	{
		$fs[] = new form\FormField('enameid', "GET", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('domain', "GET", array(1, 72, '域名长度错误'));
		$fs[] = new form\FormField('tld', "GET", array(1, 6, '域名后缀错误'));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 查看是否是珍品域名
	 */
	public static function topDomainExists()
	{
		$fs[] = new form\FormField('domain', "GET", array(3, 72, '域名长度错误'));
		$fs[] = new form\FormField('priceType', "GET", array(2, 3, '只能是续费跟转入类型', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('checkTime', "GET", array(4, 4, '年份错误'));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * 获取珍品域名消费记录
	 */
	public static function getTopDomain()
	{
		$fs[] = new form\FormField('domain', "GET", array(0, 72, '域名长度错误'));
		$fs[] = new form\FormField('enameId', "GET", array(0, form\FormField::$MAX_INT, 'enameid错误'));
		$fs[] = new form\FormField('startTime', "GET", array(0, 12, '年份错误'));
		$fs[] = new form\FormField('endTime', "GET", array(0, 12, '年份错误'));
		$fs[] = new form\FormField('topType', "GET", array(0, 4, '珍品等级错误'));
		$fs[] = new form\FormField('pageNum', "GET", array(0, form\FormField::$MAX_INT, '页码错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pageSize', "GET", array(0, form\FormField::$MAX_INT, '每页数量错误'));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * 添加珍品域名记录
	 */
	public static function addTopDomainForm()
	{
		$fs[] = new form\FormField('domain', "POST", array(3, 72, '域名长度错误'));
		$fs[] = new form\FormField('topType', "POST", array(1, 4, '分类错误'));
		$fs[] = new form\FormField('remark', "POST", array(0, 72, '备注错误'));
		$fs[] = new form\FormField('enameId', "POST", array(5, form\FormField::$MAX_INT, 'enameId错误'));
		$fs[] = new form\FormField('price', "POST", array(0, 100, '价格错误'));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 查询域名是否可以注册
	 */
	public static function domainRegistQuery()
	{
		$fs[] = new form\FormField('domain', "GET", array(1, 720, '域名长度错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('suffix', "GET", array(0, 72, '域名后缀错误', form\FormField::$VAR_STRING_ARRAY));
		$fs[] = new form\FormField('enameId', "GET", array(0, form\FormField::$MAX_INT, 'enameId错误'));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * 简单域名注册
	 */
	public static function simpledomainRegist()
	{
		$fs[] = new form\FormField('domain', "POST", array(1, 720, '域名长度错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('templateid', "POST#", array(0, form\FormField::$MAX_INT, '模板ID错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('registerid', "POST", array(0, form\FormField::$MAX_INT, '接口值错误' , form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 批量查询域名是否可以注册
	 */
	public static function domainRegistQueryBatch()
	{
		$fs[] = new form\FormField('domain', "POST", array(3, form\FormField::$MAX_INT, '域名长度错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('enameId', "POST", array(0, form\FormField::$MAX_INT, 'enameId错误'));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * 115查询域名是否可以注册
	 */
	public static function domainRegistQueryOther()
	{
		$fs[] = new form\FormField('domain', "POST", array(3, 1600, '域名长度错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('enameId', "POST", array(0, form\FormField::$MAX_INT, 'enameId错误'));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 115域名续费注册
	 */
	public static function domainRegist()
	{
		$fs[] = new form\FormField('enameId', "POST", array(5, form\FormField::$MAX_INT, 'enameId错误'));
		$fs[] = new form\FormField('products', "POST", array(1,2400, '域名数据错误'));
		$fs[] = new form\FormField('type', "POST", array(1,3, '类型错误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * 域名安全锁未处理数量
	 */
	public static function domainsecureCount()
	{
		$fs[] = new form\FormField('type', "GET", array(1,3, '类型错误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * 给whois
	 */
	public static function domainRecommond()
	{
		$fs[] = new form\FormField('domain', "POST", array(1, 64, '域名长度错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('suffix', "POST", array(2, 72, '域名后缀错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	 	
	/**
	 * 域名入库和过户接口   给E+用
	 */
	public static function storageIn()
	{
		$fs[] = new form\FormField('enameId', "POST", array(5, form\FormField::$MAX_INT, 'enameId错误'));
		$fs[] = new form\FormField('domain', "POST", array(1, 64, '域名长度错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('registrarId', "POST",array(1, form\FormField::$MAX_INT, '接口错误registrarId', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	/**
	 * 域名转入和过户接口   给E+用
	 */
	public static function transferIn()
	{
		$fs[] = new form\FormField('enameId', "POST", array(5, form\FormField::$MAX_INT, 'enameId错误'));
		$fs[] = new form\FormField('domain', "POST", array(1, 64, '域名长度错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('transferPassword', "POST", array(1, 72, '域名密码错误'));
		$fs[] = new form\FormField('qiangZhuEnameId', "POST", array(5, form\FormField::$MAX_INT, 'qiangZhuEnameId错误'));
		form\FormParser::parse($fs, true);
	}
}

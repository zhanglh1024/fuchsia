<?php
namespace form\manage\domain;
use core\form as form;
class DomainRestoreForm
{
	/**
	 * 赎回列表
	 */
	public static function restoreListForm()
	{
		$fs[] = new form\FormField('enameId', "GET", array(0, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('domain', "GET", array(0, 72, '域名长度错误'));
		$fs[] = new form\FormField('status', "GET", array(0, 6, '赎回状态错误'));
		$fs[] = new form\FormField('templateId', "GET", array(0, form\FormField::$MAX_INT, '模版id错误',
				form\FormField::$VAR_INT));
		$fs[] = new form\FormField('templateName', "GET", array(0, 70, '模版名错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('type', "GET", array(0, 6, '域名类别错误'));
		$fs[] = new form\FormField('pagesize', "GET", array(0, 10000, '每页数量错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('perpage', "GET", array(0, form\FormField::$MAX_INT, '当前页码错误',
				form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}

	/**
	 * 赎回详情
	 */
	public static function getRestoreDetailForm()
	{
		$fs[] = new form\FormField('id', "GET", array(1, form\FormField::$MAX_INT, '记录id错误'));
		form\FormParser::parse($fs, true);
	}

	/**
	 * org asia域名 域名赎回操作
	 */
	public static function domainRestoreOperForm()
	{
		$fs[] = new form\FormField('id', "GET", array(1,form\FormField::$MAX_INT,'记录id错误'));
		$fs[] = new form\FormField('status', "GET", array(1,form\FormField::$MAX_INT,'记录id错误'));
		$fs[] = new form\FormField('handle', "GET", 
			array(1,form\FormField::$MAX_INT,'审核人员不能为空',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * 是否可以赎回查询
	 */
	public static function domainRestoreQuery()
	{
		$fs[] = new form\FormField('enameId', 'GET', array(1, form\FormField::$MAX_INT, '域名长度错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('domain', 'GET', array(1, 720, '域名长度错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * cn域名赎回/保留域名赎回
	 */
	public static function domainRestoreDirect()
	{
		$fs[] = new form\FormField('enameId', 'POST', array(1, form\FormField::$MAX_INT, '域名长度错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('domain', 'POST', array(1, 72, '域名长度错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('expTime', 'POST', array(1, 72, '过期时间错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('registrarId', 'POST', array(1, form\FormField::$MAX_INT, 'registrarId错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('templateId', 'POST', array(1, form\FormField::$MAX_INT, '模版信息错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('price', 'POST', array(1, 1000, '域名赎回价格错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('templateName', 'POST#', array(0, 100, '模版信息错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('regTime', 'POST', array(1, 72, '注册时间错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('type', 'POST', array(1, 4, '赎回类型错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	/**
	 * 赎回备注--domainservice表
	 */
	public static function restoreSetRemarkForm()
	{
		$fs[] = new form\FormField('id', "POST", array(1, form\FormField::$MAX_INT, '记录id错误'));
		$fs[] = new form\FormField('remark', "POST", array(1, form\FormField::$MAX_INT, '备注错误',
				form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('handle', "POST", array(1, form\FormField::$MAX_INT, '审核人员不能为空',
				form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
}

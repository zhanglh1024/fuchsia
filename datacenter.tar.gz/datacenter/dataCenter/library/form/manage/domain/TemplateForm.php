<?php
namespace form\manage\domain;
use core\form as form;
class TemplateForm
{

	/**
	 * 检验用户ID
	 */
	public static function checkEnameId()
	{
		$fs[] = new form\FormField('EnameId', "GET", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	/**
	 * 检验用户ID 
	 */
	public static function checkTmplateList()
	{
		$fs[] = new form\FormField('pagenum', 'GET#', array(1, 9999, '分页格式有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pagesize', 'GET#', array(0, 9999, '页码格式有误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('EnameId', "GET", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	public static function saveCnTemplate()
	{
		$tempType= 0;
		if($_POST)
		{
			$tempType= isset($_POST['temptype']) ?intval($_POST['temptype']) :1;
		}
		$fs= array();
		$fs[]= new form\FormField('cnorg','POST#',array(1, form\FormField::$MAX_INT, '请选择认证的企业名称', form\FormField::$VAR_STRING));	
		$fs[] = new form\FormField('EnameId', "post", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[]= new form\FormField('mail',"POST",array(1, form\FormField::$MAX_INT, '请选择认证的电子邮件', form\FormField::$VAR_STRING));
		$fs[]= new form\FormField('tempname','POST',array(3, 20, '模板名长度3-20个字符，特殊符号无效，如""'));
		$fs[]= new form\FormField('temptype','POST',array(0, 4, '中文模板类型错误', form\FormField::$VAR_INT));
		$fs[]= new form\FormField('cnname','POST#',array(1, form\FormField::$MAX_INT, '请选择通过认证的姓名', form\FormField::$VAR_STRING));
		$fs[]= new form\FormField('street','POST',array(3, 30, '地址长度3-30个字符', form\FormField::$VAR_STRING),array('common\FormCheck::isContainChinese' => '地址必须包含中文'));
		$fs[]= new form\FormField('estreet','POST#',array(3, 128, '地址长度3-128个字符', form\FormField::$VAR_STRING),array('common\FormCheck::isPinYin' => '地址必须英文'));
		$fs[]= new form\FormField('enorg','POST#',array(2, 64, '公司名称(英文)长度2-64个字符', form\FormField::$VAR_STRING),array('common\FormCheck::isPinYin' => '英文公司名称(英文/拼音)格式错误!'));
		$fs[]= new form\FormField('country','POST',array(2, 4, '请选择国家(地区)', form\FormField::$VAR_STRING),array('common\FormCheck::isEnglish' => '大写字母'));
		if(isset($_POST['country']) && strtoupper($_POST['country']) == "CN")
		{
			$fs[]= new form\FormField('chprovince','POST',array(2, 30, '请选择省份', form\FormField::$VAR_STRING),array('common\FormCheck::isChinese' => '省份必须是中文'));
			$fs[]= new form\FormField('chcity','POST',array(2, 30, '请选择城市', form\FormField::$VAR_STRING),array('common\FormCheck::isChinese' => '城市名必须是中文'));
		}
		else
		{
			$fs[]= new form\FormField('chprovince','POST',array(2, 30, '请选择省份', form\FormField::$VAR_STRING));
			$fs[]= new form\FormField('chcity','POST',array(2, 30, '请选择城市', form\FormField::$VAR_STRING));
		}
		$fs[]= new form\FormField('postcode','POST',array(0, 6, '邮编必须是6个数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '邮编必须是数字'));
		$fs[]= new form\FormField('phone','POST',array(7, 12, '电话号码必须是7-12个数字 号码 或者手机号码', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '电话号码必须是数字'));
		$fs[]= new form\FormField('phonecc','POST#',array(0, 6, '电话的国际区号必须0-6位数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '电话的国际区号必须是数字'));
		$fs[]= new form\FormField('fax','POST',array(10, 12, '传真号码必须是10-12个数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '传真号码必须是数字'));
		$fs[]= new form\FormField('faxcc','POST#',array(0, 6, '传真的国际区号必须0-6位数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '传真的国际区号必须是数字'));
		$fs[]= new form\FormField('version','POST#',array(0, 6, '版本号错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs,true);
	}
	public static function saveInternetTemplate()
	{
		$fs= array();
		$fs[] = new form\FormField('EnameId', "post", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[]= new form\FormField('org','post#',array(2, 64, '单位名称请输入2-64个字符'));
		$fs[]= new form\FormField('mail',"post",array(1, form\FormField::$MAX_INT, '请选择认证的电子邮件', form\FormField::$VAR_STRING));
		$fs[]= new form\FormField('tempname','POST',array(3, 30, '模板名长度3-30个字符'));
	
		$fs[]= new form\FormField('firstname','POST#',array(1, 10, '中文姓必须1-10个字符', form\FormField::$VAR_STRING));
		$fs[]= new form\FormField('lastname','POST#',array(1, 20, '中文名必须1-20个字符', form\FormField::$VAR_STRING));
		$fs[]= new form\FormField('street','POST',array(6, 64, '地址长度6-64个字符', form\FormField::$VAR_STRING),array('common\FormCheck::isOkAddress' => '地址不能包含中文字符'));
		$fs[]= new form\FormField('country','POST',array(2, 4, '请选择国家(地区)', form\FormField::$VAR_STRING),array('common\FormCheck::isEnglish' => '大写字母'));
		if(isset($_POST['country']) && strtoupper($_POST['country']) == 'CN')
		{
			$fs[]= new form\FormField('chprovince','POST',array(2, 30, '请选择省份', form\FormField::$VAR_STRING),array('common\FormCheck::isChinese' => '省份必须是中文'));
			$fs[]= new form\FormField('chcity','POST',array(2, 30, '请选择城市',form\FormField::$VAR_STRING),array('common\FormCheck::isChinese' => '城市名必须是中文'));
		}
		else
		{
			$fs[]= new form\FormField('chprovince','POST',array(2, 30, '请选择省份', form\FormField::$VAR_STRING));
			$fs[]= new form\FormField('chcity','POST',array(2, 30, '请选择城市', form\FormField::$VAR_STRING));
		}
	
		$fs[]= new form\FormField('postcode','POST',array(0, 6, '邮编必须是6个数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '邮编必须是数字'));
		$fs[]= new form\FormField('phone','POST',array(7, 12, '电话号码必须是7-12个数字 区号+号码 或者手机号码', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '电话号码必须是数字'));
		$fs[]= new form\FormField('phonecc','POST#',array(0, 6, '电话的国际区号必须0-6位数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '电话的国际区号必须是数字'));
		$fs[]= new form\FormField('fax','POST',array(10, 12, '传真号码必须是10-12个数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '传真号码必须是数字'));
		$fs[]= new form\FormField('faxcc','POST#',array(0, 6, '传真的国际区号必须0-6位数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '传真的国际区号必须是数字'));
		$fs[]= new form\FormField('efirstname','POST',array(2, 20, '英文姓必须2-20个字符', form\FormField::$VAR_STRING),array('common\FormCheck::isEnglishAndSpace' => '英文姓必须是英文或者拼音'));
		$fs[]= new form\FormField('elastname','POST',array(2, 20, '英文名必须2-20个字符', form\FormField::$VAR_STRING),array('common\FormCheck::isEnglishAndSpace' => '英文名必须是英文或者拼音'));
		$fs[]= new form\FormField('eorg','POST',array(2, 64, '公司名称必须2-64个字符', form\FormField::$VAR_STRING),array('common\FormCheck::isOkOrg' => '组织机构必须是英文或者拼音'));
		form\FormParser::parse($fs,true);
	}
	public static function editChinaTemplate()
	{
		$tempType= 0;
		if($_POST)
		{
			$tempType= isset($_POST['temptype']) ?intval($_POST['temptype']) :1;
		}
		$fs= array();
		$fs[] = new form\FormField('EnameId', "post", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		if($tempType == 1)
		{
			if(!empty($_POST['cnorg']))
			{
				$fs[]= new form\FormField('cnorg','post',array(1, form\FormField::$MAX_INT, '请选择认证的企业名称', form\FormField::$VAR_INT));
			}
			else
			{
				$fs[]= new form\FormField('cnorg','post#',array(1, form\FormField::$MAX_INT, '请选择认证的企业名称', form\FormField::$VAR_INT));
			}
		}
		else
		{
			$fs[]= new form\FormField('cnorg','post#',array(1, form\FormField::$MAX_INT, '请选择认证的企业名称', form\FormField::$VAR_INT));
		}
		if(!empty($_POST['oldName']))
		{
			$fs[]= new form\FormField('oldName','post',array(1, 100, '请选择通过认证的姓名', form\FormField::$VAR_STRING));
		}
		if(!empty($_POST['oldCompany']))
		{
			$fs[]= new form\FormField('oldCompany','post',array(1, 100, '请选择通过认证的企业', form\FormField::$VAR_STRING));
		}
		$fs[]= new form\FormField('id',"post",array(1, form\FormField::$MAX_INT, '模板ID错误', form\FormField::$VAR_INT));
		$fs[]= new form\FormField('mail',"post",array(1, form\FormField::$MAX_INT, '请选择认证的电子邮件', form\FormField::$VAR_INT));
		$fs[]= new form\FormField('tempname','POST',array(3, 20, '模板名长度3-20个字符，特殊符号无效，如""'));
		$fs[]= new form\FormField('temptype','POST',array(0, 4, '中文模板类型错误', form\FormField::$VAR_INT));
		$fs[]= new form\FormField('enorg','POST#',array(2, 64, '公司名称(英文)长度2-64个字符', form\FormField::$VAR_STRING),array('common\FormCheck::isPinYin' => '英文公司名称(英文/拼音)格式错误!'));
		$fs[]= new form\FormField('cnname','post#',array(1, form\FormField::$MAX_INT, '请选择通过认证的姓名', form\FormField::$VAR_INT));
		$fs[]= new form\FormField('street','post',array(3, 21, '地址长度3-21个字符', form\FormField::$VAR_STRING),array('common\FormCheck::isContainChinese' => '地址必须包含中文'));
		$fs[]= new form\FormField('estreet','POST#',array(3, 64, '地址长度3-21个字符', form\FormField::$VAR_STRING),array('common\FormCheck::isOkAddress' => '地址必须英文'));
		$fs[]= new form\FormField('country','post',array(2, 4, '请选择国家(地区)', form\FormField::$VAR_STRING),array('common\FormCheck::isEnglish' => '大写字母'));
		if(isset($_POST['country']) && strtoupper($_POST['country']) == "CN")
		{
			$fs[]= new form\FormField('chprovince','post',array(2, 30, '请选择省份', form\FormField::$VAR_STRING),array('common\FormCheck::isChinese' => '省份必须是中文'));
			$fs[]= new form\FormField('chcity','post',array(2, 30, '请选择城市', form\FormField::$VAR_STRING),array('common\FormCheck::isChinese' => '城市名必须是中文'));
		}
		else
		{
			$fs[]= new form\FormField('chprovince','post',array(2, 30, '请选择省份', form\FormField::$VAR_STRING));
			$fs[]= new form\FormField('chcity','post',array(2, 30, '请选择城市', form\FormField::$VAR_STRING));
		}
		$fs[]= new form\FormField('postcode','POST',array(0, 6, '邮编必须是6个数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '邮编必须是数字'));
		$fs[]= new form\FormField('phone','POST',array(7, 12, '电话号码必须是7-12个数字 区号+号码 或者手机号码', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '电话号码必须是数字'));
		$fs[]= new form\FormField('phonecc','POST#',array(0, 6, '电话的国际区号必须0-6位数字',form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '电话的国际区号必须是数字'));
		$fs[]= new form\FormField('fax','POST',array(7, 12, '传真号码必须是7-12个数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '传真号码必须是数字'));
		$fs[]= new form\FormField('faxcc','POST#',array(0, 6, '传真的国际区号必须0-6位数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '传真的国际区号必须是数字'));
		form\FormParser::parse($fs,true);
	
	}
	
	public static function editInernetTemplate()
	{
		$fs= array();
		$fs[] = new form\FormField('EnameId', "post", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[]= new form\FormField('id',"post",array(1, form\FormField::$MAX_INT, '模板ID错误', form\FormField::$VAR_INT));
		$fs[]= new form\FormField('org','post#',array(2, 64, '单位名称请输入2-64个字符'));
		$fs[]= new form\FormField('mail',"post",array(1, form\FormField::$MAX_INT, '请选择认证的电子邮件', form\FormField::$VAR_INT));
		$fs[]= new form\FormField('tempname','POST',array(3, 30, '模板名长度3-30个字符'));
	
		$fs[]= new form\FormField('firstname','post#',array(1, 10, '中文姓必须1-10个字符', form\FormField::$VAR_STRING));
		$fs[]= new form\FormField('lastname','post#',array(1, 20, '中文名必须1-20个字符', form\FormField::$VAR_STRING));
		$fs[]= new form\FormField('street','post',array(6, 64, '地址长度6-64个英文字符', form\FormField::$VAR_STRING),array('common\FormCheck::isOkAddress' => '地址不能包含中文字符'));
		$fs[]= new form\FormField('country','post',array(2, 4, '请选择国家(地区)', form\FormField::$VAR_STRING),array('common\FormCheck::isEnglish' => '大写字母'));
		if(isset($_POST['country']) && strtoupper($_POST['country']) == 'CN')
		{
			$fs[]= new form\FormField('chprovince','post',array(2, 30, '请选择省份', form\FormField::$VAR_STRING),array('common\FormCheck::isChinese' => '省份必须是中文'));
			$fs[]= new form\FormField('chcity','post',array(2, 30, '请选择城市', form\FormField::$VAR_STRING),array('common\FormCheck::isChinese' => '城市名必须是中文'));
		}
		else
		{
			$fs[]= new form\FormField('chprovince','post',array(2, 30, '请选择省份', form\FormField::$VAR_STRING));
			$fs[]= new form\FormField('chcity','post',array(2, 30, '请选择城市', form\FormField::$VAR_STRING));
		}
		$fs[]= new form\FormField('postcode','POST',array(0, 6, '邮编必须是6个数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '邮编必须是数字'));
		$fs[]= new form\FormField('phone','POST',array(7, 12, '电话号码必须是7-12个数字 区号+号码 或者手机号码', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '电话号码必须是数字'));
		$fs[]= new form\FormField('phonecc','POST#',array(0, 6, '电话的国际区号必须0-6位数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '电话的国际区号必须是数字'));
		$fs[]= new form\FormField('fax','POST',array(7, 12, '传真号码必须是7-12个数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '传真号码必须是数字'));
		$fs[]= new form\FormField('faxcc','POST#',array(0, 6, '传真的国际区号必须0-6位数字', form\FormField::$VAR_STRING),array('common\FormCheck::isNumber' => '传真的国际区号必须是数字'));
		$fs[]= new form\FormField('efirstname','post',array(2, 20, '英文姓必须2-20个字符', form\FormField::$VAR_STRING),array('common\FormCheck::isEnglishAndSpace' => '英文姓必须是英文或者拼音'));
		$fs[]= new form\FormField('elastname','post',array(2, 20, '英文名必须2-20个字符', form\FormField::$VAR_STRING),array('common\FormCheck::isEnglishAndSpace' => '英文名必须是英文或者拼音'));
		$fs[]= new form\FormField('eorg','post',array(2, 64, '公司名称必须2-64个字符', form\FormField::$VAR_STRING),array('common\FormCheck::isOkOrg' => '组织机构必须是英文或者拼音'));
		form\FormParser::parse($fs,true);
	}
	
	/**
	 * 设置默认模板提交表单
	 */
	public static function defaultTemplate()
	{
		$fs[] = new form\FormField('EnameId', "post", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		$fs[]= new form\FormField('registc','POST',array(0, form\FormField::$MAX_INT, '注册模板ID错误', form\FormField::$VAR_INT));
		$fs[]= new form\FormField('transferc','POST',array(0, form\FormField::$MAX_INT, '转入模板ID错误', form\FormField::$VAR_INT));
		$fs[]= new form\FormField('pushc','POST',array(0, form\FormField::$MAX_INT, 'PUSH模板ID错误', form\FormField::$VAR_INT));
		$fs[]= new form\FormField('tradec','POST',array(0, form\FormField::$MAX_INT, '交易模板ID错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs,true);
	}
	public static function delTemplate()
	{
		$fs[] = new form\FormField('id',"post",array(1, form\FormField::$MAX_INT, '模板ID错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('EnameId',"post", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		form\FormParser::parse($fs,TRUE);
	}
	public static function templateDetail()
	{
		$fs[] = new form\FormField('id',"get",array(1, form\FormField::$MAX_INT, '模板ID错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('EnameId',"get", array(1, form\FormField::$MAX_INT, "enameID错误",
				form\FormField::$VAR_INT));
		form\FormParser::parse($fs,TRUE);
	}
	
	public static function templateAddExt()
	{
		$fs[] = new form\FormField('enameId',"post", array(1, form\FormField::$MAX_INT, "enameID错误",form\FormField::$VAR_INT));
		$fs[] = new form\FormField('templateId',"post", array(1, form\FormField::$MAX_INT, "模板ID错误",form\FormField::$VAR_INT));
		$fs[] = new form\FormField('status',"post#", array(1, 10, "模板状态错误",form\FormField::$VAR_INT));
		$fs[] = new form\FormField('registrar',"post", array(1, 120, "模板接口错误",form\FormField::$VAR_STRING));
		form\FormParser::parse($fs,TRUE);
	}
	
	public static function templateSetExt()
	{
		$fs[] = new form\FormField('enameId',"post#", array(1, form\FormField::$MAX_INT, "enameID错误",form\FormField::$VAR_INT));
		$fs[] = new form\FormField('templateId',"post", array(1, form\FormField::$MAX_INT, "模板ID错误",form\FormField::$VAR_INT));
		$fs[] = new form\FormField('registrar',"post#", array(1, form\FormField::$MAX_INT, "旧模板接口错误",form\FormField::$VAR_INT));
		$fs[] = new form\FormField('status',"post#", array(1, 10, "模板状态错误",form\FormField::$VAR_INT));
		$fs[] = new form\FormField('newStatus',"post#", array(1, 10, "模板状态错误",form\FormField::$VAR_INT));
		$fs[] = new form\FormField('registrarNew',"post", array(1, form\FormField::$MAX_INT, "模板接口错误",form\FormField::$VAR_STRING));
		form\FormParser::parse($fs,TRUE);
	}
	
	public static function templateGetExt()
	{
		$fs[] = new form\FormField('enameId',"post#", array(1, form\FormField::$MAX_INT, "enameID错误",form\FormField::$VAR_INT));
		$fs[] = new form\FormField('templateId',"post#", array(1, form\FormField::$MAX_INT, "模板ID错误",form\FormField::$VAR_INT));
		$fs[] = new form\FormField('status',"post#", array(1, 10, "模板状态错误",form\FormField::$VAR_INT));
		$fs[] = new form\FormField('registrar',"post#", array(1, 100, "模板接口错误",form\FormField::$VAR_INT));
		form\FormParser::parse($fs,TRUE);
	}
	
	/**
	 * 获取域名可以使用的模板
	 */
	public static function getUseTemplates()
	{
		$fs[] = new form\FormField('enameId',"post", array(1, form\FormField::$MAX_INT, "enameID错误",form\FormField::$VAR_INT));
		$fs[] = new form\FormField('templateType',"post", array(1, 30, "模板类型错误",form\FormField::$VAR_STRING));
		form\FormParser::parse($fs,TRUE);
	}
	
	public static function setTemplateLinkCount()
	{
		$fs[] = new form\FormField('operation',"post#", array(1,1, "operation错误",form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('templateId',"post", array(1, form\FormField::$MAX_INT, "模板ID错误",form\FormField::$VAR_INT));
		form\FormParser::parse($fs,TRUE);
	}
}

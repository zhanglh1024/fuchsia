<?php
namespace form\huodong\activity;
use core\form as form;
class ActivityForm
{

	public static function ActivityList()
	{
		$fs= array();
		$fs[]=new form\FormField("EnameId","GET#",array(1, 99999999999,'用户ID有误',form\FormField::$VAR_INT));
		$fs[]=new form\FormField("pagesize","GET#",array(0,form\FormField::$MAX_INT,'分页标记错误',form\FormField::$VAR_INT));
		$fs[]=new form\FormField("pagenum","GET#",array(0,form\FormField::$MAX_INT,'分页标记错误',form\FormField::$VAR_INT));
		$fs[]=new form\FormField("plat","GET#",array(0,10,'调用平台有误',form\FormField::$VAR_INT));
		$fs[]=new form\FormField("type","GET#",array(0,10,'活动类型有误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs,true);
	}
}

<?php
namespace form\lottery\lottery;
use core\form\FormField;
use core\form\FormParser;
use core\form\FormException;

class ChanceForm
{

	/**
	 * 添加抽奖机会
	 */
	public static function addChance()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "POST", array(1, FormField::$MAX_INT, '用户id错误', FormField::$VAR_INT));
		$fs[] = new FormField('domain', "POST#", array(1, 80, '域名错误', FormField::$VAR_STRING));
		$fs[] = new FormField('expiretime', "POST#", array(1, FormField::$MAX_INT, '过期时间错误', FormField::$VAR_INT));
		$fs[] = new FormField('type', "POST", array(1, 30, '活动类型错误', FormField::$VAR_INT));
		FormParser::parse($fs, true);
	}
	
	/**
	 * 统计抽奖机会
	 */
	public static function getCount()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET#", array(1, FormField::$MAX_INT, '用户id错误', FormField::$VAR_INT));
		$fs[] = new FormField('status', "GET", array(0, 2, '机会状态错误', FormField::$VAR_INT));
		$fs[] = new FormField('type', "GET", array(1, 30, '活动类型错误', FormField::$VAR_INT));
		FormParser::parse($fs, true);
	}
	
	/**
	 * 更新抽奖机会
	 */
	public static function updateChance()
	{
		$fs = array();
		$fs[] = new FormField('chid', "POST", array(1, FormField::$MAX_INT, '用户id错误', FormField::$VAR_INT));
		$fs[] = new FormField('chstatus', "POST", array(0, 2, '机会状态错误', FormField::$VAR_INT));
		FormParser::parse($fs, true);
	}
	
	/**
	 * 使用抽奖机会
	 */
	public static function useChance()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "POST", array(1, FormField::$MAX_INT, '用户id错误', FormField::$VAR_INT));
		$fs[] = new FormField('chid', "POST#", array(1, FormField::$MAX_INT, '用户id错误', FormField::$VAR_INT));
		$fs[] = new FormField('type', "POST", array(1, 30, '活动类型错误', FormField::$VAR_INT));
		FormParser::parse($fs, true);
	}
}
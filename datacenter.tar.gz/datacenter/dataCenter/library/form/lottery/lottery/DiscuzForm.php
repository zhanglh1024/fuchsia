<?php
namespace form\lottery\lottery;
use core\form\FormField;
use core\form\FormParser;
use core\form\FormException;

class DiscuzForm
{

	/**
	 * 获取用户玉米数
	 */
	public static function getUserCredit()
	{
		$fs = array();
		$fs[] = new FormField('EnameId', "GET", array(1, FormField::$MAX_INT, '用户id错误', FormField::$VAR_INT));
		FormParser::parse($fs, true);
	}
	
	/**
	 * 修改用户玉米数
	 */
	public static function updateUserCredit()
	{
		$fs = array();
		$fs[] = new FormField('EnameId', "POST", array(1, FormField::$MAX_INT, '用户id错误', FormField::$VAR_INT));
		$fs[] = new FormField('Credit', "POST", array(1, FormField::$MAX_INT, '基本错误', FormField::$VAR_INT));
		$fs[] = new FormField('Flag', "POST", array(0, 1,'标识错误', FormField::$VAR_INT));
		FormParser::parse($fs, true);
	}
	
}
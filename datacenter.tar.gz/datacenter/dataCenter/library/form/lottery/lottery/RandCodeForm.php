<?php
namespace form\lottery\lottery;
use core\form\FormField;
use core\form\FormParser;
use core\form\FormException;
class RandCodeForm
{
	public static function CreatCode()
	{
		$fs= array();
		$fs[] = new FormField('enameid', "POST", array(1, 99999999999,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('transid', "POST", array(1,FormField::$MAX_INT,'竞价ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'POST', array(1,72,'域名有误',FormField::$VAR_STRING));
		$fs[] = new FormField('bidtime', "POST", array(0,30,'时间有误',FormField::$VAR_STRING),array('\common\FormCheck::checkDate' => '日期格式错误'));
		$fs[] = new FormField('type', "POST", array(1,30,'活动类型错误',FormField::$VAR_INT));
		FormParser::parse($fs,true);
	}
	public static function checkUp()
	{
		$fs= array();
		$fs[] = new FormField('transid', "POST", array(1,FormField::$MAX_INT,'竞价ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('bindprice', "POST", array(1,FormField::$MAX_INT,'结算价格错误',FormField::$VAR_INT));
		FormParser::parse($fs,true);
	}
	public static function checkRecord()
	{
		$fs= array();
		$fs[] = new FormField('setin', 'GET#', array(1,FormField::$MAX_INT,'ID有误',FormField::$VAR_STRING));
		$fs[] = new FormField('enameid', "GET#", array(1, 99999999999,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'GET#', array(1,72,'域名有误',FormField::$VAR_STRING));
		$fs[] = new FormField('pstatus', 'GET#', array(1,4,'是否发放标志有误',FormField::$VAR_INT));
		$fs[] = new FormField('starttime', "GET#", array(1,FormField::$MAX_INT,'时间有误',FormField::$VAR_INT));
		$fs[] = new FormField('endtime', "GET#", array(1,FormField::$MAX_INT,'时间有误',FormField::$VAR_INT));
		$fs[] = new FormField('pagesize', 'GET#', array(1, 99999999, '分页有误!', FormField::$VAR_INT));
		$fs[] = new FormField('pagenum', 'GET#', array(1, 99999999, '每页数量有误!', FormField::$VAR_INT));
		$fs[] = new FormField('type', 'GET#', array(1, FormField::$MAX_INT, '活动类型错误!', FormField::$VAR_INT));
		FormParser::parse($fs,true);
	}
	public static function checkCodeList()
	{
		$fs= array();
		$fs[] = new FormField('enameid', "GET#", array(1, 99999999999,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('chstatus', "GET#", array(0,2,'机会状态错误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'GET#', array(1,72,'域名有误',FormField::$VAR_STRING));
		$fs[] = new FormField('bindtime', "GET#", array(1,FormField::$MAX_INT,'时间有误',FormField::$VAR_INT));
		$fs[] = new FormField('lstatus', "GET#", array(0,2,'中奖状态有误',FormField::$VAR_INT));
		$fs[] = new FormField('randcode', "GET#", array(0,100,'随机码有误',FormField::$VAR_INT));
		$fs[] = new FormField('pagesize', 'GET#', array(1, 99999999, '分页有误!', FormField::$VAR_INT));
		$fs[] = new FormField('pagenum', 'GET#', array(1, 99999999, '每页数量有误!', FormField::$VAR_INT));
		$fs[] = new FormField('setin', 'GET#', array(1,FormField::$MAX_INT,'ID有误',FormField::$VAR_STRING));
		$fs[] = new FormField('awtypeid', "GET#", array(1,FormField::$MAX_INT,'活动类型ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('order', "GET#", array(1,100,'排序错误',FormField::$VAR_STRING));
		FormParser::parse($fs,true);
	}
	public static function getChance()
	{
		$fs= array();
		$fs[] = new FormField('enameid', "GET", array(1, 99999999999,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('chstatus', "GET", array(0,2,'机会状态错误',FormField::$VAR_INT));
		$fs[] = new FormField('type', "GET", array(1,FormField::$MAX_INT,'活动类型ID错误',FormField::$VAR_INT));
		FormParser::parse($fs,true);
	}
	public static function creatAward()
	{
		$fs= array();
		$fs[] = new FormField('awtypeid', "GET#", array(1,FormField::$MAX_INT,'活动类型ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('awid', "GET#", array(1,FormField::$MAX_INT,'ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('amount', 'GET#', array(1,FormField::$MAX_INT,'总数有误',FormField::$VAR_INT));
		$fs[] = new FormField('money', "GET#", array(0,FormField::$MAX_INT,'奖项金额有误',FormField::$VAR_INT));
		$fs[] = new FormField('type', "GET#", array(0,20,'奖项类型',FormField::$VAR_INT));
		$fs[] = new FormField('percent', "GET#", array(0,100,'获奖比例',FormField::$VAR_INT));
		$fs[] = new FormField('remark', 'GET#', array(1, FormField::$MAX_INT, '奖项备注!', FormField::$VAR_STRING));
		$fs[] = new FormField('promoid', 'GET#', array(1,FormField::$MAX_INT,'对应优惠券ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('prompt', 'GET#', array(1,50,'中奖提示语错误',FormField::$VAR_STRING));
		$fs[] = new FormField('starttime', 'GET#', array(1,10,'开始时间错误',FormField::$VAR_STRING));
		$fs[] = new FormField('endtime', 'GET#', array(1,10,'结束时间错误',FormField::$VAR_STRING));
		FormParser::parse($fs,true);
	}
	public static function upBusin()
	{
		$fs= array();
		$fs[] = new FormField('busdate', "GET#", array(0,30,'时间有误',FormField::$VAR_STRING),array('\common\FormCheck::checkDate' => '日期格式错误'));
		$fs[] = new FormField('busin', "GET#", array(1,FormField::$MAX_INT,'创业指数错误',FormField::$VAR_INT));
		FormParser::parse($fs,true);
	}
	
	public static function CreatChance()
	{
		$fs= array();
		$fs[] = new FormField('enameid', "POST", array(1, 99999999999,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'POST', array(1,72,'域名有误',FormField::$VAR_STRING));
		$fs[] = new FormField('expiretime', "POST#", array(0,30,'时间有误',FormField::$VAR_STRING),array('\common\FormCheck::checkDate' => '日期格式错误'));
		$fs[] = new FormField('type', "POST", array(1,30,'活动类型错误',FormField::$VAR_INT));
		FormParser::parse($fs,true);
	}
	
	public static function prized()
	{
		$fs= array();
		$fs[] = new FormField('enameid', "GET", array(1, 99999999999,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('chid', "GET#", array(1,FormField::$MAX_INT,'机会ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('reid', 'GET', array(1,FormField::$MAX_INT,'记录ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('awid', 'GET', array(1,FormField::$MAX_INT,'奖项ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('activityTitle', 'GET#', array(1,100,'活动类型错误',FormField::$VAR_STRING));
		$fs[] = new FormField('typeSon', 'GET#', array(1,FormField::$MAX_INT,'活动子类型错误哦',FormField::$VAR_INT));
		FormParser::parse($fs,true);
	}
}
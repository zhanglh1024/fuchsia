<?php

namespace form\trans\finance;
use core\form\FormField;
use core\form\FormParser;

class FinanceForm
{ 

	public static function getUserFinance()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'GET', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function addOrder()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'GET', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'GET#', array(1,100,'域名有误',FormField::$VAR_STRING));
		$fs[] = new FormField('type', 'GET', array(1,FormField::$MAX_INT,'预订保证金财务类型错误',FormField::$VAR_INT));
		$fs[] = new FormField('price', 'GET', array(0,FormField::$MAX_INT,'预订保证金错误',FormField::$VAR_INT));
		$fs[] = new FormField('linkEnameId', 'GET#', array(1,FormField::$MAX_INT,'enameid错误',FormField::$VAR_INT));
		$fs[] = new FormField('oldOrderId', 'GET#', array(1,FormField::$MAX_INT,'旧订单号错误',FormField::$VAR_INT));
		$fs[] = new FormField('remark', 'GET#', array(1,100,'备注错误',FormField::$VAR_STRING));
		$fs[] = new FormField('remarkHide', 'GET#', array(1,100,'后台备注错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}
	
	public static function userFinanceIn()
	{
		$fs = array();
		$fs[] = new FormField('enameId', 'GET', array(1, FormField::$MAX_INT, '用户ID有误', FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'GET#', array(1, 100, '域名有误', FormField::$VAR_STRING));
		$fs[] = new FormField('inType', 'GET', array(1, FormField::$MAX_INT, '财务类型错误', FormField::$VAR_INT));
		$fs[] = new FormField('price', 'GET', array(1, FormField::$MAX_INT, '金额错误', FormField::$VAR_INT));
		$fs[] = new FormField('moneyType', 'GET#', array(1, FormField::$MAX_INT, '款项类型错误', FormField::$VAR_INT));
		$fs[] = new FormField('remarkHide', 'GET#', array(1, 100, '隐藏备注错误', FormField::$VAR_STRING));
		$fs[] = new FormField('remark', 'GET#', array(1, 100, '备注错误', FormField::$VAR_STRING));
		$fs[] = new FormField('adminId', 'GET#', array(1, FormField::$MAX_INT, 'adminId错误', FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function cancelOrder()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'GET', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('sellerorderid', 'GET', array(1,FormField::$MAX_INT,'订单ID错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function confirmOrder()
	{
		
		$fs = array();
		$fs[] = new FormField('enameid', 'GET#', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('orderid', 'GET', array(1,FormField::$MAX_INT,'订单ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('type', 'GET#', array(1,4,'moneyType错误',FormField::$VAR_INT));
		$fs[] = new FormField('seller', 'GET#', array(1,FormField::$MAX_INT,'卖家ID错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function addPayOrder()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'GET', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('transId', 'GET', array(1,FormField::$MAX_INT,'订单ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('type', 'GET', array(1,FormField::$MAX_INT,'moneyType错误',FormField::$VAR_INT));
		$fs[] = new FormField('price', 'GET', array(1,FormField::$MAX_INT,'价格错误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING),
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		FormParser::parse($fs, TRUE);
	}
	
	public static function getOrderInfo()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'GET', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('orderId', 'GET', array(1,FormField::$MAX_INT,'订单ID错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
	
	
	public static  function getOrderList()
	{
		$fs = array();
		$fs[] = new FormField('enameId', 'GET#', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('orderStatus', 'GET#', array(1,FormField::$MAX_INT,'订单ID状态错误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "GET#", array(1,80,'域名长度错误',FormField::$VAR_STRING),
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		$fs[] = new FormField('orderType', 'GET#', array(1,FormField::$MAX_INT,'订单ID类型错误',FormField::$VAR_INT));
		$fs[] = new FormField('startDate', 'GET#', array(1,FormField::$MAX_INT,'开始时间错误',FormField::$VAR_STRING));
		$fs[] = new FormField('endDate', 'GET#', array(1,FormField::$MAX_INT,'结束时间错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
		
	}

}
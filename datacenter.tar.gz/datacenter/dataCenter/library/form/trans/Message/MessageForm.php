<?php
namespace form\trans\message;

use core\form\FormField;
use core\form\FormParser;
use core\form\FormException;
class MessageForm
{ 
	public static function buyerLateForReply()
	{
		$fs = array();
		$fs[] = new FormField('message', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('email', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('sms', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('seller', 'GET', array(1,FormField::$MAX_INT,'卖家ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING),
				array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		$fs[] = new FormField('sellerprice', 'GET', array(1,FormField::$MAX_INT,'域名价格出错',FormField::$VAR_INT));
		$fs[] = new FormField('operatedate', 'GET', array(0,FormField::$MAX_INT,'操作时间出错',FormField::$VAR_INT));
		$fs[] = new FormField('replyid', 'GET', array(1,FormField::$MAX_INT,'ID有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
}
?>
<?php
namespace form\trans\book;

use \core\form\FormField;
use \core\form\FormParser;
class BookForm
{

	/**
	 * 我的预订域名列表
	 */
	public static function myBookDomain()
	{
		$fs[] = new FormField('enameid', 'GET', array(0,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('flag', 'GET#', array(0,1,'参数有误',FormField::$VAR_INT));
		$fs[] = new FormField('type', 'GET#', array(0,1,'类型有误',FormField::$VAR_INT));
		$fs[] = new FormField('num', 'GET#', array(0,30,'获取个数有误',FormField::$VAR_INT));
		$fs[] = new FormField('year', 'GET#', array(2009,FormField::$MAX_INT,'历史年份有误',FormField::$VAR_INT));
		$fs[] = new FormField('p', 'GET#', array(0,FormField::$MAX_INT,'页码格式错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::isNumber' => '参数格式错误'));
		$fs[] = new FormField('status', 'GET#', array(1,10,'域名状态有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	/**
	 * 可预订推荐域名
	 */
	public static function getRecBookDomain()
	{
		$fs = array();
		$fs[] = new FormField('num', "GET#", array(0,FormField::$MAX_INT,'每页显示数有误',FormField::$VAR_INT));
		$fs[] = new FormField('p', 'GET#', array(0,FormField::$MAX_INT,'页码格式错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::isNumber' => '参数格式错误'));
		FormParser::parse($fs, TRUE);
	}

	/**
	 * 可预订国内域名
	 */
	public static function getCnBookDomain()
	{
		$fs = array();
		$fs[] = new FormField('keyword', "GET#", array(0,30,'关键字长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkDomain' => '域名格式错误'));
		$fs[] = new FormField('pos', "GET#", array(0,FormField::$MAX_INT,'后缀有误',FormField::$VAR_STRING));
		$fs[] = new FormField('unkeyword', "GET#", array(0,30,'关键字长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkDomain' => '域名格式错误'));
		$fs[] = new FormField('lengthstart', "GET#", array(0,30,'起始长度格式有误',FormField::$VAR_INT));
		$fs[] = new FormField('lengthend', "GET#", array(0,70,'结束长度格式有误',FormField::$VAR_INT));
		$fs[] = new FormField('tld', "GET#", array(0,FormField::$MAX_INT,'后缀有误',FormField::$VAR_STRING));
		$fs[] = new FormField('type', "GET#", array(0,21,'类型格式有误',FormField::$VAR_INT));
		$fs[] = new FormField('delday', "GET#", array(0,30,'删除时间有误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkDate' => '日期格式错误'));
		$fs[] = new FormField('ordertype', "GET#", array(0,4,'排序类型有误',FormField::$VAR_INT));
		$fs[] = new FormField('num', "GET#", array(0,FormField::$MAX_INT,'每页显示数有误',FormField::$VAR_INT));
		$fs[] = new FormField('p', 'GET#', array(0,7,'页码格式错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::isNumber' => '参数格式错误'));
		FormParser::parse($fs, TRUE);
	}

	/**
	 * 可预订国际域名
	 */
	public static function getEnBookDomain()
	{
		$fs = array();
		$fs[] = new FormField('keyword', "GET#", array(0,30,'关键字长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkDomain' => '域名格式错误'));
		$fs[] = new FormField('pos', "GET#", array(0,FormField::$MAX_INT,'后缀有误',FormField::$VAR_STRING));
		$fs[] = new FormField('unkeyword', "GET#", array(0,30,'关键字长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkDomain' => '域名格式错误'));
		$fs[] = new FormField('lengthstart', "GET#", array(0,30,'起始长度格式有误',FormField::$VAR_INT));
		$fs[] = new FormField('lengthend', "GET#", array(0,70,'结束长度格式有误',FormField::$VAR_INT));
		$fs[] = new FormField('tld', "GET#", array(0,FormField::$MAX_INT,'后缀有误',FormField::$VAR_STRING));
		$fs[] = new FormField('type', "GET#", array(0,21,'类型格式有误',FormField::$VAR_INT));
		$fs[] = new FormField('delday', "GET#", array(0,30,'删除时间有误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkDate' => '日期格式错误'));
		$fs[] = new FormField('ordertype', "GET#", array(0,4,'排序类型有误',FormField::$VAR_INT));
		$fs[] = new FormField('num', "GET#", array(0,FormField::$MAX_INT,'每页显示数有误',FormField::$VAR_INT));
		$fs[] = new FormField('p', 'GET#', array(0,7,'页码格式错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::isNumber' => '参数格式错误'));
		FormParser::parse($fs, TRUE);
	}

	/**
	 * 预订竞价域名列表
	 */
	public static function getBookDomainList()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'GET#', array(0,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('keyword', 'GET#', array(0,70,'域名长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkDomain' => '域名格式错误'));
		$fs[] = new FormField('pos', "GET#", array(0,FormField::$MAX_INT,'后缀有误',FormField::$VAR_STRING));
		$fs[] = new FormField('domaintld', 'GET#', array(0,10,'域名后缀错误',FormField::$VAR_INT));
		$fs[] = new FormField('domaingroup', 'GET#', array(0,21,'域名分组有误',FormField::$VAR_INT));
		$fs[] = new FormField('finishtime', 'GET#', array(0,70,'时间长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkDate' => '日期格式错误'));
		$fs[] = new FormField('ordertype', 'GET#', array(0,3,'排列方式有误',FormField::$VAR_INT));
		$fs[] = new FormField('num', "GET#", array(0,FormField::$MAX_INT,'每页显示数有误',FormField::$VAR_INT));
		$fs[] = new FormField('p', 'GET#', array(0,7,'页码格式错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::isNumber' => '参数格式错误'));
		FormParser::parse($fs, TRUE);
	}

	/**
	 * 表单预订域名
	 */
	public static function bookDomain()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'POST', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('domainnames', "POST", array(1,FormField::$MAX_INT,'域名长度错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function cancelBook()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'POST', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('id', "POST", array(1,FormField::$MAX_INT,'域名ID错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function domainInfo()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'GET#', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('id', "GET", array(1,FormField::$MAX_INT,'域名ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('isajax', "GET#", array(0,1,'ajax标识错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function getBidRecords()
	{
		$fs = array();
		$fs[] = new FormField('id', "GET", array(1,FormField::$MAX_INT,'域名id有误',FormField::$VAR_INT));
		$fs[] = new FormField('enameid', "GET#", array(1,FormField::$MAX_INT,'用户id有误',FormField::$VAR_INT));
		$fs[] = new FormField('num', 'GET#', array(0,30,'获取个数有误',FormField::$VAR_INT));
		$fs[] = new FormField('p', 'GET#', array(0,FormField::$MAX_INT,FormField::$VAR_INT), 
			array('\common\FormCheck::isNumber' => '参数格式错误'));
		FormParser::parse($fs, TRUE);
	}

	public static function doBookDomain()
	{
		$fs[] = new FormField('enameid', 'POST', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('nickname', "POST", array(1,FormField::$MAX_INT,'昵称不能为空',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkS' => '非法字符'));
		$fs[] = new FormField('endomesticids', "POST#", 
			array(0,FormField::$MAX_INT,'英文国内域名Id错误',FormField::$VAR_INT_ARRAY));
		$fs[] = new FormField('cndomesticids', "POST#", 
			array(0,FormField::$MAX_INT,'中文国内域名Id错误',FormField::$VAR_INT_ARRAY));
		$fs[] = new FormField('eninternationalids', "POST#", 
			array(1,FormField::$MAX_INT,'英文国际域名Id错误',FormField::$VAR_INT_ARRAY));
		$fs[] = new FormField('domainnames', 'POST#', array(1,FormField::$MAX_INT,'过期域名错误',FormField::$VAR_STRING_ARRAY));
		FormParser::parse($fs, TRUE);
	}
	
	public static function getBookAndRecCount()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET#", array(1,FormField::$MAX_INT,'用户id有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
}
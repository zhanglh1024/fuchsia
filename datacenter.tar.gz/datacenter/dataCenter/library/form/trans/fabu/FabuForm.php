<?php
namespace form\trans\fabu;
use core\form\FormField;
use core\form\FormParser;

class FabuForm
{

	public static function auditDomainList()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'GET', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('num', 'GET#', array(0,30,'获取个数有误',FormField::$VAR_INT));
		$fs[] = new FormField('flag', 'GET#', array(0,1,'显示类型有误',FormField::$VAR_INT));
		$fs[] = new FormField('p', 'GET#', array(0,FormField::$MAX_INT,FormField::$VAR_STRING), 
			array('\common\FormCheck::isNumber'=> '参数格式错误'));
		FormParser::parse($fs, TRUE);
	}

	public static function preTradeList()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'GET', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('transtype', 'GET#', array(1,4,'交易类型有误',FormField::$VAR_INT));
		$fs[] = new FormField('num', 'GET#', array(0,30,'获取个数有误',FormField::$VAR_INT));
		$fs[] = new FormField('p', 'GET#', array(0,FormField::$MAX_INT,FormField::$VAR_STRING), 
			array('\common\FormCheck::isNumber'=> '参数格式错误'));
		FormParser::parse($fs, TRUE);
	}

	public static function cancelAudit()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'POST', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('id', 'POST', array(1,FormField::$MAX_INT,'ID有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function delPreTradeDomain()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'POST', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('domainName', "POST", array(1,FormField::$MAX_INT,'域名格式错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkDomain'=> '域名格式错误'));
		FormParser::parse($fs, TRUE);
	}

	public static function fabuTrade()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'POST', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('domainname', "POST", array(1,FormField::$MAX_INT,'域名格式错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkDomain'=> '域名格式错误'));
		$fs[] = new FormField('type', 'POST', array(1,5,'交易类型有误',FormField::$VAR_INT));
		$fs[] = new FormField('transpoundage', 'POST', array(2,3,'手续费有错',FormField::$VAR_INT));
		$fs[] = new FormField('transdate', 'POST#', array(1,FormField::$MAX_INT,'交易结束日期有错',FormField::$VAR_INT));
		$fs[] = new FormField('transtime', 'POST#', array(1,FormField::$MAX_INT,'交易结束时间段有错',FormField::$VAR_INT));
		$fs[] = new FormField('transmoney', 'POST#', array(1,FormField::$MAX_INT,'价格有错',FormField::$VAR_INT));
		$fs[] = new FormField('transdesc', 'POST#', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		$fs[] = new FormField('agent', 'POST#', array(1,FormField::$MAX_INT,'经纪人有错',FormField::$VAR_INT));
		$fs[] = new FormField('transtopic', 'POST#', array(1,FormField::$MAX_INT,'专题有错',FormField::$VAR_INT));
		$fs[] = new FormField('identify', 'POST', 
			array(1,FormField::$MAX_INT,'操作保护标识码有错',FormField::$VAR_STRING));
		$fs[] = new FormField('questionid', 'POS#T', array(1,FormField::$MAX_INT,'操作保护问题有错',FormField::$VAR_INT));
		$fs[] = new FormField('answer', 'POST#', array(1,FormField::$MAX_INT,'操作保护答案有错',FormField::$VAR_STRING));
		$fs[] = new FormField('captcha', 'POST#', 
			array(1,FormField::$MAX_INT,'操作保护验证码有错',FormField::$VAR_STRING));
		$fs[] = new FormField('pass', 'POST#', array(1,FormField::$MAX_INT,'操作保护密码码有错',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function getTransTime()
	{
		$fs = array();
		$fs[] = new FormField('transtype', 'GET', array(1,5,'交易类型有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function getPoundage()
	{
		$fs = array();
		$fs[] = new FormField('flag', 'GET#', array(0,1,'flag有误',FormField::$VAR_INT));
		$fs[] = new FormField('enameid', 'GET', array(1,FormField::$MAX_INT,'用户名Id有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function fabuBeach()
	{
		$fs = array();
		$fs[] = new FormField('domainstext', "POST", array(0,FormField::$MAX_INT,'域名有误',FormField::$VAR_STRING));
		$fs[] = new FormField('type', "POST", array(0,FormField::$MAX_INT,'类型有误',FormField::$VAR_INT));
		$fs[] = new FormField('enameid', "POST", array(1,FormField::$MAX_INT,'enameid有误',FormField::$VAR_INT));
		FormParser::parse($fs, true);
	}

	public static function beachSub()
	{
		$fs = array();
		$fs[] = new FormField('domains', "POST", array(0,FormField::$MAX_INT,'域名有误',FormField::$VAR_STRING));
		$fs[] = new FormField('type', "POST", array(0,FormField::$MAX_INT,'类型有误',FormField::$VAR_INT));
		$fs[] = new FormField('enameid', "POST", array(1,FormField::$MAX_INT,'enameid有误',FormField::$VAR_INT));
		$fs[] = new FormField('identify', 'POST', 
			array(1,FormField::$MAX_INT,'操作保护标识码有错',FormField::$VAR_STRING));
		$fs[] = new FormField('questionid', 'POS#T', array(1,FormField::$MAX_INT,'操作保护问题有错',FormField::$VAR_INT));
		$fs[] = new FormField('answer', 'POST#', array(1,FormField::$MAX_INT,'操作保护答案有错',FormField::$VAR_STRING));
		$fs[] = new FormField('captcha', 'POST#', 
			array(1,FormField::$MAX_INT,'操作保护验证码有错',FormField::$VAR_STRING));
		$fs[] = new FormField('pass', 'POST#', array(1,FormField::$MAX_INT,'操作保护密码码有错',FormField::$VAR_STRING));
		FormParser::parse($fs, true);
	}

	public static function fabuMoreTrade()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'POST', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('domainname', "POST", 
			array(1,FormField::$MAX_INT,'域名格式错误',FormField::$VAR_STRING_ARRAY), 
			array('\common\FormCheck::checkDomain'=> '域名格式错误'));
		$fs[] = new FormField('type', 'POST', array(1,5,'交易类型有误',FormField::$VAR_INT));
		$fs[] = new FormField('transpoundage', 'POST', array(2,3,'手续费有错',FormField::$VAR_INT));
		$fs[] = new FormField('transdate', 'POST#', 
			array(1,FormField::$MAX_INT,'交易结束日期有错',FormField::$VAR_STRING_ARRAY));
		$fs[] = new FormField('transtime', 'POST#', 
			array(1,FormField::$MAX_INT,'交易结束时间段有错',FormField::$VAR_STRING_ARRAY));
		$fs[] = new FormField('transmoney', 'POST#', 
			array(1,FormField::$MAX_INT,'价格有错',FormField::$VAR_INT_ARRAY));
		$fs[] = new FormField('transdesc', 'POST#', 
			array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING_ARRAY));
		$fs[] = new FormField('agent', 'POST#', array(1,FormField::$MAX_INT,'经纪人有错',FormField::$VAR_INT));
		$fs[] = new FormField('transtopic', 'POST#', array(1,FormField::$MAX_INT,'专题有错',FormField::$VAR_INT));
		$fs[] = new FormField('identify', 'POST', 
			array(1,FormField::$MAX_INT,'操作保护标识码有错',FormField::$VAR_STRING));
		$fs[] = new FormField('questionid', 'POS#T', array(1,FormField::$MAX_INT,'操作保护问题有错',FormField::$VAR_INT));
		$fs[] = new FormField('answer', 'POST#', array(1,FormField::$MAX_INT,'操作保护答案有错',FormField::$VAR_STRING));
		$fs[] = new FormField('captcha', 'POST#', 
			array(1,FormField::$MAX_INT,'操作保护验证码有错',FormField::$VAR_STRING));
		$fs[] = new FormField('pass', 'POST#', array(1,FormField::$MAX_INT,'操作保护密码码有错',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function fabuCheck()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'POST', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('domaintext', 'POST', array(1,FormField::$MAX_INT,'域名有误',FormField::$VAR_STRING));
		$fs[] = new FormField('type', 'POST', array(1,5,'交易类型有误',FormField::$VAR_INT));
		FormParser::parse($fs, true);
	}

	public static function batchdelpreDomain()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'POST', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('domainName', "POST", 
			array(1,FormField::$MAX_INT,'域名格式错误',FormField::$VAR_STRING_ARRAY), 
			array('\common\FormCheck::checkDomain'=> '域名格式错误'));
		FormParser::parse($fs, TRUE);
	}

	public static function getMemberVerify()
	{
		$fs = array();
		$fs[] = new FormField('enameId', 'get', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
}
?>
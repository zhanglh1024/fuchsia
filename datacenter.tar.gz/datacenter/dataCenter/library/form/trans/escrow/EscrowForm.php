<?php
namespace form\trans\escrow;
use core\form\FormField;
use core\form\FormParser;
class EscrowForm
{
	public static function addAgencyForm()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'POST#', array(0, FormField::$MAX_INT, '用户ID有误', FormField::$VAR_INT));
		$fs[] = new FormField('domain', "POST", array(1, 72, '域名格式错误', FormField::$VAR_STRING), array(
				'\common\FormCheck::checkFullDomain' => '域名格式错误'));
		$fs[] = new FormField('user', 'POST', array(1, 64, '姓名有误', FormField::$VAR_STRING));
		$fs[] = new FormField('mobile', 'POST', array(1, 14, '手机有错', FormField::$VAR_STRING), array(
				'\common\FormCheck::isMobile' => '手机格式错误'));
		$fs[] = new FormField('email', 'POST', array(1, 100, '邮箱有错', FormField::$VAR_STRING), array(
				'\common\FormCheck::isEmail' => '邮箱格式错误'));
		$fs[] = new FormField('price', 'POST', array(200, FormField::$MAX_INT, '价格必须大于200', FormField::$VAR_INT));
		$fs[] = new FormField('transtype', 'POST', array(1, 2, '交易类型有错', FormField::$VAR_INT));
		$fs[] = new FormField('paytype', 'POST', array(1, 3, '中介费支付方式有错', FormField::$VAR_INT));
		$fs[] = new FormField('otheruser', 'POST#', array(1, 64, '对方联系人姓名有误', FormField::$VAR_STRING));
		$fs[] = new FormField('otheruid', 'POST#', array(1, FormField::$MAX_INT, '对方EnameId有误', FormField::$VAR_INT));
		$fs[] = new FormField('othermobile', 'POST#', array(1, 14, '对方手机有误', FormField::$VAR_STRING), array(
				'\common\FormCheck::isMobile' => '对方手机格式错误'));
		$fs[] = new FormField('otheremail', 'POST#', array(1, 100, '对方邮箱有误', FormField::$VAR_STRING), array(
				'\common\FormCheck::isEmail' => '对方邮箱格式错误'));
		$fs[] = new FormField('version', 'POST#', array(0, 1, '客户端版本错误', FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}
	
	public static function listForm()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'GET', array(1, FormField::$MAX_INT, '用户ID有误', FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'GET#', array(1,72,'域名有误',FormField::$VAR_STRING));
		$fs[] = new FormField('role', 'GET#', array(0,2,'交易方式错误',FormField::$VAR_INT));
		$fs[] = new FormField('transtype', "GET", array(1, 3, '交易类型错误', FormField::$VAR_INT));
		$fs[] = new FormField('status', 'GET#', array(0, 2, '状态有误', FormField::$VAR_INT));
		$fs[] = new FormField('flag', 'GET#', array(0, 1, '标识有误', FormField::$VAR_INT));
		$fs[] = new FormField('num', 'GET#', array(0,30,'获取个数有误',FormField::$VAR_INT));
		$fs[] = new FormField('p', 'GET#', array(0,FormField::$MAX_INT,FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
	
	public static function addEscrow()
	{
		$fs = array();
		$fs[] = new FormField('domainname', "GET#", array(1, 72, '域名格式错误', FormField::$VAR_STRING), array(
			'\common\FormCheck::checkFullDomain' => '域名格式错误'));
		$fs[] = new FormField('enameid', 'GET#', array(1, FormField::$MAX_INT, '用户ID有误', FormField::$VAR_INT));
		$fs[] = new FormField('linkman', 'GET#', array(1,FormField::$MAX_INT,'联系人有误',FormField::$VAR_STRING));
		$fs[] = new FormField('telphone', 'GET#', array(1,FormField::$MAX_INT,'联系电话有误',FormField::$VAR_STRING));
		$fs[] = new FormField('email', 'GET#', array(1,FormField::$MAX_INT,'联系邮箱有误',FormField::$VAR_STRING));
		$fs[] = new FormField('price', 'GET#', array(1, FormField::$MAX_INT, '价格有误', FormField::$VAR_INT));
		$fs[] = new FormField('paytype', 'GET#', array(1, 3, '中介费支付方式有误', FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
	
	public static function info()
	{
		$fs = array();
		$fs[] = new FormField('id', 'GET#', array(1, FormField::$MAX_INT, 'ID有误', FormField::$VAR_INT));
		$fs[] = new FormField('enameid', 'GET', array(1, FormField::$MAX_INT, '用户ID有误', FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
	
	public static function escrowSure()
	{
		$fs = array();
		$fs[] = new FormField('enameid', 'GET', array(1, FormField::$MAX_INT, '用户ID有误', FormField::$VAR_INT));
		$fs[] = new FormField('id', 'GET', array(1, FormField::$MAX_INT, 'id有误', FormField::$VAR_INT));
		FormParser::parse($fs,TRUE);
	}
	
	public static function getAgentByEnameId()
	{
		$fs = array();
		$fs[] = new FormField('enameids', 'GET', array(1, FormField::$MAX_INT, '用户ID有误', FormField::$VAR_STRING));
		FormParser::parse($fs,TRUE);
	}

}
?>
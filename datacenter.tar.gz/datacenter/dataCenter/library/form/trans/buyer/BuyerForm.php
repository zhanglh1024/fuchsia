<?php
namespace form\trans\buyer;

use core\form\FormField;
use core\form\FormParser;
	class BuyerForm
	{
		public static function userBid()
		{
			$fs = array();
			$fs[] = new FormField('enameid', 'GET', array(1,FormField::$MAX_INT,'用户ID有误',FormField::$VAR_INT));
			$fs[] = new FormField('num','GET#',array(0,30,'获取个数有误',FormField::$VAR_INT));
			$fs[] = new FormField('p','GET#',array(0,FormField::$MAX_INT,FormField::$VAR_STRING),array('\common\FormCheck::isNumber' => '参数格式错误'));
			$fs[] = new FormField('type', 'GET#', array(0,1,'type有误',FormField::$VAR_INT));
			$fs[] = new FormField('flag', 'GET#', array(0,1,'flag有误',FormField::$VAR_INT));
			FormParser::parse($fs,TRUE);
		}		
	}
?>
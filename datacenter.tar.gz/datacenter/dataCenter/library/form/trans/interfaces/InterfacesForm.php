<?php
namespace form\trans\interfaces;
use core\form\FormField;
use core\form\FormParser;
use core\form\FormException;

class InterfacesForm
{ 
 
	public static function regInfoForm()  
	{
		$fs = array();
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		FormParser::parse($fs, TRUE);
	}

	public static function confirmTransOrder()
	{
		$fs = array();
		$fs[] = new FormField('seller', "#POST", array(1,FormField::$MAX_INT,'卖家ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('buyer', "POST", array(1,FormField::$MAX_INT,'买家ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('orderId', "POST", array(1,FormField::$MAX_INT,'订单id错误',FormField::$VAR_INT));
		$fs[] = new FormField('moneyType', "#POST", array(1,FormField::$MAX_INT,'金额类型错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function sendCaptcha()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		$fs[] = new FormField('purpose', "GET", array(1,4,'purpose有误',FormField::$VAR_STRING));
		$fs[] = new FormField('smsconfig', "GET#", array(1,100,'smsconfig有误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function checkIsUnReg()
	{
		$fs = array();

		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		FormParser::parse($fs, TRUE);
	}

	public static function checkDomain()
	{
		$fs = array();
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		FormParser::parse($fs, TRUE);
	}

	public static function checkEnameId()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function lockDomain()
	{
		$fs = array();
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		$fs[] = new FormField('remark', "GET#", array(1,200,'备注长度错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function addSecureWarning()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		$fs[] = new FormField('businesstype', "GET", array(1,10,'类型有误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		$fs[] = new FormField('content', "GET#", array(1,200,'备注长度错误',FormField::$VAR_STRING));
		$fs[] = new FormField('priority', "GET", array(1,10,'参数有误',FormField::$VAR_INT));
		$fs[] = new FormField('ip', "GET#", array(1,15,'IP错误',FormField::$VAR_STRING));
		$fs[] = new FormField('ext', "GET#", array(1,200,'参数错误',FormField::$VAR_STRING));
		$fs[] = new FormField('createdate', "GET#", array(1,FormField::$MAX_INT,'时间有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function domainBatchRegistQuery()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		$fs[] = new FormField('domains', "GET", array(1,65535,'域名长度错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function isBindMobile()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function creatCode()
	{
		$fs = array();
		$fs[] = new FormField('transid', 'GET', array(1,FormField::$MAX_INT,'交易id有误',FormField::$VAR_INT));
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		$fs[] = new FormField('bidtime', 'GET', array(1,FormField::$MAX_INT,'出价时间有误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function addChance()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		$fs[] = new FormField('time', 'GET', array(1,FormField::$MAX_INT,'过期时间有误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function getDomainUs()
	{
		$fs = array();
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		FormParser::parse($fs, TRUE);
	}

	public static function getDomainGroup()
	{
		$fs = array();
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		FormParser::parse($fs, TRUE);
	}

	public static function getDomainForUser()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function getDomainStatus()
	{
		$fs = array();
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function canelOrder()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		$fs[] = new FormField('bookid', "GET", array(0,FormField::$MAX_INT,'bookid有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function sendReplyMess()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('price', "POST", array(1,FormField::$MAX_INT,'报价错误',FormField::$VAR_INT));
		$fs[] = new FormField('replyId', "POST", array(5,20,'询价回复ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('noticeCode', 'POST', array(1,FormField::$MAX_INT,'识别码有错',FormField::$VAR_STRING));
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		$fs[] = new FormField('flag', "POST", array(1,2,'标记错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function sendRefuseMess()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('replyId', "POST", array(5,20,'询价回复ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		$fs[] = new FormField('flag', "POST", array(1,2,'标记错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function sendToEscrowMess()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('replyId', "POST", array(5,20,'询价回复ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('esid', "POST", array(1,FormField::$MAX_INT,'经纪ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		$fs[] = new FormField('flag', "POST", array(1,2,'标记错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function sendApplyMess()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('replyId', "POST", array(5,20,'询价回复ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('day', "POST", array(1,FormField::$MAX_INT,'申请延期天数错误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		$fs[] = new FormField('flag', "POST", array(1,2,'标记错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function sendAgreeApplyMess()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('replyId', "POST", array(5,20,'询价回复ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('day', "POST", array(1,FormField::$MAX_INT,'申请延期天数错误',FormField::$VAR_INT));
		$fs[] = new FormField('deadLine', "POST", array(1,FormField::$MAX_INT,'确认操作时间错误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		$fs[] = new FormField('flag', "POST", array(1,2,'标记错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function sendRefuseAgreeApplyMess()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('replyId', "POST", array(5,20,'询价回复ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('day', "POST", array(1,FormField::$MAX_INT,'申请延期天数错误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		$fs[] = new FormField('flag', "POST", array(1,2,'标记错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function sendInquirySuccessMess()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('replyId', "POST", array(5,20,'询价回复ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('price', "POST", array(1,FormField::$MAX_INT,'成交价错误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		$fs[] = new FormField('flag', "POST", array(1,2,'标记错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function sendBuyerConfirmMess()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('replyId', "POST", array(5,20,'询价回复ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('price', "POST", array(1,FormField::$MAX_INT,'成交价错误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		$fs[] = new FormField('noticeCode', 'POST#', array(1,FormField::$MAX_INT,'识别码有错',FormField::$VAR_STRING));
		$fs[] = new FormField('date', 'POST', array(1,FormField::$MAX_INT,'操作时间有错',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function domainPush()
	{
		$fs = array();
		$fs[] = new FormField('seller', "POST", array(1,FormField::$MAX_INT,'卖家ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('buyer', "POST", array(1,FormField::$MAX_INT,'买家ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING_ARRAY));
		$fs[] = new FormField('isnewinter', 'POST#', array(0,1,'标志位有误',FormField::$VAR_INT));
		$fs[] = new FormField('isLock', 'POST#', array(0,3,'标志位有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function auctionDomainPush()
	{
		$fs = array();
		$fs[] = new FormField('seller', "POST", array(1,FormField::$MAX_INT,'卖家ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('buyer', "POST", array(1,FormField::$MAX_INT,'买家ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}
	
	public static function lockInquiryDomain()
	{
		$fs = array();
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function createInquiryOrder()
	{
		$fs = array();
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		$fs[] = new FormField('seller', "POST", array(1,FormField::$MAX_INT,'卖家ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('buyer', "POST", array(1,FormField::$MAX_INT,'买家ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('type', "POST", array(1,FormField::$MAX_INT,'订单类型错误',FormField::$VAR_INT));
		$fs[] = new FormField('oldOrderId', "POST#", array(1,FormField::$MAX_INT,'订单ID错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function transBuyerOrder()
	{
		$fs = array();
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		$fs[] = new FormField('seller', "POST#", array(1,FormField::$MAX_INT,'卖家ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('buyer', "POST", array(1,FormField::$MAX_INT,'买家ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('type', "POST", array(1,FormField::$MAX_INT,'财务类型错误',FormField::$VAR_INT));
		$fs[] = new FormField('oldOrderId', "POST#", array(0,FormField::$MAX_INT,'订单ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('price', "POST", array(1,FormField::$MAX_INT,'提交的价格有错',FormField::$VAR_INT));
		$fs[] = new FormField('transType', "POST#", array(1,FormField::$MAX_INT,'交易类型有错',FormField::$VAR_INT));
		$fs[] = new FormField('remark', "POST#", array(1,FormField::$MAX_INT,'备注有错',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function createBuyerOrder()
	{
		$fs = array();
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		$fs[] = new FormField('seller', "POST", array(1,FormField::$MAX_INT,'卖家ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('buyer', "POST", array(1,FormField::$MAX_INT,'买家ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('type', "POST", array(1,FormField::$MAX_INT,'订单类型错误',FormField::$VAR_INT));
		$fs[] = new FormField('price', "POST", array(1,FormField::$MAX_INT,'保证金错误',FormField::$VAR_INT));
		
		FormParser::parse($fs, TRUE);
	}

	public static function cancelInquiryOrder()
	{
		$fs = array();
		$fs[] = new FormField('seller', "POST", array(1,FormField::$MAX_INT,'卖家ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('orderId', "POST", array(1,FormField::$MAX_INT,'卖家保证金id错误',FormField::$VAR_INT));
		$fs[] = new FormField('moneyType', "POST#", array(1,FormField::$MAX_INT,'保证金类型错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function setDomainMyStatus()
	{
		$fs = array();
		$fs[] = new FormField('domain', "POST", array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		$fs[] = new FormField('status', "POST", array(1,FormField::$MAX_INT,'状态错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function inquiryOperation()
	{
		$fs = array();
		$fs[] = new FormField('EnameId', "POST", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('identify', 'POST', array(1,FormField::$MAX_INT,'操作保护标识码有错',FormField::$VAR_STRING));
		$fs[] = new FormField('questionId', 'POST#', array(1,FormField::$MAX_INT,'操作保护问题有错',FormField::$VAR_INT));
		$fs[] = new FormField('answer', 'POST#', array(1,FormField::$MAX_INT,'操作保护答案有错',FormField::$VAR_STRING));
		$fs[] = new FormField('captcha', 'POST#', array(1,FormField::$MAX_INT,'操作保护验证码有错',FormField::$VAR_STRING));
		$fs[] = new FormField('pass', 'POST#', array(1,FormField::$MAX_INT,'操作保护密码码有错',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function buyerSucessSend()
	{
		$fs = array();
		$fs[] = new FormField('message', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('email', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('sms', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('buyer', 'GET', array(1,FormField::$MAX_INT,'买家ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		$fs[] = new FormField('id', 'GET', array(1,FormField::$MAX_INT,'交易ID有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function buyerSucessSendSeller()
	{
		$fs = array();
		$fs[] = new FormField('message', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('email', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('createdate', 'GET', array(0,FormField::$MAX_INT,'创建时间出错',FormField::$VAR_STRING));
		$fs[] = new FormField('sms', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('price', 'GET', array(0,FormField::$MAX_INT,'域名价格出错',FormField::$VAR_STRING));
		$fs[] = new FormField('nowtime', 'GET', array(0,FormField::$MAX_INT,'时间错误',FormField::$VAR_STRING));
		$fs[] = new FormField('seller', 'GET', array(1,FormField::$MAX_INT,'卖家ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		$fs[] = new FormField('id', 'GET', array(1,FormField::$MAX_INT,'交易ID有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function getSecuritySetting()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('code', 'GET', array(1,FormField::$MAX_INT,'操作保护标识码有错',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function getOperateProtection()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('code', 'GET', array(1,FormField::$MAX_INT,'操作保护标识码有错',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function sendCancelMess()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('replyId', "POST", array(1,FormField::$MAX_INT,'询价回复ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('domain', 'POST', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		$fs[] = new FormField('flag', "POST", array(1,4,'标记错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function unEnoughPay()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('money', "POST", array(1,FormField::$MAX_INT,'保证金错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
	
	public static function sendBuynowSuccessBuyer()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('price', "GET", array(1,FormField::$MAX_INT,'交易金额错误',FormField::$VAR_INT));
		$fs[] = new FormField('id', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('nowTime', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('domainName', "GET", array(1,FormField::$MAX_INT,'域名错误',FormField::$VAR_STRING));
		FormParser::parse($fs,TRUE);
	}
	
	public static function sendBuynowSuccessSeller()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('price', "GET", array(1,FormField::$MAX_INT,'交易金额错误',FormField::$VAR_INT));
		$fs[] = new FormField('id', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('nowTime', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('domainName', "GET", array(1,FormField::$MAX_INT,'域名错误',FormField::$VAR_STRING));
		FormParser::parse($fs,TRUE);
	}
	
	public static function sendAuctionSuccessBuyer()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('id', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('domainName', "GET", array(1,FormField::$MAX_INT,'域名错误',FormField::$VAR_STRING));
		FormParser::parse($fs,TRUE);
	}
	
	public static  function sendAuctionSuccessSeller()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('id', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('domainName', "GET", array(1,FormField::$MAX_INT,'域名错误',FormField::$VAR_STRING));
		FormParser::parse($fs,TRUE);
	}
	
	public static function getMemberSettingByIdentifier()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		$fs[] = new FormField('code', 'GET', array(1,FormField::$MAX_INT,'操作保护标识码有错',FormField::$VAR_STRING));
		$fs[] = new FormField('version', 'GET#', array(1,2,'语言版本有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function isUsedTimes()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function checkOperateProtection()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('questionid', 'GET', array(0,FormField::$MAX_INT,'操作保护问题ID有错',FormField::$VAR_INT));
		$fs[] = new FormField('answer', 'GET', array(0,FormField::$MAX_INT,'操作保护答案有错',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function checkPass()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('pass', 'GET', array(0,FormField::$MAX_INT,'密码错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function checkLimited()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('flag', 'GET', array(0,1,'参数错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function buynowSuccessSellerNoteName()
	{
		$fs = array();
		$fs[] = new FormField('message', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('email', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('createdate', 'GET', array(0,FormField::$MAX_INT,'创建时间出错',FormField::$VAR_STRING));
		$fs[] = new FormField('sms', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('price', 'GET', array(0,FormField::$MAX_INT,'域名价格出错',FormField::$VAR_STRING));
		$fs[] = new FormField('nowtime', 'GET', array(0,FormField::$MAX_INT,'时间错误',FormField::$VAR_STRING));
		$fs[] = new FormField('seller', 'GET', array(1,FormField::$MAX_INT,'卖家ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		$fs[] = new FormField('id', 'GET', array(1,FormField::$MAX_INT,'交易ID有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function buynowSuccessSeller()
	{
		$fs = array();
		$fs[] = new FormField('message', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('email', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('createdate', 'GET', array(0,FormField::$MAX_INT,'创建时间出错',FormField::$VAR_STRING));
		$fs[] = new FormField('sms', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('price', 'GET', array(0,FormField::$MAX_INT,'域名价格出错',FormField::$VAR_STRING));
		$fs[] = new FormField('nowtime', 'GET', array(0,FormField::$MAX_INT,'时间错误',FormField::$VAR_STRING));
		$fs[] = new FormField('seller', 'GET', array(1,FormField::$MAX_INT,'卖家ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		FormParser::parse($fs, TRUE);
	}
	
	public static function sendBookMsg()
	{
		$fs = array();
		$fs[] = new FormField('message', 'POST', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('email', 'POST', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('sms', 'POST', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('title', 'POST', array(0,FormField::$MAX_INT,'标题错误',FormField::$VAR_STRING));
		$fs[] = new FormField('getNum', 'POST', array(0,FormField::$MAX_INT,'数量错误',FormField::$VAR_INT));
		$fs[] = new FormField('auctionNum', 'POST', array(0,FormField::$MAX_INT,'竞价数量错误',FormField::$VAR_INT));
		$fs[] = new FormField('enameId', 'POST', array(1,FormField::$MAX_INT,'enameId错误',FormField::$VAR_INT));
		$fs[] = new FormField('content', "POST", array(1,FormField::$MAX_INT,'内容错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function buynowSuccessBuyer()
	{
		$fs = array();
		$fs[] = new FormField('id', 'GET', array(0,100,'ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('message', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('email', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('createdate', 'GET', array(0,FormField::$MAX_INT,'创建时间出错',FormField::$VAR_STRING));
		$fs[] = new FormField('sms', 'GET', array(0,1,'参数错误',FormField::$VAR_INT));
		$fs[] = new FormField('price', 'GET', array(0,FormField::$MAX_INT,'域名价格出错',FormField::$VAR_STRING));
		$fs[] = new FormField('nowtime', 'GET', array(0,FormField::$MAX_INT,'时间错误',FormField::$VAR_STRING));
		$fs[] = new FormField('buyer', 'GET', array(1,FormField::$MAX_INT,'卖家ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		FormParser::parse($fs, TRUE);
	}

	public static function sendDeliveryBuyerapply()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('id', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('day', "GET", array(1,FormField::$MAX_INT,'申请延期天数错误',FormField::$VAR_INT));
		$fs[] = new FormField('domainName', "GET", array(1,FormField::$MAX_INT,'域名错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}
	
	public static function sendDeliverySellerapply()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('id', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('day', "GET", array(1,FormField::$MAX_INT,'申请延期天数错误',FormField::$VAR_INT));
		$fs[] = new FormField('domainName', "GET", array(1,FormField::$MAX_INT,'域名错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}
	
	public static function sendDeliverySellerapllyBuyerrefuse()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('id', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('day', "GET", array(1,FormField::$MAX_INT,'申请延期天数错误',FormField::$VAR_INT));
		$fs[] = new FormField('domainName', "GET", array(1,FormField::$MAX_INT,'域名错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}
	
	public static function sendDeliveryBuyerapllySellerrefuse()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('id', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('day', "GET", array(1,FormField::$MAX_INT,'申请延期天数错误',FormField::$VAR_INT));
		$fs[] = new FormField('domainName', "GET", array(1,FormField::$MAX_INT,'域名错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}
	
	public static function sendDeliverySellerapplyBuyeragree()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('id', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('day', "GET", array(1,FormField::$MAX_INT,'申请延期天数错误',FormField::$VAR_INT));
		$fs[] = new FormField('domainName', "GET", array(1,FormField::$MAX_INT,'域名错误',FormField::$VAR_STRING));
		$fs[] = new FormField('deadLine', "GET", array(1,FormField::$MAX_INT,'删除日期错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}
	
	public static function sendDeliveryBuyerapllySelleragree()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('id', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('day', "GET", array(1,FormField::$MAX_INT,'申请延期天数错误',FormField::$VAR_INT));
		$fs[] = new FormField('domainName', "GET", array(1,FormField::$MAX_INT,'域名错误',FormField::$VAR_STRING));
		$fs[] = new FormField('deadLine', "GET", array(1,FormField::$MAX_INT,'删除日期错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function sendAuctionBuyerrefuseBuyer()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('flag', "GET", array(0,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('nowTime', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('domainName', "GET", array(1,FormField::$MAX_INT,'域名错误',FormField::$VAR_STRING));
		FormParser::parse($fs,TRUE);
	}
	
	public static function sendAuctionBuyerrefuseSeller()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('nowTime', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('domainName', "GET", array(1,FormField::$MAX_INT,'域名错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}
	
	public static function sendAuctionSellerrefuseSeller()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('flag', "GET", array(0,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('nowTime', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('domainName', "GET", array(1,FormField::$MAX_INT,'域名错误',FormField::$VAR_STRING));
		FormParser::parse($fs,TRUE);
	}
	
	public static function sendAuctionSellerrefuseBuyer()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('nowTime', "GET", array(1,FormField::$MAX_INT,'交易ID错误',FormField::$VAR_STRING));
		$fs[] = new FormField('domainName', "GET", array(1,FormField::$MAX_INT,'域名错误',FormField::$VAR_STRING));
		FormParser::parse($fs,TRUE);
	}
	
	public static function sendMobileSmsCaptcha()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('config', 'GET', array(1,FormField::$MAX_INT,'验证码配置文件出错',FormField::$VAR_STRING));
		$fs[] = new FormField('purpose', 'GET', array(1,FormField::$MAX_INT,'参数错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function checkOperateDataBuyNow()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('captcha', '#GET', array(0,FormField::$MAX_INT,'手机验证码有错误',FormField::$VAR_STRING));
		$fs[] = new FormField('identify', 'GET', array(1,FormField::$MAX_INT,'参数错误',FormField::$VAR_STRING));
		$fs[] = new FormField('questionId', '#GET', array(1,FormField::$MAX_INT,'问题ID参数错误',FormField::$VAR_STRING));
		$fs[] = new FormField('answer', '#GET', array(1,FormField::$MAX_INT,'问题答案参数错误',FormField::$VAR_STRING));
		$fs[] = new FormField('pass', '#GET', array(1,FormField::$MAX_INT,'密码错误',FormField::$VAR_STRING));
		$fs[] = new FormField('noused', '#GET', array(0,1,'不设为已用的标志位错误',FormField::$VAR_INT));
		$fs[] = new FormField('version', 'GET#', array(1,2,'语言版本有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function checkIdEmailVerify()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('email', "GET", array(1,FormField::$MAX_INT,'邮箱长度错误'));
		FormParser::parse($fs, TRUE);
	}
	
	public static function checkDnbbsAuth()
	{ 
		$fs = array();
		$fs[] = new FormField('enameId', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
	
	public static function getOperateData()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('identify', "POST", array(1,FormField::$MAX_INT,'操作标识符错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	
	public static function getDomainDate()
	{
		$fs = array();
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING), 
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		FormParser::parse($fs, TRUE);
	}
	public static function getDomainLtd()
	{
		$fs = array();
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING),
			array('\common\FormCheck::checkFullDomain'=> '域名格式错误'));
		FormParser::parse($fs, TRUE);
	}
	public static function getEmailByEnameId()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
	
	public static function sendSmsRemind()
	{
		$fs = array();
		$fs[] = new FormField('id', "GET", array(1,FormField::$MAX_INT,'ID错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	} 
	public static function checkKeyWords()
	{
		$fs = array();
		$fs[] = new FormField('word', "GET", array(1,2000,'关键字错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}
	
	public static function checkIsBlackDomain()
	{
		$fs = array();
		$fs[] = new FormField('enameIdOrDoamin', "POST", array(1,2000,'域名错误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}
	
	public static function sendBookSucc()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "GET", array(1,FormField::$MAX_INT,'用户ID错误',FormField::$VAR_INT));
		$fs[] = new FormField('bookDomain', 'GET', array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function isHasPushDomain()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "GET", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		$fs[] = new FormField('end', 'GET', array(1,FormField::$MAX_INT,'结束时间有误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "GET", array(1,80,'域名长度错误',FormField::$VAR_STRING),array('\common\FormCheck::checkFullDomain' => '域名格式错误'));
		$fs[] = new FormField('start', 'GET', array(1,FormField::$MAX_INT,'开始时间有误',FormField::$VAR_INT));
		$fs[] = new FormField('ismanage', 'GET', array(0,1,'是否是管理有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
	/**
	 * 新版交易
	 */
	public static function getAcceptInfo()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "GET", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
	
	/**
	 * 新版交易
	 */
	public static function sendSiteMsg()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		$fs[] = new FormField('templateId', "POST", array(1,FormField::$MAX_INT,'templateId有误',FormField::$VAR_STRING));
		$fs[] = new FormField('type', "POST", array(1,FormField::$MAX_INT,'type有误',FormField::$VAR_INT));
		FormParser::parse($fs,TRUE);
	}
	/**
	 * 新版交易
	 */
	public static function sendMail()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		$fs[] = new FormField('templateId', "POST", array(1,FormField::$MAX_INT,'templateId有误',FormField::$VAR_STRING));
		$fs[] = new FormField('email', "POST", array(1,FormField::$MAX_INT,'type有误',FormField::$VAR_STRING),array('\common\FormCheck::isEmail' => '邮箱格式错误'));
		$fs[] = new FormField('priority', "POST#", array(1,5,'priority有误',FormField::$VAR_INT));
		FormParser::parse($fs,TRUE);
	}
	
	/**
	 * 新版交易
	 */
	public static function sendSms()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'enameId有误',FormField::$VAR_INT));
		$fs[] = new FormField('templateId', "POST", array(1,FormField::$MAX_INT,'templateId有误',FormField::$VAR_STRING));
		$fs[] = new FormField('phone', "POST", array(1,FormField::$MAX_INT,'type有误',FormField::$VAR_STRING),array('\common\FormCheck::isMobile' => '手机号码格式错误'));
		$fs[] = new FormField('priority', "POST#", array(1,5,'priority有误',FormField::$VAR_INT));
		FormParser::parse($fs,TRUE);
	}
	
	public static function userFinanceIn()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'出款enameid有误',FormField::$VAR_INT));
		$fs[] = new FormField('price', "POST", array(0,FormField::$MAX_INT,'金额有误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "POST", array(1,FormField::$MAX_INT,'域名有误',FormField::$VAR_STRING), array('\common\FormCheck::checkFullDomain' => '域名格式错误'));
		$fs[] = new FormField('moneyType', "POST", array(1,FormField::$MAX_INT,'金额类型有误',FormField::$VAR_INT));
		$fs[] = new FormField('remark', "POST", array(0,200,'备注有误',FormField::$VAR_STRING));
		FormParser::parse($fs,TRUE);
	}
	
	public static function userFinanceOut()
	{
		$fs = array();
		$fs[] = new FormField('enameId', "POST", array(1,FormField::$MAX_INT,'出款enameid有误',FormField::$VAR_INT));
		$fs[] = new FormField('price', "POST", array(0,FormField::$MAX_INT,'金额有误',FormField::$VAR_INT));
		$fs[] = new FormField('domain', "POST", array(1,FormField::$MAX_INT,'域名有误',FormField::$VAR_STRING), array('\common\FormCheck::checkFullDomain' => '域名格式错误'));
		$fs[] = new FormField('moneyType', "POST", array(1,FormField::$MAX_INT,'金额类型有误',FormField::$VAR_INT));
		$fs[] = new FormField('remark', "POST", array(0,200,'备注有误',FormField::$VAR_STRING));
		FormParser::parse($fs,TRUE);
	}
	
	public static function setBatchDomainMyStatus()
	{
		$fs = array();
		$fs[] = new FormField('domain', "POST", array(1,FormField::$MAX_INT,'域名有错',FormField::$VAR_STRING_ARRAY));
		$fs[] = new FormField('status', "POST", array(1,FormField::$MAX_INT,'状态错误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
}
?>

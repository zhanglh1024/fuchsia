<?php

namespace form\trans\domain;
use core\form\FormField;
use core\form\FormParser;

class DomainForm
{

	public static function getDomainGroup()
	{
		$fs = array();
		$fs[] = new FormField('domain', 'GET', array(0,FormField::$MAX_INT,'域名有误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

	public static function getDomainEnameId()
	{
		$fs = array();
		$fs[] = new FormField('domain', 'GET', array(0,FormField::$MAX_INT,'域名有误',FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}
	
	public static function getDomainForUser()
	{
		$fs = array();
		$fs[] = new FormField('domain', 'GET', array(0, FormField::$MAX_INT, '域名有误',FormField::$VAR_STRING));
		$fs[] = new FormField('enameid', 'GET', array(0, FormField::$MAX_INT, '用户ID错误',FormField::$VAR_INT));
		FormParser::parse($fs,TRUE);
	}
	
	public static function checkQQDomain()
	{
		$fs = array();
		$fs[] = new FormField('domain', 'GET', array(0, FormField::$MAX_INT, '域名有误',FormField::$VAR_STRING));
		FormParser::parse($fs,TRUE);
	}
}

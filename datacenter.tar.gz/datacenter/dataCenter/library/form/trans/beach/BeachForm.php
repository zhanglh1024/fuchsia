<?php
namespace form\trans\beach;
use core\form\FormField;
use core\form\FormParser;
		class BeachForm
	{
		public static function index()
		{
			$fs = array();
			$fs[] = new FormField('tid', "GET#", array(0,FormField::$MAX_INT,'分类id有误',FormField::$VAR_INT));
			$fs[] = new FormField('day', "GET#", array(0,FormField::$MAX_INT,'分类id有误',FormField::$VAR_STRING),array('\common\FormCheck::isDate'=>'日期格式不合法'));
			$fs[] = new FormField('flag','GET#',array(0,1,'flag有误',FormField::$VAR_INT));
			$fs[] = new FormField('version','GET#',array(1,FormField::$MAX_INT,'版本有误',FormField::$VAR_INT));
			FormParser::parse($fs,TRUE);
		}
		
		public static function more()
		{
			$fs = array();
			$fs[] = new FormField('cid', "GET#", array(0,FormField::$MAX_INT,'分类id有误',FormField::$VAR_INT));
			$fs[] = new FormField('version', "GET#", array(0,8,'版本有误',FormField::$VAR_INT));
			$fs[] = new FormField('p', "GET#", array(0,FormField::$MAX_INT,'',FormField::$VAR_INT));
			$fs[] = new FormField('enameid', "GET#", array(0,FormField::$MAX_INT,'enameid有误',FormField::$VAR_INT));
			$fs[] = new FormField('domainname', "GET#", array(0,FormField::$MAX_INT,'域名有误',FormField::$VAR_STRING));
			$fs[] = new FormField('domaintld', "GET#", array(0,FormField::$MAX_INT,'后缀有误',FormField::$VAR_INT));
			$fs[] = new FormField('type', "GET#", array(0,FormField::$MAX_INT,'分类有误',FormField::$VAR_INT));
			FormParser::parse($fs,true);
		}
		
		public static function domain()
		{
			$fs = array();
			$fs[] = new FormField('id', "GET", array(0,FormField::$MAX_INT,'id有误',FormField::$VAR_INT));
			$fs[] = new FormField('version', "GET#", array(0,FormField::$MAX_INT,'版本有误',FormField::$VAR_INT));
			$fs[] = new FormField('enameId', "GET#", array(0,FormField::$MAX_INT,'enameid有误',FormField::$VAR_INT));
			FormParser::parse($fs,true);
		}
	}
?>
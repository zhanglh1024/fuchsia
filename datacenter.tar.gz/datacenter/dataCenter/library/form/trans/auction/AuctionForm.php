<?php
	namespace form\trans\auction;
	use core\form\FormField;
	use core\form\FormParser;
	class AuctionForm
	{
		public static function topic()
		{
			$fs = array();
			$fs[] = new FormField('tid', "GET#", array(0,FormField::$MAX_INT,'分类id有误',FormField::$VAR_INT));
			$fs[] = new FormField('day', "GET#", array(0,FormField::$MAX_INT,'分类id有误',FormField::$VAR_STRING),array('\common\FormCheck::isDate'=>'日期格式不合法'));
			$fs[] = new FormField('flag','GET#',array(0,1,'flag有误',FormField::$VAR_INT));
			FormParser::parse($fs,TRUE);
		}
		
		public static function type()
		{
			$fs = array();
			$fs[] = new FormField('transtype', "GET#", array(0,5,'交易类型有误',FormField::$VAR_STRING));
			$fs[] = new FormField('domainsld', "GET#", array(0, FormField::$MAX_INT, '域名有误', FormField::$VAR_STRING), array(
				'\common\FormCheck::taoCheckDomain' => '域名格式错误'));
			$fs[] = new FormField('sldtypestart', "GET#", array(0,1, '关键字位置有误', FormField::$VAR_INT));
			$fs[] = new FormField('sldtypeend', "GET#", array(0,1, '关键字位置有误', FormField::$VAR_INT));
			$fs[] = new FormField('domaintld', "GET#", array(0, FormField::$MAX_INT, '域名后缀有误',  FormField::$VAR_STRING));
			$fs[] = new FormField('domainlenstart', "GET#", array(0, 60, '域名长度1-60', FormField::$VAR_INT));
			$fs[] = new FormField('domainlenend', "GET#", array(0, 60, '域名长度1-60', FormField::$VAR_INT));
			$fs[] = new FormField('domaingroup', "GET#", array(0, 30, '域名分组有误', FormField::$VAR_INT));
			
			$fs[] = new FormField('bidpricestart', "GET#", array(0, FormField::$MAX_INT, '当前价格有误', FormField::$VAR_INT));
			$fs[] = new FormField('bidpriceend', "GET#", array(0, FormField::$MAX_INT, '当前价格有误', FormField::$VAR_INT));
			$fs[] = new FormField('finishtime', "GET#", array(0, 12, '结束时间有误', FormField::$VAR_INT));
			$fs[] = new FormField('registrar', "GET#", array(0, 10, '注册商类型有误', FormField::$VAR_INT));
			$fs[] = new FormField('sort', "GET#", array(0, 3, '排序有误', FormField::$VAR_INT));
			$fs[] = new FormField('hidenobider', "GET#", array(0, 2, '非法参数', FormField::$VAR_INT));
			$fs[] = new FormField('bidstartone', "GET#", array(0, 2, '非法参数', FormField::$VAR_INT));
			$fs[] = new FormField('skipword1', "GET#", array(0, 20, '过滤字符有误', FormField::$VAR_STRING));
			$fs[] = new FormField('skipstart1', "GET#", array(0, 1, '过滤关键字位置有误', FormField::$VAR_INT));
			$fs[] = new FormField('skipend1', "GET#", array(0, 1, '过滤关键字位置有误', FormField::$VAR_INT));
			$fs[] = new FormField('skipword2', "GET#", array(0, 20, '过滤字符有误', FormField::$VAR_STRING));
			$fs[] = new FormField('skipstart2', "GET#", array(0, 1, '过滤关键字位置有误', FormField::$VAR_INT));
			$fs[] = new FormField('skipend2', "GET#", array(0, 1, '过滤关键字位置有误', FormField::$VAR_INT));
			$fs[] = new FormField('num','GET#',array(0,30,'获取个数有误',FormField::$VAR_INT));
			$fs[] = new FormField('p','GET#',array(0,FormField::$MAX_INT,FormField::$VAR_INT),array('\common\FormCheck::isNumber' => '参数格式错误'));
			FormParser::parse($fs,TRUE);
		}
		
		public static function getConf()
		{
			$fs = array();
			$fs[] = new FormField('flag', "GET#", array(0, 1, '参数有误',  FormField::$VAR_INT));
			$fs[] = new FormField('transtype', "GET#", array(1, 5, '类型有误',  FormField::$VAR_INT));
			FormParser::parse($fs,TRUE);
		}
		
		public static function domain()
		{
			$fs = array();
			$fs[] = new FormField('id', "GET", array(1, FormField::$MAX_INT, '域名id有误',  FormField::$VAR_INT));
			$fs[] = new FormField('enameid', "GET#", array(1, FormField::$MAX_INT, '用户id有误',  FormField::$VAR_INT));
			$fs[] = new FormField('isajax', "GET#", array(0, 1, 'ajax标识有误',  FormField::$VAR_INT));
			FormParser::parse($fs,TRUE);
		}
		
		public static function inquiry()
		{
			$fs = array();
			$fs[] = new FormField('id', "GET", array(1, FormField::$MAX_INT, '域名id有误',  FormField::$VAR_INT));
			$fs[] = new FormField('enameid', "GET#", array(1, FormField::$MAX_INT, '用户id有误',  FormField::$VAR_INT));
			FormParser::parse($fs,TRUE);
		}
		public static function getBidRecords()
		{
			$fs = array();
			$fs[] = new FormField('id', "GET", array(1, FormField::$MAX_INT, '域名id有误',  FormField::$VAR_INT));
			$fs[] = new FormField('enameid', "GET#", array(1, FormField::$MAX_INT, '用户id有误',  FormField::$VAR_INT));
			$fs[] = new FormField('num','GET#',array(0,30,'获取个数有误',FormField::$VAR_INT));
			$fs[] = new FormField('p','GET#',array(0,FormField::$MAX_INT,FormField::$VAR_INT),array('\common\FormCheck::isNumber' => '参数格式错误'));
			FormParser::parse($fs,TRUE);
		}
		
		public static function addDiySearch()
		{
			$fs = array();
			$fs[] = new FormField('domainsld', "GET#", array(0, FormField::$MAX_INT, '域名有误', FormField::$VAR_STRING), array(
				'\common\FormCheck::taoCheckDomain' => '域名格式错误'));
			$fs[] = new FormField('skipword1', "GET#", array(0, 20, '过滤字符有误', FormField::$VAR_STRING));
			$fs[] = new FormField('sldtypestart', "GET#", array(0,FormField::$MAX_INT, '关键字位置有误', FormField::$VAR_STRING));
			$fs[] = new FormField('sldtypeend', "GET#", array(0,FormField::$MAX_INT, '关键字位置有误', FormField::$VAR_STRING));
			$fs[] = new FormField('transtype', "GET#", array(1,6,'交易类型有误',FormField::$VAR_INT));
			$fs[] = new FormField('domaintld', "GET#", array(0, FormField::$MAX_INT, '域名后缀有误',  FormField::$VAR_STRING));
			$fs[] = new FormField('domaingroup', "GET#", array(0, 30, '域名分组有误', FormField::$VAR_INT));
			$fs[] = new FormField('bidpricestart', "GET#", array(0, FormField::$MAX_INT, '当前价格有误', FormField::$VAR_INT));
			$fs[] = new FormField('bidpriceend', "GET#", array(0, FormField::$MAX_INT, '当前价格有误', FormField::$VAR_INT));
			$fs[] = new FormField('domainlenstart', "GET#", array(0, 60, '域名长度1-60', FormField::$VAR_INT));
			$fs[] = new FormField('domainlenend', "GET#", array(0, 60, '域名长度1-60', FormField::$VAR_INT));
			$fs[] = new FormField('registrar', "GET#", array(0, 10, '注册商类型有误', FormField::$VAR_INT));
			$fs[] = new FormField('sort', "GET#", array(0, 3, '排序有误', FormField::$VAR_INT));
			$fs[] = new FormField('hidenobider', "GET#", array(0, 2, '非法参数', FormField::$VAR_INT));
			$fs[] = new FormField('bidstartone', "GET#", array(0, 2, '非法参数', FormField::$VAR_INT));
			$fs[] = new FormField('name', "GET", array(1, 30, '自定义保存名称有误', FormField::$VAR_STRING));
			$fs[] = new FormField('enameid', "GET", array(1, FormField::$MAX_INT, '用户ID有误', FormField::$VAR_INT));
			FormParser::parse($fs,TRUE);
		}
		public static function getDiySearch()
		{
			$fs = array();
			$fs[] = new FormField('enameid', "GET", array(1, FormField::$MAX_INT, '用户ID有误', FormField::$VAR_INT));
			FormParser::parse($fs,TRUE);
		}

		public static function delDiySearch()
		{
			$fs = array();
			$fs[] = new FormField('enameid', "GET", array(1, FormField::$MAX_INT, '用户ID有误', FormField::$VAR_INT));
			$fs[] = new FormField('id', "GET", array(1, FormField::$MAX_INT, 'ID有误', FormField::$VAR_INT));
			FormParser::parse($fs,TRUE);
		}
	}
?>
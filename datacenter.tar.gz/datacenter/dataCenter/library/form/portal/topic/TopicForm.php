<?php
namespace form\portal\topic;

use core\form as form;

class TopicForm
{
	public static function getTopicForm()
	{
		$fs[] = new form\FormField('pagenum', "GET#", array(1,form\FormField::$MAX_INT,'专题页码有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pagesize', "GET#", array(1,100,'专题每页显示条数有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('title', "GET#", array(1,255,'专题标题获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('showIndex', "GET#", array(1,10,'专题是否显示showIndex获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('status', "GET#", array(1,3,'专题status获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('toUrl', "GET#", array(1,100,'专题toUrl获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('bigPicNotNull', "GET#", array(1,1,'专题toUrl获取有误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	public static function addTopicForm()
	{
		
		$fs[] = new form\FormField('title', "GET", array(1,40,'专题标题title获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('toUrl', "GET", array(1,100,'专题toUrl获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('summary', "GET#", array(1,255,'专题summary获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pic', "GET#", array(1,255,'专题小图pic获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('bigPic', "GET#", array(1,255,'专题大图pic获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('viewNum', "GET#", array(1,10,'专题浏览数量viewNum获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('showIndex', "GET#", array(1,10,'专题是否显示showIndex获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('status', "GET#", array(1,1,'专题status获取有误',form\FormField::$VAR_STRING));
		
		
		form\FormParser::parse($fs, true);
	}
	
	public static function editTopicForm()
	{
		$fs[] = new form\FormField('topicId', "GET", array(1, 11, '专题topicId有误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('title', "GET#", array(1,40,'专题标题title获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('toUrl', "GET#", array(1,100,'专题toUrl获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('summary', "GET#", array(1,255,'专题summaryl获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pic', "GET#", array(1,255,'专题小图pic获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('bigPic', "GET#", array(1,255,'专题大图pic获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('viewNum', "GET#", array(1,10,'专题浏览数量viewNum获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('showIndex', "GET#", array(1,10,'专题是否显示showIndex获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('status', "GET#", array(1,1,'专题status获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('createTime', "GET#", array(1,10,'专题创建时间createTime获取有误',form\FormField::$VAR_STRING));
		
	
		form\FormParser::parse($fs, true);
	}
	
	public static function delTopicForm()
	{
		$fs[] = new form\FormField('topicId', "GET", array(1, 11, '专题topicId有误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function getOneTopicForm()
	{
		$fs[] = new form\FormField('topicId', "GET", array(1, 11, '专题topicId有误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
}
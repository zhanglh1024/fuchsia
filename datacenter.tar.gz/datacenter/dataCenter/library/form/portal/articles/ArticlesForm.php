<?php
namespace form\portal\articles;

use core\form as form;

class ArticlesForm
{
	public static function addArticleForm()
	{
		$fs[] = new form\FormField('enameId', "POST#", array(1, 11, 'enameId错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('username', "POST#", array(1, 40, '昵称错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('status', "POST#", array(1, 1, '状态错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('caId', "POST", array(1, 11, '栏目id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('title', "POST", array(1, 50, '文章标题错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pic', "POST#", array(1, 255, '封面图片错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('shortTitle', "POST#", array(1, 30, '文章短标题错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('author', "POST#", array(1, 20, '原作者错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('from', "POST#", array(1, 20, '文章来源错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('fromUrl', "POST#", array(1, 255, '文章来源url错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('titleStyle', "POST#", array(1, 20, '文章标题样式错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('summary', "POST#", array(1, 255, '文章摘要错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('toUrl', "POST#", array(1, 255, '文章跳转url错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('tid', "POST#", array(1, 11, '帖子id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('allowComment', "POST#", array(0, 1, '是否允许评论错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('tag', "POST#", array(1, 20, '聚合标签错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('createTime', "POST#", array(10, 10, '发布时间错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iosTag', "POST#", array(0, 1, '推送客户端错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('iosTop', "POST#", array(0, 1, '客户端头条错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('hdImg', "POST#", array(1, 100, '门户幻灯片错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('zxImg', "POST#", array(1, 100, '资讯图片错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iosNewImg', "POST#", array(1, 100, '客户端新闻图片错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iosTopImg', "POST#", array(1, 100, '客户端头条图片错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iosTitle', "POST#", array(1, 30, '客户端标题错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('tkFrom', "POST#", array(1, 255, '转载感谢错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('keyword', "POST#", array(1, 255, '关键词错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('relatedId', "POST#", array(1, 255, '相关文章id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('contactType', "POST#", array(1, 3, '联系类型错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('contact', "POST#", array(1, 255, '联系方式错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('adminId', "POST#", array(1, form\FormField::$MAX_INT, '管理员ID错误', form\FormField::$VAR_INT));
		//$fs[] = new form\FormField('content', "GET", array(1, form\FormField::$MAX_INT, '文章内容错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function updateArticleForm()
	{
		$fs[] = new form\FormField('enameId', "POST#", array(1, 11, 'enameId错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('username', "POST#", array(1, 40, '昵称错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('atId', "POST", array(1, 11, '文章id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('caId', "POST#", array(1, 11, '栏目id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('title', "POST#", array(1, 50, '文章标题错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('pic', "POST#", array(1, 255, '封面图片错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('shortTitle', "POST#", array(1, 30, '文章短标题错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('author', "POST#", array(1, 20, '原作者错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('from', "POST#", array(1, 20, '文章来源错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('fromUrl', "POST#", array(1, 255, '文章来源url错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('titleStyle', "POST#", array(1, 20, '文章标题样式错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('summary', "POST#", array(1, 255, '文章摘要错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('toUrl', "POST#", array(1, 255, '文章跳转url错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('tid', "POST#", array(1, 11, '帖子id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('allowComment', "POST#", array(0, 1, '是否允许评论错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('tag', "POST#", array(1, 20, '聚合标签错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('createTime', "POST#", array(10, 10, '发布时间错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iosTag', "POST#", array(0, 1, '推送客户端错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('iosTop', "POST#", array(0, 1, '客户端头条错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('hdImg', "POST#", array(1, 100, '门户幻灯片错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('zxImg', "POST#", array(1, 100, '资讯图片错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iosNewImg', "POST#", array(1, 100, '客户端新闻图片错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iosTopImg', "POST#", array(1, 100, '客户端头条图片错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iosTitle', "POST#", array(1, 30, '客户端标题错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('tkFrom', "POST#", array(1, 255, '转载感谢错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('keyword', "POST#", array(1, 255, '关键词错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('relatedId', "POST#", array(1, 255, '相关文章id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('reason', "POST#", array(1, 255, '退稿理由错误', form\FormField::$VAR_STRING));
		//$fs[] = new form\FormField('content', "GET#", array(1, form\FormField::$MAX_INT, '文章内容错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('status', "POST#", array(1, 1, '状态错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('credit', "POST#", array(-500, 500, '积分错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('contactType', "POST#", array(1, 3, '联系类型错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('contact', "POST#", array(1, 255, '联系方式错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('adminId', "POST#", array(1, form\FormField::$MAX_INT, '管理员ID错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	public static function articleListForm()
	{
		$fs[] = new form\FormField('pagenum', "GET#", array(1,form\FormField::$MAX_INT,'页码错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pagesize', "GET#", array(1,100,'每页显示条数错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('atId', "GET#", array(1, 11, '文章id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('enameIdNotNull', "GET#", array(1, 1, '格式错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('enameId', "GET#", array(1, 11, 'enameId错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('caId', "GET#", array(1, 40, '栏目id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('title', "GET#", array(1, 50, '文章标题错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('author', "GET#", array(1, 40, '原作者错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('username', "GET#", array(1, 40, '责任编辑错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('tid', "GET#", array(1, 11, '帖子id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('tag', "GET#", array(1, 20, '聚合标签错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iosTag', "GET#", array(0, 1, '推送客户端错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('iosTop', "GET#", array(0, 1, '客户端头条错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('status', "GET#", array(1, 1, '状态错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('orderBy', "GET#", array(1, 11, '排序字段错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('sort', "GET#", array(3, 4, '排序错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('createTime', "GET#", array(10, 11, '时间错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('noIds', "GET#", array(1, 255, '不包含id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('idLess', "GET#", array(1, 11, 'id小于错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('idThan', "GET#", array(1, 11, 'id大于错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('atIds', "GET#", array(1, 255, '文章id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('caIds', "GET#", array(1, 255, '栏目id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('noUser', "GET#", array(1, 255, '不包含昵称错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('hdImgNotNull', "GET#", array(1, 1, '幻灯片不为空错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('zxImgNotNull', "GET#", array(1, 1, '资讯图片不为空错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iosNewImgNotNull', "GET#", array(1, 1, '客户端新闻图片不为空错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iosTopImgNotNull', "GET#", array(1, 1, '客户端头条图片不为空错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('comNumNotNull', "GET#", array(1, 1, '评论数不为空错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('orTag', "GET#", array(1, 20, '聚合标签错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('limit', "GET#", array(1, 50, '限制条数错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('kouChuTop', "GET#", array(1, 50, '扣除前N条记录错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	public static function articleCountForm()
	{
		$fs[] = new form\FormField('atId', "GET#", array(1, 11, '文章id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('enameIdNotNull', "GET#", array(1, 1, '格式错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('enameId', "GET#", array(1, 11, 'enameId错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('caId', "GET#", array(1, 40, '栏目id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('title', "GET#", array(1, 50, '文章标题错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('author', "GET#", array(1, 40, '原作者错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('username', "GET#", array(1, 40, '责任编辑错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('tid', "GET#", array(1, 11, '帖子id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('tag', "GET#", array(1, 20, '聚合标签错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iosTag', "GET#", array(0, 1, '推送客户端错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('iosTop', "GET#", array(0, 1, '客户端头条错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('status', "GET#", array(1, 1, '状态错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('createTime', "GET#", array(10, 11, '时间错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('noIds', "GET#", array(1, 255, '不包含id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('idLess', "GET#", array(1, 11, 'id小于错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('idThan', "GET#", array(1, 11, 'id大于错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('atIds', "GET#", array(1, 255, '文章id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('caIds', "GET#", array(1, 255, '栏目id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('noUser', "GET#", array(1, 255, '不包含昵称错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('hdImgNotNull', "GET#", array(1, 1, '幻灯片不为空错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iosNewImgNotNull', "GET#", array(1, 1, '客户端新闻图片不为空错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('iosTopImgNotNull', "GET#", array(1, 1, '客户端头条图片不为空错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('comNumNotNull', "GET#", array(1, 1, '评论数不为空错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function IndexPublishForm()
	{
		$fs[] = new form\FormField('tag', "GET", array(1, 20, '聚合标签错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('limit', "GET", array(1, 40, '限制条数错误', form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkIdForm()
	{
		$fs[] = new form\FormField('atId', "GET", array(1, 11, '文章id错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkTrashIdForm()
	{
		$fs[] = new form\FormField('trashId', "GET", array(1, 11, '回收站id错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function articleTrashListForm()
	{
		$fs[] = new form\FormField('pagenum', "GET", array(1,form\FormField::$MAX_INT,'页码错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pagesize', "GET", array(1,100,'每页显示条数错误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkAtricelCountForm()
	{
		$fs[] = new form\FormField('atId', "POST", array(1, 11, '文章id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('viewNum', "POST#", array(1, 8, '浏览次数错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('comNum', "POST#", array(1, 8, '评论次数错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('favNum', "POST#", array(1, 8, '喜欢次数错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('shareNum', "POST#", array(1, 8, '分享次数错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkAtricelCountListForm()
	{
		$fs[] = new form\FormField('pagenum', "GET", array(1,form\FormField::$MAX_INT,'页码错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pagesize', "GET", array(1,100,'每页显示条数错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('orderBy', "GET#", array(1, 11, '排序字段错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('sort', "GET#", array(3, 4, '排序错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkAtricelClickForm()
	{
		$fs[] = new form\FormField('atId', "GET", array(1,11,'文章id错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('enameId', "GET#", array(1,11,'enameId错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('username', "GET", array(1, 40, '昵称错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('clickId', "GET", array(1, 1, '表情id错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkAtricelClickListForm()
	{
		$fs[] = new form\FormField('atId', "GET", array(1,11,'文章id错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('limit', "GET", array(1,10,'限制条数错误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkAddArticleCommentForm()
	{
		$fs[] = new form\FormField('atId', "GET", array(1,11,'文章id错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('enameId', "GET#", array(1,11,'enameId错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('username', "GET#", array(1, 40, '昵称错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('comIp', "GET", array(1, 40, 'ip错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('contact', "GET#", array(1, 255, '联系方式错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('contactType', "GET#", array(1, 3, '联系类型错误', form\FormField::$VAR_INT));
// 		$fs[] = new form\FormField('message', "POST", array(1, 255, '评论内容错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkUpdateArticleCommentForm()
	{
		$fs[] = new form\FormField('amId', "GET", array(1, 11, '评论id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('status', "GET#", array(0, 3, '状态码错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('goodNum', "GET#", array(1, 1, '喜欢次数错误', form\FormField::$VAR_INT));
// 		$fs[] = new form\FormField('message', "POST#", array(1, 255, '评论内容错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkgetArticleCommentListForm()
	{
		$fs[] = new form\FormField('pagenum', "GET#", array(1,form\FormField::$MAX_INT,'页码错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pagesize', "GET#", array(1,100,'每页显示条数错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('status', "GET#", array(0, 3, '状态码错误', form\FormField::$VAR_INT));
		$fs[] = new form\FormField('atId', "GET#", array(1, 11, '文章id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('enameId', "GET#", array(1,11,'enameId错误',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkArticleCommentIdForm()
	{
		$fs[] = new form\FormField('amId', "GET", array(1, 11, '评论id错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkRelatedForm()
	{
		$fs[] = new form\FormField('atId', "GET", array(1, 11, '文章id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('limit', "GET#", array(1, form\FormField::$MAX_INT,'限制条数错误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkAttachmentForm()
	{
		$fs[] = new form\FormField('atId', "GET#", array(1, 11, '文章id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('aaUrl', "GET", array(1, form\FormField::$MAX_INT,'url错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('aaFileType', "GET", array(1, 10,'文件类型错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('aaFileSize', "GET", array(1, 11,'文件大小错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('aaIsImage', "GET", array(0, 1,'是否试图片错误',form\FormField::$VAR_INT));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkAttachmentIdForm()
	{
		$fs[] = new form\FormField('aaId', "GET", array(1, 11, '附件id错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkAttachmentAtIdForm()
	{
		$fs[] = new form\FormField('atId', "GET#", array(1, 11, '文章id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('aaId', "GET#", array(1, 11, '附件id错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkAttachmentUpFrom()
	{
		$fs[] = new form\FormField('aaId', "GET", array(1, 255, '附件id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('atId', "GET", array(1, 11, '文章id错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkKeywordArticleFrom()
	{
		$fs[] = new form\FormField('limit', "GET", array(1, form\FormField::$MAX_INT,'限制条数错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('atId', "GET", array(1, 11, '文章id错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('order', "GET", array(0, 20, '排序出错', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkEnameIdAndAtId()
	{
		$fs[] = new form\FormField('atId', "GET", array(1,11,'文章id错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('enameId', "GET", array(1,11,'enameId错误',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkEnameIdAndAmId()
	{
		$fs[] = new form\FormField('amId', "GET", array(1,11,'评论id错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('enameId', "GET", array(1,11,'enameId错误',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkAmId()
	{
		$fs[] = new form\FormField('amId', "GET", array(1,11,'评论id错误',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkTtid()
	{
		$fs[] = new form\FormField('tid', "GET", array(1,11,'帖子id有误',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function checkArticleAid()
	{
		$fs[] = new form\FormField('aid', "GET", array(1, 11, '文章id错误', form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
}
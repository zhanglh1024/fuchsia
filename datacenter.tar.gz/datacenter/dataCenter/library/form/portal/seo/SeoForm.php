<?php
namespace form\portal\seo;

use core\form as form;

class SeoForm
{
	public static function editSeoForm()
	{
		$fs[] = new form\FormField('seId', "GET", array(1,3,'seId获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('url', "GET#", array(1,100,'seo正则表达式获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('title', "GET#", array(1,form\FormField::$MAX_INT,'seo标题获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('description', "GET#", array(1,form\FormField::$MAX_INT,'seo描述获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('keywords', "GET#", array(1,form\FormField::$MAX_INT,'seo关键字获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('name', "GET#", array(1,40,'seo类型名获取有误',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function getOneSeoForm()
	{
		$fs[] = new form\FormField('seId', "GET#", array(1,3,'seId获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('url', "GET#", array(1,100,'seo正则表达式获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('title', "GET#", array(1,form\FormField::$MAX_INT,'seo标题获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('description', "GET#", array(1,form\FormField::$MAX_INT,'seo描述获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('keywords', "GET#", array(1,form\FormField::$MAX_INT,'seo关键字获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('name', "GET#", array(1,40,'seo类型名获取有误',form\FormField::$VAR_STRING));
		
		form\FormParser::parse($fs, true);
	}

}
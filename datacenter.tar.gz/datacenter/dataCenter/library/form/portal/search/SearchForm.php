<?php
namespace form\portal\search;

use core\form as form;

class SearchForm
{
	public static function getSearchIndexForm()
	{
		$fs[] = new form\FormField('keyword', "GET", array(1, 255,'关键字错误',form\FormField::$VAR_STRING));	
		$fs[] = new form\FormField('searchIp', "GET", array(1, 40,'ip错误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('enameId', "GET#", array(1, 11,'enameId错误',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
	
	public static function getSearchListForm()
	{
		$fs[] = new form\FormField('pagenum', "GET", array(1,form\FormField::$MAX_INT,'页码错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pagesize', "GET", array(1,100,'每页显示条数错误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('orderBy', "GET", array(1, 11, '排序字段错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('sort', "GET", array(3, 4, '排序错误', form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('searchId', "GET", array(1, 11,'索引id错误',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
}
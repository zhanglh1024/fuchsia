<?php
namespace form\portal\category;

use core\form as form;

class CategoryForm
{
	public static function getCategoryForm()
	{
		$fs[] = new form\FormField('pagenum', "GET#", array(1,form\FormField::$MAX_INT,'栏目页码有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('pagesize', "GET#", array(1,100,'栏目每页显示条数有误',form\FormField::$VAR_INT));
		$fs[] = new form\FormField('closed', "GET#", array(1,1,'栏目是否关闭closed获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('allowNav', "GET#", array(1,1,'栏目是否在导航显示allowNav获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('allowIndex', "GET#", array(1,1,'栏目是否在首页显示allowIndex获取有误',form\FormField::$VAR_STRING));
		
		form\FormParser::parse($fs, true);
	}

	public static function addCategoryForm()
	{
		$fs[] = new form\FormField('name', "GET", array(1,10,'栏目name获取有误',form\FormField::$VAR_STRING));
		
		$fs[] = new form\FormField('displayOrder', "GET#", array(1,2,'栏目排序displayOrder获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('caUrl', "GET#", array(1,10,'栏目caUrl获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('closed', "GET#", array(1,1,'栏目是否关闭closed获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('allowNav', "GET#", array(1,1,'栏目是否在导航显示allowNav获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('allowPublish', "GET#", array(1,1,'栏目是否允许发布文章allowPublish获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('allowSummary', "GET#", array(1,1,'栏目是否显示摘要allowSummary获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('allowComment', "GET#", array(1,1,'栏目是否显示评论allowComment获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('allowIndex', "GET#", array(1,1,'栏目是否在首页显示allowIndex获取有误',form\FormField::$VAR_STRING));
		
		form\FormParser::parse($fs, true);
	}

	public static function editCategoryForm()
	{
		$fs[] = new form\FormField('categoryId', "GET", array(1,11,'栏目categoryId获取有误',form\FormField::$VAR_STRING));
		
		$fs[] = new form\FormField('name', "GET#", array(1,10,'栏目name获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('displayOrder', "GET#", array(1,2,'栏目排序displayOrder获取有误',form\FormField::$VAR_STRING));
 		$fs[] = new form\FormField('caUrl', "GET#", array(1,10,'栏目的caUrl获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('createTime', "GET#", array(1,10,'栏目创建时间createTime获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('closed', "GET#", array(1,1,'栏目是否关闭closed获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('allowNav', "GET#", array(1,1,'栏目是否在导航显示allowNav获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('allowPublish', "GET#", array(1,1,'栏目是否允许发布文章allowPublish获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('allowSummary', "GET#", array(1,1,'栏目是否显示摘要allowSummary获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('allowComment', "GET#", array(1,1,'栏目是否显示评论allowComment获取有误',form\FormField::$VAR_STRING));
		$fs[] = new form\FormField('allowIndex', "GET#", array(1,1,'栏目是否在首页显示allowIndex获取有误',form\FormField::$VAR_STRING));
		
		form\FormParser::parse($fs, true);
	}

	public static function delCategoryForm()
	{
		$fs[] = new form\FormField('categoryId', "GET", array(1,11,'栏目categoryId获取有误',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}

	public static function getOneCategoryForm()
	{
		$fs[] = new form\FormField('categoryId', "GET", array(1,11,'栏目categoryId获取有误',form\FormField::$VAR_STRING));
		form\FormParser::parse($fs, true);
	}
}
<?php
namespace form\help\talk;
use core\form\FormField;
use core\form\FormParser;
class TalkForm
{
	public static function talklist()
	{
		$fs = array();
		$fs[] = new FormField('type', "GET", array(1, 2, '类型有误', FormField::$VAR_INT));
		$fs[] = new FormField('enameid', "GET", array(1, 50, '用户ID有误', FormField::$VAR_STRING));
		$fs[] = new FormField('id', 'GET#', array(0, FormField::$MAX_INT, 'id有误', FormField::$VAR_INT));
		$fs[] = new FormField('flag', 'GET#', array(0, FormField::$MAX_INT, '参数有误', FormField::$VAR_INT));
		$fs[] = new FormField('num', 'GET#', array(0, 30, '获取个数有误', FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}

	public static function addTalk()
	{
		$fs = array();
		$fs[] = new FormField('type', "POST", array(1, 2, '类型有误', FormField::$VAR_INT));
		$fs[] = new FormField('msg', "POST", array(1, 2000, '消息长度超出限制', FormField::$VAR_STRING));
		$fs[] = new FormField('enameid', "POST", array(1, 50, '用户ID有误', FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}
	public static function appTalk()
	{
		$fs = array();
		$fs[] = new FormField('enameid', "GET", array(1, 50, '用户ID有误', FormField::$VAR_STRING));
		FormParser::parse($fs, TRUE);
	}

}
?>
<?php
namespace form\help\faq;

use core\form\FormField;
use core\form\FormParser;
class FaqForm
{

	public static function info()
	{
		$fs = array();
		$fs[] = new FormField('id', "GET", array(1,FormField::$MAX_INT,'ID有误',FormField::$VAR_INT));
		$fs[] = new FormField('version', "GET", array(0,2,'flag有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
	
	public static function getGuideFaq()
	{
		$fs = array();
		$fs[] = new FormField('num', "GET#", array(0,30,'数量有误',FormField::$VAR_INT));
		FormParser::parse($fs, TRUE);
	}
}
?>
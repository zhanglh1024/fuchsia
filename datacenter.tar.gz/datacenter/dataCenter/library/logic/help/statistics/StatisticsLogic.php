<?php
namespace logic\help\statistics;

class StatisticsLogic
{

	private $conf;

	public function __construct()
	{
		// 加载配置
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/help.ini', 'client');
	}

	/**
	 * 客服工作情况统计
	 *
	 * @param Object $data        	
	 * @return multitype:string boolean
	 */
	public function work($data)
	{
		// 加载配置
		$csTypeConf = $this->conf->csType->toArray();
		$csTypeConf = array_keys($csTypeConf);
		// 获取参数
		$csId = $data->csid;
		$csType = $data->cstype;
		$csCount = $data->cscount;
		$vTime = $data->vtime;
		$year = date('Y', $vTime);
		$month = date('n', $vTime);
		$day = date('j', $vTime);
		$workMod = new \models\help\WorkStatMod();
		if(!in_array($csType, $csTypeConf))
			return;
		$info = $workMod->getStatistic($csId, $csType, $year, $month, $day);
		if(empty($info['id']))
		{
			// 添加操作
			$rs = $workMod->addStatistics($csId, $csType, $csCount, $year, $month, $day);
			if(false === $rs)
			{
				\core\Log::write("work addStatistics fail,$csId," . $csType . ',' . $csCount . "$year,$month,$day", 
					'trans', 'help');
				return false;
			}
		}
		else
		{
			// 更新操作
			$rs = $workMod->updateStatistic($info['id'], $csCount);
			if(false === $rs)
			{
				\core\Log::write("work updateStatistic fail," . $info['id'] . "," . $csCount, 'trans', 'help');
				return false;
			}
		}
		return true;
	}
}
?>
<?php
namespace logic\help\faq;

class FaqLogic
{

	private $lib;

	private $conf;

	public function __construct()
	{
		$this->lib = new \lib\help\faq\FaqLib();
		// 加载配置
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/help.ini', 'client');
	}

	/**
	 * 内容页
	 *
	 * @param unknown $data        	
	 */
	public function info($data)
	{
		$faqId = $data->id;
		$faqInfo = $this->lib->getFaqInfo($faqId);
		if(!$faqInfo)
		{
			throw new \Exception('暂无此FAQ信息');
		}
		// 获取全部字内容
		$faqContent = $this->lib->getFaqContent($faqId);
		$faqContent = $this->lib->format($faqContent);
		// 获取非常见问题
		$faqList = $this->lib->getFaqContent($faqId, 0);
		$faqList = $this->lib->format($faqList);
		// 获取常见问题
		$questionFaq = $this->lib->getFaqContent($faqId, 1);
		$questionFaq = $this->lib->format($questionFaq);
		return array('faqInfo' => $faqInfo,'faqContent' => $faqContent,'faqList' => $faqList,
			'questionFaq' => $questionFaq);
	}

	/**
	 * 获取新手指南FAQ
	 * 
	 * @param unknown $data        	
	 * @throws \Exception
	 * @return multitype:Ambigous <multitype:, \lib\help\faq\Ambigous, \models\help\Ambigous, boolean, unknown, multitype:multitype: >
	 */
	public function getGuideFaq($data)
	{
		// 加载配置
		$maxNum = $this->conf->default_maxnum;
		$faqSortConf = $this->conf->faqSort->toArray();
		// 获取参数
		$num = $data->num? (($data->num > $maxNum)? $maxNum :$data->num) :$maxNum;
		$sortId = $this->lib->getSortId($faqSortConf['guide'][1]);
		if(!$sortId)
		{
			throw new \Exception('分类不存在');
		}
		$list = $this->lib->getGuideFaq($sortId, $num);
		if(false === $list)
		{
			throw new \Exception('系统出错');
		}
		return array('list' => $list? $list :array());
	}
}
?>
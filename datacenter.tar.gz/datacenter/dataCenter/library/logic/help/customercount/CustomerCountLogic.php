<?php
namespace logic\help\customercount;

class CustomerCountLogic
{

	private $typeArr;

	private $redis;

	private  $conf;
	function __construct()
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/help.ini', 'client');
		$this->redis = \core\RedisLib::getInstance('manage');
		$this->typeArr = array_keys($this->conf->csType->toArray());
	}

	public function allCount()
	{
		echo $this->getFinanceFareCount();
		echo PHP_EOL;
		echo $this->getExpRemindCount();
		echo PHP_EOL;
		echo $this->getVerifyCount();
		echo PHP_EOL;
		echo $this->getUserSetCount();
		echo PHP_EOL;
		echo $this->getRecordOrDomainTipCount(6);
		echo PHP_EOL;
		echo $this->getCustomerCount();
		echo PHP_EOL;
		echo $this->getSecureWarningCount();
		echo PHP_EOL;
	}

	/**
	 * 获取展示页面审核数据
	 */
	public function getCustomerCount()
	{
		try
		{
// 			$inter = new \interfaces\trans\Custompage();
// 			$time = (object) array(
// 					'timerange' => array(strtotime(date('Y-m-d', strtotime('-1 days')) . ' 00:00:00'), 
// 							strtotime(date('Y-m-d', strtotime('-1 days')) . ' 23:59:59')));
// 			$customerData = $inter->totalAuditTemp($time);
         $time=date('Y-m-d', strtotime('-1 days'));
         $customerData=$this->countAuditByTime($time);
			if(empty($customerData))
			{
				return '展示页审核暂无数据' . PHP_EOL;
			}
			$return = array();
			foreach($customerData as $info)
			{
				$return[] = array('vtime' => $time, 'cscount' => $info['Num'], 
						'cstype' => '4', 'csid' => $info['Auditor']);
			}
			return $this->addCustomerCount($return, 4);
		}
		catch(\Exception $e)
		{
			return "展示页处理暂时无数据" . PHP_EOL;
		}
	}
   private function countAuditByTime($time)
    {
    	$postData = array();
    	$url = $this->conf->api_ename->url.'alliance/countauditbyid';//'http://api.ename.com/alliance/countauditbyid';
    	$postData['user'] = $this->conf->count_audit->user;//'alliance';
    	$postData['appkey'] = $this->conf->count_audit->appkey;//'89dae41c0d705ceb55aa778e27033d7b';
    	$postData['auditTime'] = $time;
    	$result=\common\Common::requestPost($url,$postData);
    	$result=json_decode($result,true);
    	if($result['flag'])
    	{
    		 
    		return $result['msg'];
    	}
    	return null;
    }
	/**
	 * 获取企业认证和身份认证的统计信息
	 */
	public function getVerifyCount()
	{
		$date = date('Y-m-d', strtotime('-1 days'));
		$CompanyMod = new \models\manage\verify\CompanyVerifyMod();
		$identityMod = new \models\manage\verify\IdentityVerifyMod();
		// 企业认证统计
		$compInfo = $CompanyMod->getVerifyCountGroup($this->typeArr[7], $date);
		$compInfo = $compInfo ? $compInfo : array();
		$compInfo = array_merge($compInfo, $this->getSecondVerify($this->typeArr[7], $date));
		$compInfo = $this->addCsCount($compInfo);
		// 身份认证统计
		$idInfo = $identityMod->getVerifyCountGroup($this->typeArr[6], $date, 1);
		$idInfo = $idInfo ? $idInfo : array();
		$idInfo = array_merge($idInfo, $this->getSecondVerify($this->typeArr[6], $date));
		$idInfo = $this->addCsCount($idInfo);
		
		// 交易认证统计
		$transInfo = $identityMod->getVerifyCountGroup($this->typeArr[10], $date, 3);
		$transInfo = $transInfo ? $transInfo : array();
		$transInfo = array_merge($transInfo, $this->getSecondVerify($this->typeArr[10], $date));
		$transInfo = $this->addCsCount($transInfo);
		
		// bbs认证统计
		$bbsInfo = $identityMod->getVerifyCountGroup($this->typeArr[11], $date, 2);
		$bbsInfo = $bbsInfo ? $bbsInfo : array();
		$transInfo = array_merge($transInfo, $this->getSecondVerify($this->typeArr[11], $date));
		$bbsInfo = $this->addCsCount($bbsInfo);
		
		$return = array_merge($compInfo, $idInfo, $transInfo, $bbsInfo);
		return $this->addCustomerCount($this->formatCount($return, "企业认证/身份认证/bbs认证/交易认证"), $this->typeArr[7]);
	}

	
	private function addCsCount($array)
	{
		if(empty($array))
		{
			return $array;
		}
		$return = array();
		foreach($array as $key => $value)
		{
			if(isset($return[$value['VerifyUser']]))
			{
				$return[$value['VerifyUser']]['cscount'] += $value['cscount'];
			}
			else
			{
				$return[$value['VerifyUser']] = $value;
			}
		}
		return $return;
	}

	/**
	 * 获取二次审核的数据
	 */
	public function getSecondVerify($type, $time)
	{
		$mod = new \models\help\CustomerCountMod();
		$st= $mod->getGroupData($type, $time);
		return $st ? $st : array();
	}

	/**
	 * 获取url转发审核数据/过期域名提醒数据
	 */
	public function getRecordOrDomainTipCount($type)
	{
		try
		{
			$this->redis->select(5);
			$time = date('Y-m-d', strtotime("-1 days"));
			$key = $type == 6 ? "urlrecord6" . $time : "domaintip5" . $time;
			$errTip = $type == 6 ? 'url转发审核暂无数据' : '过期提醒暂时无数据';
			$recordList = $this->redis->hgetall($key);
			if(empty($recordList))
			{
				return $time . ' ' . $errTip;
			}
			$this->redis->delete($key);
			$return = array();
			$mod = new \models\manage\member\CustomerMod();
			foreach($recordList as $key => $record)
			{
				if(! is_numeric($key))
				{
					$cs = $mod->getCustomerByName($key, 'CSID');
					if($cs)
					{
						$key = $cs['CSID'];
					}
					else
					{
						\core\Log::write('notfinduser:' . $key, 'help', 'urlcount');
						$key = 100086; // 暂时未知的 一般情况不会出现
					}
				}
				$return[] = array('vtime' => $time, 'cscount' => $record, 'cstype' => $this->typeArr[$type - 1], 
						'csid' => $key);
			}
			\core\Log::write(json_encode(array($type => $recordList)), 'help', 'urlcount');
			return $this->addCustomerCount($return, $type);
		}
		catch(\Exception $e)
		{
			\core\Log::write($e->getMessage(), 'help', 'urlcount');
			return $e->getMessage();
		}
	}

	/**
	 * 获取统计情况(转移密码 绑定邮箱 绑定手机)
	 */
	public function getUserSetCount()
	{
		$date = date('Y-m-d', strtotime('-1 days'));
		$mod = new \models\manage\member\TransferpasswdMailMod('user');
		
		$email = $mod->getUsersetCount($this->typeArr[0], $date); // 绑定邮箱
		$email = array_merge($email, $this->getSecondVerify($this->typeArr[0], $date));
		$email = $this->addCsCount($email);
		
		$transferPass = $mod->getUsersetCount($this->typeArr[1], $date); // 转移密码
		$transferPass = array_merge($transferPass, $this->getSecondVerify($this->typeArr[1], $date));
		$transferPass = $this->addCsCount($transferPass);
		
		$mobile = $mod->getUsersetCount($this->typeArr[2], $date); // 手机绑定修改
		$mobile = array_merge($mobile, $this->getSecondVerify($this->typeArr[2], $date));
		$mobile = $this->addCsCount($mobile);
		
		$findPass = $mod->getUsersetCount($this->typeArr[8], $date); // 找回密码
		$findPass = array_merge($findPass, $this->getSecondVerify($this->typeArr[8], $date));
		$findPass = $this->addCsCount($findPass);
		
		$cancelOp = $mod->getUsersetCount($this->typeArr[9], $date); // 取消操作保护
		$cancelOp = array_merge($cancelOp, $this->getSecondVerify($this->typeArr[9], $date));
		$cancelOp = $this->addCsCount($cancelOp);
		
		$return = array_merge($email, $transferPass, $mobile, $findPass, $cancelOp);
		return $this->addCustomerCount($this->formatCount($return, '转移密码/邮箱手机绑定修改/找回密码/取消操作保护'));
	}

	public function getExpRemindCount()
	{
		$mod = new \models\manage\domain\DomainExpRemindMod();
		$date = date('Y-m-d', strtotime('-1 days'));
		$return = $mod->getExpRemindCount($date, $this->typeArr[4]);
		$notice = array();
		foreach($return as $info)
		{
			if(isset($notice[$info['VerifyUser']]))
			{
				$notice[$info['VerifyUser']]['cscount'] += 1;
			}
			else
			{
				$notice[$info['VerifyUser']] = $info;
			}
		}
		return $this->addCustomerCount($this->formatCount($notice, '域名过期提醒数据'), $this->typeArr[4]);
	}

	/**
	 * 获取安全警报处理统计
	 **/
	public function getSecureWarningCount()
	{
		try
		{
			$startTime = strtotime("yesterday");
			$endTime = strtotime('today');
			$mod = new \models\manage\member\SecureWarningMod();
			$result = $mod->getSecureWarningCount($this->typeArr[12], $startTime, $endTime);
			return $this->addCustomerCount($this->formatCount($result, '安全警报'), $this->typeArr[12]);
		}
		catch (\Exception $e)
		{
			\core\Log::write($e->getMessage(), 'help', 'secureWarningCount');
			return $e->getMessage();
		}
	}

	public function getFinanceFareCount()
	{
		try
		{
			$mod = new \models\manage\verify\ProxyInvoiceMod('verify');
			$start = date('Y-m-d 00:00:00',strtotime('-1 days'));
			$end = date('Y-m-d 23:59:59',strtotime('-1 days'));
			$result = $mod->getCustomerCount($start,$end);
			$result = array_merge($result,$this->getSecondVerify($this->typeArr[13], date('Y-m-d',strtotime($start))));
			return $this->addCustomerCount($this->formatCount($result, '发票委托'), $this->typeArr[13]);
		}
		catch (\Exception $e)
		{
			\core\Log::write($e->getMessage(), 'help', 'secureWarningCount');
			return $e->getMessage();
		}
	}	
	
	/**
	 * 格式化数据(认证相关)
	 */
	private function formatCount($countList, $show = '认证相关')
	{
		if(empty($countList))
		{
			echo (date('Y-m-d', strtotime('-1 days')) . ' ' . $show . "暂无数据");
			return FALSE;
		}
		$mod = new \models\manage\member\CustomerMod();
		$return = array();
		foreach($countList as $value)
		{
			$value['csid'] = $value['VerifyUser'];
			if(! is_numeric($value['VerifyUser']))
			{
				$cs = $mod->getCustomerByName($value['VerifyUser'], 'CSID');
				$value['csid'] = $cs ? $cs['CSID'] : $value['csid'];
			}
			unset($value['VerifyUser']);
			$return[] = $value;
		}
		return $return;
	}

	/**
	 * 数据入库
	 */
	private function addCustomerCount($list, $showType = 1)
	{
		if(! $list)
		{
			return false;
		}
		$interface = new \interfaces\help\Statistics();
		$succ = 0;
		$fail = 0;
		$return = $interface->work($list);
		$tip = '';
		if($showType == 1 || $showType == 2 || $showType == 3 || $showType == 9 || $showType == 10)
		{
			$tip = "id邮箱修改/转移密码申请/手机绑定/找回密码/取消操作保护";
		}
		else if($showType == 5)
		{
			$tip = "人工提醒列表";
		}
		else if($showType == 6)
		{
			$tip = "url转发审核";
		}
		else if($showType == 7 || $showType == 8 || $showType == 11 || $showType == 12)
		{
			$tip = "身份认证/企业认证/bbs认证/交易认证";
		}
		else if($showType == 13)
		{
			$tip = '安全警报';
		}elseif($showType == 14)
		{
			$tip="发票委托";
		}
		else
		{
			$tip = "展示页模版审核";
		}
		return $tip . $return['msg'] . PHP_EOL;
	}

	public function addCustomerCountSecond($data)
	{
		$mod = new \models\help\CustomerCountMod();
		$vid = $data->vid;
		$vtype = $data->vtype;
		$adminId = $data->adminId;
		$verifyTime = $data->verifyTime;
		$info = $mod->getCustomerCountOne($vid, $vtype, $adminId, $verifyTime);
		if($info)
		{
			$update = $mod->updateCustomerCount($vid, $vtype, $adminId, $verifyTime);
			if(! $update)
			{
				\core\Log::write("客服操作添加二次操作更新失败:" . $vid . '|' . $vtype . '|' . $adminId . '|' . $verifyTime, 
					"customercount", "customercount");
			}
			return $update;
		}
		else
		{
			$add = $mod->addCustomerCount($vid, $vtype, $adminId, $verifyTime);
			if(! $add)
			{
				\core\Log::write("客服操作添加二次操作失败:" . $vid . '|' . $vtype . '|' . $adminId . '|' . $verifyTime, 
					"customercount", "customercount");
			}
			return $add;
		}
	}

	public function getCustomerCountSecond($data)
	{
		$adminId = empty($data->adminId) ? '' : $data->adminId;
		$vtype = empty($data->vtype) ? '' : $data->vtype;
		$verifyTime = empty($data->verifyTime) ? '' : $data->verifyTime;
		$vid = empty($data->vid) ? '' : $data->vid;
		$limit = empty($data->limit) ? '' : $data->limit;
		$mod = new \models\help\CustomerCountMod();
		return $mod->getCustomerCountList($vid, $vtype, $adminId, $verifyTime, $limit);
	}
}

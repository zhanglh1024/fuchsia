<?php
namespace logic\manage\information;

use logic\manage\information\InformationLogic;
use models\manage\member\FriendMessageMod;
use models\manage\member\AppMemberextMod;
use models\manage\member\MemberFriendMod;
use core;

class FriendIndexLogic
{

	private $infoLogic;
	
	private $friendMod;
	
	private $memberMod;
	
	private $memberFriMod;
	
	private $appConfig;
	
	public function __construct()
	{
		$this->infoLogic = new InformationLogic();
		$this->friendMod = new FriendMessageMod();
		$this->memberMod = new AppMemberextMod();
		$this->memberFriMod = new MemberFriendMod();
		$this->appConfig = new \Yaf\Config\Ini(APP_PATH . '/conf/application.ini', 'product');
	}
	
	public function getFriendIndex($params)
	{
		$return = $eFriend = $eMessage = array();
		//易名服务封装处理
		$return['eService'] = self::getEService($params);
		//消息中心封装处理
		$return['eInfomation'] = self::getEInfomation($params);
		
		$enameId = empty($params['EnameId']) ? false : $params['EnameId'];
		if($enameId)
		{
			$eFriend = self::getEFriend($enameId);
			$eMessage = self::getEMessage($enameId);
		}
		$return['eFriend'] = $eFriend;
		$return['eMessage'] = $eMessage;
		return array('flag' => 1, 'msg' => $return);
	}
	
	/**
	 * 获取易名服务相关内容
	 * 包括：易名客服  易名经纪  新手指南  公告（活动）  域名新闻
	 */
	private function getEService($params)
	{
		//易名服务封装处理
		$result = $this->infoLogic->InformationIndex((object)$params);
		$sTemp = array('count' => 0, 'time' => 0, 'title' => '');
		if($result['flag'])
		{
			//一些返回字段的不统一，统一写临时配置处理
			$itmeConfig = array('announceInfo' => array('count', 'Title', 'CreateTime'), 'newInfo' => array('count', 'title', 'dateline'), 'activity' => array('count', 'Title', 'StartTime'),
					'officialActivity' => array('count', 'Title', 'StartTime'), 'helpInfo' => array('count', 'msg', 'SendTime'), 'escrowInfo' => array('count', 'msg', 'SendTime')
			);
			$info = $result['msg'];
			foreach($itmeConfig as $k => $v)
			{
				if(isset($info[$k]))
				{
					$sTemp['count'] += $info[$k][$v[0]];
					if($info[$k][$v[2]] > $sTemp['time'])
					{
						$sTemp['time'] = $info[$k][$v[2]];
						$sTemp['title'] = $info[$k][$v[1]];
					}
				}
			}
		}
		return $sTemp;
	}
	
	/**
	 * 获取消息中心相关内容
	 */
	private function getEInfomation($params)
	{
		$iTemp = array('count' => 0, 'time' => 0, 'title' => '');
		$enameId = empty($params['EnameId']) ? false : $params['EnameId'];
		if($enameId)
		{
			//消息中心封装处理
			$result = $this->infoLogic->InformationIndext((object)$params, false);
			if($result['flag'])
			{
				//array('count', 'Title', 'SendTime')
				$itmeConfig = array('systemInfo', 'domainoutInfo', 'transInfo');
				$info = $result['msg'];
				foreach($itmeConfig as $v)
				{
					if(isset($info[$v]))
					{
						$iTemp['count'] += $info[$v]['count'];
						if($info[$v]['SendTime'] > $iTemp['time'])
						{
							$iTemp['time'] = $info[$v]['SendTime'];
							$iTemp['title'] = $info[$v]['Title'];
						}
					}
				}
			}
		}
		return $iTemp;
	}
	
	/**
	 * 获取新的好友通知
	 */
	private function getEFriend($enameId)
	{
		$friendReList = array();
		$friendInfo = $this->friendMod->getReMessageInfo(array('ReStatus' => 0, 'Status' => 1, 'EnameId' => $enameId), '', 'CreatTime desc');
		if($friendInfo)
		{
			foreach($friendInfo as $v)
			{
				$memberInfo = $this->memberMod->getInfoByEnameId($v['FromId']);
				$friendShip = $this->memberFriMod->getInfo(array('EnameId' => $enameId, 'friendId' => $v['FromId'], 'status' => 3));
				$nickName = empty($memberInfo['NickName']) ? '易名用户' : $memberInfo['NickName'];
				$nickName = $friendShip && $friendShip['Remark'] ? $friendShip['Remark'] : $nickName;
				$title = $nickName."(".$v['FromId'].")";
				if($v['ReStatus'] == 0)
				{
					$title .= '请求加你为好友';
				}
				elseif($v['ReStatus'] == 1)
				{
					$title .= '接受了你的好友申请';
				}
				elseif($v['ReStatus'] == 2)
				{
					$title .= '拒绝了你的好友申请';
				}
				//头像处理
				$avatar = $this->appConfig->application->imgurl . '/noAvatar.png';
				if(!empty($memberInfo['Avatar']))
				{
					list($preName, $time) = explode('_', $memberInfo['Avatar']);
					$avatar = $this->appConfig->application->imgurl . $preName . '_118_' . $time;
				}
				$tempArray = array();
				$tempArray['id'] = $v['Id'];
				$tempArray['nickName'] = $nickName;
				$tempArray['fromId'] = $v['FromId'];
				$tempArray['title'] = $title;
				$tempArray['time'] = $v['CreatTime'];
				$tempArray['count'] = 1;
				$tempArray['avatar'] = $avatar;
				$friendReList[] = $tempArray;
			}
		}
		return $friendReList;
	}
	
	/**
	 * 获取新的好友消息
	 */
	private function getEMessage($enameId)
	{
		$friendMsgList = array();
		$msgList = $this->friendMod->getUnreadList(array('EnameId' => $enameId, 'Mtype' => 1, 'Status' => 1));
		if($msgList)
		{
			foreach($msgList as $v)
			{
				$memberInfo = $this->memberMod->getInfoByEnameId($v['FromId']);
				$friendShip = $this->memberFriMod->getInfo(array('EnameId' => $enameId, 'friendId' => $v['FromId'], 'status' => 3));
				$nickName = empty($memberInfo['NickName']) ? '易名用户' : $memberInfo['NickName'];
				$nickName = $friendShip && $friendShip['Remark'] ? $friendShip['Remark'] : $nickName;
				//头像处理
				$avatar = $this->appConfig->application->imgurl . '/noAvatar.png';
				if(!empty($memberInfo['Avatar']))
				{
					list($preName, $time) = explode('_', $memberInfo['Avatar']);
					$avatar = $this->appConfig->application->imgurl . $preName . '_118_' . $time;
				}
				$tempArray = array();
				$tempArray['nickName'] = $nickName;
				$tempArray['fromId'] = $v['FromId'];
				$tempArray['title'] = empty($v['Title']) ? $v['Content'] : $v['Title'];//客户端要求，好友消息，如果是分享的消息返回title，普通消息返回content，分享的消息title会有值，不是分享的消息title没有值
				$tempArray['time'] = $v['CreatTime'];
				$tempArray['count'] = $v['sum'];
				$tempArray['avatar'] = $avatar;
				$friendMsgList[] = $tempArray;
			}
		}
		return $friendMsgList;
	}
	
}

<?php
namespace logic\manage\information;

use models\manage\member\MemberMessageMod;
use core\Response;
class SiteMessageLogic
{
 
	/**
	 * 读取用户未读站内心数量
	 *
	 * @param $enameId
	 */
	public function getUnreadMessageCountByEnameId($enameId)
	{
		$messageMod = new \models\manage\member\MemberMessageMod();
		$unreadTotal = 0;
		
		if($enameId)
		{
			$data = $messageMod->getCount(array('EnameId' => $enameId, 'Status' => 0));
			if(isset($data['sum']))
			{
				$unreadTotal += $data['sum'];
			}
			$nowYear = date('Y');
			for($i = $nowYear - 1; $i >= 2010; $i--)
			{
				$data = $messageMod->getCount(array('byYear' => $i, 'EnameId' => $enameId, 'Status' => 0));
				if(isset($data['sum']))
				{
					$unreadTotal += $data['sum'];
				}
			}
		}
		return array('flag' => 1, 'msg' => $unreadTotal);
	}

	/**
	 * 设置站内信的状态（MessageId,EnameId） MessageId未传的时候设置全部为已读
	 *
	 * @param $data['MessageId']
	 * @param $data['EnameId']
	 * @param $data['Status'] 1已读，2回收站
	 * @param $data['byYear'] 查询年份
	 * @return array('flag' => 1, 'msg' => $res)
	 */
	public function setMessageStatus($data)
	{
		$mod = new \models\manage\member\MemberMessageMod();
		if(isset($data['Status']))
		{
			$setStatus = $data['Status'];
			unset($data['Status']);
		}
		else
		{
			$setStatus = 1;
		}
		if(!empty($data['MessageId']))
		{
			if(is_array($data['MessageId']))
			{
				$data['MessageIdIn'] = $data['MessageId'];
				unset($data['MessageId']);
			}
			$res = $mod->updateStatusBatch($data, $setStatus);
		}
		else
		{
			$res = $mod->updateAllStatus($data);
		}
		if($res)
		{
			if($data['EnameId'])
			{
				\common\Sync::syncSiteMsgCount($data['EnameId']);
			}
			return array('flag' => 1, 'msg' => $res);
		}
		return array('flag' => 0, 'msg' => '修改信息失败');
	}

	/**
	 * 获取站内信各个状态数量
	 *
	 * @param $data['EnameId']
	 * @param $data['Status'] 0未读,1已读，2回收站
	 * @param $data['byYear'] 查询年份
	 * @param $data['MessageType'] 站内信类型
	 * @param $data['Keywords'] 搜索词
	 * @return RpcResponse::msg($rs['msg']
	 */
	public function getMsgCountByStatus($data)
	{
		$mod = new \models\manage\member\MemberMessageMod();
		$res = $mod->getCount($data);
		if(isset($res['sum']))
		{
			return array('flag' => 1, 'msg' => $res['sum']);
		}
		return array('flag' => 0, 'msg' => '获取信息失败');
	}

	/**
	 * 获取站内信列表
	 *
	 * @param $data['EnameId']
	 * @param $data['Status'] 0未读,1已读，2回收站
	 * @param $data['byYear'] 查询年份
	 * @param $data['MessageType'] 站内信类型
	 * @param $data['Keywords'] 搜索词
	 * @param $data['limit'] 偏移量
	 * @return RpcResponse::msg($rs['msg']
	 */
	public function getMsgListByStatus($data)
	{
		$mod = new \models\manage\member\MemberMessageMod();
		$limit = empty($data['limit']) ? false : $data['limit'];
		$res = $mod->getList($data, $limit, 'SendTime DESC');
		if($res)
		{
			return array('flag' => 1, 'msg' => $res);
		}
		return array('flag' => 0, 'msg' => '修改信息失败');
	}

	/**
	 * 添加站内信
	 *
	 * @return RpcResponse::msg($rs['msg']
	 */
	public function addMessage($data)
	{
		if(empty($data['EnameId']) || empty($data['TemplateId']))
		{
			return array('flag' => false, 'msg' => 'Params Error');
		} 
		$smsLogic = new \logic\manage\queue\SmsLogic();
		$sendRes = $smsLogic->sendSiteMsg($data['EnameId'], $data['TemplateId'], $data['Data'], $data['MessageType']);
		if($sendRes)
		{
			return array('flag' => 1, 'msg' => '添加信息成功');
		}
		return array('flag' => 0, 'msg' => '添加信息失败');
	}

	/**
	 * 批量添加模板
	 *
	 * @param array $data
	 * @return boolean
	 */
	public function addBatchSiteMessage($data)
	{
		$templateNames = $params = array();
		$templateLib = new \lib\manage\newqueue\QueueTemplateLib();
		foreach($data as $value)
		{
			$templateNames[] = $value['TemplateId'];
		}
		$templateNames = array_unique($templateNames);
		// 获取模板
		$templateList = $templateLib->getTemplateListByTemplateNames($templateNames);
		$count = array();
		foreach($data as $value)
		{
			if(empty($value['EnameId']) || empty($value['TemplateId']) || empty($templateList[$value['TemplateId']]))
			{
				\core\Log::write('empty info' . json_encode($value),'message','temperr');
				continue;
			}
			$count[$value['EnameId']] = isset($count[$value['EnameId']]) ? $count[$value['EnameId']] + 1 : 1;
			$info = array();
			$info['EnameId'] = $value['EnameId'];
			$info['SendId'] = '10001';
			$info['MessageType'] = empty($value['MessageType']) ? 12 : $value['MessageType'];
			$templateInfo = $templateList[$value['TemplateId']];
			$templateData = $templateLib->substituteTemplateData($templateInfo, $value['Data']);
			$info['Content'] = $templateData['HtmlContent'];
			$info['Title'] = $templateData['TemplateTitle'];
			$info['Data'] = json_encode($value['Data']);
			$info['TemplateId'] = $value['TemplateId'];
			$params[] = $info;
		}
		$messageMod = new \models\manage\member\MemberMessageMod();
		//站内信数量添加redis
		if($rs = $messageMod->addBatchSiteMessage($params))
		{
			foreach ($count as $enameId => $num)
			{
				\common\Sync::syncSiteMsgCount($enameId, 1, $num);
			}
		}
		return $rs;
	}
}
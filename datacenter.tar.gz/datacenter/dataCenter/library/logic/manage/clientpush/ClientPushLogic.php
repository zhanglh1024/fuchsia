<?php 
namespace logic\manage\clientpush;
use core\form\ReturnData;
use core\Response;
class ClientPushLogic
{
	public function clientPush($info)
	{
		$pushconfigs = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'apppush');
		if(!$pushconfigs->open)
		{
			return array('flag'=>1,'msg'=>'推送成功');
		}
		$extra = array();
		$push = new \common\apppush\AppPush($info->adminid);
		if($info->type == 2)
		{
			$extra['msgtype'] = 4; //新闻
			$extra['id'] = $info->newsId;
		}
		elseif ($info->type == 4)
		{
			$extra['msgtype'] = 5;//公告
			$extra['url'] = $info->linkurl;
		}
		elseif ($info->type == 5)
		{
			$extra['msgtype'] = 6 ; //活动
			$extra['url'] = $info->linkurl;
		}
		elseif ($info->type == 6)
		{
			$extra['msgtype'] = 7; //官方活动
		}
		$push->push(array('flag'=>2,'title'=>$info->title ." :",'text'=>$info->msg,'extra'=>$extra));
		$push->push(array('flag'=>3,'title'=>$info->title,'text'=>$info->msg,'extra'=>$extra));
		return array('flag'=>1,'msg'=>'推送成功');
	}

}

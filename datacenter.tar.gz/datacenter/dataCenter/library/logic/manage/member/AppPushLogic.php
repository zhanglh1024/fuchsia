<?php
namespace logic\manage\member;

use core\Response;
class AppPushLogic
{

	private $config;

	private $memberMod;

	function __construct()
	{
		$configs = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'apppush');
		$this->config = $configs->messqueue;
		$this->memberMod = new \models\manage\member\EmemberMod('');
	}

	public function TransPush()
	{
		$appRedis = new \models\manage\redis\ApppushMod();
		$startMessId = $appRedis->getAppMessId('AppStartMessId');
		if(!$startMessId)
		{
			throw new \Exception('app 推送redis中 的 startMessId不存在！');
		}
		else
		{
			$interfaces = new \interfaces\manage\Member();
			$data['status'] = 0; // 未读状态
			$data['messId'] = $startMessId? $startMessId :0;
			$data['MessageTypeIn'] = array(3,12,26); // 域名到期提醒push
			$pushList = $interfaces->getSiteMessage($data);
			$temp = array(); // 保存 推送时的信息，不要重复取push信息
			if($pushList)
			{
				foreach($pushList as $k => $v)
				{
					if(isset($temp[$v['EnameId']]))
					{
						
						$push = new \common\apppush\AppPush($v['EnameId'], $temp[$v['EnameId']]['device_token']);
						$transFlag = $temp[$v['EnameId']]['transFlag'];
						$domainFlag = $temp[$v['EnameId']]['domainFlag'];
						$detailFlag = $temp[$v['EnameId']]['detailFlag'];
						$device_token = $temp[$v['EnameId']]['device_token'];
						$loginStatus = $temp[$v['EnameId']]['loginStatus'];
					}
					else
					{
						$member = new \interfaces\manage\Member();
						$pushInfo = $member->getAppPushInfo($v['EnameId']);
						if($pushInfo)
						{
							$temp[$v['EnameId']] = $pushInfo;
							$push = new \common\apppush\AppPush($v['EnameId'], $pushInfo['device_token']);
							$transFlag = $pushInfo['transFlag'];
							$domainFlag = $pushInfo['domainFlag'];
							$detailFlag = $pushInfo['detailFlag'];
							$device_token = $pushInfo['device_token'];
							$loginStatus = $pushInfo['loginStatus'];
						}
						else 
						{
							\core\Log::write($v['EnameId'].'获取推送消息失败!', 'app_push' );
							continue;
						}
					}
					
					if($transFlag == 1 && ($v['MessageType'] == 12 || $v['MessageType'] == 26) && $loginStatus == 2)
					{
						\core\Log::write($v['EnameId'] . '-' . '登录状态为: ' . $loginStatus . '-单播推送开始', 'app_push');
						$titleFlag = strlen($device_token) > 50? 1 :2;
						
						if($detailFlag == 1)
						{
							// 当交易确认或者时域名到期提醒的时候 ios 只是显示标题，Android 标题和内容。
							$data = array('text' => $v['Title'],'flag' => 1,
								'extra' => json_decode($v['ParamsCode'], true));
							$data['title'] = ($titleFlag == 1)? '' :'交易确认';
						}
						else
						{
							$data = array('text' => '您有1条新消息！','flag' => 1,
								'extra' => json_decode($v['ParamsCode'], true));
							$data['title'] = ($titleFlag == 1)? '' :'域名';
						}
						$data['extra']['msgtype'] = 2;
						$push->push($data);
					}
					if($domainFlag == 1 && $v['MessageType'] == 3 && $loginStatus == 2)
					{
						\core\Log::write($v['EnameId'] . '-' . '登录状态为: ' . $loginStatus . '-单播推送开始', 'app_push');
						$titleFlag = strlen($device_token) > 50? 1 :2;
						if($detailFlag == 1)
						{
							// 当交易确认或者时域名到期提醒的时候 ios 只是显示标题，Android 标题和内容。
							$data = array('text' => $v['Title'],'flag' => 1,
								'extra' => json_decode($v['ParamsCode'], true));
							$data['title'] = ($titleFlag == 1)? '' :'域名到期提醒';
						}
						else
						{
							$data = array('text' => '您有1条新消息！','flag' => 1,
								'extra' => json_decode($v['ParamsCode'], true));
							$data['title'] = ($titleFlag == 1)? '' :'域名';
						}
						$data['extra']['msgtype'] = 1;
						$data['extra']['domainstatus'] = ($v['TemplateId'] == 'domainNewExpMsg')? 1 :2;
						$push->push($data);
					}
				}
				unset($temp);
				$appRedis->setAppMessId($pushList[$k]['MessageId']); // 设置最后messid 为下一次推送的起始点
			}
		}
	}

	public function messPush()
	{
		$redis = \core\RedisLib::getInstance('common');
		$redisKey = 'sendmessqueue';
		$count = $redis->lSize($redisKey);
		$userlogic = new \logic\manage\member\UserMemberLogic();
		if($count)
		{
			for($i = 1; $i <= $count && $i <= $this->config->queueline; $i ++)
			{
				$data = $redis->rPop($redisKey);
				if(empty($data))
				{
					continue;
				}
				
				$userinfo = $userlogic->getAppBaseInfo($data['friendid']);
				if(time() < $userinfo['LoginStatus'] && $userinfo['ChatFlag'] = 1)
				{
					$titleFlag = strlen($userinfo['DeviceToken']) > 50? 1 :2;
					$push = new \common\apppush\AppPush($userinfo['EnameId'], $userinfo['DeviceToken']);
					$selfinfo = $userlogic->getAppBaseInfo($data['enameid']);
					$extra['nickName'] = empty($selfinfo['NickName'])? '易名用户' :$selfinfo['NickName'];
					$extra['avatar'] = $selfinfo['Avatar'];
					if($userinfo['DetailFlag'] == 1)
					{
						if(isset($data['checkflag']) && $data['checkflag'] == 1)
						{
							$title = ($titleFlag == 1)? '好友消息: ' :'好友消息';
							$text = $extra['nickName'] . '(' . $data['enameid'] . ')' . $data['content'];
						}
						else
						{
							$title = ($titleFlag == 1)? $extra['nickName'] . ': ' :$extra['nickName'];
							$text = $data['content'];
						}
					}
					else
					{
						$title = ($titleFlag == 1)? '' :'域名';
						$text = '您有新的好友消息！';
					}
					$extra['ifFriend'] = $data['iffriend'];
					$extra['chattype'] = $data['type'];
					$extra['msgtype'] = 3;
					$extra['CreatTime'] = time();
					$push->push(array('flag' => 1,'title' => $title,'text' => $text,'extra' => $extra));
					\core\Log::write("好友推送消息，推送给enameid:" . $data['friendid'] . ",内容：" . $data['content'], 'pushmess', 
						'pushfriendmess'); //
				}
			}
		}
	}
}
<?php
namespace logic\manage\whois;
use core\Response;
class WhoisLogic
{
	private $errorMessage = array('390001' => '域名不能为空', '390002' => '域名有误',
			'390003' => '参数错误', '390004' => '域名信息查询失败', '390005' => '域名的whois server为空',
			'390006' => '该域名未注册', '390007' => '该域名审核中', '390008' => '该域名被保留');
	private $lib;

	public function __construct()
	{
		$this->lib = new \common\WhoisLib();
	}

	/**
	 * 获取域名whois信息
	 * @param string $domain
	 * @param string $isNeedMail 为TRUE返回邮箱
	 * @throws \Exception
	 * @return boolean|array
	 */
	public function getWhois($domain, $isNeedMail = FALSE)
	{
		try
		{
			if(empty($domain))
			{
				throw new \Exception('domain有误', '390001');
			}
			$base = $this->lib->getWhoisBasicInfoByDomain($domain, $isNeedMail);
			if(is_numeric($base))
			{
				Response::setErrMsg($base, $this->errorMessage[$base]);
				return FALSE;
			}
			return (array) $base;
		}
		catch(\Exception $e)
		{
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}

	/**
	 * 获取whois详细信息
	 * @param string $domain
	 * @param string $whoisServer
	 * @throws \Exception
	 * @return boolean|string
	 */
	public function getWhoisDetail($domain, $whoisServer)
	{
		try
		{
			if(empty($domain))
			{
				throw new \Exception('domain有误', '390001');
			}
			if(empty($whoisServer))
			{
				throw new \Exception('WhoisServer有误', '390001');
			}
			$detail = $this->lib->getWhoisInfoByServer($domain, $whoisServer);
			if(is_numeric($detail))
			{
				Response::setErrMsg($detail, $this->errorMessage[$detail]);
				return FALSE;
			}
			return $detail;
		}
		catch(\Exception $e)
		{
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}

	/**
	 * 如果是限定注册商 返回空数组 非限定注册商返回域名 注册时间 过期时间 联系邮箱 注册商
	 *
	 * @param string $domain
	 */
	public function whoisRegisterCheck($domain)
	{
		$return = array();
		$whois = $this->getWhois($domain, true);
		if(!$whois)
		{
			$return['code']=Response::$errCode;
			$return['msg']=Response::$errMsg;
			$return['flag']=false;
		}
		else 
		{
			$return['flag']=true;
			$registerFlag = $this->lib->registerByWhoisInfo($whois["WhoisInfo"]);
			$return['data'] = array('AdministrativeEmail'=> $whois['AdministrativeEmail'],
					'SponsoringRegistrar'=> $whois['SponsoringRegistrar'],
					'RegistrationDate'=> $whois['RegistrationDate'],'ExpirationDate'=> $whois['ExpirationDate']);
			if(! $registerFlag)
			{
				$return['code']='390010';
				$return['msg']='非限定注册商的域名';
			}
			else 
			{
				$return['code']='390009';
				$return['msg']='限定注册商的域名';
			}
		}
		return $return;
	}
}

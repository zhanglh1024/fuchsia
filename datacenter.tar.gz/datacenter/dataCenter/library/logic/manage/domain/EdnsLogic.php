<?php
namespace logic\manage\domain;
use core\Response;
use \lib\manage\common\DomainFunLib;
class EdnsLogic
{
	private $configs;
	private $domainlib;
	private $ednsLib;
	public function __construct()
	{
		$this->configs = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'edns');
		$this->domainlib = new \lib\manage\domain\DomainManageLib();
		$this->ednsLib = new \lib\manage\domain\DomainEdnsBaseLib();
	}
	
	/**
	 * 添加域名
	 * @param string $domains='hush1.com'
	 * @param int $enameid=317363
	 * @return {data:{"status":"","msg":"","code":""}}
	 */
	public function addDomain($info)
	{
		$domain = $info->domain;
		$enameid = empty($info->enameId) ? 0 : intval($info->enameId);
		$clientIp = $info->ip;
		if(empty($domain) || empty($enameid))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');//该域名不属于操作者
		}
		$checkDomain = $this->checkDomainByEnameId($enameid, $domain);
		if(FALSE === $checkDomain)
		{
			Response::setErrMsg('800001', '域名不属于操作者');
			return array('flag' => 0, 'msg' => '域名不属于操作者');//该域名不属于操作者
		}
		$return = $this->ednsLib->addDomain($domain, $enameid ,$clientIp);
		return array('flag' => 1, 'msg' => $return);
	}
	
	/**
	 * 域名加锁
	 *  * @param string $domains='hush1.com'
	 * @param int $enameid=317363
	 * @return {data:{"status":"","msg":"","code":""}}
	 */
	public function domainLock($info)
	{
		$domain = $info->domain;
		$enameid = empty($info->enameId) ? 0 : intval($info->enameId);
		$clientIp = $info->ip;
		if(empty($domain) || empty($enameid))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');//该域名不属于操作者
		}
		$checkDomain = $this->checkDomainByEnameId($enameid, $domain);
		if(FALSE === $checkDomain)
		{
			Response::setErrMsg('800001', '域名不属于操作者');
			return array('flag' => 0, 'msg' => '域名不属于操作者');//该域名不属于操作者
		}
		$return = $this->domainNoExist($domain,$enameid);
		if($return !== TRUE)
		{
			return $return;
		}
		$recordInfo = $this->ednsLib->domainLock($domain,$clientIp);
		return array('flag' => 1, 'msg' => $recordInfo);
	}
	
	/**
	 * 域名解锁
	 *  * @param string $domains='hush1.com'
	 * @param int $enameid=317363
	 * @return {data:{"status":"","msg":"","code":""}}
	 */
	public function domainUnLock($info)
	{
		$domain = $info->domain;
		$enameid = empty($info->enameId) ? 0 : intval($info->enameId);
		$clientIp = $info->ip;
		if(empty($domain) || empty($enameid))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');//该域名不属于操作者
		}
		$checkDomain = $this->checkDomainByEnameId($enameid, $domain);
		if(FALSE === $checkDomain)
		{
			Response::setErrMsg('800001', '域名不属于操作者');
			return array('flag' => 0, 'msg' => '域名不属于操作者');//该域名不属于操作者
		}
		$return = $this->domainNoExist($domain,$enameid);
		if($return !== true)
		{
			return $return;
		}
		$recordInfo = $this->ednsLib->domainUnLock($domain,$clientIp);
		return array('flag' => 1, 'msg' => $recordInfo);
	}
	
	/**
	 * 域名设置为展示页
	 *  * @param string $domains='hush1.com'
	 * @param int $enameid=317363
	 * @return {data:{"status":"","msg":"","code":""}}
	 */
	public function domainCustompage($info)
	{
		$domain = $info->domain;
		$enameid = empty($info->enameId) ? 0 : intval($info->enameId);
		$clientIp = $info->ip;
		if(empty($domain) || empty($enameid))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');//该域名不属于操作者
		}
		$domainInfo = $this->ednsLib->recordList($domain);
		if(!$domainInfo['status'] && $domainInfo['code'] == '20001')
		{
			\core\Log::write('查询域名:' . $domain . '记录失败', 'manage/edns');
			//域名不存在iidns库的域名表，执行添加域名操作，失败返回错误码
			$res = $this->ednsLib->addDomain($domain, $enameid,$clientIp);
			if($res['status'] === FALSE)
			{
				Response::setErrMsg('800002', '域名添加失败');
				return array('flag' => 0, 'msg' => '域名添加失败');
			}
		}
		$recordInfo = $this->ednsLib->domainCustompage($domain,$clientIp);
		return array('flag' => 1, 'msg' => $recordInfo);
	}
	
	/**
	 * 域名解析记录列表
	 * @param string $domain
	 * @param int $pageNum 第一页$pageNum=0，第二页$pageNum=1，以此类推
	 * @return {data:{"status":"","msg":"","code":"","data":{}}}
	 * 记录条数默认30条
	 */
	public function recordList($info)
	{
		$domain = $info->domain;
		$clientIp = $info->ip ? $info->ip : \common\Common::getRequestIp();
		if(empty($domain))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		$pageNum = empty($info->page) ? 0 : $info->page;
		$pageSize = empty($info->perpage) ?30 : $info->perpage;
		$pagetype = empty($info->pagetype) ? 'all' : strtolower($info->pagetype);
		$subDomain = empty($info->subdomain) ? '' : strtolower($info->subdomain);
		$recordType = empty($info->rtype) ? '' : $info->rtype;
		if($recordType == 4 || $recordType == 8 || $recordType == 6)
		{
			$recordValue = empty($info->rvalue) ? '' : $info->rvalue;
		}
		else
		{
			$recordValue = empty($info->rvalue) ? '' : strtolower($info->rvalue);
		}
		$line = empty($info->rline) ? '' : $info->rline;
		$clientIp = empty($info->ip) ?'' : $info->ip;
		$platform = empty($info->platform) ? '' : $info->platform;
		$rs = $this->checkDnHold(array('domain'=>$domain), 0 , true, $platform);
		if($rs !== true)
		{
			return $rs;
		}
		$return = $this->domainNoExist($domain);
		if($return !== TRUE)
		{
			return $return;
		}
		$recordInfo = $this->ednsLib->recordList($domain, $pageNum,$pageSize,$pagetype,$subDomain,$line,$recordType,$recordValue,$clientIp);
		return array('flag' => 1, 'msg' => $recordInfo);
	}
	
	/**
	 * 根据域名创建域名解析记录
	 * @param string $domain 域名格式
	 * @param string $subDomain 主机头 如@、www
	 * @param int $rline 线路类型  1通用、2电信、3联通、4教育网
	 * @param int $rtype 记录类型 1A、2CNAME、3MX、4URL、5NS、6TXT、7AAAA、8URL0
	 * @param int $ttl ttl值 如600
	 * @param string $value 解析记录值
	 * @param int $extra mx优先级
	 * @return {data:{"status":"","msg":"","code":"","data":{}}}
	 */
	public function createRdByDn($info)
	{
		$domainName = $info->domain;
		$enameid = empty($info->enameId) ? 0 : intval($info->enameId);
		$clientIp = $info->ip ? $info->ip : \common\Common::getRequestIp();
		$subDomain = empty($info->subdomain) ? '@' : strtolower($info->subdomain);
		$recordType = empty($info->rtype) ? '' : $info->rtype;
		if($recordType == 4 || $recordType == 8 || $recordType == 6)
		{
			$recordValue = empty($info->rvalue) ? '' : $_POST['rvalue'];
		}
		else
		{
			$recordValue = empty($info->rvalue) ? '' : strtolower($_POST['rvalue']);
		}
		$lineType = empty($info->rline) ? '' : $info->rline;
		$clientIp = empty($info->ip) ?'' : $info->ip;
		$ttl = empty($info->ttl) ? 600 : $info->ttl;
		$extra = empty($info->extra) ? 10 : $info->extra;
		if(empty($domainName) || empty($subDomain) || empty($lineType) || empty($recordType) || empty($recordValue) || empty($ttl))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}		
		$checkDomain = $this->checkDomainByEnameId($enameid, $domainName);
		if(FALSE === $checkDomain)
		{
			Response::setErrMsg('800001', '域名不属于操作者');
			return array('flag' => 0, 'msg' => '域名不属于操作者');//该域名不属于操作者
		}
		$rs = $this->checkDnHold($checkDomain , $enameid);
		if(TRUE !== $rs)
		{
			return $rs;
		}
		$return = $this->checkIsTmpTpl($domainName, !empty($checkDomain['TemplateId']) ? $checkDomain['TemplateId'] : FALSE);
		if(TRUE !== $return)
		{
			return $return;
		}
		$domainInfo = $this->ednsLib->recordList($domainName);
		if(!$domainInfo['status'] && $domainInfo['code'] == '20001')
		{
			\core\Log::write('查询域名:' . $domainName . '记录失败', 'manage/edns');
			//域名不存在iidns库的域名表，执行添加域名操作，失败返回错误码
			$res = $this->ednsLib->addDomain($domainName, $enameid,$clientIp);
			if($res['status'] === FALSE)
			{
				Response::setErrMsg('800002', '域名添加失败');
				return array('flag' => 0, 'msg' => '域名添加失败');
			}
		}
	
		$checkStatus = $this->checkRecord($subDomain, $recordType, $recordValue, $lineType, $extra, $ttl);
		if(TRUE === $checkStatus)
		{
			$recordInfo = $this->ednsLib->createRdByDn($domainName, $subDomain, $lineType, $recordType, $recordValue, $ttl, $extra,$clientIp);
			return array('flag' => 1, 'msg' => $recordInfo);
		}
		else
		{
			return  $checkStatus;
		}
	}
	
	/**
	 * 根据域名修改域名解析记录
	 * @param string $domain 域名格式
	 * @param string $subDomain 主机头 如@、www
	 * @param int $rline 线路类型  1通用、2电信、3联通、4教育网
	 * @param int $rtype 记录类型 1A、2CNAME、3MX、4URL、5NS、6TXT、7AAAA、8URL0
	 * @param int $ttl ttl值 如600
	 * @param string $value 解析记录值
	 * @param int $extra mx优先级
	 * @return {data:{"status":"","msg":"","code":"","data":{}}}
	 */
	public function modify($info)
	{
		$domainName = $info->domain;
		$enameId = empty($info->enameId) ? 0 : intval($info->enameId);
		$clientIp = $info->ip ? $info->ip : \common\Common::getRequestIp();
		$subDomain = empty($info->subdomain) ? '@' : strtolower($info->subdomain);
		$recordType = empty($info->rtype) ? '' : $info->rtype;
		if($recordType == 4 || $recordType == 8 || $recordType == 6)
		{
			$recordValue = empty($info->rvalue) ? '' : $_POST['rvalue'];
		}
		else
		{
			$recordValue = empty($info->rvalue) ? '' : strtolower($_POST['rvalue']);
		}
		$lineType = empty($info->rline) ? '' : $info->rline;
		$ttl = empty($info->ttl) ? 600 : $info->ttl;
		$extra = empty($info->extra) ? 10 : $info->extra;
		$dId = empty($info->did) ? '' : $info->did;
		$recordId = empty($info->drid) ? '' : $info->drid;
		if(empty($domainName) || empty($dId) || empty($recordId) || empty($subDomain) || empty($lineType) || empty($recordType) || empty($recordValue) || empty($ttl))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		$checkDomain = $this->checkDomainByEnameId($enameId, $domainName);
		if(FALSE === $checkDomain)
		{
			Response::setErrMsg('800001', '域名不属于操作者');
			return array('flag' => 0, 'msg' => '域名不属于操作者');//该域名不属于操作者
		}
		$rs = $this->checkDnHold($checkDomain, $enameId);
		if(TRUE !== $rs)
		{
			return $rs;
		}
		$return = $this->checkIsTmpTpl($domainName, !empty($checkDomain['TemplateId']) ? $checkDomain['TemplateId'] : FALSE);
		if(TRUE !== $return)
		{
			return $return;
		}
		$checkStatus = $this->checkRecord($subDomain, $recordType, $recordValue, $lineType, $extra, $ttl);
		if(TRUE === $checkStatus)
		{
			$oldRecord = $this->ednsLib->recordInfo($domainName, $recordId);
			if(!empty($oldRecord['status']) && !empty($oldRecord['data']))
			{
				if($this->isChangeRecord($oldRecord['data'], $subDomain, $lineType, $recordType, $recordValue,$extra,$ttl))
				{
					\core\Log::write($domainName . '修改记录,解析记录未变化直接返回' . $subDomain . ','.$recordValue .','.$recordType. ','.$lineType, 'manage/edns');
					return array('flag'=>1,'msg'=>array('status'=>true,'msg'=>'修改编辑解析记录成功'));
				}
			}
			$recordInfo = $this->ednsLib->modify($domainName, $dId, $recordId, $subDomain, $lineType, $recordType, $recordValue, $ttl, $extra,$clientIp);
			if($recordInfo['status'] === FALSE)
			{
				\core\Log::write($domainName . '修改记录' . $recordId . '修改记录失败', 'manage/edns');
			}
			return array('flag'=>1,'msg'=>$recordInfo);
		}
		else
		{
			return $checkStatus;
		}
	}
	
	private function isChangeRecord($oldRecord,$subDomain,$lineType,$recordType,$recordValue,$extra,$ttl)
	{
		if($oldRecord['sub_domain'] == $subDomain && $oldRecord['record_line'] == $lineType && $oldRecord['record_type'] == $recordType && $oldRecord['value'] == $recordValue && $oldRecord['ttl'] == $ttl)
		{
			if($oldRecord['record_type'] == 3)
			{
				if($oldRecord['extra'] == $extra)
				{
					return TRUE;
				}
			}
		}
		return FALSE;
	}
	
	/**
	 * 删除域名解析记录
	 * @param string $domain 域名格式
	 * @param int drId 域名解析记录ID
	 * @param int dId 域名ID
	 * @return {data:{"status":"","msg":"","code":""}}
	 */
	public function removeRecord($info)
	{
		$domain = $info->domain;
		$enameid = empty($info->enameId) ? 0 : intval($info->enameId);
		$clientIp = $info->ip ? $info->ip : \common\Common::getRequestIp();
		$dId = empty($info->did) ? '' : $info->did;
		$drId = empty($info->drid) ? '' : $info->drid;
		if(empty($domain) || empty($dId) || empty($drId) ||empty($enameid))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		$checkDomain = $this->checkDomainByEnameId($enameid, $domain);
		if(FALSE === $checkDomain)
		{
			Response::setErrMsg('800001', '域名不属于操作者');
			return array('flag' => 0, 'msg' => '域名不属于操作者');//该域名不属于操作者
		}
		$return = $this->checkIsTmpTpl($domain, !empty($checkDomain['TemplateId']) ? $checkDomain['TemplateId'] : FALSE);
		if(TRUE !== $return)
		{
			return $return;
		}
	
		$recordInfo = $this->ednsLib->removeRecord($domain, $dId, $drId,$clientIp);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	
	/**
	 * 启用域名解析记录
	 * @param string $domain 域名格式
	 * @param int drId 域名解析记录ID
	 * @param int dId 域名ID
	 * @return {data:{"status":"","msg":"","code":""}}
	 */
	public function recordEnable($info)
	{
		$domain = $info->domain;
		$enameid = empty($info->enameId) ? 0 : intval($info->enameId);
		$clientIp = $info->ip;
		$dId = empty($info->did) ? '' : $info->did;
		$drId = empty($info->drid) ? '' : $info->drid;
		if(empty($domain) || empty($dId) || empty($drId) || empty($enameid))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		$checkDomain = $this->checkDomainByEnameId($enameid, $domain);
		if(FALSE === $checkDomain)
		{
			Response::setErrMsg('800001', '域名不属于操作者');
			return array('flag' => 0, 'msg' => '域名不属于操作者');//该域名不属于操作者
		}
		$return = $this->checkIsTmpTpl($domain, !empty($checkDomain['TemplateId']) ? $checkDomain['TemplateId'] : FALSE);
		if(TRUE !== $return)
		{
			return $return;
		}
		$recordInfo = $this->ednsLib->recordEnable($domain, $dId, $drId,$clientIp);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	/**
	 * 停用域名解析记录
	 * @param string $domain 域名格式
	 * @param int drId 域名解析记录ID
	 * @param int dId 域名ID
	 * @return {data:{"status":"","msg":"","code":""}}
	 */
	public function recordDisable($info)
	{
		$domain = $info->domain;
		$enameid = empty($info->enameId) ? 0 : intval($info->enameId);
		$clientIp = $info->ip;
		$dId = empty($info->did) ? '' : $info->did;
		$drId = empty($info->drid) ? '' : $info->drid;
		if(empty($domain) || empty($dId) || empty($drId) || empty($enameid))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		$checkDomain = $this->checkDomainByEnameId($enameid, $domain);
		if(FALSE === $checkDomain)
		{
			Response::setErrMsg('800001', '域名不属于操作者');
			return array('flag' => 0, 'msg' => '域名不属于操作者');//该域名不属于操作者
		}
		$return = $this->checkIsTmpTpl($domain, !empty($checkDomain['TemplateId']) ? $checkDomain['TemplateId'] : FALSE);
		if(TRUE !== $return)
		{
			return $return;
		}
		$recordInfo = $this->ednsLib->recordDisable($domain, $dId, $drId,$clientIp);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	/**
	 * 暂停或启动域名解析
	 */
	public function recordHandle($info)
	{
		$domain = $info->domain;
		$enable = $info->enable;
		$remark = $info->remark;
		$enameId = $info->enameId;
		$clientIp = $info->ip;
		if(empty($domain) || empty($enable) || empty($enameId))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		if(FALSE === $this->checkDomainByEnameId($enameId, $domain))
		{
			Response::setErrMsg('800001', '域名不属于操作者');
			return array('flag' => 0, 'msg' => '域名不属于操作者');//该域名不属于操作者
		}
		$recordInfo = $this->ednsLib->isPause($domain, $enable,$remark, $clientIp);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	
	/**
	 * 域名解析记录详情
	 * @param string $domain
	 * @param int $drId 解析记录ID
	 * @return {data:{"status":"","msg":"","code":"","data":{}}}
	 */
	public function recordInfo($info)
	{
		$domain = $info->domain;
		$clientIp = $info->ip ? $info->ip : \common\Common::getRequestIp();
		$drId = empty($info->drid) ? '' : $info->drid;
		if(empty($domain) || empty($drId) )
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		$return = $this->checkIsTmpTpl($domain);
		if(TRUE !== $return)
		{
			return $return;
		}
		$return = $this->domainNoExist($domain);
		if($return !== TRUE)
		{
			return $return;
		}
		$recordInfo = $this->ednsLib->recordInfo($domain, $drId,$clientIp);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	
	/**
	 * URL转发审核列表
	 * @param string $pagetype 当$pagetype ='where'时可以使用条件搜索
	 * @param int $urlType url转发类型 1隐藏 2非隐藏
	 * @param int $auditStatus 转发记录审核状态 '1' => '审核中','2' => '审核成功','3' => '审核失败',
	 * @param int $errorStatus 转发记录错误状态 '1'=>'正常','2'=>'违规内容','3'=>'目标地址未备案','4'=>'目标地址动态IP','5'=>'目标地址不能访问','6'=>'不支持此类转发','7'=>'目标地址无具体内容'
	 * @param int $pageSize 分页大小
	 * @param int $pageNum 分页页码,首页为0
	 */
	
	public function auditList($info)
	{
		$pageNum = empty($info->page) ? 0 : $info->page;
		$pageSize = empty($info->perpage) ? '' : $info->perpage;
		$pagetype = empty($info->pagetype) ? 'all' : $info->pagetype;
		$clientIp = empty($info->ip) ?'' : $info->ip;
		$urlType = empty($info->urlType) ?'' : $info->urlType;
		$auditStatus = !isset($info->auditStatus) ? 0 : $info->auditStatus;
		$errorStatus = !isset($info->errorStatus) ?'' : $info->errorStatus;
		$domain = $info->domain;
		$url = empty($info->forwardUrl) ?'' : $info->forwardUrl;
		$admin = empty($info->admin) ?'' : $info->admin;
		$startTime = empty($info->startTime) ?'' : $info->startTime;
		$endTime = empty($info->endTime) ?'' : $info->endTime;
		$recordInfo = $this->ednsLib->auditList($pagetype, $pageNum, $pageSize, $urlType, $auditStatus, $errorStatus,$domain,$url,$clientIp,$admin,$startTime,$endTime);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	
	/**
	 * URL转发审核操作
	 * @param int $drId 域名解析记录ID
	 * @param int $errorStatus 转发记录错误状态 '1'=>'正常','2'=>'违规内容','3'=>'目标地址未备案','4'=>'目标地址动态IP','5'=>'目标地址不能访问','6'=>'不支持此类转发','7'=>'目标地址无具体内容'
	 * @return {data:{"status":"","msg":"","code":""}}
	 */
	public function audit($info)
	{
		$drId = empty($info->drId) ? '' : $info->drId;
		$errorStatus = !isset($info->errorStatus) ? '' : $info->errorStatus;
		$clientIp = empty($info->ip) ?'' : $info->ip;
		if(empty($drId) || empty($errorStatus))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		$adminId = !empty($info->adminId) ? $info->adminId : '';
		$recordInfo = $this->ednsLib->audit($drId, $errorStatus,$clientIp,$adminId);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	
	/**
	 * 批量修改url转发审核记录
	 * @param array $drId
	 * @param int $errorStatus 转发记录错误状态 '1'=>'正常','2'=>'违规内容','3'=>'目标地址未备案','4'=>'目标地址动态IP','5'=>'目标地址不能访问','6'=>'不支持此类转发','7'=>'目标地址无具体内容'
	 * @param string $clientIp
	 */
	public function batchAudit($info)
	{
		$drId = empty($info->drId) ? '' : $info->drId;
		$errorStatus = !isset($info->errorStatus) ? '' : $info->errorStatus;
		$clientIp = empty($info->ip) ?'' : $info->ip;
		if(empty($drId) || empty($errorStatus))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		$adminId = !empty($info->adminId) ? $info->adminId : '';
		$recordInfo = $this->ednsLib->batchAudit(explode(',',$drId), $errorStatus,$clientIp,$adminId);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	
	
	/**
	 * URL转发白名单列表
	 * @param string $pagetype 当$pagetype ='where'时可以使用条件搜索
	 * @param int $pageNum 分页页码,首页为0
	 * @param int $urdStatus 转发记录审核状态 '1' => '审核中','2' => '审核成功','3' => '审核失败',
	 * @param int $pageSize 分页大小
	 * @return {data:{"status":"","msg":"","code":"","data":{}}}
	 *
	 */
	public function urlDomainList($pagetype = 'all', $pageNum = 0, $pageSize = NULL, $urdStatus = NULL,$clientIp = '')	
	{
		$pageNum = empty($info->page) ? 0 : $info->page;
		$pageSize = empty($info->perpage) ? '' : $info->perpage;
		$pageType = empty($info->pagetype) ? 'all' : $info->pagetype;
		$clientIp = empty($info->ip) ?'' : $info->ip;
		$urdStatus = empty($info->urdStatus) ? '' : $info->urdStatus;
		$recordInfo = $this->ednsLib->urlDomainList($pageType, $pageNum, $pageSize, $urdStatus,$clientIp);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	
	/**
	 * 添加新的URL转发白名单
	 * @param string $urdvalue 值只能为IPV4与域名
	 * @param int $urdStatus 转发记录审核状态 '1' => '审核中','2' => '审核成功','3' => '审核失败',不填或者不再给定范围的值一律审核中
	 * @return {data:{"status":"","msg":"","code":"","data":{}}}
	 */
	public function addWhiteList($info)
	{
		$urdvalue = empty($info->urdvalue) ? '' : strtolower($info->urdvalue);
		$urdStatus = empty($info->urdStatus) ? 1 : $info->urdStatus;
		$clientIp = empty($info->ip) ?'' : $info->ip;
		if(empty($urdvalue))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		$recordInfo = $this->ednsLib->addWhiteList($urdvalue, $urdStatus,$clientIp);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	
	/**
	 * 编辑的URL转发白名单
	 * @param int $urdId 转发白名单表ID
	 * @param string $urdvalue 值只能为IPV4与域名
	 * @param int $urdStatus 转发记录审核状态 '1' => '审核中','2' => '审核成功','3' => '审核失败',不填或者不再给定范围的值一律审核中
	 * @return {data:{"status":"","msg":"","code":"","data":{}}}
	 */
	public function editWhiteList($info)
	{
		$urdvalue = empty($info->urdvalue) ? '' : strtolower($info->urdvalue);
		$urdStatus = empty($info->urdStatus) ?3 : $info->urdStatus;
		$urdId = empty($info->urdId) ? '' : strtolower($info->urdId);
		$clientIp = empty($info->ip) ?'' : $info->ip;
		if(empty($urdId) || empty($urdvalue))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		$recordInfo = $this->ednsLib->editWhiteList($urdId, $urdvalue, $urdStatus,$clientIp);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	
	/**
	 * 删除的URL转发白名单
	 * @param int $urdId 转发白名单表ID
	 * @return {data:{"status":"","msg":"","code":"","data":{}}}
	 */
	public function urldRemove($info)
	{
		$urdId = empty($info->urdId) ? '' : strtolower($info->urdId);
		$clientIp = empty($info->ip) ?'' : $info->ip;
		if(empty($urdId))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		$recordInfo = $this->ednsLib->urldRemove($urdId,$clientIp);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	
	/**
	 * 域名日志列表信息
	 * @params str $domain 域名
	 * @params int $pageNum 分页页码
	 * @params int $pageSize 分页大小
	 *@return {data:{"status":"","msg":"","code":"","data":{}}}
	 */
	
	public function domainLogList($info)
	{
		$domain = empty($info->domain) ? '' : strtolower($info->domain);
		$pageNum = empty($info->page) ? 0 : $info->page;
		$pageSize = empty($info->perpage) ?15 : $info->perpage;
		$pageType = empty($info->pagetype) ? 0 : $info->pagetype;
		$clientIp = empty($info->ip) ?'' : $info->ip;
		if(empty($domain) || empty($pageSize))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		$recordInfo = $this->ednsLib->domainLogList($domain, $pageNum, $pageSize,$pageType,$clientIp);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	/**
	 * 根据解析记录id  获取 域名信息
	 * @params $drId  解析记录id
	 * @return {data:{"status":"","msg":"","code":"","data":{}}}
	 */
	public function domainInfo($info)
	{
		$clientIp = empty($info->ip) ?'' : $info->ip;
		$drId = empty($info->drId) ? '' : $info->drId;
		if(empty($drId))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		$recordInfo = $this->ednsLib->domainInfo($drId,$clientIp);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	
	/**
	 * 域名信息
	 * @params str $domain
	 * @return {data:{"status":"","msg":"","code":"","data":{}}}
	 */
	public function domainInfoByDn($info)
	{
		$domain = empty($info->domain) ? '' : strtolower($info->domain);
		$clientIp = empty($info->ip) ?'' : $info->ip;
		if(empty($domain))
		{
			Response::setErrMsg('800000', '参数错误 ');
			return array('flag' => 0, 'msg' => '参数错误 ');
		}
		$recordInfo = $this->ednsLib->domainInfoByDn($domain,$clientIp);
		return array('flag'=>1,'msg'=>$recordInfo);
	}
	
	/**
	 *
	 * checkDomainByEnameId
	 * @param  $enameId
	 * @param  $domain
	 * return_type
	 */
	private function checkDomainByEnameId($enameId, $domain)
	{
		$cumsid = $this->configs->custom->enameId313->toArray();
		if(in_array($enameId, $cumsid))
		{
			//如果enameid是313特定账号，直接绕过域名判断
			$domainInfo['DnsType'] = '0';
			return $domainInfo;
		}
		$domainInfo = $this->getDomainInfo($domain,$enameId);
		if(FALSE === $domainInfo)
			return FALSE;
		else
			return $domainInfo;
	}
	/**
	 *
	 *  getDomainInfo
	 * @param  $domain
	 * @param  $enameId
	 * @return array|boolean
	 */
	private function getDomainInfo($domain, $enameId = FALSE)
	{
		if(FALSE == $enameId)
		{
			$where = array('DomainName' => $domain);
		}
		else
		{
			$where = array('DomainName' => $domain, 'EnameId' => $enameId);
		}
		$domainInfo = $this->domainlib->getDomainInfo($where, 'EnameId, DomainId, DomainName, DnsType, TemplateId,DomainMyStatus');
		if(!$domainInfo)
			return FALSE;
		else
			return $domainInfo;
	}
	
	/**
	 *
	 * checkRecord  验证各个参数规则
	 * @param string $domainName
	 * @param string $subDomain
	 * @param int $recordType
	 * @param string $recordValue
	 * @param int $lineType
	 * @param string $extra
	 * @param int $ttl
	 * @return boolean
	 * boolean
	 */
	private function checkRecord($subDomain, $recordType, $recordValue, $lineType, $extra, $ttl)
	{
		$recordCode = $this->configs->record->type->code;
	
		if('*' == $subDomain && 1 != $recordType && 2 != $recordType && 4 != $recordType && 8 != $recordType)
		{
			Response::setErrMsg('800007', '只有A记录,cname记录和URL转发才能添加泛解析');
			return array('flag' => 0, 'msg' => '只有A记录,cname记录和URL转发才能添加泛解析');
		}
		//只有A记录和cname记录才能添加泛解析
	
		if($recordType == $recordCode->MX && ($extra < 0 || $extra > 100))
		{
			Response::setErrMsg('800008', 'MX优先级必须为0-100');
			return array('flag' => 0, 'msg' => 'MX优先级必须为0-100');
		}
		//MX优先级必须大与0小与100
	
		if(!$ttl > 0)
		{
			Response::setErrMsg('800009', 'TTL必须为1以上');
			return array('flag' => 0, 'msg' => 'TTL必须为1以上');
		}
		//TTL值必需大于0
	
		if($recordType == $recordCode->NS && $subDomain == '@')
		{
			Response::setErrMsg('800010', '不能为@主机进行NS授权泛解析');
			return array('flag' => 0, 'msg' => '不能为@主机进行NS授权');
		}
		//不能为@主机进行NS授权
	
		if(!$this->isValidSubDomain($subDomain))
		{
			Response::setErrMsg('800011', '主机头非法');
			return array('flag' => 0, 'msg' => '主机头非法');
		}
		//验证主机头是否合法
	
		$valueCheck = $this->isValidRecord($recordValue, $recordType);
		if(TRUE !== $valueCheck)
			return $valueCheck;
		//判断记录值非法，返回具体错误信息
	
		return TRUE;
	}
	/**
	 *	检查域名是否有锁定(注册商|局锁定提示信息)或者DNS非我司
	 * @param string $dn
	 * @param string $enameId
	 */
	public function checkDnHold($domainInfo , $enameId ,$unenameid = false, $platform = '')
	{
		$cumsid = $this->configs->custom->enameId313->toArray();
		if(in_array($enameId, $cumsid))
		{
			//如果enameid是313特定账号，直接绕过域名判断
			return TRUE;
		}
		if($unenameid)
		{
			$domain = $domainInfo['domain'];
			unset($domainInfo);
			$domainInfo = $this->getDomainInfo($domain , FALSE);
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
			if(empty($domainInfo['TemplateId']) || $conf->template->temp->id == $domainInfo['TemplateId'] || in_array($domainInfo['TemplateId'], explode(',', $conf->template->temp->historyid)))
			{
				Response::setErrMsg('800005', '使用临时模板，无法进行解析操作，请先添加实名模板');
				return array('flag' => 0, 'msg' => '使用临时模板，无法进行解析操作，请先添加实名模板');
			}
		}
		//管理后台查看域名解析记录不判断状态 2015-02-16
		if($platform != 'admin' && !\lib\manage\common\DomainFunLib::checkSecureStatus($domainInfo['DomainMyStatus']))
		{
			return array('flag' => 0);
		}
		$domainExtInfo = $this->domainlib->getDomainExt(array('DomainId' => $domainInfo['DomainId']));
		if(isset($domainInfo['DnsType']) && $domainInfo['DnsType'] != 0 && !($domainInfo['DnsType']==4 && (strpos($domainExtInfo['Dns'], '.ename.net') || strpos($domainExtInfo['Dns'], '.ename.cn'))))
		{
			Response::setErrMsg('800023', '非我司DNS，不能解析');
			return array('flag' => 0, 'msg' => '非我司DNS，不能解析');
		}
		return TRUE;
	}
	/**
	 *
	 * isValidRecord 记录值验证
	 * @param unknown_type $value
	 * @param unknown_type $record_type
	 * @throws Exception
	 * @return boolean
	 * boolean
	 */
	private function isValidRecord($value, $record_type)
	{
		$recordCode = $this->configs->record->type->code;
		$recordType = $this->configs->record->recordtype->toArray();;
		if(empty($value) || strlen($value) > 255)
		{
			Response::setErrMsg('800012', '记录值不能超过255');
			return array('flag' => 0, 'msg' => '记录值不能超过255');
		}
		//记录值长度不能超过200
	
		if(empty($recordType[$record_type]))
		{
			Response::setErrMsg('800013', '记录类型不存在');
			return array('flag' => 0, 'msg' => '记录类型不存在');
		}
		//没有填写记录类型
	
		$value = strtolower($value);
		if($record_type == $recordCode->A)
		{
			if(FALSE === $this->isIp($value))
			{
				Response::setErrMsg('800014', 'A记录值只能是IP');
				return array('flag' => 0, 'msg' => 'A记录值只能是IP');
			}
			//A记录只接受IP
	
		}
		else if($record_type == $recordCode->CNAME)
		{
			if(TRUE == $this->isIp($value))
			{
				Response::setErrMsg('800015', 'CNAME记录值必须是一个合法的主机名，CNAME不接受IP');
				return array('flag' => 0, 'msg' => 'CNAME记录值必须是一个合法的主机名，CNAME不接受IP');
			}
			//CNAME不接受IP
	
			if($value{strlen($value) - 1} == '.'){
				$value = substr($value, 0, strlen($value) - 1);
			}
			if(FALSE === $this->isHostName($value))
			{
				Response::setErrMsg('800016', 'CNAME记录值必须是一个合法的主机名');
				return array('flag' => 0, 'msg' => 'CNAME记录值必须是一个合法的主机名');
			}
			//CNAME必须是一个合法的主机名
		}
		else if($record_type == $recordCode->MX)
		{
			if($value{strlen($value) - 1} == '.'){
				$value = substr($value, 0, strlen($value) - 1); //清理NS最后一位
			}
			if(FALSE === $this->isIp($value) && FALSE === $this->isHostName($value))
			{
				Response::setErrMsg('800017', 'MX记录值必须是一个合法的主机名或者IP地址');
				return array('flag' => 0, 'msg' => 'MX记录值必须是一个合法的主机名或者IP地址');
			}
			//MX可以使用IP或者是一个合法的主机名
		}
		else if($record_type == $recordCode->URL || $record_type == $recordCode->URL0)
		{
			if ('http://' != substr($value,0,7) and 'https://' != substr($value,0,8))
			{
				$value	= 'http://'.$value;
			}
				
			if(FALSE === $this->isUrl($value))
			{
				Response::setErrMsg('800018', 'URL转发记录值必须是一个合法的URL地址');
				return array('flag' => 0, 'msg' => 'URL转发记录值必须是一个合法的URL地址');
			}
			//URL转发记录值必须是一个合法的URL地址
		}
		else if($record_type == $recordCode->NS)
		{
			if(TRUE == $this->isIp($value))
			{
				Response::setErrMsg('800019', 'NS记录必须是一个合法的主机名，NS不接受IP');
				return array('flag' => 0, 'msg' => 'NS记录必须是一个合法的主机名，NS不接受IP');
			}
			//NS不接受IP
	
			if($value{strlen($value) - 1} == '.'){
				$value = substr($value, 0, strlen($value) - 1); //清理NS最后一位
			}
			if(FALSE === $this->isHostName($value))
			{
				Response::setErrMsg('800020', 'NS记录必须是一个合法的主机名');
				return array('flag' => 0, 'msg' => 'NS记录必须是一个合法的主机名');
			}
			//NS必须是一个合法的主机名
	
		}
		else if($record_type == $recordCode->TXT)
		{
			if('"' == $value{0})
				$value = substr($value, 1);
	
			if('"' == $value{strlen($value) - 1})
				$value = substr($value, 0, -1);
	
			for($i = 0;$i < strlen($value);$i++)
			{
				if($value{$i} == '"' || $value{$i} == "'")
				{
					Response::setErrMsg('800021', 'TXT记录值不能存在单引号和双引号主机头非法');
					return array('flag' => 0, 'msg' => 'TXT记录值不能存在单引号和双引号');
				}
							//TXT记录值不能存在单引号和双引号
			}
		}
			else if($record_type == $recordCode->AAAA)
			{
			$pattern = '/^((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))$/';
					if(!preg_match($pattern, $value))
					{
						Response::setErrMsg('800022', 'IPV6格式');
						return array('flag' => 0, 'msg' => 'IPV6格式');
					}
						//验证IPV6
			}
			return TRUE;
	}
	
	/**
	 *
	 * isIp 验证IP是否合法
	 * @param unknown_type $value
	 * @return boolean
	 * boolean
	 */
	private function isIp($value)
	{
		if(preg_match('/^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$/', $value))
			return TRUE;
		else
			return FALSE;
	}
	/**
	 *
	 * isValidSubDomain 验证主机头是否合法
	 * @param unknown_type $sub_domain
	 * @return boolean
	 * boolean
	 */
	private function isValidSubDomain($sub_domain)
	{
		if((empty($sub_domain) && $sub_domain != 0) || strlen($sub_domain) > 100)
			return FALSE;
	
		//先转换为小写
		$sub_domain = strtolower($sub_domain);
		//空主机头
		if($sub_domain == '@')
			return TRUE;
		//泛解析
		if($sub_domain == '*')
			return TRUE;
	
		$domain_parts = explode('.', $sub_domain);
		$loop_count = 1;
	
		//主机头只能最多五级
		if(count($domain_parts) > 5)
			return false;
		
		//检查域名的每一部分
		foreach($domain_parts as $domain_part)
		{
			//如果长度少于1或者超过50，非法
			if(strlen($domain_part) < 1 || strlen($domain_part) > 40)
				return FALSE;
	
			// 如果-在开头或者结尾的位置，非法
			if(strpos($domain_part, '-') === 0 || ($domain_part{(strlen($domain_part) - 1)} === '-'))
				return FALSE;
	
			if($loop_count == 1)
				if(strlen($domain_part) == 1 && ($domain_part == '@' || $domain_part == '*'))
				continue;
	
			//判断域名是否全是英文、数字、-，_（中文域名传入以前必须要先用INDA转换）
			if(!preg_match('/^[a-z0-9\-_]{1,50}$/i', $domain_part))
				return FALSE;
	
			$char_tables = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'a', 'b', 'c', 'd', 'e', 'f', 'g',
					'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '-',
					'_');
			// 继续严格审查
			for($i = 0;$i < strlen($domain_part);$i++)
			{
			if(!in_array($domain_part{$i}, $char_tables))
				return FALSE;
			}
			$loop_count++;
	}
	return TRUE;
	}
	
	/**
	*
		 * isUrl 验证是否是url
		 * @param unknown_type $url
		 * @return boolean
		 * boolean
		 */
		 public function isUrl($url)
		 {
			if(preg_match("/^(http|https|ftp):\/\/([^']*)$/i", $url))
			return TRUE;
					else
				return FALSE;
			}
	
			/**
		 *
		 * isHostName 验证合法的主机名
		  * @param unknown_type $value
		  * @return boolean
		  * boolean
		  */
		  private function isHostName($value)
		  {
		  if(preg_match('/^(([a-zA-Z0-9-]{0,61}[a-zA-Z0-9-]\.)|([a-zA-Z0-9-]\.))*(com|edu|vip|top|wang|gov|int|mil|net|org|biz|info|name|museum|coop|aero|[a-z][a-z])$/',$value))
		  	return TRUE;
		  	else
		  		return FALSE;
	}
	
	/**
	 * 查看域名是否存在edns
	 */
	public function domainNoExist($domain,$enameId = false)
	{
		$domainInfo = $this->ednsLib->recordList($domain);
		if(!$domainInfo['status'] && isset($domainInfo['code']) && $domainInfo['code'] == '20001')
		{
			//域名不存在iidns库的域名表，执行添加域名操作，失败返回错误码
			if(!$enameId)
			{
				$enameId = $this->getDomainInfo($domain);
				$enameId = !empty($enameId['EnameId']) ? $enameId['EnameId'] : '';
			}
			if(!$enameId)
			{
				\core\Log::write('查询域名:' . $domain . '记录失败,查无用户信息', 'manage/edns');
				Response::setErrMsg('800002', '域名添加失败');
				return array('flag' => 0, 'msg' => '域名添加失败');
			}
			$clientIp = !empty($_REQUEST['ip']) ? $_REQUEST['ip'] : \common\Common::getRequestIp();
			$res = $this->ednsLib->addDomain($domain, $enameId,$clientIp);
			if($res['status'] === FALSE)
			{
				\core\Log::write('查询域名:' . $domain . '记录失败,重新添加又失败', 'manage/edns');
				Response::setErrMsg('800002', '域名添加失败');
				return array('flag' => 0, 'msg' => '域名添加失败');
			}
		}
		return TRUE;
	}
	
	/**
	 * 检测域名是否在临时模板下
	 * @param string $doamin
	 * @param int|string $templateId
	 * @return boolean
	 */
	private function checkIsTmpTpl($domain, $templateId = FALSE)
	{
		if(!$templateId)
		{
			$dnInfo = $this->getDomainInfo($domain);
			if($dnInfo)
			{
				$templateId = $dnInfo['TemplateId'];
				if($dnInfo['DomainMyStatus'] == 11 || $dnInfo['DomainMyStatus'] == 12)
				{
					Response::setErrMsg('800003', '域名开通安全锁，不能操作解析');
					return array('flag' => 0, 'msg' => '域名开通安全锁，不能操作解析');
				}
				if($dnInfo['DomainMyStatus'] == 7)
				{
					Response::setErrMsg('800004', '域名被锁定，不能操作解析');
					return array('flag' => 0, 'msg' => '域名被锁定，不能操作解析');
				}
			}
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		if(empty($templateId) || $conf->template->temp->id == $templateId || in_array($templateId, explode(',', $conf->template->temp->historyid)))
		{
			Response::setErrMsg('800005', '使用临时模板，无法进行解析操作，请先添加实名模板');
			return array('flag' => 0, 'msg' =>'使用临时模板，无法进行解析操作，请先添加实名模板');
		}
		if(\lib\manage\common\DomainFunLib::isChinaDomain($domain) && $templateId)
		{
			if(\lib\manage\common\DomainFunLib::checkIsWhiteTemp($templateId) == FALSE)
			{
				Response::setErrMsg('800006','使用非实名模板，不能操作解析');
				return array('flag' => 0, 'msg' =>'使用非实名模板，不能操作解析');
			}
		}
		return TRUE;
	}

	/**
	 * 获取申请中的url转发审核数量
	 */
	public function getAuditingNum($info)
	{
		$_REQUEST['tmpadmin'] = 1;
		$clientIp = empty($info->ip) ?'' : $info->ip;
		$recordInfo = $this->ednsLib->auditList('where', 0, null, null, 1, 0,'','',$clientIp);
		$rs['count'] = isset($recordInfo['data']['total']) ? $recordInfo['data']['total'] : 0;
		$rs['name'] = 'URL转发审核';
		$config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'adminmanage');
		$baseUrl = $config->url;
		$rs['url'] = $baseUrl . 'urlrecord/index';
		return $rs;
	}
	

	/**
	 * 域名批量添加解析逻辑
	 */
	public function batchDnsLogic($info)
	{
		$operatelogic = new \logic\manage\member\OperateLogic();
		if(!$operatelogic->checkOperate($info))
		{
			Response::setErrMsg('200038','操作保护验证失败');
			return array('flag'=>0,'errorMsg'=>'操作保护验证失败');
		}
		$reData= $this->getBatchDnsData($info);
		$tempArray = explode(",",trim($reData['batchDomain']));
		$tempArray = array_unique($tempArray);
		$tempArray = array_filter($tempArray);
		$domainArr = array();
		foreach($tempArray as $k=>$v)
		{
			$domainArr[$k] = trim($v);
		}
		$data= array();
		$enameId=  $info->EnameId;
		if(count($reData['host']) * count($tempArray) > 300)
		{
			throw new \Exception('一次最多允许添加300条解析记录',800024);
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$taskName = $conf->batch_dns_task_name->add;
		$totalNum= 0;
		foreach ($domainArr as $v)
		{
			$domainInfo = $this->getDomainInfo($v, $info->EnameId);
			$st = $this->ifAllowDns($domainInfo);
			if($st === TRUE)
			{
				foreach($reData['host'] as $k => $vv)
				{
					$mxPriority= isset($reData['mxPriority'][$k]) ? $reData['mxPriority'][$k] : 10;
					$extra= ($reData['recordType'][$k] == 3) ? $mxPriority : '';
					$ttl= isset($reData['ttl'][$k]) ? $reData['ttl'][$k] : '' ;
					$data[$v][]= array('sub_domain'=> $vv,'enameId'=>$enameId,'record_line'=> $reData['lineType'][$k], 'record_type'=>$reData['recordType'][$k],
							'ttl'=>$ttl, 'value'=> $reData['iphost'][$k], 'extra'=> $extra,'clientIp'=>\common\Common::getRequestIp()) ;
				}
			}
			else 
			{
				continue;
			}
			$totalNum += count($reData['host']);
		}
		if(empty($data))
		{
			throw new \Exception('获取域名信息失败!',800025);
		}
		$records = array_values($data);
		$epp = new \lib\manage\domain\DomainEppLib($enameId);
		$vaildData = array('domains' => $domainArr, 'records' => $records[0]);
		$errorMsg = $epp->vaildBatchDnsData(1, $vaildData);
		if($errorMsg != '')
		{
			return array('flag'=>0,'batchDomain' => $reData['batchDomain'], 'errorMsg' => $errorMsg);
		}
		$data = $epp->addTaskAndTaskInfo($data, $taskName, $totalNum, $enameId,1);
		$errorMsg = $epp->addRecords($data,$domainArr,$enameId);
		if($errorMsg == '')
		{
			return array('flag'=>1,'msg'=>'操作成功!您的请求已加入队列等待执行!');
		}
		return array('flag'=>0,'batchDomain' => $reData['batchDomain'], 'errorMsg' => $errorMsg);
	}

	/**
	 * 域名批量添加解析逻辑
	 */
	public function batchDnsCheck($info)
	{
		$reData= $this->getBatchDnsData($info);
		$tempArray = explode(",",trim($reData['batchDomain']));
		$tempArray = array_unique($tempArray);
		$tempArray = array_filter($tempArray);
		$domainArr = array();
		foreach($tempArray as $k=>$v)
		{
			$domainArr[$k] = trim($v);
		}
		$data= array();
		$returndata = array();
		$enameId=  $info->EnameId;
		if(isset($reData['host']) && count($reData['host']) * count($tempArray) > 300)
		{
			throw new \Exception('一次最多允许添加300条解析记录',800024);
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$taskName = $conf->batch_dns_task_name->add;
		$totalNum= 0;
		foreach ($domainArr as $v)
		{
			$domainInfo = $this->getDomainInfo($v, $info->EnameId);
			$st = $this->ifAllowDns($domainInfo);
			if( $st === TRUE)
			{
				$returndata[] =array('domain'=>$v,'enameid'=>$enameId,'msg'=>$v .'该域名正常','status'=>1);
			}
			else
			{
				$returndata[] =array('domain'=>$v,'enameid'=>$enameId,'msg'=>$v .$st,'status'=>0);
			}
		}
		if(empty($returndata))
		{
			throw new \Exception('获取域名信息失败!',800025);
		}
		$returndata = self::arrayOrder($returndata);
		return array('flag'=>1,'data'=>$returndata);
	}
	/**
	 * 
	 */
	private function ifAllowDns($domainInfo)
	{
		if(!$domainInfo)
		{
			\core\Log::write('添加域名解析失败,域名:'.$domainInfo['DomainName'] .'enameID:' . $domainInfo['EnameId'].'域名不属于操作者','domain','batch_dns_error_domain');
			return '域名不属于操作者';
		}
		if($domainInfo['DnsType'] != 0  && !($domainInfo['DnsType']==4 && (strpos($domainExtInfo['Dns'], '.ename.net') || strpos($domainExtInfo['Dns'], '.ename.cn'))))
		{
			\core\Log::write('添加域名解析失败,域名:'.$domainInfo['DomainName'] .'enameID:' . $domainInfo['EnameId'].'域名非我司DNS，不能解析','domain','batch_dns_error_domain');
			return '域名非我司DNS，不能解析';
		}
		if($domainInfo['DomainMyStatus'] == 7)
		{
			\core\Log::write('添加域名解析失败,域名:'.$domainInfo['DomainName'] .'enameID:' . $domainInfo['EnameId'] .'域名被锁定，无法执行操作','domain','batch_dns_error_domain');
			return '域名被锁定，无法执行操作';
		}
		$secureres = \lib\manage\common\DomainFunLib::checkSecureStatus($domainInfo['DomainMyStatus']);
		if(!$secureres)
		{
			\core\Log::write('添加域名解析失败,域名:'.$domainInfo['DomainName'] .'enameID:' . $domainInfo['EnameId'] .'设置了安全锁，不能操作','domain','batch_dns_error_domain');
			return '设置了安全锁，不能操作';
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		if(empty($domainInfo['TemplateId']) || $conf->template->temp->id == $domainInfo['TemplateId'] || in_array($domainInfo['TemplateId'], explode(',', $conf->template->temp->historyid)))
		{
			\core\Log::write('添加域名解析失败,域名:'.$domainInfo['DomainName'] .'enameID:' . $domainInfo['EnameId'] .'域名的模板为临时模板，不能操作解析','domain','batch_dns_error_domain');
			return $domainInfo['DomainName'].'使用临时模板，无法进行解析操作，请先添加实名模板';
		}
		if(\lib\manage\common\DomainFunLib::isChinaDomain($domainInfo['DomainName']) && $domainInfo['TemplateId'])
		{
			if(\lib\manage\common\DomainFunLib::checkIsWhiteTemp($domainInfo['TemplateId']) == FALSE)
			{
				\core\Log::write('添加域名解析失败,域名:'.$domainInfo['DomainName'] .'enameID:' . $domainInfo['EnameId'] .'域名模板非白名单状态，不能操作解析','domain','batch_dns_error_domain');
				return $domainInfo['DomainName'].'使用非实名模板，不能操作解析';
			}
		}
		return TRUE;
	}
	//批量返回域名信息排序
	private function arrayOrder($array)
	{
		if(!is_array($array))
		{
			return $array;
		}
		$arrayNew = array();
		foreach ($array as $k => $v)
		{
			if(!$v['status'])
			{
				$arrayNew[] = $array[$k];
				unset($array[$k]);
			}
		}
		return array_merge_recursive($arrayNew,$array);
	}
	/**
	 * 格式化错误信息
	 * example:$data=> array("domain"=> array("fanzw.corm"=> "域名非法" ),
	 *  "record"=> array('1'=> array("record_type"=> "请选择记录类型" ))));
	 * @param array $errorMsg
	 */
	public function formatErrorMsg($errorMsg)
	{
		$domainMsg= '';
		$recordMsg= '';
		foreach ($errorMsg as $k => $v)
		{
			if($k == 'domain')
			{
				foreach($v as $domain => $domainErrorMsg)
				{
					$domainMsg.= $domain.$domainErrorMsg.'域名格式错误<br />';
				}
			}
			else if($k == 'record')
			{
				foreach($v as $recordId => $record)
				{
					foreach($record as $recordErrorMsg)
					{
						$recordMsg.= '第'.($recordId + 1).'条记录'.$recordErrorMsg.'<br />';
					}
				}
			}
		}
		return $domainMsg.$recordMsg;
	}
	/**
	 * 得到批量解析信息
	 * @param array $info
	 */
	public function getBatchDnsData($info)
	{
		$data = array();
		$data['batchDomain'] = !empty($info->batchDomain) ? $info->batchDomain : FALSE;
		$host = !empty($info->host) ? $info->host : FALSE;
		$recordType = !empty($info->recordType) ? $info->recordType : FALSE;
		$iphost = !empty($info->iphost) ? $info->iphost : FALSE;
		$lineType = !empty($info->lineType) ? $info->lineType : FALSE;
		$mxPriority = !empty($info->mxPriority) ? $info->mxPriority : '';
		$ttl = !empty($info->ttl) ? $info->ttl : FALSE;
		if($host)
		{
			$data['host'] =  explode(",",trim($host));
		}
		if($recordType)
		{
			$data['recordType'] =  explode(",",trim($recordType));
		}
		if($iphost)
		{
			$data['iphost'] =  explode(",",trim($iphost));
		}
		if($lineType)
		{
			$data['lineType'] =  explode(",",trim($lineType));
		}
		if($ttl)
		{
			$data['ttl'] =  explode(",",trim($ttl));
		}
		if($mxPriority)
		{
			$data['mxPriority'] =  explode(",",trim($mxPriority));
		}
		return $data;	
	}
}

<?php
namespace logic\manage\domain;
use core\form\ReturnData;
use core\Response;

class SecureWarningLogic
{
	private $redis;
	private $time;

	function __construct()
	{
		$this->redis = \core\RedisLib::getInstance('common');
		$config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'securewarning');
		$this->time = $config->securewarning;
	}

	/**
	 * 搜索push双方IP相同的域名，判断是否满足触发条件
	 */
	public function checkPush()
	{
		$memberLib = new \lib\manage\member\MemberLib();
		$pushMod = new \models\manage\domain\DomainPushMod();
		$param['ReceiveTime'] = date('Y-m-d H:i:s', time() - (int)$this->time->push);
		$param['limit'] = 5;
		$rs = $pushMod->checkPush($param);//条件一.push的发起方和接收方ip地址一致 
		if (!$rs) 
		{
			\core\Log::write('安全警报--查询push表无数据','securewarning','sw');
			exit();
		}
		foreach ($rs as $value) 
		{
			$opKey = 'weekSecureWarningOP' . $value['SendId'];
			$loginKey = 'weekSecureWarningLogin' . $value['SendId'];
			$opError = $this->redis->get($opKey);
			$loginError = $this->redis->get($loginKey);
			if ($opError || $loginError) //条件二.用户的账号一周内有出现过“24小时内登录密码错误三次”或“24小时内操作保护答案错误三次”的情况
			{
				$params = array();
				$params['enameid'] = $value['SendId'];
				$params['BusinessType'] = 1; //域名push
				$domain = explode("\n", $value['DomainName']);
				$goodDomainType = 0; // 条件三.判断是否是优质域名 0=>非优质域名 1 =>1-4数com cn net 2=>1-3字母com cn net。。。。
				foreach($domain as $v)
				{
					$goodDomainType = \lib\manage\common\DomainFunLib::getDomainType($v);
					if($goodDomainType)
					{
						break;
					}
				}
				// 条件四：push没有经过短信验证 0元push看发起方 带价看双方
				$pushPrice = sprintf("%.2f", $value['PushPrice']);
				$isSendSms = ($pushPrice == '0.00') ? $this->checkSendMsg($value['SendId'], $value['CreateTime'], 1) : $this->checkSendMsg(
					$value['SendId'], $value['CreateTime'], 1) &&
					 $this->checkSendMsg($value['ReceiveId'], $value['ReceiveTime'], 2);
				if($isSendSms) //有短信验证则不加入警报
				{
					continue;
				}
				$num = count($domain);
				$params['domain'] = $num > 1 ? $domain[0].'等' . $num . '个域名' : '域名'.$domain[0];
				if($goodDomainType) // 满足条件三
				{
					$userMemberInfo = new \logic\manage\member\UserMemberLogic();
					$linkEnameId = $userMemberInfo->getLinkEnameId($value['SendId']);
					if(in_array($value['ReceiveId'], 
						array_merge($linkEnameId['sysLinkEnameId'], $linkEnameId['operLinkEnameId']))) // $value['SendId'] 和$value['ReceiveId'] 是否关联
					{
						$params['Status'] = 3; // 警报已处理
						$params['Remark'] = "关联id间push";
					}
					else
					{
						$params['Status'] = 1; // 警报待处理
					}
				}
				else
				{
					$result = $this->pushSecureWarnSms($value['SendId'], $value['ReceiveId'], $pushPrice, 
						$params['domain'], $value['CreateTime'], $value['ReceiveTime']);
					if($result['flag'] == false)
					{
						$params['Status'] = 1; // 待处理
						$params['Remark'] = $result['msg'];
						// 系统设置警报处理方式
					}
					else
					{
						$params['Status'] = 3; // 警报已处理
						$params['Remark'] = $result['msg'];
						// 系统设置警报处理方式
						$params['DealWay']='2';//短信提醒
					}
				}
				$params['Handle'] = 21; // 处理人
				$params['UpdateDate'] = time();
				$params['Content'] = ($opError && $loginError) ? 'push双方IP一样，并且一周内有出现过“24小时内操作保护答案错误三次” 与 “24小时内登录密码错误三次”' : ($opError ? 'push双方IP一样，并且一周内有出现过“24小时内操作保护答案错误三次”' : 'push双方IP一样，并且一周内有出现过“24小时内登录密码错误三次”');
				$params['IP'] = $value['Ip'];
				$params['Priority'] = 5;
				$params['CreateDate'] = strtotime($value['ReceiveTime']);
				$this->addSecureWarning($params);
			}
		}
	}

	/**
	 * 检测是否存在域名大量转出的情况(一次申请10个以上或用户帐号下域名不足10个时，转出超过总量80%)
	 */
	public function checkTransferOut()
	{
		$transferOutMod = new \models\manage\domain\DomainTransferOutMod();
		$data['CreateTime'] = date('Y-m-d H:i:s', time() - (int)$this->time->transferout);
		$rs = $transferOutMod->getTransferInfoByTime($data);
		if (!$rs) 
		{
			\core\Log::write('安全警报--查询转出表无数据','securewarning','sw');
			exit();
		}
		$domainsMod = new \models\manage\domain\DomainsMod();
		foreach ($rs as $v) 
		{
			$flag = FALSE;
			$domains = $domainsMod->getDomainCount(array('EnameId' => $v['EnameId']));
			if($domains['sum'] < 20 && $v['sum'] > 10) 
			{
				$flag = TRUE;
			}
			if($domains['sum'] > 20 && $v['sum'] > 0.8 * $domains['sum']) 
			{
				$flag = TRUE;
			}
			if ($flag) 
			{
				$params = array();
				$params['enameid'] = $v['EnameId'];
				$params['BusinessType'] = 2; //域名转出
				$params['domain'] = $v['DomainName'] . '等' . $v['sum'] . '个域名';
				$params['Content'] = '大量转出';
				$params['Priority'] = 1;
				$params['IP'] = $v['CreateIp'];
				$params['CreateDate'] = strtotime($v['CreateTime']);
				$this->addSecureWarning($params);
			}
		}
	}

	public function checkTransferOutAdd()
	{
		$transferOutMod = new \models\manage\domain\DomainTransferOutMod();
		$data['CreateTime'] = date('Y-m-d H:i:s', time() - 3600 * 72);
		$rs = $transferOutMod->getTransferInfoByTime($data);
		if (!$rs) 
		{
			\core\Log::write('安全警报--查询转出表无数据','securewarning','sw');
			exit();
		}
		$secureWarningMod = new \models\manage\member\SecureWarningMod();
		$memberDateExtMod = new \models\manage\member\MemberDatextMod();
		$memberLogLoginMod = new \models\manage\member\MemberLogLoginMod();
		foreach($rs as $domain) 
		{
			$flag = FALSE;
			$enameId = $domain['EnameId'];
			//域名获取转移密码3天内，账户有出现修改绑定手机或新添加绑定手机、ip和修改绑定手机或新增绑定手机之前最后一次登录ip不同
			$memberDateExt = $memberDateExtMod->getInfo(array('EnameId' => $enameId, 'Type' => 9, 'Date>' => $domain['CreateTime'], 'order' => 'Id DESC'), 'Ip,Date', TRUE);
			if($memberDateExt) 
			{
				$ip = $memberDateExt['Ip'];
				$loginInfo = $memberLogLoginMod->getInfo(array('EnameId' => $enameId, 'LoginTime<' => strtotime($memberDateExt['Date']), 'order' => 'Id DESC'), 'Ip', TRUE);
				if($ip != $loginInfo['Ip']) 
				{
					$flag = 2;
				}
			}
			//域名获取转移密码3天内，账户有出现找回密码操作、ip和有操作找回密码之前的最后一次登录ip不同 
			$logArray = array('platform' => 1, 'msgType' => 210006, 'logType' => 1, 'enameId' => $enameId, 'beginAddTime' => strtotime($domain['CreateTime']), 'order' => 'id DESC', 'limit' => 1, 'columns' => 'ip,addTime');
			$findPasswordLog = \common\Logsystem::getLog($logArray);
			if($findPasswordLog['flag'] && $findPasswordLog['data']) 
			{
				$data = $findPasswordLog['data'][0];
				$ip = $data['ip'];
				$loginInfo = $memberLogLoginMod->getInfo(array('EnameId' => $enameId, 'LoginTime<' => $data['addTime'], 'order' => 'Id DESC'), 'Ip', TRUE);
				if($ip != $loginInfo['Ip']) 
				{
					$flag = 3;
				}
			}

			if($flag) 
			{
				$transferoutWarning = $secureWarningMod->getWarningList(array('EnameId' => $enameId, 'BusinessType' => 2, 'Status' => 1, 'createbegin' => date('Y-m-d H:i:s', time() - 72 * 3600)), 'Id');
				if(!$transferoutWarning) 
				{
					$params = array();
					$params['enameid'] = $enameId;
					$params['BusinessType'] = 2; //域名转出
					$params['domain'] = $domain['DomainName'];
					$params['Content'] = $flag == 1 ? '转出 -- 域名获取转移密码3天内，账户有出现操作保护出错3次以上、ip和有操作保护出错3次之前登陆的最后一次登录ip不同' : ($flag == 2 ? '转出 -- 域名获取转移密码3天内，账户有出现修改绑定手机或新添加绑定手机、ip和修改绑定手机或新增绑定手机之前最后一次登录ip不同' : '转出 -- 域名获取转移密码3天内，账户有出现找回密码操作、ip和有操作找回密码之前的最后一次登录ip不同');
					$params['Priority'] = 1;
					$params['IP'] = $domain['CreateIp'];
					$params['CreateDate'] = strtotime($domain['CreateTime']);
					$this->addSecureWarning($params);
				}
			}
		}
	}

	/**
	 * 搜索日志表e_domain_log，取出注册失败的域名
	 */
	public function checkRegDomain()
	{
		$domainLogsMod = new \models\manage\domain\DomainLogsMod();
		$data['isSuccess'] = 0;
		$data['LogType'] = 1;		//1=>注册,2=>转入,3=>续费
		$data['CreateTime'] = date('Y-m-d H:i:s', time() - (int)$this->time->regdomain);
		$rs = $domainLogsMod->getDomainLog($data);
		if (!$rs) 
		{
			\core\Log::write('安全警报--查询注册失败日志无数据','securewarning','sw');
			exit();
		}
		$secureWarningMod = new \models\manage\member\SecureWarningMod();
		foreach ($rs as $v) 
		{
			$isExistDomain = $secureWarningMod->getWarningList(array('Domain' => $v['Domain'], 'BusinessType' => 3, 'Status' => 1));
			if ($isExistDomain) 
			{
				continue;
			}
			$reData = json_decode($v['ReturnData'], true);
			$sendData = json_decode($v['SendData'], true);
			//过滤eppCode=2302,resultMsg='Object exists'的情况
			if (isset($reData['data']['msg']['eppCode']) && $reData['data']['msg']['eppCode'] == 2302) 
			{
				continue;
			}
			//过滤底层失败但是没有注册成功的域名 resultCode=1014, resultMsg = EPPconn IO error: Socket connect fail
			//域名5025存在且不在库中的，再警报，其他都不警报
			//2015.10.21新增针对.me出现提示失败，实际却注册成功的警报
			if ((isset($reData['data']['msg']['resultCode']) && $reData['data']['msg']['resultCode'] == 1014) || (isset($reData['data']['epp']) && $reData['data']['epp'] == 61 && !empty($reData['data']['msg']) && stripos($reData['data']['msg'],'Proxy Error')!==FALSE)) 
			{
				$registrarId = $sendData['registrarID']; 
				include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
				$sdk = new \ApiSdk();
				$rs = $sdk->execSdkFun(5025, array('domain' => $v['Domain'], 'registrarID' => $registrarId));
				if ($rs['resultCode'] == 5000)
				{
					$domainsMod = new \models\manage\domain\DomainsMod();
					$domainInfo = $domainsMod->getDomainInfo(array('DomainName' => $v['Domain']));
					if ($domainInfo) 
					{
						continue;
					}
				}
				else
				{
					continue;
				}
				$params = array();
				$params['enameid'] = $v['OperatorId'];
				$params['BusinessType'] = 3;	//结算失败(注册失败)
				$params['domain'] = $v['Domain'];
				$params['Content'] = '注册失败！' . $this->formatReturnData($reData);
				$params['IP'] = $v['OperatorIp'];
				$params['Priority'] = 4;
				$params['CreateDate'] = strtotime($v['CreateTime']);
				$this->addSecureWarning($params);
			}
		}
	}

	/**
	 * 取出续费失败的域名
	 */
	public function checkRenewDomain()
	{
		$domainLogsMod = new \models\manage\domain\DomainLogsMod();
		$dnManageLib = new \lib\manage\domain\DomainManageLib();
		$data['isSuccess'] = 0;
		$data['LogType'] = 3;		//1=>注册,2=>转入,3=>续费
		$data['CreateTime'] = date('Y-m-d H:i:s', time() - (int)$this->time->renewdomain);
		$rs = $domainLogsMod->getDomainLog($data);
		if (!$rs) 
		{
			\core\Log::write('安全警报--查询续费失败日志无数据','securewarning','sw');
			exit();
		}
		$secureWarningMod = new \models\manage\member\SecureWarningMod();
		foreach ($rs as $v) 
		{
			$isExistDomain = $secureWarningMod->getWarningList(array('Domain' => $v['Domain'], 'BusinessType' => 3, 'Status' => 1));
			//2015-11-05添加下有续费成功的日志 跳过不添加警报数据
			$isSuccess = $domainLogsMod->getDomainLog(array('isSuccess'=>1,'LogType'=>3,'CreateTime'=>$v['CreateTime'],'Domain'=>$v['Domain']),"count(1) as total");
			if($isExistDomain||!empty($isSuccess[0]['total']))
			{
				//20160803 OA60398 如果待处理的警报中有用户自己重试操作续费成功的，系统自动设置为已处理
				if ($isExistDomain && !empty($isSuccess[0]['total']))
				{
					$updateData['Id'] = $isExistDomain[0]['Id'];
					$updateData['Remark'] = '用户自行重试续费成功';
					$updateData['Status'] = 3; 
					$updateData['Handle'] = 21;
					$secureWarningMod->updateInfo($updateData);
				}
				continue;
			}
			$reData = json_decode($v['ReturnData'], true);
			if (is_array($reData))
			{
				$contentTemp=$this->formatReturnData($reData);
			}
			else 
			{
				$contentTemp=trim(substr($str,stripos($reData,'string=') + 7), ')}');
			}
			// 正在转移、正在转出、年限达到最大值 不加入警报记录
			iF(stripos($contentTemp, 'Parameter value policy error') !== FALSE ||
				 stripos($contentTemp, 'been renewed') !== FALSE || stripos($contentTemp, 'prohibits operation') !==
				 FALSE)
			{
				continue;
			}
			$params = array();
			$params['enameid'] = $v['OperatorId'];
			$params['BusinessType'] = 3;	//结算失败(注册失败)
			$params['domain'] = $v['Domain'];
			$params['Content'] = '续费失败！' .$contentTemp;
			$params['IP'] = $v['OperatorIp'];
			$params['Priority'] = 4;
			$params['CreateDate'] = strtotime($v['CreateTime']);
			$this->addSecureWarning($params);
		}
	}

	/**
	 * 转入后交易,改进
	 */
	public function transAfterTransferin()
	{
		$config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'securewarning');
		//白名单enameId
		$whiteEnameId = $config->transaftertransferin->whiteEnameId;
		$enameIdArr = explode(',', $whiteEnameId);
		$successTime =  date('Y-m-d H:i:s', time() - 24 * 3600);
		$transferInMod = new \models\manage\domain\DomainTransferInMod();
		$transferInDomains = $transferInMod->getTransferInfo(array('TransferStatus' => 8, 'SuccessTime>' => $successTime),'EnameId,DomainName,Whois,SuccessTime',false);
		if (!$transferInDomains)
		{
			\core\Log::write('安全警报--查询转入域名无数据','securewarning','sw');
			exit();
		}
		$secureWarningMod = new \models\manage\member\SecureWarningMod();
		$domainPushMod = new \models\manage\domain\DomainPushMod();
		$interfaces = new \interfaces\manage\Domains();
		//获取时间点以上的所有push记录，先解决表instr慢查询
		$pushDatas = $domainPushMod->pushListForSecwarning($successTime,'DomainName,PushId,Ip,CreateTime');
		foreach ($transferInDomains as $domain)
		{
			if (in_array($domain['EnameId'], $enameIdArr))
			{
				continue;
			}
			if($this->checkUserVerifyMobile($domain['EnameId']))
			{
				continue;
			}
			$isExistDomain = $secureWarningMod->getWarningList(array('Domain' => $domain['DomainName'], 'BusinessType' => 8, 'createbegin' => $successTime), 'Id', TRUE);
			if ($isExistDomain)
			{
				continue;
			}
			else if ($isExistDomain === FALSE)
			{
				\core\log::write('转入后交易添加记录时查询域名失败！' . json_encode($domain), 'securewarning', 'trans_');
			}
			$flag = FALSE;
			//判断是否有push操作
			if ($pushDatas)
			{
				$pushHas = FALSE;
				foreach($pushDatas as $push)
				{
					if(stripos($push['DomainName'], $domain['DomainName']) !== FALSE)
					{
						$pushDetails = $domainPushMod->pushDetail(array('Domain' => $domain['DomainName'], 'PushId' => $push['PushId']),'Id');
						if($pushDetails)
						{
							$pushHas = TRUE;
							break;
						}
					}
				}
				if($pushHas)
				{
					$flag = 1;
					$ip = $push['Ip'];
					$createDate = $push['CreateTime'];
				}
			}
			//判断是否有交易记录，调用交易平台接口
			$trans = false;//$interfaces->isExistTrans(array('domain' => $domain['DomainName'], 'starttime' => $domain['SuccessTime'], 'endtime' => date('Y-m-d H:i:s')));
			if (!empty($trans['info']))
			{
				$flag = $flag ? 3 : 2;
				$ip = $trans['info']['SellerIp'];
				$createDate = $trans['info']['CreateDate'];
			}
			if (FALSE != $flag)
			{
				$params = array();
				if ($domain['Whois'])
				{
					$params['Ext'] = $this->getRegistrarByWhois($domain['Whois']);
					//2015-01-16 godaddy域名不做警报处理
					if (strpos(strtolower($params['Ext']), 'godaddy') !== FALSE)
					{
						continue;
					}
				}
				$params['enameid'] = $domain['EnameId'];
				$params['BusinessType'] = 8;
				$params['domain'] = $domain['DomainName'];
				$params['Content'] = (3 == $flag) ? '域名转入成功后有push和交易记录' : (1 == $flag ? '域名转入成功后立即push' : '域名转入成功后立即发布交易');
				$params['IP'] = $ip;
				$params['Priority'] = 5;
				$params['CreateDate'] = strtotime($createDate);
				$this->addSecureWarning($params);
			}
		}
	}

	/**
	 * gd域名重复转入
	 */
	public function godaddyRepeatTransferin()
	{
		$transferInMod = new \models\manage\domain\DomainTransferInMod();
		$transferInDomains = $transferInMod->getTransferInfo(array('TransferStatus' => 8, 'SuccessTime>' => date('Y-m-d H:i:s', time() - (int)$this->time->gdrepeattransferin)), '*', FALSE);
		if(!$transferInDomains) 
		{
			\core\Log::write('gd域名重复转入--查询转入域名无数据', 'securewarning', 'sw');
			exit();
		}
		$transferOutMod = new \models\manage\domain\DomainTransferOutMod();
		$dnLib = new \lib\manage\domain\DomainManageLib();
		$domainsMod = new \models\manage\domain\DomainsMod();
		foreach($transferInDomains as $domain) 
		{
			$transferIn = $transferInMod->getTransferInfo(
				array('DomainName' => $domain['DomainName'], 'in' => array('TransferStatus' => array(9, 10, 11)),
					'SuccessTime>' => date('Y-m-d H:i:s', strtotime($domain['SuccessTime']) - 365 * 24 * 3600 ),
					'SuccessTime<' => $domain['SuccessTime']), '*', true);
			if(!$transferIn || !$transferIn['Whois'])
			{
				continue;
			}
			$registrar = $this->getRegistrarByWhois($transferIn['Whois']);
			$params = array();
			$params['enameid'] = $domain['EnameId'];
			$params['BusinessType'] = 9;
			$params['domain'] = $domain['DomainName'];
			$params['Content'] = $this->getRegistrarByWhois($domain['Whois']);
			$params['IP'] = $domain['SubmitIp'];
			$params['Priority'] = 5;
			$params['CreateDate'] = strtotime($domain['CreateTime']);
			$this->addSecureWarning($params);
			$domainInfo = $dnLib->getDomainInfo(array('DomainName'=>$domain['DomainName']));
			if($domainInfo)
			{
				if($domainInfo['DomainMyStatus'] ==14)
				{
					continue;
				}
				$setDomain = $domainsMod->upDomainInfo(array('DomainName' => $domain['DomainName']), array('DomainMyStatus' => 14));
				if(!$setDomain)
				{
					\core\Log::write('gd域名重复转入--设置域名' . $domain['DomainName'] . '交易锁定状态失败！');
					continue;
				}
				$serviceContent = $domainInfo['DomainMyStatus'] !=1 ? 'gd重复转入(状态非正常)' : 'gd重复转入';
				\lib\manage\domain\DomainLogsLib::addDomainServiceExt($domain['DomainName'], $serviceContent, 2);
			}
			else
			{
				\core\Log::write('gd域名重复转入--设置域名' . $domain['DomainName'] . '交易锁定状态失败,域名不在库中');
			}
		}
	}

	/**
	 * 增加警报记录
	 */
	private function addSecureWarning($params)
	{
		$secureWarningMod = new \models\manage\member\SecureWarningMod();
		$rs = $secureWarningMod->addInfo($params);
		if (!$rs) 
		{
			\core\Log::write('安全警报---添加数据失败' . json_encode($params), 'securewarning', 'sw');
		}
	}

	/**
	 * 通过whois信息获取注册商
	 * 
	 * @param  string $whois 
	 * @return string $registrar
	 */
	private function getRegistrarByWhois($whois)
	{
		if(preg_match_all("/Registr[ar]*[\s]*[Name]*:[\s]*(.*?)[\r\t\n\f]+/i", $whois, $regs))
		{
			if(isset($regs['1']['1']))
			{
				$registrar = $regs['1']['1'];
			}
			else
			{
				$registrar = $regs['1']['0'];
			}
			return $registrar;
		}
		return false;
	}

	/**
	 * 注册与续费格式化提醒内容
	 */
	private function formatReturnData($data)
	{
		$contentArray = array();
		if (!isset($data['data'])) 
		{
			if (!isset($data['resultMsg'])) 
			{
				foreach ($data as $key => $value) 
				{
					$contentArray[] = $key . ':' . $value;
				}
				$content = implode(',', $contentArray);
			}
			else
			{
				$content = 'resultMsg:' . $data['resultMsg'];
			}
		}
		else
		{
			if (!is_array($data['data']['msg'])) 
			{
				$content = 'msg:' . $data['data']['msg'];
			}
			else
			{
				foreach ($data['data']['msg'] as $key => $value) 
				{
					$contentArray[] = $key . ':' . $value;
				}
				$content = implode(',', $contentArray);
			}
		}
		return $content;
	}
	
	/**
	 * 检查用户是否通过手机绑定和身份认证
	 */
	private function checkUserVerifyMobile($enameId)
	{
		$lib = new \lib\manage\member\MemberLib();
		$userInfo = $lib->getMemberInfoByEnameId($enameId);
		if(empty($userInfo['IsMobileVerified']) || empty($userInfo['IsIdentityVerified']))
		{
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * PUSH 警报短信发送
	 * @param string $sendId PUSH 发起者ENAMEID
	 * @param string $receiveId PUSH 接收者ENAMEID
	 * @param string $pushPrice PUSH 价格
	 * @param string $domain PUSH 的域名
	 * @param string $domain PUSH 的发起时间
	 * @param string $domain PUSH 的接收时间
	 * @return 发送失败 false 发送成功 短信备注说明
	 */
	private function pushSecureWarnSms($sendId, $receiveId, $pushPrice, $domain, $createTime, 
		$receiveTime)
	{
		$queueInterface = new \interfaces\manage\Queue();
		$memberExtMod = new \models\manage\member\EmemberMod();
		$sendMemberInfo = $memberExtMod->getMemberExtInfo($sendId);
		if(!$sendMemberInfo)
		{
			\core\Log::write('安全警报--' . $sendId . '用户不存在,短信发送失败', 'securewarning', 'sw');
			return array('msg' => $sendId . '用户不存在,短信发送失败','flag'=>false);
		}
		$sendLinkPhone = $sendMemberInfo['Mobile'] ? $sendMemberInfo['Mobile'] : false;
		if (!$sendLinkPhone)
		{
			\core\Log::write('安全警报--' . $sendId . '没有手机号码,短信发送失败', 'securewarning', 'sw');
			return array('msg' => $sendId . '没有手机号码,短信发送失败','flag'=>false);
		}
		if($pushPrice == '0.00')
		{
			$sendSmsResult = $queueInterface->sendSms('domain_push_send_warning', $sendLinkPhone, array('enameId' => $sendId, 'time' => $createTime , 'domain' => $domain, 'money' => 0), $sendId, 0, 'send_sms', 3); // 给push发起方发送短信提醒
			$returnMsg = "已发送短信至发起方" . $sendId . "绑定手机" . $sendLinkPhone . "提醒";
		}
		else
		{
			$receiveIdMemberInfo = $memberExtMod->getMemberExtInfo($receiveId);
			if(!$receiveIdMemberInfo)
			{
				\core\Log::write('安全警报--' . $receiveId . '用户不存在,短信发送失败', 'securewarning', 'sw');
				return array('msg' => $receiveId . '用户不存在,短信发送失败','flag'=>false);
			}
			$receiveLinkPhone = $receiveIdMemberInfo['Mobile'] ? $receiveIdMemberInfo['Mobile'] : false;
			if (!$receiveLinkPhone)
			{
				\core\Log::write('安全警报--' . $receiveId . '没有手机号码,短信发送失败', 'securewarning', 'sw');
				return array('msg' => $receiveId . '没有手机号码,短信发送失败','flag'=>false);
			}
			// 给push发起方发送短信提醒 push接收方短信提醒
			$pushSendSmsResult = $queueInterface->sendSms('domain_push_send_warning', $sendLinkPhone, array('enameId' => $sendId, 'time' => $createTime , 'domain' => $domain, 'money' => $pushPrice), $sendId, 0, 'send_sms', 3);
			$pushReceiveSmsResult = $queueInterface->sendSms('domain_push_receive_warning', $receiveLinkPhone, array('enameId' => $receiveId, 'time' => $receiveTime , 'domain' => $domain, 'money' => $pushPrice), $receiveId, 0, 'send_sms', 3); 
			$returnMsg = "已发送短信至发起方" . $sendId . "绑定手机" . $sendLinkPhone . "和接收方" . $receiveId . "绑定手机" . $receiveLinkPhone . "提醒";
			$sendSmsResult = $pushSendSmsResult && $pushReceiveSmsResult;
		}
		return $sendSmsResult == false ? array('msg' => '系统出错,短信发送失败', 'flag' => false) : array('msg' => $returnMsg, 
			'flag' => true);
	}

	/**
	 * 检查用户push是否有发短信验证
	 *
	 * @param string $enameId
	 * @param string $time 短信验证时间
	 * @param int $type 1发送push短信验证 非1接收push短信验证
	 * @return 有 true 无 false
	 */
	private function checkSendMsg($enameId, $time, $type)
	{
		$userCaptaMod = new \models\manage\member\UserCaptaMod();
		// 读取$enameId离$time最早的一条短信验证码使用记录【发送push Purpose D201 CaptchaType 2、接收push Purpose D203】验证码使用时间和短信验证时间相差<90，看其有无设置PUSH短信验证
		if($type == 1)
		{
			$purpose = 'D201';
		}
		else
		{
			$purpose = 'D203';
		}
		$userCaptaInfo = $userCaptaMod->getLastCaptchaInfo(
			array('EnameId' => $enameId, 'UsedTime' => $time, 'Purpose' => $purpose, 'Status' => '1'));
		if($userCaptaInfo)
		{
			if((strtotime($time) - strtotime($userCaptaInfo['UsedTime'])) < 90) //需满足验证码使用时间和短信验证时间相差<接收PUSH程序执行完时间 默认程序90执行完可适当加长
			{
				return true;
			}
		}
		return false;
	}
}
<?php 
namespace logic\manage\domain;
use \core\Response;
use \lib\manage\common\DomainFunLib;
use \lib\manage\common\DomainOpenLib;
use \lib\manage\domain\DomainLogsLib;
use core;

class SellPageLogic
{

	private $domainManageLib;

	private $domainEppLib;

	private $ednsLogic;
 
	public function __construct($enameId = 0)
	{
		$this->domainManageLib = new \lib\manage\domain\DomainManageLib();
		$this->domainEppLib = new \lib\manage\domain\DomainEppLib();
		$this->ednsLogic = new \logic\manage\domain\EdnsLogic();
	}

	/**
	 * 设置展示页
	 *
	 * @param object $info 表单
	 */
	public function setSellPage($domains, $enameId)
	{
		if(empty($enameId))
		{
			throw new \Exception('nameId有误', 360000);
		}
		$domains = explode(',', $domains);
		if(empty($domains))
		{
			throw new \Exception('至少需要一个域名', 360001);
		}
		return $result = self::batchSetSellPage($domains, $enameId);
	}

	/**
	 * 批量设置展示页
	 *
	 * @param array $domains
	 * @param int $enameId
	 */
	private function batchSetSellPage($domains, $enameId)
	{
		$data = array();
		
		foreach($domains as $domain)
		{
			try
			{
				$status = self::doSetSellPage($domain, $enameId);
				$result = array('code' => 100000, 'domain' => $domain, 'msg' => '设置展示页成功', 'domainStatus' => $status,'enameid'=>$enameId);
			}
			catch(\Exception $e)
			{
				$code = $e->getCode();
				$result = array('code' => $code, 'domain' => $domain, 'msg' => $e->getMessage(),'enameid'=>$enameId);
			}
			$data[] = $result;
			DomainLogsLib::addDomainService($domain, $result, 38, $enameId);
		}
		return $data;
	}

	/**
	 * 展示页设置
	 *
	 * @param string $domain
	 * @param int $enameId
	 */
	private function doSetSellPage($domain, $enameId)
	{
		// 判断是否合法域名
		if(false === DomainFunLib::isOkDomain($domain))
		{
			throw new \Exception('不是正确的域名', 360013);
		}
		// 检查接口开放信息
		DomainOpenLib::checkOpen('sellpage', $domain, true);
		// 判断域名是否存在并属于用户
		if(!$domainInfo = $this->domainManageLib->getDomainInfo(array('DomainName' => $domain, 'EnameId' => $enameId)))
		{
			throw new \Exception('该域名' . $domain . '不属于' . $enameId, 360014);
		}
		// 检测域名是否安全锁定状态
		if(!DomainFunLib::checkSecureStatus($domainInfo['DomainMyStatus']))
		{
			throw new \Exception(\core\Response::$errMsg, \core\Response::$errCode);
		}
		// 记录操作日志
		DomainLogsLib::addDomainService($domain, array('memo' => 'open_sell_page', 'uid' => $enameId), 38, $enameId);
		// 是否已经开启展示页
		if($domainInfo['DomainHoldStatus'] == 3 || $domainInfo['DomainHoldStatus'] == 5)
		{
			throw new \Exception('域名已经是展示页,请勿重复提交!', 360015);
		}
		// 检测域名是否可以设置展示页
		DomainFunLib::checkDomainToSellPage($domainInfo);
		self::checkCnDomainVerifcation($domainInfo);
		
		$dnStatus = 0;
		// iidns 添加
		if(DomainFunLib::isChinaDomain($domain))
		{
			$dnStatus = self::getDomainStatus($domain, $domainInfo['RegistrarId']);
			if(in_array($dnStatus, array(1, 2)) || $domainInfo['DomainHoldStatus'] == 1)
			{
				DomainLogsLib::addDomainService($domain, '域名注册局状态:' . $dnStatus, 38, $enameId);
				throw new \Exception('域名无法添加展示页，请联系客服处理!', 360016);
			}
		}
		self::addDnSpageAndIidns($domain, $domainInfo, $enameId, 5);
		return $dnStatus;
	}

	/**
	 * 域名注册局状态 0：正常 1： clienthold 2: serverhold
	 *
	 * @param string $domain
	 * @param int $registrarId
	 * @return number
	 */
	private function getDomainStatus($domain, $registrarId)
	{
		$domainStatus = 0;
		$domainRegInfo = $this->domainEppLib->getDomainRegInfo($domain, $registrarId);
		if(stripos($domainRegInfo['status'], 'hold') !== false)
		{
			$domainStatus = (stripos($domainRegInfo['status'], 'server') !== false) ? 2 : 1;
		}
		return $domainStatus;
	}

	/**
	 * 检测新注册8天之内的CN域名是否在审核期
	 *
	 * @param array $domainInfo
	 * @throws Webpie_Handler_Exception
	 */
	private function checkCnDomainVerifcation($domainInfo)
	{
		$domain = $domainInfo['DomainName'];
		if((time() - strtotime($domainInfo['RegDate']) < 691200) && DomainFunLib::isChinaDomain($domain))
		{
			$domainRegInfo = $this->domainEppLib->getDomainRegInfo($domain, $domainInfo['RegistrarId']);
			if(stripos($domainRegInfo['status'], 'pendingverification') !== false)
			{
				throw new \Exception('对不起，您的域名' . $domain . '在注册审核期内，无法开通展示页', 360017);
			}
		}
		if(FALSE == \lib\manage\common\DomainFunLib::checkisRealDomainRenew($domainInfo['DomainName'], $domainInfo['IsRealName'], $domainInfo['RegDate']))
		{ 
			throw new \Exception('对不起，您的域名' . $domain . '未通过域名实名，无法开通展示页', 360017);
		}
	}

	/**
	 * 设置域名为展示页状态并更改域名的DNS为IIDNS
	 *
	 * @param string $domain
	 * @param array $domainInfo
	 * @param int $enameId
	 * @param string $domainStatus 3、5
	 * @param string $holdStatus 只有holdStatus==1 代表clienthold时需要修改dns为iidns
	 * @return boolean
	 */
	private function addDnSpageAndIidns($domain, $domainInfo, $enameId, $domainStatus)
	{
		if($domainInfo['DomainHoldStatus'] != $domainStatus)
		{
			$where = array('DomainId' => $domainInfo['DomainId'], 'EnameId' => $enameId, 'DomainName' => $domain);
			$set = array('DomainHoldStatus' => $domainStatus);
			if(!$result = $this->domainManageLib->setDomainStatus($where, $set, $domain . '设置展示页状态'))
			{
				throw new \Exception('系统错误，设置展示页状态失败' ,360018);
			}
		}
		DomainLogsLib::addDomainOperaterLog($domain, $enameId, '设置域名为展示页', 7, 0, '');
		DomainLogsLib::addDomainService($domain, '设置域名为展示页', 38, $enameId);
		return true;
	}

	/**
	 * 展示页解析记录设置
	 *
	 * @param string $domain
	 * @param int $enameId
	 * @param string $ip
	 * @throws \Exception
	 * @return {data:{"status":"","msg":"","code":""}}
	 */
	public function domainCustompage($domain, $enameId, $ip = '')
	{
		// 设置iidns解析
		$params = array('domain' => $domain, 'enameId' => $enameId, 'ip' => $ip);
		$result = $this->ednsLogic->domainCustompage((object) $params);
		if(empty($result['flag']))
		{
			// 设置失败
			throw new \Exception(\core\Response::$errMsg, \core\Response::$errCode);
		}
		return $result['msg'];
	}

	/**
	 * 单个域名关闭展示页
	 *
	 * @param string $domain
	 * @param int $enameId
	 * @param boolean $closeFlag
	 * @return boolean
	 */
	public function closeSellPage($domain, $enameId, $closeFlag = FALSE)
	{
		$rs = $this->batchCloseSellPage($domain, $enameId, $closeFlag);
		if(is_array($rs) && $rs[0])
		{
			if(100000 == $rs[0]['code'])
			{
				return TRUE;
			}
			Response::setErrMsg($rs[0]['code'], $rs[0]['msg']);
		}
		return FALSE;
	}

	/**
	 * 批量关闭展示页
	 *
	 * @param string $domains 多个域名请以英文逗号隔开
	 * @param int $enameId
	 * @param boolean $closeFlag
	 * @return boolean
	 */
	private function batchCloseSellPage($domains, $enameId, $closeFlag = FALSE)
	{
		if(!$enameId)
		{
			Response::setErrMsg(360000, "enameId有误");
			return FALSE;
		}
		$domains = explode(',', $domains);
		if(empty($domains))
		{
			Response::setErrMsg(360001, "至少需要一个域名");
			return FALSE;
		}
		$data = array();
		foreach($domains as $domain)
		{
			$result = array();
			$rs = $this->doCloseSellPage($domain, $enameId, $closeFlag);
			if(FALSE !== $rs)
			{
				$result = array('code' => 100000, 'domain' => $domain, 'msg' => '关闭展示页成功','enameid'=>$enameId);
			}
			else
			{
				$result = array('code' => Response::getErrCode(), 'domain' => $domain, 'msg' => Response::getErrMsg(),'enameid'=>$enameId);
			}
			$result['f'] = $closeFlag ? 1 : 0;
			$data[] = $result;
			DomainLogsLib::addDomainService($domain, $result, 37, $enameId);
		}
		return $data;
	}

	/**
	 * 执行关闭展示页
	 *
	 * @param string $domain
	 * @param int $enameId
	 * @param boolean $closeFlag
	 * @return boolean
	 */
	private function doCloseSellPage($domain, $enameId, $closeFlag = FALSE)
	{
		// 域名格式及功能开关检测
		if(FALSE == DomainFunLib::checkIsOkDomain($domain))
		{
			Response::setErrMsg(360002, "域名格式有误");
			return FALSE;
		}
		if(!DomainOpenLib::checkOpen('sellpage', $domain))
		{
			return FALSE;
		}
		// 获取域名信息
		$dnManageLib = new \lib\manage\domain\DomainManageLib();
		$domainInfo = $dnManageLib->getDomainInfo(array('DomainName' => $domain));
		if(!$domainInfo || !is_array($domainInfo))
		{
			Response::setErrMsg(360004, "域名格式有误");
			return FALSE;
		}
		if($domainInfo['EnameId'] != $enameId)
		{
			Response::setErrMsg(360014, '该域名' . $domain . '不属于' . $enameId);
			return FALSE;
		}
		// 检测域名是否安全锁定状态
		if(!DomainFunLib::checkSecureStatus($domainInfo['DomainMyStatus']))
		{
			return FALSE;
		}
		DomainLogsLib::addDomainService($domain, array('memo' => 'close_sell_page', 'uid' => $enameId), 37, $enameId);
		// 检测域名是否已开通展示页
		if(!DomainFunLib::checkDomainIsSellPageStatus($domainInfo['DomainHoldStatus']))
		{
			Response::setErrMsg(360003, "域名没有开通展示页");
			return FALSE;
		}
		// 取消域名展示页状态，如果为hold展示页则同步到注册局更新为正常状态
		$setArray = array();
		if($domainInfo['DomainHoldStatus'] == 5)
		{
			$setArray = array('DomainHoldStatus' => 0);
		}
		elseif($domainInfo['DomainHoldStatus'] == 3)
		{
			$setArray = array('DomainHoldStatus' => 0, "DomainStatus" => '3,4');
			$dnEppLib = new \lib\manage\domain\DomainEppLib();
			if(FALSE == $dnEppLib->setDomainRegisterStatus($domain, $domainInfo['RegistrarId'], array(3, 4)))
			{
				return FALSE;
			}
		}
		// 更新本库域名状态
		if(!$dnManageLib->setDomainInfo(array('DomainName' => $domain, 'EnameId' => $enameId), $setArray))
		{
			DomainLogsLib::addDomainService($domain, '关闭展示页更新数据库失败', 37, $enameId);
		}
		DomainLogsLib::addDomainService($domain, array('memo' => 'end_close_page_success', 'uid' => $enameId), 37, 
			$enameId);
		return TRUE;
	}

	/**
	 * 获取域名信息(域名库)
	 * 
	 * @param object $info 表单对象
	 * @throws \Exception
	 */
	public function checkDomain($domainName, $enameId, $showEnameId = false)
	{
		// 域名判断,是否合法
		if(empty($domainName) || !DomainFunLib::isOkDomain($domainName))
		{
			throw new \Exception('域名错误', 3590000);
		}
		$params = array('DomainName' => $domainName);
		if(!$result = $this->domainManageLib->getDomainInfo($params))
		{
			throw new \Exception('域名查询失败', 3590004);
		}
		$isOwner = FALSE;
		if(!empty($enameId))
		{
			if($result['EnameId'] == $enameId)
			{
				$isOwner = TRUE;
			}
		}
		return array("isOwner" => $isOwner);
	}
}

<?php
namespace logic\manage\domain;
use core\Response;
use core\ModBase;
use \lib\manage\domain\DomainManageLib;
use \lib\manage\domain\DomainLogsLib;
use logic\manage\queue\SmsLogic;
use core;
use lib\manage\common\DomainFunLib;

/**
 * 域名过期提醒新方案
 * 1.按过期提醒具体对应天数获取用户过期域名数，并只取前五个域名来封装信息。
 */
class DomainExpTipLogic
{
	private $dnMod;
	
	private $smsLogic;
	
	private $queueLogic;
	
	private $whoisLogic;
	
	private $dnLogLib;
	
	private $memberLib;
	
	private $userSettingLib;
	
	private $dnLimit = 3000;
	
	public function __construct()
	{
		$this->dnMod = new ModBase('domain');
		$this->memberLib = new \lib\manage\member\MemberLib();
		$this->userSettingLib = new \lib\manage\member\UserSettingLib();
		$this->dnLogLib = new \lib\manage\domain\DomainLogsLib();
		$this->queueLogic = new \logic\manage\newqueue\QueueLogic();
		$this->smsLogic = new \logic\manage\queue\SmsLogic();
		$this->whoisLogic = new \logic\manage\whois\WhoisLogic();
	}
	
	/**
	 * domain mod采用自身特殊mod--短信
	 */
	public function dnExpTipByEnameId($enameId)
	{
		set_time_limit(0);
		\core\Log::write($enameId . ",start domain", 'cronmanage/domainnotice','domain_exp_bak_enameid');
		$bcheckTime = date('Y-m-d',strtotime('-1days')).' 16:00:00';
		$echeckTime = date('Y-m-d',strtotime('+30days')).' 15:59:59';
		$query = "select count(*) from e_domains where EnameId=".$enameId." and ExpDate<='".$echeckTime."'";
		$dnCount = $this->dnMod->getOne($query, '', array());
		if(empty($dnCount))
		{
			\core\Log::write($enameId . ",没有30天内过期的域名", 'cronmanage/domainnotice','enameid_info_error');
			return true;
		}
		$userInfo = $this->memberLib->getMemberInfoByEnameId($enameId);
		if(empty($userInfo))
		{
			\core\Log::write($enameId . ",获取用户信息失败", 'cronmanage/domainnotice','enameid_info_error');
			return false;
		}
		$query = "select count(*) from e_domains where EnameId=".$enameId." and ExpDate<='".$echeckTime."' and ExpDate>='".$bcheckTime."'";
		$dnExpCount = $this->dnMod->getOne($query, '', array());
		if($this->checkIsSendTime())//当天的或者超过20天的就发送
		{
			$this->sendExpMobile($dnCount - $dnExpCount, $dnExpCount, $enameId, $userInfo);
		}
		$msgResult = $this->dnExpTipMsg($enameId);
		$mailResult = $this->dnExpTipMail($enameId, $userInfo['Email']);
		return array('msg' => $msgResult, 'mail' => $mailResult);
	}
	
	/**
	 * 域名过期提醒--站内信
	 */
	public function dnExpTipMsg($enameId)
	{
		$sendMsgDomainTimeArr = array('30', '17', '7', '-3', '-13', '-23');
		$sendData = array();
		foreach ($sendMsgDomainTimeArr as $day)
		{
			$bcheckTime = date('Y-m-d',strtotime(($day-1).'days')).' 16:00:00';
			$echeckTime = date('Y-m-d',strtotime($day.'days')).' 15:59:59';
			$query = "select count(*) from e_domains where EnameId=".$enameId." and ExpDate<='".$echeckTime."' and ExpDate>='".$bcheckTime."'";
			$dnExpCount = $this->dnMod->getOne($query, '', array());
			if(empty($dnExpCount))
			{
				continue;
			}
			$query = "select DomainName,ExpDate from e_domains where EnameId=".$enameId." and ExpDate<='".$echeckTime."' and ExpDate>='".$bcheckTime."' limit 6";
			$dnExpList = $this->dnMod->select($query, '', array());
			if(empty($dnExpList))
			{
				continue;
			}
			\core\Log::write($enameId . ",get domain total:" . $dnExpCount, 'cronmanage/domainnotice','domain_exp_bak_enameid_msg');
			foreach ($dnExpList as $v)
			{
				$sendData[$day][] = $v['DomainName'];
				\core\Log::write($v['DomainName'] . ',' . $day, 'cronmanage/domainnotice','domain_exp_bak_domain_msg');
			}
			if(!empty($sendData[$day]))
			{
				$sendData[$day]['total'] = $dnExpCount;
			}
		}
		if(empty($sendData))
		{
			return FALSE;
		}
		else
		{
			$this->sendExpMsg($this->formatDomainExpList($sendData, $enameId), $enameId);
		}
		return true;
	}
	
	/**
	 * 域名过期提醒--邮件
	 */
	public function dnExpTipMail($enameId, $userEmail)
	{
		$sendMsgDomainTimeArr = array('30', '17', '7', '-3', '-13', '-23');
		$sendData = array();
		foreach ($sendMsgDomainTimeArr as $day)
		{
			$bcheckTime = date('Y-m-d',strtotime(($day-1).'days')).' 16:00:00';
			$echeckTime = date('Y-m-d',strtotime($day.'days')).' 15:59:59';
			$query = "select count(*) as Num,if(PrivacyTemp > 0,PrivacyTemp,TemplateId) as TempId from e_domains where EnameId=".$enameId." and ExpDate<='".$echeckTime."' and ExpDate>='".$bcheckTime."' group by TempId";
			$dnExpInfo = $this->dnMod->select($query, '', array());
			if(empty($dnExpInfo))
			{
				continue;
			}
			$tempData = array();
			//根据用户模板整理，若多个模板的邮箱指向同一个，则取域名详情的时候用其中一个模板去取。
			foreach ($dnExpInfo as $tempV)
			{
				//获取域名的邮箱(直接查模板)
				$query = "select Email,TemplateId from e_template_zh where TemplateId=".$tempV['TempId'];
				$tempInfo = $this->dnMod->getRow($query, '', array());
				$emailTemp = empty($tempInfo['Email']) || empty($tempInfo['TemplateId']) || \lib\manage\common\DomainFunLib::checkIsTempTemplate($tempInfo['TemplateId']) ? $userEmail : $tempInfo['Email'];//未取到模板邮箱或者为临时模板，则发送提醒到ID邮箱
				$emailTemp = trim($emailTemp);
				if(empty($emailTemp) || !DomainFunLib::isEmail($emailTemp))
				{
					continue;//获取不到邮箱的提醒跳过
				}
				if(isset($tempData[$emailTemp]))
				{
					$tempData[$emailTemp]['total'] += $tempV['Num'];
				}
				else
				{
					$tempData[$emailTemp]['total'] = $tempV['Num'];
				}
				$tempData[$emailTemp]['templateId'][] = $tempV['TempId'];
			}
			//获取域名详情
			foreach ($tempData as $email => $info)
			{
				$query = "select DomainName from e_domains where EnameId=".$enameId." and ExpDate<='".$echeckTime."' and ExpDate>='".$bcheckTime."' and (TemplateId in(".implode(',', $info['templateId']).") or PrivacyTemp in(".implode(',', $info['templateId']).")) limit 6";
				$dnExpList = $this->dnMod->select($query, '', array());
				\core\Log::write($enameId . ",get domain total:" . $info['total'].",templateId:".implode(',', $info['templateId']), 'cronmanage/domainnotice','domain_exp_bak_enameid_email');
				foreach ($dnExpList as $v)
				{
					$tempData[$email]['detail'][] = $v['DomainName'];
					\core\Log::write($v['DomainName'] . ',' . $day, 'cronmanage/domainnotice','domain_exp_bak_domain_email');
				}
				unset($tempData[$email]['templateId']);//后期用不上了，先unset掉。
			}
			$sendData[$day] = $tempData;
		}
		if(empty($sendData))
		{
			return false;
		}
		$sendData = $this->changeEmailData($sendData);
		$this->sendExpMail($sendData, $enameId);
		return true;
	}
	
	/**
	 * 根据邮箱整理要发送的数据(邮件)
	 */
	private function changeEmailData($sendData)
	{
		$returnData = array();
		foreach ($sendData as $time => $sendInfo)
		{
			foreach ($sendInfo as $email => $expInfo)
			{
				$returnData[$email][$time] = $expInfo;
			}
		}
		return $returnData;
	}
	
	/**
	 * 根据不同的过期时间，整理域名列表(站内信)
	 */
	private function formatDomainExpList($domainList, $enameId)
	{
		$formatDomainExpString = '';
		$formatDomainExpEdString = '';
		foreach($domainList as $key => $value)
		{
			$count = $domainList[$key]['total'];
			if(is_array($value))
			{
				if(isset($value['total']))
				{
					unset($value['total']);
				}
				if($key < 0)
				{
					$formatDomainExpEdString .= $this->formatDomainExpListMsg($value, $key, $count);
				}
				else
				{
					$formatDomainExpString .= $this->formatDomainExpListMsg($value, $key, $count);
				}
			}
		}
		return array($formatDomainExpString, $formatDomainExpEdString);
	}
	
	/**
	 * 格式化发送信息的内容
	 */
	private function formatDomainExpListMsg($domainExpList, $time, $number)
	{
		$dayLater = $time < 0 ? $time : '+ ' . $time;
		$expDate = date("Y-m-d", strtotime($dayLater . ' days'));
		$url = 'http://www.ename.net/manage/domainlist?op=search&endExtTime=' . $expDate . '&startExtTime=' . $expDate;
		$diff = $time < 0 ? abs($time) : $time;
		$msg = $time < 0 ? '已经过期' . $diff . '天[' . $expDate . ']的域名，共' . $number . '个<br />' : '还有' . $diff . '天[' . $expDate . ']就到期的域名，共' . $number . '个<br />';
		$count = 1;
		foreach($domainExpList as $v)
		{
			if($count > 5)
			{
				$msg .= '<a href=' . $url . ' target=_blank>......还有更多，请点击查看</a><br />';
				return $msg;
			}
			$msg .= $v . '&nbsp;&nbsp;&nbsp;&nbsp;<a target=_blank href=http://www.ename.net/manage/renew/' . $v . '>[马上续费]</a><br/>';
			$count++;
		}
		return $msg;
	}
	
	/**
	 * 域名到期 短信提醒 发送时间大于等于20天的时候才再一次发送
	 * @param int $maxId
	 * @return boolean
	 */
	public function checkIsSendTime()
	{
		try 
		{
			$redis = core\RedisLib::getInstance('manage');
		}
		catch (\Exception $e)
		{
			//redis异常的时候默认发送
			return true;
		}
		$redisKey = 'manage_dn_exp_mobile_tip';
		$tipDay = $redis->get($redisKey);
		if(!empty($tipDay))//查到记录判断是否符合发送点
		{
			if($tipDay == date('Y-m-d'))//当天的发送
			{
				return true;
			}
			if(strtotime(date('Y-m-d')) - strtotime($tipDay) >= 1727990)//超过差不多20天的发送
			{
				$upResult = $redis->set($redisKey, date('Y-m-d'));
				$this->dnLogLib->addDomainService('upTipTime', array($info['Content'], $upResult, date('Y-m-d')), 51);
				return true;
			}
			//不符合的不发送
			return false;
		}
		else
		{
			$addResult = $redis->set($redisKey, date('Y-m-d'));
			$this->dnLogLib->addDomainService('addTipTime', array($addResult, date('Y-m-d')), 51);
		}
		return true;
	}
	
	/**
	 * 发送手机短信通知域名过期情况
	 */
	public function sendExpMobile($sendMobileExpEd, $sendMobileExp, $enameId, $userInfo)
	{
		$templateId = 'domainNewExpMobile';
		if(!empty($userInfo['IsMobileVerified']))
		{
			$mobileSetting = $this->getDomainExpUserMobileSetting($enameId);
			$this->dnLogLib->addDomainService($enameId, array('mobileSetting' => $mobileSetting, 'sendMobileCount' => $sendMobileExpEd.','.$sendMobileExp), 53);
			if($mobileSetting && !empty($userInfo['Mobile']))
			{
				if($sendMobileExp || $sendMobileExpEd)
				{
					$smsData = array('Function' => 'send_sms', 'EnameId' => $enameId, 'TemplateName' => $templateId, 'Target' => $userInfo['Mobile'], 'Data' => array('ChName' => $enameId, 'Count' => $sendMobileExp, 'expCount' => $sendMobileExpEd), 'Priority' => 1);
					$st = $this->queueLogic->addQueueNormal($smsData);
					$this->getQueueStauts($st, array('EnameId' => $enameId, 'Type' => 'Mobile', 'Count' => $sendMobileExp, 'expCount' => $sendMobileExpEd));
				}
			}
		}
	}
	
	/**
	 * 发送站内信通知域名过期情况
	 */
	public function sendExpMsg($domain, $enameId)
	{
		$domainExp = $domain[0];
		if($domainExp)
		{
			$this->smsLogic->sendSiteMsg($enameId, 'domainNewExpMsg', array('domain' => $domainExp, 'EnameId' => $enameId), 3);
		}
		$domainExpEd = $domain[1];
		if($domainExpEd)
		{
			$this->smsLogic->sendSiteMsg($enameId, 'domainExpEdMsg', array('domain' => $domainExpEd, 'EnameId' => $enameId), 3);
		}
	}
	
	/**
	 * 发送邮件通知域名过期情况
	 */
	public function sendExpMail($sendMail, $enameId)
	{
		foreach ($sendMail as $email => $sendInfo)
		{
			$domainStr = $domainStrEd = '';
			foreach ($sendInfo as $time => $expInfo)
			{
				if($time > 0)
				{
					$domainStr .= $this->formatDomainExpListMsg($expInfo['detail'], $time, $expInfo['total']);
				}
				else 
				{
					$domainStrEd .= $this->formatDomainExpListMsg($expInfo['detail'], $time, $expInfo['total']);
				}
			}
			if($domainStr)
			{
				$mailData = array('Function' => 'sendmail', 'EnameId' => $enameId, 'TemplateName' => 'domainNewExpMail', 'Target' => $email, 'Data' => array('DomainList' => $domainStr), 'Priority' => 1);
				$st = $this->queueLogic->addQueueNormal($mailData);
				$this->getQueueStauts($st, array('DomainList' => $domainStr, 'Type' => 'Email', 'Email' => $email));
			}
			if($domainStrEd)
			{
				$mailData = array('Function' => 'sendmail', 'EnameId' => $enameId, 'TemplateName' => 'domainExpEdMail', 'Target' => $email, 'Data' => array('DomainList' => $domainStrEd), 'Priority' => 1);
				$st = $this->queueLogic->addQueueNormal($mailData);
				$this->getQueueStauts($st, array('DomainList' => $domainStrEd, 'Type' => 'Email', 'Email' => $email));
			}
		}
	}
	
	/**
	 * 获取用户到期提醒的手机短信设置
	 */
	public function getDomainExpUserMobileSetting($enameId)
	{
		if(empty($enameId))
		{
			return false;
		}
		$adminSetting = $this->userSettingLib->getAdminSettingByIdentifier('D202');
		$memberSetting = $this->userSettingLib->getMemberInfoByIdentifier('D202', $enameId);
		if($memberSetting)//用户有设置过
		{
			$info = $memberSetting;
		}
		else
		{
			$this->addMemberSetting($enameId);//当用户没有设置域名到期提醒方式的时候默认设置为短信提醒(绑定手机情况下)
			$info = $adminSetting;
		}
		if($info)
		{
			return $info['IsMobile'] ? true : false;
		}
		return false;
	}
	
	/**
	 * 当用户域名到期提醒 用户没有设置提醒方式的时候添加一条记录（短信提醒）
	 */
	public function addMemberSetting($enameId)
	{
		$info = array();
		$info['Identifier'] = 'D202';
		$info['EnameId'] = $enameId;
		$info['IsProtect'] = 0;
		$info['IsMobile'] = 1;
		$info['IsMessage'] = 0;
		$info['IsEmail'] = 0;
		$info['IsPhone'] = 0;
		$info['IsCenter'] = 0;
		$result = $this->userSettingLib->addMemberSetting($info);//添加记录
		if(!$result)
		{
			$this->dnLogLib->addDomainService($enameId, '域名到期短信提醒设置失败', 53);
			return false;
		}
		$result = $this->memberLib->addMemberDateExt($enameId, 18, '提醒验证配置添加:D202 IsMobile 1(域名到期提醒)', '管理员');
		if(!$result)
		{
			$this->dnLogLib->addDomainService($enameId, '新增用户时间扩展表失败', 53);
		}
	}
	
	/**
	 * 记住下信息添加到队列是否成功
	 */
	public function getQueueStauts($status, $content)
	{
		if(!$status)
		{
			$this->dnLogLib->addDomainService('queue_get_status', $content, 51);
		}
	}
}
<?php
namespace logic\manage\domain;

use core\form\ReturnData;
use core\Response;
use \lib\manage\domain\DomainManageLib;
use \lib\manage\domain\DomainLogsLib;
use \lib\manage\common\DomainFunLib;
use lib\manage\common\DomainOpenLib;
use \lib\manage\newqueue\QueueTaskLib;
class DomainManageLogic
{

	private $dnManageLib; 

	private $enameId; 

	private $templateMod;
    
	private $taskLogic;
  
	public function __construct($enameId = '')
	{
		$this->dnManageLib = new \lib\manage\domain\DomainManageLib(); 
		$this->templateMod = new \models\manage\domain\TemplateMod();
		$this->taskLogic = new \logic\manage\queue\TaskLogic();
		$this->enameId = $enameId; 
	}

	/**
	 * 获取域名相关信息 
	 */
	public function admin($data)
	{
		$domainInfo = $this->dnManageLib->getDomainInfo(
			array('DomainName' => $data->domain, 'EnameId' => $data->enameId));
		if(!$domainInfo)
		{
			throw new \Exception("查找域名信息失败", 359003);
		}
		$EdnsFlag = 1;
		$tempLib = new \lib\manage\domain\TemplateLib();
		$tempInfo = $tempLib->getTempInfo($domainInfo['TemplateId']);
		$owner = !empty($tempInfo['Org']) ? $tempInfo['Org'] : '';
		$contact = !empty($tempInfo['Name']) ? $tempInfo['Name'] : '';
		$tempName = !empty($tempInfo['TemplateUserName']) ? $tempInfo['TemplateUserName'] : '';
		$dnsType = $domainInfo['DnsType'];
		$dns = '';
		if($dnsType == 0)
		{
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'iidns');
			$dns = $conf->iidns->toArray();
			$dns = $dns[0];
			$EdnsFlag = 0;
		}
		else 
			if($dnsType == 3 || $dnsType == 4)
			{
				$domainext = $this->dnManageLib->getDomainExt(array('DomainId' => $domainInfo['DomainId']));
				if(!empty($domainext['Dns']))
				{
					if(is_array($domainext['Dns']))
					{
						$dns = $domainext['Dns'][0];
					}
					else
					{
						$dns = explode(",", $domainext['Dns']);
						$dns = $dns[0];
					}
				}
				if($dnsType == 4 && (strpos($domainext['Dns'], '.ename.net') || strpos($domainext['Dns'], '.ename.cn')))
			{
				$EdnsFlag = 0;
			}
		}
		$tempstatus = 1;//实名模板
		if(DomainFunLib::checkIsTempTemplate($domainInfo['TemplateId']))
		{
			$tempstatus = 2;//临时模板
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'vspdomainltd');
		$shimingDomainLtd = $conf->domainltd->toArray();
		if((DomainFunLib::isChinaDomain($data->domain)||in_array(\lib\manage\common\DomainFunLib::getDomainClass($data->domain), $shimingDomainLtd))&& !DomainFunLib::checkIsWhiteTemp($domainInfo['TemplateId']))
		{
			$tempstatus = 3;//非实名模板
		}
		$expDate = $domainInfo['ExpDate'] ? date("Y-m-d", strtotime($domainInfo['ExpDate']) + 8 * 3600) : '';
		$expDate = strtotime($expDate);
		if($expDate < time())
		{
			$domainInfo['DomainMyStatus'] = -2;
		}
		$isLock = $this->checkDomainIsLock(array($data->domain));
		$domainMyStatus = ($domainInfo['DomainMyStatus'] == 9 || $domainInfo['DomainMyStatus'] == 14) ? 1 : $domainInfo['DomainMyStatus'];
		return array('domain' => DomainFunLib::showDomainToEnameShow($data->domain), 'islock'=>$isLock[$data->domain],
			'domainMyStatus' => $domainMyStatus, 'dns' => $dns, 'RegDate' => $domainInfo['RegDate'], 
			'ExpDate' => $domainInfo['ExpDate'], 'owner' => $owner, 'contact' => $contact, 
			'tempUserName' => $domainInfo['TempUserName'], 'autoRenew' => $domainInfo['AutoRenew'], 
			'tempstatus' => $tempstatus, 'EdnsFlag' => $EdnsFlag);
	}

	/**
	 * 获取域名自动续费设置
	 */
	public function autoRenew($data)
	{
		$domainInfo = $this->dnManageLib->getDomainInfo(
			array('DomainName' => $data->domain, 'EnameId' => $data->enameId));
		return array('autoRenew' => $domainInfo['AutoRenew']);
	}

	/**
	 * 发送到期域名自动续费数目提醒
	 */
	public function sendAutoRenewNotice()
	{
		$domainMod = new \models\manage\domain\DomainsMod();
		$data['AutoRenew'] = 1;
		$data['in']['DomainProperty'] = array(1, 2, 3, 8); // 过滤 4：腾讯邮箱 5:五元域名
		$data['ExpDate>'] = gmdate("Y-m-d", time()) . ' 00:00:00';
		$data['ExpDate<'] = gmdate("Y-m-d", time()) . ' 23:59:59';
		$data['in']['DomainLtd'] = array(1, 2, 6, 21, 22, 23, 24, 26); // cn域名
		$data['ClassName'] = 3; // 中文cn域名
		$countInfo = $domainMod->getDomainCount($data);
		$chiCnCount = $countInfo ? $countInfo['sum'] : 0;
		$data['ClassName'] = 1; // 英文cn域名
		$countInfo = $domainMod->getDomainCount($data);
		$engCnCount = $countInfo ? $countInfo['sum'] : 0;
		unset($data['ClassName']);
		$data['in']['DomainLtd'] = array(3, 4, 9, 10); // com net域名
		$countInfo = $domainMod->getDomainCount($data);
		$comandnetCount = $countInfo ? $countInfo['sum'] : 0;
		$emailMessage = '';
		$time = date('Y-m-d', time());
		if($chiCnCount >= 500)
		{
			$emailMessage .= $time . " 中文cn域名到期自动续费量将达到" . $chiCnCount . "个，请您注意cn接口余额是否足够！<br>";
		}
		if($engCnCount >= 1500)
		{
			$emailMessage .= $time . " 英文cn域名到期自动续费量将达到" . $engCnCount . "个，请您注意cn接口余额是否足够！<br>";
		}
		if($comandnetCount >= 3000)
		{
			$emailMessage .= $time . " com、net域名到期自动续费量将达到" . $comandnetCount . "个，请您注意verisign接口余额是否足够！";
		}
		if($emailMessage)
		{
			$queueLogic = new \logic\manage\newqueue\QueueLogic();
			$mailData = array('Function' => 'sendmail', 'EnameId' => 10000, 'TemplateName' => 'any_template_info', 'Target' => 'cw@ename.com', 'Data' => array('title' => '域名到期续费大额数目邮件提醒', 'content' => $emailMessage), 'Priority' => 5);
			$result = $queueLogic->addQueueNormal($mailData);
			return $result ? array('send' => TRUE, 'flag' => TRUE, 'data' => $emailMessage) : array('send' => TRUE, 
				'flag' => FALSE, 'data' => $emailMessage);
		}
		return array('send' => FALSE);
	}

	/**
	 * 更新域名自动续费设置
	 */
	public function autoRenewSet($data)
	{
		$domainInfo = $this->dnManageLib->getDomainInfo(array('DomainName' => $data->domain), "RegistrarId,RegDate,DomainMyStatus,DomainLtd,DomainName,IsRealName,EnameId,TemplateId", true);
		if(!$domainInfo)
		{
			throw new \Exception('修改续费设置失败', 359004);
		}
		if($data->autoRenew)
		{
			if($domainInfo['RegistrarId'] == 11)
			{
				throw new \Exception('该域名暂时不能操作。', 359007);
			}
			// 正在转出的域名不让设置自动续费
			if($domainInfo['DomainMyStatus'] == 5)
			{
				throw new \Exception('该域名正在转出，无法设置自动续费', 359009);
			}
			if(61 == $domainInfo['RegistrarId'] && in_array($domainInfo['DomainLtd'], array(3, 4, 11, 16, 17)))
			{
				throw new \Exception('该域名暂不支持设置自动续费。', 359008);
			}
			if(\lib\manage\common\DomainFunLib::checkIsVspDomainLtd($data->domain))
			{
				// 判断是否为非白名单模版
				$templateLib = new \lib\manage\domain\TemplateLib($domainInfo['EnameId']);
				$templateInfo = $templateLib->getTemplateInfoById($domainInfo['TemplateId']);
				if(!isset($templateInfo['CnStatus']) || $templateInfo['CnStatus'] != 2)
				{ 
					throw new \Exception($domainInfo['DomainName'] . '模版为非白名单模版不支持设置自动续费，如需续费请联系客服。', 359005);
				}
			} 
			if(!DomainFunLib::checkisRealDomainRenew($data->domain, $domainInfo['IsRealName'], $domainInfo['RegDate']))
			{
				throw new \Exception($data->domain . '未通过实名不支持设置自动续费，如需续费请联系客服。',322058);
			}
		}
		$domainMod = new \models\manage\domain\DomainsMod();
		$rs = $domainMod->upDomainInfo(array('EnameId' => $data->enameId, 'DomainName' => $data->domain), 
			array('AutoRenew' => $data->autoRenew));
		if($rs)
		{
			DomainLogsLib::addDomainOperaterLog($data->domain, $data->enameId, 
				($data->autoRenew ? '设置域名自动续费' : '取消域名自动续费'), 7); // 操作日志
			return TRUE;
		}
		throw new \Exception('修改续费设置失败', 359004);
	}

	/**
	 * 获取用户域名分组列表
	 */
	public function getDomainGroupList($data)
	{
		return $this->dnManageLib->getDomainGroupList($data->enameId);
	}

	/**
	 * 根据域名高级条件获取域名列表
	 */
	public function getDomainListByAdvance($data)
	{
		$domainMod = new \models\manage\domain\DomainsMod();
		$group = empty($data->group) ? '' : $data->group;
		$status = empty($data->status) ? '' : $data->status;
		$startLength = empty($data->startDomainLength) ? '' : $data->startDomainLength;
		$endtLength = empty($data->endDomainLength) ? '' : $data->endDomainLength;
	   $sysGroup = empty($data->sysGroup) ? '' : $data->sysGroup;
		$firstClass = empty($data->firstClass) ? '' : $data->firstClass;
		$secondClass = empty($data->secondClass) ? '' : $data->secondClass;
		$thirdClass = empty($data->thirdClass) ? '' : $data->thirdClass;
		$domainLtd = !empty($data->domainLtd) ? explode(',', $data->domainLtd) : '';
		$keyWord = empty($data->keyword) ? '' : $data->keyword;
		$enameId = empty($data->enameId) ? '' : $data->enameId;
		$pagenum = !empty($data->pagenum) ? $data->pagenum : 1;
		$templateId = !empty($data->templateId) ? explode(',', $data->templateId) : '';
		$pagesize = !empty($data->pagesize) ? $data->pagesize : 10;
		$send = array('DomainGroup' => $group, 'DomainMyStatus' => $status, 'StartLength' => $startLength, 
			'EnameId' => $enameId, 'KeyWord' => $keyWord, 'SysGroup' => $sysGroup, 'FirstClass' => $firstClass, 'SecondClass' => $secondClass, 'ThirdClass' => $thirdClass, 'DomainLtd' => $domainLtd,  'TemplateId' => $templateId, 
			'EndLength' => $endtLength,'IsLock'=>$data->islock);
		$total = $this->dnManageLib->getDomainAdvance($send, 'count(1) as total');
		$count = $total[0]['total'];
		$islock = empty($data->islock) ? 0 : $data->islock;
		if(!empty($count))
		{
			$limit = ($pagenum - 1) * $pagesize . ',' . $pagesize;
			$send['limit'] = $limit;
			$send['order'] = 'AddDate DESC';
			$domainList = $this->dnManageLib->getDomainAdvance($send, 
				'RegistrarId,DomainName,DomainMyStatus,DomainHoldStatus,RegDate,ExpDate'); 
			$checklocks = array();
			foreach($domainList as $k => $domainInfo)  
			{
				array_push($checklocks,$domainInfo['DomainName']);
				$domainList[$k]['DomainName'] = DomainFunLib::showDomainToEnameShow($domainInfo['DomainName']);
			}
			$lockReturns = $this->checkDomainIsLock($checklocks);//结果返回
			$returnDatas = $this->dnManageLib->formatDomainExpdate($domainList);//这个是需要返回的
			$news = array();
			foreach($returnDatas as $key=>$info)
			{
				$info['islock'] = 0;
				if(!$islock)//全部返回 数量不变
				{
					$info['islock'] = isset($lockReturns[$info['DomainName']]) ? $lockReturns[$info['DomainName']] : 0;
				}
				elseif($islock == 1)//未设置
				{
					if(!empty($lockReturns[$info['DomainName']]))//跳过有设置的
					{
						continue;
					}
				}
				elseif($islock ==2)//设置
				{
					if(empty($lockReturns[$info['DomainName']]))//跳过没有设置的
					{
						continue;
					}
					$info['islock'] = $lockReturns[$info['DomainName']];
				}
				else
				{
					$info['islock'] = 0;
				}
				$news[] = $info;
			}
			return array('data' => $news, 'pagenum' => $pagenum, 'count' => $count);
		}
		return array('data' => array(), 'pagenum' => 1, 'count' => 0);
	}

	/**
	 * 获取域名分组信息 0601
	 *
	 * @param string $domainName
	 * @return array
	 */
	public function getDomainGroup($domainName)
	{
		$groupId = DomainFunLib::getDomainSystemGroupOne($domainName);
		return array('domainClass' => DomainFunLib::getDomainClassName($domainName), 'domainSysOne' => $groupId, 
			'domainSysTwo' => DomainFunLib::getDomainSystemGroupTwo($domainName), 
			'domainLength' => mb_strlen(DomainFunLib::getDomainBody($domainName), "UTF-8"));
	}

	/**
	 * 更新域名状态(交易) 0602
	 *
	 * @param string $domain
	 * @param int $status 1下架(正常状态) 2交易
	 * @return boolean
	 */
	public function setDomainMyStatus($domain, $status)
	{
		DomainLogsLib::addDomainService($domain, array('memo' => 'set_domain_my_status', 'status' => $status), 35);
		$status = intval($status);
		if($status < 3)
		{
			return $this->domainPushLib->domainAddToSale($domain, $status);
		}
		Response::setErrMsg(300018, "域名状态有误");
		return FALSE;
	}

	/**
	 * 判断域名是否是我公司 0604
	 *
	 * @param string $domain
	 * @return boolean
	 */
	public function getDomainUs($domain)
	{
		if(FALSE != $this->dnManageLib->getDomainInfo(array('DomainName' => $domain), "DomainId"))
		{
			return TRUE;
		}
		Response::setErrMsg(300017, '域名不存在');
		return FALSE;
	}

	/**
	 * 获取域名状态 0605，不能交易则返回错误提示，反之返回域名状态
	 *
	 * @param string $domain
	 * @return number|boolean
	 */
	public function getDomainStatus($domain, $jumpTradeCk = false)
	{
		$info = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain));
		if(FALSE != $info)
		{
			if($jumpTradeCk || TRUE == DomainFunLib::checkDomainAllowToTrade($info))
			{
				return $info['DomainMyStatus'];
			}
		}
		else
		{
			Response::setErrMsg(300017, '域名不存在');
			return FALSE;
		}
		return FALSE;
	}

	/**
	 * 获取域名的LTD分类 0609
	 *
	 * @param string $domain
	 * @return number
	 */
	public function getDomainLtd($domain)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$domainLtdArray = $conf->domainLtd->toArray();
		return DomainFunLib::getDomainLtd($domainLtdArray, $domain);
	}

	/**
	 * 判断域名是否属于此人 0610
	 *
	 * @param string $domain
	 * @param int $enameId
	 * @param boolean $isShow
	 * @return number|boolean
	 */
	public function getDomainForUser($domain, $enameId, $isShow = FALSE)
	{
		$enameId = intval($enameId);
		if($enameId && $domain)
		{
			$info = $this->getDomainEnameId($domain);
			if(FALSE != $info)
			{
				if($info == $enameId)
				{
					return $isShow ? $info : TRUE;
				}
				Response::setErrMsg(300017, '域名不属于此人');
				return FALSE;
			}
		}
		else
		{
			Response::setErrMsg(300019, '参数有误');
		}
		return FALSE;
	}

	/**
	 * 获取域名的enameId 0620
	 *
	 * @param string $domain
	 * @return number|boolean
	 */
	public function getDomainEnameId($domain)
	{
		if(DomainFunLib::isOkDomain($domain))
		{
			$info = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain), "EnameId");
			if(FALSE != $info)
			{
				return $info['EnameId'];
			}
			else
			{
				Response::setErrMsg(300017, '域名不存在');
				return FALSE;
			}
		}
		Response::setErrMsg(300013, '域名格式有误');
		return FALSE;
	}

	/**
	 * 获取域名的过期时间 0630
	 *
	 * @param string $domain
	 * @return array|boolean
	 */
	public function getDomainExpdate($domain)
	{
		if(DomainFunLib::isOkDomain($domain))
		{
			$info = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain), "RegDate,ExpDate");
			if(FALSE != $info)
			{
				return array('regDate' => $info['RegDate'], 'expDate' => $info['ExpDate']);
			}
			else
			{
				Response::setErrMsg(300017, '域名不存在');
				return FALSE;
			}
		}
		Response::setErrMsg(300013, '域名格式有误');
		return FALSE;
	}

	/**
	 * 检查是否是qq域名 0631
	 *
	 * @param string $domain
	 * @return boolean
	 */
	public function checkQQDomains($domain)
	{
		$info = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain), "DomainProperty,ClassName");
		if(FALSE != $info)
		{
			if(DomainFunLib::checkDomainIsQQMail($info['DomainProperty'], $info['ClassName']))
			{
				return TRUE;
			}
			else
			{
				Response::setErrMsg(300016, '非腾讯邮箱域名');
				return FALSE;
			}
		}
		Response::setErrMsg(300017, '域名不存在');
		return FALSE;
	}

	/**
	 * 更改域名转移密码
	 */
	public function changePassword($data)
	{
		$domain = isset($data['domain']) ? $data['domain'] : '';
		$RegistrarId = isset($data['registrarId']) ? $data['registrarId'] : 0;
		$memo = isset($data['memo']) ? $data['memo'] : 'transfer_out';
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		if($domain && $RegistrarId && $memo)
		{
			$password = $this->random() . "@" . mt_rand(1, 9);
			$outData = array('domain' => $domain, 'password' => $password, 'registrarID' => $RegistrarId);
			$info = $sdk->execSdkFun(5026, $outData);
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, 
				array('memo' => 'app_' . $memo, 'param' => $outData, 'return' => $info), 11);
			if($info['resultCode'] == 5000)
			{
				return $password;
			}
			Response::setErrMsg(311007, "更改域名转移密码失败");
			return FALSE;
		}
		\lib\manage\domain\DomainLogsLib::addDomainService($domain, 
			array('memo' => 'app_change_password', 'param' => $data, 'c' => '缺少参数'), 11);
	}

	/**
	 * 域名续费
	 */
	public function domainrenew($data)
	{
		$domain = isset($data['domain']) ? $data['domain'] : '';
		$year = isset($data['year']) ? intval($data['year']) : 1;
		$enameId = isset($data['enameId']) ? intval($data['enameId']) : 0;
		$expDate = isset($data['expDate']) ? $data['expDate'] : '';
		DomainLogsLib::addDomainService($domain, 
			array('memo' => 'apprenew', 'year' => $year, 'expDate' => $expDate, 'base' => '0611接口'), 6);
		if($domain && $year && $expDate)
		{
			$domainInfo = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain ,'EnameId'=>$enameId), "*", true);
			if(!$domainInfo)
			{
				DomainLogsLib::addDomainService($domain, 
					array('memo' => 'app not find domain', 'year' => $year, 'expDate' => $expDate, 'base' => '0611接口'), 
					6);
				Response::setErrMsg(310000,"续费失败，域名信息查询失败");
				return FALSE;
			}
			
			if($domainInfo['ExpDate'] != $expDate)
			{
				DomainLogsLib::addDomainService($domain, 
					array('memo' => '过期时间异常,数据库过期时间:' . $domainInfo['ExpDate'] . ',传入的过期时间：' . $expDate, 
						'year' => $year, 'expDate' => $expDate, 'base' => '0611接口'), 6);
				Response::setErrMsg(310001,"续费失败，过期时间异常");
				return FALSE;
			}
			$registrarId = $domainInfo['RegistrarId'];
			$dnLib = new \lib\manage\domain\DomainManageLib();
			try
			{
				$iscoop = $dnLib->cooperRegidDomainCheck($domain, $registrarId, $expDate, $domainInfo['RegDate'], 
					$domainInfo['DomainMyStatus']);
			}
			catch(\Exception $e)
			{
				$iscoop = FALSE;
			}
			if($iscoop)
			{
				return $this->cooperRegidRenew($enameId, $domain, false, $domainInfo);
			}
			include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
			$sdk = new \ApiSdk();
			// webcc 无自动续费的概念 代理的必须自己续费
			// 如果是WEBCC接口的续费 $submit_year 就是用户提交的续费年限
			if($registrarId == 61)
			{
				$submit_year = $year;
			}
			else
			{
				$checkdata = array('domain' => $domain, 'registrarID' => $registrarId);
				$registry_info = $sdk->execSdkFun(5025, $checkdata);
				DomainLogsLib::addDomainService($domain, 
					array('memo' => 'apprenew', 'registryInfo' => $registry_info, 'base' => '0611接口'), 6);
				if($registry_info['resultCode'] != 5000)
				{
					DomainLogsLib::addDomainService($domain, 
						array('memo' => 'apprenew', 'c' => '5025查询失败', 'return' => $registry_info, 'base' => '0611'), 6);
					Response::setErrMsg(310000,"续费失败，域名信息查询失败");
					return FALSE;
				}
				if(isset($registry_info['data']['status']) &&
					 stripos($registry_info['data']['status'], 'pendingDelete') !== false)
				{
					DomainLogsLib::addDomainService($domain, 
						array('memo' => 'apprenew', 'c' => '域名进入赎回期', 'base' => '0611接口'), 6);
					Response::setErrMsg(310002,"续费失败，域名进入赎回期");
					return false; // 域名进入赎回期
				}
				if(isset($registry_info['data']['status']) &&
					 stripos($registry_info['data']['status'], 'RenewProhibited') !== false)
				{
					DomainLogsLib::addDomainService($domain, 
						array('memo' => 'apprenew', 'c' => '域名状态禁止续费', 'base' => '0611接口'), 6);
					Response::setErrMsg(310003,"续费失败，域名状态禁止续费");
					return false; // 禁止续费
				}
				
				$expdate_info = $this->checkExpireDate($expDate, $registry_info['data']['expireDate']);
				if($expdate_info == FALSE)
				{
					\core\Log::write(
						json_encode(
							array('过期时间异常,续费失败', 'domain:' . $domain, 'expDate:' . $expDate, 
								'registerExpDate:' . $registry_info['data']['expireDate'])), 'domain', 'expDateUnusual');
					DomainLogsLib::addDomainService($domain, 
						array('memo' => 'apprenew', 'c' => '过期时间异常', 'base' => '0611接口'), 6);
					Response::setErrMsg(310001,"续费失败，过期时间异常");
					return FALSE;
				}
				$is_autorenew = $expdate_info['autorenew'];
				$expDate = $expdate_info['expdate'];
				$submit_year = $year;
				if($is_autorenew)
				{
					$submit_year--;
				}
			}
			if($submit_year > 0)
			{
				$expDate = date("Y-m-d", strtotime($expDate)); // 走新接口cnnic接口域名不需要加8小时
				$ext = '';
				if(\lib\manage\common\DomainFunLib::getDomainClass($domain) == 'VIP')
				{
					$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'viprenew');
					$ext = array('fee' => $conf->renew_extension_fee,'currency'=>$conf->renew_extension_currency);
				}
				$renewdata = array('domain' => $domain, 'period' => $submit_year, 'expDate' => $expDate, 
					'registrarID' => $registrarId,'ext'=>$ext);
				$reData = $sdk->execSdkFun(5003, $renewdata);
				
				if($reData['resultCode'] == 5000 && empty($reData['data']['expireDate']))
				{
					$checkdata = array('domain' => $domain, 'registrarID' => $registrarId);
					$registry_info = $sdk->execSdkFun(5025, $checkdata);
					if($registry_info['resultCode'] != 5000)
					{
						DomainLogsLib::addDomainService($domain,
							array('memo' => 'renew', 'c' => '5025查询失败', 'return' => $registry_info,
								'base' => '5025重新获取域名过期时间失败，直接' . $data['expDate'] . '加' . $submit_year . '年'), 6);
						$reData['data']['expireDate'] = date("Y-m-d H:i:s",strtotime("+$submit_year years",strtotime($data['expDate'])));
					}
					else
					{
						DomainLogsLib::addDomainService($domain,
							array('memo' => 'renew', 'year' => $submit_year, 'return' => $registry_info,
								'base' => '5003获取过期时间失败 5025重新获取域名过期时间'), 6);
						$reData['data']['expireDate'] = $registry_info['data']['expireDate'];
					}
				}
				DomainLogsLib::addDomainService($domain, 
					array('memo' => 'apprenew', 'param' => $renewdata, 'return' => $reData, 'base' => '注册局'), 6);
			}
			else
			{
				$locate = true;
				$reData['resultCode'] = 5000;
				$reData['data']['expireDate'] = $registry_info['data']['expireDate'];
				$reData['data']['epp'] = $registrarId;
				$reData['autoRenew'] = $is_autorenew;
				DomainLogsLib::addDomainService($domain, 
					array('memo' => 'apprenew', 'param' => $data, 'return' => $reData, 'base' => '本地'), 6);
			}
			if($reData['resultCode'] == 5000)
			{
				// 更新过期时间
				$setData = array('UpdateDate' => gmdate("Y-m-d H:i:s"), 'ExpDate' => $reData['data']['expireDate'],
					'SysUpdateTime' => date("Y-m-d H:i:s"));
				$upLocal = $this->dnManageLib->setDomainInfo(array('DomainName' => $domain), $setData);
				if(FALSE === $upLocal)
				{
					DomainLogsLib::addDomainService($domain, 
						array('memo' => 'app 域名续费成功，修改数据过期时间错误', 
							'param' => array($domain, $reData['data']['expireDate']), 'base' => '本地'), 6);
					if(isset($locate) && $locate == true)
					{
						Response::setErrMsg(310005, "续费失败，系统繁忙");
						return FALSE;
					}
				}
				else
				{
					$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'domain_renew_success'));  
			    	$amqp->sendMq(array('uid' => $enameId,'time'=>time(),'expdate' => $reData['data']['expireDate'], 'dn' => $domain ,'from'=>2));
			    	// 站内短消息
			    	$this->addMsgMailToRedis($domain, $enameId);
			    }
				// 写入日志
				DomainLogsLib::addDomainOperaterLog($domain, $enameId, '域名续费' . $year . '年', 1);
				$renewdata = isset($renewdata) ? $renewdata : array('domain' => $domain, 'period' => 1, 
					'registrarID' => $registrarId, 'memo' => 'auto_renew');
				DomainLogsLib::addDomainLog($domain, $enameId, 3, $renewdata, $reData, $domain . '域名续费成功');
				return $reData['data']['epp'];
			}
			else
			{
				DomainLogsLib::addDomainLog($domain, $enameId, 3, $renewdata, $reData, $domain . '域名续费失败', 0); 
				//格式化注册局续费失败原因
				$this->dnManageLib->formatRenewReturn(isset($reData['data']['msg'])?$reData['data']['msg']:"");
				return FALSE;
			}
		}
		else 
		{
			Response::setErrMsg(310004,"续费失败，传入参数有误");
			return false;
		}
	}

	private function fixCnnicDomainExp($domain)
	{
		$ok = FALSE;
		if(strtolower(substr($domain, strlen($domain) - 2)) == 'cn')
		{
			$ok = true;
		}
		elseif(stripos($domain, '.中国') !== FALSE)
		{
			$ok = true;
		}
		return $ok;
	}

	private function addMsgMailToRedis($domain, $enameId)
	{
		try
		{
			$redis = \core\RedisLib::getInstance('manage',false);
			$redisKey = 'domain_renew0611_' . date('Y-m-d');
			$addInfo = $redis->sadd('domain_renew0611_' . date('Y-m-d'), $enameId . '_' . $domain);
			if(!$addInfo)
			{
				\core\Log::write('域名续费成功，提醒邮件加入redis失败' . $enameId . ',' . $domain, 'domain');
			}
		}
		catch(\Exception $e)
		{
			\core\Log::write('域名续费成功，提醒邮件加入redis失败,' . $e->getMessage(), 'domain');
		}
	}

	/**
	 * 到接口修改域名的DNS dnsid=1 我司DNS code:0612
	 *
	 * @param array $data
	 * @param $forceRestore 过期域名续费强制还原
	 * @version edit:1inlz 2012-06-13
	 */
	public function setDomainDns($infoData, $forceRestore = false)
	{
		$domain = isset($infoData['domain']) ? $infoData['domain'] : '';
		$dns = isset($infoData['dns']) ? $infoData['dns'] : '';
		$registrarId = isset($infoData['registrarID']) ? $infoData['registrarID'] : '';
		$dnsType = isset($infoData['dnsType']) ? $infoData['dnsType'] : '';
		$dnsType = $dnsType ? 3 : 0;
		$dnsId = $dnsType ? 0 : 1;
		$domainId = isset($infoData['domainId']) ? $infoData['domainId'] : '';
		$enameId = isset($infoData['enameId']) ? $infoData['enameId'] : '';
		if($domain && $dns && $registrarId && $enameId)
		{
			// 要修改的dns和之前的dns一致，直接返回修改成功
			if(!$forceRestore && self::isSameDns($domainId, $dnsType, $dns))
			{
				return true;
			}
			// 若设置其他DNS全是我司DNS强制转换类型为我司DNS
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'iidns');
			$selfDns = $conf->iidns->toArray();
			$flag = true;
			foreach($dns as $val)
			{
				if(!in_array($val, $selfDns))
				{
					$flag = false;
					break;
				}
			}
			if($flag)
			{
				$dnsType = 0;
				$dnsId = 1;
			}
			$epp = new \lib\manage\domain\DomainEppLib($enameId);
			$info = $epp->setDomainDns($domain, $dnsId, $dns, $registrarId, true);
			if($info['resultCode'] != 5000)
			{
				$returnFlag = false;
				if($info['resultCode'] == 5015)
				{
					if(!empty($info['data']['msg']['resultExt']) &&
						 stripos($info['data']['msg']['resultExt'], 'is already') !== false)
					{
						return true; // 底层返回dns已设置时直接返回成功
					}
					if(!empty($info['data']['msg']['resultMsg']) &&
						 stripos($info['data']['msg']['resultMsg'], 'is already') !== false)
					{
						return true; // 底层返回dns已设置时直接返回成功
					}
					if($dnsType && self::autoRegDns($domain, $dns))
					{
						$info = $epp->setDomainDns($domain, $dnsId, $dns, $registrarId, true);
						if($info['resultCode'] == 5000)
						{
							$returnFlag = true;
						}
					}
					if(!$returnFlag)
					{
						$this->restoreDns($domainId, $domain, $registrarId); // 5015时修改为原来的dns，因为底层是先删除dns后修改
					}
				}
				if(!$returnFlag)
				{
					return false;
				}
			}
			$where = array('DomainId' => $domainId);
			$dnsSet = $dnsType ? implode(',', $dns) : '';
			$upExtInfo = $this->dnManageLib->setDomainExtInfo($where, array('Dns' => $dnsSet)); // 修改扩展表dns
			if(!$upExtInfo)
			{
				\core\Log::write('本地修改dns失败,' . $domain);
				Response::setErrMsg(321001, '修改dns失败');
				return FALSE;
			}
			$domainInfo = $this->dnManageLib->getDomainInfo(array('DomainId' => $domainId), 'DnsType', true);
			if($domainInfo['DnsType'] != $dnsType)
			{
				$upDomainInfo = $this->dnManageLib->setDomainInfo(array('DomainId' => $domainId), 
					array('DnsType' => $dnsType));
				if(!$upDomainInfo)
				{
					\core\Log::write('本地修改域名信息失败,' . $domain);
					Response::setErrMsg(321002, '更新域名信息失败');
					return FALSE;
				}
			}
			DomainLogsLib::addDomainOperaterLog($domain, $enameId, '修改域名DNS', 6); // 操作日志
			if($dnsId)
			{
				$this->dnManageLib->addDomainIIdns($domain, $enameId); // 添加域名到edns
			}
			return TRUE;
		}
		DomainLogsLib::addDomainService($domain, 
			array('memo' => '0612修改DNS', 'param' => $infoData, 'c' => '缺少参数:domain,dns,registrarID,enameId'), 8);
		return FALSE;
	}

	/**
	 * 用户在其他注册商有注册过的DNS在我司使用时提示DNS未注册，这类DNS直接系统默认帮助注册DNS
	 * 一个失败就算失败  全部成功才算成功
	 */
	private function autoRegDns($domain, $dnsArray)
	{
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		$data['ipAddress'] = '';
		foreach($dnsArray as $k => $v)
		{
// 			$isCurLtdRegistered = $sdk->execSdkFun(5301, $data);
// 			if($isCurLtdRegistered['resultCode'] != 5000)
// 			{
// 				\core\Log::write('dns是否注册查询失败--' . $isCurLtdRegistered['resultMsg'] . '--' . json_encode($data), false, 
// 					'domainregdns_auto_');
// 				return false;
// 			}
// 			if(!$isCurLtdRegistered['data']['registered'])
// 			{
// 				\core\Log::write('dns未注册自身后缀dns服务--' . json_encode($data), false, 'domainregdns_auto_');
// 				return false;
// 			}
			//获取对应的regid
			$curLtdNum = self::getCurLtdNum($domain, $v);
			if(!$curLtdNum)
			{
				\core\Log::write('后缀不提供注册域名dns服务或者dns后缀和域名后缀相同--' . json_encode($data), false, 'domainregdns_auto_');
				return false; // 后缀不提供注册域名dns服务或者dns后缀和域名后缀相同则跳过
			}
			$data['registrarId'] = $curLtdNum[0];
			$data['domain'] = $curLtdNum[1];
			$data['host'] = $v;
			$isRegistered = $sdk->execSdkFun(5301, $data);
			if($isRegistered['resultCode'] != 5000)
			{
				\core\Log::write('dns是否注册查询失败--' . $isRegistered['resultMsg'] . '--' . json_encode($data), false, 
					'domainregdns_auto_');
				return false;
			}
			if($isRegistered['data']['registered'])
			{
				\core\Log::write('dns已注册对应后缀dns服务--' . json_encode($data), false, 'domainregdns_auto_');
				continue;
			}
			if(isset($isRegistered['data']['registered']) && !$isRegistered['data']['registered'])
			{
				$info = $sdk->execSdkFun(5302, $data);
				if($info != 5000)
				{
					\core\Log::write('dns注册对应后缀dns服务失败--' . json_encode($info) . '--' . json_encode($data), false,
						'domainregdns_auto_');
					return false;
				}
				//全部成功才算成功
				\core\Log::write('dns注册对应后缀dns服务成功--' . json_encode($data), false, 'domainregdns_auto_');
			}
			else
			{
				\core\Log::write('dns注册对应后缀dns服务失败--接口失败--' . json_encode($data), false,
					'domainregdns_auto_');
				return false;
			}
		}
		return true;
	}
	
	// 获取当前域名后缀接口和ename域名
	private function getCurLtdNum($domain, $dns)
	{
		$config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'reg_dns_registrarid');
		$registrarIdConfig = (array)$config->reg_dns_registrarid;
		$webccLtd = array('cc', 'tv', 'in', 'me', 'info', 'us', 'biz', 'tw');
		$dnsLtdArr = explode('.', $dns);
		$dnsLtd = end($dnsLtdArr);
		$domainLtdArr = explode('.', $domain);
		$domainLtd = end($domainLtdArr);
		if(in_array($dnsLtd, $webccLtd) && in_array($domainLtd, $webccLtd) && $dnsLtd == $domainLtd)
		{
			return false;
		}
		else
		{
			foreach($registrarIdConfig as $k => $v)
			{
				if($k == 61)
				{
					$is_inLtd = in_array($domainLtd, $webccLtd);
				}
				else
				{
					$is_inLtd = in_array(strtoupper($domainLtd), explode(',', $v));
				}
				if(in_array(strtoupper($dnsLtd), explode(',', $v)) && in_array(strtoupper($domainLtd), explode(',', $v)))
				{
					return false;
				}
				elseif($is_inLtd)
				{
					return array($k, 'ename.' . $domainLtd);
				}
			}
		}
		return false;
	}

	/**
	 * 检测要修改的dns是否和之前的dns一致
	 */
	private function isSameDns($domainId, $dnsType, $dns)
	{
		$domainInfo = $this->dnManageLib->getDomainInfo(array('DomainId' => $domainId), 'DnsType');
		if(empty($domainInfo['DnsType']))
		{
			return false; // 域名信息查找失败
		}
		if($dnsType == 0 && $domainInfo['DnsType'] == $dnsType)
		{
			return true; // 修改前后均为我司dns dnstype为0
		}
		$extInfo = $this->dnManageLib->getDomainExt(array('DomainId' => $domainId));
		if($extInfo)
		{
			$dnsOld = explode(',', $extInfo['Dns']);
			$diff1 = array_diff($dns, $dnsOld);
			$diff2 = array_diff($dnsOld, $dns);
			if(empty($diff1) && empty($diff2) && $domainInfo['DnsType'] == $dnsType)
			{
				return true; // dns一致
			}
		}
		return false;
	}

	/**
	 * 还原dns
	 *
	 * @param int $domainId
	 * @param string $domain
	 * @param int $registrarId
	 * @return boolean
	 * @author linlz
	 * @version 2012-06-13
	 */
	private function restoreDns($domainId, $domain, $registrarId)
	{
		$dnsId = 0;
		$domainInfo = $this->dnManageLib->getDomainInfo(array('DomainId' => $domainId), 'DnsType', true);
		if(empty($domainInfo))
		{
			\core\Log::write('5013还原DNS失败,查无域名信息domainId:' . $domainId . ',domain:' . $domain, 'domain', 'dns');
			return FALSE;
		}
		$dnsType = $domainInfo['DnsType'];
		$resetDns = array();
		$domainDnsOther = array();
		if($dnsType == 0) // 我司
		{
			$dnsId = 1;
			$domainDnsOther = array('ds1.iidns.com');
		}
		else 
			if($dnsType == 3) // 其他dns
			{
				$dnsId = 0;
				$mod = new \models\manage\domain\DomainExtMod();
				$domainExt = $mod->getOneDomainExt(array('DomainId' => $domainId));
				if(!empty($domainExt))
				{
					$domainDnsOther = explode(",", $domainExt['Dns']);
				}
				else
				{
					\core\Log::write('5013还原DNS失败,查找其他dns信息失败,domain:' . $domain, 'domain', 'dns');
					return FALSE;
				}
			}
			else 
				if($dnsType == 4)
				{
					$domainDnsOther = array('ns1.ename.net', 'ns2.ename.net', 'ns3.ename.net', 'ns4.ename.net', 
						'ns5.ename.net', 'ns6.ename.net');
				}
		foreach($domainDnsOther as $k => $v)
		{
			$resetDns[$k + 1] = trim($v);
		}
		$epp = new \lib\manage\domain\DomainEppLib();
		$epp->setDomainDns($domain, $dnsId, $resetDns, $registrarId);
	}

	/**
	 * 检测域名是否已经过期20天 是：还原域名的DNS code:0615
	 *
	 * @param array $infoData
	 */
	public function checkExpireHold($infoData)
	{
		$domain = isset($infoData['domain']) ? $infoData['domain'] : '';
		$expDate = isset($infoData['expDate']) ? $infoData['expDate'] : '';
		$enameId = isset($infoData['enameId']) ? $infoData['enameId'] : '';
		$email = isset($infoData['email']) ? $infoData['email'] : '';
		$extData = isset($infoData['extData']) ? $infoData['extData'] : '';
		\core\Log::write(
			$domain . '|' . $expDate . '|' . $enameId . '|' . $email . '|' . json_encode($extData) . '|' .
				 json_encode($infoData), 'domain', 'domainRenew');
		if(!$domain)
		{
			return false;
		}
		$domainLtd = \lib\manage\common\DomainFunLib::getDomainClass($domain);
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$expDomainLtd = $conf->expDayDomainLtd->toArray();
		if(in_array($domainLtd, $expDomainLtd) === FALSE)
		{
			return false;
		}
		if($expDate && $enameId && strtotime("- " . $conf->expDayChangeDns . " days") > strtotime($expDate))
		{
			$domainHoldStatus = 0;
			$serviceWhere = array('ServiceType' => 64, 'UserId' => $enameId, 'Domain' => $domain);
			$oldStatus = \lib\manage\domain\DomainLogsLib::getDomainService($serviceWhere, true);
			if($oldStatus)
			{
				$domainHoldStatus = isset($oldStatus['Content']) ? $oldStatus['Content'] : 0;
			}
			$domainSet = array('DomainHoldStatus' => $domainHoldStatus);
			$domainSetInfo = $this->dnManageLib->setDomainInfo(array('DomainName' => $domain, 'EnameId' => $enameId), 
				$domainSet);
			\core\Log::write('app修改域名holdstatus,return:' . $domainSetInfo, 'domain', 'domainRenew');
			$dnsType = $extData['DnsType'];
			$infoDnsData = array();
			$infoDnsData['enameId'] = $enameId;
			if($dnsType == 0 || $dnsType == 4) // iidns or ename.net
			{
				$infoDnsData['dns'] = array('dns1' => 'dns1.iidns.com');
				$infoDnsData['dnsType'] = 0;
			}
			else
			{
				$extInfo = $this->dnManageLib->getDomainExt(array('DomainId' => $extData['DomainId']));
				if($extInfo)
				{
					$dns = explode(',', $extInfo['Dns']);
					$newData = array();
					foreach($dns as $k => $v)
					{
						$newData[$k + 1] = $v;
					}
					unset($dns);
					$infoDnsData['dns'] = $newData;
					$infoDnsData['dnsType'] = 3;
				}
			}
			$infoDnsData['domain'] = $domain;
			$infoDnsData['registrarID'] = $extData['RegistrarId'];
			$infoDnsData['domainId'] = $extData['DomainId'];
			$infoDnsData['email'] = $email;
			$this->setDomainDns($infoDnsData, true);
		}
	}

	/**
	 * 获取当前域名总数
	 */
	public function getDomainCount($enameId,$domainGroup='')
	{
		return $this->dnManageLib->getDomainCount($enameId,$domainGroup);
	}

	/**
	 * 返回域名状态信息(目前仅提供给交易用获取展示页状态) 1=正常 2交易 3经纪中介 4正在转移 5正在转出 6已转出 7违规锁定 9 其他锁定 10sedo交易 11注册商安全 12注册局安全 13安全锁申请中 15禁止解析 16展示页
	 */
	public function getDomainMyStatus($domainArr)
	{
		$return = array();
		foreach($domainArr as $domain)
		{
			$domainInfo = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain), 
				'DomainMyStatus,DomainHoldStatus');
			if(!$domainInfo)
			{
				$return[$domain] = -1; // 正常状态下不会
				continue;
			}
			if($domainInfo['DomainHoldStatus'] == 1)
			{
				$domainInfo['DomainMyStatus'] = 15;
			}
			else 
				if($domainInfo['DomainHoldStatus'] == 5)
				{
					$domainInfo['DomainMyStatus'] = 16;
				}
			$return[$domain] = $domainInfo['DomainMyStatus'];
		}
		return $return;
	}

	/**
	 * 参数$local_expdate 和 $registry_expdate的格式'Y-m-d H:i:s'，例如类似 '2012-01-01 00:00:00' 正常返回数组，否则返回FALSE表示过期时间异常
	 *
	 * @param string $local_expdate
	 * @param string $registry_expdate
	 */
	private function checkExpireDate($local_expdate, $registry_expdate)
	{
		$registry = $this->isSameDate($local_expdate, $registry_expdate);
		if($registry)
		{
			return array('autorenew' => FALSE, 'expdate' => $registry);
		}
		$dt = new \DateTime($local_expdate);
		if($dt->getTimestamp() > time())
		{
			return FALSE;
		}
		$dt->add(new \DateInterval('P1Y'));
		$registry = $this->isSameDate($dt->format('Y-m-d H:i:s'), $registry_expdate);
		if(!$registry)
		{
			return FALSE;
		}
		$dt = new \DateTime($local_expdate);
		$dt->add(new \DateInterval('P46D')); // 加46天(45会差一天)
		if($dt->getTimestamp() < time())
		{
			return FALSE;
		}
		return array('autorenew' => TRUE, 'expdate' => $registry);
	}

	private function isSameDate($local_expdate, $registry_expdate)
	{
		$local = substr($local_expdate, 0, 10);
		$registry = substr($registry_expdate, 0, 10);
		if($local == $registry)
		{
			return $registry_expdate;
		}
		// cnnic .中国 后缀2月28日和2月29日特殊处理
		if(substr($local_expdate, 0, 7) == substr($registry_expdate, 0, 7) && substr($local_expdate, 5, 2) == '02')
		{
			$dayArr = array(27, 28, 29);
			$lDay = substr($local_expdate, 8, 2);
			$rDay = substr($registry_expdate, 8, 2);
			if(in_array($lDay, $dayArr) && in_array($rDay, $dayArr))
			{
				return $registry_expdate;
			}
		}
		// 针对注册局一直在变动的时间做下特殊处理。。。
		$tmp_expdate = date('Y-m-d H:i:s', strtotime($local_expdate) - 86400);
		if(substr($tmp_expdate, 0, 7) == substr($registry_expdate, 0, 7) && substr($tmp_expdate, 5, 2) == '02')
		{
			$dayArr = array(27, 28, 29);
			$lDay = substr($tmp_expdate, 8, 2);
			$rDay = substr($registry_expdate, 8, 2);
			if(in_array($lDay, $dayArr) && in_array($rDay, $dayArr))
			{
				return $registry_expdate;
			}
		}
		// fix cnnic begin: cnnic的过期时间是+8
		$dt = new \DateTime($local_expdate);
		$dt->add(new \DateInterval('PT8H'));
		$local = $dt->format('Y-m-d');
		if($local == $registry)
		{
			return $registry;
		}
		// fix cnnic end: cnnic的过期时间是+8
		return FALSE;
	}

	private function random($length = 8)
	{
		$chars = 'bcdfghjk@lmn$prstvwxzaeiou';
		$result = '';
		for($p = 0; $p < $length; $p++)
		{
			$result .= ($p % 2) ? $chars[mt_rand(19, 25)] : $chars[mt_rand(0, 18)];
		}
		return $result;
	}

	public function getRegistrarAndTemplate($domain)
	{
		$dnManageLib = new \lib\manage\domain\DomainManageLib();
		
		if(!$this->getDomainUs($domain))
		{
			return FALSE;
		}
		$rs = $dnManageLib->getDomainInfo(array('DomainName' => $domain), 'RegistrarId,TemplateId,PrivacyTemp');
		if(FALSE == $rs)
		{
			return FALSE;
		}
		if($rs['PrivacyTemp'])
		{
			$rs['TemplateId'] = $rs['PrivacyTemp'];
		}
		$templateLib = new \lib\manage\domain\TemplateLib();
		$templateInfo = $templateLib->getTemplateInfoById($rs['TemplateId']);
		if(FALSE == $templateInfo)
		{
			return FALSE;
		}
		if($templateInfo['TemplateType'] == 2)
		{
			$enTemplateInfo = $templateLib->getEnTemplate($rs['TemplateId']);
			$registerName = $enTemplateInfo['Name'];
		}
		else 
			if(in_array($templateInfo['TemplateType'], array(1, 6, 7)))
			{
				$registerName = $templateInfo['Org'];
			}
			else
			{
				$registerName = $templateInfo['Name'];
			}
		$config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'registrar');
		foreach($config->registrarId as $key => $value)
		{
			if($key == $rs['RegistrarId'])
			{
				$registrarName = $value;
				break;
			}
		}
		return array($registrarName, $registerName);
	}

	/**
	 * 设置域名状态（主要是后台锁定）,添加域名备注
	 */
	public function setDomainStatus($data)
	{
		if(empty($data['domain']))
		{
			Response::setErrMsg('3590000', '参数有误');
			return FALSE;
		}
		$params = $set = array();
		$params['DomainName'] = $data['domain'];
		if(!empty($data['enameId']))
		{
			$params['EnameId'] = $data['enameId'];
		}
		$set['DomainMyStatus'] = empty($data['setStatus']) ? 9 : $data['setStatus'];
		$remark = empty($data['remark']) ? '系统备注：gd转入异常' : $data['remark'];
		return $this->dnManageLib->setDomainStatus($params, $set, $remark);
	}

	/**
	 * 修改dns,加上各种判断，与管理前台对应
	 */
	public function checkDomainDns($data)
	{
		$domainMod = new \models\manage\domain\DomainsMod();
		$domainInfo = $domainMod->getDomainInfo(array('DomainName' => $data['domain']));
		if(!$domainInfo)
		{
			throw new \Exception("找不到该域名！", 322049);
		}
		if(\lib\manage\common\DomainFunLib::isChinaDomain($data['domain']))
		{
			\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck();
		}
		$this->checkDomainToModifyDns($domainInfo);
		$dnsArray = $this->checkDnsAndFormat($data['dnsType'], $data['dns']);
		$sendData['domain'] = $data['domain'];
		$sendData['dns'] = $dnsArray;
		$sendData['registrarID'] = $domainInfo['RegistrarId'];
		$sendData['domainId'] = $domainInfo['DomainId'];
		$sendData['enameId'] = $data['enameId'];
		$sendData['dnsType'] = $data['dnsType'];
		$result = $this->setDomainDns($sendData);
		if(!$result)
		{
			throw new \Exception("DNS修改失败", 322050);
		}
		return true;
	}

	/**
	 * 修改dns,队列操作
	 */
	public function setDomainDnsByQueue($data)
	{
		$operatelogic = new \logic\manage\member\OperateLogic();
		if(!$operatelogic->checkOperate((object)$data))
		{
			return array('flag' => false, 'msg' => '操作保护验证失败，请稍后重试！');
		}
		$dnsArray = $this->checkDnsAndFormat($data['dnsType'], $data['dns']);
		$okDomain = $this->checkSetDnsDomainStatus($data['domain']);
		if(count($okDomain) > 300)
		{
			throw new \Exception('一次最多允许批量操作300个域名', 330033);
		}
		foreach($okDomain as $k => $v)
		{
			if(!$v['status'])
			{
				unset($okDomain[$k]);
			}
		}
		$queueArray = array();
		$dnsType = $data['dnsType'] ? $data['dnsType'] : 0;
		$dnsType = $dnsType ? 3 : 0;
		foreach($okDomain as $k => $v)
		{
			$domainInfo = $this->dnManageLib->getDomainInfo(
				array('DomainName' => $v['domain'], 'EnameId' => $this->enameId));
			$queueArray[$k]['domainLtd'] = $domainInfo['DomainLtd'];
			$queueArray[$k]['domain'] = $v['domain'];
			$queueArray[$k]['domainId'] = $domainInfo['DomainId'];
			$queueArray[$k]['DNS'] = $dnsArray;
			$queueArray[$k]['dnsType'] = $dnsType;
			$queueArray[$k]['registrarId'] = $domainInfo['RegistrarId'];
		}
		
		try
		{
			$queueLib = new \logic\manage\newqueue\QueueLogic();
			$result = $queueLib->addQueueTask(
				array('Function' => 'modify_domain_dns', 'EnameId' => $this->enameId, 'Data' => $queueArray, 
					'Priority' => 3));
			return array('flag' => true, 'msg' => '设置DNS的任务已经加入队列,等待队列执行！');
		}
		catch(\Exception $e)
		{
			return array('flag' => false, 'msg' => '系统发生错误，加入队列失败，请稍后重试！');
		}
	}

	/**
	 * 修改dns前验证域名状态
	 */
	public function checkSetDnsDomainStatus($domains)
	{
		$newDomain = array();
		$domainArr = explode(',', $domains);
		$domainArr = array_unique($domainArr);
		foreach($domainArr as $k => $domain)
		{
			$domain = trim($domain);
			if(!DomainFunLib::isOkDomain($domain))
			{
				$newDomain[] = array('domain' => $domain, 'status' => false, 'msg' => '域名格式错误，不能修改DNS');
				continue;
			}
			$info = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain, 'EnameId' => $this->enameId));
			if(!$info)
			{
				$newDomain[] = array('domain' => $domain, 'status' => false, 'msg' => '不是您的域名，不能修改DNS');
				continue;
			}
			try
			{
				if(\lib\manage\common\DomainFunLib::isChinaDomain($domain))
				{
					\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck();
				}
				$this->checkDomainToModifyDns($info, false);
			}
			catch(\Exception $e)
			{
				$newDomain[] = array('domain' => $domain, 'status' => false, 'msg' => $e->getMessage());
				continue;
			}
			$newDomain[] = array('domain' => $domain, 'status' => true, 'msg' => '');
		}
		$newDomain = self::arrayOrder($newDomain);
		return $newDomain;
	}

	/**
	 * 检查域名是否可以修改DNS @hold 域名可以修改DNS 2012-04-13
	 *
	 * @param array $info
	 * @throws Exception
	 */
	public static function checkDomainToModifyDns($info, $throwDomain = true, $msg = '修改DNS!')
	{
		$domainName = $throwDomain ? $info['DomainName'] : '';
		if($info['DomainHoldStatus'] == 3 || $info['DomainHoldStatus'] == 5)
		{
			throw new \Exception($domainName . '域名已经设置展示页，不能' . $msg, 359101);
		}
		if($info['DomainMyStatus'] > 5 && $info['DomainMyStatus'] != 9 && $info['DomainMyStatus'] != 10 &&
			 $info['DomainMyStatus'] != 13 && $info['DomainMyStatus'] != 14)
		{
			throw new \Exception($domainName . '域名状态错误，不能' . $msg, 359102);
		}
		if($info['DomainHoldStatus'] == 2)
		{
			throw new \Exception($domainName . '域名被DNS锁定，不能' . $msg, 359103);
		}
		if($info['DomainHoldStatus'] == 3 || $info['DomainHoldStatus'] == 5)
		{
			throw new \Exception($domainName . '当前为展示页状态，不能' . $msg, 359104);
		}
		if(($info['DomainProperty'] == 4 || $info['DomainProperty'] == 6) && $info['ClassName'] == 1)
		{
			throw new \Exception($domainName . '腾讯邮箱域名，不能' . $msg, 359105);
		}
		if(DomainFunLib::checkIsTempTemplate($info['TemplateId']))
		{
			throw new \Exception($domainName . '域名的模板为临时模板，不能' . $msg, 359106);
		}
	}

	/**
	 * 检测DNS内容 并格式化内容
	 *
	 * @param int $dnsType
	 * @param array $dnsInfo
	 * @param MY_Controller $ctrl
	 * @throws Exception
	 * @return array
	 */
	private function checkDnsAndFormat($dnsType, $dnsInfo)
	{
		$dnsTemp = '';
		if($dnsType)
		{
			if(stripos($dnsInfo, '.,') !== FALSE)
			{
				throw new \Exception('DNS格式有误，请输入类似dns1.iidns.com的DNS地址!', 359107);
			}
			$dnsTemp = $dnsInfo;
		}
		else
		{
			// 我司
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'iidns');
			$dnsArray = $conf->iidns->toArray();
			$dnsTemp = implode(',', $dnsArray);
		}
		if(stripos($dnsTemp, '.ename.net') !== false || stripos($dnsTemp, '.ename.cn') !== false)
		{
			throw new \Exception('不能设置为 ename.net/ename.cn 的DNS!', 359108);
		}
		$dnsTempArray = explode(',', $dnsTemp);
		if(count($dnsTempArray) != count(array_unique($dnsTempArray)))
		{
			throw new \Exception('请不要填写重复的DNS服务器地址,以保证域名的正常解析!', 359109);
		}
		if(count($dnsTempArray) < 2)
		{
			throw new \Exception('请至少输入2组DNS服务器地址,以保证域名的正常解析!', 359110);
		}
		$dnsArray = array();
		foreach($dnsTempArray as $k => $v)
		{
			$dnsArray[] = trim($v);
		}
		return $dnsArray;
	}

	public function domainRenewOther($data)
	{
		$enameId = $data->enameId;
		$domain = $data->domain;
		if(\lib\manage\common\DomainFunLib::isChinaDomain($domain) &&
			 !\lib\manage\common\DomainFunLib::isWangluoDomain($domain))
		{
			\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck();
		}
		$expdate = $data->expDate;
		$year = $data->period;
		$config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'cooper');
		if($enameId != $config->enameid)
		{
			throw new \Exception("未授权的用户ID");
		}
		$memberLib = new \lib\manage\member\MemberLib();
		$memberInfo = $memberLib->getMemberInfoByEnameId($enameId);
		$dnManage = new \lib\manage\domain\DomainManageLib();
		if(!$memberInfo)
		{
			throw new \Exception('用户信息获取失败', 311006);
		}
		$email = $memberInfo['Email'];
		$userLevel = $memberInfo['UserGroup'];
		$domainInfo = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain));
		if(empty($domainInfo))
		{
			throw new \Exception("域名信息查找失败");
		}
		$productType = $domainInfo['DomainProperty'];
		$this->dnManageLib->checkEnableMoney($enameId, $domain, $productType, 3);
		$productName = \lib\manage\common\DomainFunLib::getDomainClass($domain);
		\lib\manage\common\DomainOpenLib::checkOpen('renew', $domain, TRUE);
		$orderLib = new \interfaces\manage\Finance();
		$create = array('domain' => $domain, 'enameId' => $enameId, 'year' => $year, 'promoCode' => '', 
			'productName' => '.' . $productName, 'email' => $email, 'userGroupId' => $userLevel, 
			'expDate' => $domainInfo['ExpDate'], 'productType' => $productType, 
			'templateId' => $domainInfo['TemplateId'], 'type' => 3, 'remark' => '', 'ext' => '', 
			'registarId' => $domainInfo['RegistrarId']);
		
		$orderInfo = $orderLib->addProductOrder((object)$create);
		if(is_array($orderInfo) || $orderInfo === false)
		{
			throw new \Exception('订单创建失败', 311008); // 订单创建失败
		}
		\core\Log::write('interfaces115' . $orderInfo, 'cart', 'order');
		$renewData = array('domain' => $domain, 'year' => $year, 'enameId' => $enameId, 
			'expDate' => empty($expdate) ? $domainInfo['ExpDate'] : $expdate);
		$epp = $this->domainRenew($renewData);
		if(!$epp)
		{
			$returnErrMsg = Response::getErrMsg();
			$returnErrCode = Response::getErrCode();
			$st = $orderLib->cancelOrder((object)array('orderId' => $orderInfo, 'enameId' => $enameId));
			\core\Log::write('app115cancelorder_3' . '_' . $orderInfo . '_' . ($st ? 'success' : 'failed'), 'domain', 
				'order');
			throw new \Exception($returnErrMsg, $returnErrCode); // 续费失败
		}
		if($domainInfo['DomainHoldStatus'] == 2)
		{
			$this->checkExpireHold($renewData);
		}
		$st = $orderLib->confirmOrder((object)array('orderId' => $orderInfo, 'enameId' => $enameId));
		\core\Log::write('app115confirmorder_3' . '_' . $orderInfo . '_' . ($st ? 'success' : 'failed'), 'domain', 
			'order');
		return TRUE;
	}

	public function templatePush($data)
	{ 
		$domainArray = explode(',', $data->domain);
		$tempInfo = $this->templateMod->getTemplate(array('TemplateName' => $data->tempname,'EnameId'=>$data->enameId));
		$islock = $data->islock;
		if(!$tempInfo)
		{
			throw new \Exception("模板不存在！", 330034);
		}
		foreach($domainArray as $key => $domain)
		{
			$domainInfo = $this->dnManageLib->getDomainInfo(array('DomainName' => $data->domain));
			if(!$domainInfo || $domainInfo['EnameId'] != $data->enameId)
			{
				$result[$key]['status'] = false;
				$result[$key]['msg'] = !$domainInfo ? '域名不存在' : '域名无权操作！';
				$result[$key]['domain'] = $domain;
				continue;
			}
			try
			{
				if(\lib\manage\common\DomainFunLib::isChinaDomain($domainInfo['DomainName']) &&
					 !\lib\manage\common\DomainFunLib::isWangluoDomain($domainInfo['DomainName'])) // CN域名维护临时关闭2014-05-10
				{
					\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck(); // CN域名维护临时关闭2014-05-10
				}
				$this->checkDomainHoldStatus($domainInfo);
				$this->checkDomainAllowTemplatePush($domainInfo);
			}
			catch(\Exception $e)
			{
				$result[$key]['status'] = false;
				$result[$key]['msg'] = $e->getMessage();
				$result[$key]['domain'] = $domain;
				continue;
			}
			// 隐私模板过户
			if($tempInfo[0]['TemplateType'] == 6 || $tempInfo[0]['TemplateType'] == 7)
			{
				$result[$key]['status'] = $this->privacyTemplatePushLogic(
					array('domain' => $domain, 'templateId' => $tempInfo[0]['TemplateId'], 'islock'=>$islock,
						'enameId' => $domainInfo['EnameId'], 'registrarId' => $domainInfo['RegistrarId'], 
						'templateName' => $data->tempname));
			}
			else
			{
				$result[$key]['status'] = $this->templatePushLogic(
					array('domain' => $domain, 'templateId' => $tempInfo[0]['TemplateId'], 'islock'=>$islock,
						'oldTemplateId' => $domainInfo['TemplateId'], 'registrarId' => $domainInfo['RegistrarId'], 
						'newTemplateName' => $tempInfo[0]['TempUserName'], 'tempType' => $tempInfo[0]['TemplateType'], 
						'oldTemplateName' => $domainInfo['TempUserName'], 'enameId' => $domainInfo['EnameId']));
			}
			$result[$key]['msg'] = $result[$key]['status'] ? '操作成功' : '操作失败';
			$result[$key]['domain'] = $domain;
		}
		return $result;
	}

	public function templatePushByQueue($data)
	{
		if(\common\Common::getRequestUser() == 'api' && \common\Common::getAppVersion() <= '3.4.5') // app 3.4.5后获取可用模板
		{
			throw new \Exception("您好，因icann新政调整，需升级到V4.0版，以便恢复业务。请前往官网下载最新版。");
		}
		$configs = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$provisionalId = $configs->template->temp->id;
		$domainAll = $this->checkTemplatePushDomainStatus($data->domain);
		$islock = $data->islock;
		foreach($domainAll as $k => $v)
		{
			if($k == 'cn')
			{
				continue;
			}
			foreach($v as $k1 => $tempDomain)
			{
				if(!$tempDomain['status'])
				{
					unset($domainAll[$k][$k1]);
				}
			}
		}
	
		$cnDomain = empty($domainAll['cnDomain']) ? array() : $domainAll['cnDomain'];
		$cnTempId = $data->cnTempId;
		if(count($cnDomain) > 300) // 最多允许批量操作300个域名
		{
			throw new \Exception('一次最多允许批量操作300个域名', 330033);
		}
		DomainOpenLib::domainOpenCN($cnDomain, 'temppush'); // CN域名维护临时关闭2014-05-10
		$queueArray = array();
		$lockDomains = array();
		foreach($cnDomain as $k => $domains)
		{
			$domain = $domains['domain'];
			if($cnTempId == $provisionalId)
			{
				continue; // 模板id为临时模板时忽略，不加入push队列
			}
			$tempInfo = $this->templateMod->getTemplate(array('TemplateId' => $cnTempId));
			if(!$tempInfo)
			{
				throw new \Exception("模板不存在！", 330034);
			}
			$tempInfo = $tempInfo[0];
			if($tempInfo['EnameId'] != $this->enameId)
			{
				throw new \Exception("模板无权操作！", 330035);
			}
			// 非白名单模板可以过户域名 2015.05.21
			// if(DomainFunLib::isChinaDomain($domain) && $tempInfo['CnStatus'] != 2)
			// {
			// throw new \Exception($tempInfo['TempUserName'].' 的模板暂时还不能接收CN域名，等待通过白名单审核',330036);
			// }
			$info = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain, 'EnameId' => $this->enameId));
			$queueArray[$k]['domain'] = $domain;
			$queueArray[$k]['templateId'] = $cnTempId;
			$queueArray[$k]['oldTemplateId'] = $info['TemplateId'];
			$queueArray[$k]['newTemplateName'] = $tempInfo['TempUserName'];
			$queueArray[$k]['oldTemplateName'] = $info['TempUserName'];
			$queueArray[$k]['registrarId'] = $info['RegistrarId'];
			$queueArray[$k]['tempType'] = $tempInfo['TemplateType'];
			array_push($lockDomains, $domain);
		}
		if(empty($queueArray))
		{
			return array('flag' => false, 'msg' => '域名有误');
		}
		try
		{
			$queueLib = new \logic\manage\newqueue\QueueLogic();
			$result = $queueLib->addQueueTask(
				array('Function' => 'template_push', 'EnameId' => $this->enameId, 'Data' => $queueArray, 
					'Priority' => 3));
			if($islock ==2)
			{
				$this->addDomainLockInfo($lockDomains,$this->enameId,'templatepush');
				unset($lockDomains);
			}
			return array('flag' => true, 'msg' => '模板过户的任务已经加入队列,等待队列执行！');
		}
		catch(\Exception $e)
		{
			DomainLogsLib::addDomainService($domain, 
				array('memo' => 'trans_in_temp_push', 'param' => $data, 'res' => $e->getMessage()), 35);
			return array('flag' => false, 'msg' => '系统发生错误，加入队列失败，请稍后重试！');
		}
	}

	/**
	 * 检测需要模板过户的条件是否完整
	 *
	 * @param array $cnDomain
	 * @param array $enDomain
	 * @param int $enTemp
	 * @param int $cnTemp
	 */
	public function checkTemplatePushDomain($cnDomain, $cnTempId)
	{
		if(empty($cnDomain))
		{
			throw new \Exception('请输入需要模板过户的域名', 330029);
		}
		if(\lib\manage\common\DomainFunLib::isChinaDomain($cnDomain) &&
			 !\lib\manage\common\DomainFunLib::isWangluoDomain($cnDomain)) // CN域名维护临时关闭2014-05-10
		{
			\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck(); // CN域名维护临时关闭2014-05-10
		}
		if(empty($cnTempId))
		{
			throw new \Exception('请选择对应的模板', 330032);
		}
		return TRUE;
	}

	public function checkDomainHoldStatus($domainInfo, $throw = TRUE)
	{
		if($domainInfo['DomainMyStatus'] != 7 && $domainInfo['DomainMyStatus'] != 9)
		{
			return TRUE;
		}
		if($throw)
		{
			$message = $domainInfo['DomainMyStatus'] == 7 ? '域名状态错误，无法操作' : '操作失败，请联系客服';
			throw new \Exception($message, 311013);
		}
		return FALSE;
	}

	public function checkDomainAllowTemplatePush($info, $throwDomain = true)
	{
		$domainName = $throwDomain ? $info['DomainName'] : '';
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'vspdomainltd');
		$shimingDomainLtd = $conf->domainltd->toArray();
		if(time() > strtotime($info['ExpDate']))
		{
			if(!\lib\manage\common\DomainFunLib::checkIsVspDomainLtd($info['DomainName']))
			{
				throw new \Exception($domainName . '域名已经过期 非com/net域名过期后不能模板过户!', 330024);
			}
		}
		else
		{
		   if($info['DomainHoldStatus'] == 2)
			{
				throw new \Exception($domainName . '域名的状态错误，不能模板过户!', 330025);
			}
		}
		if(($info['DomainMyStatus'] > 1 && $info['DomainMyStatus'] != 13 && $info['DomainMyStatus'] != 14))
		{
			throw new \Exception($domainName . '域名的状态错误，不能模板过户!', 330025);
		}
		if(($info['DomainProperty'] == 4 || $info['DomainProperty'] == 6) && $info['ClassName'] == 1)
		{
			throw new \Exception($domainName . '腾讯邮箱域名，不能模板过户!', 330027);
		}
		if(($info['DomainProperty'] == 8) && (time() - strtotime($info['RegDate']) < 8 * 3600 * 24))
		{
			throw new \Exception($domainName . '是姓名域名，八天内不能模板过户!', 330028);
		}
	}

	/**
	 * 隐私模板过户
	 */
	public function privacyTemplatePushLogic($data, $domainInfo = FALSE)
	{
		$domain = isset($data['domain']) ? $data['domain'] : '';
		$templateId = isset($data['templateId']) ? $data['templateId'] : '';
		$registrarId = isset($data['registrarId']) ? $data['registrarId'] : '';
		$enameId = isset($data['enameId']) ? $data['enameId'] : 0;
		if($domain && $templateId)
		{
			$dnLib = new \lib\manage\domain\DomainManageLib();
			if(!$domainInfo)
			{
				$dnInfo = $dnLib->getDomainInfo(array('DomainName' => $domain));
				if(!$dnInfo)
				{
					return FALSE;
				}
			}
			include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
			$sdk = new \ApiSdk();
			$tempData = array('domain' => $domain, 'templateId' => $templateId, 'registrarID' => $registrarId);
			$apiInfo = $sdk->execSdkFun(5011, $tempData);
			DomainLogsLib::addDomainService($domain, array('memo' => 'template_push', 'param' => $tempData, 'rs' => $apiInfo), 17);
			$pushOk = false;
			if($apiInfo['resultCode'] == 5000)
			{
				$pushOk = true;
			}
			else
			{
		   	$domainInfo = $sdk->execSdkFun(5025, array('domain' => $domain, 'registrarID' => $registrarId));
				$lib = new \lib\manage\domain\TemplateLib();
				$templateInfo = $lib->getTempInfo($templateId);
				if(isset($domainInfo['data']['registrant']) &&
					 strtoupper($domainInfo['data']['registrant']) == strtoupper($templateInfo['TemplateName']))
				{
					$pushOk = true;
				}
			}
			if($pushOk)
			{
				$this->dnManageLib->setDomainInfo(array('DomainName' => $domain), array('PrivacyTemp' => $templateId));
			}
			return $pushOk;
		}
	}

	/**
	 * 普通模板过户
	 */
	public function templatePushLogic($data)
	{
		$domain = isset($data['domain']) ? $data['domain'] : '';
		$templateId = isset($data['templateId']) ? $data['templateId'] : '';
		$oldTemplate = isset($data['oldTemplateId']) ? $data['oldTemplateId'] : '';
		$registrarId = isset($data['registrarId']) ? $data['registrarId'] : '';
		$tempUserName = isset($data['newTemplateName']) ? $data['newTemplateName'] : '';
		$tempType = isset($data['tempType']) ? $data['tempType'] : 0;
		$oldTempUserName = isset($data['oldTemplateName']) ? $data['oldTemplateName'] : '';
		$enameId = isset($data['enameId']) ? $data['enameId'] : 0;
		$islock = isset($data['islock']) ? $data['islock'] : 1;
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		if($domain && $templateId && $tempUserName)
		{
			$tempData = array('domain' => $domain, 'templateId' => $templateId, 'registrarID' => $registrarId);
			$domainLtd = DomainFunLib::getDomainClass($domain);
			$tempLib = new \lib\manage\domain\TemplateLib();
			$tempInfo = $tempLib->getTempInfo($templateId);
			// 判断域名是否有设置隐私保护,如果有判断模板是否为白名单，如果不是则取消隐私保护，反之直接修改域名的模版ID
			$dnBaseInfo = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain, 'EnameId' => $enameId));
			if($dnBaseInfo['PrivacyTemp'])
			{
				if(FALSE == \lib\manage\common\DomainFunLib::isChinaDomain($domain) || $tempInfo['CnStatus'] == 2)
				{
					$this->dnManageLib->setDomainInfo(array('DomainId' => $dnBaseInfo['DomainId']), 
						array('TemplateId' => $templateId, 'TempUserName' => $tempUserName));
					return TRUE;
				}
			}
			
			if($domainLtd == "ASIA") // asia后缀可以多添加两个参数
			{
				$tempData['chg_extension'] = array('opnContact' => $tempInfo['TemplateName'], 
					'maintainerUrl' => 'www.ename.net');
			}
			$apiInfo = $sdk->execSdkFun(5011, $tempData);
			DomainLogsLib::addDomainService($domain, 
				array('memo' => 'template_push', 'param' => $tempData, 'rs' => $apiInfo), 17);
			$pushOk = false;
			if($apiInfo['resultCode'] == 5000)
			{
				$pushOk = true;
			}
			else
			{
				$domainInfo = $sdk->execSdkFun(5025, array('domain' => $domain, 'registrarID' => $registrarId));
				if($domainInfo['resultCode'] == 5000)
				{
					if(strtoupper($domainInfo['data']['registrant']) == strtoupper($tempInfo['TemplateName']))
					{
						$pushOk = true;
					}
				}
			}
			if($pushOk)
			{
				$tempType = $tempInfo['TemplateType'];
				$this->successAction($domain, $enameId, $oldTempUserName, $templateId, $tempUserName, $tempType);
				$tempLib->setTempDomainCount($tempInfo['TemplateId']);
				if($oldTemplate)
				{
					$oldtempInfo = $tempLib->getTempInfo($oldTemplate);
					if($oldtempInfo)
					{
						$tempLib->setTempDomainCount($tempInfo['TemplateId'], '-');
					}
				}
				if($islock == 2)
				{
					$dnlogic = new \logic\manage\domain\DomainManageLogic();
					$dnlogic->addDomainLockInfo(array($domain), $enameId, "templatepush");
				}
			}
			return $pushOk;
		}
		return FALSE;
	}

	/**
	 * 域名模板过户前验证域名状态
	 */
	public function checkTemplatePushDomainStatus($domains)
	{
		$cnDomain = array();
		$domainArr = explode(',', $domains);
		$domainArr = array_unique($domainArr);
		$checkLoks = array();
		foreach($domainArr as $k => $domain)
		{ 
			$domain = trim($domain);
			if(!DomainFunLib::isOkDomain($domain))
			{
				$cnDomain[] = array('domain' => $domain, 'status' => false, 'msg' => '域名格式错误，不能模板过户','islock'=>0);
				continue;
			}
			$info = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain, 'EnameId' => $this->enameId));
			if(!$info)
			{
				$cnDomain[] = array('domain' => $domain, 'status' => false, 'msg' => '不是您的域名，不能模板过户','islock'=>0);
				continue;
			}
			try
			{
				if(\lib\manage\common\DomainFunLib::isChinaDomain($info['DomainName']) &&
					 !\lib\manage\common\DomainFunLib::isWangluoDomain($info['DomainName'])) // CN域名维护临时关闭2014-05-10
				{
					\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck(); // CN域名维护临时关闭2014-05-10
				}
				$this->checkDomainHoldStatus($info);
				$this->checkDomainAllowTemplatePush($info, true);
			}
			catch(\Exception $e)
			{
				$cnDomain[] = array('domain' => $domain, 'status' => false, 'msg' => $e->getMessage(),'islock'=>0);
				continue;
			}
			array_push($checkLoks,$domain);
			$cnDomain[] = array('domain' => $domain, 'status' => true, 'msg' => '','islock'=>0);
		}
		$tempmod = new \models\manage\domain\TemplateMod();
		$tempinfo = $tempmod->getTemplate(array('EnameId' => $this->enameId, 'IsShow' => 1 ,'CnStatus'=>2 ), false, ' TemplateId desc', 
			'TemplateId,TempUserName,CnStatus,TemplateType');
		$cn = array();
		if($tempinfo)
		{
			foreach($tempinfo as $v)
			{
				if($v['TemplateType'] == 1 || $v['TemplateType'] == 3 || $v['TemplateType'] == 4)
				{
					$cn[] = $v;
				}
			}
		}
		$defalttempinfo = array();
		if(empty($cn))
		{
			$configs = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
			$provisionalId = $configs->template->temp->id;
			$defalttempinfo = $tempmod->getTemplate(array('TemplateId' => $provisionalId), '', '', 
				'TemplateId,TempUserName,TemplateType');
			foreach($defalttempinfo as $v)
			{
				$cn[] = $v;
			}
		}
		$cnDomain = self::arrayOrder($cnDomain);
		if($checkLoks)
		{
			$return = $this->checkDomainIsLock($checkLoks);
			foreach($cnDomain as $key=>$value)
			{
				$cnDomain[$key]['islock'] = isset($return[$value['domain']]) ? $return[$value['domain']] :0;
			}
		}
		return array('cnDomain' => $cnDomain, 'cn' => $cn);
	}
	
	// 批量模板过户,批量设置dns返回域名信息排序
	private function arrayOrder($array)
	{
		if(!is_array($array))
		{
			return $array;
		}
		$arrayNew = array();
		foreach($array as $k => $v)
		{
			if(!$v['status'])
			{
				$arrayNew[] = $array[$k];
				unset($array[$k]);
			}
		}
		return array_merge_recursive($arrayNew, $array);
	}

	private function successAction($domain, $enameId, $oldTempUserName, $templateId, $tempUserName, $tempType)
	{
		$set = array('TemplateId' => $templateId, 'TempUserName' => $tempUserName);
		if($tempType != 6 && $tempType != 7) // 如果新模板不是隐私模板，取消域名隐私保护
		{
			$set['PrivacyTemp'] = 0;
		}
		$this->dnManageLib->setDomainInfo(array('DomainName' => $domain), $set);
		if($tempType)
		{
			$domainInfo = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain));
			$this->dnManageLib->setDomainExtInfo(array('DomainId' => $domainInfo['DomainId']), 
				array('TemplateType' => $tempType));
		}
	}

	/**
	 * 批量设置域名分组
	 */
	public function setDomainsGroup($info)
	{
		$domains = explode(',', $info->domain);
		$groupId = empty($info->groupId) ? '' : $info->groupId;
		$groupId = ($groupId == '-1') ? 0 : $groupId;
		$domainarr = array();
		$dnMod = new \models\manage\domain\DomainsMod();
		foreach($domains as $domain)
		{
			$domaininfo = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain, 'EnameId' => $info->enameId));
			if($domaininfo['DomainGroup'])
			{
				$this->dnManageLib->setGroupCount($domaininfo['DomainGroup'], false);
			}
			$res = $dnMod->upDomainInfo(array('DomainId' => $domaininfo['DomainId']), 
				array('DomainGroup' => $groupId),FALSE,FALSE);
			if(!$res)
			{
				\core\Log::write('更新域名分组信息失败,域名:' . $domaininfo['DomainName'] . '分组ID:' . $groupId, 'domain', 
					'domaingroup');
				$domainarr[] = array('domain' => $domain, 'status' => 0, 'msg' => '更新域名分组信息失败');
			}
			else
			{
				$mod = new \models\manage\domain\DomainLogsMod();
				$mod->addOperationLog($domaininfo['DomainName'], $info->enameId, '更改了域名的分组', 7, '', 0, 
					\common\Common::getRequestIp());
				$rs = $this->dnManageLib->setGroupCount($groupId);
				if($rs)
				{
					$domainarr[] = array('domain' => $domain, 'status' => 1);
				}
				else
				{
					$domainarr[] = array('domain' => $domain, 'status' => 0, 'msg' => '更新域名统计失败');
				}
			}
		}
		return $domainarr;
	}

	/**
	 * 获取域名备注
	 */
	public function getDomainRemarks($domain, $serviceType)
	{
		$mod = new \models\manage\domain\DomainServiceMod();
		$where = array('Domain' => $domain, 'ServiceType' => $serviceType);
		$remarksCount = 0;
		$totalCount = $mod->getDomainService($where, "count(1) as total");
		if($totalCount)
		{
			$remarksCount = $totalCount[0]['total'];
			$cYear = date('Y') - 1;
			for($cYear; $cYear > 2012; $cYear--)
			{
				if($cYear == 2014)
				{
					continue;
				}
				$where['year'] = $cYear;
				$totalHistory = $mod->getDomainService($where, "count(1) as total");
				$remarksCount += $totalHistory ? $totalHistory[0]['total'] : 0;
			}
		}
		return $remarksCount;
	}

	public function setPrivacy($data)
	{
		$enameId = $data->enameId;
		// 判断用户是否添加了隐私保护邮箱
		$tempMod = new \models\manage\domain\TemplateMod();
		$privacyTempCn = $tempMod->getTemplate(array('EnameId' => $enameId, 'IsShow' => 1, 'TemplateType' => 7), '0,1', 
			' TemplateId DESC ');
		if(!($privacyTempCn && !empty($privacyTempCn[0]['TemplateId'])))
		{
			throw new \Exception('设置失败，你还没有添加隐私保护邮箱!<a href="http://www.ename.net/template/privacytemp">点击这里添加</a>', 
				322058);
		}
		$privacyTempCn = $privacyTempCn[0];
		$domains = trim($data->domains);
		$domainArr = explode("\n", $domains);
		$domainArr = array_unique($domainArr);
		$domainArr = array_filter($domainArr);
		$isPrivacy = $data->isPrivacy;
		$unStr = array();
		$msg = '';
		$othermsg = array();
		$successDomain=array(); // 操作成功的域名
		if(count($domainArr) > 100)
		{
			throw new \Exception("最多允许批量操作100个域名", 322051);
		}
		$islock = $data->islock;
		$fromWhere = 1;
		if(\common\Common::getRequestUser() == 'api')
		{
			$fromWhere = 2;
		}
		foreach($domainArr as $domain)
		{ 
			$domain = trim($domain);
			$str = \lib\manage\common\DomainFunLib::getDomainClass($domain);
			if(!\lib\manage\common\DomainFunLib::isChinaDomain($domain) && $str != 'COM' && $str != 'NET' &&
				 $str != 'TOP' && $str != 'WANG')
			{
				$unStr[$str] = $str;
				continue;
			}
			$domainInfo = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain, 'EnameId' => $enameId));
			if(empty($domainInfo))
			{
				throw new \Exception($domain."查找域名信息失败", 359003);
			}
			if(!empty($domainInfo) && !empty($domainInfo['PrivacyTemp']) && $isPrivacy == 1)
			{
				$successDomain[]=$domain;
				continue;
			}
			if(!empty($domainInfo) && empty($domainInfo['PrivacyTemp']) && !$isPrivacy)
			{
				$successDomain[]=$domain;
				continue;
			}
			if($isPrivacy == 1)
			{
				try
				{
					$this->checkDomainTemplate($domain, $enameId, $domainInfo);
				}
				catch(\Exception $e)
				{
					$msg .= sprintf($e->getMessage(), $domain) . '<br/>';
					$othermsg[] = array('msg' => $e->getMessage(), 'code' => $e->getCode(), 'domain' => $domain);
					continue;
				}
				$result = $this->openPrivacy($domainInfo, $privacyTempCn,$islock);
			}
			else
			{
				$result = $this->cancelPrivacy($domainInfo);
			}
			if($result !== true)
			{
				$msg .= sprintf($result['msg'], $domain) . '<br/>';
				$othermsg[] = array('msg' => $result['msg'], 'code' => $result['code'], 'domain' => $domain);
				continue;
			}
			$successDomain[] = $domain;
		}
		if(!empty($unStr))
		{
			$msg .= implode(',', $unStr) . '域名不支持隐私保护';
			$othermsg[] = array('msg' => '%域名不支持隐私保护', 'code' => 322067, 'domain' => implode(',', $unStr));
		}
		return array('successDomain'=>$successDomain,'successNum' => count($successDomain), 'errMsg' => $msg, 'othermsg' => $othermsg);
	}

	public function checkDomainTemplate($domain, $enameId, $domainInfo)
	{
		$checkDomainTempResult = $this->dnManageLib->checkDomainTemp($domain, $enameId, $domainInfo);
		if($checkDomainTempResult === 2)
		{
			throw new \Exception('%s域名使用临时模版，无法设置隐私保护，请先<a href="http://www.ename.net/template/chinatemp">添加模版</a>', 
				322059); // 域名使用临时模版，无法设置隐私保护
		}
		if($checkDomainTempResult === 3 && (DomainFunLib::isChinaDomain($domain) || DomainFunLib::checkIsVspDomainLtd($domain)))
		{
			throw new \Exception(
				'%s域名使用非白名单模版，无法设置隐私保护，请先<a href="http://www.ename.net/template/chinatemp">创建白名单模版</a>', 322061); // 非白名单模版
		} 
		return TRUE; 
	}

	/**
	 * 开启域名隐私保护
	 */
	public function openPrivacy($domainInfo, $privacyTempCn,$islock = false)
	{
		if(strtotime($privacyTempCn["CreateTime"]) <= strtotime('2016-06-16 00:00:00'))
		{
			$logic = new \logic\manage\domain\DomainTemplateLogic();
			$st = $logic->registrantChangeCheck($domainInfo['EnameId'], $domainInfo['DomainName'], 
				$domainInfo['RegistrarId'], $privacyTempCn['TemplateId'], $privacyTempCn);
			if(!$st)
			{
				return array('msg' => '%s模板过户失败，请稍候重试或联系客服处理!', 'code' => '322065');
			}
		}
		if($domainInfo['DomainMyStatus'] == 11 || $domainInfo['DomainMyStatus'] == 12)
		{
			return array('msg' => '%s设置了域名安全锁，不能执行此操作!', 'code' => '322062');
		}
		if($domainInfo['DomainMyStatus'] == 7 || $domainInfo['DomainMyStatus'] == 9)
		{
			return array('msg' => '%s域名被锁定，不能启用隐私保护!', 'code' => '322063');
		}
		$domainExtInfo = $this->dnManageLib->getDomainExt(array('DomainId' => $domainInfo['DomainId']));
		if(!in_array($domainInfo['EnameId'], array(10001, 10666, 350521)) && !empty($domainExtInfo['LastClosePrivacy']) &&
			 (time() - strtotime($domainExtInfo['LastClosePrivacy']) < 7 * 3600))
		{
			return array('msg' => '%s在取消隐私保护后7天内不允许再次设置隐私保护!', 'code' => '322064');
		}
		$pushData = array('domain' => $domainInfo['DomainName'], 'templateId' => $privacyTempCn['TemplateId'], 
			'registrarId' => $domainInfo['RegistrarId'], 'enameId' => $domainInfo['EnameId']); // 向注册局发送模板过户
		$return = $this->privacyTemplatePushLogic($pushData, $domainInfo);
		if($return === true)
		{
			$this->dnManageLib->setDomainInfo(
				array('DomainName' => $domainInfo['DomainName'], 'EnameId' => $domainInfo['EnameId']), 
				array('PrivacyTemp' => $privacyTempCn['TemplateId']));
			\lib\manage\domain\DomainLogsLib::addDomainOperaterLog($domainInfo['DomainName'], $domainInfo['EnameId'], 
				'设置隐私保护', 7);
			if($islock ==2)
			{
				$this->addDomainLockInfo($domainInfo['DomainName'], $domainInfo['EnameId'], "templatepush");
			}
			$from=\common\Common::getRequestUser() == 'api' ? 2 : 1;
			$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'template_push_success'));
			$amqp->sendMq(
				array('time' => time(),'isPrivacy'=>1,'adminId'=>0,'isCancel'=>0 ,'from'=>$from,'isLock'=>$islock ? intval($islock) : 1,'dn' => array($domainInfo['DomainName']), "uid" => intval($domainInfo['EnameId']),
						'ip' => \common\Common::getRequestIp()));
			return true;
		}
		return array('msg' => '%s模板过户失败，请稍候重试或联系客服处理!', 'code' => '322065');
	}

	/**
	 * 取消隐私保护
	 */
	public function cancelPrivacy($domainInfo)
	{
		if($domainInfo['PrivacyTemp'] == 0)
		{
			return true;
		}
		if($domainInfo['DomainMyStatus'] == 11 || $domainInfo['DomainMyStatus'] == 12)
		{
			return array('msg' => '%s设置了域名安全锁，不能执行此操作!', 'code' => '322062');
		}
		if($domainInfo['DomainMyStatus'] == 7 || $domainInfo['DomainMyStatus'] == 9)
		{
			return array('msg' => '%s域名被锁定，不能启用隐私保护!', 'code' => '322063');
		}
		$domainTemplateLib = new \lib\manage\domain\TemplateLib($domainInfo['EnameId']);
		$tempInfo = $domainTemplateLib->checkUserTemplate($domainInfo['TemplateId'], $domainInfo['EnameId'], false);
		if(empty($tempInfo)) // 原来的模版已经不存在了，查询默认模版，没有默认模版，查询符合条件的模版
		{
			$tempInfo = $domainTemplateLib->getUseTemplates($domainInfo['EnameId']);
			$tempInfo = $tempInfo[0];
		}
		if($this->dnManageLib->cancelPrivacy($domainInfo['DomainId'], $domainInfo['EnameId'], $tempInfo['TemplateId'], 
			$tempInfo['TempUserName']))
		{
			$queueArray = array();
			$queueArray[0]['domain'] = $domainInfo['DomainName'];
			$queueArray[0]['templateId'] = $domainInfo['TemplateId'];
			$queueArray[0]['oldTemplateId'] = $domainInfo['PrivacyTemp'];
			$queueArray[0]['newTemplateName'] = $tempInfo['TempUserName'];
			$queueArray[0]['oldTemplateName'] = $domainInfo['EnameId'] . '隐私模板';
			$queueArray[0]['registrarId'] = $domainInfo['RegistrarId'];
			$queueArray[0]['tempType'] = $tempInfo['TemplateType'];
			try
			{
				$queueLib = new \logic\manage\thrift\QueueLogic();
				$result = $queueLib->addQueueTask(
					array('Function' => 'template_push', 'EnameId' => $domainInfo['EnameId'], 'Data' => $queueArray),1);
			}
			catch(\Exception $e)
			{
				DomainLogsLib::addDomainService($domainInfo['DomainName'], 
					array('memo' => 'temp_push', 'param' => $queueArray, 'res' => '取消隐私模板过户加入队列失败'), 17);
			}
			return true;
		}
		return array('msg' => '%s设置失败，网络超时!', 'code' => '322066');
	}

	/**
	 * 合作接口续费转接口
	 */
	public function cooperRegidRenew($enameId, $domain, $orderId = FALSE, $domainInfo = FALSE)
	{
		if(!$domainInfo)
		{
			$domainInfo = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain));
			if(!$domainInfo)
			{
				throw new \Exception("域名信息查找失败");
			}
		}
		$expdate = $domainInfo['ExpDate'];
		$registarId = $domainInfo['RegistrarId'];
		$domainLtd = $domainInfo['DomainLtd'];
		$this->dnManageLib->cooperRegidDomainCheck($domain, $registarId, $expdate, $domainInfo['RegDate'], 
			$domainInfo['DomainMyStatus']);
		return $this->dnManageLib->domainTransferAppMain($domain, $enameId, $registarId, $expdate, $domainLtd, 
			$domainInfo['DomainStatus'], $domainInfo['DomainHoldStatus'], $orderId,$domainInfo['DomainMyStatus']);
	}

	/**
	 * 获取用户域名列表
	 *
	 * @param int $enameId
	 * @param int $limit
	 */
	public function getUserDomainList($params)
	{
		$EnameId = $params['EnameId'];
		$limit = $params['limit'];
		if(!$EnameId || !$limit)
		{
			throw new \Exception("参数错误");
		}
		$where = array('EnameId' => $EnameId);
		$domainGroup = !empty($params['DomainGroup']) ? $params['DomainGroup'] : '';
		$trueDomainGroup = '';
		if(!empty($domainGroup))
		{
			$where['DomainGroup'] = $domainGroup == '-1' ? '0' : $domainGroup;
			$trueDomainGroup = $where['DomainGroup'];
		}
		$count = $this->getDomainCount($EnameId, $trueDomainGroup);
		if($count > 0)
		{
			$domainList = $this->dnManageLib->getDomainList($where, $limit, '', 'DomainName,RegDate,ExpDate');
			return array('data' => $domainList, 'count' => $count);
		}
		return array('data' => array(), 'count' => 0);
	}

	/**
	 * 获取域名信息
	 *
	 * @param array $data
	 * @return boolean|array
	 */
	public function getDomainInfo($data)
	{
		$domainInfo = $this->dnManageLib->getDomainInfo($data, "*", true);
		if(!$domainInfo)
		{
			throw new \Exception("查找域名信息失败", 359003);
		}
		return $domainInfo;
	}
	
	/**
	 * 获取用户域名分组列表 for E+
	 */
	public function getDomainGroupLists($EnameId)
	{
		if(!$EnameId)
		{
			throw new \Exception("参数错误"); 
		}
		$groupList = $this->dnManageLib->getDomainGroupList($EnameId);
	    if($groupList)
	    {
	    	return array('data'=>$groupList);
	    }
		return array('data' => '');
	}
	
	/**
	 * 添加域名到锁定表
	 */
	public function addDomainLockInfo($domains,$uid,$type)
	{
		try
		{
			$domains = is_array($domains) ? $domains : array($domains);
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domainlock');
			$type= $conf->locktype->$type;
			$domainltds = $conf->lockdomains;
			$mod = new \models\manage\domain\DomainLockMod();
			$return = array();
			foreach($domains as $domain)
			{
				if(stripos($domainltds,\lib\manage\common\DomainFunLib::getDomainClass($domain))===false)
				{
					\core\Log::write("域名后缀不合法,$domain", 'domain','domainlockadd_ltderr');
					continue;
				}
				$st = $mod->addLockInfo($domain, $uid, $type);
				if(!$st)
				{
					\core\Log::write("加锁失败,$domain", 'domain','domainlockadd');
				}
				else
				{
					\core\Log::write("加锁成功,$domain", 'domain','domainlockadd');
				}
			}
			return true;			
		}
		catch (\Exception $e)
		{
			\core\Log::write("add lock $type,error,".json_encode($domains), 'domain','domainlockadd_ltderr');
			return false;
		}
	}
	
	/**
	 * 查询域名是否有锁定
	 */
	public function checkDomainIsLock($domains)
	{
		$mod = new \models\manage\domain\DomainLockMod();
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domainlock');
		$domainltds = $conf->lockdomains;
		$check = $return = array();
		foreach($domains as $domain)
		{
			if(stripos($domainltds,\lib\manage\common\DomainFunLib::getDomainClass($domain))===false)
			{
				\core\Log::write("域名后缀不合法,$domain", 'domain','domainlockadd_ltderr');
				$return[$domain] = 0;
				continue;
			}
			$return[$domain] = 0;
			$check[] = $domain;
		}
		if(empty($check))
		{
			return $return;
		}
		$mod = new \models\manage\domain\DomainLockMod();
		$checkInfos = $mod->checkDomainIsLock(array('in'=>array('dl_domain'=>$check)));
		if($checkInfos)
		{
			foreach($checkInfos as $info)
			{
				$days = ceil(($info['dl_out_time'] -time())/86400);
				$return[$info['dl_domain']] = $days>0 ? ($days>60 ? 60 : $days) : 0;
			}
		}
		return $return;
	}
	
	public function setPrivacyNew($data)
	{
		$enameId = $data->enameId;
		// 判断用户是否添加了隐私保护邮箱
		$tempMod = new \models\manage\domain\TemplateMod();
		$privacyTempCn = $tempMod->getTemplate(array('EnameId' => $enameId, 'IsShow' => 1, 'TemplateType' => 7), '0,1',
			' TemplateId DESC ');
		if(!($privacyTempCn && !empty($privacyTempCn[0]['TemplateId'])))
		{
			throw new \Exception('设置失败，你还没有添加隐私保护邮箱!<a href="http://www.ename.net/template/privacytemp">点击这里添加</a>',
				322058);
		}
		$privacyTempCn = $privacyTempCn[0];
		$domainArr = array_filter(array_unique(explode("\n", trim(strtolower($data->domains)))));
		$isPrivacy = $data->isPrivacy;
		$unStr = array();
		$msg = '';
		$othermsg = array();
		$successDomain=array(); // 操作成功的域名
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'privacy');
		$allNum = count($domainArr);
		if($allNum > $conf->maxNum)
		{
			throw new \Exception("最多允许批量操作{$conf->maxNum}个域名", 322051);
		}
		$islock = $data->islock;
		$fromWhere = \common\Common::getRequestUser() == 'api' ? 2 : 1;
		$checkDomains = array();
		foreach($domainArr as &$domain)
		{
			$domain = trim($domain);
			$str = \lib\manage\common\DomainFunLib::getDomainClass($domain);
			if(stripos($conf->domainltd,$str)===false)
			{
				$unStr[] = $str;
				continue;
			}
			$checkDomains[] = $domain;
		}
		if($unStr)
		{
			$msg.=implode(',', array_unique($unStr)) . '域名不支持隐私保护!<br>';
		}
		if(!$checkDomains)
		{
			return array('successDomain'=>0,'successNum' => 0, 'errMsg' => $msg, 'othermsg' => $othermsg);
		}
		$domainListInfo = $this->dnManageLib->getDomainList(array('EnameId'=>$enameId,'in'=>array('DomainName'=>$checkDomains)),"","","DomainName,TemplateId,DomainMyStatus,PrivacyTemp,IsRealName,RegistrarId");
		if(!$domainListInfo)
		{
			throw new \Exception("查找域名信息失败", 359003);
		}
		$checkDomainNew = array();
		$sendDatas = array();
		$checkAllDomain = array();
		foreach($domainListInfo as $domainInfo)
		{
			$domain = $domainInfo['DomainName'];
			$checkAllDomain[] = $domain;
			if($domainInfo['DomainMyStatus'] == 11 || $domainInfo['DomainMyStatus'] == 12 )
			{
				$msg .= "{$domain}设置了域名安全锁，不能执行此操作!" . '<br/>';
				continue;
			}
			if($domainInfo['DomainMyStatus'] == 7 || $domainInfo['DomainMyStatus'] == 9)
			{
				$msg .= "{$domain}域名被锁定，不能启用隐私保护!" . '<br/>';
				continue;
			}
			if($isPrivacy == 1)
			{
				try
				{
					$this->checkDomainTemplate($domain, $enameId, $domainInfo);
				}
				catch(\Exception $e)
				{
					$msg .= sprintf($e->getMessage(), $domain) . '<br/>';
					continue;
				}
			}
			array_push($checkDomainNew, $domain);
			$sendDatas[] = array('domain'=>$domain,'registrarId'=>$domainInfo['RegistrarId'],'isCancel'=>$isPrivacy ? '0' : '1','isLock'=>$islock,'privacyTemplateId'=>$privacyTempCn['TemplateId']);
		}
		$tmp = array_diff($checkDomains,$checkAllDomain);
		if($tmp)
		{
			foreach($tmp as $dn)
			{
				$msg .= "{$dn}域名信息查找失败!" . '<br/>';
			}
		}
		if(!$checkDomainNew)
		{
			return array('successDomain'=>0,'successNum' => 0, 'errMsg' => $msg, 'othermsg' => "");
		}
		$queueLogic = new \logic\manage\thrift\QueueLogic();
		$data = array("Function"=>"privacy_template_push",'EnameId'=>$enameId,'Hidden'=>0,'Priority'=>1,'Data'=>$sendDatas);
		try
		{
			if($queueLogic->addQueueTask($data,$isPrivacy))
			{
				return array('successDomain'=>$checkDomainNew,'successNum' => count($checkDomainNew), 'errMsg' => $msg, 'othermsg' => "");
			}
		}
		catch(\Exception $e)
		{
			return array('successDomain'=>0,'successNum' => 0, 'errMsg' => "加入队列失败", 'othermsg' => "");
		}
		return array('successDomain'=>0,'successNum' => 0, 'errMsg' => "加入队列失败", 'othermsg' => "");
	}	
	
	
}

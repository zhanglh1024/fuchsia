<?php
namespace logic\manage\domain;
use common\Common;
use core\Response;
use core\form\ReturnData;

class TransferOutLogic
{
	private $config;
	private $enameId;
	private $domainTransferLib;
	private $domainTransferOutLib;
	function __construct($enameId = 0)
	{
		$this->config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$this->enameId = $enameId;
		$this->domainTransferLib = new \lib\manage\domain\DomainTransferLib($this->enameId);
		$this->domainTransferOutLib = new \lib\manage\domain\DomainTransferOutLib($this->enameId);
	}
	/**
	 * 域名转出列表
	 */
	public function transferOutList($data)
	{
		$where['EnameId'] = intval($this->enameId);
		$totalRows = $this->domainTransferOutLib->getTransferOutCount($where); //记录条数
		if($totalRows)
		{
			$pagesize = $data->pagesize ? intval($data->pagesize) : $this->config->domain->transfer->pagesize;
			$p = $data->pagenum ? intval($data->pagenum) - 1 : 0;
			$offset = $p * $pagesize;
			$limit = $offset . ',' . $pagesize;
			$info = $this->domainTransferOutLib->getTransferOutList($where, 'TransferOutId desc', $limit);
			$list = $info ? $info : array();
			$transferStatus = $this->config->domain->transfer->out->status->toArray();
			$tipway = $this->config->domain->transfer->out->tipway->toArray();
			$list = $this->domainTransferLib->actionTranferoutList($list, $transferStatus, $tipway);
			$list = $this->domainTransferLib->getInSevenDomain($list);
			return array('flag' => 1,
					'msg' => array('count' => $totalRows, 'data' => $list, 'pagenum' => $data->pagenum));
		}
		return array('flag' => 1, 'msg' => array('data' => array(), 'pagenum' => 1, 'count' => 0));
	}
	/**
	 * 域名转出确认
	 */
	public function transferOutCheck($info)
	{
		if(\common\Common::getRequestUser() == 'api' && \common\Common::getAppVersion() <= '3.4.5') // app 3.4.5后获取可用模板
		{
			throw new \Exception("您好，因icann新政调整，需升级到V4.0版，以便恢复业务。请前往官网下载最新版。");
		}
		$memberlib = new \lib\manage\member\MemberLib();
		if(!$memberlib->IsGetTransferByMobile($this->enameId))
		{
			throw new \Exception('您还未开通在线获取域名密码的服务!', 321001);
		}
		$domainNames = trim($info->domainNames);
		$domainNames = str_replace("\n", ',', $domainNames);
		$domainNames = explode(',', $domainNames);
		$domainNames = array_unique($domainNames);
		$domainMail = $this->domainTransferLib->domainTransferOutCheck($domainNames, 3);
		$flag = true;
		$return = '';
		if($domainMail)
		{
			foreach($domainMail as $key => $val)
			{
				if($val['errMsg'] != '')
				{
					$flag = false;
					$return .= $val['errMsg'];
				}
			}
		}
		if($info->plat == 2)
		{
			$return = array();
			$return = $domainMail;
		}
		if(!$flag)
		{
			Response::setErrMsg('321025', $return);
		}
		return array('flag' => $flag, 'msg' => $return);
	}
	public function setTransferOut($info)
	{
		$memberlib = new \lib\manage\member\MemberLib();
		if(!$memberlib->IsGetTransferByMobile($this->enameId))
		{
			throw new \Exception('您还未开通在线获取域名密码的服务!', 321001);
		}
		$userLogic = new \logic\manage\member\OperateLogic();
		$userLogic->checkOperate($info);
		$domainNames = trim($info->domainNames);
		$tipWay = $info->tipWay;
		$this->domainTransferLib->domainTransferOut($domainNames, $tipWay);
		return array('flag' => 1, 'msg' => '提交域名转出成功！');
	}
	public function transferOutCanel($info)
	{
		$transeroutmod = new \models\manage\domain\DomainTransferOutMod();
		$transferOutId = $info->transferOutId;
		$transferInfo = $transeroutmod->getTransferInfo(array('TransferOutId' => $transferOutId), '', '', true);
		if($transferInfo && $transferInfo['EnameId'] == $this->enameId && $transferInfo['Status'] < 2)
		{
			//取消转出的先判断域名是否已经转出了
			try
			{
				$domainModule = new \lib\manage\domain\DomainManageLib();
				$domainInfo = $domainModule->checkDomainInfo($transferInfo['DomainName'],$this->enameId);
			}
			catch(\Exception $e)
			{
				//数据库不存在的域名直接设置转出成功
				$transeroutmod->editTransferOut(array('TransferOutId' => $transferOutId), array('status' => '2',
						'UpdateTime' => date("Y-m-d H:i:s")));
				throw new \Exception('域名已经转出，不能取消', 321020);
			}

			if(\lib\manage\common\DomainFunLib::isChinaDomain($transferInfo['DomainName']))
			{
				\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck();//CN域名维护临时关闭2014-05-10
			}

			//从注册局读取信息
			$epplib = new \lib\manage\domain\DomainEppLib();
			$regInfo = $epplib->getDomainRegInfo($transferInfo['DomainName'], $domainInfo['RegistrarId']);
			if(!$regInfo)
			{
				throw new \Exception('获取域名信息失败,取消转出失败!', 321021);
			}
			if(stripos($regInfo['status'], 'pending') !== FALSE)//调用接口拒绝转出
			{
				$param = array('domain' => $domainInfo['DomainName'], 'registrarID' => $domainInfo['RegistrarId']);
				$cancelInfo = $epplib->refuseTransferOutDomain($domainInfo['DomainName'], $domainInfo['RegistrarId']);
				if(!$cancelInfo)
				{
					throw new \Exception('取消域名转出发生错误，请稍后重试!', 321022);
				}
			}
			$info = $transeroutmod->editTransferOut(array('transferOutId' => $transferOutId), array('status' => '4',
					'UpdateTime' => date("Y-m-d H:i:s")));
			if(!$info)
			{
				throw new \Exception('取消域名转出发生错误，请稍后重试!', 321022);
			}
			$this->domainTransferLib->cancelDomainTransferOutSetStatus($domainInfo);
			$mod = new \models\manage\domain\DomainLogsMod();
			$mod->addOperationLog($domainInfo['DomainName'], $this->enameId, '取消域名转出', 4, '', 0, \common\Common::getRequestIp());
			return array('flag' => 1, 'msg' => '取消域名转出成功');
		}
		throw new \Exception('错误的域名转出请求!', 321023);
	}

	/**
	 * 域名转出确认逻辑
	 * @throws Exception
	 */
	public function transferOutVerifyLogic($info)
	{
		$epplib = new \lib\manage\domain\DomainEppLib();
		$transeroutmod = new \models\manage\domain\DomainTransferOutMod();
		$transferId = $info->transferOutId;
		$md5Password = $info->md5;
		if(md5($this->enameId . '/' . $transferId) != $md5Password)
		{
			throw new \Exception('链接地址有误,无法显示信息!', 321024);
		}
		$transferInfo = $transeroutmod->getTransferInfo(array('TransferOutId' => $transferId), '', '', true);
		if(!$transferInfo)
		{
			throw new \Exception('系统查询转出信息失败!', 321025);
		}
		if($transferInfo['Status'] != 1 || $transferInfo['ClickIp'] != '0.0.0.0')
		{
			throw new \Exception('该转出请求已处理,不能重复操作', 321026);
		}
		$domain = $transferInfo['DomainName'];
		if(\lib\manage\common\DomainFunLib::isChinaDomain($domain))
		{
			\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck();//CN域名维护临时关闭2014-05-10
		}
		$domainModule = new \lib\manage\domain\DomainManageLib();
		$domainInfo = $domainModule->getDomainInfo(array('DomainName' => $domain));
		if(!$domainInfo)
		{
			throw new \Exception('系统查询域名信息失败!', 321027);
		}
		if($this->domainTransferLib->checkDomainInSeven($domain))
		{
			throw new \Exception('您的域名7天内有过转移，转出不能立即放出', 321028);
		}
		$registrarId = $domainInfo['RegistrarId'];
		$info = $epplib->getDomainRegTransInfo($domain,$registrarId);
		if(!$info|| (isset($info['status']) && strtoupper($info['status']) != 'PENDING'))
		{
			throw new \Exception('域名不是转移状态,请到注册商成功申请转入后再来同意转出', 321029);
		}
		
		$info = $epplib->transferOutDomain($domain,$registrarId,$this->enameId);
		if(!$info)
		{
			throw new \Exception('查询错误，请重试或联系客服', 321030);
		}
		//修改点击(同意转出)时间和点击Ip
		$set = array('ClickIp' => \common\Common::getRequestIp(), 'ClickTime' => date('Y-m-d H:i:s'),'UpdateTime'=>date('Y-m-d H:i:s'), 'Status' => 2);
		$info = $transeroutmod->editTransferOut(array('transferOutId' => $transferId), $set);
		$result = $this->domainTransferLib->setDomainTransferOutSuccess($domain);
		if($result)
		{
			return array('flag' => 1, 'msg' => '同意转出 操作成功！');
		}
		else
		{
			throw new \Exception('域名正在转出', 321031);
		}
	}
}

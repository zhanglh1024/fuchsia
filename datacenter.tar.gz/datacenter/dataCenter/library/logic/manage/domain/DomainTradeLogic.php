<?php
namespace logic\manage\domain;

use core\Response;
use \lib\manage\common\DomainFunLib;
use \lib\manage\common\DomainOpenLib;
use lib\manage\domain\DomainLogsLib;
use core\ModBase;
class DomainTradeLogic
{

	private $domainPushLib;

	private $conf;

	private $dnManageLib;

	function __construct()
	{
		$this->domainPushLib = new \lib\manage\domain\DomainPushLib();
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$this->dnManageLib = new \lib\manage\domain\DomainManageLib();
	}
 
	/**
	 * 更新域名状态(交易) 0602
	 *
	 * @param string $domain
	 * @param int $status 1下架(正常状态) 2交易 3经纪中介
	 * @return boolean
	 */ 
	public function setDomainMyStatus($domain, $status)
	{
		$status = intval($status); 
		if($status < 4) 
		{ 
			$time = time();
			$rs = $this->domainPushLib->domainAddToSale($domain, $status);
			$domainList = is_array($domain) ? $domain : array($domain);
			\core\Log::write('sale domain cout:' . count($domainList) . ',sale time:' . (time() - $time) . "s", $this->conf->domain->logFolder, 'domainTrade');
			return $rs;
		}
		$domain = is_array($domain) ? json_encode($domain) : $domain;
		\core\Log::write($domain . ',' . $status, 'domain', 'domainTradeTime');
		Response::setErrMsg(300018, "域名状态有误");
		return FALSE;
	}

	/**
	 * 域名PUSH 0603
	 *
	 * @param string|array $domains
	 * @param int $oldId
	 * @param int $newId
	 * @return boolean
	 */
	public function domainPush($domains, $oldId, $newId, $isNewInter = FALSE,$islock = FALSE)
	{
		try
		{
			$time = time();
			$oldId = intval($oldId);
			$newId = intval($newId);
			$domains = is_array($domains) ? $domains : array($domains);
			if(empty($domains) || empty($oldId) || empty($newId))
			{
				throw new \Exception('域名PUSH参数不能为空', 322011);
			}
			$params = array('in' => array('DomainName' => $domains, 'EnameId' => array($oldId, 623787, 70000)));
			$domainList = $this->dnManageLib->getDomainList($params);
			if(empty($domainList))
			{
				throw new \Exception(implode(',',$domains).'域名查询失败', 322010);
			}
			$countArr = array();
			foreach($domainList as $domainInfo)
			{
				if(!in_array($oldId, array(667792, 623787, 70000)))//判断域名注册是否未满9天
				{
					if(FALSE == DomainFunLib::checkDomainRegdate($domainInfo['DomainName'],$domainInfo['RegDate'], $domainInfo['ExpDate']))
					{
						throw new \Exception(Response::$errMsg, Response::$errCode);
					}
				}
				if(FALSE == $this->domainPushLib->checkDomainPushStatus($isNewInter, $domainInfo))//新交易$isNewInter=true，状态2,3;旧交易 只能为1,不然报错
				{
					throw new \Exception($domainInfo['DomainName'].'域名状态错误，不能申请过户', 322010);
				}
				array_push($countArr,$domainInfo['DomainName']);
			} 
			// 域名查询数据不匹配，报错
			if(count($countArr) != count($domains))
			{
				$notDomains = array_diff($domains,$countArr);
				if($notDomains)
				{
					throw new \Exception(implode(',', $notDomains) . '域名查询失败', 322010);
				}
			}
			$templateInfo = $this->domainPushLib->getTradeDomainTemp($newId);//获取可用的模版
			if(!$templateInfo)
			{
				throw new \Exception($countArr[0] . '域名过户失败', 322007);
			}
			$mod = new ModBase('domain');
			$mod->db->autocommit(FALSE);
			$pushData = array();
			try
			{
				$result = $this->domainPushLib->moveDomainNew($domainList, $newId, $templateInfo,$countArr);
				if($result === FALSE)
				{
					throw new \Exception('域名过户失败', 322007);
				}
				$mod->db->commit();
				$mod->db->autocommit(TRUE);
				$this->domainPushLib->DomainPushTemplate($newId, $result, TRUE); // 添加过户队列
// 				$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'domain_push_success'));
				foreach($domainList as $domainInfo)
				{
// 					$amqp->sendMq(
// 						array('sender' => intval($oldId), 'uid' => intval($newId),'ip'=>'0.0.0.0' ,'isLock'=>$islock ? intval($islock) : 0,'domains' => array($domainInfo['DomainName'])));
					DomainLogsLib::addDomainOperaterLog($domainInfo['DomainName'], $newId, '接收域名(交易)', 8);
				}
				if($islock == 2)
				{
					$dnlogic = new \logic\manage\domain\DomainManageLogic();
					$dnlogic->addDomainLockInfo($countArr, $oldId, "trade");
				}
				\core\Log::write('push domain cout:' . count($domainList) . ',push time:' . (time() - $time) . "s", $this->conf->domain->logFolder, 'moveDomain');
				return TRUE;
			}
			catch(\Exception $e)
			{
				$mod->db->rollback();
				$mod->db->autocommit(TRUE);
				throw new \Exception($e->getMessage(), $e->getCode());
			}
		}
		catch(\Exception $e)
		{
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}

	/**
	 * 经纪中介交易PUSH入口 0608
	 *
	 * @param string $domain
	 * @param int $status
	 * @return boolean
	 */
	public function domainPushBroker($domain, $status)
	{
		$status = intval($status);
		if($status == 1 || $status == 3)
		{
			return $this->domainPushLib->domainAddToSale($domain, $status,true);
		}
		Response::setErrMsg(322001, "域名状态有误");
		return FALSE;
	}

	/**
	 * 获取域名信息，给交易批量获取域名信息用
	 *
	 * @param string $domains
	 * @return boolean|array
	 */
	public function getDomainInfo($domains)
	{
		$domainArr = explode(',', $domains);
		foreach($domainArr as $domain)
		{
			if(false == DomainFunLib::checkIsOkDomain($domain))
			{
				throw new \Exception('不是正确的域名', 360013);
			}
		}
		$mod = new \models\manage\domain\DomainsMod();
		$where = array('in' => array('DomainName' => $domainArr));
		$field = 'DomainId,EnameId,DomainName,RegDate,ExpDate,DomainMyStatus';
		return $mod->getDomainList($where, '', 'DomainName desc', $field);
	}

	/**
	 * 查看域名是否可以交易 可以的话返回域名信息 不可以的话返回错误信息
	 *
	 * @param domain 单个或者批量
	 */
	public function checkDomainInfo($domains)
	{
		$domainArr = explode(',', $domains);
		$return = array();
		$dnLib = new \lib\manage\domain\DomainManageLib();
		foreach($domainArr as $domain)
		{
			if(false == DomainFunLib::checkIsOkDomain($domain)) // 格式判断
			{
				$return[] = array('code' => 322024, 'flag' => FALSE, 'msg' => '域名格式错误', 'domain' => $domain);
				continue;
			}
			$info = $dnLib->getDomainInfo(array('DomainName' => $domain)); // 信息查找
			if(!$info)
			{
				$return[] = array('code' => 322025, 'flag' => FALSE, 'msg' => '域名非我司', 'domain' => $domain);
				continue;
			}
			if(DomainFunLib::checkDomainAllowToTrade($info) !== TRUE) // 域名状态检查
			{
				if(Response::$errCode == 322003)
				{
					$ret = array('DomainId' => $info['DomainId'], 'EnameId' => $info['EnameId'], 
						'DomainName' => $info['DomainName'], 'RegDate' => $info['RegDate'], 
						'ExpDate' => $info['ExpDate'], 'DomainMyStatus' => $info['DomainMyStatus']);
					$return[] = array('code' => Response::$errCode, 'flag' => FALSE, 'msg' => Response::getErrMsg(), 
						'domain' => $domain, 'info' => $ret);
				}
				else
				{
					$return[] = array('code' => Response::$errCode, 'flag' => FALSE, 'msg' => Response::getErrMsg(), 
						'domain' => $domain);
				}
				continue;
			}
			$ret = array('DomainId' => $info['DomainId'], 'EnameId' => $info['EnameId'], 
				'DomainName' => $info['DomainName'], 'RegDate' => $info['RegDate'], 'ExpDate' => $info['ExpDate'], 
				'DomainMyStatus' => $info['DomainMyStatus']);
			$return[] = array('flag' => TRUE, 'msg' => $ret, 'domain' => $domain);
		}
		return $return;
	}

	/**
	 * 抢注域名入库0621
	 */
	public function domainInsertLogic($data)
	{
		if(empty($data) || empty($data['domain']) || empty($data['registrarName']))
		{
			return array('code' => 1006, 'msg' => '参数错误');
		}
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		$punycode = new \common\Punycode();
		$domain = $punycode->decode($data['domain']);
		$regName = trim(strtolower($data['registrarName']));
		$regName = ($regName == 'eeqq') ? 'eeau' : $regName;
		$regArr = $sdk->execSdkFun(5555);
		$regId = isset($regArr[$regName]) ? $regArr[$regName] : FALSE;
		$check = $this->domainPushLib->checkDomainInsert($domain, $regId);
		if(TRUE !== $check)
		{
			return $check;
		}
		$domainData = $sdk->execSdkFun(5025, array('domain' => $domain, 'registrarID' => $regId));
		if($domainData['resultCode'] != 5000)
		{
			DomainLogsLib::addDomainService($domain, array('memo' => '5025_is_not_info_dc', 'info' => $domainData), 26);
			return array('flag' => false, 'msg' => '域名查询注册局信息失败');
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'qiangzhu');
		$regLib = new \lib\manage\domain\DomainRegistLib($conf->newQiangzhuUserId);
		$createDate = $expireDate = '';
		$createDate = date("Y-m-d H:i:s", strtotime($domainData['data']['createDate']));
		$expireDate = date("Y-m-d H:i:s", strtotime($domainData['data']['expireDate']));
		$templateId = DomainFunLib::isChinaDomain($domain) ? $conf->qiangzhuTempCn : $conf->qiangzhuTempNet;
		$tempName = DomainFunLib::isChinaDomain($domain) ? '临时模板1' : '临时模板2';
		$productType = DomainFunLib::getDomainProductType($domain);
		$return = $regLib->domainInDbBaseTable($domain, $regId, $createDate, $expireDate, $createDate, 
			$conf->newQiangzhuUserId, $tempName, $templateId, $productType);
		if(!$return)
		{
			DomainLogsLib::addDomainService($domain, array('memo' => 'insert_fail_dc', 'c' => '域名入库失败'), 26);
			return array('flag' => false, 'msg' => '域名入库失败');
		}
		DomainLogsLib::addDomainService($domain, array('memo' => 'insert_success_dc', 'c' => '域名入库成功'), 26);
		$this->domainPushLib->domainExtAdd($return, $conf->newQiangzhuUserId, 
			DomainFunLib::isChinaDomain($domain) ? 4 : 2);
		$eppLib = new \lib\manage\domain\DomainEppLib();
		$eppLib->setDomainRegisterStatus($domain, $regId);
		$eppLib->setDomainDns($domain, 1, array('dns1.iidns.com'), $regId);
		return array('flag' => true, 'msg' => '域名入库成功');
	}

	/**
	 * 中介专用PUSH接口 code:0645
	 * 
	 * @param array $data
	 */
	public function domainPushForEname($data)
	{
		$domain = isset($data['domain']) ? $data['domain'] : false;
		$oldId = isset($data['oldId']) ? intval($data['oldId']) : false; // 域名原EnameId
		$newId = isset($data['newId']) ? intval($data['newId']) : false; // 域名现EnameId
		$systemUserId = isset($data['systemUserId']) ? intval($data['systemUserId']) : false;
		$toSysMemo = isset($data['toSysMemo']) ? $data['toSysMemo'] : '';
		$sysToMemo = isset($data['sysToMemo']) ? $data['sysToMemo'] : '';
		$ip = isset($data['ip']) ? $data['ip'] : \common\Common::getRequestIp();
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$systemTemplateId = $conf->template->temp->id;
		if(!($domain && $oldId && $newId && $sysToMemo && $systemUserId))
		{
			throw new \Exception('传入参数有误', 300019);
		}
		\lib\manage\common\DomainOpenLib::domainOpen('push');
		$domainInfo = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain, 'EnameId' => $oldId));
		if(!$domainInfo || !is_array($domainInfo))
		{
			throw new \Exception('传入参数有误', 300019);
		}
		if($domainInfo['DomainMyStatus'] == 1)
		{
			if(FALSE ==
				 DomainFunLib::checkDomainRegdate($domainInfo['DomainName'], $domainInfo['RegDate'], $domainInfo['ExpDate']))
			{
				throw new \Exception(Response::$errMsg, Response::$errCode);
			}
			if(($domainInfo['DomainProperty'] == 4 || $domainInfo['DomainProperty'] == 6) &&
				 $domainInfo['ClassName'] == 1)
			{
				throw new \Exception($domain . '腾讯邮箱域名，不能出售', 322013);
			}
			$templateLib = new \lib\manage\domain\TemplateLib();
			$templateInfo = $templateLib->getUseTemplates($newId, 'PushTemplate', true);
			$templateInfo = $templateInfo[0];
			$status = $this->domainPushLib->moveDomain($domainInfo, $newId, $templateInfo['TemplateId'], $templateInfo['TempUserName'], $templateInfo['TemplateType']);
			if(!$status)
			{
				throw new \Exception('域名过户失败', 322007);
			}
			try
			{
				$queueTasklib = new \logic\manage\newqueue\QueueLogic();
				$queueData = array('domain' => $domain, 'templateId' => $templateInfo['TemplateId'], 'oldTemplateId' => $domainInfo['TemplateId'], 'registrarId' => $domainInfo['RegistrarId'], 'newTemplateName' => $templateInfo['TempUserName'], 'tempType' => $templateInfo['TemplateType'], 'oldTemplateName' => '', 'enameId' => $newId);
				$result = $queueTasklib->addQueueTask(array('Function' => 'template_push', 'EnameId' => $newId, 'Data' => array($queueData), 'Priority' => 5));
			}
			catch(\Exception $e)
			{
				\core\Log::write('domainPushForEname:' . json_encode($queueData), 'queue', 'template_push');
				$result = $e->getMessage();
			}
// 			$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'domain_push_success'));
// 			$amqp->sendMq(
// 				array('sender' => $oldId, 'ip'=>'0.0.0.0','isLock'=>1,'uid' => $newId, 'domains' => array($domain)));
			$this->addPushRecord($domain, $oldId, $newId, $systemUserId, $sysToMemo, $toSysMemo, $ip);
			DomainLogsLib::addDomainService($domainInfo['DomainName'], array('memo' => '0645temp_push', 'param' => $queueData, 'res' => $result), 35);
			DomainLogsLib::addDomainOperaterLog($domain, $newId, '接收域名(中介交易)', 8);
			return true;
		}
		throw new \Exception($domain . '域名状态错误，不能申请过户', 322010); 
	}

	/**
	 * 中介交易过户记录
	 *
	 * @param string $domain
	 * @param int $sendId
	 * @param int $receiveId
	 * @param string $memo
	 */
	private function addPushRecord($domain, $sendId, $receiveId, $systemUserId, $sysToMemo, $toSysMemo, $ip)
	{
		$pushmod = new \models\manage\domain\DomainPushMod();
		$result = $pushmod->addPush($systemUserId, $sendId, 1, 0, $domain, 0, 2, $toSysMemo, 0, date("Y-m-d H:i:s"), $ip,1);
		if($result)
		{
			if($receiveId != 80000)
			{
				$pushmod->addPush($receiveId, $systemUserId, 1, 0, $domain, 0, 2, $sysToMemo, 0, date("Y-m-d H:i:s"), $ip,1);
			}
			return true;
		}
		\core\Log::write('中介交易过户记录,' . "{$domain},{$sendId},{$receiveId},{$systemUserId}", $this->conf->domain->logFolder, 'moveDomain');
		return FALSE;
	}
} 
<?php
/**
 * 暂时其他7788的域名相关集合
 */
namespace logic\manage\domain;
use \core\ModBase;
class DomainFuncLogic
{
	public function __construct()
	{
		
	}
	
	/**
	 * 估计要非常耗费时间
	 */
	public function getNoticeDomainNum($start,$end,$type = 1)
	{
		$mod = new ModBase('domain');
		if($type==1)
		{
			$sql="select RegistrarId,DomainLtd,MONTH(ExpDate) as Months, DAY(ExpDate) as Days,Year(ExpDate) as Years,count(*) as Num from e_domains where registrarid in(22,21)";
			$sql .= $start ? " and ExpDate>='".date('Y-m-d 00:00:00',strtotime($start))."'" : '';
			$sql .=$end ? "  and Expdate<='".date('Y-m-d 23:59:59',strtotime($end))."'" : '';
			$sql.=" group by RegistrarId,DomainLtd,Years,Months,Days";
		}
		else
		{
			$sql="select RegistrarId,DomainLtd,MONTH(ExpDate) as Months,Year(ExpDate) as Years,count(*) as Num from e_domains where registrarid in(22,21)";
			$sql .= $start ? " and ExpDate>='".date('Y-m-01 00:00:00',strtotime($start))."'" : '';
			if($end) $firlst = date('Y-m-01 00:00:00',strtotime($end));
			$lastday = date('Y-m-d 23:59:59', strtotime($end));
			$sql .=$end ? "  and Expdate<='".$lastday."'" : '';
			$sql.=" group by RegistrarId,DomainLtd,Years,Months";
		}
		$countInfo = $mod->select($sql, "", array());
		if($countInfo)
		{
			$return = array();
			foreach($countInfo as $info)
			{
				if($info['DomainLtd'] ==9) $info['DomainLtd']=3;
				else if($info['DomainLtd'] ==10)  $info['DomainLtd']=4;
				$return[$info['RegistrarId']][$info['DomainLtd']][] = $info;
			}
			return $return;
		}
		return FALSE;
	}
	
	/**
	 * 查看用户可赎回列表
	 */
	public function checkUserRestoreList($enameIds)
	{
		$enameIds = is_array($enameIds) ? $enameIds : explode(",",$enameIds);
		$time = date('Y-m-d H:i:s',strtotime('-6 months'));
		$bakMod = new \models\manage\domain\DomainBakMod();
		$list = $bakMod->getDomainBakList(array('in'=>array('EnameId'=>$enameIds),'ExpDate>'=>$time),"DomainName,EnameId");
		$return =array();
		if($list)
		{
			foreach ($list as $info)
			{
				$enameId = $info['EnameId'];
				$domain=$info['DomainName'];
				try
				{
					$logic = new \logic\manage\domain\DomainRestoreLogic();
					$st = $logic->domainRestoreQuery($enameId, $domain);
				}
				catch (\Exception $e)
				{
					$st = $e->getMessage().','.$e->getCode();
				}
				if(is_array($st))
				{
					$return[$enameId]['canrestore'][] = $domain.',可赎回';
				}
				else
				{
					$return[$enameId]['notrestore'][] = $domain.','.$st;
				}
			}
		}
		return $return;
	}
}

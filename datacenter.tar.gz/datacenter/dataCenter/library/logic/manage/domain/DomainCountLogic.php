<?php
namespace logic\manage\domain;
class DomainCountLogic
{
	private $redis = null;
	public function __construct()
	{
		$this->redis = new \lib\manage\common\RedisLib(false);
		$this->statType = 11;
	}

	/**
	 * 1域名注册 3续费  2转入
	 */
	public function addDomainCount($type = FALSE)
	{ 
		if($type)
		{
			$this->addCountEach($type);
		}
		else
		{
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domaincount');
			foreach($conf->domaincount->type->toArray() as $type)
			{
				$this->addCountEach($type);
			}
		}
	}

	private function addCountEach($type)
	{
		$redisKey = 'appdomainreg_' . date('Y-m-d', strtotime('-1 days'));
		$firstType = 1;
		if($type == 2)
		{
			$firstType = 2;
			$redisKey = 'appdomaintransfer_' . date('Y-m-d', strtotime('-1 days'));
		}
		else if($type == 3)
		{
			$firstType = 3;
			$redisKey = 'appdomainrenew_' . date('Y-m-d', strtotime('-1 days'));
		}
		else if($type == 4)
		{
			$firstType = 4;
			$redisKey = 'appdomaintransferout_' . date('Y-m-d', strtotime('-1 days'));
		}
		$allcount = $this->redis->getData($redisKey);
		$allcount = $allcount ? $allcount : 0;
		$mod = new \models\manage\domain\DomainCountMod();

		$end = date('Y-m-d 23:59:59', strtotime('-1 days'));
		$begin = date('Y-m-d 00:00:00', strtotime('-1 days'));

		$list = $mod->getCountList(array('statType' => $this->statType,
				'date(endTime)' => date('Y-m-d', strtotime('-1 days')), 'firstType' => $firstType,
				'date(beginTime)' => date('Y-m-d', strtotime('-1 days'))));
		if($list)
		{
			$add = $mod->updateCountInfo(array('dcid' => $list['dcid']), array('allCount' => $allcount));
		}
		else
		{
			$add = $mod->addCount(array('statType' => $this->statType, 'firstType' => $firstType,
					'secondType' => $firstType, 'allCount' => $allcount, 'beginTime' => $begin, 'endTime' => $end));
		}
		if(!$add)
		{
			\core\Log::write($redisKey . "firsttype:$firstType,allcount:$allcount", "domain", "domaincountfailed");
		}
		else
		{
			$delredis = $this->redis->delData($redisKey);
			if(!$delredis)
			{
				\core\Log::write($redisKey.",delrediserror",'domain','domaincountfailed');//删除失败记录
			}
		}
		echo $add ? $redisKey . ' data add success,allcount:' . $allcount : $redisKey . ' data add failed,allcount:' . $allcount;
		echo PHP_EOL;
	}
}

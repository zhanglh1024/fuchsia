<?php
namespace logic\manage\domain;
use core\form\ReturnData;
use core\Response;
use \lib\manage\common\DomainFunLib;
use lib\manage\domain\DomainQueryLib;
class DomainLogic
{
	/**
	 * 域名是否可以注册，包含交易推荐数据 提供给app使用
	 * @param object $queryData enameId domain suffix
	 * @return array
	 */
	public function domainRegistQuery($queryData)
	{
		$queryLib = new \lib\manage\domain\DomainQueryLib($queryData->enameId); 
		$queryLib->interLimit('domainRegistQuery');
		$domainRegBlack = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini','domain_register_black');
		$vspConf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini','vspdomainltd');
		$limitCount = 0;
		$data = array(); 
		$recom = array();
		$blackKey = $domainRegBlack->domain_register_black_start->toArray();
		foreach ($blackKey as $value)
		{
			if(preg_match('/^'.$value.'/', $queryData->domain))
			{
				throw new \Exception("域名不合法", 311010);
			}
		}
		if(DomainFunLib::isOkDomain($queryData->domain))
		{
			if(DomainFunLib::checkIsDownDomain($queryData->domain))
			{
				throw new \Exception("网络超时", 311014);
			}
			if($this->checkChineseDomain($queryData->domain) == FALSE)
			{
				throw new \Exception("域名不合法", 311010);
			}
			$queryData->suffix = array(DomainFunLib::getDomainClassAll($queryData->domain));
			$queryData->domain = strtolower(DomainFunLib::getDomainBody($queryData->domain));
			if(DomainFunLib::checkDomainSuffix($queryData->suffix[0]) == FALSE)
			{
				throw new \Exception("域名格式错误", 311000);
			}
		}
		else
		{
			if(empty($queryData->suffix))
			{
				throw new \Exception("域名格式错误", 311000);
			}
		}
		if($queryData->suffix && array_diff($queryData->suffix, array('cn', 'org.cn', 'com.cn', 'net.cn', '中国', '公司',
				'网络')) == FALSE)
		{
			if(DomainFunLib::isOkDomainByCross($queryData->domain) == FALSE)
			{
				throw new \Exception($queryData->domain . '格式错误,-不能放在开头或者结尾');
			}
			foreach($queryData->suffix as $suf)
			{
				if(DomainFunLib::isOkCnDomain($queryData->domain . '.' . $suf) == FALSE)
				{
					throw new \Exception($queryData->domain . '格式错误，国内域名-不能连续出现');
				}
			}
		} 
		$recommondList = array();
		$recommondList = $queryLib->getRecommendDomain($queryData->suffix, $queryData->domain);//获取推荐的数据
		//.net域名优惠活动
		$domainTmp = array();
		foreach($queryData->suffix as $key => $value)
		{
			$domainTmp[] = $queryData->domain . '.' . $value;
		}
		$domainRegBlackArr = $domainRegBlack->domain_register_black->toArray();
		$domainRegBlackStrArr = $domainRegBlack->domain_register_black_string->toArray();
		$domainRegBlackKey = $domainRegBlack->domain_register_black_key;
		$checkBusinessCode = array();
		foreach($queryData->suffix as $suf)
		{
			$suf = urldecode($suf);
			$domain = $queryData->domain . '.' . $suf;
			$limitCount++;
			if($limitCount > 20)
			{
				$data[] = array('domain' => $domain, 'msg' => '一次限制最多查询20个域名', 'code' => 60004);
				continue;
			}
			$len = mb_strlen($domain,'UTF-8');
			if(strtolower($suf) == 'org' && $len < 7 )
			{
				$data[] = array('domain' => $domain, 'msg' => 'ORG域名长度不能小于3位', 'code' => 60005);
				continue;
			}
			if(strtolower($suf) == 'org' && $len > 67 )
			{
				$data[] = array('domain' => $domain, 'msg' => 'ORG域名长度不能大于63位', 'code' => 60005);
				continue;
			}
			$domainBlack = str_replace($domainRegBlackStrArr, '----', $domain);
			if(DomainFunLib::isChinaDomain($domain) && (strpos($domainBlack, '----') !== false || stripos($domainRegBlackKey, ','.$queryData->domain.',') !== false))
			{
				$data[] = array('domain' => $domain, 'msg' => '该域名不能注册，请联系客服', 'code' => 60005);
				continue;
			}
			if(in_array(strtolower($domain), $domainRegBlackArr))
			{
				$data[] = array('domain' => $domain, 'msg' => '该域名不能注册，请联系客服', 'code' => 60005);
				continue;
			}
			if(DomainFunLib::checkIsDownDomain($domain))
			{
				$data[] = array('domain' => $domain, 'msg' => '查询超时', 'code' => 60006);
				continue;
			}
			if(DomainFunLib::checkDomainSuffix($suf) == FALSE)
			{
				$data[] = array('domain' => $domain, 'msg' => '域名格式错误,不可注册', 'code' => 60001);
				continue;
			}
			if(!\lib\manage\common\DomainFunLib::isOkDomain($domain))
			{
				$data[] = array('domain' => $domain, 'msg' => '域名格式错误,不可注册', 'code' => 60001);
				continue;
			}
			if(\lib\manage\common\DomainOpenLib::checkOpen('query', $domain) === FALSE)
			{
				$data[] = array('domain' => $domain, 'msg' => '查询超时', 'code' => 60006);
				continue;
			}
			if(FALSE === \lib\manage\common\DomainOpenLib::tmpFuncOpenCheck(FALSE) && DomainFunLib::isChinaDomain($domain) && !DomainFunLib::isWangluoDomain($domain))
			{
				$data[] = array('domain' => $domain, 'msg' => '查询超时', 'code' => 60006);
				continue;
			}
			if($this->checkChineseDomain($domain) == FALSE)
			{
				$data[] = array('domain' => $domain, 'msg' => '域名不合法', 'code' => 60008);
				continue;
			}
			if($queryLib->checkDomainStatus($domain))//正在交易的域名
			{
				$recommond = array();
				if($recommondList)
				{
					$recommond = $queryLib->checkDomainRecommend($domain, $recommondList);
				}
				$data[] = array('domain' => $domain, 'msg' => '正在交易', 'code' => 60007) + $recommond;
				continue;
			}
			$registInfo = $queryLib->domainCheckIsExits($domain);
			if(true === $registInfo)
			{
				$price = $queryLib->getDomainPrice($domain, $suf);
				if(false === $price)
				{
					$data[] = array('domain' => $domain, 'msg' => '获取域名价格失败,不可注册', 'code' => 60002);
					continue;
				}
				if(in_array(DomainFunLib::getDomainClass($domain),$vspConf->domainltd->toArray()))
				{ 
					$checkBusinessCode[] = $domain;
				}
				$data[] = array('domain' => $domain, 'price' => $price, 'msg' => '可以注册', 'code' => 60000);
			}
			else if('domainpre' === $registInfo)
			{
				throw new \Exception($domain . '溢价域名不支持app注册');
			}
			else if(false === $registInfo)
			{
				$data[] = array('domain' => $domain, 'msg' => $domain . '不可注册', 'code' => 60003);
			}
			else
			{
				$data[] = array('domain' => $domain, 'msg' => $domain . '服务器查询失败', 'code' => 60005);
			}
		}
		if(empty($data))
		{
			throw new \Exception("域名格式错误,不可注册", 311011);
		}
		$appVersion = \common\Common::getAppVersion();
		DomainQueryLib::getDomainBusinessCode($checkBusinessCode);
		$formatData['reg'] = $queryLib->formatQueryRegistList($data);
		$formatData['recommend'] = $recommondList ? array_slice($recommondList, 0, 3) : false;
		return $formatData;
	}

	private function checkChineseDomain($domain)
	{
		if(DomainFunLib::isCnDomain($domain))
		{
			if(!in_array(DomainFunLib::getDomainClassAll($domain), array('com', 'net', 'cn', '中国', '公司', '网络', 'top')) || (DomainFunLib::isChinaDomain($domain) && !DomainFunLib::isChineseCnDomain($domain)))
			{
				return FALSE;
			}
		}
		return TRUE;
	}

	/**
	 * 检测域名是否可以注册
	 * @param string $domain
	 * @return boolean
	 */
	public function domainRegistCheck($domain)
	{
		$queryLib = new \lib\manage\domain\DomainQueryLib(0);
		if(!\lib\manage\common\DomainFunLib::isOkDomain($domain))
		{
			Response::setErrMsg(311000, "域名格式错误");
			return FALSE;
		}
		if($this->checkChineseDomain($domain) == FALSE)
		{
			Response::setErrMsg(311010, "域名不合法");
			return FALSE;
		}
		if(\lib\manage\common\DomainOpenLib::checkOpen('query', $domain) === FALSE)
		{
			Response::setErrMsg(311001, "查询超时");
			return FALSE;
		}
		if($queryLib->checkDomainStatus($domain))
		{
			Response::setErrMsg(311002, $domain . "正在交易");
			return FALSE;
		}
		$registInfo = $queryLib->domainCheckIsExits($domain);
		if(TRUE === $registInfo)
		{
			return TRUE;
		}
		else if('domainpre' === $registInfo)
		{
			Response::setErrMsg(311015, $domain."溢价域名不支持app注册");
			return FALSE;
		}
		else if(FALSE === $registInfo)
		{
			Response::setErrMsg(311003, "域名已注册");
			return FALSE;
		}
		Response::setErrMsg(311004, '服务器查询失败');
		return FALSE;
	}

	public function getDomainRemindCount()
	{
		$domainExpRemindMod = new \models\manage\domain\DomainExpRemindMod();
		$count = $domainExpRemindMod->getTodoCount();
		if(!$count)
		{
			throw new \Exception("信息获取失败！" ,300017);
		}
		$rs['count'] = $count[0]['count'];
		$rs['name'] = '人工提醒';
		$config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'adminmanage');
		$baseUrl = $config->url;
		$rs['url'] = $baseUrl . 'domain/expremind';
		return $rs;
	}

	public function getDomainProtectionCount()
	{
		$domainProtectionMod = new \models\manage\domain\DomainProtectionMod();
		$count = $domainProtectionMod->getTodoCount();
		if(!$count)
		{
			throw new \Exception("信息获取失败！" ,300017);
		}
		$rs['count'] = $count[0]['count'];
		$rs['name'] = '域名安全锁';
		$config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'adminmanage');
		$baseUrl = $config->url;
		$rs['url'] = $baseUrl . 'domainservice/domainprotectlist';
		return $rs;
	}

	public function getDomainProtectCnCount($data)
	{
		$type = empty($data->type) ? 1 : $data->type;
		$type = $type == 1 ? 1 : 2;
		$domainProtectionMod = new \models\manage\domain\DomainProtectionMod();
		$count = $domainProtectionMod->getDomainSecureCount($type);
		if(!$count)
		{
			throw new \Exception("信息获取失败！" ,300017);
		}
		$rs['count'] = $count[0]['count'];
		$rs['name'] = $type == 2 ? '国内域名注册局安全锁' : '国际域名注册局安全锁';
		$config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'adminmanage');
		$baseUrl = $config->url;
		$rs['url'] = $baseUrl . 'domainservice/domainprotectlist/' . $type;
		return $rs;
	}

	public function simpleDomainReg($info)
	{
		$domain = $info->domain;
		$registerid = $info->registerid;
		$templateId = $info->templateid;
		$domainregistlib = new \lib\manage\domain\DomainRegistLib();
		$errorMsg = '注册成功';
		try
		{
			$cartConf = new \Yaf\Config\Ini(APP_PATH . '/conf/cart.ini', 'cart');
			$registLib = new \lib\manage\domain\DomainRegistLib();
			$result = $registLib->simpledomainReg($domain, $templateId, 1, $registerid);
			if($result['code'] == 1001)
			{
				$flag = $result = FALSE;//1001的不让重新注册
				$errorMsg = $cartConf->errorMsg->regedErr;
			}
			else if($result['code'] != 1000)
			{
				$result = false;
			}
		}
		catch(\Exception $e)
		{
			\core\Log::write($e->getMessage(), 'cart', 'reg');
			$result = false;
		}
		if(empty($result))
		{
			$throwMsg = isset($flag) && $flag == FALSE ? $cartConf->errorMsg->noflag : $cartConf->errorMsg->overCartErr;
			throw new \Exception($throwMsg, 311009);//域名结算失败
		}
		return $errorMsg;
	}

	/**
	 * 域名是否可以注册批量查询
	 * 给交易平台使用
	 */
	public function domainQueryBatch($queryData)
	{
		$domainListArr = explode(',', $queryData->domain);
		$domainListArr = array_unique(array_filter($domainListArr));
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domainquery');
		if(count($domainListArr) > $conf->querynum)
		{
			//throw new \Exception("一次最多允许查询" . $conf->querynum . "个域名");
		}
		//top cn com/net asia org pw 
		$data = $com = $org = $cn = $other = $pw = $top = array();
		foreach($domainListArr as $domain)
		{
			$ltd = strtolower(DomainFunLib::getDomainClass($domain));//只判断最后一级后缀
			if(DomainFunLib::isOkDomain($domain) == FALSE)
			{
				$data[] = array('domain' => $domain, 'msg' => '域名格式错误,不可注册', 'code' => 60001);
				continue;
			}
			if(stripos($conf->batchqueryltd, $ltd) === false)//com,net,org,asia,pw,top,cn
			{
				$data[] = array('domain' => $domain, 'msg' => '暂不支持查询', 'code' => 60002);
				continue;
			}
			if($this->checkChineseDomain($domain) == FALSE)
			{
				$data[] = array('domain' => $domain, 'msg' => '域名不合法', 'code' => 60008);
				continue;
			}
			if(\lib\manage\common\DomainOpenLib::checkOpen('query', $domain) === FALSE || DomainFunLib::checkIsDownDomain($domain))
			{
				$data[] = array('domain' => $domain, 'msg' => '查询超时', 'code' => 60006);
				continue;
			}
			if(FALSE ===\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck(FALSE) && DomainFunLib::isChinaDomain($domain) && !DomainFunLib::isWangluoDomain($domain))
			{
				$data[] = array('domain' => $domain, 'msg' => '查询超时', 'code' => 60006);
				continue;
			}
			$regid = $this->getDomainRegistraId($domain, $conf);
			if(!$regid)
			{
				$data[] = array('domain' => $domain, 'msg' => '接口错误', 'code' => 60003);
				continue;
			}
			switch($ltd)
			{	
				case 'com':
				case 'net':
					$com[] = $domain;
					break;
				case 'cn':
					$cn[] = $domain;
					break;
				case 'org':
					$org[] = $domain;
					break;
				case 'pw':
					$pw[] = $domain;
					break;
				case 'top':
					$top[] = $domain;
					break;
				default:
					$other[] = $domain;
			}
		}
		if(empty($com) && empty($org) && empty($other) && empty($cn) && empty($pw) && empty($top))
		{
			return $data;
		}
		$com = $this->getRealQueryDomains($com, $conf);
		$cn = $this->getRealQueryDomains($cn, $conf);
		$top = $this->getRealQueryDomains($top, $conf);
		$pw = $this->getRealQueryDomains($pw, $conf);
		$org = $this->getRealQueryDomains($org, $conf);
		$other = $this->getRealQueryDomains($other, $conf);
		$queryParams = array_merge($com, $other,$top,$pw,$org,$cn);
		$queryLib = new \lib\manage\domain\DomainQueryLib($queryData->enameId);
		$priceYearLib = new \lib\manage\domain\DomainPriceTempLib($queryData->enameId);
		foreach($queryParams as $params)
		{
			$queryInfo = $queryLib->domainCheckIsExits($params['domain'], $params['registrarID']);
			foreach(explode(',', $params['domain']) as $domain)
			{
				if($queryInfo === null)
				{
					$data[] = array('domain' => $domain, 'msg' => '服务器查询失败', 'code' => 60005);
					continue;
				}
				else if($queryInfo === false || (isset($queryInfo['registered']) && in_array($domain, $queryInfo['registered'])))
				{
					$data[] = array('domain' => $domain, 'msg' => '不可注册', 'code' => 60004);
					continue;
				}
				else if((isset($queryInfo['notRegister']) && in_array($domain, $queryInfo['notRegister'])) || $queryInfo === true)
				{
					$price = $queryLib->getDomainPrice($domain, DomainFunLib::getDomainClassAll($domain));
					if(false === $price || $price === null)
					{
						$data[] = array('domain' => $domain, 'msg' => '获取域名价格失败,不可注册', 'code' => 60002);
					}
					else
					{
						$year = $priceYearLib->getDomainYear($domain, 1, FALSE);
						//交易接口不算app  不走app活动接口 只限制top/wang等年份(价格是统一的)
						$yearPrice = $queryLib->checkDomainYears($domain, 1, $year);
						$year = $yearPrice['year'];
						$data[] = array('domain' => $domain, 'price' => $price, 'year' => $year, 'msg' => '可以注册',
								'code' => 60000);
					}
				}
			}
		}
		return $data;
	}

	private function getDomainRegistraId($domain, $conf)
	{
		$regidArr = $conf->registrarid->toArray();
		$suffix = strtolower(DomainFunLib::getDomainClass($domain));
		return isset($regidArr[$suffix]) ? $regidArr[$suffix] : FALSE;
	}
	
	private function getCnRegistraid($domain)
	{
		if(DomainFunLib::isChineseCnDomain($domain)==FALSE && DomainFunLib::isChinaDomain($domain))
		{
			$regidList = array(1,2, 3, 9, 13);
			return $regidList[mt_rand(0,count($regidList)-1)];
		}
		return FALSE;
	}
	
	/**
	 * 115合作接口查询
	 */
	public function domainRegistQueryOther($queryData)
	{
		$limitCount = 0;
		$queryLib = new \lib\manage\domain\DomainQueryLib($queryData->enameId);
		$queryLib->interLimit('domainRegistQuery115');
		$priceYearLib = new \lib\manage\domain\DomainPriceTempLib($queryData->enameId);
		$data = array();
		$checkVspDomain = array();
		foreach(explode(',', $queryData->domain) as $domain)
		{
			$limitCount++;
			if(FALSE == DomainFunLib::isOkDomain($domain) || FALSE == DomainFunLib::isOkDomainByCross($domain) || FALSE == DomainFunLib::isOkCnDomain($domain))
			{
				$data[] = array('domain' => $domain, 'msg' => '域名格式错误,不可注册', 'code' => 60001);
				continue;
			}
			if(FALSE == DomainFunLib::checkDomainSuffix115($domain))
			{
				$data[] = array('domain' => $domain, 'msg' => '暂不支持的后缀', 'code' => 60002);
				continue;
			}
			if(FALSE == $this->checkChineseDomain($domain))
			{
				$data[] = array('domain' => $domain, 'msg' => '域名不合法', 'code' => 60008);
				continue;
			}
			if($limitCount > 20)
			{
				$data[] = array('domain' => $domain, 'msg' => '一次限制最多查询20个域名', 'code' => 60003);
				continue;
			}
			if(\lib\manage\common\DomainOpenLib::checkOpen('query', $domain) === FALSE || DomainFunLib::checkIsDownDomain($domain))
			{
				$data[] = array('domain' => $domain, 'msg' => '查询超时', 'code' => 60004);
				continue;
			}
			if(FALSE === \lib\manage\common\DomainOpenLib::tmpFuncOpenCheck(FALSE) && DomainFunLib::isChinaDomain($domain) && !DomainFunLib::isWangluoDomain($domain))
			{
				$data[] = array('domain' => $domain, 'msg' => '查询超时', 'code' => 60004);
				continue;
			}
			//115接口不算app 不参与活动域名价格优惠
			$price = $queryLib->getDomainPrice($domain, DomainFunLib::getDomainClass($domain));
			if(false === $price)
			{
				$data[] = array('domain' => $domain, 'msg' => '获取域名价格失败,不可注册', 'code' => 60005);
				continue;
			}
			$registInfo = $queryLib->domainCheckIsExits($domain);
			if(true === $registInfo)
			{
				$checkVspDomain[] = $domain;
				$queryLib = new \lib\manage\domain\DomainQueryLib($queryData->enameId);
				$year = $priceYearLib->getDomainYear($domain, 1, FALSE);
				$year = $queryLib->checkDomainYears($domain, 1, $year);//只限制top/wang等注册年份(价格是统一的)
				$year = $year['year'];
				$data[] = array('domain' => $domain, 'price' => $price, 'year' => $year ? $year : 10, 'msg' => '可以注册',
						'code' => 60000);
			}
			else if(false === $registInfo || 'domainpre' === $registInfo)
			{
				$data[] = array('domain' => $domain, 'msg' => $domain . '不可注册', 'code' => 60006);
			}
			else
			{
				$data[] = array('domain' => $domain, 'msg' => $domain . '服务器查询失败', 'code' => 60007);
			}
		}
		DomainQueryLib::getDomainBusinessCode($checkVspDomain);
		return $data;
	}

	public function getdomainsuffix()
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$data = $conf->AppdomainLtd->toArray();
		foreach($data as $key => $val)
		{
			$suff[] = $val;
		}
		return array('data' => $suff);
	}

	private function getRealQueryDomains($query, $conf)
	{
		$queryLib = new \lib\manage\domain\DomainQueryLib();
		$realQuery = array();
		if(empty($query))
		{
			return $realQuery;
		}
		$regid = $queryLib->getRandRegid($query[0]);
		$regid = $regid ? $regid : $this->getDomainRegistraId($query[0], $conf);
		$limit = $conf->querynum;
		$limit = DomainFunLib::isChinaDomain($query[0]) ? 9 :$conf->querynum;
		while(true)
		{
			if(count($query) > $limit)
			{
				$realQuery[] = array('registrarID' => $regid, 'domain' => implode(',', array_splice($query, 0, $limit)));
				if(count($query) <= $conf->querynum)
				{
					$realQuery[] = array('registrarID' => $regid, 'domain' => implode(',', $query));
					break;
				}
			}
			else
			{
				$realQuery[] = array('registrarID' => $regid, 'domain' => implode(',', $query));
				break;
			}
		}
		return $realQuery;
	}

	/**
	 * whois域名推荐和查询是否可以注册
	 * 尽可能的少查接口 直接通过信有数据来
	 */
	public function getDomainRecomond($queryData)
	{
		$domainBody = $queryData->domain;//域名主体
		$suffix = explode(",",$queryData->suffix);
		$queryLib = new \lib\manage\domain\DomainQueryLib(0);
		$result = new \StdClass();
		foreach($suffix as $suf)
		{
			$domain = $domainBody . '.' . $suf;
			if(!\lib\manage\common\DomainFunLib::isOkDomain($domain))
			{
				$result->$domain = array(3);
				continue;
			}
			if(\lib\manage\common\DomainOpenLib::checkOpen('query', $domain) === FALSE)
			{
				$result->$domain = array(3);
				continue;
			}
			$exists = $queryLib->checkDomainStatus($domain,true);//获取域名信息 查看域名是否在交易
			if($exists)
			{
				if(!isset($recommondList))//获取推荐交易的域名
				{
					$recommondList = $this->filterRecomons($queryLib->getRecommendDomain($suffix, $domainBody));
				} 
				if(isset($recommondList) && $recommondList)
				{
					$recom = $this->checkDomainSolr($domain, $recommondList);
					if($recom)
					{
						$result->{$domain} = array(2,$recom);
						continue;
					}
				}
				$result->{$domain} = array();//查无推荐信息的直接返回联系购买
				continue;
			}
			//域名不存在的再查接口信息
			$registInfo = $queryLib->domainCheckIsExits($domain);
			if(true === $registInfo)
			{
				$result->{$domain} = array(1);//可以注册的域名
			}
			else if(false === $registInfo)
			{
				if(!isset($recommondList))//获取域名信息 查询一次或者失败就停止再次查询
				{
					$recommondList = $this->filterRecomons($queryLib->getRecommendDomain($suffix, $domainBody));
				}
				if(isset($recommondList) && $recommondList)
				{
					$recom = $this->checkDomainSolr($domain, $recommondList);
					if($recom)
					{
						$result->{$domain} = array(2,$recom);
						continue;
					}
				}
				$result->$domain = array();
			}
			else
			{
				$result->$domain = array(3);
			}
		}
		return $this->formatSort($result);
	}

	/**
	 * 只要 竞价 一口价  询价  暂时不知道是否不是还有其他什么交易类型的
	 */
	private function filterRecomons($recom)
	{
		if(empty($recom))
		{
			return FALSE;
		}
		$return = array();
		foreach($recom as $info)
		{
			$info = (array) $info;
			if(empty($info['Type']) || !in_array($info['TransTypeCn'], array('竞价', '一口价', '询价')))
			{
				continue;
			}
			if(isset($info['FinishDate']))
			{
				$info['FinishDate'] = strtr($info['FinishDate'], array('T' => ' ','Z' => ' '));
				$cha = strtotime($info['FinishDate']) - time();
				$cha = $this->formatTime($cha);
				$info['FinishDate'] = $cha;
				if(!$cha)
				{
					unset($info['FinishDate']);
				}
			}
			$return[] = $info;
		}
		return $return;
	}
	
	private function formatSort($data)
	{
		$return = array();
		$data = is_object($data) ? (array) $data : $data;
		foreach($data as $domain => $recom)
		{
			$ltd = strtolower(DomainFunLib::getDomainClassAll($domain));
			$key = 0;
			$key = $ltd == 'net' ? 1 : ($ltd == 'cn' ? 2 : ($ltd == 'com.cn' ? 3 : $key));
			$return[$key] = array($domain => $recom);
		}
		ksort($return);
		$tmp = array();
		foreach($return as $value)
		{
			$k=array_keys($value)[0];
			$tmp[$k]=array_values($value)[0];
		}
		return (object) ($tmp);
	}

	/**
	 * 有竞价或一口价，就不显示询价
	 */
	private function checkDomainSolr($domain,$recommond)
	{
		$inquire  = FALSE;
		foreach($recommond as $recom)
		{
			if($recom['DomainName'] == $domain)
			{
				if(in_array($recom['TransTypeCn'],array('竞价', '一口价')))
				{	
					return $recom;
				}
				$inquire = $recom;
			}
		}
		return $inquire;
	}
	
	private function formatTime($time)
	{
		if(!is_numeric($time) || $time < 0)
		{
			return false;
		}
		$value = array("years" => 0, "days" => 0, "hours" => 0, "minutes" => 0, "seconds" => 0);
		if($time >= 31556926)
		{
			$value["years"] = floor($time / 31556926);
			$time = ($time % 31556926);
		}
		if($time >= 86400)
		{
			$value["days"] = floor($time / 86400);
			$time = ($time % 86400);
		}
		if($time >= 3600)
		{
			$value["hours"] = floor($time / 3600);
			$time = ($time % 3600);
		}
		if($time >= 60)
		{
			$value["minutes"] = floor($time / 60);
			$time = ($time % 60);
		}
		$value["seconds"] = floor($time);
		$value = array_filter($value);
		$st = '';
		if(array_key_exists('years', $value))
		{
			$st .= $value['years'] . '年';
		}
		if(array_key_exists('days', $value))
		{
			$st .= $value['days'] . '天';
		}
		if(array_key_exists('hours', $value))
		{
			$st .= $value['hours'] . '小时';
		}
		if(array_key_exists('minutes', $value))
		{
			$st .= $value['minutes'] . '分钟';
		}
		if(array_key_exists('seconds', $value))
		{
			$st .= $value['seconds'] . '秒';
		}
		return $st;
	}
	
	/**
	 * 域名入库和过户接口   给E+用
	 */
	public function storageIn($domain,$enameId,$regId)
	{
		$enameId = $this->checkQiangzhuEnameId($domain, $enameId);
		$domain = strtolower($domain);
		$domainManageLib = new \lib\manage\domain\DomainManageLib(); 
		$exists = $domainManageLib->getDomainInfo(array('DomainName' => $domain));
		if($exists)
		{
			if($exists['EnameId'] == $enameId)
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('memo' => 'eplus_domain_exists,skip'), 25);
				return '域名入库成功';
			}
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('memo' => 'eplus_domain_exists'), 25);
			throw new \Exception($domain . '域名已经在我司，不能入库!');
		}
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		$domainData = $sdk->execSdkFun(5025, array('domain' => $domain, 'registrarID' => $regId));
		if($domainData['resultCode'] != 5000)
		{
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('memo' => 'eplus_5025', 'return' => $domainData), 25);
			throw new \Exception('域名信息查找失败');
		}
		$createDate = date("Y-m-d H:i:s", strtotime($domainData['data']['createDate']));
		$expireDate = date("Y-m-d H:i:s", strtotime($domainData['data']['expireDate']));
		$tempLib = new \lib\manage\domain\TemplateLib($enameId);
		$tempList = $tempLib->getUseTemplates($enameId);
		$tempName = $tempList[0]['TempUserName'];
		$templateId = $tempList[0]['TemplateId'];
		$tempType = $tempList[0]['TemplateType'];
		$productType = DomainFunLib::getDomainProductType($domain);
		$regLib = new \lib\manage\domain\DomainRegistLib($enameId);
		$return = $regLib->domainInDbBaseTable($domain, $regId, $createDate, $expireDate, $createDate, $enameId, $tempName, $templateId, $productType);
		if(!$return)
		{
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('memo' => 'eplus_infaild', 'c' => '域名入库失败'), 25);
			throw new \Exception('域名入库失败');
		}
		$domainPushLib = new \lib\manage\domain\DomainPushLib();
		$domainPushLib->domainExtAdd($return, $enameId,$tempType);
		$eppLib = new \lib\manage\domain\DomainEppLib();
		$eppLib->setDomainRegisterStatus($domain, $regId);
		$eppLib->setDomainDns($domain, 1, array('dns1.iidns.com'), $regId);
		$pushArr = array('domain'=>$domain,'oldEnameId'=>'','oldTemplateId'=>'','oldTemplateName'=>'','registrarId'=>$regId,'tempType'=>$tempType,'templateId'=>$templateId,'newTemplateName'=>$tempName);
		try 
		{
			$queueLogic = new \logic\manage\newqueue\QueueLogic();
			$queueLogic->addQueueTask(array('Function' => 'template_push','EnameId' => $enameId, 'Data' => array($pushArr)));
		}
		catch (\Exception $e)
		{
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('memo' => 'e+error', 'params' => $pushArr), 25);
		}
		\core\Log::write("eplus,$domain,$enameId,success",'domain','eplus');
		return '域名入库成功';
	}
	
	/**
	 * 检测入库enameid是否是公司的账号
	 * @param unknown $domain
	 * @param unknown $enameId
	 * @throws \Exception
	 */
	private function checkQiangzhuEnameId($domain,$enameId)
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'ePlusTransferIn');
		$staticEnameId = $conf->enameId;
		if ( $enameId && $enameId != $staticEnameId )
		{
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('memo' => 'checkQiangZhuEnameIDFail', 'c' => '参数错误'), 25);
			throw new \Exception('enameId错误');
		}
		return $staticEnameId;
	}
	
	/**
	 * 域名转入和过户接口   给E+用
	 */
	public function transferIn($enameId,$domain,$password,$qiangZhu)
	{
		$enameId = $this->checkQiangzhuEnameId($domain, $enameId);
		//域名转入检查 是否在数据库 是否允许转入(提前检查，防止重复生成订单)
		$transferInLib = new \lib\manage\domain\DomainTransferInLib($enameId);
		$tempInfo = $transferInLib->checkIsOkToAdd($domain,false);//eplus转入特殊处理  存在的话则直提示提交成功
		if(is_array($tempInfo))
		{
			if(stripos($tempInfo[0],'域名已经存在转入域名列表')!==FALSE)
			{
				return '域名提交转入成功';
			}
			throw new \Exception($tempInfo[0]);
		}
		$domain = strtolower($domain);
		$ext = array('password'=>$password,'dnstype'=>1);
		$tempLib = new \lib\manage\domain\TemplateLib($enameId);
		$tempList = $tempLib->getUseTemplates($enameId);
		$templateId = $tempList[0]['TemplateId'];
		
		//生成订单
		$orderLib = new \interfaces\manage\Finance();
		$productName = DomainFunLib::getDomainClassAll($domain);
		$productType = DomainFunLib::getDomainProductType($domain);
		$memberLib = new \lib\manage\member\MemberLib();
		$memberInfo = $memberLib->getMemberInfoByEnameId($enameId);
		$userLevel = $memberInfo['UserGroup']; 
		$orderData = array('domain' => $domain,
					'enameId' => $enameId,
					'year' => 1,
					'productName' => '.' . $productName,
					'productType' => $productType,
					'userGroupId' => $userLevel,
					'templateId' => $templateId, 
					'type' => 2);
		$orderId = $orderLib->addProductOrder((object) $orderData);
		if(is_array($orderId) || $orderId === false)
		{
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('memo' => 'eplus_order_failed', 'c' => '订单创建失败'), 25);
			throw new \Exception('订单创建失败');
		}
		//添加转入,生成订单前检查过域名了，不需要再检查
		$transferStatus = $transferInLib->domainTransferIn($domain, $ext, $orderId, $templateId, 1, $productType,false);
		if( is_array( $transferStatus ) || FALSE == $transferStatus )
		{
			$errMsg = is_array( $transferStatus )?$transferStatus[0]:'域名提交转入失败';
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('memo' => 'eplus_transferfailed', 'c' => $errMsg), 25);
			throw new \Exception($errMsg);
		}
		return '域名提交转入成功';
	}
	
	public function domainPushEplus($enameId,$domain)
	{ 
		$lib = new \lib\manage\domain\DomainManageLib();
		$domaininfo = $lib->getDomainInfo(array('DomainName'=>$domain));
		if(!$domaininfo)
		{
			throw new \Exception('域名信息查找失败');
		}
		if($domaininfo['EnameId'] == $enameId)//当前域名所有者跟请求入库的一样的话
		{
			$this->noticeEplus($domain,$enameId,1);
			return '过户成功';
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'ePlusTransferIn');
		$staticEnameId = $conf->enameId;
		if($domaininfo['EnameId']!=$staticEnameId)
		{
			throw new \Exception('域名所有者错误');
		}
		if(!$lib->setDomainInfo(array('DomainName'=>$domain,'EnameId'=>$staticEnameId), array('EnameId'=>$enameId)))
		{
			throw new \Exception('域名过户失败');
		}
		$regId = $domaininfo['RegistrarId'];
		$tempLib = new \lib\manage\domain\TemplateLib($enameId);
		$tempList = $tempLib->getUseTemplates($enameId);
		$tempName = $tempList[0]['TempUserName'];
		$templateId = $tempList[0]['TemplateId'];
		$tempType = $tempList[0]['TemplateType'];
		$pushArr = array('domain'=>$domain,'oldEnameId'=>$staticEnameId,'oldTemplateId'=>'','oldTemplateName'=>'','registrarId'=>$regId,'tempType'=>$tempType,'templateId'=>$templateId,'newTemplateName'=>$tempName);
		try
		{
			$pushData = array('domain' => $domain, 'templateId' => $templateId,'registrarId' => $regId, 'enameId' => $enameId);
			$queueLogic = new \logic\manage\newqueue\QueueLogic();
			$queueLogic->addQueueTask(array('Function' => 'template_push','EnameId' => $enameId, 'Data' => array($pushArr)));
		}
		catch (\Exception $e)
		{
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, array('memo' => 'e+error', 'params' => $pushArr), 25);
		}
		\core\Log::write("epluspush,$domain,$enameId,success",'domain','eplus');
		return '过户成功';
	}
	
	public function noticeEplus($domain,$enameId,$status)
	{
		if(!$enameId)
		{
			return FALSE;
		}
		try
		{
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'ePlusTransferIn');
			$data = array('user'=>$conf->user,'key'=>$conf->key,'EnameId'=>$enameId,'Domain'=>$domain,'Status'=>$status);
			$notice = \common\Common::requestPost($conf->noticeUrl,$data);
			$return = (is_array($notice) || is_object($notice)) ? json_encode($notice) : $notice;
			\core\Log::write("eplusnotice,{$domain},{$enameId},{$status},{$return},","transfer","eplushnotice");
			$redis = \core\RedisLib::getInstance('common');
			$redis->del($domain.'_realEnameId');
		}
		catch (\Exception $e)
		{
			\core\Log::write("eplusnotice error,{$domain},{$enameId},{$status},".$e->getMessage(),"transfer","eplushnotice");
		}
	}
}

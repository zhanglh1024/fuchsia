<?php
namespace logic\manage\domain;
use lib\manage\domain\DomainLogsLib;
use lib\manage\common\DomainFunLib;

/**
 * 域名模板过户逻辑
 */
class DomainTemplateLogic
{

	private $tempLib;

	private $dnManageLib;

	private $domainEppLib;

	public function __construct()
	{
		$this->tempLib = new \lib\manage\domain\TemplateLib();
		$this->dnManageLib = new \lib\manage\domain\DomainManageLib();
		$this->domainEppLib = new \lib\manage\domain\DomainEppLib(); 
	}

	/**
	 * 0660 模板过户
	 *
	 * @param array $data
	 */
	public function templatePush($data)
	{
	    if(\common\Common::getRequestUser() == 'api' && \common\Common::getAppVersion() <= '3.4.5') // app 3.4.5后获取可用模板
		{
			throw new \Exception("您好，因icann新政调整，需升级到V4.0版，以便恢复业务。请前往官网下载最新版。");
		}
		$domain = isset($data['domain']) ? $data['domain'] : '';
		$templateId = isset($data['templateId']) ? $data['templateId'] : '';
		$oldTemplate = isset($data['oldTemplateId']) ? $data['oldTemplateId'] : '';
		$registrarId = isset($data['registrarId']) ? $data['registrarId'] : '';
		$tempUserName = isset($data['newTemplateName']) ? $data['newTemplateName'] : '';
		$tempType = isset($data['tempType']) ? $data['tempType'] : 0;
		$oldTempUserName = isset($data['oldTemplateName']) ? $data['oldTemplateName'] : '';
		$enameId = isset($data['enameId']) ? $data['enameId'] : 0;
		$islock = isset($data['islock']) ? $data['islock'] : 1;
		if($domain && $templateId && $tempUserName)
		{
			$tempData = array('domain' => $domain, 'templateId' => $templateId, 'registrarID' => $registrarId);
			$domainLtd = strtolower(DomainFunLib::getDomainClass($domain));
			// 判断域名是否有设置隐私保护,如果有判断模板是否为白名单，如果不是则取消隐私保护，反之直接修改域名的模版ID
			if(!$dnBaseInfo = $this->dnManageLib->getDomainInfo(array('DomainName' => $domain)))
			{
				return FALSE;
			}
			// 获取模板信息
			if(! $tempInfo = $this->tempLib->getTemplateInfoById($templateId))
			{
				DomainLogsLib::addDomainService($domain, 
					array('memo' => 'psuh_param', 'c' => '模版信息获取失败', 'param' => $data), 17);
				return FALSE;
			}
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'systemplate');
			$sysTemp = $conf->systemTempId->toArray();
			$tempData['templateName'] = $tempInfo["TemplateName"];
			//　防止队列重启浪费资源(域名非当前用户)
			if($dnBaseInfo['EnameId'] != $enameId || ($tempInfo['EnameId'] != $enameId && $templateId!=$sysTemp[0]))
			{
				return NULL;
			}
			if($dnBaseInfo['PrivacyTemp'])
			{
				if($tempInfo['CnStatus'] == 2)
				{
					$this->dnManageLib->setDomainInfo(array('DomainId' => $dnBaseInfo['DomainId']), 
						array('TemplateId' => $templateId, 'TempUserName' => $tempUserName));
					return TRUE;
				}
			}
			//过户的时候没有注册的接口跟注册下
			if(!$this->registrantChangeCheck($enameId, $domain, $dnBaseInfo['RegistrarId'], $templateId, $tempInfo))
			{
				DomainLogsLib::addDomainService($domain, array('memo' => 'template_push', 'old' => $oldTemplate, 'param' => $tempData, 'return' => 'registrant error'), 17);
				return FALSE;
			}
			
			// asia后缀可以多添加两个参数
			if($domainLtd == "asia")
			{
				$tempData['chg_extension'] = array('opnContact' => $tempInfo['data']['TemplateName'], 
						'maintainerUrl' => 'www.ename.net');
			}
			$apiInfo = $this->domainEppLib->modifyDomainModelId($tempData);
			if($apiInfo['resultCode'] != 5000 && $domainLtd == 'org' && ! empty($apiInfo['data']['msg']['resultMsg']) &&
					 false !== stripos($apiInfo['data']['msg']['resultMsg'], 'Object does not exist'))
			{
				// org重新注册模板
				$info = $this->domainEppLib->interfaceRegTemplate('ename.org', $templateId, $registrarId ? $registrarId : 41);
				if(false === $info)
				{
					return false;
				}
				// 注册org模板成功后再次帮忙重试模板过户
				$apiInfo = $this->domainEppLib->modifyDomainModelId($tempData);
			}
			DomainLogsLib::addDomainService($domain, array('memo' => 'template_push', 'old' => $oldTemplate, 'param' => $tempData, 'return' => $apiInfo), 17);
			
			//模板过户之后续处理
			$pushOk = FALSE;
			if($apiInfo['resultCode'] == 5000)
			{
				$pushOk = TRUE;
			}
			else
			{
				if($domainInfo = $this->domainEppLib->getDomainRegInfo($domain, $registrarId))
				{
					if(strtoupper($domainInfo['registrant']) == strtoupper($tempInfo['TemplateName']))
					{
						$pushOk = TRUE;
					}
				}
			}
			if($pushOk)
			{
				if($islock == 2)
				{
					//1 push锁定  2交易锁定  3转入锁定 4普通过户锁定  5隐私过户锁定
					$dnlogic = new \logic\manage\domain\DomainManageLogic();
					$dnlogic->addDomainLockInfo($domain,$enameId,'templatepush');
				}
				$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'template_push_success')); 
				$from=\common\Common::getRequestUser() == 'api' ? '2' : '1';
				$amqp->sendMq(array('time' => time(),'isCancel'=>0,'isPrivacy'=>0 ,'adminId'=>0,'from'=>$from,'isLock'=>$islock ? intval($islock) : 1,'dn' => array($domain), "uid" => intval($enameId),'ip' => \common\Common::getRequestIp()));
				$this->successAction($domain, $enameId, $templateId, $tempUserName, $tempInfo['TemplateType'], $oldTemplate, $oldTempUserName, $dnBaseInfo['DomainId']);
			}
			return $pushOk;
		}
		
		DomainLogsLib::addDomainService($domain, array('memo' => 'psuh_param', 'c' => '模板过户缺少参数', 'param' => $data), 17);
		return FALSE;
	}
	
	/**
	 * 模板过户成功后更新域名的模板id和名称，并更新新旧模板对应的模板数量
	 * @param string $domain
	 * @param int $enameId
	 * @param string $oldTempUserName
	 * @param int $templateId
	 * @param string $tempUserName
	 * @param int $tempType
	 */
	private function successAction($domain, $enameId, $templateId, $tempUserName, $tempType, $oldTemplate, $oldTempUserName, $domainId)
	{
		//更新域名的模板id和名称
		$set = array('TemplateId' => $templateId, 'TempUserName' => $tempUserName);
		if($tempType != 6 && $tempType != 7) // 如果新模板不是隐私模板，取消域名隐私保护
		{
			$set['PrivacyTemp'] = 0;
		}
		$this->dnManageLib->setDomainInfo(array('DomainId' => $domainId), $set);
		if($tempType)
		{
			$this->dnManageLib->setDomainExtInfo(array('DomainId' => $domainId), array('TemplateType' => $tempType));
		}
		if($enameId && $oldTempUserName)
		{
			DomainLogsLib::addDomainOperaterLog($domain, $enameId, '域名模板过户，上次模板名' . $oldTempUserName, 5);
		}
		//更新模板的关联域名数量
		$this->tempLib->setTempDomainCount($templateId);
		if($oldTemplate)
		{
			$this->tempLib->setTempDomainCount($oldTemplate, '-');
		}
	}
	
	/**
	 * 查看是否需要注册模板接口信息
	 * @param unknown $templateId
	 * @param unknown $registrarId  模板注册接口值 不是域名的
	 * @param string $templateInfoCn
	 * @param string $templateInfoEn
	 * 不要一直开着  过段时间要关闭下
	 */
	public function checkTemplateInterFace($templateId,$registrarId,$templateInfoCn = FALSE,$templateInfoEn = FALSE,$templateExt = FALSE)
	{
		if(in_array($registrarId,array(31,41,51)) && empty($templateInfoEn))
		{
			$templateInfoEn = $this->tempLib->getEnTemplate($templateId);
		}
		if(in_array($registrarId,array(86,82)) && empty($templateExt))
		{
			$templateExt = $this->tempLib->getTemplateExt($templateId,FALSE,$registrarId);
		}
		$return = TRUE;
		switch ($registrarId) {
			case 1:
				$return = $templateInfoCn && $templateInfoCn['RegistrarId'];
				break;
			case 71:
				$return = $templateInfoCn && $templateInfoCn['CnIdn'];
				break;
			case 31:
				$return = $templateInfoEn && $templateInfoEn['AsiaId'];
				break;
			case 41:
				$return = $templateInfoEn && $templateInfoEn['OrgId'];
				break;
			case 51:
				$return = $templateInfoEn && $templateInfoEn['PwId'];
				break;
			case 86:
			case 82:
				$return = $templateExt && $templateExt['Registrar'];
				break;
			default:
				$return = TRUE;
		}
		return $return;
	}
	
	/**
	 * 获取需要注册模板接口的registrarid
	 * @param unknown $domain
	 * @param string $registrarId
	 * @return boolean|number|number|string
	 */
	public function getDomainTemplateRegid($domain,$registrarId,$templateInfo = FALSE)
	{
		if($registrarId == 61)
		{
			return FALSE;
		}
		$domainLtd = DomainFunLib::getDomainClass($domain);
		if(DomainFunLib::isChinaDomain($domain))
		{
			return $domainLtd == "CN" ? 1 : 71;
		}
		$regiArr = array("ORG"=>41,"ASIA"=>31,"PW"=>51,"TOP"=>86,"WANG"=>86,"BIZ"=>82);
		if(array_key_exists($domainLtd, $regiArr))
		{
			return $regiArr[$domainLtd];
		}
		return FALSE;
	}
	 
	public function registrantChangeCheck($enameId,$domain,$dnRegid,$templateId,$tempInfo)
	{
		$checkRegid = $this->getDomainTemplateRegid($domain,$dnRegid);
		//无论注册成功失败先暂时都往下走
		if(FALSE !== $checkRegid && FALSE == $this->checkTemplateInterFace($templateId, $checkRegid,$tempInfo))
		{
			$tempDomain = 'ename.'.strtolower(DomainFunLib::getDomainClass($domain));
			$regEpp = $this->tempLib->interfaceRegTemplateNew($tempDomain, $tempInfo['TemplateId'],$checkRegid,$tempInfo);
			\core\Log::write("temppush,registertemp,{$domain},{$templateId},{$tempDomain},".($regEpp ? $regEpp : 0),"template","shimingzhi_push");
			$this->tempLib->updateTemplateRegid($enameId,$templateId, $regEpp);
			return $regEpp;
		}
		return TRUE;
	}
}
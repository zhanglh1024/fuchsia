<?php
namespace logic\manage\domain;
use common\Common;
use core\form\ReturnData;
use core\Response;

class TemplateLogic
{
 
	private $config;

	private $mod;

	private $domainTemplateLib;

	private $enameId;

	function __construct($enameId = '')
	{
		$this->config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$this->mod = new \models\manage\domain\TemplateMod();
		$this->domainTemplateLib = new \lib\manage\domain\TemplateLib($enameId); 
		$this->enameId = $enameId;
	} 

	/**
	 * 获取模板列表
	 */
	public function templateList($info) 
	{
		$cnnicStatus = $this->config->template->cnnic->status->toArray();
		$tempStatus = $this->config->domain->template->type->toArray();
		$provisionalId = $this->config->template->temp->id;
		$data = array('EnameId' => $info->EnameId, 'upTemplateType' => '6', 'IsShow' => 1);
		$list = array();
		$count = $this->domainTemplateLib->getTemplateCount($data); 
		$pageSize = empty($info->pagesize) ? $this->config->domain->template->pagesize : $info->pagesize;
		$p = $info->pagenum ? intval($info->pagenum) - 1 : 0;
		$offset = $p * $pageSize;
		$fields = "TemplateId,TemplateName,TempUserName,LinkCount,TemplateType,CreateTime,CnStatus,RegistrarId,Org,FirstName,LastName,Email,CdnStatus";
		if(\common\Common::getRequestUser() == 'api')
		{
			$fields = "TemplateId,TemplateName,TempUserName,LinkCount,TemplateType,CnStatus,CdnStatus,CreateTime,RegistrarId";
		}
		if($count)
		{
			$limit = $offset . ',' . $pageSize;
			$list = $this->mod->getTemplate($data, $limit, ' TemplateId desc', $fields);
			foreach($list as $key => $v)
			{
				$list[$key] = $this->domainTemplateLib->formatTemplateList($v, $cnnicStatus, $tempStatus);
			} 
		}
		if($count == 0 || ($count - $offset <= $pageSize && $count - $offset>=0))
		{ 
			$tempInfo = $this->mod->getTemplate(array('TemplateId' => $provisionalId), '', '', $fields);
			if($tempInfo)
			{
				$count = $count + 1;
			}
			else 
			{
				return array('flag' => 1, 'msg' => array('count' => $count, 'data' => $list, 'pagenum' => $p + 1));
			}
			$domainmod = new \models\manage\domain\DomainsMod();
			$LinkCount = $domainmod->getDomainCount(array('EnameId' => $info->EnameId, 'TemplateId' => $provisionalId));
			$tempInfo[0]['LinkCount'] = $LinkCount ? $LinkCount['sum'] : 0;
			$tempInfo[0]['TypeName'] = '临时模板';
			$tempInfo[0]['TemplateType'] = 0;
			$tempInfo[0]['CnnicStatusName'] = '白名单';
			$tempInfo[0]['IsAllowModify'] = '0';
			$templist = $tempInfo ? $tempInfo : array();
			$return = array_merge($list, $templist);
			return array('flag' => 1, 'msg' => array('count' => $count, 'data' => $return, 'pagenum' => $p + 1));
		}
		else
		{
			return array('flag' => 1, 'msg' => array('count' => $count, 'data' => $list, 'pagenum' => $p + 1));
		}
	}

	/**
	 * 国内用户名模板修改logic
	 *
	 * @param MY_Controller $ctrl
	 * @throws Exception
	 */
	public function editSaveChinaTemplate($info)
	{
		//过滤区号前的0
		$info->phone = ltrim(trim($info->phone),'0');
		$info->fax = ltrim(trim($info->fax),'0');
		$provisionalId = $this->config->template->temp->id;
		if($info->id == $provisionalId)
		{
			throw new \Exception("更新模板失败，请稍后重试!", '330003');
		}
		$domainloglib = new \lib\manage\domain\DomainLogsLib();
		$tempInfo = $this->domainTemplateLib->checkUserTemplate($info->id, $info->EnameId);
//   	$this->domainTemplateLib->checkTemplateEdit($info->id);
		$verifylib = new \lib\manage\verify\VerifyLib();
		$identity = $verifylib->getVerfifyIdentity($info->EnameId); 
		$comVerify = $verifylib->getVerfifyCompany($info->EnameId);
		$this->domainTemplateLib->checkStatus($tempInfo, $identity, $comVerify); // 检查模板状态为1(不通过)或4或2时才往下执行
		$this->domainTemplateLib->checkUserTempNameIsExists($info->tempname, $info->EnameId, $info->id);
		$info = $this->setUserInfo($this->config->template->weituo, $info);
		if($tempInfo['CnStatus'] == 2 || $tempInfo['CdnStatus'] == 2) // 个人模版不允许更改身份认证 企业模版不允许更改身份认证+企业认证
		{
			if(($tempInfo['TemplateType'] == 1 || $tempInfo['TemplateType'] == 4) && (trim($tempInfo['FirstName']) !=
				 trim($info->firstname) || trim($tempInfo['LastName']) != trim($info->lastname) ||
				 trim($tempInfo['Org']) != trim($info->org)))
			{
				throw new \Exception('白名单模板,不能修改企业认证/身份认证!', '330016');
			}
		}
		if(strtotime($tempInfo['CreateTime'])<strtotime('2012-01-01 00:00:00'))
		{
			throw new \Exception('2012之前的模板,不能修改!', '330037');
		}
		$data['firstname'] = $info->firstname;
		$data['lastname'] = $info->lastname;
		$data['org'] = $info->org;
		$data['name'] = $info->firstname .$info->lastname;
		$data['tempUserName'] = $info->tempname;
		$data['enameId'] = $info->EnameId;
		$data['province'] = $info->chprovince;
		$data['city'] = $info->chcity;
		$data['street'] = $info->street;
		$data['postCode'] = trim($info->postcode);
		$data['countryName'] = $this->UkToGb(strtoupper($info->country));
		$data['telCC'] = empty($tempInfo['TelCC']) ? '86' : $tempInfo['TelCC'];
		$data['phone'] =$info->phone;
		$data['phoneExt'] = '';
		$data['faxCC'] = empty($tempInfo['faxCC']) ? '86' : $tempInfo['faxCC'];
		$data['fax'] = $info->fax;
		$data['faxExt'] = '';
		$data['email'] = $info->mail;
		$oriTemplateType = $tempInfo['TemplateType'];
		$updateInfo = $this->mod->updateTemplate(array('TemplateId' => $tempInfo['TemplateId']), $data);
		if(! $updateInfo)
		{
			throw new \Exception("更新模板失败，请稍后重试!", '330003');
		}
		$edata['firstname'] = $this->domainTemplateLib->toPinyin($info->firstname);
		$edata['lastname'] = $this->domainTemplateLib->toPinyin($info->lastname);
		$edata['org'] = $tempInfo['TemplateType'] == 1?$info->enorg:$this->domainTemplateLib->toPinyin($info->org);
		$edata['province'] = $this->domainTemplateLib->toPinyin($info->chprovince);
		$edata['city'] = $this->domainTemplateLib->toPinyin($info->chcity);
		$edata['street'] = !empty($info->estreet) ? $info->estreet : $this->domainTemplateLib->toPinyin($info->street);
		$edata['postCode'] = trim($info->postcode);
		$edata['countryName'] = $this->UkToGb(strtoupper($info->country));
		$edata['telCC'] = $data['telCC'];
		$edata['phone'] = $info->phone;
		$edata['phoneExt'] = '';
		$edata['faxCC'] = $data['faxCC'];
		$edata['fax'] = $info->fax;
		$edata['faxExt'] = '';
		$edata['email'] = $info->mail;
		$edata['name'] = $edata['firstname'] . $edata['lastname'];
		$addInfo = $this->mod->updateTemplate(array('TemplateId' => $tempInfo['TemplateId']), $edata, true);
		$setStatusFaile = FALSE;
		$oldTempSet = FALSE;
		if($addInfo && $oriTemplateType == 2)//中文英文修改成功后
		{
			$oldTemp = array('templatetype'=>$info->temptype,'RegistrarId'=>$tempInfo['RegistrarId'],'CnIdn'=>$tempInfo['CnIdn']);
			// 注册国内模版
			if(!$tempInfo['RegistrarId'])
			{
				$interInfo = $this->domainTemplateLib->interfaceRegTemplate('ename.cn', $tempInfo['TemplateId'], 1, $tempInfo['TemplateName'],$info->temptype);
				$oldTemp['RegistrarId'] = $interInfo ? $interInfo : 0;
			}
			if(!$oldTemp['RegistrarId'])//英文模板接口注册失败直接当做失败处理
			{
				$setStatusFaile = true;
			}
			if(!$oldTemp['CnIdn'])
			{
				$wangluoInfo = $this->domainTemplateLib->interfaceRegTemplate('ename.公司', $tempInfo['TemplateId'], FALSE, $tempInfo['TemplateName'],$info->temptype);
				$oldTemp['CnIdn'] = $wangluoInfo ? $wangluoInfo : 0;
			}
			if($setStatusFaile)
			{
				$oldTemp['CnStatus'] = 1;
			}
			$updateInfo = $this->mod->updateTemplate(array('TemplateId' => $tempInfo['TemplateId']), $oldTemp);
			if(! $updateInfo)
			{
				\core\Log::write("uptempfailed,".json_encode($oldTemp), 'template', 'uptemplate');
			}
		}
		//顺便处理之前旧的数据org pw asia top wang接口
		if($addInfo && ($oriTemplateType == 1|| $oriTemplateType == 4))
		{
			$tmpInfo = $this->domainTemplateLib->checkUserTemplate($info->id, $info->EnameId);
			//$autoReg = array("ename.top"=>86,"ename.biz"=>82,"ename.pw"=>51,"ename.org"=>41,"ename.asia"=>31);
			$autoReg = array("ename.top"=>86,"ename.biz"=>82,"ename.pw"=>51);
			foreach($autoReg as $dn=>$value)
			{
				$this->regOldTempRegist($info->EnameId, $dn, $info->id, $value, $tmpInfo);
			}
		}
		if(! $addInfo)
		{
			$domainloglib->addDomainService('temp.' . $info->EnameId, 
				array('memo' => 'edit_template', 'param' => array($data, $edata), 'result' => '更新中文模板成功，英文失败', 
						'return' => $addInfo), 21);
			throw new \Exception("更新模板失败，请稍后重试!", '330003');
		}
		else
		{
			\core\Log::write(
				$info->EnameId . ',' . $info->id . ',' . \common\Common::getRequestIp() . ',' . json_encode($tempInfo) .
					 ',' . json_encode($data), 'template', 'uptemplate');
			$changeReturn = $this->domainTemplateLib->updateUserTemplateNew($oriTemplateType, $tempInfo['TemplateId'], 
				$tempInfo['RegistrarId'], $info->EnameId, $identity, $comVerify, $tempInfo['CnIdn']);
			if($changeReturn && (!empty($changeReturn[0]) || !empty($changeReturn[1]) || (!$setStatusFaile && $oriTemplateType == 2)))
			{
				$this->domainTemplateLib->updateDomainTempUserName($tempInfo['TemplateId'], $info->tempname, $info->EnameId);
				$isUpload = $this->domainTemplateLib->checkIsUploadWhite($tempInfo, $identity, $comVerify,$changeReturn[1]);
				//可修改白名单  旧的注册成功的英文  未审核  叉叉的可以提交白名单
				if(($oriTemplateType==2 && $setStatusFaile == FALSE) || $tempInfo['CnStatus'] == 4 || (($tempInfo['CnStatus'] == 0 || $tempInfo['CnStatus'] ==1) && $isUpload == TRUE))
				{
					$setStatus = $this->mod->updateTemplate(array('TemplateId' => $tempInfo['TemplateId']), 
						array('CnStatus' => 0));
					if($setStatus)
					{
						try
						{
							$tasklogic = new \logic\manage\queue\TaskLogic();
							$tempsInfo = array(array('templateId' => $tempInfo['TemplateId'], 'domain' => 'cnninc.upload'));
							$params = array('function' => 'cnnic_upload', 'enameId' => $info->EnameId, 'priority' => 4,
									'title' => '域名模板上传', 'data' => $tempsInfo);
							$tasklogic->addTask((object)$params);
						}
						catch (\Exception $e)
						{
							\core\Log::write($info->EnameId . ',' . $info->id . ',' . \common\Common::getRequestIp() . ',' . json_encode($tempInfo) . ',' . json_encode($data) . '添加任务失败', 'template', 'uptemplate');
						}
					}
				}
				return array('flag' => 1, 'msg' => '修改成功');
			}
			throw new \Exception("更新模板失败，请稍后重试!", '330003');
		}
	}

	/**
	 * 国际用户名模板修改logic
	 *
	 * @param
	 *
	 * @throws Exception
	 */
	public function editSaveInternetTemplate($info)
	{
		$domainloglib = new \lib\manage\domain\DomainLogsLib();
		$tempInfo = $this->domainTemplateLib->checkUserTemplate($info->id, $info->EnameId);
		$this->domainTemplateLib->checkTemplateEdit($tempInfo['TemplateId']);
		// 判断模板类型是否准确
		if($tempInfo['TemplateType'] != 2)
		{
			throw new \Exception('模板类型检测失败!请刷新页面重试!', '330004');
		}
		$domainMangeLib = new \lib\manage\domain\DomainManageLib();
		$check = $domainMangeLib->getDomainList(
			array('EnameId' => $info->EnameId, 'TemplateId' => $info->id, 
					'in' => array('DomainMyStatus' => array(11, 12)), 1), '0,1');
		if($check)
		{
			throw new \Exception('模板下有开通安全锁服务的域名，不能修改！', '330005');
		}
		$emailLib = new \lib\manage\verify\VerifyLib('email');
		$mail = $emailLib->getUserVerifyMailById($info->mail);
		if(! $mail)
		{
			throw new \Exception('不能使用未通过认证的email地址', '330006');
		}
		$this->domainTemplateLib->checkUserTempNameIsExists($info->tempname, $info->EnameId, $info->id);
		$info->mail = $mail;
		$data['tempUserName'] = $info->tempname;
		$info->firstname = $info->firstname ? $info->firstname : $info->efirstname; // 如果中文信息为空
		                                                                            // 填充英文信息
		$info->lastname = $info->lastname ? $info->lastname : $info->elastname;
		$data['firstname'] = $info->firstname;
		$data['lastname'] = $info->lastname;
		$data['org'] = $info->org ? $info->org : $info->eorg;
		$data['name'] = $info->firstname . $info->lastname;
		$data['province'] = $info->chprovince;
		$data['city'] = $info->chcity;
		$data['street'] = $info->street;
		$data['postCode'] = trim($info->postcode);
		$data['countryName'] = $this->UkToGb(strtoupper($info->country));
		$data['telCC'] = trim($tempInfo['TelCC']) ? trim($tempInfo['TelCC']) : '86';
		$data['phone'] = trim($info->phone);
		$data['phoneExt'] = '';
		$data['faxCC'] = trim($tempInfo['FaxCC']) ? trim($tempInfo['FaxCC']) : '86';
		$data['fax'] = trim($info->fax);
		$data['faxExt'] = '';
		$data['email'] = $info->mail;
		$updateInfo = $this->mod->updateTemplate(array('TemplateId' => $tempInfo['TemplateId']), $data);
		if(! $updateInfo)
		{
			throw new \Exception("更新模板失败，请稍后重试!", '330003');
		}
		$edata['firstname'] = $info->efirstname; // 如果英文信息为空填充拼音
		$edata['lastname'] = $info->elastname;
		$edata['org'] = $info->eorg;
		$edata['province'] = $this->domainTemplateLib->toPinyin($info->chprovince);
		$edata['city'] = $this->domainTemplateLib->toPinyin($info->chcity);
		$edata['street'] = $info->street;
		$edata['postCode'] = trim($info->postcode);
		$edata['countryName'] = $this->UkToGb(strtoupper($info->country));
		$edata['telCC'] = $data['telCC'];
		$edata['phone'] = trim($info->phone);
		$edata['phoneExt'] = '';
		$edata['faxCC'] = $data['faxCC'];
		$edata['fax'] = trim($info->fax);
		$edata['faxExt'] = '';
		$edata['email'] = $info->mail;
		$edata['Name'] = $info->efirstname . $info->elastname;
		$addInfo = $this->mod->updateTemplate(array('TemplateId' => $tempInfo['TemplateId']), $edata, true);
		
		if(! $addInfo)
		{
			$domainloglib->addDomainService('temp.' . $info->EnameId, 
				array('memo' => 'edit_template', 'param' => array($data, $edata), 'result' => '更新中文模板成功，英文失败', 
						'return' => $addInfo), 21);
			throw new \Exception("更新模板失败，请稍后重试!", '330003');
		}
		else
		{
			\core\Log::write(
				$info->EnameId . ',' . $info->id . ',' . \common\Common::getRequestIp() . ',' . json_encode($tempInfo) .
					 ',' . json_encode($data), 'template', 'uptemplate');
			if($this->domainTemplateLib->updateUserTemplate(2, $tempInfo['TemplateId'], $tempInfo['RegistrarId'], 
				$info->EnameId))
			{
				$this->domainTemplateLib->updateDomainTempUserName($tempInfo['TemplateId'], $info->tempname, 
					$info->EnameId);
				return array('flag' => 1, 'msg' => '修改成功');
			}
			throw new \Exception("更新模板失败，请稍后重试!", '330003');
		}
	}

	public function delTemplate($info)
	{
		$templateId = intval($info->id);
		$enameid = intval($info->EnameId);
		$domainloglib = new \lib\manage\domain\DomainLogsLib();
		if($templateId)
		{
			$mod = new \models\manage\domain\DomainSettingMod();
			$defaultTempData = $mod->getSettingByEnameId(array('EnameId' => $enameid));
			if($defaultTempData)
			{
				$defaultTemp = $defaultTempData['TransferInTemplate'] . ',' . $defaultTempData['RegistTemplate'] . ',' .
					 $defaultTempData['PushTemplate'] . ',' . $defaultTempData['TradeTemplate'];
				if(strpos($defaultTemp, trim($templateId)) !== false)
				{
					throw new \Exception("模板是默认模板，不能删除!", '330007');
				}
			}
			$cnInfo = $this->mod->getTemplate(array('TemplateId' => $templateId, 'EnameId' => $enameid));
			if($cnInfo)
			{
				$cinfo = $cnInfo[0];
				if(in_array($cinfo['TemplateType'], array(1, 4, 5, 7))) // CN域名维护临时关闭2014-05-10
				{
					\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck();
				}
				
				if($cinfo['LinkCount'])
				{
					throw new \Exception("模板有关联的域名，不能删除!", '330008');
				}
				
				// 当template_zh表中linkcount为0，搜索domains表该模板下域名数量，不为0终止删除并更新到linkcount字段
				$domainmod = new \models\manage\domain\DomainsMod();
				$domain = $domainmod->getDomainCount(array('EnameId' => $enameid, 'TemplateId' => $templateId));
				if($domain)
				{
					if($domain['sum'] > 0)
					{
						$this->mod->updateTemplate(array('TemplateId' => $templateId, 'EnameId' => $enameid), 
							array('LinkCount' => $domain['sum']));
						throw new \Exception("模板有关联的域名，不能删除!", '330008');
					}
				}
				else
				{
					$domainloglib->addDomainService('template' . $enameid, 
						array('memo' => 'del_template', 'param' => 'templateId:' . $templateId, 'result' => '查询域名表失败'), 
						21);
					throw new \Exception("删除模板失败，请稍后重试!", '340017');
				}
				$returnInfo = $this->mod->updateTemplate(array('TemplateId' => $templateId), array('IsShow' => 0));
				$domainloglib->addDomainService('template' . $enameid, 
					array('memo' => 'del_template', 'param' => 'templateId:' . $templateId, 'result' => $returnInfo), 21);
				if($returnInfo)
				{
					return array('flag' => 1, 'msg' => '成功删除模板');
				}
				else
				{
					throw new \Exception("删除模板失败，请稍后重试!", '330009');
				}
			}
		}
		throw new \Exception("模板信息有误", '330010');
	}

	/**
	 * 保存模板
	 *
	 * @throws Exception
	 */
	public function addChinaTemp($info)
	{
		//过滤区号前的0
		$info->phone = trim($info->phone);
		$info->fax = trim($info->fax);
		$info->phone = substr($info->phone,0,1) == '0' ? substr($info->phone,1) :$info->phone;
		$info->fax = substr($info->fax,0,1) == '0' ? substr($info->fax,1) :$info->fax;
		$memberlib = new \lib\manage\member\MemberLib();
		$verifylib = new \lib\manage\verify\VerifyLib();
		$memberInfo = $memberlib->getMemberBaseInfoByEnameId($info->EnameId);
		$identity = $verifylib->getVerfifyIdentity($info->EnameId);
		$version = isset($info->version) ? ($info->version == 2 ? 2 : 1) : 1;
		if(empty($memberInfo['IsMobileVerified']) && $version == 1)
		{
			throw new \Exception('请先绑定手机再创建模板！', '330011');
		}
		if($version == 2 && empty($memberInfo['IsGoogleVerified']))
		{
			throw new \Exception('Please Bind Google Authenticator', '330011');
		}
		// 检查用户模板名是否存在
		$this->domainTemplateLib->checkUserTempNameIsExists($info->tempname, $info->EnameId);
		$info = $this->setUserInfo($this->config->template->weituo, $info);
		$info->phonecc = empty($info->phonecc) ? '86' : $info->phonecc;
		$info->faxcc = empty($info->faxcc) ? '86' : $info->faxcc;
		
		$data['tempUserName'] = $info->tempname;
		$data['templateType'] = $info->temptype;
		$data['enameId'] = $info->EnameId;
		$data['firstname'] = $info->firstname;
		$data['lastname'] = $info->lastname;
		if($info->temptype == 4)
		{
			$data['org'] = $data['firstname'] . $data['lastname'];
		}
		else
		{
			$data['org'] = trim($info->org);
		}
		$data['province'] = $info->chprovince;
		$data['city'] = $info->chcity;
		$data['street'] = $info->street;
		$search = array();
		$end = mb_substr($data['city'], mb_strlen($data['city'],'UTF8')-1);
		if($end=='市')
		{
			$search = array($data['city'],mb_substr($data['city'],0,mb_strlen($data['city'],'UTF8')-1));
		}
		else
		{
			$search = array($data['city'].'市',$data['city']);
		}
		$data['street'] = str_replace($search, "", $info->street);
		$data['street'] = $data['street'] ? $data['street'] : $info->street;
		$data['postCode'] = trim($info->postcode);
		$data['countryName'] = $this->UkToGb(strtoupper($info->country));
		$data['telCC'] = trim($info->phonecc);
		$data['phone'] = $info->phone;
		$data['phoneExt'] = '';
		$data['faxCC'] = trim($info->faxcc);
		$data['fax'] = $info->fax;
		$data['faxExt'] = '';
		$data['email'] = $info->mail;
		$data['isShow'] = 1;
		$data['isDefault'] = 0;
		$edata['firstname'] = $this->domainTemplateLib->toPinyin($data['firstname']);
		$edata['lastname'] = $this->domainTemplateLib->toPinyin($data['lastname']);
		$edata['org'] = ($info->temptype == 1&&$info->enorg)?$info->enorg:$this->domainTemplateLib->toPinyin($data['org']);
		$edata['province'] = $this->domainTemplateLib->toPinyin($info->chprovince);
		$edata['city'] = $this->domainTemplateLib->toPinyin($info->chcity);
		$edata['street'] = !empty($info->estreet) ? $info->estreet : $this->domainTemplateLib->toPinyin($data['street']);
		array_walk($search, function(&$item){$item=$this->domainTemplateLib->toPinyin($item);});
		$tmp = $edata['street'];
		$edata['street'] = str_replace($search, "", $edata['street']);
		$edata['street'] = $edata['street'] ? $edata['street'] : $tmp;
		$edata['postCode'] = trim($info->postcode);
		$edata['countryName'] = $this->UkToGb(strtoupper($info->country));
		$edata['telCC'] = trim($info->phonecc);
		$edata['phone'] = $info->phone;
		$edata['phoneExt'] = '';
		$edata['faxCC'] = trim($info->faxcc);
		$edata['fax'] = $info->fax;
		$edata['faxExt'] = '';
		$edata['email'] = $info->mail;
		$edata['name'] = $edata['firstname'] . $edata['lastname'];
		$templateId = $this->domainTemplateLib->regDomainTemplate($data, $edata, $info->temptype);
		if(! $templateId)
		{
			\core\Log::write('创建中文模板失败,' . $info->EnameId, $this->config->domain->logFolder);
			throw new \Exception('系统发生错误，创建模板失败!', '330012');
		}
		else
		{
			if($this->checkIdentityCompany($info->temptype, $info, $identity, $verifylib->getVerfifyCompany($info->EnameId)))
			{
				try 
				{
					$queueLogic = new \logic\manage\newqueue\QueueLogic();
					$tempsInfo = array(array('templateId' => $templateId, 'domain' => 'cnninc.upload'));
					$taskData = array('Function' => 'cnnic_upload', 'EnameId' => $info->EnameId, 'Data' => $tempsInfo, 'Priority' => 4);
					$rs = $queueLogic->addQueueTask($taskData);
				}
				catch (\Exception $e)
				{
					$rs = false;
				}
				if(FALSE == $rs)
				{
					$domainloglib = new \lib\manage\domain\DomainLogsLib();
					$domainloglib->addDomainService('addupload' . $info->EnameId, $params, 22);
				}
			}
		}
		$templateInfo = $this->domainTemplateLib->getTempInfo($templateId);
		if(! empty($templateInfo['TemplateName']) && \common\Common::getRequestUser() == 'apicom')
		{
			return array('flag' => 1, 'msg' => $templateInfo['TemplateName']);
		}
		return array('flag' => 1, 'msg' => '创建成功');
	}

	/**
	 * 保存国际模板
	 *
	 * @throws Exception
	 */
	public function saveInternetTemplate($info)
	{
		$this->domainTemplateLib->checkUserTempNameIsExists($info->tempname, $info->EnameId);
		$info = $this->setInternetUserInfo($info);
		$info->phonecc = empty($info->phonecc) ? '86' : $info->phonecc;
		$info->faxcc = empty($info->faxcc) ? '86' : $info->faxcc;
		// $info->phoneac = strlen($info->phone) > 8 ? '' : $info->phoneac;
		// $info->faxac = strlen($info->fax) > 8 ? '' : $info->faxac;
		if(trim($info->firstname) . trim($info->lastname) == '姓名')
		{
			$info->firstname = '';
			$info->lastname = '';
		}
		$data['tempUserName'] = $info->tempname;
		$data['templateType'] = 2;
		$data['enameId'] = $info->EnameId;
		$data['firstname'] = $info->firstname && trim($info->firstname) != "姓" ? $info->firstname : $info->efirstname;
		$data['lastname'] = $info->lastname && trim($info->lastname) != "名" ? $info->lastname : $info->elastname;
		
		$data['org'] = $info->org ? $info->org : $info->eorg;
		$data['province'] = $info->chprovince;
		$data['city'] = $info->chcity;
		$data['street'] = $info->street;
		$data['postCode'] = trim($info->postcode);
		$data['countryName'] = $this->UkToGb(strtoupper($info->country));
		$data['telCC'] = trim($info->phonecc);
		$data['phone'] = trim($info->phone);
		$data['phoneExt'] = '';
		$data['faxCC'] = trim($info->faxcc);
		$data['fax'] = trim($info->fax);
		$data['faxExt'] = '';
		$data['email'] = $info->mail;
		$data['isShow'] = 1;
		$data['isDefault'] = 0;
		
		$edata['firstname'] = $info->efirstname;
		$edata['lastname'] = $info->elastname;
		$edata['org'] = $info->eorg;
		$edata['province'] = ucfirst(str_replace(' ', '', $this->domainTemplateLib->toPinyin($info->chprovince)));
		$edata['city'] = ucfirst(str_replace(' ', '', $this->domainTemplateLib->toPinyin($info->chcity)));
		$edata['street'] = $info->street;
		$edata['postCode'] = trim($info->postcode);
		$edata['countryName'] = $this->UkToGb(strtoupper($info->country));
		$edata['telCC'] = trim($info->phonecc);
		$edata['phone'] = trim($info->phone);
		$edata['phoneExt'] = '';
		$edata['faxCC'] = trim($info->faxcc);
		$edata['fax'] = trim($info->fax);
		$edata['faxExt'] = '';
		$edata['email'] = $info->mail;
		$edata['name'] = $info->efirstname . $info->elastname;
		$templateId = $this->domainTemplateLib->regDomainTemplate($data, $edata, 2);
		if(! $templateId)
		{
			\core\Log::write('创建英文模板失败,' . $info->EnameId, $this->config->domain->logFolder);
			throw new \Exception('系统发生错误，创建模板失败!', '330012');
		}
		$templateInfo = $this->domainTemplateLib->getTempInfo($templateId);
		if(! empty($templateInfo['TemplateName']) && \common\Common::getRequestUser() == 'apicom')
		{
			return array('flag' => 1, 'msg' => $templateInfo['TemplateName']);
		}
		return array('flag' => 1, 'msg' => '创建成功');
	}

	/**
	 * 查看表单只是否被修改
	 */
	private function checkEditTemp($tempInfo, $hidden)
	{
		if($tempInfo['TemplateType'] == 1 || $tempInfo['TemplateType'] == 4)
		{
			if(! empty($hidden['oldName']) && $hidden['oldName'] != $tempInfo['FirstName'] . $tempInfo['LastName'])
			{
				throw new \Exception("个人姓名出错", 330014);
			}
			if(! empty($hidden['oldCompany']) && $hidden['oldCompany'] != $tempInfo['Org'])
			{
				throw new \Exception("企业名称出错", 330015);
			}
		}
	}

	/**
	 * 提交设置默认模板
	 */
	public function setDefaultTemplate($info)
	{
		$regist = empty($info->registc) ? 0 : $info->registc;
		$transfer = empty($info->transferc) ? 0 : $info->transferc;
		$push = empty($info->pushc) ? 0 : $info->pushc;
		$trade = empty($info->tradec) ? 0 : $info->tradec;
		if(!$this->checkDefaultTempSet($info->EnameId, $regist) || !$this->checkDefaultTempSet($info->EnameId, $transfer) 
			|| !$this->checkDefaultTempSet($info->EnameId, $push) || !$this->checkDefaultTempSet($info->EnameId, $trade))
		{
			return array('flag' => 0, 'msg' => '操作失败，请重新提交!');//前台先都这么显示先
		}
		$setMod = new \models\manage\domain\DomainSettingMod();
		$setting = $setMod->getSettingByEnameId(array('EnameId' => $info->EnameId));
		if($setting)
		{
			$result = $setMod->editSetting(
				array('EnameId' => $info->EnameId, 'RegistTemplate' => $regist, 'TransferInTemplate' => $transfer, 
						'PushTemplate' => $push, 'TradeTemplate' => $trade));
			if($result)
			{
				return array('flag' => 1, 'msg' => '修改成功');
			}
			Response::setErrMsg('330013', '操作失败，请重新提交!');
			return array('flag' => 0, 'msg' => '操作失败，请重新提交!');
		}
		else
		{
			$result = $setMod->addSetting($info->EnameId, $regist, $transfer, $push, $trade);
			if($result)
			{
				return array('flag' => 1, 'msg' => '修改成功');
			}
			Response::setErrMsg('330013', '操作失败，请重新提交!');
			return array('flag' => 0, 'msg' => '操作失败，请重新提交!');
		}
	}

	/**
	 * 获取默认模板列表
	 */
	public function getDefaultTemplates($enameid)
	{	
		$info = $this->mod->getTemplate(array('EnameId' => $enameid, 'CnStatus'=>2,'IsShow' => 1), false, ' TemplateId desc','CreateTime,TemplateId,TempUserName,TemplateType,CnStatus');
		$info = $info ? $info : array();
		$cn = array();
		foreach($info as $v)
		{
			if(($v['TemplateType'] == 1 || $v['TemplateType'] == 3 || $v['TemplateType'] == 4)) 
			{
				$cn[] = $v;//CN白名单模版
			}
		}
		$return = array();
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'transwhitetemptime');
// 		if($cn && $conf->switchtop)//开放配置
// 		{
// 			foreach($cn as $key=>$info)
// 			{
// 				$extInfo = $this->domainTemplateLib->getTemplateExt($info['TemplateId'],$enameid,86);
// 				if($extInfo && $extInfo['Status'] == 2)
// 				{
// 					$return[] = $info;
// 				}
// 			}
// 		} 
		$setting = $this->domainTemplateLib->getDefaultTemplate($enameid);
		$defaultTemplate = $setting ? $setting : array();
		return array('flag' => 1, 
				'msg' => array('cn' => $return ? $return : $cn, 'defaultTemplate' => $defaultTemplate));
	}

	
	/**
	 * 获取模板详情
	 */
	public function templateDetail($info)
	{
		$cnnicStatus = $this->config->template->cnnic->status->toArray();
		$tempStatus = $this->config->domain->template->type->toArray();
		$templateId = intval($info->id);
		$provisionalId = $this->config->template->temp->id;
		$mod = new \models\manage\domain\TemplateMod();
		if($provisionalId == $templateId)
		{
			$tempInfo = $mod->getTempInfoByTempId($templateId);
			if(! $tempInfo)
			{
				throw new \Exception('模板信息错误', '330010');
			}
		}
		else
		{
			$tempInfo = $this->domainTemplateLib->checkUserTemplate($templateId, $info->EnameId);
			if($tempInfo['TemplateType'] == 2)
			{
				$tempInfo['street'] = '';
			}
			else
			{
				$tempInfo['street'] = $tempInfo['Street'];
			}
			$etempinfo = $mod->getEnTemplateByTemplateId($templateId);
			if($etempinfo)
			{
				$tempInfo['efirstname'] = $etempinfo['FirstName'];
				$tempInfo['elastname'] = $etempinfo['LastName'];
				$tempInfo['eorg'] = $etempinfo['Org'];
				$tempInfo['estreet'] = $etempinfo['Street'];
			}
// 		unset($tempInfo['Street']);
		}
		if($tempInfo)
		{
			$tempInfo = $this->domainTemplateLib->formatTemplateList($tempInfo, $cnnicStatus, $tempStatus);
			if($provisionalId == $templateId)
			{
				$tempInfo['TypeName'] = '临时模板';
			}
			return array('flag' => 1, 'msg' => $tempInfo);
		}
		Response::setErrMsg('330010', '模板信息有误！');
		return array('flag' => 0, 'msg' => '模板信息有误！');
	}

	/**
	 * 根据用户的认证信息填充姓名，公司，邮箱信息
	 *
	 * @param unknown_type $info
	 * @param DomainTemplateLib $domainTemplateLib
	 * @throws Exception
	 */
	private function setUserInfo($weituoCompany, $info)
	{
		$identityLib = new \lib\manage\verify\VerifyLib('identity');
		if($info->temptype)
		{
			$info->firstname = '';
			$info->lastname = '';
			if(empty($info->cnname))
			{
				throw new \Exception("不存在的实名认证信息", '210011');
			}
			if(! empty($info->cnname))
			{
				if(is_numeric($info->cnname))
				{
					$name = $identityLib->getUserVerifyNameById($info->cnname);
				}
				else
				{
					$name = $identityLib->getVerfifyIdentity($info->EnameId, $info->cnname);
					$name = $name ? $name[0]['Name'] : '';
				}
				if(! $name)
				{
					throw new \Exception("不存在的实名认证信息", '210011');
				}
				$info->firstname = mb_substr($name, 0, 1, 'utf-8');
				$info->lastname = mb_substr($name, 1, mb_strlen($name, 'utf-8'), 'utf-8');
			}
		}
		$emailLib = new \lib\manage\verify\VerifyLib('email');
		if(is_numeric($info->mail))
		{
			$mail = $emailLib->getUserVerifyMailById($info->mail);
		}
		else
		{
			$mail = $emailLib->getVerfifyEmail($info->EnameId, $info->mail);
			$mail = $mail ? $mail[0]['Email'] : '';
		}
		if(! $mail)
		{
			$cooper = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'cooper');
			if($this->enameId != $cooper->enameid)
			{
				throw new \Exception("不存在的电子邮件认证信息", '210013');
			}
		}
		$info->mail = strtolower($mail);
		if($info->temptype == 1)
		{
			$info->org = '';
			if(empty($info->cnorg) && empty($info->companyName) && empty($info->oldCompany))
			{
				throw new \Exception("不存在的公司认证信息", '210012');
			}
			if(! empty($info->cnorg))
			{
				$companyLib = new \lib\manage\verify\VerifyLib('company');
				if(is_numeric($info->cnorg))
				{
					$org = $companyLib->getUserVerifyCompanyById($info->cnorg);
				}
				else
				{
					$org = $companyLib->getVerfifyCompany($info->EnameId, $info->cnorg);
					$org = $org ? $org[0]['CompanyName'] : "";
				}
				if(! $org)
				{
					throw new \Exception("不存在的公司认证信息", '210012');
				}
				$info->org = $org;
			}
		}
		elseif($info->temptype == 3)
		{
			$info->org = $weituoCompany;
		}
		elseif($info->temptype == 4)
		{
			$info->org = $info->firstname . $info->lastname;
		}
		return $info;
	}

	private function setInternetUserInfo($info)
	{
		$emailLib = new \lib\manage\verify\VerifyLib('email');
		if(is_numeric($info->mail))
		{
			$mail = $emailLib->getUserVerifyMailById($info->mail);
		}
		else
		{
			$mail = $emailLib->getVerfifyEmail($info->EnameId, $info->mail);
			$mail = $mail ? $mail[0]['Email'] : "";
		}
		if(! $mail)
		{
			$cooper = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'cooper');
			if($this->enameId != $cooper->enameid)
			{
				throw new \Exception("不存在的电子邮件认证信息", '210013');
			}
		}
		$info->mail = $mail;
		return $info;
	}

	/**
	 * 检查用户提交的数据是否早已经通过了认证
	 */
	private function checkIdentityCompany($temptype, $info, $identityList, $companyList)
	{
		if($temptype != 1 && $temptype != 4)
		{
			return FALSE;
		}
		// 个人模版 如果是用户自己填写信息的话 看填写的信息是否通过认证 如果用户没有填写的话 必须有已经通过认证的信息
		$isNameVerify = FALSE;
		$isNameVerify = ! empty($info->cnname);
		if($temptype == 4)
		{
			return $isNameVerify;
		}
		$isComVerify = FALSE;
		// 企业模版的话 如果用户没有自己填写企业信息则看身份信息是否通过认证 认证则提交
		if(! empty($identityList) && ! empty($companyList))
		{
			// 用户没有自己填写的话 并且有通过认证的企业信息，则查看身份认证的
			if(! empty($info->cnorg))
			{
				return $isNameVerify;
			}
		}
		return $isComVerify && $isNameVerify;
	}

	/**
	 * 添加模版扩展数据
	 */
	public function addTemplateExt($data)
	{
		return $this->domainTemplateLib->addTemplateExt($data->templateId, $data->enameId, $data->registrar);
	}

	/**
	 * 更新模板扩展数据
	 */
	public function updateTemplateExt($data)
	{
		$templateId = $data->templateId;
		$enameId = $data->enameId;
		$status = $data->status;
		$newstatus = $data->newStatus;
		$regid = $data->registrar;
		$newregid = $data->registrarNew;
		if((empty($templateId) && empty($status) && empty($enameId) && empty($regid)) ||
			 (empty($newstatus) && $newregid===""))
		{
			throw new \Exception("更新失败");
		}
		$where = array('enameId' => $enameId, 'registrar' => $regid, 'status' => $status, 'templateId' => $templateId);
		$set = array('newstatus' => $newstatus, 'registrarNew' => $newregid);
		return $this->domainTemplateLib->setTemplateExt($where, $set);
	}

	public function getTemplateExt($data)
	{
		$templateId = $data->templateId;
		$enameId = $data->enameId;
		$regid = ! empty($data->registrar) ? $data->registrar : 0;
		return $this->domainTemplateLib->getTemplateExt($templateId, $enameId, $regid);
	}

	/**
	 * 获取域名可以使用的模板id
	 */
	public function getUseTemplates($data)
	{
		$enameId = $data->enameId;
		$templateType = $data->templateType;
		if(empty($enameId) || empty($templateType))
		{
			throw new \Exception('参数错误', 410043);
		}
		// 获取用户设置的默认模板
		$defaultTemp = $this->domainTemplateLib->getDefaultTemplate($enameId);
		$tempType = array('PushTemplate' => 'push','TransferInTemplate'=>'transfer');
		if(isset($defaultTemp[$tempType[$templateType]]) && $defaultTemp[$tempType[$templateType]])
		{
			$cn = $this->mod->getTemplate(
				array('TemplateId' => $defaultTemp[$tempType[$templateType]], 'IsShow' => 1,'CnStatus'=>2), false, 
				' TemplateId desc', 'TemplateId, TempUserName, TemplateType,TemplateName');
		}
		$returncn = empty($cn) ? array() : $cn;
		// 获取用户模板
		$info = $this->mod->getTemplate(array('CnStatus'=>2,'EnameId' => $enameId, 'IsShow' => 1,'in'=>array('TemplateType'=>array(1,4))), false, ' TemplateId desc', 
			'TemplateId, TempUserName, TemplateType,CnStatus,TemplateName');
		$info = $info ? $info : array();
		$cn = array();
		foreach($info as $v)
		{
			$cn[] = $v;
		}
		$returncn = $returncn ? $returncn : $cn;
		$sysTempId = $this->config->template->temp->id;
		$sysTempInfo = $this->mod->getTemplate(array('TemplateId' => $sysTempId, 'IsShow' => 1), false, 
			' TemplateId desc', 'TemplateId, TempUserName, TemplateType,TemplateName');
		$returncn = $returncn ? $returncn : $sysTempInfo;
		return array('cn' => $returncn);
	}

	public function UkToGb($city)
	{
		return $city == 'UK' ? 'GB' : $city;
	}
	public function regOldTempRegist($enameId,$domain,$templateId,$registrarId,$templateInfo)
	{
		$logic = new \logic\manage\domain\DomainTemplateLogic();
		if(FALSE == $logic->checkTemplateInterFace($templateId, $registrarId,$templateInfo))
		{
			$epp = new \lib\manage\domain\DomainEppLib();
			$returnEpp = $epp->interfaceRegTemplate($domain, $templateId,$registrarId,in_array($domain,array("ename.top","ename.wang")) ? array('postalType'=>'loc') : array(),FALSE,$templateInfo['TemplateType']);
			return $this->domainTemplateLib->updateTemplateRegid($enameId,$templateId, $returnEpp);
		}
		return false;
	}
	public function setTemplateLinkCount($param)
	{
		$tempLib = new \lib\manage\domain\TemplateLib(0);
		$operation = "+";
		if(isset($param['operation']) && $param['operation'])
		{
			$operation = $param['operation'];
		}
		return $tempLib->setTempDomainCount($param['templateId'], $operation);
	}
	
	public function checkDefaultTempSet($enameId,$templateId)
	{
		if(!$templateId)
		{
			return true;
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'systemplate');
		if(in_array($templateId,$conf->systemTempId->toArray()))
		{
			return true;
		}
		$templateInfo = $this->mod->getTempInfoByTempId($templateId);
		return 	$templateInfo && $templateInfo['EnameId'] == $enameId && $templateInfo['CnStatus'] == 2;	
	}
}

<?php
namespace logic\manage\domain;

class DomainServiceLogic
{

	private $dnServiceExtMod;

	function __construct()
	{
		$this->dnServiceExtMod = new \models\manage\domain\DomainServiceExtMod();
	}

	/**
	 * 获取域名记录信息
	 * domain和serviceType至少一个
	 * @param year 可选
	 * @param domain
	 * @param serviceType
	 */
	public function getDomainService($data, $isOne = false)
	{
		return $this->dnServiceExtMod->getDomainService($data, $isOne);
	}
	
	/**
	 * 获取域名记录信息数量
	 * domain和serviceType至少一个
	 * @param year 可选
	 * @param domain
	 * @param serviceType
	 */
	public function getDomainServiceCount($data)
	{
		return $this->dnServiceExtMod->getDomainServiceCount($data);
	}
	
	/**
	 * 增加域名记录信息
	 * @param content
	 * @param domain
	 * @param serviceType
	 */
	public function addDomainService($data)
	{
		if(empty($data['domain']) || empty($data['content']) || empty($data['serviceType']))
		{
			return false;
		}
		$adminId = empty($data['adminId']) ? 0 : $data['adminId'];
		$enameId = empty($data['enameId']) ? 0 : $data['enameId'];
		return $this->dnServiceExtMod->addDomainService($data['domain'], $data['content'], $data['serviceType'], $adminId, $enameId);
	}
}

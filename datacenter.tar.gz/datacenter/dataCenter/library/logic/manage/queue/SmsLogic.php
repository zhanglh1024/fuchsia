<?php
namespace logic\manage\queue;
use models\manage\queue\TemplateMod;
use core\Response;
use common;
class SmsLogic
{
	private $defaultFunc;
	private $conf;
	private $funLib;

	public function __construct()
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'queue');
		$this->defaultFunc = 'send_sms';
		$this->funLib = new \lib\manage\queue\PublicFuncLib();
	}

	/**
	 * 发短信
	 * @param string $templateId
	 * @param string $phone 
	 * @param string $tplData json_encode
	 * @param int $enameId
	 * @param int $taskId
	 * @param string $function
	 * @param int $priority 1-5，5表示直接发送，失败不入库也不重发
	 * @return boolean|int
	 */
	public function sendSms($templateId, $phone, $tplData = '', $enameId = 0, $taskId = 0, $function = 'send_sms', $priority = 5)
	{
		\core\Log::write('旧队列'.$templateId, 'queue', 'sms');
		return false;//旧队列关闭
		if(!$function)
		{
			$function = $this->defaultFunc;
		}
		if(!$priority)
		{
			$priority = 5;
		}
		//检测模板是否存在
		$tplInfo = $this->funLib->getQueTemplate($templateId);
		if(!$tplInfo)
		{
			return FALSE;
		}
		if(is_array($tplData))
		{
			$tplData = json_encode($tplData);
		}
		$tplData = htmlspecialchars_decode($tplData);
		//优先级为5则直接发送
		if(5 == $priority)
		{
			return $this->doSendSms($templateId, $phone, $tplData, $enameId, $tplInfo);
		}

		//未执行直接入库后加入队列
		$data = array();
		$data['function'] = $function;
		$data['enameId'] = $enameId;
		$data['taskId'] = $taskId;
		$data['priority'] = intval($priority);
		$data['templateId'] = $templateId;
		$data['phone'] = $phone;
		$data['data'] = $tplData;
		$data['status'] = $this->conf->sysSms->status->waiting;
		$data['created'] = time();
		$data['completed'] = $data['repeat'] = 0;
		$smsMod = new \models\manage\queue\SmsMod();
		if($queueId = $smsMod->newQueue($data))
		{
			$queRunLib = new \lib\manage\queue\QueueRunLib();
			if($queRunLib->addRunQue($queueId, $data))
			{
				return $queueId;
			}
		}
		Response::setErrMsg(340001, "添加短信队列失败");
		return FALSE;
	}

	/**
	 * 发语音短信
	 * @param string $templateId
	 * @param string $phone
	 * @param string $tplData json_encode
	 * @param int $enameId
	 * @param int $taskId
	 * @param string $function
	 * @param int $priority 1-5，5表示直接发送，失败不入库也不重发
	 * @return boolean|int
	 */
	public function sendAudioSms($templateId, $phone, $tplData = '', $enameId = 0, $taskId = 0, $function = 'send_audio_sms', $priority = 5)
	{
		\core\Log::write('旧队列'.$templateId, 'queue', 'send_audio_sms');
		return false;//旧队列关闭
		if(!$function)
		{
			$function = "send_audio_sms";
		}
		if(!$priority)
		{
			$priority = 5;
		}

		//检测模板是否存在
		$tplInfo = $this->funLib->getQueTemplate($templateId, "Id");
		if(!$tplInfo)
		{
			return FALSE;
		}

		//未执行直接入库后加入队列
		$data = array();
		$data['function'] = $function;
		$data['enameId'] = $enameId;
		$data['taskId'] = $taskId;
		$data['priority'] = intval($priority);
		$data['templateId'] = $templateId;
		$data['phone'] = $phone;
		$data['data'] = $tplData;
		$data['status'] = $this->conf->queParams->status->waiting;
		$data['created'] = time();
		$data['completed'] = $data['repeat'] = 0;
		$audioSmsMod = new \models\manage\queue\AudioSmsMod();
		if($queueId = $audioSmsMod->newQueue($data))
		{
			$queRunLib = new \lib\manage\queue\QueueRunLib();
			if($queRunLib->addRunQue($queueId, $data))
			{
				return $queueId;
			}
		}
		Response::setErrMsg(340003, "添加语音队列失败");
		return FALSE;
	}

	/**
	 * 直接发送短信
	 * @param string $templateId
	 * @param string $phone
	 * @param string $tplData
	 * @param int $enameId
	 * @param array $tplInfo
	 * @return boolean|int
	 */
	private function doSendSms($templateId, $phone, $tplData, $enameId, $tplInfo)
	{
		//替换模板数据
		$templateData = $this->funLib->transData($tplInfo, json_decode($tplData, TRUE), $enameId);
		//发送短信
		$smsLib = new \lib\manage\queue\SysSmsLib();
		$sendResult = $smsLib->sendSms($phone, $templateData['AltBody']);
		if(!$sendResult)
		{
			Response::setErrMsg(340004, "发送短信失败");
			return FALSE;
		}

		//发送成功，写入实时短信表
		$data = array();
		$data['enameId'] = $enameId;
		$data['templateId'] = $templateId;
		$data['phone'] = $phone;
		$data['data'] = $tplData;
		$data['status'] = $this->conf->sysSms->status->success;
		$data['msgid'] = $sendResult;
		$smsMod = new \models\manage\queue\SmsMod();
		if($smsId = $smsMod->addSms($data))
		{
			return $smsId;
		}
		Response::setErrMsg(340005, "短信写入队列信息失败");
		return FALSE;
	}
	
	/**
	 * 发送站内信
	 * 
	 * @param int $enameId
	 * @param string $templateId
	 * @param array $data
	 * @param int $type
	 * @return boolean
	 */
	public function sendSiteMsg($enameId, $templateId, $data, $type = 12, $status = 0)
	{
		// 获取模板
		$templateLib = new \lib\manage\newqueue\QueueTemplateLib();
		$tplInfo = $templateLib->getInfoByTemplateName($templateId);
		if(!$tplInfo)
		{
			\lib\manage\domain\DomainLogsLib::addDomainService('other', 
				array('memo' => 'site_msg_error', 'enameid' => $enameId, 'templateName' => $templateId), 19, 0, '系统');
			return FALSE;
		}
		$info = array();
		$info['EnameId'] = $enameId;
		$info['SendId'] = '10001';
		$info['MessageType'] = $type;
		$info['Status'] = $status; // 未读
		$info['SendTime'] = date("Y-m-d H:i:s");
		$info['ViewTime'] = '';
		$templateData = $templateLib->substituteTemplateData($tplInfo, $data);
		$info['Content'] = $templateData['HtmlContent'];
		$info['Title'] = $templateData['TemplateTitle'];
		$info['Data'] = $data;
		$info['TemplateId'] = $templateId;
		$messageMod = new \models\manage\member\MemberMessageMod();
		if($messageMod->addInfo($info))
		{
			// 非联盟的站内信添加redis缓存
			if($type != 99)
			{
				\common\Sync::syncSiteMsgCount($enameId, 1);
			}
			return TRUE;
		}
		\lib\manage\domain\DomainLogsLib::addDomainService('other', 
			array('memo' => 'site_msg_error',
				'param' => $enameId . ',tempale:' . $templateId), 19, 0, '系统');
		Response::setErrMsg(340006, "站內信发送失败");
		return FALSE;
	}
}

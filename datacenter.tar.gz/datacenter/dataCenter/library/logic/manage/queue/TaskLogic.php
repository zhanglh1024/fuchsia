<?php
namespace logic\manage\queue;
use core\Response;
class TaskLogic
{
	private $conf;
	private $errCode;
	private $errMsg;

	public function __construct()
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'queue');
	}

	/**
	 * 添加批量任务
	 * @param object $params function enameId title data total status created 非必须 priority默认1 hidden默认0是否隐藏队列的标识
	 * @return boolean|array
	 */
	public function addTask($params)
	{
		\core\Log::write('旧队列'.var_export($params, true), 'queue', 'task');
		if(!$params->function)
		{
			Response::setErrMsg(340007, 'function有误');
			return FALSE;
		}
		$data = array();
		$data['total'] = count($params->data);
		if($data['total'] <= 0)
		{
			Response::setErrMsg(340008, 'data有误');
			return FALSE;
		}
		$data['function'] = $params->function;
		$data['enameId'] = $params->enameId;
		$data['title'] = $params->title;
		$data['data'] = $params->data;
		$data['priority'] = empty($params->priority) ? 1 : intval($params->priority);
		$data['status'] = $this->conf->queParams->status->waiting;
		$data['created'] = time();
		$data['hidden'] = empty($params->hidden) ? 0 : 1;
		//数据入队列总库
		$taskMod = new \models\manage\queue\TaskMod();
		$tasksId = $taskMod->addTasks($data);
		if(!$tasksId)
		{
			Response::setErrMsg(340009, '批量任务添加失败');
			return FALSE;
		}
		//添加任务数据分支到队列详细列表and添加任务到队列执行表
		$taskDetMod = new \models\manage\queue\TaskDetMod();
		$queRunLib = new \lib\manage\queue\QueueRunLib();
		$queueTotal = 0;
		foreach($params->data as $key => $taskQueueData)
		{
			$queueData = array();
			$queueData['enameId'] = $data['enameId'];
			$queueData['taskId'] = $tasksId;
			$queueData['function'] = $data['function'];
			$queueData['data'] = json_encode($taskQueueData);
			$queueData['priority'] = intval($data['priority']);
			$queueData['created'] = $data['created'];
			$queueData['status'] = $this->conf->queParams->status->waiting;
			$queueData['completed'] = $queueData['repeat'] = 0;
			$queueId = $taskDetMod->newQueue($queueData);
			if($queueId)
			{
				$queRunLib->addRunQue($queueId, $queueData);
				$queueTotal++;
				$queueIds[] = $queueId;
			}
		}
		if(!$queueTotal)
		{
			Response::setErrMsg(340010, '批量任务添加到详细表失败');
			return FALSE;
		}
		return array('queueTotal' => $queueTotal, 'total' => $data['total'], 'taskId' => $tasksId,
				'queueIds' => $queueIds);
	}
}

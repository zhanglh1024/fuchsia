<?php
namespace logic\manage\queue;
use core\Response;
class MailLogic
{
	private $defaultFunc;
	private $conf;
	private $funLib;

	public function __construct()
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'queue');
		$this->defaultFunc = 'sendmail';
		$this->funLib = new \lib\manage\queue\PublicFuncLib();
	}
 
	/**
	 * 发邮件
	 * @param string $templateId
	 * @param string $email
	 * @param string $tplData json_encode 模板变量值
	 * @param int $enameId
	 * @param int $taskId
	 * @param string $function
	 * @param int $priority 1-5，5表示直接发送
	 * @return boolean|int
	 */
	public function sendMail($templateId, $email, $tplData = '', $enameId = 0, $taskId = 0, $function = 'sendmail',	$priority = 5)
	{ 
		\core\Log::write('旧队列'.$templateId, 'queue', 'mail');
		return false;//旧队列关闭
		if(!$function)
		{
			$function = $this->defaultFunc;
		}
		if(!$priority)
		{
			$priority = 5;
		}

		//检测模板是否存在
		$tplInfo = $this->funLib->getQueTemplate($templateId);
		if(!$tplInfo)
		{
			return FALSE;
		}
		
		//没有邮箱则获取账号邮箱
		if(!$email && $enameId)
		{
			$memberMod = new \models\manage\member\EmemberMod();
			$email = $memberMod->getEmailById($enameId);
		}
		if(!$email)
		{
			return FALSE;
		}

		$mailMod = new \models\manage\queue\MailMod();
		if(is_array($tplData))
		{
			$tplData = json_encode($tplData);
		}
		$tplData = htmlspecialchars_decode($tplData);
		$data = array();
		$data['function'] = $function;
		$data['enameId'] = $enameId;
		$data['taskId'] = $taskId;
		$data['priority'] = intval($priority);
		$data['templateId'] = $templateId;
		$data['email'] = $email;
		$data['data'] = $tplData;
		$data['status'] = $this->conf->queParams->status->waiting;
		$data['created'] = time();
		$data['completed'] = $data['repeat'] = 0;

		//优先级为5则直接发送
		if(5 == $priority)
		{
			//替换模板
			$templateData = $this->funLib->transData($tplInfo, json_decode($tplData, TRUE));//数据
			$templateData["HtmlBody"] = $this->funLib->transHtmlData($templateId, $templateData["HtmlBody"]);//邮件html

			//允许重复执行3次
			$cnt = 0;
			$mailLib = new \lib\manage\queue\MailLib();
			while($cnt < 3 && ($sendResult = @$mailLib->send($email, $templateData["Subject"], $templateData["AltBody"], $templateData["HtmlBody"], $templateData["TemplateId"])) == FALSE)
			{
				$cnt++;
			}

			if($sendResult)
			{
				$data['status'] = $this->conf->queParams->status->success;
				$data['completed'] = time();
				$queueId = $mailMod->newQueue($data);
				return $queueId;
			}
		}

		//未执行或者首次执行失败直接入库后加入队列
		if($queueId = $mailMod->newQueue($data))
		{
			$queRunLib = new \lib\manage\queue\QueueRunLib();
			if($queRunLib->addRunQue($queueId, $data))
			{
				return $queueId;
			}
		}
		Response::setErrMsg(340001, "添加邮件队列失败");
		return FALSE;
	}
}

<?php
namespace logic\manage\product;
use Thrift\Exception\TException;
use Thrift\Transport\TSocket;
use Thrift\Factory\TTransportFactory;
use Thrift\Factory\TBinaryProtocolFactory;
use Thrift\Protocol\TMultiplexedProtocol;

class ActivityLogic
{

	private $acMod;
	
	private $conf;
	
	private $client;
	
	private $protocol;
	
	private $transport;
	
	private $socket;
	
	private $proConfig;
	
	public function __construct()
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', "financeRpc");
		$this->proConfig = new \Yaf\Config\Ini(APP_PATH . '/conf/product.ini', 'product');
		$this->acMod = new \models\manage\product\ActivityMod();
	}
	
	public function addActivity($params)
	{
		if(empty($params['acBusinessType']))
		{
			throw new \Exception('业务类型错误');
		}
		return $this->acMod->addActivity($params);
	}
	
	public function getActivityCount($params)
	{
		return $this->acMod->getActivityCount($params);
	}
	
	public function getActivityList($params)
	{
		return $this->acMod->getActivityList($params);
	}
	
	/**
	 * 获取产品活动信息
	 */
	public function getActivityInfo($params)
	{
		if(empty($params['ac_id']))
		{
			throw new \Exception('产品活动ID错误');
		}
		return $this->acMod->getActivityList($params, true);
	}
	
	public function setActivity($params)
	{
		if(empty($params['ac_id']))
		{
			throw new \Exception('产品活动ID错误');
		}
		return $this->acMod->setActivity($params);
	}
	
	/**
	 * 更新美金汇率
	 */
	public function updateProductRate($rate)
	{
		$proConf = $this->proConfig->toArray();
		$proRateFile = empty($proConf['productRateFile']) ? false : $proConf['productRateFile'];
		if(!$proRateFile)
		{
			throw new \Exception('product rate file config error');
		}
		return file_put_contents($proRateFile, $rate);
	}
	
	/**
	 * 获取美金汇率
	 */
	public function getProductRate($isGo = true)
	{
		if($isGo)
		{
			include_once APP_PATH . '/dataCenter/library/lib/manage/thrift/common.php';
			\common\thrift\ThriftStar::startup("finance");
			$this->socket = new TSocket($this->conf->serverHost, $this->conf->serverPort);
			$this->socket->setRecvTimeout($this->conf->timeout);
			$transportFactory = new TTransportFactory();
			$protocolFactory = new TBinaryProtocolFactory();
			$this->transport = $transportFactory->getTransport($this->socket);
			$this->protocol = $protocolFactory->getProtocol($this->transport);
			$this->transport->open();
			$mp = new TMultiplexedProtocol($this->protocol, "finance");
			$client = new \finance\FinanceServiceClient($mp);
			$result = $client->GetExchangeRate();
			$proRate = $result->ExchangeRate;
			$this->transport->close();
			//如果go返回的为0则走文件获取，否则更新文件。
			if(!empty($proRate))
			{
				$this->updateProductRate($proRate);
				return $proRate;
			}
		}
		$proConf = $this->proConfig->toArray();
		$proRateFile = empty($proConf['productRateFile']) ? false : $proConf['productRateFile'];
		$proRate = false;
		if($proRateFile && file_exists($proRateFile))
		{
			$proRate = file_get_contents($proRateFile);
		}
		return $proRate;
	}
}

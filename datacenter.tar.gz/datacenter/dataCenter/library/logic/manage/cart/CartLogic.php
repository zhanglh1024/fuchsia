<?php
namespace logic\manage\cart;
use core\form\ReturnData;
use core\Response;
use lib\manage\common\DomainFunLib as DomainFunLib;
use lib\manage\common\DomainOpenLib as DomainOpenLib;
use lib\manage\domain\DomainQueryLib;


class CartLogic
{
	public $enameId; 
	public $cartLib;
	public function __construct($enameId)
	{
		$this->cartLib = new \lib\manage\cart\CartLib($enameId);
		$this->enameId = $enameId;
	} 

	/**
	 * 购物车结算
	 */
	public function overCart($cartData)
	{
		$freqLib = new \lib\manage\domain\DomainQueryLib($this->enameId);
		$freqLib->interLimit('cartResult');
		$postData = $this->cartLib->getResultData($cartData);
		$cartConf = new \Yaf\Config\Ini(APP_PATH . '/conf/cart.ini', 'cart');
		$memberLib = new \lib\manage\member\MemberLib();
		$memberInfo = $memberLib->getMemberInfoByEnameId($this->enameId); 
		$dnManage = new \lib\manage\domain\DomainManageLib();
		if(!$memberInfo)
		{
			throw new \Exception('用户信息获取失败', 311006);
		}
		$email = $memberInfo['Email'];
		$userLevel = $memberInfo['UserGroup'];
		$allMoney = 0;
		$domains = array();
		$priceError = array();
		$domainTmp = array();
		$domainPriceLib = new \lib\manage\domain\DomainPriceTempLib($this->enameId);
		foreach($postData as $k => $v)
		{
			if($v['type'] != 1)
			{
				continue;
			}
			$domainTmp[] = $v['domain'];
		} 
		$domainRegBlack = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini','domain_register_black');
		$domainRegBlackArr = $domainRegBlack->domain_register_black->toArray();
		$domainRegBlackStrArr = $domainRegBlack->domain_register_black_string->toArray();
		$domainRegBlackKey = $domainRegBlack->domain_register_black_key;
		$redis = \core\RedisLib::getInstance('manage', false);
		$notRepeateRenew = isset($cartData->notRepeateRenew) ? $cartData->notRepeateRenew : 0; // 1不重复续费 0 重复续费,默认重复续费
		\core\Log::write(json_encode(array('enameId' => $this->enameId, 'notRepeateRenew' => $notRepeateRenew)), 'cart', 
			'notRepeateRenew'); // 记录不重复续费勾选状态
		$domainPremiumMod=new \models\manage\domain\DomainPremiumMod();
		foreach($postData as $v)
		{
			$domainBlack = str_replace($domainRegBlackStrArr, '----', $v['domain']);
			if(\lib\manage\common\DomainFunLib::isChinaDomain($v['domain']) && $v['type'] == 1 && (strpos($domainBlack,'----') !== false || stripos($domainRegBlackKey, ','.\lib\manage\common\DomainFunLib::getDomainBody($v['domain']).',') !==false))
			{
				$priceError[] = array('domain' => $v['domain'], 'msg' => '该域名不能注册，请联系客服','cart' => FALSE, 'code' => 60011);
				continue;
			}
			if(in_array(strtolower($v['domain']), $domainRegBlackArr) && $v['type'] == 1)
			{
				$priceError[] = array('domain' => $v['domain'], 'msg' => '该域名不能注册，请联系客服','cart' => FALSE, 'code' => 60011);
				continue;
			}
			if(\lib\manage\common\DomainFunLib::getDomainClass($v['domain'])=='TV')
			{
				$domainPremiumList=$domainPremiumMod->getDomainPremiumList(array('in'=>array('dp_domain'=>array($v['domain']))));
				if(!empty($domainPremiumList))
				{
					throw new \Exception($v['domain'].'溢价域名,APP不能续费/转入/注册', 60017);
				}
			}
			//直接过滤 注册续费转入
			if(\lib\manage\common\DomainFunLib::isChinaDomain($v['domain']) && FALSE == \lib\manage\common\DomainOpenLib::tmpFuncOpenCheck(FALSE))
			{
				$priceError[] = array('domain' => $v['domain'], 'msg' => 'CNNIC接口维护','cart' => FALSE, 'code' => 60009);
				continue;
			}
			if(DomainFunLib::checkIsDownDomain($v['domain']) && in_array($v['type'],array(1,2)))
			{
				$priceError[] = array('domain' => $v['domain'], 'msg' => $cartConf->errorMsg->priceErr,
						'code' => 60002, 'cart' => FALSE);
				continue;
			}
			$queryLib = new \lib\manage\domain\DomainQueryLib($this->enameId);
			$coupon = '';
			if($v['type'] == 1)
			{
				$coupon = !empty($cartData->couponContent1) ? $cartData->couponContent1 : '';
			}
			else if($v['type'] == 2)
			{
				$coupon = !empty($cartData->couponContent2) ? $cartData->couponContent2 : '';
			}
			else if($v['type'] == 3)
			{
				$coupon = !empty($cartData->couponContent3) ? $cartData->couponContent3 : '';
			}
			$domain = $v['domain'];
			$templateId = isset($v['templateid']) ? $v['templateid'] : false;
			$shopType = $v['type'];
			$year = $v['year'];
			$ext = empty($v['ext']) ? '' : (is_string($v['ext']) ? json_decode($v['ext'], true) : $v['ext']);
			$this->checkDnsPass($shopType, $ext);
			$productType = \lib\manage\common\DomainFunLib::getDomainProductType($domain);
			$specialPrice = $suffix = $expDate = $registarId = $remark = '';
			$isCoop = FALSE;//目前转接口的先都只让续费1年最多
			if($shopType == 3)//域名续费
			{
				$domainInfo = $dnManage->getDomainInfo(array('DomainName' => $domain), 'DomainProperty,IsRealName,ExpDate,RegDate,DomainMyStatus,RegistrarId,TemplateId');
				if(empty($domainInfo))
				{
					$priceError[] = array('domain' => $domain, 'msg' => $cartConf->errorMsg->dnError,
							'cart' => TRUE, 'code' => 60008);
					continue;
				}
				if(FALSE == \lib\manage\common\DomainFunLib::checkisRealDomainRenew($domain, $domainInfo['IsRealName'], $domainInfo['RegDate']))
				{
					$priceError[] = array('domain' => $domain, 'msg' => "域名未实名",'cart' => FALSE, 'code' => 60016);
					continue;
				}
				if($notRepeateRenew ==1)//不重复续费
				{
					$isRenewalApp = $redis->get($this->enameId . strtolower($domain) . 'for_repeate_renewal_mark');
					$isRenewalPc = $redis->get($this->enameId . strtolower($domain) . 'for_repeate_renewal_mark_pc');
					if($isRenewalApp||$isRenewalPc)
					{
						$priceError[] = array('domain' => $domain, 'msg' => $cartConf->errorMsg->repeaterenewErr,
							'cart' => TRUE, 'code' => 60015);
						continue;
					}
				}
				if($domainInfo['RegistrarId']==11)//11接口不允许续费
				{
					throw new \Exception('该域名暂时不能操作。', 359007);
				}
				$productType = $domainInfo['DomainProperty'];
				$expDate = $domainInfo['ExpDate'];
				$registarId = $domainInfo['RegistrarId'];
				$isCoop = $domainPriceLib->checkIscoopDomain($shopType, $domain, $domainInfo['RegistrarId'], $domainInfo['ExpDate'], $domainInfo['RegDate'], $domainInfo['DomainMyStatus']);
			}
			$suffix = \lib\manage\common\DomainFunLib::getDomainClassAll($domain);
			$domainClass = DomainFunLib::getDomainClass($domain);
			$checkArr = $queryLib->checkDomainYears($domain, $shopType, $year);//主要活动域名 珍品域名
			$year = $checkArr['year'];
			$specialPrice = $checkArr['specialPrice'];
			$remark = $checkArr['remark'];
			$productName = \lib\manage\common\DomainFunLib::getDomainClassAll($domain);
			if(FALSE!==$specialPrice)
			{
				$price = sprintf("%.2f", $specialPrice);
			}
			else
			{
				$price = $queryLib->getDomainPrice($domain, $suffix, $shopType, $productType);
			}
			if(FALSE === $price)
			{
				$priceError[] = array('domain' => $v['domain'], 'msg' => $cartConf->errorMsg->priceErr,
						'code' => 60002, 'cart' => FALSE);
				continue;
			}
			$domainsArr = array('domain' => $domain, 'enameId' => $this->enameId, 'year' => $isCoop ? 1 : $year,
					'promoCode' => $coupon, 'productName' => '.' . $productName, 'email' => $email,
					'userGroupId' => $userLevel, 'expDate' => $expDate, 'productType' => $productType,
					'templateId' => $templateId, 'type' => $shopType, 'remark' => $remark, 'ext' => $ext,
					'registarId' => $registarId);
			if($isCoop)
			{
				$domainsArr['remarkHide'] = "合作接口域名续费转接口";
				$domainsArr['coopToRenew'] = true;
			}
			if(FALSE!==$specialPrice)
			{
				$domainsArr['specialPrice'] = TRUE;
				$domainsArr['price'] = $specialPrice;
			}
			if($shopType == 3)
			{
				$domainsArr['notRepeateRenew'] = $notRepeateRenew;
			}
			$allMoney += $price * $year;
			$domains[] = $domainsArr;
		}
		if(empty($domains))
		{
			return $priceError;
		}
		$financeLib = new \lib\manage\finance\FinanceInfoLib($this->enameId);
		$financeInfo = $financeLib->getUserFinance($this->enameId);
		$enableMoney = floatval(str_replace(',', '', $financeInfo['UseMoney']));
		$data = array();
		$manageConf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini');
		$tempTemplateId = $manageConf->systemplate->systemTempId->toArray();
		$tempTemplateId = $tempTemplateId[0];
		$domainLtdArray = $manageConf->domain->domainLtd->toArray();
		$registLib = new \lib\manage\domain\DomainRegistLib($this->enameId);
		$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'domain_regist_success')); 
		foreach($domains as $v)
		{
			$errorMsg = $this->cartLib->singleDomainResult($v, $registLib, $tempTemplateId, $domainLtdArray);
			if(!empty($errorMsg))
			{
				$data[] = array('domain' => $v['domain'], 'msg'=> $this->cartLib->cartConf->errorMsg->overCartErr, 
					'cart' => $shopType == 3 ? FALSE : $this->cartLib->recart, 'code' => 60001);
				continue;
			}
			if($shopType == 1)
			{
				$amqp->sendMq(
					array('expdate' => date('Y', time()) + $v['year'] . '-' . date('m-d',time()),'uid' => $this->enameId, 'dn' => $v['domain'], 'time' => time(), 'ip' => \common\common::getRequestIp(), 'from' => 2));
			}
			$data[] = array('domain' => $v['domain'], 'msg' => '成功', 'code' => 60000);
		}
		if($priceError)
		{
			$data = array_merge($data, $priceError);
		}
		\core\Log::write(json_encode($data), 'cart');
		return $data;
	}

	/**
	 * 获取域名的价格和可以用的模板--注册年限默认10年 转入1年  续费的话根据过期时间计算
	 * app
	 */
	public function getDomainPrice($queryData)
	{
		$enameId = $queryData->enameId;
		$domainList = explode(",", $queryData->domains);
		$shopType = $queryData->shopType;
		$domainPriceTemp = array();
		$tempLib = new \lib\manage\domain\TemplateLib($enameId);
		$priceTempLib = new \lib\manage\domain\DomainPriceTempLib($enameId);
		$tvDomain=array();
		foreach($domainList as $domain)
		{
			$domainProperty = '';
			$isTrans = FALSE;
			if($shopType == 3)//续费
			{
				$templateId = 0;
				$domainInfo = $this->checkDomainInfo($domain, $enameId);
				$templateId = $domainInfo['TemplateId'];
				$domainProperty = $domainInfo['DomainProperty'];
				$this->domainRenewCheck($domainInfo);
				$isTrans = $priceTempLib->checkIscoopDomain($shopType, $domain, $domainInfo['RegistrarId'], $domainInfo['ExpDate'], $domainInfo['RegDate'], $domainInfo['DomainMyStatus']);
			}
			$priceTemp = $priceTempLib->priceTemplate($enameId, $shopType, $domain,'',empty($domainProperty) ? \lib\manage\common\DomainFunLib::getDomainProductType($domain) : $domainProperty);
            if($shopType == 3)
			{
				$priceTemp['vsp'] = $this->checkIsWhiteTemp($domain, $templateId) ? 1 : 0;
			}
			if($shopType == 3 && isset($priceTemp['year']) && $isTrans)
			{
				$priceTemp['year'] = 1;
			}
			$domainPriceTemp[] = $priceTemp;
			if(\lib\manage\common\DomainFunLib::getDomainClass($domain)=='TV')
			{
				$tvDomain[]=$domain;
			}
		}
		if(!empty($tvDomain))
		{
			$domainPremiumMod=new \models\manage\domain\DomainPremiumMod();
			$domainPremiumList=$domainPremiumMod->getDomainPremiumList(array('in'=>array('dp_domain'=>$tvDomain)));
			if(!empty($domainPremiumList))
			{
				$dp_domain=array_column($domainPremiumList, 'dp_domain');
				$yijiaDomian=implode(',', $dp_domain);
				throw new \Exception($yijiaDomian.'是溢价域名，溢价域名不支持APP转入/注册/续费', 60017);
			}
		}
		//net域名活动
		$activityConf = new \Yaf\Config\Ini(APP_PATH . '/conf/huodong.ini', 'activity');
		$balance = 0.00;
		if($enameId)//登录状态的查看余额
		{
			$financeLib = new \interfaces\manage\Finance();
			$balance = $financeLib->getUserFinance($enameId);
			$balance = $balance && !empty($balance['UseMoney']) ? $balance['UseMoney'] : '0.00';
		}
		return array('domainTempInfo' => $this->checkDomainBaseCode64($domainPriceTemp, $shopType), 'balance' => $balance);
	}

	/**
	 * 续费时候检查域名是否是当前用户的
	 */
	private function checkDomainInfo($domain, $enameId)
	{
		$dnManage = new \lib\manage\domain\DomainManageLib();
		$domainInfo = $dnManage->getDomainInfo(array('DomainName' => $domain, 'EnameId' => $enameId));
		if($domainInfo)
		{
			return $domainInfo;
		}
		throw new \Exception($domain . "域名信息获取失败", 311005);
	}
	
	/**
	 * 注册的时候是否通过了实名制  以批量的方式检测
	 * @param unknown $domainArr
	 */
	private function checkDomainBaseCode64($domainPriceTemp,$shoptype)
	{
		if($shoptype != 1 && $shoptype != 2)//目前只有注册检测 续费通过模板来检测
		{
			return $domainPriceTemp;
		}
		$checkDomains = array();
		$nocheck = array();
		$tmp = array();
		foreach($domainPriceTemp as &$domainInfo)
		{
			//可以注册的域名才去检测
			if($domainInfo['code'] == 60000 && DomainFunLib::checkIsVspDomainLtd($domainInfo['domain']))
			{
				$domainInfo['vsp'] = 0;//默认先没通过
				$tmp[] = $domainInfo;
				$checkDomains[] = $domainInfo['domain'];
			}
			else//其他非com net的或者不可注册的统统算通过实名制
			{
				//不用检测的数据
				$domainInfo['vsp'] = 1;
				$nocheck[] = $domainInfo;
			}
		}
		if(!$checkDomains)
		{
			return $domainPriceTemp;
		}
		$businessCodeArr = DomainQueryLib::getDomainBusinessCode($checkDomains);
		if(!$businessCodeArr)//所有接口异常的数据
		{
			return array_merge($nocheck,$tmp);
		}
		$baseArr = DomainQueryLib::getDomainBase64Code($businessCodeArr);
		foreach($tmp as &$domainInfo)
		{
			if(!$baseArr)
			{
				$domainInfo['vsp'] = 1;
				continue;
			}
			if(array_key_exists($domainInfo['domain'], $baseArr) && in_array($baseArr[$domainInfo['domain']],array(1,2)))
			{
				$domainInfo['vsp'] = 1;//可以查询到base64的 审核通过跟审核中的都可以
			}
			else
			{
				$domainInfo['vsp'] = 0;//审核不通过的 不允许注册转入
			}
		}
		return array_merge($nocheck,$tmp);
	}
	
	/**
	 * 检测转移密码  dns类型
	 */
	private function checkDnsPass($type, $dnspass)
	{
		if($type == 2)
		{
			if(!is_array($dnspass) || empty($dnspass['password']) || empty($dnspass['dnstype']))
			{
				throw new \Exception("转移密码和dns类型不能为空", 320020);
			}
		}
		return TRUE;

	}

	/**
	 * 查看域名是否可以续费--主要是7天限制
	 */
	public function domainRenewCheck($info)
	{
		if($info['RegistrarId'] == 12)
		{
			return TRUE;
		}
		
	    //webcc接口下的.cc域名暂停续费功能
	    if($info['RegistrarId'] == 61 && in_array($info['DomainLtd'],array(3,4,11,16,17)))
		{
			throw new \Exception($info['DomainName'].':该域名暂不支持续费，请转接口。', 359009);
		}
		// 正在转出的域名不让续费功能
		if($info['DomainMyStatus'] == 5)
		{
			throw new \Exception($info['DomainName'] . ':该域名正在转出暂不支持续费');
		}
		if((\lib\manage\common\DomainFunLib::isChinaDomain($info['DomainName']) && $info['RegDate'] > gmdate('Y-m-d H:i:s', time() - 604800)))//cnnic管辖域名七天后才可以续费
		{
			//公司和网络后缀注册和过期是同一天的直接通过
			$str = \lib\manage\common\DomainFunLib::getDomainClass($info['DomainName']);
			if($str == '公司' || $str == '网络')
			{
				if(substr($info['RegDate'], 0, 10) != substr($info['ExpDate'], 0, 10))
				{
					throw new \Exception("新注册CN域名未满7天，暂无法续费", 320021);
				}
			}
			else
			{
				throw new \Exception("新注册CN域名未满7天，暂无法续费", 320021);
			}
		}
		if(\lib\manage\common\DomainFunLib::isChinaDomain($info['DomainName']) && !\lib\manage\common\DomainFunLib::isWangluoDomain($info['DomainName']))
		{
			\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck();
		} 
		if(FALSE == \lib\manage\common\DomainFunLib::checkisRealDomainRenew($info['DomainName'], $info['IsRealName'], $info['RegDate']))
		{
			throw new \Exception($info['DomainName']."域名未通过实名，无法续费", 322057);
		}
		return TRUE;
	}

	/**
	 * 获取用户购物车数量
	 *
	 * @param  $enameId
	 */
	public function getCartCount()
	{
		$domainShopMod = new \models\manage\product\DomainShopMod();
		$count = $domainShopMod->getCartCount($this->enameId);
		if($count)
			return $count;
		else
			return 0;
	}

	public function updateCartByShopId($data)
	{
		$domainShopMod = new \models\manage\product\DomainShopMod();
		if(empty($data->ShopId))
		{
			$where['DomainName']=$data->DomainName;
			$where['EnameId']=$data->EnameId;
		}
		else 
		{ 
			$where['ShopId']=$data->ShopId; 
		}
		return $domainShopMod->updateCartByShopId($where, (array)$data);
	}
	
	public function domainRegistOther($data)
	{
		$enameId = $data->enameId;
		$freqLib = new \lib\manage\domain\DomainQueryLib($enameId);
		if(date('Y-m-d H:i:s') >= date('Y-m-d 02:00:00') && date('Y-m-d H:i:s') <= date('Y-m-d 06:59:59'))
		{
			$freqLib->interLimit('cartResult115', 1);
		}
		$config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'cooper');
		$memberLib = new \lib\manage\member\MemberLib();
		$memberInfo = $memberLib->getMemberInfoByEnameId($enameId);
		if(!$memberInfo)
		{
			throw new \Exception('用户信息获取失败', 311006);
		}
		$email = $memberInfo['Email'];
		$userLevel = $memberInfo['UserGroup'];
		$postData = json_decode($_POST['products'], true);
		$dnManage = new \lib\manage\domain\DomainManageLib();
		$tempLib = new \lib\manage\domain\TemplateLib();
		$yearLib = new \lib\manage\domain\DomainPriceTempLib($enameId);
		$allMoney = 0;
		$shopType = $data->type;
		$domains = array();
		$errors = array();
		foreach($postData as $v)
		{
			$domain = $v['domain'];
			$queryLib = new \lib\manage\domain\DomainQueryLib($enameId);
			//直接过滤 注册续费转入
			if(\lib\manage\common\DomainFunLib::isChinaDomain($domain) && FALSE == \lib\manage\common\DomainOpenLib::tmpFuncOpenCheck(FALSE) && !DomainFunLib::isWangluoDomain($domain))
			{
				$data[] = array('domain' => $v['domain'], 'msg' => 'CNNIC接口维护','cart' => FALSE, 'code' => 60013);
				continue;
			}
			if(!$domain || FALSE == DomainFunLib::isOkDomain($domain) || FALSE == DomainFunLib::isOkDomainByCross($domain) || FALSE == DomainFunLib::isOkCnDomain($domain))
			{
				$data[] = array('domain' => $domain, 'msg' => '域名格式错误,不可注册', 'code' => 60001);
				continue;
			}
			if(FALSE == DomainFunLib::checkDomainSuffix115($domain))
			{
				$errors[] = array('domain' => $domain, 'msg' => '暂不支持的后缀', 'code' => 60002);
				continue;
			}
			if(DomainFunLib::checkIsDownDomain($domain) && in_array($shopType,array(1,2)))
			{
				$errors[] = array('domain' => $domain, 'msg' => '获取域名价格失败,不可注册', 'code' => 60005);
				continue;
			}
			$templateId = isset($v['templateId']) ? $v['templateId'] : '';
			$templateInfo = $tempLib->checkRegTemplate($domain, $templateId);
			if(!$templateInfo && $shopType == 1)//domain reg
			{
				$errors[] = array('domain' => $domain, 'msg' => '模板信息错误', 'code' => 60009);
				continue;
			}
			$templateId = !empty($templateInfo['TemplateId']) ? $templateInfo['TemplateId'] : FALSE;
			$allowYear = $yearLib->getDomainYear($domain, $shopType, FALSE);
			if(!$allowYear)//通常只有续费可能异常
			{
				$errors[] = array('domain' => $domain, 'msg' => '获取域名信息失败', 'code' => 60008);
				continue;
			}
			if(empty($v['year']) || $v['year'] > $allowYear)
			{
				$errors[] = array('domain' => $domain, 'msg' => '域名年限错误', 'code' => 60012);
				continue;
			}
			$year = $v['year'];
			//115接口域名不参与注册价格的优惠 只限制年份
			$yearPrice = $queryLib->checkDomainYears($domain, $shopType, $year);
			$year = $yearPrice['year'];
			$productType = \lib\manage\common\DomainFunLib::getDomainProductType($domain);
			$expDate = '';
			$registarId = '';
			if($shopType == 3)//域名续费
			{
				$domainInfo = $dnManage->getDomainInfo(array('DomainName' => $domain), 'DomainProperty,ExpDate,RegistrarId');
				if(empty($domainInfo))
				{
					$errors[] = array('domain' => $domain, 'msg' => '获取域名信息失败', 'code' => 60008);
					continue;
				}
				$productType = $domainInfo['DomainProperty'];
				$expDate = $domainInfo['ExpDate'];
				$registarId = $domainInfo['RegistrarId'];
			}
			$suffix = \lib\manage\common\DomainFunLib::getDomainClassAll($domain);
			$productName = \lib\manage\common\DomainFunLib::getDomainClass($domain);
			$price = $queryLib->getDomainPrice($domain, $suffix, $shopType, $productType);
			if(FALSE === $price)
			{
				$errors[] = array('domain' => $domain, 'msg' => '获取域名价格失败,不可注册', 'code' => 60005);
				continue;
			}
			$priceLib = new \lib\manage\domain\DomainPriceTempLib($enameId);
			$allMoney += $price * $year;
			$domainsArr = array('domain' => $domain, 'enameId' => $this->enameId, 'year' => $year, 'promoCode' => '',
					'productName' => '.' . $productName, 'email' => $email, 'userGroupId' => $userLevel,
					'expDate' => $expDate, 'productType' => $productType, 'templateId' => $templateId,
					'type' => $shopType, 'remark' => '', 'ext' => '', 'registarId' => $registarId);
			$domains[] = $domainsArr;
		}
		if(empty($domains))
		{
			return $errors;
		}
		$financeLib = new \lib\manage\finance\FinanceInfoLib($enameId);
		$financeInfo = $financeLib->getUserFinance($enameId);
		$enableMoney = floatval(str_replace(',', '', $financeInfo['UseMoney']));
		$data = array();
		$manageConf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini');
		$tempTemplateId = $manageConf->systemplate->systemTempId->toArray();
		$tempTemplateId = $tempTemplateId[0];
		$domainLtdArray = $manageConf->domain->domainLtd->toArray();
		$msgCenter = new \common\MsgCenterLib();
		$registLib = new \lib\manage\domain\DomainRegistLib($enameId);
		foreach($domains as $v)
		{
			$errorMsg = $this->cartLib->singleDomainResult($v, $registLib, $tempTemplateId, $domainLtdArray);
			if(!empty($errorMsg))
			{
				$data[] = array('domain' => $v['domain'], 'msg' => '域名结算失败', 'code' => 60010);
				continue;
			}
			$data[] = array('domain' => $v['domain'], 'msg' => $shopType == 1 ? '注册成功' : '续费成功', 'code' => 60000);
		}
		if($errors)
		{
			$data = array_merge($data, $errors);
		}
		return $data;
	}

	public function checkIsWhiteTemp($domain,$templateId)
	{ 
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'vspdomainltd');
		$vpsDomainLtd = $conf->domainltd->toArray();
		if(in_array(DomainFunLib::getDomainClass($domain),$vpsDomainLtd))
		{
			$lib = new \lib\manage\domain\TemplateLib();
			$templateInfo = $lib->getTempInfo($templateId);
			return $templateInfo && $templateInfo['CnStatus'] == 2;
		}
		return true;
	}
}

<?php
namespace logic\manage\finance;

use core\Response;
use core\form\ReturnData;
use lib\manage\common\DomainFunLib;
use core\Log;

class FinanceGeneralLogic
{

	private $generalLib;

	private $finInMod;

	private $finOutMod;

	private $financeLib;

	private $finLogLib; 

	private $generalMod;

	private $conf;

	public function __construct()
	{
		$this->generalLib = new \lib\manage\finance\FinanceGeneralLib();
		
		$this->generalMod = new \models\manage\finance\FinGeneralMod();
		
		$this->finInMod = new \models\manage\finance\FinInMod();
		
		$this->finOutMod = new \models\manage\finance\FinOutMod();
		
		$this->finLogLib = new \lib\manage\finance\FinanceLogLib();
		
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
	}

	/**
	 * 根据条件获取流水账列表记录数
	 *
	 * @return \models\manage\finance\Ambigous
	 */
	public function getGeneralCount()
	{
		if(ReturnData::$success)
		{
			return $this->generalLib->getGeneralCount((array)ReturnData::$info);
		}
	}

	/**
	 * 根据条件获取流水账列表
	 *
	 * @return \models\manage\finance\Ambigous
	 */
	public function getGeneralList()
	{
		if(ReturnData::$success)
		{
			return $this->generalLib->getGeneralList((array)ReturnData::$info);
		}
	}
	/**
	 * 根据InOutMoney InOutType TypeSon 获取财务流水账统计信息InOutMoney InOutType必须  TypeSon可选
	 * 具体传入数据参考getGeneralCount
	 */
	public function getFinGeneralStatistics()
	{
		if(ReturnData::$success)
		{
			return $this->generalLib->getFinGeneralStatistics((array)ReturnData::$info);
		}
	}
	/**
	 * 根据条件获取出入款金额统计
	 *
	 * @throws \Exception
	 * @return Ambigous <number, multitype:, boolean, unknown,
	 *         multitype:multitype: >
	 */
	public function getStatistics()
	{
		if(!ReturnData::$success)
		{
			throw new \Exception('传入参数错误', 410043);
		}
		// Type 1: FinanceOut 2: FinanceIn 3 : WithdrawMoney
		if(empty(ReturnData::$info->Type) && empty($_REQUEST['in']['Type']))
		{
			throw new \Exception('请传入出款或入款参数值');
		}
		return $this->generalLib->getStatistics((array)ReturnData::$info);
	}

	/**
	 * 获取订单取消的相关信息
	 *
	 * @return array $cancelInfo
	 */
	public function getOrderCancelInfo()
	{
		$orderId = ReturnData::$info->orderId;
		$enameId = ReturnData::$info->enameId;
		$orderLib = new \lib\manage\finance\OrderLib($enameId);
		$orderInfo = $orderLib->getOrderInfo($orderId);
		
		// 判断订单是否已经取消
		$remark = '取消订单';
		$financeInLib = new \lib\manage\finance\FinanceInLib($enameId);
		$inRecord = $financeInLib->getFinanceInSDK(
			array('enameId' => $enameId, 'orderId' => $orderId, 'offset' => '0', 'num' => '1', 'inRemark' => $remark), 
			false);
		if(is_array($inRecord) && !empty($inRecord))
		{
			throw new \Exception('该订单已经取消过:' . $orderId, 410080);
		}
		
		return $this->getCancelInfoByType($orderInfo);
	}

	/**
	 * 取消订单逻辑
	 *
	 * @throws \Exception
	 */
	public function cancelOrder()
	{
		if(!ReturnData::$success)
		{ 
			throw new \Exception('参数错误!' , 410043);
		}
		
		$info = (array)ReturnData::$info;
		$orderId = $info['orderId'];
		
		$orderLib = new \lib\manage\finance\OrderLib($info['bEnameId']);
		if(!$orderInfo = $orderLib->getOrderInfo($orderId))
		{
			throw new \Exception('获取订单信息失败:' . $orderId , 410056);
		}
		
		$cancelType = $this->getCancelType($orderInfo['OrderType']);
		
		if(false === $cancelType)
		{
			throw new \Exception('该订单类型不可取消:' . $orderId);
		} 
		
		if($orderInfo['OrderStatus'] != 1)
		{
			throw new \Exception('该订单非成功状态，无法取消' . $orderId);
		}
		// 订单取消对应的款项的退回 , 域名转移和记录添加
		switch($cancelType)
		{
			// 把域名从买家账号下转移到卖家账号下，从卖家账号下扣除所得金额，在买家账号下增加所付金额
			case 1:
				$this->generalLib->cancelType1($info, $orderInfo);
				break;
			// 从卖家账号下扣除所得金额，在买家账号下增加所付金额
			case 2:
				$this->generalLib->cancelType2($info, $orderInfo);
				break;
			case 3:
			case 4:
				$this->generalLib->cancelType3($info, $orderInfo);
				break;
			default:
				throw new \Exception('未知错误!');
		}
		// 在财务报表里删除相应记录
	}

	/**
	 * 收入统计
	 *
	 * @param object $info
	 */
	public function getFinanceInStat($info)
	{
		$data['startTime'] = $info->startTime;
		$data['endTime'] = $info->endTime;
		$data['year'] = date('Y', $data['startTime']);
		$result = array();
		$result = $this->generalMod->getFinanceInStat($data);
		return self::financeInStatDataFormatter($result);
	}

	/**
	 * 收入统计详细
	 *
	 * @param object $info
	 */
	public function getFinanceInStatDetail($info)
	{
		$data['startTime'] = $info->startTime;
		$data['endTime'] = $info->endTime;
		$data['year'] = date('Y', $data['startTime']);
		$result = $this->generalMod->getFinanceInStatDetail($data, $info->typeArrDn, $info->typeArrFee);
		return self::financeInStatDataFormatter($result);
	}

	/**
	 * 财务收入统计数据格式化
	 *
	 * @param array $data
	 * @return array
	 */
	private function financeInStatDataFormatter($data)
	{
		if(empty($data))
		{
			return $data;
		}
		$field = array('Num', 'MoneyCount', 'YearCount', 'InOutMoney', 'RegistrarId', 'DomainLtd', 'InOutType', 'Type', 'TypeSon');
		foreach($data as &$v)
		{
			foreach($field as $k)
			{
				if(!isset($v[$k]))
				{
					$v[$k] = '';
				}
			}
		}
		return $data;
	}

	/**
	 * 财务收入统计数据格式化
	 *
	 * @param array $data
	 * @return array
	 */
	public function updateFinanceType($info)
	{
		$GeneralIds = explode(',', $info->GeneralId);
		$FinanceType = $info->FinanceType;
		$SonType = $info->SonType;
		$byYear = $info->byYear;
		$msg = '';
		foreach($GeneralIds as $GeneralId)
		{
			$params = array('GeneralId' => $GeneralId, 'FinanceType' => $FinanceType, 'SonType' => $SonType, 
					'byYear' => $byYear);
			$info = $this->generalMod->getInfoById($GeneralId, $byYear);
			if(empty($info))
			{
				$msg = $GeneralId . '修改失败,数据不存在';
				Log::write("GeneralId:$GeneralId,FinanceType:$FinanceType,SonType:$SonType,byYear:$byYear,result:$msg", 
					'financegeneral', 'updateFinanceType');
				continue;
			}
			if($FinanceType == 6 )
			{
				$params['Type'] = 4;
			}
			else if($FinanceType == 200)			
			{
				$params['Type'] = 3;
			}
			else if($info['InOutType'] == 6)
			{
				$params['Type'] = 1;
			}
			else if($info['InOutType'] == 200)
			{
				$params['Type'] = 2;
			}
			if(!$this->generalMod->updateFinanceTypeById($params))
			{
				$msg = $GeneralId . '修改失败';
			}
			Log::write("GeneralId:$GeneralId,FinanceType:{$info['InOutType']} => $FinanceType,SonType:{$info['TypeSon']} => $SonType,byYear:$byYear,result:$msg",'financegeneral','updateFinanceType');
		}
		if(!empty($msg))
		{
			throw new \Exception($msg);
		}
		return true;
	}

	/**
	 * 格式化操作数据库数据
	 *
	 * @param array $finInfo 出入款信息
	 * @param array $post post数据
	 * @param array $orderInfo
	 * @param int $isInOrOut 1:In 2:Out
	 */
	private function setData($finInfo, $post, $orderInfo, $isInOrOut)
	{
		$return = array();
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$conf = $conf->domainLtd->toArray();
		$return['EnameId'] = $isInOrOut == 1 ? $post['sEnameId'] : $post['bEnameId'];
		$this->financeLib = new \lib\manage\finance\FinanceLib($return['EnameId']);
		// 用户余额
		$userFinInfo = $this->financeLib->getUserFinance();
		if(!$userFinInfo)
		{
			throw new \Exception('获取用户余额失败' ,410094);
		}
		$balance = $userFinInfo['PublicMoney'] + $userFinInfo['UnWithdrawalMoney'] + $userFinInfo['WithdrawalMoney'] +
			 $userFinInfo['MarginMoney'];
		$return['DomainLtd'] = DomainFunLib::getDomainLtd($conf, $orderInfo['Domain']);
		$return['InOutMoney'] = $isInOrOut == 1 ? $finInfo['InMoney'] + $finInfo['FeeMoney'] : $finInfo['OutMoney'];
		$return['CurrentMoney'] = $isInOrOut == 1 ? $balance - $finInfo['InMoney'] : $balance + $finInfo['OutMoney'];
		$return['InOutStatus'] = $isInOrOut == 1 ? $finInfo['InStatus'] : $finInfo['OutStatus'];
		$return['InOutType'] = $orderInfo['OrderType'];
		$return['LinkDomain'] = $finInfo['LinkDomain'];
		$return['LinkEnameId'] = $isInOrOut == 1 ? $post['bEnameId'] : $post['sEnameId'];
		$return['Type'] = $isInOrOut == 1 ? 2 : 1; // 原来出款变入款，入款变出款
		$return['OrderId'] = $orderInfo['OrderId'];
		$return['OrderType'] = $orderInfo['OrderType'];
		$return['ProductId'] = $orderInfo['ProductId'];
		$return['ProductName'] = $orderInfo['ProductName'];
		$return['PromoId'] = $orderInfo['PromoId'];
		$return['PromoMoney'] = $orderInfo['PromoMoney'];
		$return['ProductCost'] = $orderInfo['ProductCost'];
		$return['FreezeMoneySort'] = $orderInfo['FreezeMoneySort'];
		$return['ProductOption'] = $orderInfo['ProductOptions'];
		$return['FeeMoney'] = $isInOrOut == 1 ? $finInfo['FeeMoney'] : 0;// 手续费应该都为0
		$return['BankName'] = $isInOrOut == 1 ? $finInfo['BankName'] : '';
		$return['TypeSon'] = $isInOrOut == 1 ? $finInfo['InTypeSon'] : $finInfo['OutTypeSon'];
		$return['UniqueId'] = $isInOrOut == 1 ? $finInfo['UniqueId'] : '';
		$return['Remark'] = isset($post['remark']) ? $post['remark'] : '';
		$return['CreateTime'] = time();
		return $return;
	}

	/**
	 * 根据orderType获取取消订单需要的数据
	 *
	 * @param array $orderInfo
	 * @return array $info
	 */
	private function getCancelInfoByType(array $orderInfo)
	{
		$return = array();
		$orderId = $orderInfo['OrderId'];
		// 财务类型不属于取消订单类型范围或者订单状态非成功状态
		$cancelType = $this->getCancelType($orderInfo['OrderType']);
		if(false === $cancelType)
		{
			throw new \Exception('该订单类型不可取消' . $orderId);
		}
		if($orderInfo['OrderStatus'] != 1)
		{
			throw new \Exception('订单非成功状态不可取消' . $orderId);
		}
		// 根据orderId获取财务入款信息
		$finInInfo = $this->finInMod->getFinanceIn(
			array('orderId' => $orderId, 'enameId' => $orderInfo['LinkEnameId'], 'offset' => 0, 'num' => 1));
		$finOutInfo = $this->finOutMod->getFinanceOut(
			array('orderId' => $orderId, 'enameId' => $orderInfo['EnameId'], 'offset' => 0, 'num' => 1));
		if(!$finInInfo && !$finOutInfo)
		{
			throw new \Exception('获取该订单相关财务信息失败:' . $orderId);
		}
		// 获取返回值
		$return['domain'] = $orderInfo['Domain'];
		$return['bEnameId'] = $orderInfo['EnameId'];
		$return['sEnameId'] = $orderInfo['LinkEnameId'];
		$return['orderType'] = $orderInfo['OrderType'];
		// 类型1：交易成功，有款项转移，有域名过户
		if($cancelType == 1)
		{
			// orderType小于100的只需判断出款，手续费为0
			$return['deSellMoney'] = $orderInfo['OrderType'] > 100 ? $finInInfo[0]['InMoney'] : $finOutInfo[0]['OutMoney']; // 应该扣除卖家金额
			$return['deFee'] = $orderInfo['OrderType'] <= 100 ? 0 : $finInInfo[0]['FeeMoney']; // 应该扣除手续费金额
			$return['retBMoney'] = $finOutInfo[0]['OutMoney']; // 应该退还买家金额
		}
		// 类型2：交易违约，有款项转移，没有域名过户
		if($cancelType == 2)
		{
			// 买家违约
			if(in_array($orderInfo['OrderType'], array(108)))
			{
				$return['breakType'] = 1;
				$return['bBreakMoney'] = $finOutInfo[0]['OutMoney']; // 应该扣除买家违约金额
				$return['retSMoney'] = $finInInfo[0]['FeeMoney']; // 应该退还卖家金额
			}
			// 卖家违约
			else
			{
				$return['breakType'] = 2;
				$return['sBreakMoney'] = $finInInfo[0]['InMoney']; // 应该扣除卖家违约金额
				$return['retBMoney'] = $finInInfo[0]['InMoney'] + $finInInfo[0]['FeeMoney']; // 应该退还买家金额
			}
			$return['deFee'] = $finInInfo[0]['FeeMoney']; // 应该扣除手续费金额
		}
		// 类型3：域名PUSH
		if($cancelType == 3)
		{
			$domain = $orderInfo['Domain'];
			$pushMod = new \models\manage\domain\DomainPushMod();
			$pushInfo = $pushMod->pushList(array('OrderId' => $orderId), "*", true);
			if(!empty($pushInfo))
			{
				$domainArr=explode("\n",$pushInfo['DomainName']);
				if(count($domainArr) > 1)
				{
					//throw new \Exception('打包push的暂时不支持取消订单，请手动取消!');
				}
				if($pushInfo['DomainName'] != $domain || $pushInfo['ReceiveId'] != $orderInfo['EnameId'] || $pushInfo['SendId'] != $orderInfo['LinkEnameId'])
				{
					$pushInfo = false;
				}
			}
			if(!$pushInfo)
			{
				//没有PUSH记录的PUSH订单处理 
				$return['deSellMoney'] = $finInInfo[0]['InMoney']; // 应该扣除卖家金额
				$return['retBMoney'] = $finOutInfo[0]['OutMoney']; // 应该退还买家金额
				$return['deFee'] = $finInInfo[0]['FeeMoney'];

			}
			// 1：带价push可提现，有款项转移，有域名过户
			elseif($pushInfo['PushType'] == 3 && $pushInfo['PushPrice'] != '0.0000')
			{
				$return['deSellMoney'] = $finInInfo[0]['InMoney']; // 应该扣除卖家金额
				$return['retBMoney'] = $finOutInfo[0]['OutMoney']; // 应该退还买家金额
				$return['deFee'] = $finInInfo[0]['FeeMoney'];
				// 应该扣除手续费金额
			}
			// 2：带价push不可提现，有款项转移，有域名过户
			elseif($pushInfo['PushType'] == 2 && $pushInfo['PushPrice'] != '0.0000')
			{
				$return['deSellMoney'] = $finInInfo[0]['InMoney']; // 应该扣除卖家金额
				$return['retBMoney'] = $finOutInfo[0]['OutMoney']; // 应该退还买家金额
				// 应该扣除手续费金额
			}
			// 3：不带价push，没有款项转移，有域名过户 (默认那三个)
		}
		// 类型4：注册 续费 转入
		if($cancelType == 4)
		{
			$return['retBMoney'] = $finOutInfo[0]['OutMoney']; // 应该退还买家金额
		}
		return $return;
	}

	/**
	 * 获取可取消订单type
	 *
	 * @return int
	 */
	private function getCancelType($orderType) 
	{
		$cancelType = array();
		// 类型1：交易成功，有款项转移，有域名过户
		if(in_array($orderType, array(8, 24, 25, 26, 105, 121, 122, 123, 102, 103, 106, 115, 132, 135)))
		{
			return 1;
		} 
		// 类型2：交易违约，有款项转移，没有域名过户
		if(in_array($orderType, array(110, 108, 109, 113, 114, 116)))
		{
			return 2;
		}
		// 类型3：域名PUSH
		if($orderType == 101)
		{
			return 3;
		}
		// 类型4：注册 转入 续费
		if(in_array($orderType ,array(1,2,3)))
		{
			return 4;
		}
		return false;
	}

	/* 域名消费统计 */
	public function domainCost($data)
	{
		$beginMonth = $data['beginMonth'];
		$beginYear = substr($beginMonth, 0, 4);
		$beginMonthStr = strtotime($beginMonth);
		$endMonth = $data['endMonth'];
		$endYear = substr($endMonth, 0, 4);
		$endMonthStr = strtotime("+1month", strtotime($endMonth));
		$typeArr = $data['typeArr'];
		return $this->generalMod->domainCostStat($beginYear, $endYear, $beginMonthStr, $endMonthStr, $typeArr);
	}

	/* 交易统计 */
	public function trade($data)
	{
		$tempArray = array();
		$beginMonth = $data['beginMonth'];
		$beginYear = substr($beginMonth, 0, 4);
		$beginMonthStr = strtotime($beginMonth);
		$endMonth = $data['endMonth'];
		$endYear = substr($endMonth, 0, 4);
		$endMonthStr = strtotime("+1month", strtotime($endMonth));
		$tradeFeeStat = $this->generalMod->tradeFeeStat($beginYear, $endYear, $beginMonthStr, $endMonthStr, $data['typeArrFee']);
		$tradeProStat = $this->generalMod->tradeProStat($beginYear, $endYear, $beginMonthStr, $endMonthStr, $data['typeArrPro']);
		if(!empty($tradeFeeStat) && !is_null($tradeFeeStat[0]['Count']))
		{
			$tempArray = array_merge($tempArray, $tradeFeeStat);
		}
		if(!empty($tradeProStat) && !is_null($tradeProStat[0]['Count']))
		{
			$tempArray = array_merge($tempArray, $tradeProStat);
		}
		// 数据排序转换
		$tempChange1 = $tempChange2 = array();
		foreach($tempArray as $key => $row)
		{
			$tempChange1[$key] = $row['DomainLtd'];
			$tempChange2[$key] = $row['InOutType'];
		}
		array_multisort($tempChange1, SORT_ASC, $tempChange2, SORT_ASC, $tempArray);
		return $tempArray;
	}

	/* 用户统计 */
	public function user($data)
	{
		$beginMonth = $data['beginMonth'];
		$beginMonthStr = strtotime($beginMonth);
		$beginTime = date('Y-m-d H:i:s', $beginMonthStr);
		$endMonth = $data['endMonth'];
		$endMonthStr = strtotime("+1month", strtotime($endMonth));
		$endTime = date('Y-m-d H:i:s', $endMonthStr);
		$statMod = new \models\manage\stat\StatMod();
		return $statMod->getUserTotal($beginTime, $endTime);
	}

	/* 域名消费额排名 */
	public function domainCostRanking($data)
	{
		$beginMonth = $data['beginMonth'];
		$beginYear = substr($beginMonth, 0, 4);
		$beginMonthStr = strtotime($beginMonth);
		$endMonth = $data['endMonth'];
		$endYear = substr($endMonth, 0, 4);
		$endMonthStr = strtotime("+1month", strtotime($endMonth));
		$statList = $this->generalMod->domainCostRankingStat($beginYear, $endYear, $beginMonthStr, $endMonthStr);
		$userLib = new \lib\manage\member\MemberLib();
		foreach($statList as $k => $v)
		{
			$memberInfo = $userLib->getMemberInfoByEnameId($v['EnameId'], "Email,ChName", "Mobile,ChProvince,ChCity,ChStreet,ChCompanyName");
			$statList[$k]['Name'] = empty($memberInfo['ChName']) ? '' : $memberInfo['ChName'];
			$statList[$k]['Email'] = empty($memberInfo['Email']) ? '' : $memberInfo['Email'];
			$statList[$k]['Mobile'] = empty($memberInfo['Mobile']) ? '' : $memberInfo['Mobile'];
			$statList[$k]['Address'] = $memberInfo['ChProvince'].$memberInfo['ChCity'].$memberInfo['ChStreet'].$memberInfo['ChCompanyName'];
		}
		return $statList;
	}

	/* 域名交易额排名 */
	public function tradeRanking($data)
	{
		$beginMonth = $data['beginMonth'];
		$beginYear = substr($beginMonth, 0, 4);
		$beginMonthStr = strtotime($beginMonth);
		$endMonth = $data['endMonth'];
		$endYear = substr($endMonth, 0, 4);
		$endMonthStr = strtotime("+1month", strtotime($endMonth));
		$statList = $this->generalMod->tradeRankingStat($beginYear, $endYear, $beginMonthStr, $endMonthStr);
		$userLib = new \lib\manage\member\MemberLib();
		foreach($statList as $k => $v)
		{
			$memberInfo = $userLib->getMemberInfoByEnameId($v['EnameId'], "Email,ChName", "Mobile,ChProvince,ChCity,ChStreet,ChCompanyName");
			$statList[$k]['Name'] = empty($memberInfo['ChName']) ? '' : $memberInfo['ChName'];
			$statList[$k]['Email'] = empty($memberInfo['Email']) ? '' : $memberInfo['Email'];
			$statList[$k]['Mobile'] = empty($memberInfo['Mobile']) ? '' : $memberInfo['Mobile'];
			$statList[$k]['Address'] = $memberInfo['ChProvince'].$memberInfo['ChCity'].$memberInfo['ChStreet'].$memberInfo['ChCompanyName'];
		}
		return $statList;
	}

	/* 域名交易额排名（去掉push） */
	public function tradeRankingNoPush($data)
	{
		$beginMonth = $data['beginMonth'];
		$beginYear = substr($beginMonth, 0, 4);
		$beginMonthStr = strtotime($beginMonth);
		$endMonth = $data['endMonth'];
		$endYear = substr($endMonth, 0, 4);
		$endMonthStr = strtotime("+1month", strtotime($endMonth));
		$statList = $this->generalMod->tradeRankingNoPushStat($beginYear, $endYear, $beginMonthStr, $endMonthStr);
		$userLib = new \lib\manage\member\MemberLib();
		foreach($statList as $k => $v)
		{
			$memberInfo = $userLib->getMemberInfoByEnameId($v['EnameId'], "Email,ChName", "Mobile,ChProvince,ChCity,ChStreet,ChCompanyName");
			$statList[$k]['Name'] = empty($memberInfo['ChName']) ? '' : $memberInfo['ChName'];
			$statList[$k]['Email'] = empty($memberInfo['Email']) ? '' : $memberInfo['Email'];
			$statList[$k]['Mobile'] = empty($memberInfo['Mobile']) ? '' : $memberInfo['Mobile'];
			$statList[$k]['Address'] = $memberInfo['ChProvince'].$memberInfo['ChCity'].$memberInfo['ChStreet'].$memberInfo['ChCompanyName'];
		}
		return $statList;
	}

	/* 域名类型统计 */
	public function domainType($data)
	{
		$beginMonth = $data['beginMonth'];
		$beginMonthStr = strtotime($beginMonth);
		$beginTime = date('Y-m-d H:i:s', $beginMonthStr);
		$endMonth = $data['endMonth'];
		$endMonthStr = strtotime("+1month", strtotime($endMonth));
		$endTime = date('Y-m-d H:i:s', $endMonthStr);
		$statMod = new \models\manage\stat\StatMod();
		return $statMod->getDnLtdSysGroupTotal($beginTime, $endTime);
	}

	/**
	 * 入款方式统计
	 */
	public function financeInType($data)
	{
		$beginMonth = $data['beginMonth'];
		$beginYear = substr($beginMonth, 0, 4);
		$beginMonthStr = strtotime($beginMonth);
		$endMonth = $data['endMonth'];
		$endYear = substr($endMonth, 0, 4);
		$endMonthStr = strtotime("+1month", strtotime($endMonth));
		return $this->generalMod->financeInTypeStat($beginYear, $endYear, $beginMonthStr, $endMonthStr);
	}

	/**
	 * 预付款统计
	 *
	 * @param $total false:统计详细 true：统计总额
	 */
	public function prePay($data, $isTotal = false)
	{
		$beginMonth = $data['beginMonth'];
		$beginMonthStr = strtotime($beginMonth);
		$beginTime = date('Y-m-d', $beginMonthStr);
		$endMonth = $data['endMonth'];
		$endMonthStr = strtotime("+1month", strtotime($endMonth));
		if(!empty($data['monthType']) && $data['monthType'] == 2)
		{
			$endMonthStr = strtotime("+1day", strtotime($endMonth));
		}
		$endTime = date('Y-m-d', $endMonthStr);
		$statMod = new \models\manage\stat\StatMod();
		$prePayInfo = $statMod->getPrePayTotal($beginTime, $endTime, $isTotal);
		return $prePayInfo;
	}
	
	/**
	 *  按接口统计
	 */
	public function registrar($data)
	{
		$beginMonth = $data['beginMonth'];
		$beginYear = substr($beginMonth, 0, 4);
		$beginMonthStr = strtotime($beginMonth);
		$endMonth = $data['endMonth'];
		$endYear = substr($endMonth, 0, 4);
		$endMonthStr = strtotime("+1month", strtotime($endMonth));
		$registrarId = $data['registrarId'] ? $data['registrarId'] : false;
		$typeArr = $data['typeArr'];
		return $this->generalMod->domainCostStat($beginYear, $endYear, $beginMonthStr, $endMonthStr, $typeArr, $registrarId, true);
	}
	
	/**
	 * 预付款总额更新 
	 */
	public function updatePrepayTotal($data)
	{
		$statMod = new \models\manage\stat\StatMod();
		return $statMod->updatePrepayTotal($data);
	}
	
	/**
	 * 获取财务新表流水信息
	 * 预收款分类详情专用
	 */
	public function getFinanceList($data)
	{
		return $this->generalMod->getFinancePrepayList($data);
	}
}

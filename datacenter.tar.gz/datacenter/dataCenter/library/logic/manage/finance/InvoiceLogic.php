<?php
namespace logic\manage\finance;
use core\Response;
use core\form\ReturnData;

class InvoiceLogic
{

	private $finInvoiceLib;

	private $conf;

	public function __construct()
	{
		$this->finInvoiceLib = new \lib\manage\finance\FinanceInvoiceLib();
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
	}

	/**
	 * 添加发票
	 *
	 * @param object
	 * @return number|boolean
	 */
	public function addInvoice($params) 
	{ 
		$this->finInvoiceLib->setEnameId($params->enameId);
		$this->finInvoiceLib->setInvoiceType($params->invoiceType);
		if(isset($params->invoiceTitle))
		{
			$this->finInvoiceLib->setInvoiceTitle($params->invoiceTitle);
		}
		$this->finInvoiceLib->setInvoiceAmout($params->invoiceAmout);
		$this->finInvoiceLib->setInvoiceContent($params->invoiceContent);
		$this->finInvoiceLib->setTaxRegistNumber($params->taxRegistNumber);
		if(isset($params->taxRegistFile))
		{
			$this->finInvoiceLib->setTaxRegistFile($params->taxRegistFile); 
		}
		if(isset($params->taxQualiFile))
		{
			$this->finInvoiceLib->setTaxQualiFile($params->taxQualiFile);
		}
		if(isset($params->companyAddress))
		{
			$this->finInvoiceLib->setCompanyAddress($params->companyAddress);
		}
		if(isset($params->companyPhone))
		{
			$this->finInvoiceLib->setCompanyPhone($params->companyPhone);
		}
		if(isset($params->bank))
		{
			$this->finInvoiceLib->setBank($params->bank);
		}
		if(isset($params->bankAccount))
		{
			$this->finInvoiceLib->setBankAccount($params->bankAccount);
		}
		if(isset($params->linkEmail))
		{
			$this->finInvoiceLib->setLinkEmail($params->linkEmail);
		}
		$this->finInvoiceLib->setChProvince($params->chProvince);
		$this->finInvoiceLib->setInvoiceAddress($params->invoiceAddress);
		$this->finInvoiceLib->setInvoiceRecipient($params->invoiceRecipient);
		$this->finInvoiceLib->setLinkPhone($params->linkPhone);
		$this->finInvoiceLib->setInvoiceZipCode($params->invoiceZipCode);
		$this->finInvoiceLib->setDeliveryType($params->deliveryType);
		$this->finInvoiceLib->setPayWay($params->payWay);
		$this->finInvoiceLib->setDealWay($params->dealWay);
		$this->finInvoiceLib->setUserType($params->userType);
		if(!empty($params->deliveryFare))
		{
			$this->finInvoiceLib->setDeliveryFare($params->deliveryFare);
		}
		else
		{
			$this->finInvoiceLib->setDeliveryFare(0);
		}
		if(isset($params->invoiceRemarks))
		{
			$this->finInvoiceLib->setInvoiceRemarks($params->invoiceRemarks);
		}
		if(isset($params->isDefault))
		{
			$this->finInvoiceLib->setIsDefault($params->isDefault);
		} 
		if($params->dealWay == 5 || $params->dealWay == 3)
		{
			if(empty($params->year))
			{
				throw new \Exception('请选择开票年份');
			}
			$this->finInvoiceLib->setOperateRemarks(date("Y-m-d H:i:s",time()).':<font color="red">'.($params->dealWay == 5?'后台':'前台').'申请开'.$params->year.'年的发票</font>');
		}
		$amountFee = $this->conf->invoice->amountFee;
		// 可用余额验证 选项圆通1 中通4 选择余额付费 发票金额不大于500或者 或者选择EMS
		if(($params->invoiceAmout < $amountFee && in_array($params->deliveryType, array(
				1, 4
		))) || ($params->deliveryType == '3'))
		{
			// 余额付快递费
			if($params->payWay == '2')
			{
				// 是否为有效快递费的验证
				if($params->deliveryFare != $this->countInvoiceDeliveryFare($params->chProvince, $params->deliveryType))
				{
					throw new \Exception('操作失败,请重试', 420012);
				}
				// 可用余额
				$finlogic = new \logic\manage\finance\FinanceLogic();
				$canUseMoney = $finlogic->getBalance($params);
				// 可用余额验证
				if($params->deliveryFare > $canUseMoney)
				{
					throw new \Exception('可以余额不足', 420013);
				}
			}
		}
		// 快递费订单操作
		if($params->payWay == '2')
		{
			$price = $params->deliveryFare;
			$remark = '用户承担的快递费用，不开票';
			$finOrder = new \interfaces\manage\Finance();
			$orderId = $finOrder->addOrder((object) array('enameId' => $params->enameId, 'price' => $price,
					'type' => 32, 'remark' => $remark));
			if($orderId)
			{
				$this->finInvoiceLib->setOrderId($orderId);
			}
			else
			{
				\core\Log::write(json_encode(array('enameId' => $params->enameId, 'price' => $params->deliveryFare,
						'type' => 32, 'function' => 'addOrder', 'remark' => $remark)), 'invoice');
				throw new \Exception('发票申请失败', 410023);
			}
		}
		// 发票记录操作
		//设置为默认信息
		if($this->finInvoiceLib->getIsDefault())
		{
			$this->finInvoiceLib->updateInvoice(array('isDefault' => 0), array('enameId' => $params->enameId));
		}
		$invoiceId = $this->finInvoiceLib->addInvoice();
		if(! $invoiceId)
		{
			\core\Log::write(json_encode(array('添加发票失败', $data), 'invoice'));
			if($this->finInvoiceLib->getOrderId())
			{
				$finOrder->cancelOrder((object) array('enameId' => $params->enameId, 'orderId' => $this->finInvoiceLib->getOrderId()));
			}
			throw new \Exception('添加发票失败', 420021);
		}
		// 发票额度操作
		$updatData = array('enameId' => $params->enameId, 'invoiceFare' => $params->invoiceAmout, 'action' => 1, 
			'type' => $params->dealWay);
		if($params->dealWay == 2)
		{
			$updatData['year'] = date('Y');
		}
		$redis = \core\RedisLib::getInstance('manage', false);
		if($params->dealWay == 5 || $params->dealWay == 3)
		{
			$updatData['year'] = $params->year;
			//redis记录处理发票对应年份
		    $redis->setex('invoice_fare_'.$invoiceId, 30*24*3600, $params->year);
			\core\Log::write(json_encode(array('申请开指定年份发票', '年份:'.$params->year,'发票ID'.$invoiceId)), 'invoice');
		}
		if(in_array($params->dealWay, array(1, 2, 4, 5))) // 3特殊开票不创建订单
		{
			try
			{
				$this->setInvoiceFare($updatData); // 更新可开发票金额	
			}
			catch(\Exception $e)
			{
				if($params->dealWay == 5 || $params->dealWay == 3)
				{
					$redis->delete('invoice_fare_'.$invoiceId);
				}
				\core\Log::write(json_encode('更新发票金额出错', $updatData), 'invoice');
				// 删除申请记录若有创建订单取消订单
				if($this->finInvoiceLib->delInvoiceById(array('invoiceId' => $invoiceId)))
				{
					\core\Log::write(json_encode(array('删除申请记录出错', 'invoiceId' => $invoiceId)), 'invoice');
				}
				if($this->finInvoiceLib->getOrderId())
				{
					$finOrder->cancelOrder(
						(object)array('enameId' => $params->enameId, 'orderId' => $this->finInvoiceLib->getOrderId()));
				}
				throw new \Exception($e->getMessage(), $e->getCode());
		    }
		}
		return true;
	}

	/**
	 *  快递费计算
	 * @param $selectChProvince 快递邮寄的省
	 * @param $selectDeliveryType 快递类型
	 * @return number
	 */
	private function countInvoiceDeliveryFare($selectChProvince, $selectDeliveryType)
	{
		if($selectDeliveryType == 4)
		{
			if(in_array($selectChProvince, explode('，', $this->conf->invoice->provinceArea1DeliveryType1)))
			{
				return $this->conf->invoice->provinceArea1DeliveryType1Fare;
			}
			if(in_array($selectChProvince, explode('，', $this->conf->invoice->provinceArea2DeliveryType1)))
			{
				return $this->conf->invoice->provinceArea2DeliveryType1Fare;
			}
			if(in_array($selectChProvince, explode('，', $this->conf->invoice->provinceArea3DeliveryType1)))
			{
				return $this->conf->invoice->provinceArea3DeliveryType1Fare;
			}
			if(in_array($selectChProvince, explode('，', $this->conf->invoice->provinceArea4DeliveryType1)))
			{
				return $this->conf->invoice->provinceArea4DeliveryType1Fare;
			}
			if(in_array($selectChProvince, explode('，', $this->conf->invoice->provinceArea5DeliveryType1)))
			{
				return $this->conf->invoice->provinceArea5DeliveryType1Fare;
			}
		}
		if($selectDeliveryType == 3)
		{
			if($selectChProvince == $this->conf->invoice->provinceArea1DeliveryType3)
			{
				return $this->conf->invoice->provinceArea1DeliveryType3Fare;
			}
			else
			{
				return $this->conf->invoice->provinceArea2DeliveryType3Fare;
			}
		}
	}

	/**
	 * 取消发票申请,InvoiceStatus值置为2
	 *
	 * @param object enameId invoiceId
	 * @return number|boolean
	 */
	public function cancleInvoice($params)
	{
		if(empty($params->enameId))
		{
			throw new \Exception('enameId有误', 410001);
		}
		if(empty($params->invoiceId))
		{
			throw new \Exception('发票ID有误', 420016);
		}
		// 验证
		$invoiceBase = $this->finInvoiceLib->getInvoiceOne(array('invoiceId' => $params->invoiceId));
		if($invoiceBase['InvoiceStatus'] != 1)
		{
			throw new \Exception('状态错误,无法操作', 420018);
		}
		if($invoiceBase['EnameId'] != $params->enameId)
		{
			throw new \Exception('非法操作不允许取消他人申请的发票', 420019);
		}
		$updatData = array('enameId'=> $invoiceBase['EnameId'],'invoiceFare'=> $invoiceBase['InvoiceAmout'],
				'action'=> 2,'type'=> $invoiceBase['DealWay']);
		if($invoiceBase['DealWay'] == 2)
		{
			$updatData['year'] = date('Y',$invoiceBase['CreateTime']);
		}
		if($invoiceBase['DealWay'] == 5)
		{
			$updatData['year']=$this->getInvoiceYearByRedis($invoiceBase['InvoiceId']);
		}
		if(in_array($invoiceBase['DealWay'], array(1,2,4,5)))
		{
			// 更新用户可用发票金额
			if(FALSE == $this->setInvoiceFare($updatData))
			{
				\core\Log::write(json_encode($updatData), 'invoice');
				throw new \Exception('更新发票金额出错', 420014);
			}
		}
		// 可用余额更新
		$amountFee = $this->conf->invoice->amountFee;
	 	// 在线付快递费
		$invoiceBase = $this->finInvoiceLib->getInvoiceOne(array('invoiceId' => $params->invoiceId));
		if($invoiceBase['PayWay']=='2')
		{
			$finOrder = new \interfaces\manage\Finance();
			if(FALSE == $finOrder->cancelOrder((object) array('enameId' => $invoiceBase['EnameId'],
					'orderId' => $invoiceBase['OrderId'])))
			{
				\core\Log::write(json_encode(array('enameId' => $invoiceBase['EnameId'],
						'orderId' => $invoiceBase['OrderId'], 'function' => 'cancelOrder')), 'invoice');
				throw new \Exception('取消订单失败', 410054);
			}
		}
		$set = array('status' => 2, 'updateTime' => time());
		$data = array('invoiceId' => $params->invoiceId, 'enameId' => $params->enameId);
		$updateResult = $this->finInvoiceLib->updateInvoice($set, $data);
		if($updateResult)
		{
			if($invoiceBase['DealWay'] == 5 || $invoiceBase['DealWay'] == 3)
			{
				$redis = \core\RedisLib::getInstance('manage', false);
				$redis->delete('invoice_fare_'.$params->invoiceId);
			}
			// 添加操作记录处理
			$domainLogsLib = new \lib\manage\domain\DomainLogsLib();
			$domainLogsLib::addDomainService($params->invoiceId, '取消申请', 68, $params->enameId, $params->enameId);
			return $updateResult;
		}
	}

	/**
	 * 发票审核处理
	 *
	 * @param object
	 * @return number|boolean
	 */
	public function dealInvoice($params)
	{
		if(empty($params->invoiceId))
		{
			throw new \Exception('发票ID有误', 410013);
		}
		// 验证
		$set = $this->setData($params);
		$invoiceBase = $this->finInvoiceLib->getInvoiceOne(array('invoiceId'=> $params->invoiceId));
		if($set['status'] == $invoiceBase['InvoiceStatus'])
		{
			throw new \Exception('状态错误,无法操作', 410160);
		}
		if(!empty($set['status']) && (in_array($set['status'], array(3,4,5,6))))
		{
			// 发票审核通过操作处理
			if($set['status'] == '3')
			{
				$operateContent = "发票审核通过";
				$tplData = array('title' => '审核通过', 'result' => '审核通过', 'explain' => '发票将稍后寄出，您可以在发票列表查看快递信息。');
			}
			// 发票审核不通过操作
			elseif($set['status'] == '4')
			{
				if(empty($set['operateRemarks']))
				{
					throw new \Exception('请在管理员备注填写发票审核不通过的原因', 420020);
				}
				$this->checkFail($invoiceBase);
				$operateContent = "发票审核不通过";
				$explain = '原因：(' . $set['operateRemarks'] . ')';
				$tplData = array('title' => '审核不通过', 'result' => '审核不通过', 'explain' => $explain);
			}
			// 发票寄出信息填写
			elseif($set['status'] == '5') 
			{
				//是否有付费方式改为到付操作
				if(isset($params->payWay) && $params->payWay==3 && $invoiceBase['PayWay']==2)
				{
					$operateContent = "付费更改为到付";
					$set['payWay']=3;
					$set['deliveryFare']=0;
					$finOrder = new \interfaces\manage\Finance();
					$finOrder->cancelOrder(
						(object)array('enameId'=> $invoiceBase['EnameId'],'orderId'=> $invoiceBase['OrderId']));
				}
				//若快递单号和发票号码都填写了设置操作状态为已寄出 出否则状态不变
				if(isset($set['invoiceNumber']) && isset($set['deliveryNumber']) && $set['invoiceNumber'] &&
					 $set['deliveryNumber']||isset($set['invoiceNumber']) && $set['invoiceNumber'] && $invoiceBase['InvoiceType']=='3')
				{
					$sendResult = $this->sendInvoice($invoiceBase, $params);
					if($sendResult == 2)
					{
						$set['deliveryFare'] = 0;
					}
					$operateContent = "发票寄出";
				}
				else
				{
					if(isset($set['invoiceNumber']) && $set['invoiceNumber'])
					{
						$operateContent = "发票号码填写";
					}
					if(isset($set['deliveryNumber']) && $set['deliveryNumber'])
					{
						$operateContent = "快递单号填写";
					}
					unset($set['status']);
				}
			}
			//发票退回
			elseif($set['status'] == '6')
			{
				$this->checkReturn($invoiceBase);
				$operateContent = "发票退回";
			}
		}
		else
		{
			throw new \Exception('状态错误,无法操作', 420018);
		}
		//更改发票信息
		if(isset($set['operateRemarks']))
		{
			$set['operateRemarks']=$invoiceBase['OperateRemarks'].'<BR/>'.date("Y-m-d H:i:s",time()).':'.$set['operateRemarks'];
			$set['operateRemarks']=ltrim($set['operateRemarks'],'<BR/>');
		}
		$set = array_merge($set, array('adminId'=> $params->adminId,'updateTime'=> time()));
		$data = array('invoiceId'=> $params->invoiceId);
		if($this->finInvoiceLib->updateInvoice($set, $data))
		{
			// 若为审核通过或审核不通过操作发站内信和邮件
			if(! empty($set['status']) && (in_array($set['status'], array(3,4))))
			{
				$templateId = $this->conf->invoice->templateId;
				$userMemberLogic = new \logic\manage\member\UserMemberLogic();
				$enameInfo = $userMemberLogic->getMemberInfo($params->enameId);
				$email = $enameInfo['Email'];
				$queueIf = new \interfaces\manage\Queue();
				$rs = $queueIf->sendMail($templateId, $email, $tplData, $params->enameId, 0, 'sendmail', 3) &&
					 $queueIf->sendSiteMsg($params->enameId, $templateId, $tplData, 6);
			}
			// 添加操作记录处理
			$domainLogsLib = new \lib\manage\domain\DomainLogsLib();
			$domainLogsLib::addDomainService($params->invoiceId, $operateContent, 68, $params->adminId, 
				$params->adminId);
			if(in_array($invoiceBase['DealWay'], array(3, 5)) && in_array($set['status'], array(4, 6)))
			{
				$redis = \core\RedisLib::getInstance('manage', false);
				$redis->delete('invoice_fare_' . $params->invoiceId);
			}
			return true;
		}
	}
	//发票寄出操作处理
	private function sendInvoice($invoiceBase,$params)
	{
		$updatData = array('enameId'=> $invoiceBase['EnameId'],'invoiceFare'=> $invoiceBase['InvoiceAmout'],
				'action'=> 3,'type'=> $invoiceBase['DealWay']);
		if($invoiceBase['DealWay'] == 2 )
		{
			$updatData['year'] = date('Y', $invoiceBase['CreateTime']);
		}
	    if($invoiceBase['DealWay'] == 5 || $invoiceBase['DealWay'] == 3)
		{
			$updatData['year'] = $this->getInvoiceYearByRedis($invoiceBase['InvoiceId']);
		}
		// 更新用户可用发票金额
		if(FALSE == $this->setInvoiceFare($updatData))
		{
			\core\Log::write(json_encode($updatData), 'invoice');
			throw new \Exception('更新发票金额出错', 420014);
		}
		if($invoiceBase['PayWay'] == '2' && ! (isset($params->payWay) && $params->payWay == 3))
		{
			$finOrder = new \interfaces\manage\Finance();
			if(!isset($params->conformOrder) || (isset($params->conformOrder)&&$params->conformOrder))
			{
				$finOrder->confirmOrder((object) array('enameId' => $invoiceBase['EnameId'],
						'orderId' => $invoiceBase['OrderId']));
				return 1;//收取了快递费
			}
			else 
			{
				$finOrder->cancelOrder(
					(object)array('enameId'=> $invoiceBase['EnameId'],'orderId'=> $invoiceBase['OrderId']));
				return 2;//取消了快递费
			}
		} 
		return 3;//未收取快递费
	}
	// 发票审核不通过操作处理
	private function checkFail($invoiceBase)
	{
		$updatData = array('enameId'=> $invoiceBase['EnameId'],'invoiceFare'=> $invoiceBase['InvoiceAmout'],
				'action'=> 2,'type'=> $invoiceBase['DealWay']);
		if($invoiceBase['DealWay'] == 2 )
		{
			$updatData['year'] = date('Y',$invoiceBase['CreateTime']);
		}
		if($invoiceBase['DealWay'] == 5 || $invoiceBase['DealWay'] == 3)
		{
			$updatData['year'] = $this->getInvoiceYearByRedis($invoiceBase['InvoiceId']);
		}
		if(in_array($invoiceBase['DealWay'], array(1,2,4,5)))
		{
			// 更新用户可用发票金额
			if(FALSE == $this->setInvoiceFare($updatData))
			{
				\core\Log::write(json_encode($updatData), 'invoice');
				throw new \Exception('更新发票金额出错', 420014);
			}
		}
		// 在线付快递费
		$amountFee = $this->conf->invoice->amountFee;
		if($invoiceBase['PayWay'] == '2')
		{
			$finOrder = new \interfaces\manage\Finance();
			$finOrder->cancelOrder(
				(object)array('enameId'=> $invoiceBase['EnameId'],'orderId'=> $invoiceBase['OrderId']));
		}
	}
	// 发票退回处理
	private function checkReturn($invoiceBase)
	{
		$leftMoney = $invoiceBase['InvoiceAmout'];
// 		$this->checkRebackFare($invoiceBase['EnameId'], "Used", $leftMoney, $invoiceBase['DealWay'],date('Y',$invoiceBase['CreateTime']));
		if($invoiceBase['DealWay'] == 1)
		{
			$fareInfoYest = $this->getInvoiceFare(array('enameId'=> $invoiceBase['EnameId'],'year'=> date('Y',$invoiceBase['CreateTime']) - 1));
			if($fareInfoYest)
			{
				if($fareInfoYest['0']['Used'] > $leftMoney)
				{
					$updateData['canUse'] = $fareInfoYest['0']['Canuse'] + $leftMoney;
					$updateData['used'] = $fareInfoYest['0']['Used'] - $leftMoney;
					$leftMoney = 0;
				}
				else
				{
					$updateData['canUse'] = $fareInfoYest['0']['Canuse'] + $fareInfoYest['0']['Used'];
					$updateData['used'] = 0;
					$leftMoney = $leftMoney - $fareInfoYest['0']['Used'];
				}
				$status = $this->finInvoiceLib->updateInvoiceFareOnly(
					array('enameId'=> $invoiceBase['EnameId'],'year'=>  date('Y',$invoiceBase['CreateTime']) - 1), $updateData);
				\core\Log::write("old year fare admin," . json_encode($fareInfoYest), 'finance', 'invoicefare');
				if(! $status)
				{
					throw new \Exception("设置可开票额度错误" ,410090);
				}
			}
		}
		if($leftMoney == 0)
		{
			return true;
		}
		if($invoiceBase['DealWay'] == 3 || $invoiceBase['DealWay'] == 5)
		{
			$year = $this->getInvoiceYearByRedis($invoiceBase['InvoiceId']);
		}
		else
		{
			$year = date('Y',$invoiceBase['CreateTime']);
		}
		$fareInfo = $this->getInvoiceFare(array('enameId'=> $invoiceBase['EnameId'],'year'=> $year));
		if(empty($fareInfo)) // 没有找到当年度的话当做添加处理
		{
			throw new \Exception("查无可用发票金额", 410082);
		}
		$updateData['canUse'] = $fareInfo['0']['Canuse'] + $leftMoney;
		$updateData['used'] = $fareInfo['0']['Used'] - $leftMoney;
		$status = $this->finInvoiceLib->updateInvoiceFareOnly(array('enameId'=> $invoiceBase['EnameId'],'year'=> $year), 
			$updateData);
		\core\Log::write("old year fare admin," . json_encode($fareInfo), 'finance', 'invoicefare');
		if(! $status)
		{
			throw new \Exception("设置可开票额度错误" ,410090);
		}
		return true;
	}
	
	public function checkRebackFare($enameId,$item,$checkfare, $type, $year = FALSE)
	{
		$fareInfo = $this->getInvoiceFare(array('enameId' => $enameId));
		if(empty($fareInfo))
		{
			throw new \Exception("查询用户发票额度失败", 410091);
		}
		$year = $year ? $year : date('Y');
		$lastY = $nyear = $bothYear = 0.0000;
		foreach($fareInfo as $info)
		{
			if(in_array($info['Year'], array($year, $year - 1)))
			{
				$bothYear += $info[$item];
			}
		}
		foreach($fareInfo as $info)
		{
			if($info['Year'] == $year)
			{
				$nyear = $info[$item];
				break;
			}
		}
		foreach($fareInfo as $info)
		{
			if($info['Year'] == $year - 1)
			{
				$lastY = $info[$item];
				break;
			}
		}
		$return = $type == 1 ? $bothYear : ($type == 2 ? $nyear : $lastY);
		$return = sprintf("%.2f", $return);
		$checkfare = sprintf("%.2f", $checkfare);
		if($return < $checkfare)
		{
			throw new \Exception("发票额度回退金额错误", 410092);
		}
		return $return;
	}
	
	/**
	 * 获取发票记录列表
	 *
	 * @param object
	 * @return array|boolean
	 *
	 */
	public function getInvoiceList($params)
	{
		try
		{
			$data = $this->setData($params);
			if(isset($params->offset))
			{
				$data['offset'] = $params->offset;
			}
			if(!empty($params->num))
			{
				$data['num'] = $params->num;
			}
			return $this->finInvoiceLib->getInvoiceList($data);
		}
		catch(\Exception $e)
		{
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}

	/**
	 * 用户获取发票基本信息
	 *
	 * @param object
	 * @return array|boolean
	 *
	 */
	public function userGetInvoice($params)
	{
		$return = array();
		$financeLogic = new \logic\manage\finance\FinanceLogic();
		// 可用余额
		$return['canUseMoney'] = number_format($financeLogic->getBalance($params), 2);
		try 
		{
			$return['invoiceAllAmount'] = $this->getCanUseInvoiceFare(array('enameId' => $params->enameId));
		}
		catch(\Exception $e)
	    {
	    	\core\Log::write("getCanUseInvoiceFare fail," . json_encode($e->getMessage()), 'finance', 'invoicefare');
	    }
		$data = $this->setData($params);
		// 发票基本信息
		$invoiceDefaultInfo = $this->finInvoiceLib->getInvoiceOne($data);
		if($invoiceDefaultInfo)
		{
			$return['invoiceDefaultInfo'] = $invoiceDefaultInfo;
		}
		// 单独获得发票抬头
		$rowData = array('EnameId' => $params->enameId, 'VerifyStatus' => 2, 'IsBound' => 1);
		$identityVerifyMod = new \models\manage\verify\IdentityVerifyMod();
		$return['perIdentityVerify'] = $identityVerifyMod->getVerifyInfo($rowData); 
		$companyVerifyMod = new \models\manage\verify\CompanyVerifyMod();
		$return['perCompanyVerify'] = $companyVerifyMod->getVerifyInfo($rowData);
		$proxyInvoiceMod = new \models\manage\verify\ProxyInvoiceMod();
		$return['proxyIdentityVerify'] = $proxyInvoiceMod->getProxyInvoiceList(array('Type' => 1, 'Status' => 2, 'EnameId' => $params->enameId));
		$return['proxyCompanyVerify'] = $proxyInvoiceMod->getProxyInvoiceList(array('Type' => 2, 'Status' => 2, 'EnameId' => $params->enameId));
		return $return;
	}

	/**
	 * 获取可开发票金额信息
	 *
	 * @param array('enameId'=> enameId)
	 * @return array eg array("2015"=》array("Canuse"=》15418.2,'Freezes'=>1000),"2014"=》array("Canuse"=》15418.2,'Freezes'=>1000))
	 */
	public function getCanUseInvoiceFare($params, $throw = TRUE)
	{
		$invoiceFareInfo = $this->getInvoiceFare($params);
		$return = array();
		if(!empty($invoiceFareInfo))
		{
			foreach($invoiceFareInfo as $v)
			{
				$return[$v['Year']] = array("Canuse" => $v['Canuse'], 'Freezes' => $v['Freezes']);
			}
		}
		else
		{
			if($throw)
			{
				throw new \Exception("查无可用发票金额", 410082);
			}
		}
		return $return;
	}

	/**
	 * 操作员获取发票详细信息
	 *
	 * @param object
	 * @return array|boolean
	 *
	 */
	public function operGetInvoice($params)
	{
		if(empty($params->invoiceId))
		{
			throw new \Exception('发票ID有误', 410013);
		}
		try
		{
			$data = $this->setData($params);
			$return['invoiceInfo'] = $this->finInvoiceLib->getInvoiceOne($data);
			if(!empty($return['invoiceInfo']) && is_array($return['invoiceInfo']))
			{
				// 可开发票总金额
				$return['invoiceAllAmount'] = $this->getCanUseInvoiceFare(array(
						'enameId' => $return['invoiceInfo']['EnameId']),false);
				// 获取发票操作记录信息
				$dataTemp['ServiceType'] = 68;
				$dataTemp['Domain'] = $params->invoiceId;
				$domainLogsLib = new \lib\manage\domain\DomainLogsLib();
				$return['invoiceOperInfo'] = $domainLogsLib::getDomainService($dataTemp);
				// 获取关联发票【EnameId相同、寄送同一地址、邮寄方式相同、状态为已通过审核、或待审核的】
				$return['invoiceLinkInfo'] = $this->finInvoiceLib->getInvoiceList(
					array('enameId'=> $return['invoiceInfo']['EnameId'],
							'chProvince'=> $return['invoiceInfo']['ChProvince'],
							'invoiceAddress'=> $return['invoiceInfo']['InvoiceAddress'],
							'deliveryType'=> $return['invoiceInfo']['DeliveryType'],'status'=> array(1,3)		
					));
			}
			return $return;
		}
		catch(\Exception $e)
		{
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}

	/**
	 * 获取发票记录数
	 *
	 * @param array
	 * @return number|boolean
	 *
	 */
	public function getInvoiceCount($params)
	{
		try
		{
			$data = $this->setData($params);
			return $this->finInvoiceLib->getInvoiceCount($data);
		}
		catch(\Exception $e)
		{
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}
	/**
	 * 统计开票金额
	 */
	public function getInvoiceStatic($params)
	{
		try
		{
			$data = $this->setData($params);
			return $this->finInvoiceLib->getInvoiceStatic($data);
		}
		catch(\Exception $e)
		{
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}
	
	private function setData($params)
	{
		$data = array();
		if(!empty($params->invoiceId))
		{
			$data['invoiceId'] = $params->invoiceId;
		}
		if(!empty($params->enameId))
		{
			$data['enameId'] = $params->enameId;
		}
		if(!empty($params->status))
		{
			$data['status'] = $params->status;
		}
		if(!empty($params->startDate))
		{
			$data['startDate'] = $params->startDate;
		}
		if(!empty($params->endDate))
		{
			$data['endDate'] = $params->endDate;
		}
		if(!empty($params->isDefault))
		{
			$data['isDefault'] = $params->isDefault;
		}
		if(!empty($params->deliveryNumber))
		{
			$data['deliveryNumber'] = $params->deliveryNumber;
		}
		if(!empty($params->operateRemarks))
		{
			$data['operateRemarks'] = $params->operateRemarks;
		}
		if(!empty($params->invoiceNumber))
		{
			$data['invoiceNumber'] = $params->invoiceNumber;
		}
		if(!empty($params->dealWay))
		{
			$data['dealWay'] = $params->dealWay;
		}
		if(!empty($params->invoiceType))
		{
			$data['invoiceType'] = $params->invoiceType;
		}
		if(!empty($params->deliveryType))
		{
			$data['deliveryType'] = $params->deliveryType;
		}
		if(!empty($params->updateStartDate))
		{
			$data['updateStartDate'] = $params->updateStartDate;
		}
		if(!empty($params->updateEndDate))
		{
			$data['updateEndDate'] = $params->updateEndDate;
		}
		if(!empty($params->linkPhone))
		{
			$data['linkPhone'] = $params->linkPhone;
		}
		if(!empty($params->chProvince))
		{
			$data['chProvince'] = $params->chProvince;
		}
		if(!empty($params->invoiceRecipient))
		{
			$data['invoiceRecipient'] = $params->invoiceRecipient;
		}
		if(!empty($params->invoiceTitle))
		{
			$data['invoiceTitle'] = $params->invoiceTitle;
		}
		return $data;
	}
	/**
	 * 添加/更新用户可用发票金额
	 *
	 * @param s array('enameId'=>'1001','invoiceFare'=>'10086','year'=>2014)
	 */
	public function addInvoiceFare($data)
	{
		$data = (array) $data;
		if(empty($data['enameId']) || empty($data['invoiceFare']))
		{
			return FALSE;
		}
		$year = !empty($data['year']) ? $data['year'] : date('Y');
		$enameId = $data['enameId'];
		$fare = $data['invoiceFare'];
		$fareInfo = $this->getInvoiceFare(array('enameId' => $enameId, 'year' => $year));
		if(empty($fareInfo))
		{
			$data = array('enameId' => $enameId, 'year' => $year, 'canUse' => $fare);
			return $this->finInvoiceLib->addInvoiceFare($data);
		}
		return $this->finInvoiceLib->updateInvoiceFare(array('enameId' => $enameId, 'year' => $year), array(
				'canUse' => $fare));
	}

	/**
	 * 获取用户的可开发票金额
	 */
	public function getInvoiceFare($data,$one = FALSE)
	{ 
		return $this->finInvoiceLib->getInvoiceFare((array) $data,$one);
	}

	/**
	 * @param unknown_type $type 发票类型
	 * @param unknown_type $action 审核通过  解冻 冻结
	 * @param unknown_type $enameId 用户id
	 * @param unknown_type $year 查询年份
	 * @param unknown_type $yearFare 查询的信息
	 * @param unknown_type $checkYear 另外一年
	 * @param unknown_type $checkFare 另外一年的信息
	 * @throws Exception
	 */
	private function setInvoiceBothYear($type, $action, $enameId, $year, $fareInfo, $checkYear, $checkFare, $fare)
	{
		//两年都可以操作
		$yearFreeze = 0.00;//当年需要冻结的
		$yearCanUseLe = 0.00;//当年需要扣除的可用
		$checkFreeze = 0.00;//额外一年需要冻结的
		$checkCanUseL = 0.00;//额外需要扣除的
		$checkKey = $action == 1 ? 'Canuse' : 'Freezes';
		$allValue = $fareInfo && $fareInfo[$checkKey] ? $fareInfo[$checkKey] : 0.00;
		$allValue += $checkFare && $checkFare[$checkKey] ? $checkFare[$checkKey] : 0.00;
		$fare = sprintf("%.2f",$fare);
		$allValue = sprintf("%.2f",$allValue);
		if($fare > $allValue)
		{
			if ($action == 1)
			{
				throw new \Exception("可用发票金额不足"  ,410083);
			}
			else 
			{
				throw new \Exception("可解冻金额错误" , 410084);
			}
		}
		if($action == 1) // 冻结 提交申请的时候
		{
			if($fareInfo && $fareInfo['Canuse'])//当年额度够的话
			{
				$yearFreeze = $fareInfo['Canuse'] >= $fare ? $fare : $fareInfo['Canuse'];//需要冻结的金额
				$yearCanUseLe = $yearFreeze;//需要扣除的金额
			}
			if($checkFare && $checkFare['Canuse'])
			{
				if($fare > $yearFreeze)//当年额度不够的话 需要从额外的年份冻结
				{
					$checkFreeze = $checkFare['Canuse'] > ($fare - $yearFreeze) ? $fare - $yearFreeze : $checkFare['Canuse'];//需要冻结的减去当年最大可以冻结的 剩下的旧是额外年度要冻结的
					$checkCanUseL = $checkFreeze; //额外年度需要扣除的金额
				}
			}
			if($fare > sprintf("%.2f",$yearFreeze + $checkFreeze))//再次检测一次
			{
				throw new \Exception("可用发票金额不足", 410083);
			}
			if($yearFreeze > 0)
			{
				$yearStatus = $this->finInvoiceLib->updateInvoiceFare(array('id' => $fareInfo['Id']), array(
						'canUse' => -$yearCanUseLe, 'freezes' => $yearFreeze));
				if(!$yearStatus)
				{
					\core\Log::write("action1 freezes failed,year,id" . $fareInfo['Id'] . ',' . $yearCanUseLe . ',' . $yearFreeze, 'finance', 'invoicefareafter');
					throw new Exception("冻结发票金额错误" . $fareInfo['Id'] . ',' . $yearCanUseLe . ',' . $yearFreeze);
				}
			}
			if($checkFreeze > 0)
			{
				$checkStatus = $this->finInvoiceLib->updateInvoiceFare(array('id' => $checkFare['Id']), array(
						'canUse' => -$checkCanUseL, 'freezes' => $checkFreeze));
				if(!$checkStatus)
				{
					\core\Log::write("action1 failed,checkyear,id" . $checkFare['Id'] . ',' . $checkCanUseL . ',' . $checkFreeze, 'finance', 'invoicefareafter');
				}
			}
			//暂时未使用事务阿阿阿
			return true;
		}
		elseif($action == 2) // 审核不通过的时候 解冻原路退回
		{
			if($fareInfo && $fareInfo['Freezes'])//当年冻结额度够解冻的话
			{
				$yearFreeze = $fareInfo['Freezes'] >= $fare ? $fare : $fareInfo['Freezes'];//如果当年可解冻额度大于需要解冻的额度  需要扣除的解冻金额
				$yearCanUseLe = $yearFreeze;//需要添加的额度
			}
			if($checkFare && $checkFare['Freezes'])
			{
				if($fare > $yearFreeze)//当年所能够解冻的金额比要解冻的金额小的话
				{
					$checkFreeze = $checkFare['Freezes'] > ($fare - $yearFreeze) ? $fare - $yearFreeze : $checkFare['Freezes'];//需要冻结的减去当年最大可以冻结的 剩下的旧是额外年度要冻结的
					$checkCanUseL = $checkFreeze; //额外年度需要添加的金额
				}
			}
			$yearFreeze = sprintf("%.2f",$yearFreeze);
			$checkFreeze = sprintf("%.2f",$checkFreeze);
			if($fare > sprintf("%.2f",$yearFreeze + $checkFreeze))//再次检测一次
			{
				throw new \Exception("可解冻金额错误", 410084);
			}
			if($yearFreeze > 0)
			{
				$yearStatus = $this->finInvoiceLib->updateInvoiceFare(array('id' => $fareInfo['Id']), array(
						'canUse' => $yearCanUseLe, 'freezes' => -$yearFreeze));
				if(!$yearStatus)
				{
					\core\Log::write("action2 freezes failed,year,id" . $fareInfo['Id'] . ',' . $yearCanUseLe . ',' . $yearFreeze, 'finance', 'invoicefareafter');
					throw new Exception("解冻发票金额错误" . $fareInfo['Id'] . ',' . $yearCanUseLe . ',' . $yearFreeze);
				}
			}
			if($checkFreeze > 0)
			{
				$checkStatus = $this->finInvoiceLib->updateInvoiceFare(array('id' => $checkFare['Id']), array(
						'canUse' => $checkCanUseL, 'freezes' => -$checkFreeze));
				if(!$checkStatus)
				{
					\core\Log::write("action2 failed,checkyear,id" . $checkFare['Id'] . ',' . $checkCanUseL . ',' . $checkFreeze, 'finance', 'invoicefareafter');
				}
			}
			return true;
		}
		elseif($action == 3) // 审核通过的时候 
		{
			if($fareInfo && $fareInfo['Freezes'])//当年冻结额度够解冻的话
			{
				$yearFreeze = $fareInfo['Freezes'] >= $fare ? $fare : $fareInfo['Freezes'];//如果当年可解冻额度大于需要解冻的额度  需要扣除的解冻金额
				$yearCanUseLe = $yearFreeze;//需要添加的已用额度
			}
			if($checkFare && $checkFare['Freezes'])
			{
				if($fare > $yearFreeze)//当年所能够解冻的金额比要解冻的金额小的话
				{
					$checkFreeze = $checkFare['Freezes'] > ($fare - $yearFreeze) ? $fare - $yearFreeze : $checkFare['Freezes'];//需要冻结的减去当年最大可以冻结的 剩下的旧是额外年度要冻结的
					$checkCanUseL = $checkFreeze; //需要添加的已用额度
				}
			}
			$yearFreeze = sprintf("%.2f",$yearFreeze);
			$checkFreeze = sprintf("%.2f",$checkFreeze);
			if($fare > sprintf("%.2f",$yearFreeze + $checkFreeze))//再次检测一次
			{
				throw new \Exception("可解冻金额错误," .$fare . ','.($yearFreeze + $checkFreeze) , 410084);
			}
			if($yearFreeze > 0)
			{
				$yearStatus = $this->finInvoiceLib->updateInvoiceFare(array('id' => $fareInfo['Id']), array(
						'used' => $yearCanUseLe, 'freezes' => -$yearFreeze));
				if(!$yearStatus)
				{
					\core\Log::write("action3 freezes failed,year,id" . $fareInfo['Id'] . ',' . $yearCanUseLe . ',' . $yearFreeze, 'finance', 'invoicefareafter');
					throw new Exception("解冻发票金额错误" . $fareInfo['Id'] . ',' . $yearCanUseLe . ',' . $yearFreeze);
				}
			}
			if($checkFreeze > 0)
			{
				$checkStatus = $this->finInvoiceLib->updateInvoiceFare(array('id' => $checkFare['Id']), array(
						'used' => $checkCanUseL, 'freezes' => -$checkFreeze));
				if(!$checkStatus)
				{
					\core\Log::write("action3 failed,checkyear,id" . $checkFare['Id'] . ',' . $checkCanUseL . ',' . $checkFreeze, 'finance', 'invoicefareafter');
				}
			}
			return true;
		}
	}

	/**
	 * 今年/去年操作
	 */
	public function setInvoiceOne($action, $enameId, $year, $fareInfo, $fare,$type)
	{
		if(empty($fareInfo) || $year != $fareInfo['Year'])
		{
			throw new \Exception('暂无可操作发票金额' ,410093);
		}
		$canUse = $fareInfo['Canuse'];
		$used = $fareInfo['Used'];
		$freezes = $fareInfo['Freezes'];
		$status=false;
		//if($action != 4){}//过滤非后台发票操作
		$errmsg = $action == 1 ? '可用发票金额不足' : '可解冻金额错误';
		$status = $action == 1|| $type == 3 ? $canUse < $fare : $freezes < $fare;
		if($status)
		{
			throw new \Exception($errmsg);
		}
		if($action == 1 && in_array($type,array(1,2,4,5)))//冻结 今年 混合 提交申请的时候
		{
			$setStatus = $this->finInvoiceLib->updateInvoiceFare(array('id' => $fareInfo['Id']), array(
					'canUse' => -$fare, 'freezes' => $fare));
		}
		elseif($action == 2 && in_array($type,array(1,2,4,5)))//审核不通过  今年 混合 后台混合 后台今年
		{
			$setStatus = $this->finInvoiceLib->updateInvoiceFare(array('id' => $fareInfo['Id']), array('canUse' => $fare, 'freezes' => -$fare));
		}
		else if($action ==3)// 审核通过的时候
		{
			$set = $type == 5 ||$type == 4 ||$type == 2 || $type == 1 ? array('used' => $fare, 'freezes' => -$fare) : array('used' => $fare, 'canUse' => -$fare);
			$setStatus = $this->finInvoiceLib->updateInvoiceFare(array('id' => $fareInfo['Id']), $set);
		}
		else
		{
			throw new \Exception("操作类型错误" , 322035);
		}
		if(!$setStatus)
		{
			throw new \Exception("操作失败,请重试");
		}
		return true;
	}

	/**
	 * 限制发票类型和年份
	 */
	private function checkYearType($year, $type)
	{
		$st = TRUE;
		if($type == 1 || $type==4)
		{
			$st = in_array($year, array(date('Y'), (date('Y') - 1)));
		}
		elseif($type == 2|| $type==5)
		{
			$st = $year == date('Y');
		}
		else
		{
			$st = $year == (date('Y') - 1);
		}
		if(FALSE == $st)
		{
			throw new \Exception("开发票年份跟类型不符合");
		}
	}

	/**
	 * 开发票金额冻结/解冻
	 * type  1 前台开混合  2 前台开今年  3 前台开指定年份【不冻结方式、默认去年】  4 后台混合 5 后台开指定年份【冻结方式、默认今年】
	 */
	public function setInvoiceFare($data) 
	{
		
		$data = (array) $data;
		if(empty($data['action']) || empty($data['enameId']) || empty($data['invoiceFare']) || empty($data['type']))
		{
			throw new \Exception("参数错误" , 410043);
		}
		$action = $data['action']; // 冻结还是解冻 1冻结 2解冻
		$enameId = $data['enameId'];
		$fare = $data['invoiceFare'];
		$year = !empty($data['year']) ? $data['year'] : date('Y') - 1;
// 		$this->checkYearType($year, $data['type']);
		$checkYear = $year == date('Y') ? $year - 1 : $year + 1;
		$fareInfo = $this->getInvoiceFare(array('enameId' => $enameId, 'year' => $year),true);//查询的情况
		$checkFare = $this->getInvoiceFare(array('enameId' => $enameId, 'year' => $checkYear), true); // 去年或者今年的情况
		if($data['type'] == 1 || $data['type'] == 4)
		{
			return $this->setInvoiceBothYear($data['type'], $action, $enameId, $year, $fareInfo, $checkYear, $checkFare, $fare);
		}
// 		$fareInfo = ($data['type'] == 5 ||$data['type'] == 2 || $data['type'] == 3 && $year == date('Y') -1 ) ? $fareInfo : $checkFare;
		return $this->setInvoiceOne($action, $enameId, $year, $fareInfo, $fare,$data['type']);
	}

	/**
	 * 设置用户开票额度 can use
	 */
	public function setUserInvoiceFare($data)
	{
		$enameId = $data->enameId;
		$year = $data->year;
		$fareInfo = $this->getInvoiceFare(array('enameId' => $enameId, 'year' => $year));
		if(empty($fareInfo))//没有找到当年度的话当做添加处理
		{
			$fare = $data->fare;
			$status = $this->finInvoiceLib->addInvoiceFare(array("enameId" => $enameId, 'canUse' => $fare,'year'=>$year));
		}
		else
		{
			if(isset($data->addFare)&&$data->addFare)
			{
				$fare=$fareInfo['0']['Canuse']+$data->addFare;
			}
			else
			{
				$fare = $data->fare;
			}
			$status = $this->finInvoiceLib->updateInvoiceFareOnly(array('enameId' => $enameId,'year'=>$year), array('canUse' => $fare));
			\core\Log::write("old year fare admin," . json_encode($fareInfo), 'finance', 'invoicefare');
		}
		if(!$status)
		{
			throw new \Exception("设置可开票额度错误" ,410090);
		}
		return true;
	}

	/**
	 * 更新用户发票信息
	 */
	public function setUserInvoice($params)
    {
    	$set = $this->setData($params);
    	$data = array('invoiceId' => $params->invoiceId);
    	$updateResult = $this->finInvoiceLib->updateInvoice($set, $data);
		if($updateResult)
		{
			if(isset($params->deliveryNumber) && $params->deliveryNumber)
			{
				$operateContent = '修改快递单号为' . $params->deliveryNumber;
			}
			elseif(isset($params->invoiceNumber) && $params->invoiceNumber)
			{
				$operateContent = '修改发票号码为' . $params->invoiceNumber;
			}
			// 添加操作记录处理
			$domainLogsLib = new \lib\manage\domain\DomainLogsLib();
			$domainLogsLib::addDomainService($params->invoiceId, $operateContent, 68, $params->adminId, $params->adminId);
    		return $updateResult;
    	}
    	throw new \Exception($operateContent. ',操作失败', 420021);
    }

	private function getInvoiceYearByRedis($invoiceId)
	{
		$redis = \core\RedisLib::getInstance('manage', false);
		$year = $redis->get('invoice_fare_' . $invoiceId);
		if(empty($year))
		{
			throw new \Exception('更新发票金额出错', 420014);
		}
		return $year;
	}
}

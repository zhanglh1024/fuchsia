<?php
namespace logic\manage\finance;

/**
 * 在线充值新接口 
 */
class PayCenterLogic
{
	private $payCenterLib;
	
	private $enameId;
	
	private $finPayMod;
	
	private $finLog;
	
	public function __construct($enameId = '') 
	{
		$this->payCenterLib = new \lib\manage\finance\PayCenterLib($enameId);
		$this->finPayMod = new \models\manage\finance\FinPayMod();
		$this->finLog = new \lib\manage\finance\FinanceLogLib();
	}
	
	public function getPayCenterCount($data)
	{
		return $this->payCenterLib->getPayCenterCount($data);
	}
	
	public function getPayCenterList($data)
	{
		return $this->payCenterLib->getPayCenterList($data);
	}
	
	public function addPayCenterInfo($data)
	{
		$return = $this->finPayMod->addPayInfo($data);
		if(!$return)
		{
			$this->finLog->log('添加充值款项失败', $data, 'false', 1);
		}
		return $return;
	}
	
	public function getPayCenterByPayId($data)
	{
		$return = $this->finPayMod->getInfoByPayId($data);
		if(!$return)
		{
			$return = self::acrossYearCompatible($data, 'getInfoByPayId', false);
		}
		if(!$return)
		{
			$this->finLog->log('获取在线支付记录失败', $data, 'false', 1);
		}
		return $return;
	}
	
	public function getPayCenterByTransId($data)
	{
		$return = $this->finPayMod->getInfoByTransId($data);
		if(!$return)
		{
			$return = self::acrossYearCompatible($data, 'getInfoByTransId');
		}
		if(!$return)
		{
			$this->finLog->log('获取在线支付记录失败', $data, 'false', 1);
		}
		return $return;
	}
	
	public function getPayCenter($data)
	{
		$return = $this->finPayMod->getPayInfo($data);
		if(!$return)
		{
			$return = self::acrossYearCompatible($data, 'getPayInfo', false);
		}
		if(!$return)
		{
			$this->finLog->log('获取在线支付记录失败', $data, 'false', 1);
		}
		return $return;
	}
	
	public function updateMargin($data)
	{
		$return = $this->finPayMod->setMarginPayInfo($data);
		if(!$return)
		{
			$return = self::acrossYearCompatible($data, 'setMarginPayInfo');
		}
		if(!$return)
		{
			$this->finLog->log('更新保证金信息失败', $data, $return, 1);
		}
		return $return;
	}
	
	public function updatePayInfo($data)
	{
		if(empty($data['payId']))
		{
			return false;
		}
		$return = $this->finPayMod->setPayInfo($data);
		if(!$return)
		{
			$return = self::acrossYearCompatible($data, 'setPayInfo');
		}
		if(!$return)
		{
			$this->finLog->log('在线支付失败', $data, 'false', 1);
		}
		return $return;
	}
	
	public function setPayInfoByMobile($data)
	{
		$return = $this->finPayMod->setPayInfoByMobile($data);
		if(!$return)
		{
			$return = self::acrossYearCompatible($data, 'setPayInfoByMobile');
		}
		if(!$return)
		{
			$this->finLog->log('根据mobile和payId更新充值订单EnameId失败', $data, 'false', 1);
		}
		return $return;
	}
	
	/**
	 * 年末跨年数据兼容处理(兼容一小时)
	 */
	private function acrossYearCompatible($data, $action, $checkTime = true)
	{
		$return = false;
		$newYear = date('Y') . '0101000000';
		$newYearUnix = strtotime($newYear);
		$nowUnix = time();
		if(! $checkTime || ($nowUnix >= $newYearUnix && $nowUnix <= $newYearUnix + 3600))
		{
			$return = $this->finPayMod->$action($data, date('Y') - 1);
		}
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'ext');
		\core\Log::write('年末跨年数据兼容,' . $action . ',' . json_encode($data), $conf->logFolder);
		return $return;
	}
	
	/**
	 * 充值成功的一系列更新操作
	 */
	public function doPaycenterUpdate($data)
	{
		if(empty($data['payId']) || ! is_numeric($data['payId']))
		{
			throw new \Exception('payId错误', 410100);
		}
		$payInfo = $this->getPayCenterByPayId(array(
				'payId' => $data['payId']
		));
		if(empty($payInfo))
		{
			throw new \Exception('查询充值记录失败', 410101);
		}
		$payInfo = $payInfo[0];
		$data['enameId'] = $payInfo['EnameId'];
		if($payInfo['IsSuccess'] == '1')
		{
			return true; // 订单已完成状态
		}
		if(empty($payInfo['RechargeMoney']))
		{
			throw new \Exception('订单金额数据异常', 410102);
		}
		if(round($payInfo['RechargeMoney'], 2) != $data['rechargeMoney'])
		{
			throw new \Exception('订单金额数据异常', 410102);
		}
		// 更新充值表
		$upRes = $this->updatePayInfo($data);
		if(! $upRes)
		{
			throw new \Exception('更新充值记录失败', 410103);
		}
		$finInMod = new \models\manage\finance\FinInMod();
		$financeIn = $finInMod->getFinanceInCount(array(
				'payId' => $data['payId'], 'enameId' => $data['enameId']
		));
		if(! empty($financeIn['sum']))
		{
			return true; // 存在入款记录
		}
		
		$financeInfoLib = new \lib\manage\finance\FinanceInfoLib($data['enameId']);
		$userFinInfo = $financeInfoLib->getUserFinance();
		if(empty($userFinInfo) || !isset($userFinInfo['UseMoney']))
		{
			throw new \Exception('获取用户财务信息失败', 410036);
		}
		$addInParams = array(
				'enameId' => $data['enameId'], 'payId' => $data['payId'], 'moneyType' => $payInfo['MoneyType'], 
				'inMoney' => $payInfo['RechargeMoney'], 
				'currentMoney' => $userFinInfo['UseMoney'] + $payInfo['RechargeMoney'], 'inType' => 200, 
				'bankName' => $data['payType']
		);
		$addFin = $finInMod->addFinanceIn($addInParams);
		if(empty($addFin))
		{
			throw new \Exception('添加到入款表失败', 410045);
		}
		$finMod = new \models\manage\finance\FinancesMod();
		if($payInfo['MoneyType'] == 4)
		{
			$params['m'] = $payInfo['RechargeMoney'];
		}
		else
		{
			$params['u'] = $payInfo['RechargeMoney'];
		}
		$addUserMoney = $finMod->addFinanceInMoney($data['enameId'], $params);
		if(empty($addUserMoney))
		{
			if(! $finInMod->delFinanceIn($addFin))
			{
				throw new \Exception('回滚入款记录失败', 410104);
			}
			throw new \Exception('更新用户财务信息失败', 410071);
		}
		if($payInfo['MoneyType'] == 2)
		{
			if(floor($payInfo['RechargeMoney']) >= 2000)
			{
				$userLogic = new \logic\manage\member\UserMemberLogic();
				$userLogic->setGoldMember((object) array(
						'enameId' => $data['enameId'], 'year' => 2
				));
			}
			elseif(floor($payInfo['RechargeMoney']) >= 1000)
			{
				$userLogic = new \logic\manage\member\UserMemberLogic();
				$userLogic->setGoldMember((object) array(
						'enameId' => $data['enameId'], 'year' => 1
				));
			}
		}
		$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'user_pay_success'));
		$amqp->sendMq(
			array('uid' => $data['enameId'], 'ip' => \common\Common::getRequestIp(), 
				'payType' => $payInfo['PayType'] == 1 ? 1 : ($payInfo['PayType'] == 6 ? 2 : ($payInfo['PayType'] == 7 ? 3 : 4)), 
				'price' => $payInfo['RechargeMoney'], 'from' => 1, 'time' => time())); 
		return true;
	}
}
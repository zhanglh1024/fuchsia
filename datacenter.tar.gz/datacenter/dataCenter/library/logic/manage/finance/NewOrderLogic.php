<?php
namespace logic\manage\finance;
 
/**
 * 新订单逻辑(改用事物处理)
 */
class NewOrderLogic
{
	private $financeMod;

	private $financeOrderMod;

	private $newOrderLib;

	private $newFinanceMod;
	
	private $conf;

	public function __construct()
	{
		$this->newFinanceMod = new \models\manage\finance\NewFinanceMod();
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
	}

	/**
	 * 订单处理 
	 * @param array $params
	 * @return array
	 */
	public function processOrder($params)
	{
		$returnData = false;
		$enameId = $params['enameId'];
		// 取消订单
		if(!empty($params['cancleOrderIds']))
		{
			$cancleOrderIds = explode(',', $params['cancleOrderIds']);
			$cancleOrderIds = array_unique($cancleOrderIds);
			$result = $this->newFinanceMod->cancelOrder($enameId, $cancleOrderIds);
		}
		// 有价格无订单id创建新订单，有订单id更新订单 
		if(!empty($params['price']))
		{
			if(!empty($params['orderId']))
			{
				try 
				{
					// 修改订单信息
					$returnData = $this->newFinanceMod->updateOrder($enameId, $params);
				}
				catch (\Exception $e)
				{
					// 如果订单已经不是处理中的状态创建新订单
					if($e->getCode() == 410218)
					{
						$returnData = $this->newFinanceMod->addOrder($params);
					}
					else
					{
						throw new \Exception($e->getMessage(), $e->getCode());
					}
				}
			}
			else
			{
				// 添加新订单
				$returnData = $this->newFinanceMod->addOrder($params);
			}
		}
		// 修改订单
		return $returnData;
	}
	
	public function entrustOrder($params)
	{
		return $this->newFinanceMod->entrustOrder($params);
	}
	
	public function batchSubMoney($params)
	{
		$enameId = $params['EnameId'];
		$domain = empty($params['Domain']) ? '' : $params['Domain'];
		$adminId = empty($params['AdminId']) ? '' : $params['AdminId'];
		$uniqueId = empty($params['UniqueId']) ? '0' : $params['UniqueId'];
		$allMoneySum = array_sum($params['AllMoney']);
		$moneyListSum = array_sum($params['MoneyList']);
		$allMoneySum = round($allMoneySum, 2);
		$moneyListSum = round($moneyListSum, 2);
		//检测扣款金额总额 是否 与各扣款款项相同
		if($allMoneySum != $moneyListSum)
		{
			throw new \Exception('总扣款金额[' . $allMoneySum . ']与各款项[' . $moneyListSum . ']不对!', '410216');
		}
		
		//扣除相应总金额
		$financeInfoLib = new \lib\manage\finance\FinanceInfoLib($enameId);
		$financeInfoLib->getUserFinance();
		if($params['AllMoney']['p'] > $financeInfoLib->getPublicMoney())
		{
			throw new \Exception('对公款金额不足:' . $params['AllMoney']['p'] . '>' . $financeInfoLib->getPublicMoney(), '410217');
		}
		if($params['AllMoney']['u'] > $financeInfoLib->getUnWithdrawalMoney())
		{
			throw new \Exception('不可提现金额不足:' . $params['AllMoney']['u'] . '>' . $financeInfoLib->getUnWithdrawalMoney(), '410217');
		}
		if($params['AllMoney']['w'] > $financeInfoLib->getWithdrawalMoney())
		{
			throw new \Exception('可提现金额不足:' . $params['AllMoney']['w'] . '>' . $financeInfoLib->getWithdrawalMoney(), '410217');
		}
		
		$financeOutLib = new \lib\manage\finance\FinanceOutLib($enameId);
		//查看是否已经存在对应的扣款记录（防止重复扣款）
		$checkUniqueIdRetrun = $financeOutLib->checkUniqueId($enameId, $uniqueId);
		if($checkUniqueIdRetrun)
		{
			throw new \Exception('该扣款编号[' . $uniqueId . ']已存在!', '420022');
		}
		
		$currentMoney = $financeInfoLib->getFreezeMoney() + $financeInfoLib->getPublicMoney() + $financeInfoLib->getUnWithdrawalMoney() + $financeInfoLib->getWithdrawalMoney() + $financeInfoLib->getMarginMoney();
		$financeInfoLib->setSubMoney($allMoneySum);
		$financeInfoLib->setFinanceType($params['Type']);
		$subReturn = $financeInfoLib->subUserFinanceMoney($params['AllMoney']);
		if(!$subReturn)
		{
			throw new \Exception('扣款总金额失败:' . $subReturn, '410035');
		}
		
		//添加扣款记录
		foreach($params['MoneyList'] as $key => $val)
		{
			if(empty($val))
			{
				continue;
			}
			//检测该记录是否已经存在
			//添加扣款记录
			$financeOutLib->setOutTypeSon($key);
			$financeOutLib->setCreateDate(date('Y-m-d H:i:s'));
			$currentMoney = $currentMoney - $val;
			$financeOutLib->setCurrentMoney($currentMoney);
			$financeOutLib->setOutMoney($val);
			$financeOutLib->setOutStatus(1);
			$financeOutLib->setOrderId('0');
			$financeOutLib->setOutType($params['Type']);
			$financeOutLib->setLinkEnameId('9999');
			$financeOutLib->setLinkDomain($domain);
		
			$remark = empty($params['Remark'][$key]) ? '' : $params['Remark'][$key];
			$sonTypeConf = $this->conf->sonType->lang->toArray();
			$sonTypeReMark = empty($sonTypeConf[$key]) ? '' : $sonTypeConf[$key];
			$remark = $sonTypeReMark . ' ' . $remark;
			$remarkHide = empty($params['RemarkHide'][$key]) ? '' : $params['RemarkHide'][$key];
			$financeOutLib->setOutRemark($remark);
			$financeOutLib->setOutRemarkHide($remarkHide);
			$financeOutLib->setOperator($adminId);
			$financeOutLib->setOutTypeSon($key);
			$financeOutLib->setUniqueId($uniqueId);
			$outReturn = $financeOutLib->addFinanceOutRecord();
			if(empty($outReturn))
			{
				//记录日志
				$finLogLib = new \lib\manage\finance\FinanceLogLib();
				$finLogLib->log('批量插入扣款记录失败:' . $key, $val, $outReturn);
			}
		}
		return true;
	}
	
	public function batchAddMoney($params)
	{
		$enameId = $params['EnameId'];
		$domain = empty($params['Domain']) ? '' : $params['Domain'];
		$adminId = empty($params['AdminId']) ? '' : $params['AdminId'];
		$uniqueId = empty($params['UniqueId']) ? '0' : $params['UniqueId'];
		$allMoneySum = array_sum($params['AllMoney']);
		$moneyListSum = array_sum($params['MoneyList']);
		if($allMoneySum != $moneyListSum)
		{
			throw new \Exception('总入款金额[' . $allMoneySum . ']与各款项[' . $moneyListSum . ']不对!', '410216');
		}
		$financeInLib = new \lib\manage\finance\FinanceInLib($enameId);
		//查看是否已经存在对应的入款记录（防止重复入款）
		$checkUniqueIdRetrun = $financeInLib->checkUniqueId($enameId, $uniqueId);
		if($checkUniqueIdRetrun)
		{
			throw new \Exception('该入款编号[' . $uniqueId . ']已存在!', '420023');
		}

		//入相应总金额
		$financeInfoLib = new \lib\manage\finance\FinanceInfoLib($enameId);
		$financeInfoLib->getUserFinance();
		$currentMoney = $financeInfoLib->getFreezeMoney() + $financeInfoLib->getPublicMoney() + $financeInfoLib->getUnWithdrawalMoney() + $financeInfoLib->getWithdrawalMoney() + $financeInfoLib->getMarginMoney();
		$financeInfoLib->setAddMoney($allMoneySum);
		$financeInfoLib->setFinanceType($params['Type']);
		$subReturn = $financeInfoLib->addUserFinanceMoney($params['AllMoney']);
		if(!$subReturn)
		{
			throw new \Exception('入款总金额失败:' . $subReturn, '410034');
		}
		$moneyType = $this->checkMoneyType($params['AllMoney']);
		//添加入款记录
		foreach($params['MoneyList'] as $key => $val)
		{
			if(empty($val))
			{
				continue;
			}
			//添加入款记录
			$financeInLib->setInTypeSon($key);
			$financeInLib->setInMoney($val);
			$financeInLib->setInType($params['Type']);
			$financeInLib->setLinkDomain($domain);
			$financeInLib->setMoneyType($moneyType);//根据订单扣款进行退款，所以金额类型未知
			$financeInLib->setOperator('9999');//操作者：系统调用
			$currentMoney = $currentMoney + $val;
			$financeInLib->setCurrentMoney($currentMoney);
			$financeInLib->setLinkEnameId('9999');
			$financeInLib->setLinkDomain($domain);

			$remark = empty($params['Remark'][$key]) ? '' : $params['Remark'][$key];
			$sonTypeConf = $this->conf->sonType->lang->toArray();
			$sonTypeReMark = empty($sonTypeConf[$key]) ? '' : $sonTypeConf[$key];
			$remark = $sonTypeReMark . ' ' . $remark;
			$remarkHide = empty($params['RemarkHide'][$key]) ? '' : $params['RemarkHide'][$key];
			$financeInLib->setInRemark($remark);
			$financeInLib->setInRemarkHide($remarkHide);
			$financeInLib->setOperator($adminId);
			$financeInLib->setInStatus('1');
			$financeInLib->setUniqueId($uniqueId);
			$inReturn = $financeInLib->addFinanceInSDK();
			if(empty($inReturn))
			{
				//记录日志
				$finLogLib = new \lib\manage\finance\FinanceLogLib();
				$finLogLib->log('批量插入入款记录失败:' . $key, $val, $inReturn);
			}
		}
		return true;
	}
	
	private function checkMoneyType($moneyArray)
	{
		if(!empty($moneyArray['w']) and empty($moneyArray['p']) and empty($moneyArray['u']))
		{
			return '3';
		}
		if(!empty($moneyArray['u']) and empty($moneyArray['w']) and empty($moneyArray['p']))
		{
			return '2';
		}
		if(!empty($moneyArray['p']) and empty($moneyArray['u']) and empty($moneyArray['w']))
		{
			return '1';
		}
		return '0';
	}
	
}
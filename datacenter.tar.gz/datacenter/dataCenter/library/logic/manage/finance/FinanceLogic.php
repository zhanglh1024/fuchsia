<?php
namespace logic\manage\finance;
use core\Response;
class FinanceLogic
{
	private $finLog;
	private $conf;
	private $confBase;

	public function __construct()
	{
		$this->finLog = new \lib\manage\finance\FinanceLogLib();
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'ext');
		$this->confBase = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
	}
 
	/**
	 * 获取用户财务信息
	 * @param int $enameId
	 * @return array|boolean
	 */
	public function getUserFinance($enameId)
	{
		try
		{
			$financeInfoLib = new \lib\manage\finance\FinanceInfoLib($enameId);
			return $financeInfoLib->getUserFinance();
		}
		catch(\Exception $e)
		{
			$this->finLog->log('[0401]获取财务信息失败', array('EnameId' => $enameId), $e->getCode() . ":: " . $e->getMessage(), 0, 0);
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}

	/**
	 * 初始化用户信息
	 * @param int $enameId
	 * @return boolean
	 */
	public function initUserFinance($enameId)
	{
		try
		{
			$financeInfoLib = new \lib\manage\finance\FinanceInfoLib($enameId);
			$return = $financeInfoLib->initUserFinance();
			if($return)
			{
				return TRUE;
			}
			throw new \Exception('初始化用户财务信息失败', 410027);
		}
		catch(\Exception $e)
		{
			$this->finLog->log('[0402]初始化用户信息失败', array('EnameId' => $enameId), $e->getCode() . ":: " . $e->getMessage(), 0, 0);
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}

	}

	/**
	 * 
	 * 根据交易类型生成保证金充值订单
	 * @param object $params 必须enameId type price transId domain
	 * @return int|boolean
	 */
	public function addPayOrder($params)
	{
		try
		{
			if(empty($params->enameId))
			{
				throw new \Exception('enameId有误', 410001);
			}
			if(empty($params->type) || $params->type < 0)
			{
				throw new \Exception('type有误', 410020);
			}
			if(empty($params->price) || $params->price <= 0)
			{
				throw new \Exception('price有误', 410022);
			}
			if(empty($params->transId) || $params->transId <= 0)
			{
				throw new \Exception('transId有误', 410028);
			}
			if(empty($params->domain))
			{
				throw new \Exception('domain有误', 410029);
			}

			$financeInfoLib = new \lib\manage\finance\FinanceInfoLib($params->enameId);
			$financeInfoLib->getUserFinance();

			//判断是否是充值保证金
			if(!$financeInfoLib->isMargin($params->type))
			{
				throw new \Exception('type不是充值保证金类型', 410030);
			}
			if($financeInfoLib->setSort($params->type, $params->price))
			{
				throw new \Exception('余额足够，不需要再充值', 410031);
			}
			$needPayMoney = $financeInfoLib->getNeedPayMoney();
			if($needPayMoney <= 0)
			{
				throw new \Exception('余额足够，不需要再充值', 410031);
			}
			if($needPayMoney > $this->conf->charge->margin->max)
			{
				throw new \Exception('保证金最高只能充值' . $this->conf->charge->margin->max . '元', 410032);
			}

			//创建充值订单
			$payCenterLib = new \lib\manage\finance\PayCenterLib($params->enameId);
			$PayOrderId = $payCenterLib->addPayRecord($needPayMoney, $params->transId, $params->domain);
			if($PayOrderId)
			{
				return $PayOrderId;
			}
			throw new \Exception('创建保证金充值订单失败', 410033);
		}
		catch(\Exception $e)
		{
			$this->finLog->log('[0403]创建保证金充值订单失败', $params, $e->getCode() . ":: " . $e->getMessage(), 0, 0);
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}

	/**
	 *
	 *获取用户财务明细
	 * @param $info->type in 消费 out入款 all 全部
	 * @param $info->EnameId
	 * @return array
	 */
	public function getFinanceList($info)
	{
		$data = $this->setData($info);
		$pageSize = empty($info->pagesize) ? $this->conf->pagesize : $info->pagesize;
		$p = $info->pagenum ? intval($info->pagenum) - 1 : 0;
		$offset = $p * $pageSize;
		$financeType = $this->confBase->type->lang->toArray();
		if($info->financetype == 'in')
		{
			$FinanceInLib = new \lib\manage\finance\FinanceInLib($info->EnameId);
			$financeInCount = $FinanceInLib->getFinanceInCount($data);
			if($financeInCount && $offset < $financeInCount)
			{
				$offNum = array('offset' => $offset, 'num' => $pageSize);
				$rowdata = array_merge($data, $offNum);
				$financeInList = $FinanceInLib->getFinanceInSDK($rowdata);
				if($financeInList)
				{
					foreach($financeInList as $key => $v)
					{
						$v['Money'] = $v['InMoney'];
						$v['recordType'] = 2;
						$v['mark'] = '';
						$v['mark'] .= !empty($financeType[$v['InType']]) ? $financeType[$v['InType']] : '未知类型';
						$v['mark'] = $this->getFinRemark($v);
						if(!empty($v['LinkDomain']))
						{
							$v['LinkDomain'] = mb_substr($v['LinkDomain'], 0, 50, 'UTF-8');
						}
						$financeInList[$key] = $v;
					}
					return array('flag' => 1,
							'msg' => array('pagenum' => $info->pagenum, 'data' => $financeInList,
									'count' => $financeInCount));
				}
				return array('flag' => 1,
						'msg' => array('pagenum' => $info->pagenum, 'data' => array(), 'count' => $financeInCount));
			}
			return array('flag' => 1, 'msg' => array('pagenum' => $info->pagenum, 'data' => array(), 'count' => 0));
		}
		elseif($info->financetype == 'out')
		{
			$FinanceOutLib = new \lib\manage\finance\FinanceOutLib($info->EnameId);
			$financeOutCount = $FinanceOutLib->getFinanceOutCount($data);
			if($financeOutCount && $offset < $financeOutCount)
			{
				$offNum = array('offset' => $offset, 'num' => $pageSize);
				$rowdata = array_merge($data, $offNum);
				$financeOutList = $FinanceOutLib->getFinanceOutSDK($rowdata);
				if($financeOutList)
				{
					foreach($financeOutList as $key => $v)
					{
						$v['Money'] = $v['OutMoney'];
						$v['recordType'] = 1;
						$v['mark'] = '';
						if(!empty($financeType[$v['OutType']]) && $financeType[$v['OutType']] == '人工冻结' && !empty($v['OutRemark']) && $v['OutRemark'] == '款项补扣' && ($v['OutMoney'] == 10 || $v['OutMoney'] == 20) && $v['CreateDate'] >= '2013-11-28 00:00:00' && $v['CreateDate'] <= '2013-11-28 17:00:00')
						{
							$v['mark'] .= '域名';
						}
						else
						{
							$v['mark'] .= !empty($financeType[$v['OutType']]) ? $financeType[$v['OutType']] : '未知类型';
						}
						$v['mark'] = $this->getFinRemark($v);
						if(!empty($v['LinkDomain']))
						{
							$v['LinkDomain'] = mb_substr($v['LinkDomain'], 0, 50, 'UTF-8');
						}
						$financeOutList[$key] = $v;
					}
					return array('flag' => 1,
							'msg' => array('pagenum' => $info->pagenum, 'data' => $financeOutList,
									'count' => $financeOutCount));
				}
				return array('flag' => 1,
						'msg' => array('pagenum' => $info->pagenum, 'data' => array(), 'count' => $financeOutCount));
			}
			return array('flag' => 1, 'msg' => array('pagenum' => $info->pagenum, 'data' => array(), 'count' => 0));
		}
		else
		{
			$FinanceAllLib = new \lib\manage\finance\FinanceLib($info->EnameId);
			$financeAllCount = $FinanceAllLib->getFinanceAllCount($data);
			if($financeAllCount && $offset < $financeAllCount)
			{
				$offNum = array('offset' => $offset, 'num' => $pageSize);
				$rowdata = array_merge($data, $offNum);
				$financeAllList = $FinanceAllLib->getFinanceAllSDK($rowdata);
				if($financeAllList)
				{
					foreach($financeAllList as $key => $v)
					{
						$v['mark'] = '';
						if($v['LinkDomain'])
						{
							$v['LinkDomain'] = mb_substr($v['LinkDomain'], 0, 50, 'UTF-8');
						}
						if(!empty($financeType[$v['Type']]) && $financeType[$v['Type']] == '人工冻结' && !empty($v['Remark']) && $v['Remark'] == '款项补扣' && ($v['Money'] == 10 || $v['Money'] == 20) && $v['CreateDate'] >= '2013-11-28 00:00:00' && $v['CreateDate'] <= '2013-11-28 17:00:00')
						{
							$v['mark'] .= '域名';
						}
						else
						{
							$v['mark'] .= !empty($financeType[$v['Type']]) ? $financeType[$v['Type']] : '未知类型';
						}
						$v['mark'] = $this->getFinRemark($v);
						$financeAllList[$key] = $v;
					}
					return array('flag' => 1,
							'msg' => array('pagenum' => $info->pagenum, 'data' => $financeAllList,
									'count' => $financeAllCount));
				}
				return array('flag' => 1,
						'msg' => array('pagenum' => $info->pagenum, 'data' => array(), 'count' => $financeAllCount));
			}
			return array('flag' => 1, 'msg' => array('pagenum' => $info->pagenum, 'data' => array(), 'count' => 0));
		}
	}
	//设置传到的数组参数
	private function setData($info)
	{
		$rowData = array();
		$rowData['enameId'] = $info->EnameId;
		if($info->startDate)
		{
			$rowData['startDate'] = $info->startDate;
		}
		if($info->endDate)
		{
			$rowData['endDate'] = $info->endDate;
		}
		if($info->type)
		{
			$rowData['type'] = $info->type;
		}
		if($info->searchKey)
		{
			$rowData['searchKey'] = $info->searchKey;
		}
		if($info->TypeSon)
		{
			$rowData['TypeSon'] = $info->TypeSon;
		}
		return $rowData;
	}
	
	/**
	 * 获取出入款备注
	 */
	private function getFinRemark($info)
	{
		if(isset($info['recordType']) && $info['recordType'] == 1)
		{
			if(isset($info['OutRemark']))
			{
				$info['Remark'] = $info['OutRemark'];
				$info['Type'] = $info['OutType'];
			}
			if(!empty($info['Remark']))
			{
				$info['mark'] .= ' 备注:' . $info['Remark'];
			}
			if(isset($info['Type']) && $info['Type'] == '108')
			{
				$info['mark'] .= '拍卖违约';
			}
			if($info['PromoMoney'] > 0 && FALSE == stripos($info['Remark'], "打包促销活动"))
			{
				$info['mark'] .= ' 优惠券：' . number_format($info['PromoMoney'], 2) . '￥';
			}
			if(!empty($info['Remark']))
			{
				if($info['Remark'] == '款项补扣')
				{
					$info['Remark'] = '续费扣款';
				}
				$info['mark'] .= ' 备注:' . $info['Remark'];
			}
		}
		elseif(isset($info['recordType']) && $info['recordType'] == 2)
		{
			if(isset($info['InRemark']))
			{
				$info['Remark'] = $info['InRemark'];
			}
			if(!empty($info['Remark']))
			{
				$info['mark'] .= ' 备注:' . $info['Remark'];
			}
			if(isset($info['FeeMoney']))
			{
				if($info['FeeMoney'] > 0)
				{
					$info['mark'] .= ' (扣除' . number_format($info['FeeMoney'], 2) . '手续费)';
				}
			}
		}
		return $info['mark'];
	}

	public function updateFinanceScore($info)
	{
		$data['enameId'] = $info->EnameId;
		$data['score'] = $info->Score;
		$data['scoreType'] = $info->ScoreType;
		if(property_exists($info, 'PortalId') && !empty($info->PortalId))
		{
			$data['orderId'] = $info->PortalId;
		}
		else 
		{
			$data['orderId'] = $info->OrderId;
		}
		$data['createTime'] = date("Y-m-d H:i:s");
		$status = $info->Status;
		$financesMod = new \models\manage\finance\FinancesMod();
		$financesInfo = $financesMod->getFinanceInfo($data['enameId']);
		if(!$financesInfo)
		{
			throw new \Exception("enameId有误！",410001);
		}

		if ($status) 
		{
			//增积分
			$data['currentScore'] = $financesInfo['TotalScore'] + $data['score'];
			$data['scoreRemark'] = $info->Remark;
			$scoreMod = new \models\manage\finance\FinScoreMod();
			//积分表新增记录
			$scoreRes = $scoreMod->addScore($data);
			if (!$scoreRes) 
			{
				throw new \Exception("积分记录添加失败！",410066);
			}
			//财务表更新积分
			$financeRes = $financesMod->addScore($data['score'],$data['enameId']);
			if (!$financeRes) 
			{
				throw new \Exception("更新用户财务信息失败！",410071);
			}
 		}
 		else
 		{
 			//扣积分
 			$data['currentScore'] = $financesInfo['TotalScore'] - $data['score'];
 			if($data['currentScore'] < 0)
 			{
 				throw new \Exception("积分不足",410072);
 			}
 			$data['consumerRemark'] = $info->Remark;
 			if($data['scoreType'] == 30)
 			{
 				$data['scoreType']  = 6 ;
 			}
 			if($data['scoreType'] == 31)
 			{
 				$data['scoreType']  = 7 ;
 			}
 			$scoreConsumeMod = new \models\manage\finance\FinScoreConsumeMod();
 			$scoreConsumeRes = $scoreConsumeMod->addScoreConsumer($data);
 			if (!$scoreConsumeRes) 
 			{
 				throw new \Exception("消费记录添加失败！",410067);
 			}
 			$financeRes = $financesMod->subScore($data['score'],$data['enameId']);
 			if (!$financeRes) 
 			{
 				throw new \Exception("更新用户财务信息失败！",410071);
 			}
 		}

 		return array('flag' => 1, 'msg' => '更新成功！');

	}
	public function getUserBalanceOrder($enameId , $outType , $needMoney)
	{
		$financeInfoLib = new \lib\manage\finance\FinanceInfoLib($enameId);
		$financeInfoLib->getUserFinance();
		$return = $financeInfoLib->setSort($outType, $needMoney);
		return $return;
	}
/**
	 * 获取财务冻结明细
	 */
	public function getFinanceFreezeDetail($data)
	{
		$ver = \common\Common::getAppVersion();
		$financeOrderMod = new \models\manage\finance\FinOrderMod();
		$orderTypeConf = $this->confBase->type->lang->toArray();
		$info = array('orderStatus'=>3);
		$info['EnameId'] = $data['EnameId'];
		$count = $financeOrderMod->getFinanceFreezeCount($info);
		$pagesize = (isset($data['pagesize'])&&!empty($data['pagesize']))?intval($data['pagesize']):10;
		$pagenum = (isset($data['pagenum'])&&!empty($data['pagenum']))?intval($data['pagenum']):1;
		$page = $pagenum - 1 ;
		$offset = $page * $pagesize;
		$limit = $offset . ',' . $pagesize;
		$financeFreezeList = $financeOrderMod->getFinanceFreezeList($info,$limit);
		foreach($financeFreezeList as $k=>$v)
		{
			$financeFreezeList[$k]['Remark'] = $orderTypeConf[$v['OrderType']] ? $orderTypeConf[$v['OrderType']]:'未知类型';
			if(!empty($v['Domain']))
			{
				if($ver && $ver == '3.1')
				{
					$financeFreezeList[$k]['Remark'] .= '['.$v['Domain'].']';
				}	
			}
			unset($financeFreezeList[$k]['OrderType']);
			//unset($financeFreezeList[$k]['Domain']);
		}
		return array('count'=>$count['total'],'pagenum'=>$pagenum,'data'=>$financeFreezeList);
	}

	/**
	 * 财务扣款
	 */
	public function charge($data)
	{
		$orderLogic = new \logic\manage\finance\OrderLogic();
		$orderId = $orderLogic->addOrder($data);
		if(!$orderId) 
		{
			throw new \Exception(Response::getErrMsg(), Response::getErrCode());
		}
		$sonType = empty($data->sonType) ? 0 : $data->sonType;
		$confirmStatus = $orderLogic->confirmOrder((object)array('enameId' => $data->enameId, 'orderId' => $orderId, 'sonType' => $sonType));
		if (!$confirmStatus) 
		{
			throw new \Exception(Response::getErrMsg(), Response::getErrCode());
		}

		return array('flag' => true, 'msg' => array('msg' => '扣款成功！', 'orderId' => $orderId));
	}

	/**
	 * 查询余额
	 */
	public function getBalance($data)
	{
		$financeInfo = $this->getUserFinance($data->enameId);
		if(FALSE == $financeInfo) 
		{
			throw new \Exception(Response::getErrMsg(), Response::getErrCode());
		}
		$total = $financeInfo['PublicMoney'] + $financeInfo['UnWithdrawalMoney'] + $financeInfo['WithdrawalMoney'] + $financeInfo['MarginMoney'];
		return $total;
	}
	/**
	 * app充值统计
	 */
	public function payCenterCount()
	{
		$countConf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'financecount');
		$statId = $countConf->statId;
		$types = $countConf->countType->toArray();
		$redis = new \lib\manage\common\RedisLib();
		foreach(array_keys($types) as $type)
		{
			$redisKey = 'apppaycenter_' . $type . '_' . date('Y-m-d', strtotime('-1 days'));
			$allcount = $redis->getData($redisKey);//money
			$allcount = $allcount ? $allcount : 0;
			$mod = new \models\manage\finance\FinanceCountMod();
			$end = date('Y-m-d 23:59:59', strtotime('-1 days'));
			$begin = date('Y-m-d 00:00:00', strtotime('-1 days'));
			$list = $mod->getCountList(array('statId' => $statId,
					'date(endTime)' => date('Y-m-d', strtotime('-1 days')), 'typeId' => $type,
					'date(beginTime)' => date('Y-m-d', strtotime('-1 days'))));
			if($list)
			{
				$add = $mod->updateCountInfo(array('fcid' => $list['fcid']), array('price' => $allcount));
			}
			else
			{
				$add = $mod->addCount(array('statId' => $statId, 'typeId' => $type,
						'price' => $allcount, 'beginTime' => $begin, 'endTime' => $end));
			}
			if(!$add)
			{
				\core\Log::write($redisKey . ",allcount:$allcount", "finance", "financecountfailed");
			}
			else
			{
				$delredis = $redis->delData($redisKey);
				if(!$delredis)
				{
					\core\Log::write($redisKey . ",delrediserror", 'finance', 'financecountfailed');//删除失败记录
				}
			}
			echo $add ? $redisKey . ' data add success,allcount:' . $allcount : $redisKey . ' data add failed,allcount:' . $allcount;
			echo PHP_EOL;
		}
	}
	

	/**
	 * 程序调用，根据enameid和price做账户入款(默认为人工入款到不可提现)
	 * @params (object)array('enameId','price','inType可选默认201人工入款','moneyType可选','domain可选'，'remark可选','remarkhide可选','adminid可选');
	 */
	public function manualRecharge($params)
	{
		try
		{  
			if(empty($params->enameId))
			{
				throw new \Exception('enameId有误', 410001);
			}
			if(empty($params->price))
			{
				throw new \Exception('price有误', 410022);
			}
			$this->ProductOrderLib = new \lib\manage\finance\ProductOrderLib($params->enameId);
			$this->ProductOrderLib->setPrice($params->price);//金额
			if(isset($params->inTypeSon))
			{
				$this->ProductOrderLib->setInTypeSon($params->inTypeSon);//金额
			}
			$this->ProductOrderLib->setType(empty($params->inType) ? $this->confBase->type->manDeposit : $params->inType);//入款类型，默认201人工入款财务类型
			$this->ProductOrderLib->setMoneyTpye(empty($params->moneyType) ? $this->confBase->moneyType->unwithdrawal : $params->moneyType);//金额类型，默认不可提现
			$this->ProductOrderLib->setDomain(!empty($params->domain) ? $params->domain : '');//关联域名
			$this->ProductOrderLib->setRemark(!empty($params->remark) ? $params->remark : '');//备注
			$this->ProductOrderLib->setRemarkHide(!empty($params->remarkHide) ? $params->remarkHide : '');//隐藏的后台备注
			$this->ProductOrderLib->setAdminId(!empty($params->adminId) ? $params->adminId : 0);//操作者
			return $this->ProductOrderLib->addFinanceIn($params->enameId);
		}
		catch(\Exception $e)
		{
			$this->finLog->log('给用户入款失败', $params, array($e->getCode(), $e->getMessage()));
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}
	
	/**
	 * 程序调用，根据enameid和price做账户扣款(根据moneyType扣除对应的可提现或者不可提现)
	 * @params (object)array('enameId','price','outType可选默认11人工扣款','outTypeSon可选','moneyType可选2不可提现3可提现','domain可选'，'remark可选','remarkhide可选','adminid可选');
	 */
	public function manualCharge($params)
	{
		try 
		{
			if(empty($params->enameId))
			{
				throw new \Exception('enameId有误', 410001);
			}
			if(empty($params->price))
			{
				throw new \Exception('price有误', 410022);
			}
			$financeOutLib = new \lib\manage\finance\FinanceOutLib($params->enameId);
			if(isset($params->outTypeSon))
			{
				$this->ProductOrderLib->setOutTypeSon($params->outTypeSon);
			}
			$financeOutLib->setOutMoney($params->price);
			$financeOutLib->setOutType(empty($params->outType) ? $this->confBase->type->manCharge : $params->outType);//扣款类型，默认11人工扣款财务类型
			$financeOutLib->setLinkDomain(!empty($params->domain) ? $params->domain : '');
			$financeOutLib->setOperator(!empty($params->adminId) ? $params->adminId : 0);
			$financeOutLib->setOutRemark(!empty($params->remark) ? $params->remark : '');
			$financeOutLib->setOutRemarkHide(!empty($params->remarkHide) ? $params->remarkHide : '');
			$financeOutLib->setLinkEnameId('');
			$financeOutLib->setOrderId('');
			if(!$financeOutLib->refundFinanceOut($this->confBase->moneyType->unwithdrawal == $params->moneyType ?
					array('p' => 0, 'u' => $params->price, 'w' => 0, 'm' => 0) : array('p' => 0, 'u' => 0, 'w' => $params->price, 'm' => 0)))
			{
				$this->finLog->log('给用户扣款失败', $params, array(), 0, 1);
				throw new \Exception('给用户扣款失败', 410035);
			}
			return TRUE;
		}
		catch(\Exception $e)
		{
			$this->finLog->log('给用户扣款失败', $params, array(), 0, 1);
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}
	
	/**
	 * 2015取消订单功能－款项回退
	 * 操作：退款给买家并产生入款记录，补扣卖家的钱并产生出款记录，财务记录orderid为取消的订单id，其中不涉及优惠券和积分的回滚
	 * 涉及：预订保证金，交易违约金，域名push等订单
	 * 说明：特殊区分出入款记录可根据备注InRemark和OutRemark：取消订单
	 * 
	 * @param int $enameId 买家id
	 * @param int $orderId 订单id
	 * @param string $remarkHide 管理员备注
	 * @return boolean
	 */
	public function cancelOrderByAdmin($enameId, $orderId, $remarkHide = FALSE)
	{
		try 
		{
			if(empty($enameId))
			{
				throw new \Exception('enameId有误', 410001);
			}
			if(empty($orderId))
			{
				throw new \Exception('orderId有误', 410026);
			}
			$this->orderLib = new \lib\manage\finance\OrderLib($enameId);
			//获取订单信息
			if(!$this->orderLib->getOrderInfo($orderId))
			{
				throw new \Exception('获取订单信息失败：' . $orderId, 410056);
			}
			//确保是成功订单 
			if($this->orderLib->getOrderStatus() != '1')
			{
				throw new \Exception('订单非成功状态：' . $orderId, 410070);
			}
			//判断该订单是否已经自动退款，根据'取消订单'前台备注搜索
			$remark = '取消订单';
			$financeInLib = new \lib\manage\finance\FinanceInLib($enameId);
			$inRecord = $financeInLib->getFinanceInSDK(array('enameId' => $enameId, 'orderId' => $orderId, 'offset' => '0', 'num' => '1', 'inRemark' => $remark), FALSE);
			if(is_array($inRecord) && !empty($inRecord))
			{
				throw new \Exception('该订单已经取消过:' . $orderId, 410080);
			}
			//卖家账号下扣除所得实际金额，手续费则变为取消（对应之前扣除的手续费）
			if(!in_array($this->orderLib->getLinkEnameId(), array(0, 9999, '')))
			{
				$this->subSolderMoney($enameId, $orderId, $remark, $remarkHide, $this->orderLib);
			}
			//买家账号下返还所扣除的金额，好像0元的也有流水记录so暂时无脑返还，ConsumeMoney TradingPayMoney暂无处理
			$this->addBuyerMoney($enameId, $orderId, $remark, $remarkHide, $this->orderLib);
			$this->finLog->log('取消订单成功', array('enameId' => $enameId, 'orderId' => $orderId), array(), 0, 1);
			return TRUE;
		}
		catch(\Exception $e)
		{
			$this->finLog->log('取消订单失败', array('enameId' => $enameId, 'orderId' => $orderId), array(
					$e->getCode(), $e->getMessage()));
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}
	
	/**
	 * 2015取消订单功能－款项回退(重写)
	 * 操作：退款给买家并产生入款记录，补扣卖家的钱并产生出款记录，财务记录orderid为取消的订单id，其中不涉及优惠券和积分的回滚
	 * 涉及：预订保证金，交易违约金，域名push等订单
	 * 说明：特殊区分出入款记录可根据备注InRemark和OutRemark：取消订单
	 *
	 * @param int $enameId 买家id
	 * @param int $orderId 订单id
	 * @param string $remarkHide 管理员备注
	 * @return boolean
	 */
	public function cancelOrderByAdminRe($enameId, $orderId, $remarkHide = FALSE)
	{
		\lib\manage\finance\FinanceLogLib::logBatchSet(true);
		$db = \models\manage\finance\FinMod::getDB();
		try
		{
			$db->transBegin();//开始事务  
			if(empty($enameId))
			{
				throw new \Exception('enameId有误', 410001);
			}
			if(empty($orderId))
			{
				throw new \Exception('orderId有误', 410026);
			}
			$this->orderLib = new \lib\manage\finance\OrderLib($enameId);
			//获取订单信息
			if(!$this->orderLib->getOrderInfo($orderId))
			{
				throw new \Exception('获取订单信息失败：' . $orderId, 410056);
			}
			//确保是成功订单
			if($this->orderLib->getOrderStatus() != '1')
			{
				throw new \Exception('订单非成功状态：' . $orderId, 410070);
			}
			
			//行锁，防止并发时数据有误
			$db->query('SELECT * FROM e_finances WHERE EnameId = '.$enameId.' FOR UPDATE');
			
			//判断该订单是否已经自动退款，根据'取消订单'前台备注搜索
			$remark = '取消订单';
			$financeInLib = new \lib\manage\finance\FinanceInLib($enameId);
			$inRecord = $financeInLib->getFinanceInSDK(array('enameId' => $enameId, 'orderId' => $orderId, 'offset' => '0', 'num' => '1', 'inRemark' => $remark), FALSE);
			if(is_array($inRecord) && !empty($inRecord))
			{
				throw new \Exception('该订单已经取消过:' . $orderId, 410080);
			}
			//卖家账号下扣除所得实际金额，手续费则变为取消（对应之前扣除的手续费）
			if(!in_array($this->orderLib->getLinkEnameId(), array(0, 9999, '')))
			{
				$this->subSolderMoney($enameId, $orderId, $remark, $remarkHide, $this->orderLib);
			}
			//买家账号下返还所扣除的金额，好像0元的也有流水记录so暂时无脑返还，ConsumeMoney TradingPayMoney暂无处理
			$this->addBuyerMoney($enameId, $orderId, $remark, $remarkHide, $this->orderLib);
			$this->finLog->log('取消订单成功', array('enameId' => $enameId, 'orderId' => $orderId), array(), 0, 1);
			$db->transCommit();//提交事务
			\lib\manage\finance\FinanceLogLib::batchLog();//批量处理日志
			return TRUE;
		}
		catch(\Exception $e)
		{
			$db->transRollback();//回滚事务
			$this->finLog->log('取消订单失败', array('enameId' => $enameId, 'orderId' => $orderId), array(
					$e->getCode(), $e->getMessage()));
			Response::setErrMsg($e->getCode(), $e->getMessage());
			\lib\manage\finance\FinanceLogLib::batchLog();//批量处理日志
			return FALSE;
		}
	}
	
	/**
	 * 卖家账号下扣除所得实际金额，手续费则变为取消（对应之前扣除的手续费）
	 * @throws \Exception
	 */
	private function subSolderMoney($enameId, $orderId, $remark, $remarkHide, $orderLib)
	{
		//获取原始订单的卖家入款记录 
		$financeInLib = new \lib\manage\finance\FinanceInLib($orderLib->getLinkEnameId());
		$inRecord = $financeInLib->getFinanceInSDK(array('enameId' => $orderLib->getLinkEnameId(), 'orderId' => $orderId, 'offset' => '0', 'num' => '1', 'inRemark!=' => $remark), FALSE);
		if(!is_array($inRecord) || empty($inRecord))
		{
			throw new \Exception('该订单入款记录获取失败:' . $orderId, 410081);
		}
		$inRecord = $inRecord[0];
		//卖家补扣款
		$financeOutLib = new \lib\manage\finance\FinanceOutLib($orderLib->getLinkEnameId());
		$financeOutLib->setOrderId($orderId);
		$financeOutLib->setOutMoney($inRecord['InMoney']);
		$financeOutLib->setOutType($orderLib->getOrderType());
		$financeOutLib->setLinkDomain($orderLib->getDomain());
		$financeOutLib->setLinkEnameId($enameId);
		$financeOutLib->setRegistrarId($orderLib->getRegistarId());
		$financeOutLib->setOperator('9999');//操作者：系统调用
		$financeOutLib->setOutRemark($remark);//前台备注
		$financeOutLib->setOutRemarkHide($remarkHide);//后台备注
		$financeOutLib->setFeeMoney($inRecord['FeeMoney']);//取消卖家入款手续费
		if(!$financeOutLib->refundFinanceOut($this->confBase->moneyType->unwithdrawal == $inRecord['MoneyType'] ?
				array('p' => 0, 'u' => $inRecord['InMoney'], 'w' => 0, 'm' => 0) : array('p' => 0, 'u' => 0, 'w' => $inRecord['InMoney'], 'm' => 0)))//根据订单入款类型组装扣款顺序
		{
			throw new \Exception('取消订单-扣款失败' . $orderId, 410083);
		}
		$this->finLog->log('取消订单-扣款成功', array('enameId' => $orderLib->getLinkEnameId(), 'orderId' => $orderId), array(), 0, 1);
	}
	
	/**
	 * 买家账号下返还所扣除的金额，好像0元的也有流水记录so暂时无脑返还，ConsumeMoney TradingPayMoney暂无处理
	 * @throws \Exception
	 */
	private function addBuyerMoney($enameId, $orderId, $remark, $remarkHide, $orderLib)
	{ 
		//获取原始订单的买家出款记录
		$financeOutLib = new \lib\manage\finance\FinanceOutLib($enameId);
		$outRecord = $financeOutLib->getFinanceOutSDK(array('enameId' => $enameId, 'orderId' => $orderId, 'offset' => '0', 'num' => '1', 'outRemark!=' => $remark));
		if(!is_array($outRecord) || empty($outRecord))
		{
			throw new \Exception('该订单出款记录获取失败:' . $orderId, 410081);
		}
		$financeInLib = new \lib\manage\finance\FinanceInLib($enameId);
		$freezeMoneySort = $this->orderLib->getFreezeMoneySort();
		$financeInLib->setOrderId($orderId);
		$financeInLib->setInMoney($this->orderLib->getPrice());
		$financeInLib->setInType($this->orderLib->getOrderType());
		$financeInLib->setLinkDomain($this->orderLib->getDomain());
		$financeInLib->setLinkEnameId($this->orderLib->getLinkEnameId());
		$financeInLib->setRegistrarId($this->orderLib->getRegistarId());
		$financeInLib->setMoneyType('0');//根据订单扣款进行退款，所以金额类型未知
		$financeInLib->setOperator('9999');//操作者：系统调用
		$financeInLib->setInRemark($remark);//前台备注
		$financeInLib->setInRemarkHide($remarkHide);//后台备注
		if(!$financeInLib->refundFinanceIn($freezeMoneySort))
		{
			throw new \Exception('取消订单-退款失败' . $orderId, 410084);
		}
		$this->finLog->log('取消订单-退款成功', array('enameId' => $enameId, 'orderId' => $orderId), array(), 0, 1);
	}
	
	/**
	 * 站内转账
	 * @param int $sendId 出款enameid
	 * @param int $receiveId 入款enameid
	 * @param string $money 转账金额
	 * @param int $moneyType 金额类型 2：不可提现  3：可提现
	 * @param string $remark 备注
	 */
	public function changeMoneyOwner($sendId, $receiveId, $money, $moneyType, $remark)
	{
		try 
		{
			if($sendId == $receiveId)
			{
				throw new \Exception('转帐人和被转账人不能是同一个人', 410085);
			}
			if(!is_numeric($money))
			{
				throw new \Exception('转账金额必须为数字', 410086);
			}
			if(!in_array($moneyType, array(2, 3)))
			{
				throw new \Exception('转账方式错误', 410087);
			}
			$financeInfoLib = new \lib\manage\finance\FinanceInfoLib($sendId);
			$sendIdFinance = $financeInfoLib->getUserFinance();
			if($money > ($sendIdFinance['UnWithdrawalMoney'] + $sendIdFinance['WithdrawalMoney']))
			{
				throw new \Exception('转账方金额不足', 410088);
			}
			$productLib = new \lib\manage\finance\ProductOrderLib($sendId);
			$productLib->setLinkEnameId($receiveId);
			$productLib->setMoneyTpye($moneyType);
			$productLib->setRemark($remark);
			$productLib->setPrice($money);
			$productLib->setType(120);
			$orderId = $productLib->addOrder();
			return $productLib->confirmOrder($orderId);
		}
		catch(\Exception $e)
		{
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}
	
}
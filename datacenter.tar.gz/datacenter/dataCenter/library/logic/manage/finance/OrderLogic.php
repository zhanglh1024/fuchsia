<?php 
namespace logic\manage\finance;
use core\Response;
class OrderLogic
{
	private $finLog;
	private $conf;

	public function __construct()
	{
		$this->finLog = new \lib\manage\finance\FinanceLogLib();
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
	}

	/**
	 * 创建产品订单(若为珍品域名需要specialPrice为TRUE并传价格price)
	 * @param object $params 必须：enameId type 非必须：productId productName productType userGroupId year quantity linkEnameId promoCode remark registarId price specialPrice
	 * @throws Exception
	 * @return number|boolean
	 */
	public function addProductOrder($params)
	{
		try
		{
			if(empty($params->enameId))
			{
				throw new \Exception('enameId有误', 410001);
			}
			if(empty($params->type))
			{
				throw new \Exception('订单type有误', 410020);
			}
			if(empty($params->productId) && empty($params->productName))
			{
				throw new \Exception('productId和productName不能同时为空', 410059);
			}
			if(!empty($params->productName) and empty($params->productType))
			{
				throw new \Exception('productType不能为空', 410021);
			}
			$pdOrderLib = new \lib\manage\finance\ProductOrderLib($params->enameId);
			if(isset($params->domain))
			{
				$pdOrderLib->setDomain($params->domain);
			}
			if(isset($params->productId))
			{
				$pdOrderLib->setProductId($params->productId);
			}
			if(isset($params->productName))
			{
				$pdOrderLib->setProductName($params->productName);
			}
			if(isset($params->productType))
			{
				$pdOrderLib->setProductType($params->productType);
			}
			if(isset($params->userGroupId))
			{
				$pdOrderLib->setUserGroupId($params->userGroupId);
			}
			if(isset($params->year))
			{
				$pdOrderLib->setYear($params->year);
			}
			if(isset($params->quantity))
			{
				$pdOrderLib->setQuantity($params->quantity);
			}
			if(isset($params->linkEnameId))
			{
				$pdOrderLib->setLinkEnameId($params->linkEnameId);
			}
			if(isset($params->promoCode))
			{
				$pdOrderLib->setPromoCode($params->promoCode);
			}
			if(isset($params->remark))
			{
				$pdOrderLib->setRemark($params->remark);
			}
			if(isset($params->remarkHide))
			{
				$pdOrderLib->setRemarkHide($params->remarkHide);
			}
			if(isset($params->registarId))
			{
				$pdOrderLib->setRegistarId($params->registarId);
			}
			$pdOrderLib->setType($params->type);
			$orderId = $pdOrderLib->addProductOrder(!empty($params->specialPrice) && isset($params->price) ? $params->price : FALSE);
			$this->finLog->log('创建产品订单成功', $params, array('orderId' => $orderId), 0, 1);
			return $orderId;
		}
		catch(\Exception $e)
		{
			$this->finLog->log('[0311]创建产品订单失败', $params, $e->getCode() . ":: " . $e->getMessage());
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}

	/**
	 * 创建无产品订单
	 * @param object $params 必须：enameId price type 非必须：oldOrderIddomain linkEnameId remark remarkHide adminId registarId
	 * @throws Exception
	 * @return number|boolean
	 */
	public function addOrder($params)
	{
		try
		{
			if(empty($params->enameId))
			{
				throw new \Exception('enameId有误', 410001);
			}
			if(empty($params->type))
			{
				throw new \Exception('type有误', 410020);
			}
			if((empty($params->price) || $params->price < 0) && $params->type != 32 && $params->type != 39)
			{
				throw new \Exception('price有误', 410022);
			}
			$pdOrderLib = new \lib\manage\finance\ProductOrderLib($params->enameId);
			if(isset($params->domain))
			{
				$pdOrderLib->setDomain($params->domain);
			}
			$pdOrderLib->setPrice($params->price);
			if(isset($params->linkEnameId))
			{
				$pdOrderLib->setLinkEnameId($params->linkEnameId);
			}
			if(isset($params->remark))
			{
				$pdOrderLib->setRemark($params->remark);
			}
			if(isset($params->remarkHide))
			{
				$pdOrderLib->setRemarkHide($params->remarkHide);
			}
			if(isset($params->adminId))
			{
				$pdOrderLib->setAdminId($params->adminId);
			}
			if(isset($params->registarId))
			{
				$pdOrderLib->setRegistarId($params->registarId);
			}
			$pdOrderLib->setType($params->type);
			if(!isset($params->oldOrderId) || !is_numeric($params->oldOrderId) || intval($params->oldOrderId) <= 0)
			{
				$orderId = $pdOrderLib->addOrder();
				if(empty($orderId))
				{
					throw new \Exception('创建无产品订单失败', 410023);
				}
				$this->finLog->log('创建无产品订单成功', $params, array('orderId' => $orderId), 0, 1);
				return $orderId;
			}
			//存在需取消的旧订单的情况
			$cancelOldOrder = FALSE;
			try
			{
				$orderId = $pdOrderLib->addOrder();
				$freezeMoneySort = $pdOrderLib->getFreezeMoneySort();
				if(empty($orderId))
				{
					throw new \Exception('创建无产品订单失败', 410023);
				}
			}
			catch(\Exception $e)
			{
				if($e->getCode() == 410024)
				{
					//余额不足时，判断旧冻结订单是否足够
					if(!$pdOrderLib->checkOldOrder($params->oldOrderId))
					{
						throw new \Exception('可用余额不足', 410024);
					}
					//足够，先取消旧订单,再创建新订单
					if(!$pdOrderLib->cancelOrder($params->oldOrderId))
					{
						throw new \Exception('取消旧订单' . $params->oldOrderId . '失败', 410025);
					}
					$this->finLog->log('取消旧订单' . $params->oldOrderId . '成功', $params, array(true), 0, 1);
					$cancelOldOrder = TRUE;
					try
					{
						$orderId = $pdOrderLib->addOrder();
						if(empty($orderId))
						{
							$this->finLog->log('生成新订单失败,但旧订单' . $params->oldOrderId . '已取消', $params, $e->getMessage());
							throw new \Exception('创建无产品订单失败', 410023);
						}
					}
					catch(\Exception $e)
					{
						$this->finLog->log('生成新订单失败,但旧订单' . $params->oldOrderId . '已取消', $params, $e->getMessage());
						throw new \Exception($e->getMessage(), $e->getCode());
					}
				}
				else
				{
					throw new \Exception($e->getMessage(), $e->getCode());
				}
			}
			try
			{
				if(!$cancelOldOrder)
				{
					if($pdOrderLib->cancelOrder($params->oldOrderId, $orderId, $freezeMoneySort))
					{
						$this->finLog->log('生成新订单' . $orderId . '成功,取消旧订单' . $params->oldOrderId . '成功', $params, array('orderId' => $orderId), 0, 1);
					}
					else 
					{
						$this->finLog->log('生成新订单' . $orderId . '成功,取消旧订单' . $params->oldOrderId . '失败', $params, array('orderId' => $orderId));
					}
// 					if(!$pdOrderLib->cancelOrder($orderId))
// 					{
// 						$this->finLog->log('生成新订单' . $orderId . '成功,取消旧订单' . $params->oldOrderId . '失败,同时取消新订单' . $orderId . '失败', $params, $orderId);
// 					}
// 					$this->finLog->log('生成新订单' . $orderId . '成功,取消旧订单' . $params->oldOrderId . '失败,同时取消新订单' . $orderId . '成功', $params, $orderId);
// 					Response::setErrMsg( '410070','取消旧订单失败');
// 					return FALSE;
				}
			}
			catch(\Exception $e)
			{
				$this->finLog->log('生成新订单' . $orderId . '成功,取消旧订单' . $params->oldOrderId . '失败', $params, $e->getMessage());
// 				if(!$pdOrderLib->cancelOrder($orderId))
// 				{
// 					$this->finLog->log('生成新订单' . $orderId . '成功,取消旧订单' . $params->oldOrderId . '失败,同时取消新订单' . $orderId . '失败', $params, $orderId);
// 				}
// 				$this->finLog->log('生成新订单' . $orderId . '成功,取消旧订单' . $params->oldOrderId . '失败,同时取消新订单' . $orderId . '成功', $params, $orderId);
// 				Response::setErrMsg( '410070','取消旧订单失败');
// 				return FALSE;
			}

			$this->finLog->log('创建无产品订单成功', $params, array('orderId' => $orderId), 0, 1);
			return $orderId;

		}
		catch(\Exception $e)
		{
			$this->finLog->log('[0312]创建无产品订单失败', $params, $e->getCode() . ":: " . $e->getMessage());
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}

	/**
	 * 确认订单
	 * @param object $params 必须：enameId orderId，非必须：moneyType registarId linkEnameId
	 * @throws Exception
	 * @return boolean
	 */
	public function confirmOrder($params)
	{
		try
		{
			if(empty($params->enameId))
			{
				throw new \Exception('enameId有误', 410001);
			}
			if(empty($params->orderId))
			{
				throw new \Exception('orderId有误', 410026);
			}
			$this->ProductOrderLib = new \lib\manage\finance\ProductOrderLib($params->enameId);
			$this->ProductOrderLib->setMoneyTpye(empty($params->moneyType) ? $this->conf->moneyType->unwithdrawal : $params->moneyType);
			$this->ProductOrderLib->setRegistarId(empty($params->registarId) ? 0 : $params->registarId);
			$this->ProductOrderLib->setInTypeSon(empty($params->sonType) ? 0 : $params->sonType);
			$this->ProductOrderLib->setOutBankName(empty($params->outBankName) ? 0 : $params->outBankName);
			$return = $this->ProductOrderLib->confirmOrder($params->orderId, empty($params->linkEnameId) ? FALSE : $params->linkEnameId);
			$this->finLog->log('确认订单成功', $params, array('return' => $return), 0, 1);
			return $return;
		}
		catch(\Exception $e)
		{
			$this->finLog->log('[0313]确认订单失败', $params, array($e->getCode(), $e->getMessage()));
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}

	}
	/**
	 * 确认订单重寫
	 *
	 * @param object $params
	 *        	必须：enameId orderId，非必须：moneyType registarId linkEnameId
	 * @throws Exception
	 * @return boolean
	 */
	public function confirmOrderRe($params)
	{
		\lib\manage\finance\FinanceLogLib::logBatchSet(true);
		$db = \models\manage\finance\FinMod::getDB();
		try
		{
			
			$db->transBegin();//开始事务  
			if(empty($params->enameId))
			{
				throw new \Exception('enameId有误', 410001);
			}
			if(empty($params->orderId))
			{
				throw new \Exception('orderId有误', 410026);
			}
			$this->ProductOrderLib = new \lib\manage\finance\ProductOrderLib($params->enameId);
			
			//行锁，防止并发时数据有误
			$db->query('SELECT * FROM e_finances WHERE EnameId = '.$params->enameId.' FOR UPDATE');
			
			$this->ProductOrderLib->setMoneyTpye(empty($params->moneyType) ? $this->conf->moneyType->unwithdrawal : $params->moneyType);
			$this->ProductOrderLib->setRegistarId(empty($params->registarId) ? 0 : $params->registarId);
			$this->ProductOrderLib->setInTypeSon(empty($params->sonType) ? 0 : $params->sonType);
			$return = $this->ProductOrderLib->confirmOrder($params->orderId, empty($params->linkEnameId) ? FALSE : $params->linkEnameId);
			$db->transCommit();//提交事务
			$this->finLog->log('确认订单成功', $params, array('return' => $return), 0, 1);
			\lib\manage\finance\FinanceLogLib::batchLog();//批量处理日志
			return $return;
		}
		catch(\Exception $e)
		{
			$db->transRollback();//回滚事务
			$this->finLog->log('[0313]确认订单失败', $params, array($e->getCode(), $e->getMessage()));
			Response::setErrMsg($e->getCode(), $e->getMessage());
			\lib\manage\finance\FinanceLogLib::batchLog();
			return FALSE;
		}
		
	}

	/**
	 * 取消订单
	 * @param object $params 必须enameId orderId
	 * @throws Exception
	 * @return boolean
	 */
	public function cancelOrder($params)
	{
		try
		{
			if(empty($params->enameId))
			{
				throw new \Exception('enameId有误', 410001);
			}
			if(empty($params->orderId))
			{
				throw new \Exception('orderId有误', 410026);
			}
			$this->ProductOrderLib = new \lib\manage\finance\ProductOrderLib($params->enameId);
			$return = $this->ProductOrderLib->cancelOrder($params->orderId);
			$this->finLog->log('取消订单成功', $params, array('return' => $return), 0, 1);
			return $return;
		}
		catch(\Exception $e)
		{
			$this->finLog->log('[0314]取消订单失败', $params, array($e->getCode(), $e->getMessage()));
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}

	/**
	 * 获取订单信息
	 * @param int $enameId
	 * @param int $orderId
	 * @throws \Exception
	 * @return array|boolean
	 */
	public function getOrderInfo($enameId, $orderId)
	{
		try
		{ 
			if(empty($enameId))
			{
				throw new \Exception('enameId有误', 410001);
			}
			if(empty($orderId))
			{
				throw new \Exception('orderId有误', 410026);
			}
			$this->ProductOrderLib = new \lib\manage\finance\OrderLib($enameId);
			$return = $this->ProductOrderLib->getOrderInfo($orderId);
			$this->finLog->log('获取订单成功', array('enameId' => $enameId, 'orderId' => $orderId), array('return' => $return), 0, 1);
			return $return;
		}
		catch(\Exception $e)
		{
			$this->finLog->log('[0316]获取订单失败', array('enameId' => $enameId, 'orderId' => $orderId), array(
					$e->getCode(), $e->getMessage()));
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}

	/**
	 * 根据条件获取订单信息
	 */
	public function getOrderListByContion($data, $isNeedEnameId = true)
	{
		try 
		{
			$enameId = !empty($data['enameId']) ? $data['enameId'] : '';
			if(!$enameId && $isNeedEnameId)
			{
				throw new \Exception('enameId有误', 410001);
			}
			$params = array();
			$params['EnameId'] = $enameId;
			if(isset($data['orderStatus']))
			{
				$params['orderStatus'] = $data['orderStatus'];
			}
			if(!empty($data['orderType']))
			{
				$params['OrderType'] = $data['orderType'];
			}
			if(!empty($data['domain']))
			{
				$params['Domain'] = $data['domain'];
			}
			if(isset($data['registarId']))
			{
				$params['RegistarId'] = $data['registarId'];
			}
			if(!empty($data['startDate']))
			{
				$params['StartDate'] = $data['startDate'];
			}
			if(!empty($data['endDate']))
			{
				$params['EndDate'] = $data['endDate'];
			}
			if(!empty($data['remark']))
			{
				$params['Remark'] = $data['remark'];
			}
			if(!empty($data['inOrderType']))
			{
				$params['inOrderType'] = $data['inOrderType'];
			}
			if(!empty($data['inOrderStatus']))
			{
				$params['inOrderStatus'] = $data['inOrderStatus'];
			}
			if(!empty($data['checkYear']))
			{
				$params['checkYear'] = $data['checkYear'];
			}
			if(!empty($data['remarkHide']))
			{
				$params['RemarkHide'] = $data['remarkHide'];
			}
			$this->ProductOrderLib = new \lib\manage\finance\OrderLib($enameId);
			$return = $this->ProductOrderLib->getOrderListByContion($params);
			$this->finLog->log('获取订单成功', array('enameId' => $enameId, 'params' => $params), array('returntotal' => count($return)), 0, 1);
			return $return;
		}
		catch(\Exception $e)
		{
			$this->finLog->log('[自定义]获取订单失败', array('enameId' => $enameId,'params'=>$params), array(
					$e->getCode(), $e->getMessage()));
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}
	
	/**
	 * 已经确认成功订单后退款 
	 */
	public function systemRefund($enameId, $orderId,$remark = FALSE)
	{
		try
		{
			if(empty($enameId))
			{
				throw new \Exception('enameId有误', 410001);
			}
			if(empty($orderId))
			{
				throw new \Exception('orderId有误', 410026);
			}
			$this->ProductOrderLib = new \lib\manage\finance\OrderLib($enameId);
			$return = $this->getOrderInfo($enameId, $orderId);//获取订单信息
			if($this->ProductOrderLib->getOrderStatus() != '1')//确保是成功订单
			{
				throw new \Exception('订单非成功状态：' . $orderId, 410070);
			}
			$freezeMoneySort = $this->ProductOrderLib->getFreezeMoneySort();
			$financeInLib = new \lib\manage\finance\FinanceInLib($enameId);//判断该订单是否已经自动退款
			try
			{
				$checkStatus = $financeInLib->checkOrderId($enameId, $orderId);
			}
			catch(\Exception $e)
			{
				$checkStatus = FALSE;
			}
			if($checkStatus)
			{
				throw new \Exception('该退款记录已经存在' . $orderId, 410071);
			}
			$financeInLib->setOrderId($orderId);
			$financeInLib->setInMoney($this->ProductOrderLib->getPrice());
			$financeInLib->setInType($this->conf->type->systemRefund);
			$financeInLib->setLinkDomain($this->ProductOrderLib->getDomain());
			$financeInLib->setMoneyType('0');//根据订单扣款进行退款，所以金额类型未知
			$financeInLib->setOperator('9999');//操作者：系统调用
			$OrderType = $this->ProductOrderLib->getOrderType();
			$typeArr = $this->conf->type->lang->toArray();
			if(isset($typeArr[$OrderType]))
			{
				$inRemark = $this->conf->type->lang->$OrderType;
				$inRemark = $remark == FALSE ? $inRemark. '审核失败退款' : $inRemark . $remark;
				$financeInLib->setInRemark($inRemark);
			}
			if(!$financeInLib->refundFinanceIn($freezeMoneySort))
			{
				throw new \Exception('退款失败' . $orderId, 410072);
			}
			$totalScore = $financeInLib->getTotalScore();
			$scoreLib = new \lib\manage\finance\ScoreLib();
			$score = $this->setScore($this->ProductOrderLib->getOrderType(), $this->ProductOrderLib->getPrice());
			$scoreLib->subScore($enameId, $score, $totalScore, $orderId, $inRemark, $this->ProductOrderLib->getDomain());
			//取消对应的优惠券使用记录
			$promoId = $this->ProductOrderLib->getPromoId();
			if(intval($promoId) > 0)
			{
				$promoLib = new \lib\manage\finance\PromoLib();
				$promoLib->setCheckOrderId($orderId);
				$promoLib->setCheckEnameId($enameId);
				$promoLib->setCheckPromoId($promoId);
				$promoLib->cancelPromoUsedSDK();
			}
			return TRUE;
		}
		catch(\Exception $e)
		{
			$this->finLog->log('[0404]系统退款失败', array('enameId' => $enameId, 'orderId' => $orderId), array(
					$e->getCode(), $e->getMessage()));
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}
	}
	
	/**
	 * 已经确认成功订单后退款(重写)
	 */
	public function systemRefundRe($enameId, $orderId,$remark = FALSE)
	{
		\lib\manage\finance\FinanceLogLib::logBatchSet(true);
		$db = \models\manage\finance\FinMod::getDB();
		try
		{
			$db->transBegin();//开始事务
			if(empty($enameId))
			{
				throw new \Exception('enameId有误', 410001);
			}
			if(empty($orderId))
			{
				throw new \Exception('orderId有误', 410026);
			}
			$this->ProductOrderLib = new \lib\manage\finance\OrderLib($enameId);
			$return = $this->getOrderInfo($enameId, $orderId);//获取订单信息
			if($this->ProductOrderLib->getOrderStatus() != '1')//确保是成功订单
			{
				throw new \Exception('订单非成功状态：' . $orderId, 410070);
			}
			
			//行锁，防止并发时数据有误
			$db->query('SELECT * FROM e_finances WHERE EnameId = '.$enameId.' FOR UPDATE');
			
			$freezeMoneySort = $this->ProductOrderLib->getFreezeMoneySort();
			$financeInLib = new \lib\manage\finance\FinanceInLib($enameId);//判断该订单是否已经自动退款
			try
			{
				$checkStatus = $financeInLib->checkOrderId($enameId, $orderId);
			}
			catch(\Exception $e)
			{
				$checkStatus = FALSE;
			}
			if($checkStatus)
			{
				throw new \Exception('该退款记录已经存在' . $orderId, 410071);
			}
			$financeInLib->setOrderId($orderId);
			$financeInLib->setInMoney($this->ProductOrderLib->getPrice());
			$financeInLib->setInType($this->conf->type->systemRefund);
			$financeInLib->setLinkDomain($this->ProductOrderLib->getDomain());
			$financeInLib->setMoneyType('0');//根据订单扣款进行退款，所以金额类型未知
			$financeInLib->setOperator('9999');//操作者：系统调用
			$OrderType = $this->ProductOrderLib->getOrderType();
			$typeArr = $this->conf->type->lang->toArray();
			if(isset($typeArr[$OrderType]))
			{
				$inRemark = $this->conf->type->lang->$OrderType;
				$inRemark = $remark == FALSE ? $inRemark. '审核失败退款' : $inRemark . $remark;
				$financeInLib->setInRemark($inRemark);
			}
			if(!$financeInLib->refundFinanceIn($freezeMoneySort))
			{
				throw new \Exception('退款失败' . $orderId, 410072);
			}
			$totalScore = $financeInLib->getTotalScore();
			$scoreLib = new \lib\manage\finance\ScoreLib();
			$score = $this->setScore($this->ProductOrderLib->getOrderType(), $this->ProductOrderLib->getPrice());
			$scoreLib->subScore($enameId, $score, $totalScore, $orderId, $inRemark, $this->ProductOrderLib->getDomain());
			//取消对应的优惠券使用记录
			$promoId = $this->ProductOrderLib->getPromoId();
			if(intval($promoId) > 0)
			{
				$promoLib = new \lib\manage\finance\PromoLib();
				$promoLib->setCheckOrderId($orderId);
				$promoLib->setCheckEnameId($enameId);
				$promoLib->setCheckPromoId($promoId);
				$promoLib->cancelPromoUsedSDK();
			}
			$db->transCommit();//提交事务
			\lib\manage\finance\FinanceLogLib::batchLog();//批量处理日志
			return TRUE;
		}
		catch(\Exception $e)
		{
			$db->transRollback();//回滚事务
			$this->finLog->log('[0404]系统退款失败', array('enameId' => $enameId, 'orderId' => $orderId), array(
					$e->getCode(), $e->getMessage()));
			Response::setErrMsg($e->getCode(), $e->getMessage());
			\lib\manage\finance\FinanceLogLib::batchLog();//批量处理日志
			return FALSE;
		}
	}

	/**
	 * 设置消费产生的积分
	 */ 
	private function setScore($financeType, $money)
	{
		$scoreToJifen = $this->conf->score->toArray();
		$scoreRate = isset($scoreToJifen[$financeType]) ? $scoreToJifen[$financeType] : 0;
		$addScore = floor($scoreRate * $money);
		return $addScore;
	}
	
	/**
	 * 暂时是更改订单表的productcost
	 */
	public function setOrderInfo($params)
	{
		try
		{
			$enameId = $params['enameId'];
			$orderId = $params['orderId'];
			if(empty($enameId))
			{
				throw new \Exception('enameId有误', 410001);
			}
			if(empty($orderId))
			{
				throw new \Exception('orderId有误', 410026);
			}
			$set = array();
			if(isset($params['productCost']))
			{
				$set['productCost'] = $params['productCost'];
			}
			$this->ProductOrderLib = new \lib\manage\finance\OrderLib($enameId);
			$this->ProductOrderLib->getOrderInfo($orderId);
			return $this->ProductOrderLib->setOrderInfoByOrderId($orderId, $set);
		}
		catch(\Exception $e)
		{
			$this->finLog->log('setOrderInfo订单失败', array('enameId' => $enameId, 'orderId' => $orderId), array(
					$e->getCode(), $e->getMessage()));
			Response::setErrMsg($e->getCode(), $e->getMessage());
			return FALSE;
		}		
	}
}
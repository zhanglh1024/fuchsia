<?php
namespace logic\manage\newqueue;
use lib\manage\newqueue\QueueTaskLib;
use models\manage\newqueue\TasksMod;
use models\manage\newqueue\TasksDetailMod;

/**
 * 队列逻辑(用户前后使用)
 */
class QueueLogic
{

	private $queueTaskLib;

	private $tasksMod;

	private $tasksDetailMod;

	private $templdateMod;

	private $normalMod;

	private $normalLib;

	public function __construct()
	{
		$this->queueTaskLib = new QueueTaskLib();
		$this->tasksDetailMod = new TasksDetailMod();
		$this->tasksMod = new TasksMod();
		$this->templdateMod = new \models\manage\newqueue\TemplateMod();
		$this->normalMod = new \models\manage\newqueue\NormalMod();
		$this->normalLib = new \lib\manage\newqueue\QueueNormalLib();
	}

	/**
	 * 添加任务队列
	 *
	 * @param array $data
	 */
	public function addQueueTask($params)
	{
		if(in_array($params['Function'], array('template_push', 'modify_domain_dns')))
		{
			$logic = new \logic\manage\thrift\QueueLogic();
			return $logic->addQueueTask($params);
		}
		return $this->queueTaskLib->addQueue($params); 
	}

	/**
	 * 获取任务队列列表
	 *
	 * @param array $params
	 */
	public function getQueueTaskList($params)
	{
		return $this->tasksMod->getList($params);
	}

	/**
	 * 获取任务列表统计
	 *
	 * @param array $params
	 */
	public function getQueueTaskCount($params)
	{
		return $this->tasksMod->getCount($params);
	}

	/**
	 * 获取任务详情队列列表
	 *
	 * @param array $params
	 */
	public function getQueueTaskDetailList($params)
	{
		return $this->tasksDetailMod->getList($params);
	}

	/**
	 * 获取任务详情数量
	 *
	 * @param array $params
	 */
	public function getQueueTaskDetailCount($params)
	{
		return $this->tasksDetailMod->getCount($params);
	}

	/**
	 * 根据任务id取消队列
	 *
	 * @param array $params
	 * @throws \Exception
	 */
	public function cancelQueueByTaskId($params)
	{
		if(empty($params['TaskId']))
		{
			throw new \Exception('error argument');
		}
		$taskId = intval($params['TaskId']);
		if(! $list = $this->tasksDetailMod->getList($params))
		{
			throw new \Exception('队列不可取消');
		}
		$error = '';
		foreach($list as $value)
		{
			if($value['Function'] == 'domain_renew' || $value['Status'] != 0)
			{
				continue;
			}
			if(! $this->queueTaskLib->cancelQueue($value['Function'], $value['QueueId'], $value['TaskId'],$value['CreateTime']))
			{
				$error .= $value['QueueId'] . '取消执行失败；';
			}
		}
		if($error)
		{
			throw new \Exception($error);
		}
		return true;
	}

	/**
	 * 根据队列id取消队列
	 *
	 * @param int $queueId
	 * @throws \Exception
	 */
	public function cancelQueueByQueueId($params)
	{
		if(empty($params['QueueId']))
		{
			throw new \Exception('error argument');
		}
		$info = $this->tasksDetailMod->getList($params, true);
		if(empty($info) || $info['Status'] != 0 || $info['Function'] == 'domain_renew')
		{
			throw new \Exception('队列不可取消');
		}
		if(!$this->queueTaskLib->cancelQueue($params['Function'], $params['QueueId'], $info['TaskId'],$info['CreateTime']))
		{
			throw new \Exception('队列取消失败', 340011);
		}
		return true;
	}

	/**
	 * 设置任务队列失败
	 *
	 * @param array $params
	 * @throws \Exception
	 */
	public function setQueueTaskFailure($params)
	{
		if(empty($params['QueueId']))
		{
			throw new \Exception('error argument');
		}
		if(! $info = $this->tasksDetailMod->getList($params, true))
		{
			throw new \Exception('队列不存在' ,340012);
		}
		// 设置详情表状态
		if(! $this->tasksDetailMod->updateQueue(array('Status' => 3, 'SuccessTime' => time()), $params['QueueId']))
		{
			throw new \Exception('状态设置失败' ,340013);
		}
			// 添加取消队列key
		$queueCommonLib = new \lib\manage\newqueue\QueueCommonLib();
		if(!$queueCommonLib->cancelQue($info['Function'], $params['QueueId'], $info['CreateTime']))
		{
			throw new \Exception('redis队列取消失败', 340011);
		}
		// 修改队列失败数量
		if(! $this->tasksMod->updateTask(array('FailureTotal' => 1), array('TaskId' => $info['TaskId'])))
		{
			throw new \Exception('状态设置成功，失败数量修改失败' ,340014);
		}
		// 获取队列主表信息
		if(! $taskInfo = $this->tasksMod->getList(array('TaskId' => $info['TaskId']), true))
		{
			throw new \Exception('队列信息获取失败' ,340015);
		}
		if($taskInfo['Total'] == ($taskInfo['SuccessTotal'] + $taskInfo['FailureTotal']))
		{
			if(! $this->tasksMod->updateTask(array('Status' => 5), array('TaskId' => $info['TaskId'])))
			{
				throw new \Exception('修改队列状态失败' ,340016);
			}
		}
		return true;
	}

	/**
	 * 批量重启
	 *
	 * @param array $params
	 */
	public function setMultiTaskRestart($params)
	{
		$result = array('success' => array(), 'error' => array());
		foreach($params['QueueId'] as $queueId)
		{
			try
			{
			   $this->setTaskRestart(array('QueueId' => $queueId));
				$result['success'][] = $queueId;
			}
			catch(\Exception $e)
			{
				$result['error'][] = array('queueId' => $queueId, 'errorMsg' => $e->getMessage());
			}
		}
		return $result;
	}

	/** 
	 * 设置重启队列
	 *
	 * @param array $params
	 * @throws \Exception
	 */
	public function setTaskRestart($params)
	{
		if(empty($params['QueueId']))
		{
			throw new \Exception('error argument');
		}
		if(! $info = $this->tasksDetailMod->getList($params, true))
		{
			throw new \Exception('队列不存在' ,340012);
		}
		// 判断队列是否能够重启
		if(!$this->queueTaskLib->isAllowResend($info['Status'], $info['Function'], $info['QueueId'], $info['CreateTime']))
		{
			throw new \Exception('不能加入重启队列', 340018);
		}
		if(! $this->tasksDetailMod->updateQueue(array('Status' => 5), $params['QueueId']))
		{
			throw new \Exception('队列状态修改失败' ,340019);
		}
		if(!$this->queueTaskLib->addRestarQueue($params['QueueId'], $info))
		{
			throw new \Exception('添加重启队列失败', 340020);
		}
		return true;
	}

	/**
	 * 更新批量任务主表信息
	 */
	public function upQueueTaskByTaskId($params)
	{
		if(empty($params['TaskId']))
		{
			throw new \Exception('error taskid');
		}
		$where['TaskId'] = $params['TaskId'];
		unset($params['TaskId']);
		return $this->tasksMod->updateTask($params, $where);
	}

	/**
	 * 获取队列模板列表
	 *
	 * @param array $params
	 */
	public function getTemplateList($params)
	{
		return $this->templdateMod->getList($params);
	}

	/**
	 * 获取队列模板统计
	 */
	public function getTemplateCount($params)
	{
		return $this->templdateMod->getCount($params);
	}

	/**
	 * 获取队列模板统计
	 */
	public function getTemplateInfo($tempateId)
	{
		if(is_numeric($tempateId))
		{
			return $this->templdateMod->getInfo($tempateId);
		}
		else
		{
			return $this->templdateMod->getInfoByTemplateName($tempateId);
		}
	}

	/**
	 * 修改模板队列
	 *
	 * @param array $data
	 * @param int $templdateId
	 */
	public function updateTempalate($data, $templateId)
	{
		// 如果修改成默认模板，其他模板要置为未默认
		if($data['IsDefault'] == 1)
		{
			if(! $info = $this->templdateMod->getInfo($templateId))
			{
				throw new \Exception('获取模板ID：' . $templateId . '信息失败' ,330037);
			}
			if($result = $this->templdateMod->getInfoByTemplateName($info['TemplateName']));
			{
				if(! $this->templdateMod->updateTemplate(array('IsDefault' => 0), $result['TemplateId']))
				{
					throw new \Exception('修改模板ID:' . $result['TemplateId'] . '为非默认模板失败' ,330038);
				}
			}
		}
		return $this->templdateMod->updateTemplate($data, $templateId);
	}

	/**
	 * 添加模板
	 *
	 * @param array $params
	 */
	public function addTemplate($params)
	{
		$params['CreateTime'] = time();
		$params['UpdateTime'] = 0;
		if($result = $this->templdateMod->getInfoByTemplateName($params['TemplateName']))
		{
			if(! $this->templdateMod->updateTemplate(array('IsDefault' => 0), $result['TemplateId']))
			{
				throw new \Exception('修改模板ID:' . $result['TemplateId'] . '为非默认模板失败' ,330038);
			}
		}
		return $this->templdateMod->addTemplate($params);
	}

	/**
	 * 获取普通队列列表
	 *
	 * @param array $params
	 */
	public function getQueueNormalList($params)
	{
		$result = array('count' => 0, 'list' => array());
		if($result['count'] = $this->normalMod->getCount($params))
		{
			$result['list'] = $this->normalMod->getList($params);
		}
		return $result;
	}

	/**
	 * 添加普通队列
	 *
	 * @param array $params
	 * @param boolean|int
	 */
	public function addQueueNormal($params)
	{
		$logic = new \logic\manage\thrift\QueueLogic();
		return $logic->addQueueNormal($params);
		//return $this->normalLib->addNormalQueue($params); 
	}

	/**
	 * 批量普通队列重启
	 *
	 * @param array $params
	 */
	public function setMultiNormalResend($params)
	{
		$result = array('success' => array(), 'error' => array());
		foreach($params['queueId'] as $queueId)
		{
			try
			{
				$this->setNormalResend(array('QueueId' => $queueId));
				$result['success'][] = $queueId;
			}
			catch(\Exception $e)
			{
				$result['error'][] = array('queueId' => $queueId, 'errorMsg' => $e->getMessage());
			}
		}
		return $result;
	}

	/**
	 * 设置添加重发队列
	 *
	 * @param array $params
	 * @throws \Exception
	 */
	public function setNormalResend($params)
	{
		if(empty($params['QueueId']))
		{
			throw new \Exception('error argument');
		}
		if(! $info = $this->normalMod->getInfo($params['QueueId']))
		{
			throw new \Exception('队列不存在' ,340012);
		}
		// 判断队列是否能够重启
		if(! $this->normalLib->isAllowResend($info['Status'], $info['Function'], $info['QueueId']))
		{
			throw new \Exception('不能加入重启队列' ,340018);
		}
		if(! $this->normalMod->updateQueue(array('Status' => 5), $params['QueueId']))
		{
			throw new \Exception('队列状态修改失败' ,340019);
		}
		if(! $this->normalLib->addRestarQueue($params['QueueId'], $info))
		{
			throw new \Exception('添加重启队列失败' ,340020);
		}
		return true;
	}
}
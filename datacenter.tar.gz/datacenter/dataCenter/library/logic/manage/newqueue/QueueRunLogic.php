<?php
namespace logic\manage\newqueue;
use core\Response;

/**
 * 队列执行逻辑
 */
class QueueRunLogic
{

	private $funcName;

	private $queueCommonLib;

	private $funcConfig;

	private $redis;

	private $queueRunLib;

	private $queueFunLib;

	private function init($funcName)
	{
		if(empty($funcName))
		{
			throw new \Exception('参数错误' , 410043);
		}
		$this->funcName = $funcName;
		$this->queueCommonLib = new \lib\manage\newqueue\QueueCommonLib();
		// 获取方法对应的队列配置
		if(! $this->funcConfig = $this->queueCommonLib->getFuncItemByFuncName($this->funcName))
		{
			throw new \Exception('不存在的队列', 900001);
		}
		if(empty($this->funcConfig['code']))
		{
			throw new \Exception('队列code不存在', 900002);
		}
		$this->redis = \core\RedisLib::getInstance('manage');
		$this->queueRunLib = new \lib\manage\newqueue\QueueRunLib();
		$this->queueFunLib = new \lib\manage\newqueue\QueueFuncLib();
	}

	/**
	 * 执行正常队列
	 *
	 * @throws \Exception
	 * @return array
	 */
	public function run($funcName)
	{
		try
		{
			$this->init($funcName);
			foreach($this->funcConfig['priority'] as $priority)
			{
				$startTime = microtime(true);
				$queueKey = $this->queueCommonLib->generateKey('runQue', $this->funcName, $priority);
				//\core\Log::write('queueKey:' . $queueKey . ',count:' . count($this->redis->lrange($queueKey, 0, - 1)), 'newQueue', 'runQueue');//量大是容易导致溢出
				if(! $info = $this->redis->lPop($queueKey))
				{
					continue;
				}
				\core\Log::write('queueKey:' . $queueKey . ',info:' . json_encode($info), 'newQueue', 'runQueue');
				// 队列表自增id
				$queueId = intval($info['QueueId']);
				$manualKey = $this->queueCommonLib->generateKey('manual', $this->funcName, '', $queueId);
				$cancelKey = $this->queueCommonLib->generateKey('cancel', $this->funcName, '', $queueId);
				$restartKey = $this->queueCommonLib->generateKey('restart', $this->funcName, '', $queueId);
				if($this->redis->exists($manualKey))
				{
					$this->redis->del($manualKey);
					continue;
				}
				elseif($this->redis->exists($restartKey))
				{
					continue;
				}
				if($this->redis->exists($cancelKey))
				{
					$this->redis->del($cancelKey);
					continue;
				}
				$this->execute($info);
				\core\Log::write('queueId:' . $queueId . ',time:' . (microtime(true) - $startTime), 'newQueue', 
					'runQueue' . $funcName);
			}
		}
		catch(\Exception $e)
		{
			\core\Log::write($e->getMessage() . ',info:' . (empty($info) ? '' : json_encode($info)), 'newQueue', 
				'runError');
		}
	}

	/**
	 * 重启队列
	 */
	public function rerun($funcName)
	{
		try
		{
			$this->init($funcName);
			$startTime = microtime(true);
			$queueKey = $this->queueCommonLib->generateKey('rerunQue', $this->funcName);
			\core\Log::write('queueKey:' . $queueKey . ',count:' . count($this->redis->lrange($queueKey, 0, - 1)), 
				'newQueue', 'rerunQueue');
			if(! $info = $this->redis->lPop($queueKey))
			{
				return false;
			}
			// 队列表自增id
			$queueId = intval($info['QueueId']);
			$this->redis->del($this->queueCommonLib->generateKey('restart', $this->funcName, '', $queueId));
			$cancelKey = $this->queueCommonLib->generateKey('cancel', $this->funcName, '', $queueId);
			if($this->redis->exists($cancelKey))
			{
				$this->redis->del($cancelKey);
				return false;
			}
			$result = $this->execute($info);
			\core\Log::write('queueId:' . $queueId . ',time:' . (microtime(true) - $startTime) . ',result:' . $result, 
				'newQueue', 'rerunQueue' . $funcName);
		}
		catch(\Exception $e)
		{
			\core\Log::write($e->getMessage() . ',info:' . (empty($info) ? '' : json_encode($info)), 'newQueue', 
				'rerunError');
		}
	}

	/**
	 * 具体执行逻辑
	 *
	 * @param array $info
	 * @throws \Exception
	 */
	private function execute($info)
	{
		if(! method_exists('\lib\manage\newqueue\QueueFuncLib', $this->funcName))
		{
			$this->queueRunLib->updateFailure($info);
			return 'function not exists';
		}
		$function = $this->funcName;
		$result = $this->queueFunLib->$function($info);
		
		// QueueFuncLib中关闭了数据库连接，重新实例化类
		$this->queueRunLib = new \lib\manage\newqueue\QueueRunLib();
		$this->queueFunLib = new \lib\manage\newqueue\QueueFuncLib();
		
		\core\Log::write('Params:' . json_encode($info) . ',result:' . $result, 'newQueue', 'executeQueue');
		if(true === $result)
		{
			$this->queueRunLib->updateSuccess($info);
		}
		else if(NULL === $result)
		{
			$this->queueRunLib->updateFailure($info);
		}
		else
		{
			if('Authorization' === $result)
			{
				$this->queueRunLib->updateFailure($info);
			}
			elseif($this->funcConfig['repeat'] != 0 && ($info['Repeat'] + 1 > $this->funcConfig['repeat']))
			{
				$this->queueRunLib->updateFailure($info);
			}
			else
			{
				if(! empty($result))
				{
					$this->queueRunLib->updateStep(array('Step' => $result), $info['QueueId']);
				}
				// 作为批量任务执行后更新成功或者失败次数的依据
				$info['Status'] = $info['Status'] == 3 ? 3 : 5;
				$info['Repeat']++;
				if(! $this->queueRunLib->addRestarQueue($info['QueueId'], $info))
				{
					$this->queueRunLib->updateFailure($info);
				}
				else 
				{
					$this->queueRunLib->updateResend($info);
				}
			}
		}
		return true;
	}
}
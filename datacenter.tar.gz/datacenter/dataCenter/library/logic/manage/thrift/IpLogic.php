<?php
namespace logic\manage\thrift;
use Thrift\Exception\TException;
use Thrift\Transport\TSocket;
use Thrift\Factory\TTransportFactory;
use Thrift\Factory\TBinaryProtocolFactory;
use Thrift\Protocol\TMultiplexedProtocol;
class IpLogic
{

	private $conf;

	private $client;

	private $protocol;

	private $transport;

	private $socket;

	public function __construct()
	{
		include_once APP_PATH . '/dataCenter/library/lib/manage/thrift/common.php';
		\common\thrift\ThriftStar::startup("IpServer");
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', "IpServer");
		$this->socket = new TSocket($this->conf->serverHost, $this->conf->serverPort);
		$this->socket->setRecvTimeout($this->conf->timeout);
		$this->socket->setRecvTimeout($this->conf->timeout);
		$transportFactory = new TTransportFactory();
		$protocolFactory = new TBinaryProtocolFactory();
		$this->transport = $transportFactory->getTransport($this->socket);
		$this->protocol = $protocolFactory->getProtocol($this->transport);
	}

	/**
	 * 省份和城市是以字符串的方式返回
	 * 
	 * @param string $ip
	 * @param boolean $force true的时候表示不完整的省份城市也要返回，不存在的以横杠‘－’拼接运营商
	 */
	public function getLocationStr($ip, $force = false)
	{
		try
		{
			$this->transport->open();
			$mp = new TMultiplexedProtocol($this->protocol, "ipServer");
			$client = new \IpServer\IPClient($mp);
			$result = $client->Find($ip);
			$location = '';
			$flag = false;//标志是否中国地区不完整
			if(!empty($result->Country) && $result->Country != 'N/A')
			{
				if($result->Country == '中国')
				{
					if(empty($result->Region) || empty($result->City) || $result->Region == 'N/A' ||
						 $result->City == 'N/A') // 国内地址，需要定位到省市 否则''
					{
						//中国地区无城市的不强制返回空，用于安全警报显示，反之返回''
						if(false == $force)
						{
							return '';
						}
						$flag = true;
					}
				}
				else
				{
					if($result->Country == '局域网' || $result->Country == '本地地址' || empty($result->Region) ||
						 $result->Region == 'N/A') // 国外，需要定位到区域 否则'' 局域网和本地地址返回也当''
					{
						return '';
					}
				}
				$location .= $result->Country;
			}
			else
			{
				return ''; // 获取地址失败
			}
			if(!empty($result->Region) && $result->Region != 'N/A')
			{
				$location .= $result->Region;
			}
			if(!empty($result->City) && $result->City != 'N/A' && $result->Region != $result->City)
			{
				$location .= $result->City;
				if(!(strpos($result->City, '自治州') || in_array($result->City, array('兴安盟', '锡林郭勒盟', '阿拉善盟')) ||
					 strpos($result->City, '地区')))
				{
					$location .= '市';
				}
			}
			$this->transport->close();
			if(true == $flag && true == $force && !empty($result->Isp) && $result->Isp != 'N/A')
			{
				return $location . "-" . $result->Isp;
			}
			return $location;
		}
		catch(\Exception $tx)
		{
			\core\Log::write("getAddress," . $tx->getMessage(), 'thrift', 'getAddress');
			$this->transport->close();
			return 'wfc';//请求异常和请求频率超出限制
		}
	}
	
	/**
	 * 省份和城市是以数组的方式返回
	 * @param string $ip
	 * @return array('Country'=>'国家','Region'=>'省','City'=>'市','Isp'=>'运行商') 
	 * 值N/A 表示未知
	 */
	public function getLocation($ip)
	{
		try
		{   
		    $this->transport->open();
			$mp = new TMultiplexedProtocol($this->protocol, "ipServer");
			$client = new \IpServer\IPClient($mp);
			$result = $client->Find($ip);
			$this->transport->close();
			return (array)$result;
		}
		catch(\Exception $tx)
		{
			\core\Log::write("getAddress," . $tx->getMessage(), 'thrift', 'getAddress');
			$this->transport->close();
			return FALSE;
		}
	}
}
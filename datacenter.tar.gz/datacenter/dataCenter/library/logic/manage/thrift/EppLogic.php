<?php
namespace logic\manage\thrift;
use Thrift\Exception\TException;
use Thrift\Transport\TSocket;
use Thrift\Factory\TTransportFactory;
use Thrift\Factory\TBinaryProtocolFactory;
use Thrift\Protocol\TMultiplexedProtocol;
use core\RpcResponse;
use lib\manage\common\DomainFunLib;

class EppLogic
{

	private $conf;

	private $client;

	private $protocol;

	private $transport;

	private $socket;

	public function __construct()
	{
		include_once APP_PATH . '/dataCenter/library/lib/manage/thrift/common.php';
		\common\thrift\ThriftStar::startup("enameepp");
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', "enameepp");
		$this->socket = new TSocket($this->conf->serverHost, $this->conf->serverPort);
		$this->socket->setRecvTimeout($this->conf->timeout);
		$this->socket->setRecvTimeout($this->conf->timeout);
		$transportFactory = new TTransportFactory();
		$protocolFactory = new TBinaryProtocolFactory();
		$this->transport = $transportFactory->getTransport($this->socket);
		$this->protocol = $protocolFactory->getProtocol($this->transport);
		$this->transport->open();
	}

	/**
	 * com net实名制注册接口 暂时com/net
	 *
	 * @param unknown $domain        	
	 * @param unknown $templateId        	
	 * @param unknown $year        	
	 * @param unknown $productType        	
	 * @param string $business        	
	 */
	public function domainEppReg($domain, $templateId, $year, $business = "", $productType = "")
	{
		try
		{
			$mp = new TMultiplexedProtocol($this->protocol, "domain");
			$client = new \enameepp\EppDomainClient($mp);
			$dnInfo = new \enameepp\DomainCreateParams();
			if(! $business)
			{
				$vspLogic = new \logic\manage\thrift\VspLogic();
				$business = $vspLogic->getDomainBusinessCode($domain);
			}
			$dnInfo->BusinessCode = $business;
			$dnInfo->domain = $domain;
			$dnInfo->period = $year;
			$dnInfo->periodUnit = "y";
			$dnInfo->templateID = is_numeric($templateId) ? self::getTemplateNameVsp($templateId,FALSE) : $templateId;
			$dnInfo->dcf = new \enameepp\DomainCreateFee();
			$dnInfo->dcl = new \enameepp\DomainCreateLaunch();
			$dnInfo->isForceCreate = true;
			$dnInfo->dcl->notice = new \enameepp\DomainCreateLaunchNotice();
			$dnInfo->wdwp = new \enameepp\WebccDomainWhoisParams();
			$dnInfo->tld = $productType == 7 ? 22 : strtolower(DomainFunLib::getDomainClass($domain));
			$regDomain = $client->Create($dnInfo);
			$return = json_decode($regDomain, true);
			$this->transport->close();
			if(! empty($return["resultCode"]))
			{
				if($return["resultCode"] == 1000)
				{
					return array(
							"resultCode" => 5000,  
							'data' => array('epp' => $productType == 7 ? 22 : ($dnInfo->tld =="top" ? 86 : 21), // 后期需要优化下
"createDate" => $return["createDate"], "updateDate" => $return["createDate"], "expireDate" => $return["expireDate"]));
				}
				\core\Log::write("shimingreg,".$domain."," . json_encode($return),'domain', 'shimingzhi_reg');
				return array(
						"resultCode" => "5015", 
						"data" => array(
								"msg" => array(
										"resultCode" => $return["resultCode"], "resultMsg" => $return["resultMsg"])));
			}
			return array(
					"resultCode" => "5015", "data" => array("msg" => array("resultCode" => 1019, "resultMsg" => "系统错误")));
		}
		catch(\Exception $e)
		{
			\core\Log::write(
				"shimingreg," . $e->getMessage() . "," . $domain . "," . $templateId . "," . $year . "," . $business, 
				'domain', 'shimingzhi_reg');
			return array(
					"resultCode" => "5015", 
					"data" => array("msg" => array("resultCode" => 1019, "resultMsg" => $e->getMessage())));
		}
	}

	/**
	 * com net模板过户接口
	 *
	 * @param unknown $domain        	
	 * @param unknown $templateName        	
	 */
	public function domainEppChangeRegistrant($tempData)
	{
		try
		{
			$mp = new TMultiplexedProtocol($this->protocol, "domain");
			$client = new \enameepp\EppDomainClient($mp);
			$dnInfo = new \enameepp\DomainUpdateContactParams();
			$dnInfo->domain = $tempData['domain'];
			$dnInfo->BusinessCode = ! empty($tempData['businessCode']) ? $tempData['businessCode'] : '';
			$dnInfo->templateName = ! empty($tempData['templateName']) ? $tempData['templateName'] : self::getTemplateNameVsp($tempData['templateId']);
			$dnInfo->templateName = $this->checkEUTemp($dnInfo->templateName);
			$tld = self::getDomainRegid($tempData);
			$dnInfo->tld = $tld ? $tld : strtolower(DomainFunLib::getDomainClass($tempData['domain']));
			$dnInfo->wdwp = new \enameepp\WebccDomainWhoisParams();
			if($dnInfo->tld == 61)
			{
				$tempInfo = self::getTemplateEnNameVsp(! empty($tempData['templateName']) ? $tempData['templateName'] : $tempData['templateId']);
				$dnInfo->wdwp->City = $tempInfo['City'];
				$dnInfo->wdwp->CountryName=$tempInfo['CountryName'];
				$dnInfo->wdwp->Email=$tempInfo['Email'];
				$dnInfo->wdwp->Fax=$tempInfo['Fax'];
				$dnInfo->wdwp->FirstName=$tempInfo['FirstName'];
				$dnInfo->wdwp->LastName=$tempInfo['LastName'];
				$dnInfo->wdwp->Org=$tempInfo['Org'];
				$dnInfo->wdwp->Phone=$tempInfo['Phone'];
				$dnInfo->wdwp->PostCode=$tempInfo['PostCode'];
				$dnInfo->wdwp->Province=$tempInfo['Province'];
				$dnInfo->wdwp->Street=$tempInfo["Street"];
			}
			$upInfo = $client->UpdateContact($dnInfo);
			$return = json_decode($upInfo, true);
			$this->transport->close();
			if(! empty($return["resultCode"]))
			{
				if($return["resultCode"] == 1000)
				{
					return array("resultCode" => 5000, 'data' => $return);
				}
				\core\Log::write("shimingupcontantc," . $dnInfo->domain.','.json_encode($dnInfo).','.json_encode($return), 'domain',
					'shimingzhi_upcontact');
				return array("resultCode" => "5004", "data" => array("msg" => $return));
			}
			return array(
					"resultCode" => "5004", "data" => array("msg" => array("resultCode" => 1003, "resultMsg" => "系统错误")));
		}
		catch(\Exception $e)
		{
			\core\Log::write("shimingupcontantc," . $e->getMessage() . "," . json_encode($tempData), 'domain', 
				'shimingzhi_upcontact');
			return array(
					"resultCode" => "5004", 
					"data" => array("msg" => array("resultCode" => 1003, "resultMsg" => $e->getMessage())));
		}
	}

	public static function getTemplateNameVsp($templateId,$throw = true)
	{
		$mod = new \models\manage\domain\TemplateMod();
		$tempInfo = $mod->getTemplate(array('TemplateId' => $templateId));
		if($tempInfo)
		{
			return $tempInfo[0]['TemplateName'];
		}
		if(!$throw)
		{
			return FALSE;
		}
		throw new \Exception("模板信息获取失败");
	}

	public static function getTemplateEnNameVsp($templateId)
	{
		$mod = new \models\manage\domain\TemplateMod();
		$tempInfo = $mod->getEnTemplateByTemplateId($templateId);
		if($tempInfo)
		{
			return $tempInfo;
		}
		throw new \Exception("模板信息获取失败");
	}
	
	public static function getDomainRegid($data)
	{
		if(!empty($data['registrarID']))
		{
			return $data['registrarID'];
		}
		$dnLib = new \lib\manage\domain\DomainManageLib();
		$info = $dnLib->getDomainInfo(array('DomainName'=>$data['domain']));
		return $info && $info['RegistrarId'] ? $info['RegistrarId'] : 0;
	}
	
	/**
	 * com/net域名申请转入
	 *
	 * @param unknown $domain        	
	 * @param unknown $password        	
	 * @param unknown $period        	
	 * @param unknown $templateName        	
	 */
	public function domainTransferIn($domain, $password, $period, $templateName, $business = '')
	{
		try
		{
			$mp = new TMultiplexedProtocol($this->protocol, "domain");
			$client = new \enameepp\EppDomainClient($mp);
			$dnt = new \enameepp\DomainApplyTransferInParams();
			$dnt->datif = new \enameepp\DomainApplyTransferInFee();
			$dnt->domain = $domain;
			$dnt->password = $password;
			$dnt->period = $period;
			$dnt->periodUnit = "y";
			$dnt->tld = DomainFunLib::getDomainClass($domain);
			$dnt->wdwp = new \enameepp\WebccDomainWhoisParams();
			$dnt->BusinessCode = $business;
			$dnt->templateName = $templateName;
			$return = $client->ApplyTransferIn($dnt);
			$return = json_decode($return, true);
			$this->transport->close();
			if(! empty($return["resultCode"]))
			{
				if($return["resultCode"] == 1000)
				{
					return array(
							"resultCode" => 5000, 'resultMsg' => array("domain transfer in success shiming"), 
							"data" => array());
				}
			}
			\core\Log::write("{$domain},{$business},{$templateName},".json_encode($return), 'domain',
				'shimingtransfer');
			return array(
					"resultCode" => 5019, "resultMsg" => "domain transfer in fail", "data" => array("msg" => $return));
		}
		catch(\Exception $e)
		{
			\core\Log::write("shimingtransfer," . $e->getMessage() . "," . $domain . "," . $templateName, 'domain', 
				'shimingtransfer');
			return array(
					"resultCode" => "5015", "resultMsg" => "domain transfer in fail", 
					"data" => array("msg" => array("resultMsg" => $e->getMessage())));
		}
	}
	
	
	/**
	 * 临时方法
	 */
	public static function checkEUTemp($templateName)
	{
		$mod = new \models\manage\domain\TemplateMod();
		$tempInfo = $mod->getTemplate(array('TemplateName' => $templateName));
		if(!empty($tempInfo[0]))
		{
			if($tempInfo[0]['CreateTime']>='2016-08-08 08:00:00' && substr($tempInfo[0]['TemplateName'],0,3)=='em_')
			{
				$templateName = substr(md5($tempInfo[0]['TemplateName']),0,16);
			}
		}
		return $templateName;
	}
	
	public function domainEppChangeRegistrantTemp($tempData)
	{
		try 
		{ 
			$mp = new TMultiplexedProtocol($this->protocol, "domain");
			$client = new \enameepp\EppDomainClient($mp);
			$dnInfo = new \enameepp\DomainUpdateContactParams();
			$vsplogic = new \logic\manage\thrift\VspLogic();
			$dnInfo->domain = $tempData['domain'];
			$dnInfo->BusinessCode = $vsplogic->getDomainBusinessCode($tempData['domain']);
			$dnInfo->templateName = "";
			$tld = self::getDomainRegid($tempData);
			$dnInfo->tld = $tld ? $tld : strtolower(DomainFunLib::getDomainClass($tempData['domain']));
			$dnInfo->tld = strval($dnInfo->tld);
			$dnInfo->wdwp = new \enameepp\WebccDomainWhoisParams();
			$upInfo = $client->UpdateContact($dnInfo);
			$return = json_decode($upInfo, true);
			$this->transport->close();
			if(! empty($return["resultCode"]))
			{
				if($return["resultCode"] == 1000)
				{
					return array("resultCode" => 5000, 'data' => $return);
				}
				\core\Log::write("shimingupcontantc," . json_encode($dnInfo).','.json_encode($upInfo), 'domain','shimingzhi_upcontact_three');
				return array("resultCode" => "5004", "data" => array("msg" => $return));
			}
			return array(
					"resultCode" => "5004", "data" => array("msg" => array("resultCode" => 1003, "resultMsg" => "系统错误")));
		}
		catch(\Exception $e)
		{
			\core\Log::write("shimingupcontantc," . $e->getMessage() . "," . json_encode($tempData), 'domain',
				'shimingzhi_upcontact');
			return array(
					"resultCode" => "5004",
					"data" => array("msg" => array("resultCode" => 1003, "resultMsg" => $e->getMessage())));
		}
	}
}
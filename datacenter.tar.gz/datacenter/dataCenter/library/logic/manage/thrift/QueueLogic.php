<?php
namespace logic\manage\thrift;
use Thrift\Exception\TException;
use Thrift\Transport\TSocket;
use Thrift\Factory\TTransportFactory;
use Thrift\Factory\TBinaryProtocolFactory;
use Thrift\Protocol\TMultiplexedProtocol;
use core\RpcResponse;
use lib\manage\common\DomainFunLib;

class QueueLogic
{

	private $conf;

	private $client;

	private $protocol;

	private $transport;

	private $socket;

	public function __construct()
	{
		include_once APP_PATH . '/dataCenter/library/lib/manage/thrift/common.php';
		\common\thrift\ThriftStar::startup("enamequeue");
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/queue.ini', "gonormalqueue");
		$this->socket = new TSocket($this->conf->serverHost, $this->conf->serverPort);
		$this->socket->setRecvTimeout($this->conf->timeout);
		$this->socket->setRecvTimeout($this->conf->timeout);
		$transportFactory = new TTransportFactory();
		$protocolFactory = new TBinaryProtocolFactory();
		$this->transport = $transportFactory->getTransport($this->socket);
		$this->protocol = $protocolFactory->getProtocol($this->transport);
	}

	public function addQueueNormal($data)
	{
		if(empty($data['Function']))
		{
			$data['Function'] = 'sendmail';
		}
		if(empty($data['Target']))
		{
			$memberLib = new \lib\manage\member\MemberLib();
			$memberInfo = $memberLib->getMemberInfoByEnameId($data['EnameId']);
			if(! $memberInfo)
			{
				throw new \Exception('用户不存在', 900001);
			}
			if($data['Function'] == 'sendmail')
			{
				$data['Target'] = $memberInfo['Email'];
			}
			else if($data['Function'] == 'send_sms')
			{
				$data['Target'] = $memberInfo['Mobile'];
			}
		}
		$data['Target'] = trim($data['Target']);
		if(empty($data['Target']) || ($data['Function'] == 'sendmail' && ! DomainFunLib::isEmail($data['Target'])))
		{
			throw new \Exception('目标不存在', 900001);
		}
		$templib = new \lib\manage\newqueue\QueueTemplateLib();
		if(! $templateInfo = $templib->getInfoByTemplateName($data['TemplateName']))
		{
			throw new \Exception('the template does not define', 900003);
		}
		try
		{
			$this->transport->open();
			$mp = new TMultiplexedProtocol($this->protocol, "Queue");
			$client = new \enamequeue\QueueNormalClient($mp);
			$queueParams = new \enamequeue\QueueNormalParam();
			$queueParams->EnameId = intval($data['EnameId']);
			$queueParams->Function = strval($data['Function']);
			$queueParams->Priority = !empty($data['Priority']) ? intval($data['Priority']) : 1;
			$queueParams->Target = strval(trim($data['Target']));
			$queueParams->TemplateName = strval($data['TemplateName']);
			if(!empty($data['Data']))
			{
				$data['Data'] = is_object($data['Data']) ? (array)$data['Data'] : (is_string($data['Data']) ? json_decode($data['Data'],true) : $data['Data']);
				array_walk($data['Data'], function (&$item) {$item = strval($item);});
			}
			else
			{
				$data['Data'] = array("SpecialEnameId"=>"");
			}
			if($queueParams->Function == 'sendmail' && ! isset($data['Data']['enameId']))
			{
				$data['Data']['enameId'] = strval($data['EnameId']);
			}
			$queueParams->DataMap = $data['Data'];
			if($queueParams->TemplateName =="reply_remind")
			{
				error_log(json_encode($queueParams)."\r\n",3,"/tmp/jiaoyitemp");
			}
			$return = $client->AddNormalQueue($queueParams);
			$this->transport->close();
			if(isset($return->Code) && $return->Code == 1000) 
			{
				return $return->Id;
			}
			\core\Log::write(json_encode($data).",goreturn:".json_encode($return), 'queuego', 'bak_' . $data['Function']); // 先临时记录一段时间 没问题了在去掉
			throw new \Exception('add queue failed', 900002);
		}
		catch(\Exception $e)
		{
			$this->transport->close();
			\core\Log::write(json_encode($data) . "," . $e->getMessage(), 'queuego', 'bak_'.$data['Function']);
			throw new \Exception('add queue failed', 900002);
		}
	}

	private function getParams($data)
	{
		if(! in_array($data['Function'], array('template_push', 'modify_domain_dns','privacy_template_push')))
		{
			return FALSE;
		}
		$enameId = intval($data['EnameId']);
		$function = strval($data['Function']);
		$hidden = ! empty($data['Hidden']) ? 1 : 0;
		$priority = isset($data['Priority']) ? intval($data['Priority']) : 1;
		if($function == 'template_push')
		{
			$params = new \enamequeue\TemplatePushParam();
			$params->EnameId = $enameId; 
			$params->Function = $function;
			$params->Hidden = $hidden;
			$params->Priority = $priority;
			$pushDataAll = array();
			foreach($data['Data'] as $info)
			{
				array_walk($info, function (&$item) {$item = strval($item);});
				$pushDatas = new \enamequeue\TemplatePushData();
				$pushDatas->Domain = $info['domain'];
				$pushDatas->NewTemplateName = $info['newTemplateName'];
				$pushDatas->OldTemplateId = empty($info['oldTemplateId']) ? 0 : $info['oldTemplateId'];
				$pushDatas->RegistrarId = $info['registrarId'];
				$pushDatas->OldTemplateName = empty($info['oldTemplateName']) ? '' : $info['oldTemplateName'];
				$pushDatas->TemplateId = $info['templateId'];
				$pushDatas->TempType = $info['tempType'];
				$pushDataAll[] = $pushDatas;
			}
			$params->TemplatePushDatas = $pushDataAll;
			return $params;
		}
		if($function == "modify_domain_dns")
		{
			$params = new \enamequeue\DnsParam();
			$params->EnameId = $enameId;
			$params->Function = $function;
			$params->Hidden = $hidden;
			$params->Priority = $priority;
			$dnsDatas = array();
			foreach($data['Data'] as $info)
			{
				$dns = new \enamequeue\DnsData();
				$dns->DNS = $info['DNS'];
				$dns->DnsType = strval($info['dnsType']);
				$dns->Domain = strval($info['domain']);
				$dns->DomainId = strval($info['domainId']);
				$dns->RegistrarId = strval($info['registrarId']);
				$dnsDatas[] = $dns;
			}
			$params->Datas = $dnsDatas;
			return $params;
		}
		if($function == "privacy_template_push")
		{
			$params = new \enamequeue\PrivacyTemplatePushParam();
			$params->EnameId = intval($enameId);
			$params->Function = $function;
			$params->Hidden = intval($hidden);
			$params->Priority = intval($priority);
			$privacyData = array();
			foreach($data['Data'] as $info)
			{
				$privacy = new \enamequeue\PrivacyTemplatePushData();
				$privacy->Domain=strval($info['domain']);
				$privacy->IsCancel=intval($info['isCancel']);
				$privacy->IsLock=intval($info['isLock']);
				$privacy->RegistrarId = intval($info['registrarId']);
				$privacy->PrivacyTemplateId=intval($info['privacyTemplateId']);
				$privacyData[] = $privacy;
			}
			$params->PrivacyTemplatePushDatas = $privacyData;
			return $params;
		}		
		return FALSE;
	}

	public function addQueueTask($data,$isCancelPrivacy=0)
	{
		try
		{
			$params = self::getParams($data);
			if(! $params)
			{
				\core\Log::write('params error,' . json_encode($data)  , 'queuego', $data['Function']);
				throw new \Exception('add queue failed', 900002);
			}
			$this->transport->open();
			$mp = new TMultiplexedProtocol($this->protocol, "Queue");
			$client = new \enamequeue\QueueClient($mp);
			if($data['Function'] == "template_push")
			{
				$return = $client->AddTemplatePushQueue($params);
			}
			else if($data['Function'] == "modify_domain_dns")
			{
				$return = $client->AddDnsQueue($params);
			}
			else if($data['Function'] == "privacy_template_push")
			{
				$return = $client->AddPrivacyTemplatePushQueue($params);
			}
			$this->transport->close();
			if(isset($return->Code) && $return->Code == 1000)
			{
				$this->addMqDataTempPush($data);
				return $return->Id;
			}
			\core\Log::write(json_encode($params).",goreturn".json_encode($return), 'queuego', 'bak_' . $data['Function']); // 先临时记录一段时间 没问题了在去掉
			throw new \Exception('add queue failed', 900002);
		}
		catch(\Exception $e)
		{
			$this->transport->close();
			\core\Log::write(json_encode($data) . "," . $e->getMessage(), 'queuego', $data['Function']);
			throw new \Exception('add queue failed', 900002);
		}
	}
	
	private function addMqDataTempPush($data)
	{
		if(false == in_array($data['Function'],array('template_push','privacy_template_push')))
		{
			return false;
		}
		$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'template_push_success'));
		$addLocks = array();
		foreach($data['Data'] as $info)
		{
			array_push($addLocks, $info['domain']);
		}
		$islock = isset($data['IsLock']) ? $data['IsLock'] : 1;
		$isCancelPrivacy = 0;
		$isPrivacy = $data['Function'] == 'template_push' ? 0 : 1;
		if($islock == 2 && $data['Function'] == 'template_push')
		{
			$dnlogic = new \logic\manage\domain\DomainManageLogic();
			$dnlogic->addDomainLockInfo($addLocks, $data["EnameId"], "templatepush");
		}
		//普通过户跟开通隐私
		if($data['Function'] == 'template_push' || ($data['Function'] == 'privacy_template_push' && !$data['Data'][0]['isCancel']))
		{
			$from = \common\Common::getRequestUser() == 'api' ? '2' : '1';
			$amqp->sendMq(
				array('time' => time(),'isCancel'=>$isCancelPrivacy,'isPrivacy'=>$isPrivacy ,'adminId'=>0,'from'=>$from,'isLock'=>$islock ? intval($islock) : 1,'dn' => $addLocks, "uid" => intval($data["EnameId"]),'ip' => \common\Common::getRequestIp()));
		}
		return true;
	}
	
	/**
	 * 普通队列重启
	 * @param unknown $queueId
	 * @throws \Exception
	 */
	public function reRunQueueNormal($queueId)
	{
		try
		{
			if(!$queueId)
			{
				throw new \Exception('队列id错误');
			}
			$this->transport->open();
			$mp = new TMultiplexedProtocol($this->protocol, "Queue");
			$client = new \enamequeue\QueueClient($mp);
			$queueIds = is_array($queueId) ? $queueId : array($queueId);
			array_walk($queueIds, function (&$item) {$item = intval($item);});
			$return = $client->RebootAddNormalQueue($queueIds);
			$this->transport->close();
			if(isset($return->Code) && $return->Code ==1000 && !empty($return->sucArr))
			{
				return $return;
			}
			\core\Log::write('rerunerror,'.json_encode($queueId).",return:".json_encode($return), 'queuego', 'rerunnormalqueue');
			throw new \Exception('队列重启失败');
		}
		catch(\Exception $e)
		{
			\core\Log::write('rerunerror,'.json_encode($queueId).",return:".$e->getMessage(), 'queuego', 'rerunnormalqueue');
			$this->transport->close();
			throw new \Exception('队列重启失败');
		}
	}
}
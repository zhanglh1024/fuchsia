<?php
namespace logic\manage\thrift;

use Thrift\Exception\TException;
use Thrift\Transport\TSocket;
use Thrift\Factory\TTransportFactory;
use Thrift\Factory\TBinaryProtocolFactory;
use Thrift\Protocol\TMultiplexedProtocol;
class FinanceLogic
{

	private $conf;

	private $client;

	private $protocol;

	private $transport;

	private $socket;

	public function __construct()
	{
		include_once APP_PATH . '/dataCenter/library/lib/manage/thrift/common.php';
		\common\thrift\ThriftStar::startup("finance");
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', "financeRpc");
		$this->socket = new TSocket($this->conf->serverHost, $this->conf->serverPort);
		$this->socket->setRecvTimeout($this->conf->timeout);
		$this->socket->setRecvTimeout($this->conf->timeout);
		$transportFactory = new TTransportFactory();
		$protocolFactory = new TBinaryProtocolFactory();
		$this->transport = $transportFactory->getTransport($this->socket);
		$this->protocol = $protocolFactory->getProtocol($this->transport);
	}

	/**
	 * 返款列表
	 */
	public function getRepayMentList($data)
	{
		try
		{
			$return = false;
			$this->transport->open();
			$mp = new TMultiplexedProtocol($this->protocol, "creditCtl");
			$client = new \finance\CreditServerClient($mp);
			$searchParams = new \finance\GetCreditInfosParams();
			$searchParams->Uid = intval($data['Uid']);
			$searchParams->Offset = intval($data['Offset']);
			$searchParams->Limit = intval($data['Limit']);
			!empty($data['CreditType']) ? $searchParams->CreditType = intval($data['CreditType']) : $searchParams->CreditType = 0;
			!empty($data['Domain']) ? $searchParams->domain = $data['Domain'] : $searchParams->domain = '';
			!empty($data['ConsumeType']) ? $searchParams->ConsumeType = intval($data['ConsumeType']) : $searchParams->ConsumeType = 0;
			$return = \common\Common::objectToarray($client->GetFinanceCreditInfos($searchParams));
		}
		catch(Exception $e)
		{
			\core\Log::write("user," . $tx->getMessage(), 'thrift', 'getRepaymentList');
		}
		$this->transport->close();
		return $return;
	}

	/**
	 * 还款操作
	 *
	 * @param int $enameId
	 * @param int $fcId 返款ID
	 * @return boolean
	 */
	public function repayment($enameId, $fcId)
	{
		try
		{
			$return = false;
			$this->transport->open();
			$mp = new TMultiplexedProtocol($this->protocol, "creditCtl");
			$client = new \finance\CreditServerClient($mp);
			$return = \common\Common::objectToarray($client->UserCreditRepay(intval($enameId), intval($fcId)));
		}
		catch(Exception $e)
		{
			\core\Log::write("user," . $tx->getMessage(), 'thrift', 'repayment');
		}
		$this->transport->close();
		return $return;
	}

	/**
	 * 用户还款信息
	 */
	public function getCreditNotRepayInfos($enameId)
	{
		try
		{
			$res = false;
			$this->transport->open();
			$mp = new TMultiplexedProtocol($this->protocol, "creditCtl");
			$client = new \finance\CreditServerClient($mp);
			$result = $client->GetCreditNotRepayInfos(intval($enameId));
			$res['needReturnMoney'] = number_format($result->AllNeedRepay, 2); // 待还款总额
			$res['todayReturnCount'] = $result->WantExpireNum; // 今天到期
			$res['brforeReturnCount'] = $result->AlreadyExpireNum; // 已逾期
		}
		catch(\Exception $e)
		{
			\core\Log::write("user," . $tx->getMessage(), 'thrift', 'miDaiApi');
		}
		$this->transport->close();
		return $res;
	}
}
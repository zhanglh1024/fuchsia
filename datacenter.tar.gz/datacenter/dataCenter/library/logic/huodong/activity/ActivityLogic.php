<?php 
namespace logic\huodong\activity;

use \lib\manage\common\DomainFunLib;

class ActivityLogic
{
	private $activityMod;
	private $config;
	function __construct()
	{
		$configs = new \Yaf\Config\Ini(APP_PATH . '/conf/huodong.ini', 'activity');
		$this->config = $configs; 
		$this->activityMod = new \models\huodong\activity\ActivityMod();
	}
	/**
	 * 获取活动列表
	 * @param
	 */
	public function getActivityList($info)
	{
		$data = array();
		$result = array();
		$result['count'] = 0;
		$result['data'] = array();
		$result['pagenum'] = 0;
		$redis = \core\RedisLib::getInstance('common');
		$activitybeta = $redis->get('activityifnewdata');
		$result['activitybeta']= intval($activitybeta);
		$pageSize = empty($info->pagesize) ? $this->config->list->pagesize : $info->pagesize;
		$p = $info->pagenum ? intval($info->pagenum) - 1 : 0;
		$offset = $p * $pageSize;
		$limit = $offset . ',' . $pageSize;
		//调用平台 1 WEB  2 客户端  
		$data['plat'] = !empty($info->plat) ? intval($info->plat) : 2;
		//type 1 显示有效期内的 
		if(isset($info->type) && $info->type)
		{
			$data['starttime'] = date('Y-m-d') . ' 00:00:00';
			$data['endtime'] = date('Y-m-d') . ' 23:59:59';
		}
		$order = 'Sort desc,StartTime desc';
		$count = $this->activityMod->getCount($data);
		if($count)
		{
			$res = $this->activityMod->getActivityInfo($data, $limit, $order);
			foreach ($res as $key=>$val)
			{
				$val['Logo'] = $this->config->pic->imgurl . $val['Logo'];
				$val['Image'] = $this->config->pic->imgurl . $val['Image'];
				$val['ToUrl'] = $val['Link'];
				$val['Link'] = $this->config->uploginurl . '?tourl=' . urlencode($val['Link']);
				$res[$key] = $val;
			}
			$result['count'] = $count['sum'];
			$result['data'] = $res;
			$result['pagenum'] = $p + 1;
			return array('flag' => 1, 'msg' => $result);
		}
		return array('flag' => 1, 'msg' => $result);
	}

	/**
	 * .com,.net域名打包注册，.net域名优惠活动，判断所有域名中是否有满足活动要求的.net域名，有则返回
	 * @param  array $domainList 域名数组
	 * @return array 满足要求的活动域名
	 */
	public static function getActivityDomain($domainList)
	{
		if(!is_array($domainList) || !\lib\manage\common\DomainOpenLib::tmpFuncOpenCheck(FALSE, 'netActivity')) 
		{
			return FALSE;
		}
		//判断是否有前缀相同，.com和.net都存在的域名组，提取出.net域名
		//.com,.net域名打包注册.net域名优惠活动 2015-01-28
		$domainPrefix = $activityDomain = array();
		foreach ($domainList as $key => $domain) 
		{
			$domainLtd = strtolower(DomainFunLib::getDomainClass($domain));
			if(!in_array($domainLtd, array('com', 'net'))) 
			{
				continue;
			}
			$domainPrefix[] = str_replace('.' . $domainLtd, '', $domain);
		}
		//如果有重复的前缀，则.com和.net都有
		$domainPrefixUnique = array_unique($domainPrefix);
		$domainPrefixDiff = array_diff_assoc($domainPrefix, $domainPrefixUnique);
		if(!empty($domainPrefixDiff)) 
		{
			foreach ($domainPrefixDiff as $value) 
			{
				$activityDomain[] = $value . '.net';
			}
		}
		return $activityDomain;
	}

}

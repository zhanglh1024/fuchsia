<?php
namespace logic\lottery\lottery;
use core\form\ReturnData;
use core\Response;

class RecordLogic
{

	/**
	 * 获取抽奖记录
	 *
	 * @param objec $info
	 * @return multitype:number unknown Ambigous <multitype:, boolean, unknown,
	 *         multitype:multitype: >
	 */
	public function getRecordList($info)
	{
		$data = array();
		$mod = new \models\lottery\lottery\RecordMod();
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/lottery.ini', 'pageconfig');
		$data['enameid'] = intval($info->enameid);
		$data['starttime'] = $info->starttime;
		$data['endtime'] = $info->endtime;
		$data['domain'] = $info->domain;
		$data['type'] = $info->type;
		if(isset($info->pstatus) && $info->pstatus !== '')
		{
			$data['pstatus'] = $info->pstatus;
		}
		if($info->setin)
		{
			$setin = explode(',', $info->setin);
			foreach($setin as $key)
			{
				$data['setin'][] = intval($key);
			}
		}
		$count = $mod->getRecordCount($data);
		$pagesize = (isset($info->pagesize) && !empty($info->pagesize)) ? intval($info->pagesize) : $conf->list->pagesize;
		$pagenum = (isset($info->pagenum) && !empty($info->pagenum)) ? intval($info->pagenum) : 1;
		$page = $pagenum - 1;
		$offset = $page * $pagesize;
		$limit = '';
		if(!isset($data['setin']) && $pagesize != 99999999)
		{
			$limit = $offset . ',' . $pagesize;
		}
		$order = ' re_time desc';
		$codelist = $mod->getRecordList($data, $limit, $order);
		return array('flag' => 1, 'count' => $count['sum'], 'pagenum' => $pagenum, 'data' => $codelist);
	}

	/**
	 * 抽奖记录排行榜
	 */
	public function getRecordTop($info)
	{
		$mod = new \models\lottery\lottery\RecordMod();
		$awardId = $info->awardId;
		$activityType = $info->activityType;
		$limit = $info->limit;
		$params = array();
		if($awardId)
		{
			$params['aw_id'] = $awardId;
		}
		if($activityType)
		{
			$params['re_type'] = $activityType;
		}
		if($limit)
		{
			$params['limit'] = $limit;
		}
		if(!$result = $mod->getRecordTop($params))
		{
			throw new \Exception('暂无数据');
		}
		foreach($result as $key => $value)
		{
			$count = $mod->getRecordCount(array('enameid' => $value['re_enameid'], 'type' => $activityType));
			$result[$key]['count'] = $count['sum'];
		}
		return $result;
	}

	/**
	 * 更新状态
	 *
	 * @param object $info
	 * @return boolean
	 */
	public function updateRecord($info)
	{
		$reid = $info->reid;
		$mod = new \models\lottery\lottery\RecordMod();
		return $mod->upRecord($reid);
	}
}

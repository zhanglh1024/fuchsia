<?php
namespace logic\lottery\lottery;
use core\form\ReturnData;
use core\Response;

class RandCodeLogic
{

	public function CreatCode($info)
	{
		\core\Log::write("用户：" . $info->enameid . '，交易ID：' . $info->transid . '，域名：' . $info->domain . '调用接口生成随机码', 
			'lottery', 'randcode'); //
			                        // 生成随机码
		$data = array();
		$data['enameid'] = $info->enameid;
		$data['transid'] = $info->transid;
		$data['domain'] = $info->domain;
		$data['type'] = empty($info->type) ? 1 : $info->type;
		$data['bindtime'] = ! empty($info->bindtime) ? strtotime($info->bindtime) : time();
		if(! $data['enameid'] || empty($data['domain']) || ! $data['transid'])
		{
			throw new \Exception('传入参数错误!', 810001);
		}
		$data['randcode'] = \common\Random::getNumber(2);
		$data['createtime'] = time();
		$mod = new \models\lottery\lottery\RandCodeMod();
		$rs = $mod->addCode($data);
		if($rs)
		{
			$content = array('title' => "拍卖会随机码");
			$content['content'] = "尊敬的客户" . $info->enameid . ":<br>您好，您出价了拍卖会域名：【" . $info->domain . "】，获得随机码：" .
				 $data['randcode'] . '。';
			$queue = new \interfaces\manage\Queue();
			$res = $queue->sendSiteMsg($info->enameid, 'any_template_info', $content, 6);
			if(FALSE == $res)
			{
				\core\Log::write("用户：" . $info->enameid . '，交易ID：' . $info->transid . '生成随机码成功，发送站内信失败', 'lottery', 
					'randcode'); //
				return array('flag' => 0, 'msg' => '发送站内信失败');
			}
			return array('flag' => 1, 'msg' => '生成随机码成功', 'data' => $data['randcode']);
		}
		else
		{
			\core\Log::write("用户：" . $info->enameid . '，交易ID：' . $info->transid . '生成随机码失败', 'lottery', 'randcode'); //
			Response::setErrMsg('810006', '生成随机码失败');
			return array('flag' => 0, 'msg' => '生成随机码失败');
		}
	}

	public function upBindPrice($info)
	{
		\core\Log::write("结拍价格：" . $info->bindprice . '，交易ID：' . $info->transid . '调用接口更新结拍价格', 'lottery', 'randcode'); //
		$data = array();
		$data['transid'] = $info->transid;
		$data['bindprice'] = $info->bindprice;
		if(empty($data['bindprice']) || ! $data['transid'])
		{
			throw new \Exception('传入参数错误!', 810001);
		}
		$mod = new \models\lottery\lottery\RandCodeMod();
		$rs = $mod->upBindprice($data);
		if($rs)
		{
			return array('flag' => 1, 'msg' => '更新结拍价格成功');
		}
		else
		{
			Response::setErrMsg('810007', '更新结拍价格失败');
			return array('flag' => 0, 'msg' => '更新结拍价格失败');
		}
	}
	// 获取随机码列表
	public function getCodeList($info)
	{
		$data = array();
		$mod = new \models\lottery\lottery\RandCodeMod();
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/lottery.ini', 'pageconfig');
		if($info->enameid)
		{
			$data['enameid'] = intval($info->enameid);
		}
		if($info->randcode)
		{
			$data['randcode'] = $info->randcode;
		}
		if($info->bindtime)
		{
			$data['bindtime'] = $info->bindtime;
		}
		if($info->lstatus)
		{
			$data['lstatus'] = $info->lstatus;
		}
		if($info->domain)
		{
			$data['domain'] = $info->domain;
		}
		if($info->awtypeid)
		{
			$data['type'] = $info->awtypeid;
		}
		if($info->setin)
		{
			$setin = explode(',', $info->setin);
			foreach($setin as $key)
			{
				$data['setin'][] = intval($key);
			}
		}
		$count = $mod->getCodeCount($data);
		$pagesize = (isset($info->pagesize) && ! empty($info->pagesize)) ? intval($info->pagesize) : $conf->list->page;
		$pagenum = (isset($info->pagenum) && ! empty($info->pagenum)) ? intval($info->pagenum) : 1;
		$page = $pagenum - 1;
		$offset = $page * $pagesize;
		$limit = '';
		if(! isset($data['setin']) && $pagesize != 99999999)
		{
			$limit = $offset . ',' . $pagesize;
		}
		$order = ' rd_id desc';
		$codelist = $mod->getCodeList($data, $limit, $order);
		return array('flag' => 1, 'count' => $count['sum'], 'pagenum' => $pagenum, 'data' => $codelist);
	}
	// 更新创业指数
	public function upBusIn($info)
	{
		if(empty($info->busdate) || empty($info->busin))
		{
			throw new \Exception('传入参数错误!', 810001);
		}
		$folder = 'lottery/randcode/';
		$config = \Yaf\Registry::get("config");
		$path = $config->application->logPath;
		$path = $path . $folder;
		$filename = $path . 'bussine.log';
		$inlist = array();
		if(file_exists($filename))
		{
			$instr = file_get_contents($filename);
			$inlist = json_decode($instr);
		}
		if($inlist)
		{
			foreach($inlist as $key => $val)
			{
				if($val->busdate == $info->busdate)
				{
					throw new \Exception('已经设置过请不要重复设置!', '810004');
				}
			}
		}
		$inlist[] = array('busin' => $info->busin, 'busdate' => $info->busdate);
		if($path)
		{
			if(! file_exists($path))
			{
				@mkdir($path, 0777, TRUE);
			}
		}
		file_put_contents($filename, json_encode($inlist));
		return array('flag' => 1, 'msg' => '更新成功');
	}
	// 获取创业之数
	public function getBusIn($info)
	{
		$busdate = $info->busdate;
		$folder = 'lottery/randcode/';
		$config = \Yaf\Registry::get("config");
		$path = $config->application->logPath;
		$path = $path . $folder;
		$filename = $path . 'bussine.log';
		$inlist = $returndata = array();
		if(file_exists($filename))
		{
			$instr = file_get_contents($filename);
			$inlist = json_decode($instr);
		}
		if($inlist)
		{
			foreach($inlist as $key => $val)
			{
				if(! empty($busdate) && $val->busdate == $busdate)
				{
					return array('flag' => 1, 'data' => $val);
				}
			}
		}
		return array('flag' => 1, 'data' => $inlist);
	}

	public function CreatChance($info)
	{
		\core\Log::write("生成抽奖机会调用接口：enameid：" . $info->enameid . '，域名：' . $info->domain . '调用接口生成抽奖机会', 'lottery', 
			'randcode'); //
			             // 生成随机码
		$data = array();
		$data['enameid'] = $info->enameid;
		$data['domain'] = $info->domain;
		$data['type'] = empty($info->type) ? 1 : $info->type;
		$data['expiretime'] = ! empty($info->expiretime) ? strtotime($info->expiretime) : '';
		if(! $data['enameid'] || empty($data['domain']))
		{
			throw new \Exception('传入参数错误!', 810001);
		}
		$data['createtime'] = time();
		$mod = new \models\lottery\lottery\RandCodeMod();
		$rs = $mod->addChance($data);
		if($rs)
		{
			return array('flag' => 1, 'msg' => '生成中奖机会成功');
		}
		else
		{
			Response::setErrMsg('810008', '生成中奖机会失败');
			return array('flag' => 0, 'msg' => '生成中奖机会失败');
		}
	}

	public function getChance($enameid, $chstatus,$type)
	{
		if(! $enameid)
		{
			throw new \Exception('传入参数错误!', 810001);
		}
		$mod = new \models\lottery\lottery\RandCodeMod();
		$rs = $mod->getChancenum($enameid, $chstatus,$type);
		if($rs)
		{
			return array('flag' => 1, 'msg' => '获取中奖次数成功', 'data' => $rs['sum']);
		}
		else
		{
			Response::setErrMsg('810009', '获取中奖次数失败');
			return array('flag' => 0, 'msg' => '获取中奖次数失败');
		}
	}
}

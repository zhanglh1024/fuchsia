<?php
namespace logic\portal\category;
use core\Response;
use core\form\ReturnData;

class CategoryLogic
{
	private $categoryLib;

	public function __construct()
	{
		$this->categoryLib = new \lib\portal\category\CategoryLib();
	}

	public function getCategory($info)
	{
		return $this->categoryLib->getCategory($info);
	}

	public function addCategory($info)
	{
		$result = $this->categoryLib->addCategory($info);

		if(empty($result))
		{
			\core\Log::write('[添加栏目失败]' . json_encode($info), 'portal');
			throw new \Exception('添加栏目失败');
		}
		return $result;
	}

	public function editcategory($info)
	{
		$pcId = (int)$info->categoryId;
		$result = $this->categoryLib->editCategory($info,$pcId);
		if(empty($result))
		{
			\core\Log::write('[修改栏目失败]' . json_encode($info), 'portal');
			throw new \Exception('修改栏目失败');
		}
		return $result;
	}

	public function delCategory($id)
	{
		$id = (int)$id;
		$result = $this->categoryLib->delCategory($id);
		if(empty($result))
		{
			\core\Log::write('[删除栏目失败]' . json_encode($id), 'portal');
			throw new \Exception('删除栏目失败');
		}
		return $result;
	}

	public function getOneCategory($categoryId)
	{
		$categoryId = (int)$categoryId;
		return $this->categoryLib->getOneCategory($categoryId);
	}
}
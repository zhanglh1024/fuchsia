<?php
namespace logic\portal\topic;
use core\Response;
use core\form\ReturnData;

class TopicLogic
{
	private $topicLib;

	public function __construct()
	{
		$this->topicLib = new \lib\portal\topic\TopicLib();
	}

	public function getTopic($info)
	{
		return $this->topicLib->getTopic($info);
	}
	
	public function addTopic($info)
	{
		$result = $this->topicLib->addTopic($info);
		
		if(empty($result))
		{
		    \core\Log::write('[添加专题标题失败]' . json_encode($info), 'portal');
 			throw new \Exception('添加专题标题失败');
		}
		return $result;
	}
	
	public function editTopic($info)
	{
		$toId = (int)$info->topicId;
		$result = $this->topicLib->editTopic($info,$toId);
		if(empty($result))
		{
			\core\Log::write('[修改专题标题失败]' . json_encode($info), 'portal');
			throw new \Exception('修改专题标题失败');
		}
		return $result;
	}
	
	public function delTopic($id)
	{
		$id = (int)$id;
		$result = $this->topicLib->delTopic($id);
		if(empty($result))
		{
			\core\Log::write('[删除专题标题失败]' . json_encode($id), 'portal');
			throw new \Exception('删除专题标题失败');
		}
		return $result;
	}
	
	public function getOneTopic($topicId)
	{
		$topicId = (int)$topicId;
		return $this->topicLib->getOneTopic($topicId);
	}
}
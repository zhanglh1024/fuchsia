<?php
namespace logic\portal\search;

class SearchLogic
{

	private $searchLib;

	public function __construct()
	{
		$this->searchLib = new \lib\portal\search\SearchLib();
	}

	public function getSearchIndex($info)
	{
		$keyword = $this->setKeyword($info->keyword);
		if($keyword == '')
		{
			return false;
		}
		$enameId = (int)$info->enameId;
		$searchIp = $info->searchIp;
		$searchId = $this->searchLib->getSeachIndex($keyword);
		if(empty($searchId))
		{
			$searchId = $this->searchLib->addSeachIndex($keyword, $enameId, $searchIp);
		}
		return $searchId;
	}

	public function getSearchList($info)
	{
		$searchId = (int)$info->searchId;
		$pagesize = (int)$info->pagesize;
		$pagenum = (int)$info->pagenum;
		$orderBy = $info->orderBy;
		$sort = $info->sort;
		$searchIndex = $this->searchLib->getSeachIndexById($searchId);
		if(!empty($searchIndex))
		{
			$info = array();
			$count = 0;
			if(!empty($searchIndex['si_num']) && !empty($searchIndex['si_ids']))
			{
				$offset = ($pagenum - 1) * $pagesize;
				$ids = explode(',', $searchIndex['si_ids']);
				$count = count($ids);
				$ids = array_slice($ids, $offset, $pagesize);
				if(!empty($ids))
				{
					$info = $this->searchLib->getSearchList($ids, $orderBy, $sort);
				}
			}
			return array('data' => $info, 'count' => $count, 'pagenum' => $pagenum, 'keyword' => $searchIndex['si_keyword']);
		}
		return false;
	}

	private function setKeyword($keyword)
	{
		$keyword = trim($keyword);
		$keyword = htmlspecialchars($keyword, ENT_QUOTES);
		$keyword = preg_replace("/(\||\sOR\s|\sAND\s|&| )/is", " ", $keyword);
		return $keyword;
	}
}
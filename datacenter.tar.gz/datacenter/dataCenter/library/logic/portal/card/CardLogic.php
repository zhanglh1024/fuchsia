<?php
namespace logic\portal\card;
use core\Response;
use core\form\ReturnData;

class CardLogic
{
	private $cardLib;

	public function __construct()
	{
		$this->cardLib = new \lib\portal\card\CardLib();
	}

	public function getCard($info)
	{
		return $this->cardLib->getCard($info);
	}

	public function addCard($info)
	{
		$result = $this->cardLib->addCard($info);

		if(empty($result))
		{
			\core\Log::write('[添加名片失败]' . json_encode($info), 'portal');
			throw new \Exception('添加名片失败');
		}
		return $result;
	}

	public function editcard($info)
	{
		$pcId = (int)$info->cardId;
		$result = $this->cardLib->editCard($info,$pcId);
		if(empty($result))
		{
			\core\Log::write('[修改名片失败]' . json_encode($info), 'portal');
			throw new \Exception('修改名片失败');
		}
		return $result;
	}

	public function delCard($id)
	{
		$id = (int)$id;
		$result = $this->cardLib->delCard($id);
		if(empty($result))
		{
			\core\Log::write('[删除名片失败]' . json_encode($id), 'portal');
			throw new \Exception('删除名片失败');
		}
		return $result;
	}

	public function getOneCard($cardId)
	{
		$cardId = (int)$cardId;
		return $this->cardLib->getOneCard($cardId);
	}
}
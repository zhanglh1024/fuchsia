<?php
namespace logic\portal\announce;
use core\Response;
use core\form\ReturnData;

class AnnounceLogic
{
	private $announceLib;

	public function __construct()
	{
		$this->announceLib = new \lib\portal\announce\AnnounceLib();
	}

	public function getAnnouncelist($info)
	{
		return $this->announceLib->getAnnouncelist($info);
	}
	
	public function addAnnounce($info)
	{
		$result = $this->announceLib->addAnnounce($info);
		
		if(empty($result))
		{
		    \core\Log::write('[添加公告标题失败]' . json_encode($info), 'portal');
 			throw new \Exception('添加公告标题失败');
		}
		return $result;
	}
	
	public function editAnnounce($info)
	{
		$result = $this->announceLib->editAnnounce($info);
		
		if(empty($result))
		{
			\core\Log::write('[修改公告标题失败]' . json_encode($info), 'portal');
			throw new \Exception('修改公告标题失败');
		}
		return $result;
	}
	
	public function delAnnounce($announceId)
	{
		$announceId = (int)$announceId;
		$result = $this->announceLib->delAnnounce($announceId);
		if(empty($result))
		{
			\core\Log::write('[删除公告标题失败]' . json_encode($announceId), 'portal');
			throw new \Exception('删除公告标题失败');
		}
		return $result;
	}
	
	public function getOneAnnounce($announceId)
	{
		$announceId = (int)$announceId;
		return $this->announceLib->getOneAnnounce($announceId);
	}
}
<?php
namespace logic\portal\index;

class IndexLogic
{
	private $indexLib;
	
	public function __construct()
	{
		$this->indexLib = new \lib\portal\index\IndexLib();
	}
	
	public function index()
	{
		return $this->indexLib->index();
	}
}
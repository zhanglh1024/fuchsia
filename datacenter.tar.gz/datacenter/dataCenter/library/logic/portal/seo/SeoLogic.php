<?php
namespace logic\portal\seo;
use core\Response;
use core\form\ReturnData;

class SeoLogic
{
	private $seoLib;

	public function __construct()
	{
		$this->seoLib = new \lib\portal\seo\SeoLib();
	}

	public function getSeo()
	{
		return $this->seoLib->getSeo();
	}
	
	public function editSeo($info)
	{
		$seId = (int)$info->seId;
		$result = $this->seoLib->editSeo($info,$seId);
		if(empty($result))
		{
			\core\Log::write('[修改seo失败]' . json_encode($info), 'portal');
			throw new \Exception('修改seo失败');
		}
		return $result;
	}
	
	public function getOneSeo($info)
	{
		return $this->seoLib->getOneSeo($info);
	}
}
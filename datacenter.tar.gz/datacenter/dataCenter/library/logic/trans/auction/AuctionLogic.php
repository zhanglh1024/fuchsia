<?php
namespace logic\trans\auction;

use core\Response;
use core\form\ReturnData;
use models\trans\CnSaveDomainMod;
class AuctionLogic
{

	private $conf;

	private $lib; 

	public function __construct()
	{
		// 加载配置
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
		$this->lib = new \lib\trans\auction\AuctionLib();
	}

	/**
	 * 易拍易卖/易拍易卖
	 */
	public function transTopic($data)
	{
		// 加载配置
		$transTopicConf = $this->conf->fabu_transtopic->toArray();
		$transStatusConf = $this->conf->trans_status->toArray();
		// 获取参数
		$tid = $data->tid? $data->tid :0;
		$day = $data->day? $data->day :'';
		$flag = $data->flag? $data->flag :0;
		$transTopic = 0;
		$type = '';
		if($flag == 1)
		{
			$transTopic = $transTopicConf['topicshow'][0];
		}
		else
		{
			$transTopic = $transTopicConf['ebuy'][0];
		}
		if(!$tid)
		{
			$maxNum = 4;
		}
		else
		{
			$maxNum = 0; // 不限制个数
		}
		$domainTopicMod = new \models\trans\DomainTopicMod();
		$list = $domainTopicMod->getVaildTopic($transTopic, $tid);
		if($list === false)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'),610000);
		}
		$domainAuctionMod = new \models\trans\DomainAuctionMod();
		$pLib = new \lib\trans\common\PublicLib();
		$topicList = array();
		if($list)
		{
			if($flag == 1)
			{
				$topicList = $this->lib->getTopicDomainList($list, $day, $maxNum);
			}
			else
			{
				$topicList = $this->lib->getEbuyDomainList($list, $day, $maxNum);
			}
		}
		return array('list' => $topicList);
	}

	public function transType($data)
	{
		// 加载配置
		$transTypeConf = $this->conf->trans_type->toArray();
		$transStatusConf = $this->conf->trans_status->toArray();
		$tldConf = $this->conf->ts_domaintld->toArray();
		$tsDomaintld = $this->conf->ts_domaintld->toArray();
		$tsRegistrar = $this->conf->ts_registrar->toArray();
		$tsFinishTime = $this->conf->ts_finishtime->toArray();
		
		// 获取参数
		$getDomainSLD = $data->domainsld; // 关键字
		$sldtypestart = $data->sldtypestart; // 关键字
		$sldtypeend = $data->sldtypeend; // 关键字
		$getSldType = $this->lib->getWordPosition($sldtypestart, $sldtypeend); // 关键字位置
		$skipword1 = $data->skipword1; // 排除
		$skipstart1 = $data->skipstart1; // 排除位置
		$skipend1 = $data->skipend1; // 排除位置
		$skipword2 = $data->skipword2; // 排除
		$skipstart2 = $data->skipstart2; // 排除位置
		$skipend2 = $data->skipend2; // 排除位置
		$skipPos1 = $this->lib->getWordPosition($skipstart1, $skipend1); // 关键字位置
		$skipPos2 = $this->lib->getWordPosition($skipstart2, $skipend2); // 关键字位置
		$transType = $data->transtype; // 交易类型
		$getDomainTLD = $data->domaintld? explode(',', $data->domaintld) :array(); // 后缀
		$getDomainGroup = $data->domaingroup; // 分类
		$getBidPriceStart = $data->bidpricestart; // 价格
		$getBidPriceEnd = $data->bidpriceend;
		$getDomainLenStart = $data->domainlenstart; // 长度
		$getDomainLenEnd = $data->domainlenend;
		$getRegistrar = $data->registrar; // 注册商
		$getSort = $data->sort; // 排序
		$getFinishTime = $data->finishtime; // 结束时间
		$getHideNoBider = $data->hidenobider; // 竞价有人出价
		$getBidStartOne = $data->bidstartone; // 竞价1元起拍
		$getDomainSLD = preg_replace('/(http[s]?:\/\/)/', '', $getDomainSLD);
		$getDomainSLD = preg_replace('/。/', '.', $getDomainSLD);
		$getDomainSLD = str_replace(array(",","，"), ",", $getDomainSLD);
		if(strpos($getDomainSLD, ',') !== FALSE && strpos($getDomainSLD, '.') !== FALSE)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610029'),610029);
		}
		
		$TransTypeArray = array();
		foreach($transTypeConf as $k => $v)
		{
			$TransTypeArray[] = $v[0];
		}
		$TransTypeArray = implode(',', $TransTypeArray); // 竞价，保留竞价，一口价
		
		$pLib = new \lib\trans\common\PublicLib();
		$domainTLD = array();
		$getDomainTLD = is_array($getDomainTLD)? array_filter($getDomainTLD) :'';
		if($getDomainTLD)
		{
			foreach($getDomainTLD as $tld)
			{
				$domainTLD[] = $tld? $tsDomaintld[$tld][1] :'';
			}
		}
		foreach($tldConf as $k => $v)
		{
			$formTldConf[$v[1]] = $k;
			$searchTldConf[$v[0]] = $v[1];
		}
		$domain = $pLib->getDomainSearch($getDomainSLD, $domainTLD, $searchTldConf, $formTldConf, TRUE);
		
		$pDomainLib = new \lib\trans\common\PublicDomainLib();
		$sysGroup = $pDomainLib->getSysGroup($getDomainGroup);
		$sysGroupOne = $sysGroup['sysGroupOne'];
		$sysGroupTwo = $sysGroup['sysGroupTwo'];
		$domainLen = $sysGroup['domainLen'];
		$domainLen = empty($domainLen)? $pLib->getSearchDataRange($getDomainLenStart, $getDomainLenEnd, TRUE) :$domainLen;
		
		$bidPrice = $pLib->getSearchDataRange($getBidPriceStart, $getBidPriceEnd);
		
		if($getFinishTime)
		{
			$temp = $tsFinishTime[$getFinishTime][1];
			$finishTime = date("Y-m-d H:i:s", strtotime(date("Y-m-d H:i:s")) + $temp);
		}
		else
		{
			$finishTime = '';
		}
		$registrar = $getRegistrar? $tsRegistrar[$getRegistrar][1] :'';
		
		$bidStartOne = 0;
		
		// 如果勾选了 "竞价1元起拍"
		if(isset($getBidStartOne) && strval($getBidStartOne) == "1")
		{
			// 选择竞价
			$transType = $transTypeConf['auction'][0];
			// 设置起拍价
			$bidStartOne = 1;
		}
		elseif($transType == $transTypeConf['buynow'][0])
		{
			$bidStartOne = 0;
		}
		if($getHideNoBider == 1 && empty($transType))
		{
			$transType = $transTypeConf['auction'][0];
		}
		else
		{
			$getHideNoBider = 0;
		}
		// /////////竞价，保留竞价，一口价///////////////
		$condition = array();
		$condition['TransTypeArray'] = !empty($TransTypeArray)? $TransTypeArray :array();
		$condition['domain'] = $domain? $domain :'';
		$condition['getSldType'] = $getSldType? $getSldType :'';
		$condition['sysGroupOne'] = $sysGroupOne? $sysGroupOne :'';
		$condition['sysGroupTwo'] = $sysGroupTwo? $sysGroupTwo :'';
		$condition['domainLen'] = $domainLen? $domainLen :'';
		$condition['bidPrice'] = $bidPrice? $bidPrice :'';
		$condition['finishTime'] = $finishTime? $finishTime :'';
		$condition['registrar'] = $registrar? $registrar :'';
		$condition['transType'] = $transType? $transType :'';
		$condition['getHideNoBider'] = $getHideNoBider? $getHideNoBider :'';
		$condition['getSort'] = $getSort? $getSort :'';
		$condition['getBidPriceEnd'] = $getBidPriceEnd? $getBidPriceEnd :'';
		$condition['bidStartOne'] = $bidStartOne? $bidStartOne :'';
		$skip['skipword1'] = ($skipword1 || is_int($skipword1))? $skipword1 :'';
		$skip['skipword2'] = ($skipword2 || is_int($skipword2))? $skipword2 :'';
		$skip['skipPos1'] = $skipPos1;
		$skip['skipPos2'] = $skipPos2;
		$condition['skip'] = $skip;
		
		$condition['num'] = $data->num? (($data->num > $this->conf->default_maxnum)? $this->conf->default_maxnum :$data->num) :$this->conf->default_getnum;
		$p = $data->p? $data->p :1;
		$condition['page'] = ($p - 1) * $condition['num'];
		$list = array();
		if($transType && is_numeric($transType))
		{
			// 具体交易类型列表
			if($transType == $transTypeConf['inquiry'][0])
			{
				$list[0]['TypeId'] = $transTypeConf['inquiry'][0];
				$list[0]['TypeName'] = $transTypeConf['inquiry'][1];
				$rs = $this->lib->getInquirySearchSql($condition);
				$list[0]['DomainList'] = $rs['list'];
				$list[0]['Count'] = $rs['count'];
			}
			elseif($transType == $transTypeConf['auction'][0] || $transType == $transTypeConf['buynow'][0])
			{
				if($transType == $transTypeConf['auction'][0])
				{
					$list[0]['TypeId'] = $transTypeConf['auction'][0];
					$list[0]['TypeName'] = $transTypeConf['auction'][1];
				}
				elseif($transType == $transTypeConf['buynow'][0])
				{
					$list[0]['TypeId'] = $transTypeConf['buynow'][0];
					$list[0]['TypeName'] = $transTypeConf['buynow'][1];
				}
				$rs = $this->lib->getSearchTransByType($transType, $condition);
				$list[0]['DomainList'] = $rs['list'];
				$list[0]['Count'] = $rs['count'];
			}
		}
		else
		{
			// 多选交易类型搜索时
			if($transType)
			{
				$sTransType = explode(',', $transType);
			}
			else
			{
				$sTransType = array($transTypeConf['auction'][0],$transTypeConf['buynow'][0],
					$transTypeConf['inquiry'][0]);
			}
			// 所有交易类型列表
			$i = 0;
			foreach($transTypeConf as $k => $v)
			{
				// 竞价/一口价
				if($v[0] == $transTypeConf['auction'][0] || $v[0] == $transTypeConf['buynow'][0])
				{
					$domainList = in_array($v[0], $sTransType)? $this->lib->getSearchTransByType($v[0], $condition) :array();
					$list[$i]['TypeId'] = $v[0];
					$list[$i]['TypeName'] = $v[1];
					$list[$i]['DomainList'] = isset($domainList['list'])? $domainList['list'] :array();
					$list[$i]['Count'] = isset($domainList['count'])? $domainList['count'] :0;
					$i ++;
				}
				// 询价
				if($v[0] == $transTypeConf['inquiry'][0])
				{
					$domainList = in_array($v[0], $sTransType)? $this->lib->getInquirySearchSql($condition) :array();
					$list[$i]['TypeId'] = $transTypeConf['inquiry'][0];
					$list[$i]['TypeName'] = $transTypeConf['inquiry'][1];
					$list[$i]['DomainList'] = isset($domainList['list'])? $domainList['list'] :array();
					$list[$i]['Count'] = isset($domainList['count'])? $domainList['count'] :0;
					$i ++;
				}
			}
		}
		return array('list' => $list,'p' => $p);
	}

	/**
	 * 获取出价保证金和加价幅度
	 *
	 * @param unknown $data        	
	 * @return multitype:unknown
	 */
	public function getConf($data)
	{
		// 获取参数
		$flag = $data->flag? $data->flag :0;
		$transtype = $data->transtype? $data->transtype :0;
		
		$data = array();
		// 加载配置
		if($flag)
		{
			$data = $this->conf->rate_increase->toArray();
		}
		else
		{
			if($transtype == 3)
			{
				$data = $this->conf->book_bond_auction->toArray();
			}
			else
			{
				$data = $this->conf->bond_auction->toArray();
			}
		}
		if(empty($data))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610030'),610030);
		}
		return $data;
	}

	/**
	 * 竞价/一口价/认购域名详情
	 *
	 * @param array $data        	
	 * @throws \Exception
	 * @return multitype:Ambigous <\lib\trans\auction\multitype:string, multitype:string Ambigous <string, number> int array NULL unknown number Ambigous <number, unknown> Ambigous <boolean, mixed> Ambigous <boolean, string> >
	 */
	public function domain($data)
	{
		// 加载配置
		$transTypeConf = $this->conf->trans_type->toArray();
		// 获取参数
		$enameId = $data->enameid;
		$auditListId = $data->id;
		$isAjax = $data->isajax;
		$TDAsdk = new \models\trans\DomainAuctionMod();
		$rs = $TDAsdk->getByAuditListId($auditListId);
		
		if($rs === false)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'),610000);
		}
		// 判断是否存在此交易
		if(!$rs)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610031'),610031);
		}
		// 判断是否对外显示
		if(!empty($rs['RestrictGrade']))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610031'),610031);
		}
		$info = $this->lib->getTransData($enameId, $rs, $isAjax);
		if($rs['TransType'] == $transTypeConf['buynow'][0] || $rs['TransType'] == $transTypeConf['rengou'][0])
		{
			unset($info['nickName']);
			unset($info['bidPrice']);
			unset($info['bidCount']);
		}
		$praiseMod = new \models\trans\PraiseMod();
		$cnsaveMod = new \models\trans\CnSaveDomainMod();
		$saveDomainInfo =   $cnsaveMod->getCnDomain($auditListId);
		$info['praiseCount'] = 0;
		if($saveDomainInfo)
		{
			//拍卖会的域名
			$info['praiseCount'] = intval($saveDomainInfo['PraiseCount']);
		}
		else
		{
			//非拍卖会的域名
			$count =  $praiseMod->getPraiseCount($auditListId);
			$info['praiseCount'] = $count ? $count : 0;
		}
		$info['isPraise'] = false;
		if($enameId)
		{
			$info['isPraise'] = $praiseMod->getPraiseCount($auditListId,$enameId) ? true : false;
		}
		return array('info' => $info);
	}

	public function inquiry($data)
	{
		// 获取参数
		$enameId = $data->enameid;
		$inquiryId = $data->id;
		
		$inquiryStatusConfig = $this->conf->inquiry_status->toArray();
		$inquiryOnsaleStatus = $inquiryStatusConfig['onsale'][0];
		$inquiryEndsaleStatus = $inquiryStatusConfig['endsale'][0];
		
		$inquiryRegConifg = $this->conf->fabu_reg->toArray();
		$inquiryInfo = $this->lib->inquiryDomainSql($inquiryId, $inquiryOnsaleStatus);
		if($inquiryInfo)
		{
			$inquiryCycleStart = date('Y-m-d H:i', strtotime($inquiryInfo['CreateDate']));
			$inquiryCycleEnd = date('Y-m-d H:i', strtotime($inquiryInfo['FinishDate']));
			if($inquiryInfo['IsDomainInEname'] == $inquiryRegConifg['inename'][0])
			{
				$reg = $inquiryRegConifg['inename'][1];
			}
			else
			{
				$reg = $inquiryRegConifg['notinename'][1];
			}
			
			/*
			$isfinish = strtotime($inquiryInfo['FinishDate']) - time() > 0? False :True;
			if($isfinish)
			{
				$this->lib->inquiryCanelSql($inquiryInfo['Seller'], $inquiryId, $inquiryOnsaleStatus, 
					$inquiryEndsaleStatus); // 设置为过期
			} */
			$isfinish = False;
			
			$isseller = ($inquiryInfo['Seller'] == $enameId)? True :False;
			if($enameId)
			{
				$userNickName = $this->lib->createUserNickName($inquiryInfo['InquiryId'], $enameId);
			}
			else
			{
				$userNickName = '';
			}
			
			$tips = '';
			/*
			if($isfinish)
			{
				$tips = '交易已经结束';
			} */
			if($isseller)
			{
				$tips = '该域名是您所有，不能出价';
			}
			$data = array('id' => $inquiryId,'domainName' => \lib\trans\common\PublicDomainLib::replaceL($inquiryInfo['DomainName']),
				'simpleDesc' => $inquiryInfo['SimpleDec'],'reg' => $reg,'seller' => $inquiryInfo['Seller'],
				'bidCount' => $inquiryInfo['BidCount'],'inquiryCycleStart' => $inquiryCycleStart,
				'inquiryCycleEnd' => $inquiryCycleEnd,'userNickName' => $userNickName,'enameId' => $enameId,
				'tips' => $tips,'isFinish' => $isfinish);
			
			return array('info' => $data);
		}
		else
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610032'),610032);
		}
	}

	/**
	 * 竞价记录
	 *
	 * @param array $data        	
	 * @throws \Exception
	 * @return multitype:number Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getBidRecords($data)
	{
		// 加载配置
		$cnnicUser = $this->conf->cnnicUser;
		$transTopicConf = $this->conf->trans_transtopic->toArray();
		$transDisplayStatus = $this->conf->trans_display_status->toArray();
		// 获取参数
		$enameId = $data->enameid;
		$auditListId = $data->id;
		$pageSize = $data->num? (($data->num > $this->conf->default_maxnum)? $this->conf->default_maxnum :$data->num) :$this->conf->default_getnum;
		$p = $data->p? $data->p :1;
		$offset = ($p - 1) * $pageSize;
		
		$TDAsdk = new \models\trans\DomainAuctionMod();
		$TBRsdk = new \models\trans\BidRecordMod();
		// 判断是否存在此交易
		$domainInfo = $TDAsdk->getTransAuctionInfo($auditListId);
		if(!$domainInfo)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610031'),610031);
		}
		// 判断是否对外显示
		if(!empty($domainInfo['RestrictGrade']))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610031'),610031);
		}
		
		// 判断当前用户是否参与了竞价
		$isbidRecorder = FALSE;
		if($enameId)
		{
			$isbidRecorder = $TBRsdk->checkIsBider($auditListId, $enameId)? TRUE :FALSE;
		}
		if($enameId == $domainInfo['Seller'])
		{
			$isbidRecorder = TRUE;
		}
		// CNNIC保留域名竞价，开放所有人查看出价记录
		if($domainInfo['Seller'] == $cnnicUser || $domainInfo['TransTopic'] == $transTopicConf['beach'][0])
		{
			$isbidRecorder = TRUE;
		}
		$bidRecordList = FALSE;
		$bidRecordList = array();
		if($isbidRecorder)
		{
			// 出价记录
			$bidRecordList = $TBRsdk->getBidRecord($auditListId, $offset, $pageSize);
			if($bidRecordList === false)
			{
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'),610000);
			}
			$expireFlag = FALSE;
			foreach($bidRecordList as $k => $v)
			{
				if($enameId)
				{
					$bidRecordList[$k]['NickName'] = ($v['Bider'] == $enameId)? '我的出价' :$v['NickName'];
				}
				$bidRecordList[$k]['BidDate'] = strtotime($v['BidDate']);
				$bidRecordList[$k]['BidPrice'] = intval($v['BidPrice']);
				$bidRecordList[$k]['DisplayStatus'] = $v['DisplayStatus'] == $transDisplayStatus['leader'][0]? $transDisplayStatus['leader'][1] :$transDisplayStatus['unleader'][1];
				if($v['Bider']==$enameId)
				{
					continue;
				}
				if($v['NickName'] && $v['NickName']!=$v['Bider'])
				{
					$bidRecordList[$k]['Bider'] = 'hidden';
				}
			}
		}
		else
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610033'),610033);
		}
		
		return array('list' => $bidRecordList,'p' => $p);
	}

	/**
	 * 保存自定义搜索
	 *
	 * @param array $data        	
	 * @throws \Exception
	 * @return boolean
	 */
	public function addDiySearch($data)
	{
		// 加载配置
		$transTypeConf = $this->conf->trans_transtype->toArray();
		$maxNum = $this->conf->tao_diysearch_num;
		$TDSsdk = new \models\trans\DivSearchMod();
		$name = $data->name;
		$enameId = $data->enameid;
		if(!$data->bidpricestart)
		{
			$data->bidpricestart = 1;
		}
		if(!$data->domainlenstart)
		{
			$data->domainlenstart = 1;
		}
		if(!$data->sort)
		{
			$data->sort = 1;
		}
		if($data->domaintld)
		{
			$data->domaintld = explode(',', $data->domaintld);
		}
		// 检查名字是否重复
		if($TDSsdk->checkIsExist($enameId, $name))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610034'),610034);
		}
		// 检查是否超过数量限制10个
		$num = $TDSsdk->getDiySearchCnt($enameId);
		if($num >= $maxNum)
		{
			$str = str_replace('%%', $maxNum,\common\Lang::create('transmsg')->getMsg('610037'));
			throw new \Exception($str,610037);
		}
		$data = array_diff_key((array)$data, array('name' => '','enameid' => ''));
		$condition = $data? json_encode(
			array_filter($data, function ($element)
			{
				return (is_numeric($element) || $element);
			})) :'';
		$rs = $TDSsdk->addDiySearch($enameId, $name, $condition);
		if($rs == FALSE)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610035'),610035);
		}
		return array('flag' => true,'msg' => \common\Lang::create('transmsg')->getMsg('610036'));
	}

	/**
	 * 获取自定义搜索
	 *
	 * @param Object $data        	
	 * @throws \Exception
	 * @return multitype:Ambigous <multitype:, boolean, unknown, multitype:multitype: >
	 */
	public function getDiySearch($data)
	{
		$fabuPrice = $this->conf->fabu_price->toArray();
		// 加载配置
		$transTypeConf = $this->conf->trans_transtype->toArray();
		// 获取参数
		$enameId = $data->enameid;
		$TDSsdk = new \models\trans\DivSearchMod();
		$data = $TDSsdk->getDiySearchList($enameId);
		if($data === FALSE)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'),610000);
		}
		$list = array();
		if($data)
		{
			foreach($data as $k => $v)
			{
				$cdt = array();
				if($v['param'])
				{
					$cdt = json_decode($v['param'], true);
				}
				$list[$k] = $v;
				// 将后缀解析成逗号分割的字符串形式
				if(!empty($cdt['domaintld']))
				{
					$cdt['domaintld'] = implode(',', $cdt['domaintld']);
				}
				$cdt = $cdt? array_map("strval", $cdt) :array();
				$list[$k]['param'] = $cdt;
			}
		}
		return array('list' => $list);
	}

	/**
	 * 删除自定义搜索
	 *
	 * @param Object $data        	
	 * @throws \Exception
	 */
	public function delDiySearch($data)
	{
		// 获取参数
		$enameId = $data->enameid;
		$id = $data->id;
		
		$TDSsdk = new \models\trans\DivSearchMod();
		// 检查记录是否存在
		if($TDSsdk->getDiySearchCnt($enameId, $id))
		{
			$rs = $TDSsdk->delDiySearch($id, $enameId);
			if(!$rs)
			{
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610038'),610038);
			}
			return array('flag' => true,'msg' => \common\Lang::create('transmsg')->getMsg('610052'));
		}
		else
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610039'),610039);
		}
	}
}
?>
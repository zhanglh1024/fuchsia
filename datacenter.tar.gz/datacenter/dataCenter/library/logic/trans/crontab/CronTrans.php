<?php 
namespace logic\trans\crontab;

use models\trans\BuyerRemind;
class CronTrans
{ 
	/**
	 * 整理需要发送信息的资料
	 */
	public function arrangeData()
	{
		$mod = new \models\trans\DeliveryMod();
		//设置搜索时间
		$startTime = date('Y-m-d H:i:s');
		$endTime = date('Y-m-d H:i:s',strtotime('+1 day'));
		//获取相应数据
		$data = $mod->getNeedSendSmsData($startTime, $endTime);
		if($data)
		{
			$lib = new \lib\trans\trans\TransBidPublicLib();
			$finance = new \interfaces\manage\Finance();
			$mod = new \models\trans\BuyerRemind();
			$needData = array();
			foreach($data as $item)
			{
				//计算冻结金额
				$assMoney = $lib->createAssMoney($item['TransMoney']);
				//计算余额
				$userFinance = $finance->getUserFinance($item['Buyer']);
				$balance = $userFinance['UseMoney']; // 可用余额
				//若冻结金额加余额小于成交额。短信提醒
				if($assMoney + $balance < $item['TransMoney'])
				{
					$item['BuyerDeadline'] = strtotime($item['BuyerDeadline']);
					$needData[] = $item;
				}
			}
			if($needData)
			{
				if(!$mod->insert($needData))
				{
					\core\Log::write(date('Y-m-d H:i:s') . '插入数据表失败','crontab_trans');
				}
			}
		}
	}
	
	/**
	 * 批量发送短信
	 * @return boolean
	 */
	public function sendSms()
	{
		$mod = new \models\trans\BuyerRemind();
		$data = $mod->getNoSendSms();
		if($data)
		{
			$message = new \lib\trans\trans\TransMessageLib(0,false,false,true);
			foreach($data as $item)
			{
				//发送短信
				$message->setReceiveId($item['EnameId']);
				//格式化时间
				$item['EndTime'] = date('Y-m-d H:i:s',$item['EndTime']);
				//发送短信
				$rs = $message->trans_auction_buyer_remind($item);
				if($rs)
				{
					//设置为已发送
					$mod->setIsSend($item['id']);
				}
				else
				{
					\core\Log::write("id:{$item['id']},EnameId:{$item['EnameId']},短信发送失败",'crontab_trans');
				}
			}
		}
	}
	
	/**
	 * 人工重发短信提醒
	 * @param object $data
	 * @throws \Exception
	 * @return boolean
	 */
	public function sendSmsRemind($data)
	{
		$mod = new \models\trans\BuyerRemind();
		$info = $mod->getInfo($data->id);
		if($info)
		{
			$delivery = new \models\trans\DeliveryMod();
			//获取单条信息
			$res = $delivery->getTransferInfo($info[0]['AuditListId']);
			if($res)
			{
				//交付状态为卖家确认的情况下发送短信
				if($res['DeliveryStatus'] == 4)
				{
					$message = new \lib\trans\trans\TransMessageLib($info[0]['EnameId'],false,false,true);
					//格式化时间
					$info[0]['EndTime'] = date('Y-m-d H:i:s',$info[0]['EndTime']);
					//发送短信
					$rs = $message->trans_auction_buyer_remind($info[0]);
					if($rs)
					{
						//修改状态，设置为已发送
						if(!$mod->setIsSend($info[0]['id']))
						{
							\core\Log::write("买家提醒表id{$info[0]['id']}修改状态失败",'crontab_trans');
						}
						return true;
					}
					else
					{
						\core\Log::write("id:{$data->id},EnameId:{$info[0]['EnameId']},短信发送失败",'crontab_trans');
						return false;
					}
				}
				else
				{
					//修改状态
					if(!$mod->setIsSend($info[0]['id'], 3))
					{
						\core\Log::write("买家提醒表id{$info[0]['id']}修改状态失败",'crontab_trans');
					}
				}
			}
			else
			{
				\core\Log::write("找不到AuditListId为{$info[0]['AuditListId']}的记录",'crontab_trans');
				throw new \Exception('找不到记录');
			}
		}
		else
		{
			\core\Log::write("找不到id为{$data->id}的记录",'crontab_trans');
			throw new \Exception('找不到记录');
		}
	}
}
<?php
namespace logic\trans\crontab;

class CronZc
{
	private $domainStatusConf;
	private $recordStatusConf;
	private $moneyType;
	private $financeConf;
	/**
	 * @var \models\trans\CRecordMod
	 */
	private $recordMod;
	/**
	 * @var \models\trans\CDomainsMod
	 */
	private $domainsMod;

	public function __construct()
	{
		$transConf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
		$this->domainStatusConf=$transConf->zc_domain_status->toArray();
		$this->recordStatusConf=$transConf->zc_record_status->toArray();
		$financeConf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
		$this->moneyType = $financeConf->moneyType->withdrawal; //可提现
		$this->domainsMod = new \models\trans\CDomainsMod();
		$this->recordMod = new \models\trans\CRecordMod();
		$this->financeConf = $financeConf;
	}

	/**
	 * 结束已到结束时间的众筹
	 */
	public function endZcDomains()
	{
		$nowTime = time();
		$lastId = 0;
		while ($endDomains = $this->domainsMod->getDomainsToEnd($nowTime, 50, $lastId))
		{
			foreach ($endDomains as $endDomain)
			{
				if (0 == $endDomain['Remain'])
				{
					$this->doEndSuccZcDomain($endDomain); //处理众筹成功的域名
				}
				else
				{
					$this->doEndFailZcDomain($endDomain); //处理众筹失败的域名
				}
				$lastId = $endDomain['DomainsId'];
			}
		}
		if ($endDomains === false)
		{
			\core\Log::write("获取众筹结束的域名失败", 'crontab_zc');
		}
	}

	/**
	 * 处理成功的众筹，扣款并更新状态
	 * @param array $endDomain 包含单个众筹信息的数组
	 * @return boolean
	 */
	private function doEndSuccZcDomain($endDomain)
	{
		$orderList = $this->recordMod->getOrders($endDomain['DomainsId']);
		if ($orderList === false)
		{
			\core\Log::write("获取待确认众筹订单失败,DomainsId:{$endDomain['DomainsId']},Domain:{$endDomain['Domain']}", 'crontab_zc');
			return false;
		}
		$newStatus = $this->recordStatusConf['waitdraw'][0]; //Status 2:众筹结束 扣除用户金额/等待开奖
		foreach ($orderList as $orderItem)
		{
			$financeLogic = new \interfaces\trans\Finance($orderItem['EnameId']);
			$data = $financeLogic->confirmOrder($orderItem['OrderId'], $this->moneyType, $endDomain['Seller']);
			if (!$data)
			{
				\core\Log::write("确认众筹订单失败,OrderId:{$orderItem['OrderId']},EnameId:{$orderItem['EnameId']},Domain:{$endDomain['Domain']}", 'crontab_zc');
			}
			else
			{
				//更新c_record表记录
				if (!$this->recordMod->setRecordStatusByOrderId($endDomain['DomainsId'], $orderItem['OrderId'], $newStatus))
				{
					\core\Log::write("根据OrderId设置众筹购买记录状态为$newStatus,失败,OrderId:{$orderItem['OrderId']},EnameId:{$orderItem['EnameId']},Domain:{$endDomain['Domain']}", 'crontab_zc');
				}
			}
		}
		//更新c_domains表记录
		$result = $this->domainsMod->setDomainStatus($endDomain['DomainsId'], $this->domainStatusConf['waitdraw'][0]); //设置众筹主表状态为结束等待开奖
		if (!$result)
		{
			\core\Log::write("设置众筹状态为{$this->domainStatusConf['waitdraw'][0]},失败"
					. ",DomainsId:{$endDomain['DomainsId']},Domain:{$endDomain['Domain']}", 'crontab_zc');
			return false;
		}
		return true;
	}

	/**
	 * 处理失败的众筹，退还冻结款并更新状态
	 * @param array $endDomain 包含单个众筹信息的数组
	 * @return boolean
	 */
	private function doEndFailZcDomain($endDomain)
	{
		$domainsId = $endDomain['DomainsId'];
		$domain = $endDomain['Domain'];
		$orderList = $this->recordMod->getOrders($domainsId);
		$failOrders = array(); //保存取消订单失败的OrderId
		if ($orderList === false)
		{
			\core\Log::write("获取待解冻众筹订单失败,DomainsId:$domainsId,Domain:$domain", 'crontab_zc');
			return false;
		}
		elseif (is_array($orderList) && $orderList)
		{
			foreach ($orderList as $orderItem)
			{
				$financeLogic = new \interfaces\trans\Finance($orderItem['EnameId']);
				$data = $financeLogic->canelOrder($orderItem['OrderId'], $orderItem['EnameId']);
				if (!$data)
				{
					\core\Log::write("取消众筹订单失败,OrderId:{$orderItem['OrderId']},EnameId:{$orderItem['EnameId']},Domain:$domain", 'crontab_zc');
					$failOrders[] = $orderItem['OrderId'];
				}
				else
				{
					//更新c_record表记录
					if (!$this->recordMod->setRecordStatusByOrderId($domainsId, $orderItem['OrderId'], $this->recordStatusConf['fail'][0])) //Status:3 众筹失败，退还用户金额
					{
						\core\Log::write("根据OrderId设置众筹购买记录状态为{$this->recordStatusConf['fail'][0]},失败,OrderId:{$orderItem['OrderId']},EnameId:{$orderItem['EnameId']},Domain:$domain", 'crontab_zc');
					}
				}
			}
		}
		//更新c_domains表记录
		if (!$this->domainsMod->setDomainStatus($domainsId, $this->domainStatusConf['fail'][0])) //众筹结束等待退款
		{
			\core\Log::write("设置众筹状态为{$this->domainStatusConf['fail'][0]},失败,DomainsId:$domainsId,Domain:$domain", 'crontab_zc');
			return false;
		}
		//解锁域名
		if (!$this->unlockDomain($domain))
		{
			\core\Log::write("解锁流拍的众筹域名,失败,DomainsId:$domainsId,Domain:$domain", 'crontab_zc');
		}
		return true;
	}

	/**
	 * 获取需要开奖的域名进行处理
	 */
	public function doZcLottery(){
		$today = mktime(0, 0, 0);
		$lastId = 0;
		while ($domains = $this->domainsMod->getDomainsForLottery($today, 50, $lastId))
		{
			foreach ($domains as $domain)
			{
				$this->updateZcLottery($domain);
				$lastId = $domain['DomainsId'];
			}
		}
		if ($domains === false)
		{
			\core\Log::write("获取待处理开奖的众筹域名失败", 'crontab_zc');
		}
	}

	/**
	 * 判断中奖记录，更新状态
	 * @param array $domain 包含众筹信息的数组
	 * @return boolean
	 */
	private function updateZcLottery($domain)
	{
		$winner = $this->recordMod->getWinner($domain['DomainsId'], $domain['Result']);
		if(!$winner)
		{
			\core\Log::write("判断众筹中奖用户失败，"
					. "DomainsId:{$domain['DomainsId']},Domain:{$domain['Domain']},Result:{$domain['Result']}", 'crontab_zc');
			return false;
		}
		//更新c_record表记录
		//更新中奖记录
		if (!$this->recordMod->setStatusForLottery($domain['DomainsId'], $winner['RecordId'], $this->recordStatusConf['win'][0])) //Status:4 众筹结束，中奖
		{
			\core\Log::write("设置众筹购买记录状态为{$this->recordStatusConf['win'][0]}中奖,失败,"
			. "DomainsId:{$domain['DomainsId']},WinnerId:{$winner['EnameId']},"
			. "WinnerRecordId:{$winner['RecordId']},Domain:{$domain['Domain']}", 'crontab_zc');
		}
		//更新未中奖记录
		if (!$this->recordMod->setStatusForLottery($domain['DomainsId'], $winner['RecordId'], $this->recordStatusConf['nowin'][0], false)) //Status:5 众筹结束，未中奖
		{
			\core\Log::write("设置众筹购买记录状态为{$this->recordStatusConf['nowin'][0]}未中奖,失败,"
			. "DomainsId:{$domain['DomainsId']},WinnerId:{$winner['EnameId']},"
			. "WinnerRecordId:{$winner['RecordId']},Domain:{$domain['Domain']}", 'crontab_zc');
		}
		//更新c_domains表记录
		if (!$this->domainsMod->setDomainStatus($domain['DomainsId'], $this->domainStatusConf['success'][0], $winner['EnameId']))
		{
			\core\Log::write("设置众筹状态为{$this->domainStatusConf['success'][0]},失败,DomainsId:{$domain['DomainsId']},Domain:{$domain['Domain']}", 'crontab_zc');
			return false;
		}
		//域名过户
		if(!$this->doDomainPush($domain['Domain'], $winner['EnameId']))
		{
			\core\Log::write("众筹域名过户失败,DomainsId:{$domain['DomainsId']},Domain:{$domain['Domain']},"
				. "WinnerId:{$winner['EnameId']},WinnerRecordId:{$winner['RecordId']}", 'crontab_zc');
			return false;
		}
		//通知用户
		if(!$this->notifyWinner($domain, $winner['EnameId'], $domain['Result']))
		{
			\core\Log::write("众筹中奖通知站内信发送失败,DomainsId:{$domain['DomainsId']},Domain:{$domain['Domain']},"
				. "WinnerId:{$winner['EnameId']},WinnerRecordId:{$winner['RecordId']}", 'crontab_zc');
		}
		//给卖家入款
		if(!$this->transferToSeller($domain['Seller'], $domain['Money'], $domain['Domain']))
		{
			\core\Log::write("众筹入款给卖家，失败,DomainsId:{$domain['DomainsId']},Domain:{$domain['Domain']},"
				. "Seller:{$domain['Seller']},Money:{$domain['Money']}", 'crontab_zc');
		}
		return true;
	}
	
	/**
	 * 域名转给中奖用户
	 * @param string $domain 域名
	 * @param integer $toEnameId 中奖用户EnameId
	 * @return boolean
	 */
	private function doDomainPush($domain, $toEnameId)
	{
		//查出当前归属
		$interface = new \interfaces\manage\Domains();
		$curOwner = $interface->getDomainEnameId($domain);
		if($curOwner)
		{
			//push前解锁
			if(!$this->unlockDomain($domain))
			{
				\core\Log::write("众筹过户前解锁域名失败,Domain:{$domain},TargetEnameId:$toEnameId", 'crontab_zc');
				return false;
			}
			//执行push
			if($interface->domainPush($domain, $curOwner, $toEnameId))
			{
				return true;
			}
			//过户失败重新锁定域名
			if(!$this->relockDomain($domain))
			{
				\core\Log::write("众筹过户失败，重新锁定域名失败,Domain:{$domain},TargetEnameId:$toEnameId", 'crontab_zc');
			}
		}
		return false;
	}
	
	/**
	 * 发送众筹中奖通知站内信
	 * @param array $domain 包含众筹信息的数组
	 * @param integer $winner
	 * @param integer $result 开奖号码
	 * @return boolean
	 */
	private function notifyWinner($domain, $winner, $result)
	{
		$totalAmout = $this->recordMod->getTotalAmountByEnameId($domain['DomainsId'], $winner);
		$message = new \lib\trans\trans\TransMessageLib($winner,true,false,false);
		$data = array();
		$data['Domain'] = $domain['Domain'];
		$data['winner'] = $winner;
		$data['totalAmount'] = $totalAmout;
		$data['result'] = $result;
		$rs = $message->trans_zc_winner_remind($data);
		return $rs;
	}

	/**
	 * 解锁域名
	 * @param string $domain
	 * @return boolean
	 */
	private function unlockDomain($domain)
	{
		$interface = new \interfaces\manage\Domains();
		return $interface->setDomainMyStatus($domain, 1);
	}

	/**
	 * 锁定域名
	 * @param string $domain
	 * @return boolean
	 */
	private function relockDomain($domain)
	{
		$interface = new \interfaces\manage\Domains();
		return $interface->setDomainMyStatus($domain, 2);
	}

	/**
	 * 给卖家入款
	 * @param integer $seller 卖家ID
	 * @param integer $Money 入款金额
	 * @param array $info 附加信息
	 * @return boolean
	 */
	private function transferToSeller($seller, $Money, $domain='')
	{
		$interface = new \interfaces\trans\Finance($seller);
		$data = array();
		$data['enameId'] = $seller;
		$data['price'] = $Money;
		$data['inType'] = $this->financeConf->type->domainZC;//域名众筹129
		$data['moneyType'] = $this->moneyType;//可提现
		$data['domain'] = !empty($domain) ? $domain : '';
		return $interface->userFinanceIn((object)$data);
	}

}


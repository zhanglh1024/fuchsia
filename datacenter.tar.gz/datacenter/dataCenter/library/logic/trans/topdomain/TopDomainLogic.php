<?php
namespace logic\trans\topdomain;

class TopDomainLogic
{

	private $conf;

	public function __construct()
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'topdomain');
	}

	/**
	 * 获取域名珍品级别 及 抢滩信息 
	 * $conf = new \Yaf\Config\Ini(APP_PATH.'/conf/trans.ini','topdomain');
	 *
	 * @param
	 *        	$data
	 * @return array
	 */
	public function getTopDomainLevel($domain)
	{
		$mod = new \models\trans\TopDomainMod();
		if(is_array($domain))
		{
			foreach ($domain as $k=>$v)
			{
				$info = $mod->getInfoByDomain($v);
				$beachInfo = $mod->getBeachInfoByDomain($v);
				$ret[$v] = array('level' => 0,'beach' => 0);
				if($beachInfo !== false)
				{
					$ret[$v]['beach'] = $info['Beach'];
				}
				if($info !== false)
				{
					$ret[$v]['level'] = $info['Level'];
				}
			}
		}
		else
		{
			$info = $mod->getInfoByDomain($domain);
			$beachInfo = $mod->getBeachInfoByDomain($domain);
			$ret = array('level' => 0,'beach' => 0);
			if($beachInfo !== false)
			{
				$ret['beach'] = $info['Beach'];
			}
			if($info !== false)
			{
				$ret['level'] = $info['Level'];
			}
		}
		return $ret;
	}

	/**
	 * 获取非抢滩，审核通过的珍品域名
	 *
	 * @param unknown $data        	
	 * @throws \Exception
	 * @return multitype:multitype:Ambigous <multitype:>
	 */
	public function getTopDomain($data)
	{
		// 获取配置
		$statusConf = $this->conf->status->toArray();
		$beachConf = $this->conf->beach->toArray();
		// 获取參數
		$status = isset($data->status) && ($data->status)? explode(',', $data->status) :array($statusConf['success']);
		$beach = isset($data->beach) && ($data->beach)? explode(',', $data->beach) :array($beachConf['no']);
		$mod = new \models\trans\TopDomainMod();
		// 获取非抢滩，审核通过的珍品域名
		$domainList = $mod->getTopDomain($status, $beach);
		if(false === $domainList)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'), 610000);
		}
		$list = array();
		if(is_array($domainList) && $domainList)
		{
			foreach($domainList as $k => $v)
			{
				$list[$v['DomainName']] = $v['Level'];
			}
		}
		
		return array('list' => $list);
	}

	/**
	 * 获取珍品域名数据
	 *
	 * @param unknown $info        	
	 * @throws \Exception
	 * @return multitype:multitype:Ambigous <multitype:>
	 */
	public function getTopDomainList($info)
	{
		// 获取配置
		$topdomain_cat = $this->conf->topdomain_cat->toArray()['flag'];
		$mod = new \models\trans\TopDomainMod();
		$p = empty($info->p)? 1 :$info->p;
		$num = empty($info->num)? 4 :$info->num;
		$domain = empty($info->domain)? null :$info->domain;
		$data = array();
		$data['list'] = array();
		if(empty($info->cate)) // 如果$cate为空，获取所有分类数据
		{
			$level = empty($info->level) ? '' : $info->level;
			foreach($topdomain_cat as $key => $value)
			{
				$resultData = $mod->getTopDomainList($level, $key, $p, $num, $domain);
				if(false == $resultData)
				{
					continue;
				}
				$data['list'][] = array('cid' => $key,'idCateName' => $value,'DomainList' => $resultData,
							'Count' => count($resultData),'domain'=>$domain);
			}
		}
		else // 如果$cate非空，获取该分类数据
		{
			$resultData = $mod->getTopDomainList($info->level, $info->cate, $p, $num, $domain);
			if(false == $resultData)
			{
				throw new \Exception('查询不到相关域名', 660082);
			}
			$data['list'][] = array('cid' => $info->cate,'idCateName' => $topdomain_cat[$info->cate],
						'DomainList' => $resultData,'Count' => count($resultData));
		}
		return $data;
	}

	/**
	 * 获取域名详情
	 *
	 * @param object $data
	 * @throws \Exception
	 * @return multitype:multitype:Ambigous <multitype:>
	 */
	public function getTopDomainInfo($data)
	{
		$data->domain = strtolower($data->domain);
		$mod = new \models\trans\TopDomainMod();

		//读取数据库
		$dbInfo = $mod->getInfoByDomain($data->domain);
		if($dbInfo === FALSE)
		{
			throw new \Exception('该域名不属于珍品域名');
		}
		
		$info['Registrant'] = $dbInfo['Registrant'] ? :'';
		$info['Registrar'] = $dbInfo['Registrar'] ? : '';
		$info['CreateDate'] = $dbInfo['CreateDate'] ? date('Y-m-d',$dbInfo['CreateDate']) : '';
		$info['ExpireDate'] = $dbInfo['ExpireDate'] ? date('Y-m-d',$dbInfo['ExpireDate']) : '';

		if(empty($dbInfo['CreateDate']))
		{
			//查询whois
			$whois = new \interfaces\manage\Whois();
			if(($whoisData = $whois->getWhoisHasMail($data->domain))!==false)
			{
				$info['Registrant'] = !empty($whoisData['RegistrantOrganization']) ? $whoisData['RegistrantOrganization'] : (!empty($whoisData['RegistrantName']) ? $whoisData['RegistrantName'] : '');
				$info['Registrar'] = isset($whoisData['SponsoringRegistrar']) ? $whoisData['SponsoringRegistrar'] : '';
				$info['CreateDate'] = isset($whoisData['RegistrationDate']) ? $whoisData['RegistrationDate'] : '';
				$info['ExpireDate'] = isset($whoisData['ExpirationDate']) ? $whoisData['ExpirationDate'] : '';
				//更新数据库
				$rss=$mod->updateRegInfo($dbInfo['id'], $info['Registrant'], $info['Registrar'], strtotime($info['CreateDate']), strtotime($info['ExpireDate']));
			}
		}

		$info['DomainName'] = $data->domain;
		$info['Level'] = $dbInfo['Level'];
		switch($dbInfo['Level'])
		{
			case 1:
				$info['LevelName'] = '至尊级';
				break;
			case 2:
				$info['LevelName'] = '典藏级';
				break;
			case 3:
				$info['LevelName'] = '荣耀级';
				break;
		}
		$info['ShortDes'] = $dbInfo['ShortDes'];
		return $info;
	}
}

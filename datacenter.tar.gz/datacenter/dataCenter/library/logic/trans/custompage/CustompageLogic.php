<?php
namespace logic\trans\custompage;

class CustompageLogic
{

	/**
	 * 统计审核模版的数量
	 * 供管理平台调用
	 * 
	 * @param unknown $data        	
	 */
	public function totalAuditTemp($data)
	{
		$status = isset($data->status)? $data->status :0;
		$timeRange = isset($data->timerange)? $data->timerange :array(strtotime(date('Y-m-d')),
			strtotime(date('Y-m-d')) + 86400);
		$cDataTemplateMod = new \models\trans\CDataTemplate();
		$data = $cDataTemplateMod->totalTemplate($status, $timeRange);
		if(false === $data)
		{
			throw new \Exception(\common\Lang::create('pagemsg')->getMsg('650000'),650000);
		}
		
		return $data;
	}
}
?>
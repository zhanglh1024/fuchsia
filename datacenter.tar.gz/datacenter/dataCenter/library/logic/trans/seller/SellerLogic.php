<?php
namespace logic\trans\seller;
use core\Response;
use interfaces\trans\TransUserCaptcha;
use models\trans\TransTopDomainMod;

class SellerLogic
{

	private $conf;

	private $lib;

	private $financeConf;

	public function __construct()
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'shop');
		$this->financeConf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
		$this->lib = new \lib\trans\seller\SellerLib();
	}

	/**
	 * 正在出售域名
	 *
	 * @param unknown $data        	
	 * @throws \Exception
	 * @return multitype:number Ambigous <string, multitype:, boolean, unknown,
	 *         multitype:multitype: >
	 */
	public function onsale($data)
	{
		// 加载配置
		$transTypeConf = $this->conf->trans_type->toArray();
		$inquiryStatusConfig = $this->conf->inquiry_status->toArray();
		$inquiryStatusArray = array(
				$inquiryStatusConfig['onsale'][0]
		);
		// 获取参数
		$enameId = $data->enameid;
		$transType = $data->transtype? $data->transtype: 0;
		$pageSize = $data->num? (($data->num > $this->conf->default_maxnum)? $this->conf->default_maxnum: $data->num): $this->conf->default_getnum;
		$p = $data->p? $data->p: 1;
		$offset = ($p - 1) * $pageSize;
		$flag = $data->flag? $data->flag: 0;
		$domainName = $data->domainname? trim($data->domainname): '';
		
		$domainAuctionMod = new \models\trans\DomainAuctionMod();
		$inquiryMod = new \models\trans\InquiryMod();
		$list = array();
		$count = 0;
		if($flag)
		{
			if($transType == 6)
			{
				$count = array();
				$count['bidding'] = $domainAuctionMod->getSellerOnSaleCount($enameId, 1);
				$count['buynow'] = $domainAuctionMod->getSellerOnSaleCount($enameId, 4);
				$count['inquiry'] = $inquiryMod->getSellerOnSaleCount($enameId, $inquiryStatusArray);
				if($count === FALSE)
				{
					throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'), 610000);
				}
				return $count;
			}
			else 
				if($transType == $transTypeConf['inquiry'][0])
				{
					$count = $inquiryMod->getSellerOnSaleCount($enameId, $inquiryStatusArray);
				}
				else
				{
					$count = $domainAuctionMod->getSellerOnSaleCount($enameId, $transType);
				}
			if(false === $count)
			{
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'), 610000);
			}
		}
		else
		{
			if($transType == $transTypeConf['inquiry'][0])
			{
				$list = $inquiryMod->getSellerOnSale($enameId, $offset, $pageSize, $inquiryStatusArray, $domainName);
			}
			else
			{
				$list = $domainAuctionMod->getSellerOnSale($enameId, $offset, $pageSize, $transType, $domainName);
			}
			if($list === false)
			{
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'), 610000);
			}
			$pLib = new \lib\trans\common\PublicLib();
			$transTypes = $pLib->covertArray($transTypeConf, 1);
			foreach($list as $k => $v)
			{
				$list[$k]['LeftTime'] = $pLib->NewTimeToDHIS(strtotime($v['FinishDate']) - time());
				if($transType == $transTypeConf['inquiry'][0])
				{
					$list[$k]['TransType'] = $transTypeConf['inquiry'][1];
					$list[$k]['BidPrice'] = intval($v['InquiryPrice']);
				}
				else
				{
					$list[$k]['TransType'] = isset($transTypes[$v['TransType'] - 1])? $transTypes[$v['TransType'] - 1]: '未知';
					if($v['TransType'] == $transTypeConf['auction'][0])
					{
						$list[$k]['BidPrice'] = intval($v['BidCount']) > 0? intval($v['BidPrice']): 0;
						$list[$k]['AskingPrice'] = intval($v['AskingPrice']);
					}
					else
					{
						$list[$k]['BidPrice'] = intval($v['BidPrice']);
					}
				}
				$list[$k]['DomainName'] =  \lib\trans\common\PublicDomainLib::replaceL($v['DomainName']);
				unset($list[$k]['FinishDate']);
			}
		}
		
		return $flag? array(
				'num' => $count
		): array(
				'list' => $list,'p' => $p
		);
	}

	public function getOnsaleDetail($data)
	{
		// 加载配置
		$transStatusConf = $this->conf->trans_status->toArray();
		$transTypeConf = $this->conf->trans_type->toArray();
		$ttType = $this->conf->shop_tag_trans_type->toArray();
		$tagStatus = $this->conf->shop_tag_status->toArray();
		$inquiryOnsaleStatus = $this->conf->inquiry_status->toArray();
		
		$pLib = new \lib\trans\common\PublicLib();
		$transType = $pLib->covertArray($transTypeConf, 1);
		// 获取参数
		$enameId = $data->enameid;
		$id = $data->id;
		$flag = $data->flag;
		if($flag)
		{
			$inquiryMod = new \models\trans\InquiryMod();
			$info = $inquiryMod->getInquiryDomainInfoModel($id, $inquiryOnsaleStatus['onsale'][0]);
		}
		else
		{
			$domainAuction = new \models\trans\DomainAuctionMod();
			$info = $domainAuction->getOnsaleDomainDetail($enameId, $id, $transStatusConf['trading'][0]);
		}
		if($info === false)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'), 610000);
		}
		if($info)
		{
			if($flag)
			{
				$info['TransType'] = $transTypeConf['inquiry'][1];
				$info['BidPrice'] = $info['InquiryPrice'];
				$info['BidCount'] = $info['BidCount'];
				$info['AuditListId'] = $info['InquiryId'];
				// 交易类型为拍卖的自定义标签
				$STlib = new \lib\trans\shop\ShopTagLib();
				$userTags = $STlib->getShopTagsByUser($enameId, $ttType['inquiry'][0], $tagStatus['del'][0]);
			}
			else
			{
				$info['TransType'] = isset($transType[$info['TransType'] - 1])? $transType[$info['TransType'] - 1]: 0;
				$info['BidPrice'] = $info['Buyer']? intval($info['BidPrice']): 0;
				$info['AskingPrice'] = intval($info['AskingPrice']);
				$info['LeftTime'] = $pLib->NewTimeToDHIS(strtotime($info['FinishDate']) - time());
				$info['Leader'] = $info['NickName']? (($info['NickName'] == $info['Buyer'])? strval($info['Buyer']): 'Ename-' .
					 $info['NickName']): ($info['Buyer']? strval($info['Buyer']): "");
				// 交易类型为拍卖的自定义标签
				$STlib = new \lib\trans\shop\ShopTagLib();
				$userTags = $STlib->getShopTagsByUser($enameId, $ttType['auction'][0], $tagStatus['del'][0]);
				// 计算违约金
				$Tlib = new \lib\trans\trans\TransLib();
				$info['AbandonMoney'] = $info['Buyer']? $Tlib->createSellerAbandonMoney($info['BidPrice']): 0;
			}
			$info['DomainName'] =  \lib\trans\common\PublicDomainLib::replaceL($info['DomainName']);
			$tags = array();
			if($info['IsShopRecommend'] && $userTags)
			{
				foreach($userTags as $val)
				{
					if($val['Value'] & (int) $info['IsShopRecommend'])
					{
						$tags[] = $val['TagName'];
					}
				}
			}
			$info['Tags'] = $tags? implode(',', $tags): '';
			unset($info['Buyer']);
			unset($info['NickName']);
			unset($info['FinishDate']);
			unset($info['IsShopRecommend']);
			unset($info['SimpleDec']);
			unset($info['Seller']);
			unset($info['CreateDate']);
			unset($info['IsDomainInEname']);
			unset($info['Poundage']);
			unset($info['DomainSLD']);
			unset($info['InquiryPrice']);
			unset($info['InquiryId']);
		}
		else
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610069'), 610069);
		}
		
		return array(
				'info' => $info
		);
	}

	public function getShopTags($data)
	{
		// 加载配置
		$ttType = $this->conf->shop_tag_trans_type->toArray();
		$tagStatus = $this->conf->shop_tag_status->toArray();
		// 获取参数
		$enameId = $data->enameid;
		$num = $data->num? (($data->num > $this->conf->default_maxnum)? $this->conf->default_maxnum: $data->num): $this->conf->default_getnum;
		$tagType = $data->tagtype;
		$STlib = new \lib\trans\shop\ShopTagLib();
		
		$tagTransType = $tagType == $ttType['inquiry'][0]? $ttType['inquiry'][0]: $ttType['auction'][0];
		$userTags = $STlib->getShopTagsByUser($enameId, $tagTransType, $tagStatus['del'][0], $num);
		
		if($userTags === false)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'), 610000);
		}
		return array(
				'list' => $userTags
		);
	}

	/**
	 * 域名设置自定义标签
	 *
	 * @param unknown $data        	
	 */
	public function setShopTag($data)
	{
		// 获取参数
		$enameId = $data->enameid;
		$auditListIds = explode(',', $data->id);
		$tag = $data->tag;
		$transType = $data->transtype;
		$STlib = new \lib\trans\shop\ShopTagLib();
		
		$tagStatus = $this->conf->shop_tag_status->toArray();
		$ttType = $this->conf->shop_tag_trans_type->toArray();
		$transStatus = $this->conf->trans_status->toArray();
		$transTypeConf = $this->conf->trans_type->toArray();
		$inquiryStatus = $this->conf->inquiry_status->toArray();
		
		$tagTransType = $transType == $transTypeConf['inquiry'][0]? $ttType['inquiry'][0]: $ttType['auction'][0];
		// 检查TagValue是否存在
		$STlib->checkTagValue($enameId, $tag, $tagStatus['del'][0], $tagTransType);
		
		// 设置店铺标签
		if($transType == $transTypeConf['inquiry'][0])
		{
			$STlib->setInquiryTag($auditListIds, $tag, $enameId, $inquiryStatus['onsale'][0]);
		}
		else
		{
			// 设置店铺标签
			$STlib->setTransTag($auditListIds, $tag, $enameId, $transStatus['trading'][0]);
			// 标签为店铺推荐， 则论坛推荐域名，信息更新redis
			if(1 == $tag)
			{
				$redis = new \lib\trans\shop\ShopRedisLib();
				$redis->setShopDomainQueue(intval($enameId));
			}
		}
		
		return array(
				'flag' => true,'msg' => \common\Lang::create('transmsg')->getMsg('610071')
		);
	}

	/**
	 * 取消交易店铺标签
	 */
	public function cancelShopTag($data)
	{
		// 加载配置
		$tagStatus = $this->conf->shop_tag_status->toArray();
		$ttType = $this->conf->shop_tag_trans_type->toArray();
		$transStatus = $this->conf->trans_status->toArray();
		$transTypeConf = $this->conf->trans_type->toArray();
		$inquiryStatus = $this->conf->inquiry_status->toArray();
		// 获取参数
		$enameid = $data->enameid;
		$auditListIds = explode(',', $data->id);
		$tag = $data->tag;
		$transType = $data->transtype? $data->transtype: 0;
		
		$STlib = new \lib\trans\shop\ShopTagLib();
		
		$tagTransType = $transType == $transTypeConf['inquiry'][0]? $ttType['inquiry'][0]: $ttType['auction'][0];
		// 检查TagValue是否存在
		$STlib->checkTagValue($enameid, $tag, $tagStatus['del'][0], $tagTransType);
		
		if($transType == $transTypeConf['inquiry'][0])
		{
			// 取消店铺标签
			$STlib->cancelInquiryTag($auditListIds, $tag, $enameid, $inquiryStatus['onsale'][0]);
		}
		else
		{
			// 取消标签
			$STlib->cancelTransTag($auditListIds, $tag, $enameid, $transStatus['trading'][0]);
			
			// 标签为店铺推荐， 则论坛推荐域名，信息更新redis
			if(1 == $tag)
			{
				$redis = new \lib\trans\shop\ShopRedisLib();
				$redis->setShopDomainQueue(intval($enameid));
			}
		}
		return array(
				'flag' => true,'msg' => \common\Lang::create('transmsg')->getMsg('610050')
		);
	}

	/**
	 * 下架操作
	 */
	public function cancelTrans($data)
	{
		// 获取参数
		$auditListId = $data->id;
		$identify = $data->identify;
		$enameId = $data->enameid;
		$questionId = $data->questionid;
		$answer = $data->answer;
		$pass = $data->pass;
		$captcha = $data->captcha;
		$transType = intval($data->transtype);
		// 操作保护验证
		$UserCaptcha = new \interfaces\trans\UserCaptcha();
		$rs = $UserCaptcha->checkOperateData(
			(object) array(
					'identify' => $identify,'EnameId' => $enameId,'questionId' => $questionId,'answer' => $answer,
					'pass' => $pass,'captcha' => $captcha
			));
		$transTypeConf = $this->conf->trans_type->toArray();
		if($transType == $transTypeConf['inquiry'][0])
		{
			// 询价下架操作
			$rs = $this->lib->cancelInquiryTrans($auditListId, $enameId);
		}
		else
		{
			// 竞价/一口家下架操作
			$rs = $this->lib->cancelTrans($auditListId, $enameId);
		}
		
		return array(
				'flag' => true,'code' => $rs['code'],'msg' => $rs['msg']
		);
	}

	/**
	 * 批量下架
	 *
	 * @param Object $data        	
	 */
	public function cancelTransBatch($data)
	{
		
		// 获取参数
		$ids = $data->ids;
		$enameId = $data->enameid;
		$identify = $data->identify;
		$questionId = $data->questionid;
		$answer = $data->answer;
		$pass = $data->pass;
		$captcha = $data->captcha;
		$transType = $data->transtype;
		
		if(empty($ids))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610070'), 610070);
		}
		// 检测是否设置操作保护
		$UserCaptcha = new \interfaces\trans\UserCaptcha();
		$UserCaptcha->checkOperateData(
			(object) array(
					'identify' => $identify,'EnameId' => $enameId,'questionId' => $questionId,'answer' => $answer,
					'pass' => $pass,'captcha' => $captcha
			));
		$transTypeConf = $this->conf->trans_type->toArray();
		if($transType == $transTypeConf['inquiry'][0])
		{
			$result = $this->lib->cancelInquiryTrans($ids, $enameId);
		}
		else
		{
			// 域名未出价才能执行批量下架操作
			$result = $this->lib->doCancelTrans($ids, $enameId, TRUE);
		}
		return $result['data'];
	}

	/**
	 * 获取卖家正在交易域名列表
	 * 供管理平台调用
	 *
	 * @param unknown $data        	
	 * @throws \Exception
	 * @return Ambigous <multitype:, string, \models\trans\Ambigous, boolean,
	 *         unknown, multitype:multitype: >
	 */
	public function gotsale($data)
	{
		// 加载配置
		$transStatusConf = $this->conf->trans_status->toArray();
		$transTypeConf = $this->conf->trans_type->toArray();
		$deliveryStatusStr = implode(',', 
			array(
					$transStatusConf['checking'][0],$transStatusConf['buyerchecked'][0],
					$transStatusConf['sellerchecked'][0],$transStatusConf['allchecked'][0]
			));
		$transTypeStr = implode(',', 
			array(
					$transTypeConf['auction'][0],$transTypeConf['reserved'][0],$transTypeConf['buynow'][0],
					$transTypeConf['inquiry'][0],$transTypeConf['rengou'][0]
			));
		$defaultNum = $this->conf->default_getnum;
		// 获取参数
		$enameId = $data->enameid;
		$pageSize = isset($data->num)? $data->num: $defaultNum;
		if(! $enameId)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610068'), 610068);
		}
		$deliveryMod = new \models\trans\DeliveryMod();
		$data = $deliveryMod->getSellerDelivery('', $enameId, $deliveryStatusStr, $transTypeStr, 0, $pageSize);
		if(false === $data)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'), 610000);
		}
		elseif(! $data)
		{
			$data = array();
		}
		else
		{
			foreach($data as $k => $v)
			{
				$data[$k]['ReservePrice'] = intval($v['TransMoney']);
				$data[$k]['url'] = "http://www.ename.com/auction/domain/" . $v['AuditListId'];
				if($v['DeliveryStatus'] == $transStatusConf['sellerchecked'][0] ||
					 $v['DeliveryStatus'] == $transStatusConf['allchecked'][0])
				{
					$data[$k]['SellerDeadline'] = '我已确认';
				}
			}
		}
		return array(
				'list' => $data
		);
	}
}
?>
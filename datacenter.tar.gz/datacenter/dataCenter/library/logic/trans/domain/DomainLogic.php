<?php

namespace logic\trans\domain;

use interfaces\manage\Domains;
class DomainLogic
{
	/**
	 * 获取域名分组信息 0601
	 * @param string $domainName
	 * @return array
	 * @author zhangsc
	 */
	public function getDomainGroup($data)
	{
		$domain = new Domains;
		return $domain->getDomainGroup($data->domain);
	}
	
	/**
	 * 判断域名是否为用户所有
	 * @param unknown $data
	 * @return Ambigous <number, boolean, multitype:>
	 * @author zhangsc
	 */
	public function getDomainForUser($data)
	{
		$domain = new Domains;
		$rs = $domain->getDomainForUser($data->domain, $data->enameid);
		return $rs;
	}
	
}

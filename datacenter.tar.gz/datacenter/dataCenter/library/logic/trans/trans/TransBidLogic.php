<?php

namespace logic\trans\trans;

use core\Response;
class TransBidLogic
{

	private $conf;

	private $transBidPublicLib;

	private $enameId;

	public function __construct($enameId)
	{
		// 加载配置
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
		$this->transBidPublicLib = new \lib\trans\trans\TransBidPublicLib();
		$this->enameId = $enameId;
	}

	public function initClass($auditListId, $transType)
	{
		$transTypeConfig = $this->conf->trans_transtype->toArray();
		if($transType == $transTypeConfig['booking'][0])
		{
			$TBAsdk = new \models\trans\BookAuctionMod();
			if($TBAsdk->isDomainExist($auditListId))
				$this->transBidLib = new \lib\trans\trans\TransBidBookLib();
			else
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610072'), 610072);
		}
		else
		{
			$TDAsdk = new \models\trans\DomainAuctionMod();
			if($TDAsdk->isDomainExist($auditListId))
				$this->transBidLib = new \lib\trans\trans\TransBidAuctionLib();
			else
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610072'), 610072);
		}
	}

	public function postAucAllLogic($data)
	{
		//检查用户是否被交易冻结
		//\lib\trans\trans\TransLib::checkFrozenStatus($this->enameId);

		// 加载配置
		$transStatusConf = $this->conf->trans_status->toArray(); // 交易状态配置
		$transTopicConf = $this->conf->trans_transtopic->toArray();
		$socketConf = $this->conf->websocket->toArray();
		
		// 获取参数
		$auditListId = $data->id;
		$postPrice = $data->postprice;
		$nickName = $data->postnick;
		$transType = $data->transtype;
		$socket = $data->socket;
		
		$this->initClass($auditListId, $transType);
		$transInfo = $this->transBidLib->getTransInfoForBid($auditListId, $transStatusConf['trading'][0]);
		if(!$transInfo)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610073'), 610073);
		}
		if($transInfo['Seller'] == $this->enameId)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610074'), 610074);
		}
		$postPrice = $this->transBidPublicLib->checkPostPrice($postPrice, $auditListId, $transInfo['Seller']); // 验证是否符合出价规则
		$tempNick = $this->transBidLib->getUserNickName($auditListId, $this->enameId);
		$nickName = $this->transBidPublicLib->checkPostNick($auditListId, $this->enameId, $nickName, $tempNick); // 验证是否符合昵称规则
		$pFinanceLib = new \interfaces\trans\Finance($this->enameId);
		// 请求时间
		$rqTime = empty($_SERVER['REQUEST_TIME'])? time() :$_SERVER['REQUEST_TIME'];
		if(($rqTime - strtotime($transInfo['CreateDate'])) < 0)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610075'), 610075);
		}
		// 记录出价日志
		\core\Log::write(
			"$auditListId|" . $transInfo['DomainName'] . '|' . $this->enameId . '|' . $nickName . '|' . $postPrice, 
			'trans', 'bid');
		
		if($postPrice < ($transInfo['BidPrice']? $transInfo['BidPrice'] :$transInfo['AskingPrice']))
		{
			$str = str_replace('%%', intval($transInfo['BidPrice']), \common\Lang::create('transmsg')->getMsg('610076'));
			throw new \Exception($str, 610076);
		}
		if($transInfo['Buyer'] == 0 && $transInfo['BuyerOrderId'] == 0)
		{
			// 第一个出价
			$result = $this->firstBid($auditListId, $nickName, $postPrice, $transInfo);
			$message = $result? sprintf(\common\Lang::create('transmsg')->getMsg('610102'), 
				intval($transInfo['AskingPrice']), $postPrice) :str_replace('%%', intval($transInfo['AskingPrice']), 
			   \common\Lang::create('transmsg')->getMsg('610103'));
		}
		else
		{
			// 非第一个出价
			$addPrice = $this->transBidPublicLib->createAddPrice($transInfo['BidPrice'], $transInfo['Seller']);
			if($postPrice < $addPrice)
			{
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610077'), 610077);
			}
			
			$this->transBidLib->checkPre($this->enameId, $auditListId, $transInfo['DomainName'], $postPrice); // 闯入扣款
			if($this->enameId == $transInfo['Buyer']) // 自己领先的出价
			{
				$result = $this->leaderBid($auditListId, $nickName, $postPrice, $transInfo);
				if(!$result)
				{
					throw new \Exception(\common\Lang::create('transmsg')->getMsg('610078'), 610078);
				}
				$message = '您当前领先，新代理价为' . intval($postPrice) . '元';
			}
			else // 非自己领先的出价
			{
				$addPrice = $this->transBidPublicLib->createAddPrice($transInfo['BidPrice'], $transInfo['Seller']);
				$newBidPrice = $addPrice + $transInfo['BidPrice'];
				if($postPrice < $newBidPrice)
				{
					throw new \Exception(\common\Lang::create('transmsg')->getMsg('610077'), 610077);
				}
				$buyerOrderId = $this->transBidPublicLib->createBuyerOrderId($auditListId, $this->enameId, $postPrice, 
					$transInfo['DomainName'], $transInfo['Seller'], $transInfo['TransType']);
				$newFinishDate = $this->transBidPublicLib->newFinishDate($transInfo['FinishDate']);
				if($transInfo['AgentBidPrice'] == 0) // 无代理价
				{
					$newAgentBidPrice = ($postPrice == $newBidPrice)? 0 :$postPrice;
					$result = $this->unLeadBidWithoutAgent($auditListId, $nickName, $transInfo, $pFinanceLib, 
						$buyerOrderId, $newFinishDate, $newBidPrice, $newAgentBidPrice);
					$message = $newAgentBidPrice? '您当前领先，您的出价为' . intval($newBidPrice) . '元，代理价为' . $postPrice . '元' :'您当前领先，您的出价为' .
						 intval($newBidPrice) . '元，您当前未设置代理价';
				}
				else
				{
					$addPrice = $this->transBidPublicLib->createAddPrice($transInfo['AgentBidPrice'], 
						$transInfo['Seller']); // 代理最小加价
					$newBidPrice = $addPrice + $transInfo['AgentBidPrice'];
					if($postPrice >= $newBidPrice) // 出价大于等于代理最小加价，$this->enameId领先
					{
						$newAgentBidPrice = ($postPrice == $newBidPrice)? 0 :$postPrice;
						$result = $this->unLeadBidWithAgentWin($auditListId, $nickName, $transInfo, $pFinanceLib, 
							$buyerOrderId, $newFinishDate, $newBidPrice, $newAgentBidPrice);
						$message = $newAgentBidPrice? '您当前领先，您的出价为' . intval($newBidPrice) . '元，代理价为' . $postPrice . '元' :'您当前领先，您的出价为' .
							 intval($newBidPrice) . '元，您当前未设置代理价';
					}
					else // 出价小于代理最小加价，$old领先
					{
						if($postPrice == $transInfo['AgentBidPrice'])
						{
							$newBidPrice = $postPrice;
							$newAgentBidPrice = 0;
						}
						else
						{
							$newBidPrice = $postPrice +
								 $this->transBidPublicLib->createAddPrice($postPrice, $transInfo['Seller']);
							$newAgentBidPrice = ($newBidPrice == $transInfo['AgentBidPrice'])? 0 :$transInfo['AgentBidPrice'];
						}
						$result = $this->unLeadBidWithAgentLoss($auditListId, $nickName, $postPrice, $transInfo, 
							$pFinanceLib, $buyerOrderId, $newFinishDate, $newBidPrice, $newAgentBidPrice);
						$message = '出价成功，当前出价落后';
					}
				}
				// 加入出价表、关注表交易结束时间更新队列
				if($newFinishDate > $transInfo['FinishDate'])
				{
					$this->addDateUpdateQueue($auditListId);
				}
			}
		}
		
		// 更新交易表的BidCount值
		$this->transBidLib->updateBidCount($auditListId);
		
		// 出价成功，查看redis并更新
		$redisLib = new \lib\trans\trans\TransRedisLib();
		$redisLib->doRedisPostAucAll($auditListId, $transType);
		
		// 精品域名拍卖会
		if(isset($transInfo['TransTopic']) && $transInfo['TransTopic'] == 8 )
		{
			
			$TDAsdk = new \models\trans\BidRecordMod();
			
			// 是不是第一次出价
			if(($TDAsdk->isFirstBidByEnameid($this->enameId, $auditListId) == 1) && ($this->enameId != $transInfo['Buyer']))
			{
 				// 域名拍卖会第一次出价获取抽奖机会
				$this->addChance($transInfo);
				// 每个域名每个用户第一次出价将获得一组两位数字的不重复随机码
				$this->randomCode($transInfo, $auditListId);
				$message .= "，获得一次刮红包机会。";
			} 
		}	
		
		// 手机出价更新竞价大厅
/* 		if($socket != 1 && $transType == 1)
		{
			// 更新竞价大厅出价
			$auctionHall = new \lib\trans\trans\TransUpdateHallLib();
			$auctionHall->auctionHallUpdate($socketConf['host'], $socketConf['port'], $auditListId, $this->enameId, 3);
		} */
		
		return array('flag' => true,'msg' => $message);
	}

	/**
	 * 第一个出价
	 *
	 * @param int $auditListId        	
	 * @param string $nickName        	
	 * @param float $postPrice        	
	 * @param float $transInfo        	
	 * @throws Exception
	 * @return boolean
	 */
	private function firstBid($auditListId, $nickName, $postPrice, $transInfo)
	{
		$bidAgentPrice = ($postPrice == $transInfo['AskingPrice'])? 0 :$postPrice;
		$buyerOrderId = $this->transBidPublicLib->createBuyerOrderId($auditListId, $this->enameId, $postPrice, 
			$transInfo['DomainName'], $transInfo['Seller'], $transInfo['TransType']);
		
		if(!$this->transBidLib->auctionFirstBider($auditListId, $this->enameId, $nickName, $buyerOrderId, 
			$transInfo['AskingPrice'], $bidAgentPrice))
		{
			// 取消出价保证金
			$pFinanceLib = new \interfaces\trans\Finance($this->enameId);
			\core\Log::write("$auditListId,$this->enameId,$buyerOrderId,出价更新主表记录失败，原因可能是不同用户同时出价，取消用户出价保证金,".__METHOD__, 'trans', 
				'bid');
			if(!$pFinanceLib->canelOrder($buyerOrderId, $this->enameId))
			{
				\core\Log::write("FALSE,$auditListId,$this->enameId,$buyerOrderId,出价更新主表记录失败，原因可能是不同用户同时出价，取消用户出价保证金失败,".__METHOD__, 
					'trans', 'bid');
			}
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610079'), 610079);
		}
		if(!$this->transBidLib->CreateBidPrice($auditListId, $transInfo['DomainName'], $transInfo['TransType'], 
			$this->enameId, $transInfo['Seller'], $nickName, $transInfo['AskingPrice'], \common\Common::getRequestIp(), 
			$transInfo['FinishDate'], FALSE, TRUE)) // 写入出价表
		{
			\core\Log::write("FALSE,$auditListId,$this->enameId,出价更新出价表记录失败,".__METHOD__, 'trans', 'bid');
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610001'), 610001);
		}
		return $bidAgentPrice? true :false;
	}

	/**
	 * 领先出价
	 *
	 * @param int $auditListId        	
	 * @param string $nickName        	
	 * @param float $postPrice        	
	 * @param array $transInfo        	
	 * @throws Exception
	 * @return boolean
	 */
	private function leaderBid($auditListId, $nickName, $postPrice, $transInfo)
	{
		$buyerIP = \common\Common::getRequestIp();
		$addPrice = '';
		$addPrice = ($transInfo['AgentBidPrice'] == 0)? $this->transBidPublicLib->createAddPrice($transInfo['BidPrice'], 
			$transInfo['Seller']) :$this->transBidPublicLib->createAddPrice($transInfo['AgentBidPrice'], 
			$transInfo['Seller']);
		$agentAddPrice = ($transInfo['AgentBidPrice'] == 0)? $addPrice + $transInfo['BidPrice'] :$addPrice +
			 $transInfo['AgentBidPrice'];
		if($postPrice == $transInfo['AgentBidPrice'])
		{
			Response::success('您当前领先，新代理价为' . intval($postPrice) . '元');
		}
		if($postPrice > $transInfo['BidPrice']) // 更新代理价
		{
			$buyerOrderId = $this->transBidPublicLib->createBuyerOrderId($auditListId, $this->enameId, $postPrice, 
				$transInfo['DomainName'], $transInfo['Seller'], $transInfo['TransType'], $transInfo['BuyerOrderId']);
			if(!$this->transBidLib->leaderUpdateAgentPrice($auditListId, $this->enameId, $transInfo['AgentBidPrice'], 
				$buyerOrderId, $postPrice))
			{
				\core\Log::write("$auditListId,$this->enameId,$buyerOrderId,出价更新主表记录失败，原因可能是不同用户同时出价,".__METHOD__, 'trans', 'bid');
				// 取消出价保证金
				$pFinanceLib = new \interfaces\trans\Finance($this->enameId);
				if(!$pFinanceLib->canelOrder($buyerOrderId, $this->enameId))
					\core\Log::write(
						"FAlSE,$auditListId,$this->enameId,$buyerOrderId，出价更新主表记录失败，原因可能是不同用户同时出价，取消用户出价保证金失败,".__METHOD__, 'trans', 
						'bid');
				\core\Log::write(
					"FALSE,$auditListId,$this->enameId,$postPrice,$buyerOrderId,update agentBidPrice failure,".__METHOD__, 'trans', 
					'bid');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610070'), 610070);
			}
			return true;
		}
		return false;
	}

	/**
	 * 非领先出价，无代理价
	 *
	 * @param int $auditListId        	
	 * @param string $nickName        	
	 * @param array $transInfo        	
	 * @param Objecct $pFinanceLib        	
	 * @param int $buyerOrderId        	
	 * @param string $newFinishDate        	
	 * @param float $newBidPrice        	
	 * @param float $newAgentBidPrice        	
	 * @throws \Exception
	 * @return boolean
	 */
	public function unLeadBidWithoutAgent($auditListId, $nickName, $transInfo, $pFinanceLib, $buyerOrderId, 
		$newFinishDate, $newBidPrice, $newAgentBidPrice)
	{
		if(!$this->transBidLib->unLeaderUpdatePrice($auditListId, $transInfo['Buyer'], $transInfo['BidPrice'], 
			$this->enameId, $nickName, $buyerOrderId, $newBidPrice, $newAgentBidPrice, $newFinishDate, 
			$transInfo['AgentBidPrice'])) // 写入主表出价保证金
		{
			\core\Log::write("FALSE,$auditListId,$this->enameId,出价更新主表记录失败，原因可能是不同用户同时出价,".__METHOD__, 'trans', 'bid');
			// 取消出价保证金
			if(!$pFinanceLib->canelOrder($buyerOrderId, $this->enameId))
				\core\Log::write("FALSE,$auditListId,$this->enameId,$buyerOrderId,出价更新主表记录失败，原因可能是不同用户同时出价，取消用户出价保证金失败,".__METHOD__, 
					'trans', 'bid');
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610079'), 610079);
		}
		if(!$this->transBidLib->CreateBidPrice($auditListId, $transInfo['DomainName'], $transInfo['TransType'], 
			$this->enameId, $transInfo['Seller'], $nickName, $newBidPrice, \common\Common::getRequestIp(), $newFinishDate, 
			FALSE, FALSE)) // 写入出价表
		{
			\core\Log::write("FALSE,$auditListId,$this->enameId,出价更新出价表记录失败,".__METHOD__, 'trans', 'bid');
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610001'), 610001);
		}
		$canel = $pFinanceLib->canelOrder($transInfo['BuyerOrderId'], $transInfo['Buyer']); // 取消订单
		if($canel === False)
		{
			\core\Log::write("FALSE,$auditListId," . $transInfo['BuyerOrderId'] . ',' . $transInfo['Buyer'] . '取消订单失败,'.__METHOD__, 
				'trans', 'bid');
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610001'), 610001);
		}
		return true;
	}

	/**
	 * 非领先出价,最后得标,当前领先者有代理价
	 *
	 * @param int $auditListId        	
	 * @param int $nickName        	
	 * @param array $transInfo        	
	 * @param Object $pFinanceLib        	
	 * @param int $buyerOrderId        	
	 * @param datetime $newFinishDate        	
	 * @param float $newBidPrice        	
	 * @param float $newAgentBidPrice        	
	 * @throws \Exception
	 * @throws Exception
	 * @return boolean
	 */
	private function unLeadBidWithAgentWin($auditListId, $nickName, $transInfo, $pFinanceLib, $buyerOrderId, 
		$newFinishDate, $newBidPrice, $newAgentBidPrice)
	{
		if(!$this->transBidLib->unLeaderUpdatePrice($auditListId, $transInfo['Buyer'], $transInfo['BidPrice'], 
			$this->enameId, $nickName, $buyerOrderId, $newBidPrice, $newAgentBidPrice, $newFinishDate, 
			$transInfo['AgentBidPrice'])) // 写入主表出价保证金
		{
			\core\Log::write("FALSE,$auditListId,$this->enameId,unleaderbidprice update domainauction Error,".__METHOD__, 'trans', 
				'bid');
			\core\Log::write("FALSE,$auditListId,$this->enameId,$buyerOrderId,出价更新主表记录失败，原因可能是不同用户同时出价,".__METHOD__, 'trans', 'bid');
			// 取消出价保证金
			if(!$pFinanceLib->canelOrder($buyerOrderId, $this->enameId))
			{
				\core\Log::write("FALSE,$auditListId,$this->enameId,$buyerOrderId,出价更新主表记录失败，原因可能是不同用户同时出价，取消用户出价保证金失败,".__METHOD__, 
					'trans', 'bid');
			}
			
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610080'), 610080);
		}
		$canel = $pFinanceLib->canelOrder($transInfo['BuyerOrderId'], $transInfo['Buyer']); // 取消订单
		if($canel === False)
		{
			\core\Log::write("FALSE,$auditListId," . $transInfo['BuyerOrderId'] . ',' . $transInfo['Buyer'] . '取消订单失败,'.__METHOD__, 
				'trans', 'bid');
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610079'), 610079);
		}
		$rs = $this->transBidLib->CreateBidPrice($auditListId, $transInfo['DomainName'], $transInfo['TransType'], 
			$transInfo['Buyer'], $transInfo['Seller'], $transInfo['NickName'], $transInfo['AgentBidPrice'], 
			\common\Common::getRequestIp(), $newFinishDate, TRUE, FALSE);
		if(!$rs)
		{
			\core\Log::write("FALSE,$auditListId,$this->enameId,unleaderBidPrice update bidPrice error,".__METHOD__, 'trans', 'bid');
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610081'), 610081);
		}
		$rs = $this->transBidLib->CreateBidPrice($auditListId, $transInfo['DomainName'], $transInfo['TransType'], 
			$this->enameId, $transInfo['Seller'], $nickName, $newBidPrice, \common\Common::getRequestIp(), $newFinishDate, 
			False, False);
		if(!$rs)
		{
			\core\Log::write("FALSE,$auditListId,$this->enameId,unleaderBidPrice update bidprice error,".__METHOD__, 'trans', 'bid');
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610081'), 610081);
		}
		return true;
	}

	/**
	 * 不领先出价,最后不得标,当前领先者有代理价
	 *
	 * @param int $auditListId        	
	 * @param string $nickName        	
	 * @param float $postPrice        	
	 * @param array $transInfo        	
	 * @param Object $pFinanceLib        	
	 * @param int $buyerOrderId        	
	 * @param string $newFinishDate        	
	 * @param float $newBidPrice        	
	 * @param float $newAgentBidPrice        	
	 * @throws \Exception
	 * @return boolean
	 */
	public function unLeadBidWithAgentLoss($auditListId, $nickName, $postPrice, $transInfo, $pFinanceLib, $buyerOrderId, 
		$newFinishDate, $newBidPrice, $newAgentBidPrice)
	{
		if(!$this->transBidLib->unLeaderUpdatePrice($auditListId, $transInfo['Buyer'], $transInfo['BidPrice'], 
			$transInfo['Buyer'], $transInfo['NickName'], $transInfo['BuyerOrderId'], $newBidPrice, $newAgentBidPrice, 
			$newFinishDate, $transInfo['AgentBidPrice'])) // 修改主表
		{
			\core\Log::write("FALSE,$auditListId,$this->enameId,unleaderBidPrice update domainauction Error,".__METHOD__, 'trans', 
				'bid');
			\core\Log::write("FALSE,$auditListId,$this->enameId,$buyerOrderId,出价更新主表记录失败，原因可能是不同用户同时出价,".__METHOD__, 'trans', 'bid');
			// 取消出价保证金
			if(!$pFinanceLib->canelOrder($buyerOrderId, $this->enameId))
			{
				\core\Log::write("FALSE,$auditListId,$this->enameId,$buyerOrderId,出价更新主表记录失败，原因可能是不同用户同时出价，取消用户出价保证金失败,".__METHOD__, 
					'trans', 'bid');
			}
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610001'), 610001);
		}
		$canel = $pFinanceLib->canelOrder($buyerOrderId, $this->enameId); // 取消订单
		if($canel === False)
		{
			\core\Log::write("FALSE,$auditListId," . $transInfo['BuyerOrderId'] . '取消订单失败,'.__METHOD__, 'trans', 'bid');
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610001'), 610001);
		}
		if(!$this->transBidLib->CreateBidPrice($auditListId, $transInfo['DomainName'], $transInfo['TransType'], 
			$this->enameId, $transInfo['Seller'], $nickName, $postPrice, \common\Common::getRequestIp(), $newFinishDate)) // EnameId 出价
		{
			\core\Log::write("FALSE,$auditListId,$this->enameId,bidprice failure,".__METHOD__, 'trans', 'bid');
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610001'), 610001);
		}
		if(!$this->transBidLib->CreateBidPrice($auditListId, $transInfo['DomainName'], $transInfo['TransType'], 
			$transInfo['Buyer'], $transInfo['Seller'], $transInfo['NickName'], $newBidPrice, $transInfo['BuyerIP'], 
			$newFinishDate, TRUE)) // transInfo['buyer']
		{
			\core\Log::write("FALSE,$auditListId,$this->enameId,出价表出错,".__METHOD__, 'trans', 'bid');
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610079'), 610079);
		}
		return true;
	}
	
	/**
	 * 增加抽奖机会
	 * @param unknown $transInfo
	 * @param unknown $auditListId
	 */
	private function addChance($transInfo)
	{		
		$interface = new \interfaces\trans\Lottery();
		return $interface->addChance($this->enameId, strtotime($transInfo['FinishDate']), $transInfo['DomainName']);
	}
	
	/**
	 * 每个域名每个用户第一次出价将获得一组两位数字的不重复随机码
	 */
	private function randomCode($transInfo, $auditListId)
	{
		// 获取出价随机码
		$interface = new \interfaces\trans\Lottery();
		$rqTime = strtotime(date('Y-m-d 00:00:00', strtotime($transInfo['FinishDate'])));
		return $interface->creatCode($this->enameId, $auditListId, $transInfo['DomainName'], $rqTime);
	}

	/**
	 * 加入交易结束时间更新队列
	 * @param int $auditListId
	 */
	public function addDateUpdateQueue($auditListId)
	{
		try
		{
			$redis = new \models\trans\redis\TransIndex();
			$redis->addFinishDateUpdateQueue($auditListId);
		}
		catch (\Exception $exc)
		{
			\core\Log::write("FALSE,$auditListId,$this->enameId,".$exc->getMessage().','.__METHOD__, 'trans', 
				'bid');
		}
	}
}

?>
<?php
namespace logic\trans\trans;
use core\Response;

class TransLogic
{

	private $lib;

	private $conf;

	public function __construct()
	{
		// 加载配置
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
		$this->lib = new \lib\trans\trans\TransLib();
	}

	/**
	 * 获取卖家/买家正在交易/交易结束的域名列表和数量
	 *
	 * @param unknown $data        	
	 * @throws \Exception
	 * @return multitype:Ambigous <\lib\trans\trans\Ambigous,
	 *         \models\trans\Ambigous, boolean, mixed> |multitype:number
	 *         Ambigous <multitype:, \lib\trans\trans\Ambigous,
	 *         \models\trans\Ambigous, boolean, unknown, multitype:multitype: >
	 */
	public function getTrans($data)
	{
		// 加载配置
		$transStatusConf = $this->conf->trans_status->toArray();
		$pLib = new \lib\trans\common\PublicLib();
		$transStatus = $pLib->KeyToValue($transStatusConf);
		$transTypeConf = $this->conf->trans_transtype->toArray();
		$transTypes = $pLib->KeyToValue($transTypeConf);
		// 获取参数
		$enameId = $data->enameid;
		$type = $data->type;
		$flag = $data->flag;
		$transType = $data->transtype;
		$domain = $data->domain;
		$status = $data->status;
		$pageSize = $data->num? (($data->num > $this->conf->default_maxnum)? $this->conf->default_maxnum: $data->num): $this->conf->default_getnum;
		$p = $data->p? $data->p: 1;
		$offset = ($p - 1) * $pageSize;
		$isEnd = $data->isend;
		
		if($transType == $transTypeConf['booking'][0])
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610096'), 610096);
		}
		if($isEnd)
		{
			$deliveryStatus = $status? array(
					$status
			): array(
					$transStatusConf['buyerabandon'][0],$transStatusConf['sellerabandon'][0],
					$transStatusConf['successtrans'][0],$transStatusConf['reserverabandon'][0],
					$transStatusConf['failtrans'][0]
			);
			$deliveryStatus = implode(',', $deliveryStatus);
		}
		else
		{
			$deliveryStatus = implode(',', 
				array(
						$transStatusConf['checking'][0],$transStatusConf['buyerchecked'][0],
						$transStatusConf['sellerchecked'][0],$transStatusConf['allchecked'][0]
				));
		}
		
		$list = array();
		$count = 0;
		
		if($type == 2)
		{
			// 获得所有的数量
			$count = $this->lib->getBuyerTrandingCount($domain, $enameId, $transType, $deliveryStatus);
			$count += $this->lib->getSellerTrandingCount($domain, $enameId, $transType, $deliveryStatus);
			$flag = 1;
		}
		else 
			if($type == 1)
			{
				// 买家
				switch($flag)
				{
					case 0:
						$list = $this->lib->getBuyerTrandingList($domain, $enameId, $transType, $deliveryStatus, 
							$offset, $pageSize);
						break;
					case 1:
						$count = $this->lib->getBuyerTrandingCount($domain, $enameId, $transType, $deliveryStatus);
						break;
					case 2:
						$list = $this->lib->getBuyerTrandingList($domain, $enameId, $transType, $deliveryStatus, 
							$offset, $pageSize);
						$count = $this->lib->getBuyerTrandingCount($domain, $enameId, $transType, $deliveryStatus);
						break;
				}
			}
			else
			{
				// 卖家
				switch($flag)
				{
					case 0:
						$list = $this->lib->getSellerTrandingList($domain, $enameId, $transType, $deliveryStatus, 
							$offset, $pageSize);
						break;
					case 1:
						$count = $this->lib->getSellerTrandingCount($domain, $enameId, $transType, $deliveryStatus);
						break;
					case 2:
						$count = $this->lib->getSellerTrandingCount($domain, $enameId, $transType, $deliveryStatus);
						$list = $this->lib->getSellerTrandingList($domain, $enameId, $transType, $deliveryStatus, 
							$offset, $pageSize);
						break;
				}
			}
		
		if(! empty($list) && is_array($list))
		{
			foreach($list as $k => $v)
			{
				$Deadline = $type? $v['BuyerDeadline']: $v['SellerDeadline'];
				$statusArr = $type ? array(3,5,6,8) : array(4,5,7,8);
				if(! $isEnd)
				{
					$list[$k]['Lefttime'] = (in_array($v['DeliveryStatus'],$statusArr) || strtotime($Deadline) - time()<0)? '-' : $pLib->NewTimeToDHIS(strtotime($Deadline) - time());
				}
				$list[$k]['DeliveryStatus'] = $transStatus[$v['DeliveryStatus']];
				$list[$k]['TransMoney'] = intval($v['TransMoney']);
				if($isEnd)
				{
					$list[$k]['DeliveryDate'] = date('Y-m-d', strtotime($v['DeliveryDate']));
				}
				else
				{
					unset($list[$k]['DeliveryDate']);
				}
				unset($list[$k]['SellerDeadline']);
				if(isset($list[$k]['SellerDeadline']))
				{
					unset($list[$k]['SellerDeadline']);
				}
				if(isset($list[$k]['BuyerDeadline']))
				{
					unset($list[$k]['BuyerDeadline']);
				}
				if(isset($list[$k]['DomainName']))
				{
					$list[$k]['DomainName'] = \lib\trans\common\PublicDomainLib::replaceL($list[$k]['DomainName']);
				}
			}
		}
		if($flag == 1)
		{
			return array(
					'count' => $count
			);
		}
		elseif($flag == 2)
		{
			return array(
					'list' => $list,'p' => $p,'count' => $count,'transtype' => $transTypes[$transType]
			);
		}
		else
		{
			return array(
					'list' => $list,'p' => $p,'transtype' => $transTypes[$transType]
			);
		}
	}

	/**
	 * 卖家/买家竞价详情
	 *
	 * @param Object $data        	
	 */
	public function transInfo($data)
	{
		// 加载配置
		$transStatusConf = $this->conf->trans_status->toArray();
		$pLib = new \lib\trans\common\PublicLib();
		$transStatus = $pLib->KeyToValue($transStatusConf);
		$transTypeConf = $this->conf->trans_transtype->toArray();
		$transTypes = $pLib->KeyToValue($transTypeConf);
		// 获取参数
		$enameId = $data->enameid;
		$id = $data->id;
		$type = $data->type;
		$isEnd = $data->isend;
		$deliveryMod = new \models\trans\DeliveryMod();
		if($isEnd)
		{
			$deliveryStatus = implode(',', 
				array(
						$transStatusConf['buyerabandon'][0],$transStatusConf['sellerabandon'][0],
						$transStatusConf['successtrans'][0],$transStatusConf['reserverabandon'][0],
						$transStatusConf['failtrans'][0]
				));
		}
		else
		{
			$deliveryStatus = implode(',', 
				array(
						$transStatusConf['checking'][0],$transStatusConf['buyerchecked'][0],
						$transStatusConf['sellerchecked'][0],$transStatusConf['allchecked'][0]
				));
		}
		if($type)
		{
			$info = $deliveryMod->getBuyerAuctionInfo($enameId, $id, $deliveryStatus);
			$method = 'buyerrefuse';
		}
		else
		{
			$info = $deliveryMod->getSellerAuctionInfo($enameId, $id, $deliveryStatus);
			$method = 'sellerrefuse';
		}
		if(false === $info)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'), 610000);
		}
		if(! empty($info) && is_array($info))
		{
			$info['TransType'] = isset($transTypes[$info['TransType']])? $transTypes[$info['TransType']]: '未知';
			$info['TransMoney'] = intval($info['TransMoney']);
			if(! $isEnd)
			{
				$info['Status'] = $info['DeliveryStatus'];
				$info['AbandonMsg'] = $this->lib->getAbandonMoney($method, $info['TransMoney'], $enameId, 
					$info['Buyer'], $info['Seller']);
			}
			else
			{
				if(isset($info['BuyerApplyDay']))
				{
					unset($info['BuyerApplyDay']);
				}
				if(isset($info['SellerApplyDay']))
				{
					unset($info['SellerApplyDay']);
				}
				if(isset($info['TransTopic']))
				{
					unset($info['TransTopic']);
				}
			}
			if(isset($info['Buyer']))
			{
				unset($info['Buyer']);
			}
			$info['DeliveryStatus'] = isset($transStatus[$info['DeliveryStatus']])? $transStatus[$info['DeliveryStatus']]: '未知';
			$info['NickName'] = $this->lib->getNickName($info['AuditListId'], $info['DeliveryDate']);
			$info['DomainName'] =  \lib\trans\common\PublicDomainLib::replaceL($info['DomainName']);
			//兼容App端，将延期达上限次数的标记改为延期被拒绝
			//卖家为cnnicUser的交易买家禁止申请延期
			$cnnicUser = $this->conf->cnnicUser;
			if((isset($info['BuyerApply']) && 4 == $info['BuyerApply']) ||$info['Seller'] == $cnnicUser)
			{
				$info['BuyerApply'] = 3;
			}
			if(isset($info['SellerApply']) && 4 == $info['SellerApply'])
			{
				$info['SellerApply'] = 3;
			}
			
			return array(
					'info' => $info
			);
		}
		else
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610039'), 610039);
		}
	}

	public function pushDomainNum($data)
	{
		$enameid = $data->enameid;
		
		$push = new \interfaces\trans\Domains();
		
		$count = $push->getdomainPushCount($enameid);
		
		if($count !== FALSE)
		{
			return array(
					'count' => $count
			);
		}
		else
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'), 610000);
		}
	}

	/**
	 * 我-我的交易-正在交易（统计数量）
	 */
	public function getMyTransTotal($data)
	{
		// 加载配置
		$transStatusConf = $this->conf->trans_status->toArray();
		$trans_status = $this->conf->trans_status->toArray();
		$pLib = new \lib\trans\common\PublicLib();
		
		$domain = empty($data->domain)? '': $domain = $data->domain;
		;
		$enameId = $data->enameid;
		// $type = $data->type;
		
		$deliveryStatus = implode(',', 
			array(
					$transStatusConf['checking'][0],$transStatusConf['buyerchecked'][0],
					$transStatusConf['sellerchecked'][0],$transStatusConf['allchecked'][0]
			));
		
		$count = array();
		// 获得竞价所有的数量
		$count['bidding'] = $this->lib->getBuyerTrandingCount($domain, $enameId, 1, $deliveryStatus);
		$count['bidding'] += $this->lib->getSellerTrandingCount($domain, $enameId, 1, $deliveryStatus);
		
		// 获得一口价所有数量
		$count['buynow'] = $this->lib->getBuyerTrandingCount($domain, $enameId, 4, $deliveryStatus);
		$count['buynow'] += $this->lib->getSellerTrandingCount($domain, $enameId, 4, $deliveryStatus);
		
		// 获取询价的所有数量
		$transInquiryLogic = new \logic\trans\trans\TransInquiryLogic($enameId);
		$data->domain = '';
		$data->flag = 1;
		$data->status = 0;
		$data->flag = 1;
		$data->isend = '';
		$data->num = 4;
		$data->p = 1;
		$data->type = 2;
		$count['inquery'] = $transInquiryLogic->getInquiry($data)['count'];
		
		// 获得push域名的数量
		$push = new \interfaces\trans\Domains();
		$count['push'] = $push->getdomainPushCount($enameId);
		
		// 获得经纪中介的所有值
		$escrow = new \logic\trans\escrow\EscrowLogic();
		$data->transtype = 1;
		$data->role = '';
		$data->flag = 1;
		$count['agency'] = $escrow->listLogic($data)['count'];
		$data->transtype = 0;
		
		$count['total'] = array_sum($count);
		
		if(false === $count)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'), 610000);
		}
		return $count;
	}

	/**
	 * 我的交易数量整合
	 */
	public function getMytransInfo($data)
	{
		$enameid = $data->enameid;
		$type = $data->type;
		
		$count = array();
		
		// 我-我的交易-正在交易
		$transing = $this->getMyTransTotal($data);
		
		if($type < 2)
		{
			// 我-我的交易-店铺管理
			$shop = new \logic\trans\shop\ShopLogic();
			
			// 获取店铺的数量
			$inquiryStatusConfig = $this->conf->inquiry_status->toArray();
			$inquiryStatusArray = array(
					$inquiryStatusConfig['onsale'][0],$inquiryStatusConfig['success'][0],
					$inquiryStatusConfig['endsale'][0],$inquiryStatusConfig['fail'][0]
			);
			$domainAuctionMod = new \models\trans\DomainAuctionMod();
			$inquiryMod = new \models\trans\InquiryMod();
			$shopNum = $domainAuctionMod->getSellerOnSaleCount($enameid, 1);
			$shopNum += $domainAuctionMod->getSellerOnSaleCount($enameid, 4);
			
			// 我-我的交易-我的出价
			$buyer = new \logic\trans\buyer\BuyerLogic();
			
			$data->flag = 1;
			$data->type = 0;
			$buyerNum = $buyer->userBid($data)['num'];
			
			if($type < 1)
			{
				// 我的交易
				$mytrans = $transing['total'];
				
				// 我的域名
				$domain = new \interfaces\manage\domains();
				$mydomain = $domain->domainCount($data->enameid);
				
				$count['mytrans'] = $mytrans;
				$count['mydomain'] = $mydomain;
			}
			else
			{
				$count['shopnum'] = $shopNum;
				$count['buyernum'] = $buyerNum;
				$count['transing'] = $transing['total'];
			}
		}
		else
		{
			unset($transing['total']);
			$count = $transing;
		}
		
		return $count;
	}

	/**
	 * 判断交易是否结束,1:竞价,2:询价,3:经纪中介,4:push域名
	 *
	 * @param int $data        	
	 */
	public function getIsFinish($data)
	{
		// 获取参数
		$typeConf = $this->conf->information_type->toArray();
		// 获取参数
		$id = $data->id;
		$type = $data->type;
		
		$flag = false;
		switch($type)
		{
			case $typeConf['auction'][0]:
				$flag = $this->lib->autionIsFinish($id);
				break;
			case $typeConf['inquiry'][0]:
				$flag = $this->lib->inquiryIsFinish($id);
				break;
			case $typeConf['escrow'][0]:
				$lib = new \lib\trans\escrow\EscrowLib();
				$flag = $lib->escrowIsFinish($id);
				break;
			case $typeConf['push'][0]:
				$domains = new \interfaces\trans\Domains();
				$rs = $domains->domainPushStatus($id);
				if(1 == $rs)
				{
					$flag = true;
				}
				elseif(2 == $rs)
				{
					$flag = false;
				}
				else
				{
					throw new \Exception(Response::getErrMsg(), Response::getErrCode());
				}
				break;
			default:
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610097'), 610097);
				break;
		}
		
		return $flag;
	}

	/**
	 * 判断是否存在交易信息,供管理平台调用
	 *
	 * @param Object $data        	
	 */
	public function isExistTrans($data)
	{
		// 获取参数
		$domain = $data->domain;
		$startTime = $data->starttime;
		$endTime = $data->endtime;
		$domainAuctionMod = new \models\trans\DomainAuctionMod();
		$auctionDomain = $domainAuctionMod->getTransdata($domain, $startTime, $endTime);
		if(false === $auctionDomain)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'), 610000);
		}
		$inquiryMod = new \models\trans\InquiryMod();
		$inquiryDomain = $inquiryMod->getInquiryData($domain, $startTime, $endTime);
		if(false === $inquiryDomain)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'), 610000);
		}
		$info = array();
		if($auctionDomain && $inquiryDomain)
		{
			if($auctionDomain['CreateDate'] >= $inquiryDomain['CreateDate'])
			{
				$info = $auctionDomain;
			}
			else
			{
				$info = $inquiryDomain;
			}
		}
		elseif($auctionDomain)
		{
			$info = $auctionDomain;
		}
		elseif($inquiryDomain)
		{
			$info = $inquiryDomain;
		}
		return array(
				'info' => $info
		);
	}

	/**
	 * 检测好域名，供管理平台调用
	 *
	 * @param Objet $data        	
	 * @return Ambigous <\logic\trans\fabu\multitype:boolean, boolean,
	 *         multitype:boolean unknown , multitype:boolean Ambigous <number,
	 *         multitype:> >
	 */
	public function checkGoodDomain($data)
	{
		// 加载配置
		$transTopicConf = $this->conf->fabu_transtopic->toArray();
		// 获取参数
		$domainName = $data->domain;
		$interface = new \interfaces\trans\Domains();
		$info = array();
		$rs = $interface->getDomainGroup($domainName);
		$info['sysGroupOne'] = $rs['domainSysOne'];
		$info['sysGroupTwo'] = $rs['domainSysTwo'];
		$info['domainLength'] = $rs['domainLength'];
		$info['TLDIndex'] = $interface->getDomainLtd($domainName);
		$pDomainLib = new \lib\trans\common\PublicDomainLib();
		$info['domainSLD'] = $pDomainLib->getDomainBody($domainName);
		$fabuSpecialLogic = new \logic\trans\fabu\FabuSpecialLogic();
		$info['transTopic'] = $transTopicConf['ebuy'][0];
		$info['topic'] = 0;
		return $fabuSpecialLogic->checkPassCondition($info, true);
	}

	/**
	 * 淘域名总数量
	 */
	public function getTotalCount()
	{
		$transTypeConf = $this->conf->trans_type->toArray();
		$domainAuctionMod = new \models\trans\DomainAuctionMod();
		$inquiryMod = new \models\trans\InquiryMod();
		$num1 = $domainAuctionMod->getTotalCount($transTypeConf);
		$num2 = $inquiryMod->getTotalCount();
		if($num1 == false || $num2 == false)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'), 610000);
		}
		$num = $num1 + $num2;
		return array(
				'num' => $num
		);
	}

	/**
	 * 点赞
	 * 
	 * @param Obj $data        	
	 * @throws \Exception
	 * @return multitype:string
	 */
	public function praise($data)
	{
		$transTypeConf = $this->conf->trans_type->toArray();
		$id = $data->id;
		$enameId = $data->enameid;
		$plat = isset($data->plat)? intval($data->plat): 0;
		$transType = ! empty($data->transtype)? $data->transtype: $transTypeConf['auction'][0];
		$praiseMod = new \models\trans\PraiseMod();
		$cnSaveDomainMod = new \models\trans\CnSaveDomainMod();
		$this->lib->checkExistTrans($id, $transType);
		if(! $praiseMod->getPraiseCount($id, $enameId))
		{
			if($praiseMod->addPraise($enameId, $id, $plat))
			{
				
				$cnSaveDomainInfo = $cnSaveDomainMod->getCnDomain($id);
				if($cnSaveDomainInfo && ! $cnSaveDomainMod->updateCnDomain($id, $cnSaveDomainInfo['PraiseCount'] + 1))
				{
					\core\Log::write('update praiseCount fail,EnameId:' . $enameId . ',Id:' . $id, 'trans',
						'praise');
				}
				if(! $plat)
				{
					Response::msg(\common\Lang::create('transmsg')->getMsg('610109'), 610109, true);
				}
				else
				{
					if($cnSaveDomainInfo)
					{
						//是拍卖会的域名
						$info = $cnSaveDomainMod->getCnDomain($id);
						$praiseCount = $info ? intval($info['PraiseCount']) : 0;
					}
					else
					{
						//不是拍卖会的域名
						$count = $praiseMod->getPraiseCount($id);
						$praiseCount = $count ? $count : 0;
					}
					Response::msg(
						array(
								'code' => 610109,'msg' => \common\Lang::create('transmsg')->getMsg('610109'),
								'praiseCount' => $praiseCount
						), true);
				}
			}
			else
			{
				\core\Log::write('add praise fail,EnameId:' . $enameId . ',Id:' . $id, 'trans', 'praise');
				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610098'), 610098);
			}
		}
		else
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610099'), 610099);
		}
	}

	/**
	 * 取消点赞
	 * 
	 * @param Obj $data        	
	 * @throws \Exception
	 * @return string
	 */
	public function cancelPraise($data)
	{
		$transTypeConf = $this->conf->trans_type->toArray();
		$id = $data->id;
		$enameId = $data->enameid;
		$transType = ! empty($data->transtype)? $data->transtype: $transTypeConf['auction'][0];
		$plat = isset($data->plat)? intval($data->plat): 0;
		$praiseMod = new \models\trans\PraiseMod();
		$cnSaveDomainMod = new \models\trans\CnSaveDomainMod();
		$this->lib->checkExistTrans($id, $transType);
		if($praiseMod->getPraiseCount($id, $enameId))
		{
// 			if(! $praiseMod->delPraise($enameId, $id))
// 			{
// 				\core\Log::write('del praise fail,EnameId:' . $enameId . ',Id:' . $id, 'trans', 'praise');
// 				throw new \Exception(\common\Lang::create('transmsg')->getMsg('610100'), 610100);
// 			}
// 			else
// 			{
// 				$cnSaveDomainInfo = $cnSaveDomainMod->getCnDomain($id);
// 				if($cnSaveDomainInfo)
// 				{
// 					$praiseCount = $cnSaveDomainInfo['PraiseCount'] - 1 > 0? $cnSaveDomainInfo['PraiseCount'] - 1: 0;
// 					if(! $cnSaveDomainMod->updateCnDomain($id, $praiseCount))
// 					{
// 						\core\Log::write('update praiseCount fail,EnameId:' . $enameId . ',Id:' . $id, 'trans',
// 							'praise');
// 					}
// 				}
			   $cnSaveDomainInfo = $cnSaveDomainMod->getCnDomain($id);
				if(! $plat)
				{
					Response::msg(\common\Lang::create('transmsg')->getMsg('610110'), 610110, true);
				}
				else
				{
					if($cnSaveDomainInfo)
					{
						//是拍卖会的域名
						$info = $cnSaveDomainMod->getCnDomain($id);
						$praiseCount = $info ? intval($info['PraiseCount']) : 0;
					}
					else
					{
						//不是拍卖会的域名
						$count = $praiseMod->getPraiseCount($id);
						$praiseCount = $count ? $count : 0;
					}
					Response::msg(
					array(
					'code' => 610110,'msg' => \common\Lang::create('transmsg')->getMsg('610110'),
					'praiseCount' => $praiseCount
					), true);
				}
			//}
		}
		else
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610101'), 610101);
		}
	}

	/**
	 * 获取专题拍卖会客户端点赞前几名
	 */
	public function getTopCnDomainList($data)
	{
		$ver = isset($data->ver) && $data->ver? $data->ver: 9;
		$num = isset($data->num) && $data->num? $data->num: 8;
		$cnSaveDomainMod = new \models\trans\CnSaveDomainMod();
		$data = $cnSaveDomainMod->getTopDomainList($ver, $num);
		if(false === $data)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610000'), 610000);
		}
		$pLib = new \lib\trans\common\PublicLib();
		foreach($data as $k => $v)
		{
			$data[$k]['FinishTime'] = $data[$k]['FinishDate'];
			if(strtotime($v['CreateDate']) > time())
			{
				$data[$k]['FinishDate'] = \common\Lang::create('transmsg')->getMsg('610111');
			}
			else
			{
				$data[$k]['FinishDate'] = $pLib->NewTimeToDHIS(strtotime($v['FinishDate']) - time());
			}
			$data[$k]['BidPrice'] = intval($v['BidPrice']);
		}
		return $data;
	}
	
	public function getdomainsByIds($id)
	{
		$transStatusConf = $this->conf->trans_status->toArray();
		$transStatus = array();
		foreach ($transStatusConf as $k=>$v)
		{
			$transStatus[$v[0]] = $v[1];
		}
		$domainAuctionMod = new \models\trans\DomainAuctionMod();
		
		$ids = is_array($id) ? $id : array($id);
		$domainlist = array();
		if($ids)
		{
			foreach ($ids as $id)
			{
				$info = $domainAuctionMod->getTransAuctionInfo($id);
				if($info)
				{
					$domainlist[$id]['DomainName'] = $info['DomainName'];
					$domainlist[$id]['BidPrice'] = $info['BidPrice'];
					$domainlist[$id]['AgentBidPrice'] = $info['AgentBidPrice'];
					$domainlist[$id]['TransStatus'] = isset($transStatus[$info['TransStatus']]) ? $transStatus[$info['TransStatus']] : '未知';
				}
				else
				{
					$domainlist[$id] = array();
				}
			}
		}
		return $domainlist;
	}
}

?>
<?php
namespace logic\trans\escrow;

use models\trans\EscrowMod;
use core\form\ReturnData;
class EscrowLogic
{

	private $lib;

	private $conf;

	public function __construct()
	{
		// 加载配置
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'escrow');
		$this->lib = new \lib\trans\escrow\EscrowLib();
	}

	/**
	 * 添加中介
	 */
	public function addAgencyLogic($data)
	{
		$escrowPercentage = $this->conf->escrow_percentage->toArray();
		// 判断是否提交过经纪
		if($this->lib->checkEscrowIsExist($data->enameid, $data->domain, $data->mobile, $data->email, $data->transtype))
		{
			throw new \Exception(\common\Lang::create('escrowmsg')->getMsg('630000'),630000);
		}
		
		$check = FALSE; // 默认必须填对方信息
		if(!empty($data->version)) // 旧版本不需要填对方信息
		{
			$check = TRUE;
		}
		else
		{
			// 新版本需要填对方联系方式或者EnameId
			if($data->otheruid || ($data->otheruser && $data->othermobile && $data->otheremail))
			{
				$check = TRUE;
			}
		}
		
		// enameid 是卖家 userid是买家
		if($check)
		{
			$contact = array('email' => $data->email,'telPhone' => $data->mobile,'phone' => '','qq' => '');
			$opposite = array('mail' => $data->otheremail,'linkman' => $data->otheruser,'mobile' => $data->othermobile,
				'enameId' => $data->otheruid,'phone' => '','qq' => '');
			
			$domainLib = new \interfaces\trans\Domains();
			if($data->transtype == 1)
			{
				// 购买域名
				$buyer = $data->enameid;
				$domainUid = $domainLib->getDomainEnameId($data->domain);
				if($domainUid)
				{
					if($domainUid == $data->enameid)
					{
						throw new \Exception(\common\Lang::create('escrowmsg')->getMsg('630018'),630018);
					}
					$seller = $domainUid;
				}
				else
				{
					if($data->otheruid == $data->enameid)
					{
						throw new \Exception(\common\Lang::create('escrowmsg')->getMsg('630025'),630025);
					}
					$seller = $data->otheruid;
				}
			}
			else
			{
				// 出售域名
				$domainUid = $domainLib->getDomainEnameId($data->domain);
				if($domainUid && $domainUid != $data->enameid)
				{
					throw new \Exception(\common\Lang::create('escrowmsg')->getMsg('630026'),630026);
				}
				$buyer = $data->otheruid;
				$seller = $data->enameid;
			}
			
			$domain = $domainLib->getDomainGroup($data->domain);
			$pLib = new \lib\trans\common\PublicDomainLib();
			$tld = $pLib->getDomainClassAll($data->domain);
			
			$parm = array('domainName' => $data->domain,'telPhone' => $data->mobile,'email' => $data->email,
				'mobile' => $data->mobile,'mail' => $data->otheremail,'enameId' => $seller,'domainPrice' => $data->price,
				'userName' => $data->user,'contactus' => $contact,'opposite' => $opposite,'domainMessage' => '',
				'userId' => $buyer,'trideType' => 2,'paymode' => $data->paytype,'typeTride' => $data->transtype,
				'fromHost' => 'open.ename.net','groupOne' => $domain['domainSysOne'],
				'groupTwo' => $domain['domainSysTwo'],'domainLen' => $domain['domainLength'],'domainTLD' => $tld,
				'type' => 2,'percentage' => $escrowPercentage[2]);
			$this->lib->addEscrowLib($parm);
		}
		else
		{
			throw new \Exception(\common\Lang::create('escrowmsg')->getMsg('630001'),630001);
		}
	}

	/**
	 * 经纪中介列表
	 */
	public function listLogic($data)
	{
		// 加载配置
		$statucConf = $this->conf->escrow_status->toArray();
		// 获取参数
		$enameId = $data->enameid;
		$domain = $data->domain;
		$role = $data->role;
		$transType = $data->transtype? $data->transtype :0;
		$status = $data->status? $data->status :0;
		$flag = $data->flag? $data->flag :0;
		$pageSize = $data->num? (($data->num > $this->conf->default_maxnum)? $this->conf->default_maxnum :$data->num) :$this->conf->default_getnum;
		$p = $data->p? $data->p :1;
		$offset = ($p - 1) * $pageSize;
		
		$escrowMod = new \models\trans\EscrowMod();
		$list = array();
		
		if($transType == 1)
		{
			$data = $escrowMod->getEscrowAgency($transType, $domain, $role, $enameId, $flag, $status, $offset, 
				$pageSize);
			$typeCn = \common\Lang::create('escrowmsg')->getMsg('630002');
		}
		else
		{
			$data = $escrowMod->getEscrowAgency($transType, $domain, $role, $enameId, $flag, $status, $offset, 
				$pageSize);
			$typeCn = \common\Lang::create('escrowmsg')->getMsg('630003');
		}
		if($data === false)
		{
			throw new \Exception(\common\Lang::create('escrowmsg')->getMsg('630004'),630004);
		}
		
		// 统计数量
		$cnt['escrow'] = $escrowMod->getEscrowAgency(1, $domain, $role, $enameId, 1, $status, $offset, $pageSize);
		$cnt['agency'] = $escrowMod->getEscrowAgency(2, $domain, $role, $enameId, 1, $status, $offset, $pageSize);
		
		if($flag)
		{
			// 统计数量
			return array('count' => $cnt['escrow'] + $cnt['agency']);
		}
		else
		{
			$list = array();
			if($data)
			{
				foreach($data as $k => $v)
				{
					$list[$k]['FinalPrice'] = intval($v['FinalPrice']);
					$v['Purchaser'] = $v['buyer'];
					$v['Bargainor'] = $v['seller'];
					$list[$k]['TransType'] = $typeCn . ($this->getTradeType($v, $enameId));
					if($v['Status'] < 2)
					{
						$status = \common\Lang::create('escrowmsg')->getMsg('630007');
					}
					elseif($v['Status'] == 2)
					{
						if(1 == $v['BuyStatus'] && 1 == $v['SaleStatus'])
						{
							$status = \common\Lang::create('escrowmsg')->getMsg('630008');
						}
						else 
							if(1 == $v['BuyStatus'] && 0 == $v['SaleStatus'])
							{
								$status = \common\Lang::create('escrowmsg')->getMsg('630009');
							}
							else 
								if(0 == $v['BuyStatus'] && 1 == $v['SaleStatus'])
								{
									$status = \common\Lang::create('escrowmsg')->getMsg('630010');
								}
								else
								{
									$status = \common\Lang::create('escrowmsg')->getMsg('630011');
								}
					}
					elseif(3 == $v['Status'])
					{
						$status = \common\Lang::create('escrowmsg')->getMsg('630012');
					}
					elseif(4 == $v['Status'])
					{
						$status = \common\Lang::create('escrowmsg')->getMsg('630013');
					}
					elseif(5 == $v['Status'])
					{
						$status = \common\Lang::create('escrowmsg')->getMsg('630014');
					}
					else
					{
						$status = \common\Lang::create('escrowmsg')->getMsg('630015');
					}
					$list[$k]['Status'] = $status;
					$list[$k]['Domain'] = $v['Domainname'] !=\common\Lang::create('escrowmsg')->getMsg('630027') ?  \lib\trans\common\PublicDomainLib::replaceL($v['Domainname']) : $v['note'];
					$list[$k]['Esid'] = $v['ESID'];
				}
			}
			return array('list' => $list,'count' => $cnt?  :0,'p' => $p);
		}
	}

	/**
	 * 获取经纪列表和数量,供管理平台调用
	 */
	public function getEsrowInfoByEid($data)
	{
		$defaultNum = $this->conf->default_getnum;
		$enameId = $data->enameid;
		$pageSize = isset($data->num)? intval($data->num) :$defaultNum;
		if(!$enameId)
		{
			throw new \Exception(\common\Lang::create('escrowmsg')->getMsg('630016') , 630016);
		}
		$list = $this->lib->getEscrowList($enameId, $pageSize);
		$count = $this->lib->getEscrowNum($enameId);
		return array('list' => $list? $list :array(),'count' => $count? $count :0);
	}

	public function addEscrowLogic($data)
	{
		$escrowPercentage = $this->conf->escrow_percentage->toArray();
		// 加载配置
		$pdPerson = $this->conf->system_pd_person->toArray();
		$domainName = $data->domainname;
		$enameId = $data->enameid;
		$linkman = $data->linkman;
		$telPhone = $data->telphone;
		$email = $data->email;
		$price = $data->price;
		$paytype = $data->paytype;
		if($price < 200)
		{
			throw new \Exception(\common\Lang::create('escrowmsg')->getMsg('630017') , 630017);
		}
		$postData = $this->lib->formatData($domainName, $enameId, $price, '', $linkman, $telPhone, $email);
		// 判断域名是否属于用户
		if($postData['senameid'] == $enameId && !empty($enameId))
			throw new \Exception(\common\Lang::create('escrowmsg')->getMsg('630018') , 630018);
			
			// 判断是否提交过经纪,经纪默认的交易类型是购买1
		if($this->lib->checkEscrowIsExist($enameId, $domainName, $telPhone, $email, 1))
		{
			throw new \Exception(\common\Lang::create('escrowmsg')->getMsg('630019') , 630019);
		}
		
		// 读取配置文件
		$role = 1; // 经纪购买
		$trideType = 1; // 经纪
		$fromHost = 'open.ename.net';
		$domainLib = new \interfaces\trans\Domains();
		$domain = $domainLib->getDomainGroup($domainName);
		$pLib = new \lib\trans\common\PublicDomainLib();
		$tld = $pLib->getDomainClassAll($domainName);
		// 系统派单人
		$param = array();
		$param['typeTride'] = $role; // 购买/出售
		$param['email'] = $email;
		$param['mobile'] = $telPhone;
		$param['domainName'] = $domainName;
		$param['domainPrice'] = $price;
		$param['domainMessage'] = '';
		$param['type'] = $trideType; // 经纪
		$param['userId'] = $enameId; // 买家
		$param['enameId'] = $postData['senameid']; // 卖家
		$param['paymode'] = $paytype;
		$param['fromHost'] = $fromHost;
		$param['groupOne'] = $domain['domainSysOne'];
		$param['groupTwo'] = $domain['domainSysTwo'];
		$param['domainLen'] = $domain['domainLength'];
		$param['domainTLD'] = $tld;
		$param['userName'] = $linkman;
		$param['contactus'] = $postData['contactOther'];
		$param['opposite'] = $postData['oppositeOther'];
		$param['percentage'] = $escrowPercentage[$trideType];
		$this->lib->addEscrowLib($param);
	}

	/**
	 * 详情
	 *
	 * @param unknown $enameId        	
	 * @param unknown $esid        	
	 * @return boolean multitype:string Ambigous <string, unknown> Ambigous <string, mixed> Ambigous <multitype:, unknown> Ambigous <multitype:>
	 */
	public function getEscrowInfo($enameId, $esid)
	{
		$escrowMod = new \models\trans\EscrowMod();
		$escrowInfo = $escrowMod->escrowInfo($esid);
		if(!$escrowInfo)
		{
			throw new \Exception(\common\Lang::create('escrowmsg')->getMsg('630020') , 630020);
		}
		else
		{
			$escrowContent = array();
			$escrowContent['ESID'] = $escrowInfo['ESID'];
			$escrowContent['Domainname'] = $escrowInfo['Domainname'] !=\common\Lang::create('escrowmsg')->getMsg('630027') ? \lib\trans\common\PublicDomainLib::replaceL($escrowInfo['Domainname']) : $escrowInfo['Note'];
			$escrowContent['FinalPrice'] = $escrowInfo['EscrowAttribute'] == 1? $this->lib->isShowPrice($enameId, 
				$escrowInfo['EscrowAttribute'], $escrowInfo['Role'], $escrowInfo['Purchaser'], $escrowInfo['Bargainor'], 
				$escrowInfo['Status'], $escrowInfo['SaleStatus'], $escrowInfo['BuyStatus'], $escrowInfo['FinalPrice']) :$escrowInfo['FinalPrice'];
			$escrowContent['CreateTime'] = $escrowInfo['CreateTime']? date("Y-m-d H:i:s", $escrowInfo['CreateTime']) :'';
			$escrowContent['AcceptTime'] = $escrowInfo['AcceptTime']? date("Y-m-d H:i:s", $escrowInfo['AcceptTime']) :'';
			$escrowContent['Note'] = $escrowInfo['Note'];
			
			if($escrowInfo['EscrowAttribute'] == 1 || $escrowInfo['EscrowAttribute'] == 3)
			{
				$escrowType = \common\Lang::create('escrowmsg')->getMsg('630002');
			}
			else
			{
				$escrowType = \common\Lang::create('escrowmsg')->getMsg('630003');
			}
			
			
			$tradeType = $this->getTradeType($escrowInfo, $enameId);
			
			if(2 > $escrowInfo['Status'])
			{
				$escrowStatus = \common\Lang::create('escrowmsg')->getMsg('630007');
				$status = '1';
			}
			else 
				if(2 == $escrowInfo['Status'])
				{
					if(1 == $escrowInfo['BuyStatus'] && 1 == $escrowInfo['SaleStatus'])
					{
						$escrowStatus = '双方已确认';
						$status = '9';
					}
					else 
						if(1 == $escrowInfo['BuyStatus'] && 0 == $escrowInfo['SaleStatus'])
						{
							if($escrowInfo['SendTime'] &&
								 (0 == $escrowInfo['SaleStatus'] && $enameId == $escrowInfo['Bargainor']))
							{
								$escrowStatus = \common\Lang::create('escrowmsg')->getMsg('630011'); // 卖家确认
								$status = '13';
							}
							else
							{
								$escrowStatus = \common\Lang::create('escrowmsg')->getMsg('630009');
								$status = '8';
							}
						}
						else 
							if(0 == $escrowInfo['BuyStatus'] && 1 == $escrowInfo['SaleStatus'])
							{
								if($escrowInfo['SendTime'] &&
									 (0 == $escrowInfo['BuyStatus'] && $enameId == $escrowInfo['Purchaser']))
								{
									$escrowStatus = \common\Lang::create('escrowmsg')->getMsg('630011');// 买家确认
									$status = '12';
								}
								else
								{
									$escrowStatus = \common\Lang::create('escrowmsg')->getMsg('630008');
									$status = '7';
								}
							}
							else
							{
								if($escrowInfo['SendTime'] &&
									 (0 == $escrowInfo['BuyStatus'] && $enameId == $escrowInfo['Purchaser']))
								{
									$escrowStatus = \common\Lang::create('escrowmsg')->getMsg('630011'); // 买家确认
									$status = '10';
								}
								else 
									if($escrowInfo['SendTime'] &&
										 (0 == $escrowInfo['SaleStatus'] && $enameId == $escrowInfo['Bargainor']))
									{
										$escrowStatus = \common\Lang::create('escrowmsg')->getMsg('630011'); // 卖家确认
										$status = '11';
									}
									else
									{
										$escrowStatus = \common\Lang::create('escrowmsg')->getMsg('630011');
										$status = '2';
									}
							}
				}
				elseif(3 == $escrowInfo['Status'])
				{
					$escrowStatus = \common\Lang::create('escrowmsg')->getMsg('630012');
					$status = '3';
				}
				elseif(4 == $escrowInfo['Status'])
				{
					$escrowStatus = \common\Lang::create('escrowmsg')->getMsg('630013');
					$status = '4';
				}
				elseif(5 == $escrowInfo['Status'])
				{
					$escrowStatus = \common\Lang::create('escrowmsg')->getMsg('630021');
					$status = '5';
				}
				else
				{
					$escrowStatus = \common\Lang::create('escrowmsg')->getMsg('630015');
					$status = '6';
				}
			
			$escrowContent['tradeType'] = $tradeType;
			$escrowContent['escrowType'] = $escrowType;
			$escrowContent['escrowStatus'] = $status;
			$escrowContent['escrowName'] = $escrowStatus;
			
			// 判断是否有权限查看,都不是买家卖家
			if($escrowInfo['Purchaser'] != $enameId && $escrowInfo['Bargainor'] != $enameId)
			{
				// 无权查看记录
				throw new \Exception(\common\Lang::create('escrowmsg')->getMsg('630022') , 630022);
			}
			// 获取卖家买家的联系方式
			$eContactMod = new \models\trans\escrowContactMod();
			$userInfo = $eContactMod->getContact($esid);
			// 当前是买家，取买家联系方式
			if($escrowInfo['Purchaser'] == $enameId)
			{
				if($escrowInfo['Role'] == 2)
				{
					$escrowContent['linkman'] = isset($userInfo['opposite_name']) ? $userInfo['opposite_name'] : '';
					$escrowContent['email'] = isset($userInfo['opposite_email']) ? $userInfo['opposite_email'] : '';
					$escrowContent['telPhone'] = isset($userInfo['opposite_mobile']) ? $userInfo['opposite_mobile'] : '';
					$escrowContent['phone'] = isset($userInfo['opposite_telphone'])&&$userInfo['opposite_telphone'] && $userInfo['opposite_telphone'] != '-'? $userInfo['opposite_telphone'] :'';
					$escrowContent['phone'] = trim($escrowContent['phone'], '-');
					$escrowContent['qq'] = empty($userInfo['opposite_qq'])? '' :$userInfo['opposite_qq'];
				}
				else
				{
					$escrowContent['linkman'] = isset($userInfo['name']) ? $userInfo['name'] : '';
					$escrowContent['email'] = isset($userInfo['email']) ? $userInfo['email'] : '';
					$escrowContent['telPhone'] = isset($userInfo['mobile']) ? $userInfo['mobile'] : '';
					$escrowContent['phone'] = isset($userInfo['telphone']) && $userInfo['telphone'] && $userInfo['telphone'] != '-'? $userInfo['telphone'] :'';
					$escrowContent['phone'] = trim($escrowContent['phone'], '-');
					$escrowContent['qq'] = empty($userInfo['qq'])? '' :$userInfo['qq'];
				}
			}
			// 当前是卖家，取卖家联系方式
			if($escrowInfo['Bargainor'] == $enameId)
			{
				if($escrowInfo['Role'] == 2)
				{
					$escrowContent['linkman'] = isset($userInfo['name']) ? $userInfo['name'] : '';
					$escrowContent['email'] = isset($userInfo['email']) ? $userInfo['email'] : '';
					$escrowContent['telPhone'] = empty($userInfo['mobile'])? '' :$userInfo['mobile'];
					$escrowContent['phone'] = isset($userInfo['telphone']) && $userInfo['telphone'] && $userInfo['telphone'] != '-'? $userInfo['telphone'] :'';
					$escrowContent['phone'] = trim($escrowContent['phone'], '-');
					$escrowContent['qq'] = empty($userInfo['qq'])? '' :$userInfo['qq'];
				}
				else
				{
					$escrowContent['linkman'] = empty($userInfo['opposite_name'])? '' :$userInfo['opposite_name'];
					$escrowContent['email'] = empty($userInfo['opposite_email'])? '' :$userInfo['opposite_email'];
					$escrowContent['telPhone'] = empty($userInfo['opposite_mobile'])? '' :$userInfo['opposite_mobile'];
					$escrowContent['phone'] = isset($userInfo['opposite_telphone']) && $userInfo['opposite_telphone'] && $userInfo['opposite_telphone'] != '-'? $userInfo['opposite_telphone'] :'';
					$escrowContent['phone'] = trim($escrowContent['phone'], '-');
					$escrowContent['qq'] = empty($userInfo['opposite_qq'])? '' :$userInfo['opposite_qq'];
				}
			}
			// 调用操作记录
			$eContactMod = new \models\trans\escrowContactMod();
			$escrowLog = $this->lib->getEscrowLog($esid);
			if($escrowLog === FALSE)
			{
				// 查询操作记录失败
				$escrowContent['logList'] = '';
			}
			else
			{
				$handlers = $this->lib->getAllMember();
				$newLog = array();
				foreach($escrowLog as $key => $value)
				{
					$newLog[$key]['Remark'] = $value['Remark'];
					if('域名过户成功' == $value['Remark'])
					{
						$value['Handler'] = $value['Distribution'];
					}
					if(4 == $value['status'])
					{
						$newLog[$key]['Remark'] = \common\Lang::create('escrowmsg')->getMsg('630013');
					}
					if(9 == $value['status'])
					{
						$newLog[$key]['Handler'] = \common\Lang::create('escrowmsg')->getMsg('630023');
					}
					elseif(10 == $value['status'])
					{
						$newLog[$key]['Handler'] = \common\Lang::create('escrowmsg')->getMsg('630024');
					}
					else
					{
						$newLog[$key]['Handler'] = isset($handlers[$value['Handler']])? $handlers[$value['Handler']] :$value['Handler'];
					}
					
					$newLog[$key]['CreateTime'] = date("Y-m-d H:i:s", $value['CreateTime']);
				}
				$escrowContent['logList'] = $newLog;
			}
			return $escrowContent;
		}
	}

	/**
	 * 经纪中介详情
	 *
	 * @param unknown $data        	
	 * @return multitype:unknown number string Ambigous <multitype:>
	 */
	public function escrowSure($data)
	{
		$id = ReturnData::$info->id;
		$enameId = ReturnData::$info->enameid;
		return $this->lib->getEscrowSure($enameId, $id);
	}

	/**
	 * 买家确认
	 *
	 * @param unknown $data        	
	 * @return boolean
	 */
	public function escrowBuySure($data)
	{
		$id = ReturnData::$info->id;
		$enameId = ReturnData::$info->enameid;
		return $this->lib->escrowBuySure($enameId, $id);
	}

	/**
	 * 卖家确认
	 *
	 * @param unknown $data        	
	 * @return boolean
	 */
	public function escrowSellerSure($data)
	{
		$enameId = ReturnData::$info->enameid;
		$id = ReturnData::$info->id;
		return $this->lib->escrowSellerSure($enameId, $id);
	}
	
	public function getAgentByEnameIds($enameIds)
	{
		$enameIdArr = explode(',',$enameIds);
		$eCrmMod = new \models\trans\EscrowCrmMod();
		return $eCrmMod->getAgentByEnameIds($enameIdArr);
	}
	
	public function getTradeType($info,$enameId)
	{
		$tradeType = '';
		if($info['Purchaser'] == $enameId)
		{
			$tradeType = \common\Lang::create('escrowmsg')->getMsg('630005');
		}
		elseif($info['Bargainor'] == $enameId)
		{
			$tradeType = \common\Lang::create('escrowmsg')->getMsg('630006');
		}
		elseif($info['Role'] == 1)
		{
			$tradeType = \common\Lang::create('escrowmsg')->getMsg('630005');
		}
		else
		{
			$tradeType = \common\Lang::create('escrowmsg')->getMsg('630006');
		}
		
		return $tradeType;
	}
}
?>
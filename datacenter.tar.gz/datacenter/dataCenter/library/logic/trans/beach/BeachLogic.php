<?php
namespace logic\trans\beach;

use core\Response;
class BeachLogic
{

	private $conf;

	private $lib;

	private $version;

	private $finishDate;

	private $noticeTime;

	private $cnClassConf;

	private $beachConf;

	private $enameId;

	public function __construct($version = 1, $enameId = 0)
	{
		// 加载配置
		if($version == 8)
		{
			$versionStr = 'beach';
		}
		else
		{
			$versionStr = 'top';
		}
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', $versionStr);
		$this->lib = new \lib\trans\beach\BeachLib($enameId);
		$this->version = $version;
		$this->beachConf = $this->conf->beach_conf->toArray();
		$this->cnClassConf = $this->beachConf['class'];
		$this->noticeTime = $this->beachConf['qq_notice_time'];
		$this->finishDate = date('Y-m-d') . " " . $this->beachConf['cnnic_finish_time'];
	}

	public function indexLogic()
	{
		// 首页
		$perPage = $this->conf->toArray()['cn_per_class_num'];
		$limit = array(0,$perPage);
		$data = $this->lib->getDomainByClass($limit, '', '', 0, $this->version);
		$count = $data['count'];
		$data = $data['domainList'];
		// 获取客户端点赞前4个域名
		$transLogic = new \logic\trans\trans\TransLogic();
		$getTopParam = array(
			'ver' => $this->version
		);
		if($this->version == 8)
		{
			$topDomainList = $transLogic->getTopCnDomainList((object)$getTopParam);
		}
		$domainList = array();
		if($data)
		{
			$domainList[1] = $data[1];
			if($this->version == 8)
			{
				$domainList[0] = $topDomainList;
			}
			$data = array_slice($data, 1, count($data));
			$i = 2;
			foreach($data as $k => $v)
			{
				$domainList[$i] = $v;
				$i ++;
			}
		}
		// 1期违约域名（分类Id是15）
		$DomainArr = $this->lib->getDomainByClass(8, 15, '', 0, 1, true);
		$renegeDomain = $DomainArr['domainList'];
		return array('domainList' => $domainList,'classConf' => $this->cnClassConf,'version' => $this->version,'count'=>$count);
	}

	public function addLogic()
	{
		$transAuditList = new \models\trans\AuditListMod();
		$specialAuctionId = $this->conf->trans_transtopic->specialauction->toArray()[0];
		$domainCount = $transAuditList->getAuditNum($specialAuctionId);
		$beachConf = $this->conf->toArray();
		$limit = $beachConf['beach_conf']['limit'];
		$domainCount = $domainCount * 2 + rand(0, 1) + $beachConf['beach_constant'];
		return array('domainCount' => $domainCount,'limit' => $limit);
	}

	public function moreLogic($data)
	{
		$cid = isset($data->cid) && $data->cid? $data->cid :0;
		$domainName = $data->domainname;
		$p = isset($data->p) && $data->p > 0? $data->p :1;
		$perPage = $cid || $domainName === ''? 10 :$this->conf->toArray()['cn_per_class_num'];
		if($this->version == 8)
		{
			$perPage = $cid ? 10 :$this->conf->toArray()['cn_per_class_num'];
		}
		$limit[0] = ($p - 1) * $perPage;
		$limit[1] = $perPage;
		$flag = 0;
		$countList = array();
		$condition = array();
		if($this->version == 8)
		{
			$domaintld = $data->domaintld;
			$type = $data->type;
			$rs['domainname'] = $domainName ? $domainName : '';
			$rs['domaintld'] = $data->domaintld ? $data->domaintld : 0;
			$rs['type'] = $data->type ? $data->type : 0;
			$condition = $this->makeCondition($type, $domaintld);
			
		}
		if($domainName !== '' || $this->version == 8)
		{
			if($cid)
			{
				$data = $this->lib->getSearchByName($domainName, $limit, $cid, 0, $this->version, $condition);
			}
			else
			{
				$data = $this->lib->getSearchByName($domainName, $limit, 0, 0, $this->version, $condition);
				$countList = $data['count'];
				$flag = 1;
			}
		}
		else
		{
			if($cid)
			{
				$data = $this->lib->getDomainByClass($limit, $cid, '', 0, $this->version,false, $condition);
			}
			else
			{
				$data = $this->lib->getDomainList($limit, 0, '', $this->version, $condition);
			}
		}
		$rs['domainList'] = $data['domainList'];
		$rs['p'] = $p;
		$rs['classConf'] = $this->cnClassConf;
		$rs['flag'] = $flag;
		$rs['cid'] = $cid;
		$rs['domainName'] = $domainName;
		$rs['countList'] = $countList;
		$rs['perPage'] = $perPage;
		return $rs;
	}
	
	public function makeCondition($type,$domaintld)
	{
		$condition = array('sql'=>array(),'data'=>array(),'type'=>'');
		$domainLen = 0;
		if($type)
		{
			$configs = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
			$conf = $configs->ts_domaingroup->toArray();
			$temp = $conf[$type];
			if(isset($temp['start']))
			{
				$sysGroupOne = array($temp['start'],$temp['end']);
				$sysGroupTwo = '';
				if(isset($temp['len']))
				{
					$domainLen = $temp['len'];
				}
			}
			elseif(isset($temp['sysone']))
			{
				$sysGroupOne = $temp['sysone'];
				$sysGroupTwo = '';
			}
			elseif(isset($temp['systwo']))
			{
				$sysGroupTwo = $temp['systwo'];
				$sysGroupOne = '';
			}
			//sysGroupOne
			if($sysGroupOne)
			{
				if(is_array($sysGroupOne))
				{
					$condition['sql'][] = "SysGroupOne Between ? AND ?";
					$condition['type'] .= 'ii';
					$condition['data'][] = $sysGroupOne[0];
					$condition['data'][] = $sysGroupOne[1];
				}
				else
				{
					$condition['sql'][] = "SysGroupOne = ?";
					$condition['type'] .= 'i';
					$condition['data'][] = $sysGroupOne;
				}
		
			}
			//sysGroupTwo
			if($sysGroupTwo)
			{
				$condition['sql'][] = "SysGroupTwo = ?";
				$condition['type'] .= 'i';
				$condition['data'][] = $sysGroupTwo;
			}
			if($domainLen)
			{
				$condition['sql'][] = "DomainLen=?";
				$condition['type'] .= 'i';
				$condition['data'][] = $domainLen;
			}
		}
		if($domaintld)
		{
			if($domaintld == 2)
			{
				$domaintld .= ',6';
				$condition['sql'][] = "DomainTLD IN (?,?)";
				$condition['type'] .= 'ii';
				$condition['data'][] = 2;
				$condition['data'][] = 6;
			}
			else
			{
				$condition['sql'][] = "DomainTLD IN (?)";
				$condition['type'] .= 'i';
				$condition['data'][] = $domaintld;
			}
		}
		return $condition;
	}
}
?>
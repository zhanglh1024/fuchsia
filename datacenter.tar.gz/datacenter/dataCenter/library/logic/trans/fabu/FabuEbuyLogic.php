<?php

namespace logic\trans\fabu;

use core\Response;
class FabuEbuyLogic extends \logic\trans\fabu\FabuSpecialLogic
{

	private $conf;

	private $enameId;

	public function __construct($enameId)
	{
		parent::__construct($enameId);
		// 加载配置
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
		$this->enameId = $enameId;
	}

	/**
	 * 易拍易卖结束的日期最长可以是一周
	 * 从当前时间加一天的时间算起，如当前时间是2014-07-09，那么
	 * 可选择的竞价发布日期是从2014-07-10～2014-07-16
	 *
	 * @param unknown $transDate        	
	 */
	public function checkTransDate($transDate)
	{
		if(!in_array($transDate, array(1,2,3,4,5,6,7)))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610042'),610042);
		}
	}

	/**
	 * 易拍易卖交易结束时间段是当天的
	 * 8:00-8:59 , 9:00-9:59，.......22:00-22:59
	 *
	 * @param unknown $transTime        	
	 */
	public function checkTransTime($transTime)
	{
		if(!in_array($transTime, array(8,9,10,11,12,13,14,15,16,17,18,19,20,21,22)))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610043'),610043);
		}
	}

	/**
	 * 检查价格
	 *
	 * @param unknown $transMoney        	
	 * @throws \Exception
	 */
	public function checkTransMoney($transMoney)
	{
		if($transMoney > 1)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610046'),610046);
		}
	}

	/**
	 * 检测简介
	 *
	 * @param unknown $transDesc        	
	 */
	public function checkSimpleDesc($transDesc)
	{}

	/**
	 * 检查经纪人
	 *
	 * @param unknown $agent        	
	 * @throws \Exception
	 */
	public function checkAgent($agent)
	{
		
		// 加载配置
		$fabuLib = new \lib\trans\fabu\FabuLib($this->enameId);
		$agentConf = $fabuLib->getAgentConf(1,1);
		//$agentConf = array_keys($this->conf->fabu_agent->toArray());
		if($agent && !in_array($agent, $agentConf))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610047'),610047);
		}
	}

	/**
	 * 验证数据
	 *
	 * @param unknown $data        	
	 */
	public function checkPostData($data)
	{
		$this->checkTransDate($data->transdate);
		$this->checkTransTime($data->transtime);
		$this->checkTransMoney($data->transmoney);
		$this->checkSimpleDesc($data->transdesc);
		$this->checkAgent($data->agent);
	}

	/**
	 * 获取交易数据
	 * @param Object $data
	 * @param int $sellerOrderId
	 * @param array $wData
	 * @return array
	 */
	public function getTransData($data,$sellerOrderId,$wData)
	{
		//加载配置
		$typeConf = $this->conf->trans_transtype->toArray();
		$auditStatusConf = $this->conf->fabu_audit_status->toArray();
		$afterAuditConf = $this->conf->fabu_after_audit->toArray();
		$transTopicConf = $this->conf->fabu_transtopic->toArray();
		
		//获取参数
		$domainName = $data->domainname;
		$transDesc = $data->transdesc;
		$register = $data->register;
		$transDay = $data->transdate;
		$transPoundage = $data->transpoundage;
		$transTime = $data->transtime;
		$agent = $data->agent;
		$fabuLib = new \lib\trans\fabu\FabuLib($this->enameId);
		$data = array();
		$data = $fabuLib->getPublicTransData($domainName, $transDesc, $register, $sellerOrderId, $transDay, 
			$transPoundage, $transTime);
		$data['transType'] = $typeConf['auction'][0]; // 出售方式
		$data['agent'] = $agent;
		$data['auditer'] = 0; // 审核人ID
		$data['auditDate'] = date("Y-m-d H:i:s");
		$data['auditStatus'] = $auditStatusConf['noAudit'][0];
		$data['afterAudit'] = $afterAuditConf['caneltrans'][0];
		$data['transTopic'] = $transTopicConf['ebuy'][0];
		$data['topic'] = 0;
		$data['askingPrice'] = 1; // 起拍价
		$data['reservePrice'] = 0; // 保留价
		$data['bidPrice'] = 1; // 当前价格
		
		$data['weight'] = 0;
		
		return $data;
	}
	
	/**
	 * 检测进入审核条件
	 * @param unknown $transData
	 */
	public function checkSpecialCondition($transData)
	{
		//对比直接通过条件
		$ckCdt = $this->checkPassCondition($transData);
		if($ckCdt['result']==TRUE)
			return $ckCdt;
		//对比进入审核条件
		$flag = FALSE;
		$auditCdt = $this->getAuditCondition($transData['transTopic']);
		if($auditCdt)
		{
			foreach ($auditCdt AS $v)
			{
				if($v['GroupOne'] && $v['GroupOne']!=$transData['sysGroupOne'])
					continue;
				if($v['GroupTwo'] && $v['GroupTwo']!=$transData['sysGroupTwo'])
					continue;
				if($v['DomainLen'] && $v['DomainLen']!=$transData['domainLength'])
					continue;
				if($v['DomainTld'] && $v['DomainTld']!=$transData['TLDIndex'])
					continue;
				$topicId = $v['TopicId'];
				$flag = TRUE;
				break;
			}
		}
		if($flag)
		{
			//易拍易卖，设置TopicId（自动归类）
			$transData['topic'] = $topicId;
			return array('result'=>TRUE, 'data'=>$transData);
		}
		//不满足发布易拍易卖条件
		$fabuFalseTypeConf = $this->conf->fabu_false_type->toArray();
		\core\Log::write("InEname,addAgentDomain,".$transData['domainName'].','.$this->enameId,'trans','fabu');
		return array('result'=>FALSE, 'msg'=>$fabuFalseTypeConf['ebuyConditionFalse'][1]);
	}
	/**
	 * 添加特殊交易redis
	 * @param array $data
	 * @param int $transTopic
	 * @return boolean
	 */
	public function addSpecialRedis($data, $transTopic, $domain=array())
	{
		if ($data ['sysGroupOne'] > 0 && $data ['sysGroupOne'] < 101)
			$group = 'number';
		elseif ($data ['sysGroupOne'] > 100 && $data ['sysGroupOne'] < 201)
		$group = 'string';
		else
			$group = 'other';
	
		$domain ['AuditListId'] = $data ['auditListId'];
		$domain ['DomainName'] = $data ['domainName'];
		$domain ['BidPrice'] = $data ['bidPrice'];
		$domain ['FinishDate'] = $data ['finishDate'];
		$domain ['Seller'] = $data['seller'];
		$domain ['SimpleDec'] = $data['summary'];
		$domain ['BidCount'] = 0;
		$domain ['TransType'] = $data['transType'];
		\core\Log::write("addSpecialRedis,Data,".$data['summary'],'trans','fabu');
	
		$FinishDateFlag = date('Y-m-d', strtotime($data['finishDateFlag']));
		$TIsdk = new \models\trans\redis\TransIndex();
		if(!$TIsdk->setSpecialTransRedis ( $transTopic, $data ['auditListId'], $data ['topic'], $group, $FinishDateFlag, $domain))
		\core\Log::write("FABU2",'trans','fabu');
		return TRUE;
	}
	/**
	 * 设置redis
	 * @param array $transData
	 * @return boolean
	 */
	public function setSpecialRedis($transData)
	{
		return $this->addSpecialRedis($transData, 'ebuy');
	}
	/**
	 * 删除首页特殊交易redis
	 * @param int $transTopic
	 * @return boolean
	 */
	public function delSpecailRedisIndex()
	{
		$TIsdk = new \models\trans\redis\TransIndex();
		return $TIsdk->delEbuyListIndex();
	}
}
?>
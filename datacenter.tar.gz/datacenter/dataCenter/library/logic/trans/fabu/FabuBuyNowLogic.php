<?php
namespace logic\trans\fabu;

use core\Response;
class FabuBuyNowLogic extends \logic\trans\fabu\FabuNormalLogic
{

	private $enameId;
	private $conf;

	public function __construct($enameId)
	{
		parent::__construct($enameId);
		$this->enameId = $enameId;
		// 加载配置
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
	}

	/**
	 * 一口价的时间
	 * 1天，3天，7天，15天,1个月,2个月,3个月
	 *
	 * @param unknown $transDate        	
	 */
	public function checkTransDate($transDate)
	{
		if(!in_array($transDate, array(1,3,7,15,30,60,90)))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610042'),610042);
		}
	}

	/**
	 * 一口价交易结束时间段是当天的
	 * 8:00-8:59 , 9:00-9:59，.......22:00-22:59
	 *
	 * @param unknown $transTime        	
	 */
	public function checkTransTime($transTime)
	{
		if(!in_array($transTime, array(8,9,10,11,12,13,14,15,16,17,18,19,20,21,22)))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610043'),610043);
		}
	}

	public function checkSimpleDesc($simpleDesc)
	{
		return true;
	}
	public function checkTransMoney($transMoney)
	{
		if(intval($transMoney) == 0)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610045'),610045);
		}
	}
	public function checkPostData($data)
	{
		$this->checkTransDate($data->transdate);
		$this->checkTransTime($data->transtime);
		$this->checkSimpleDesc($data->transdesc);
		$this->checkTransMoney($data->transmoney);
	}

	/**
	 * 获取交易数据
	 * @param Object $data
	 * @param int $sellerOrderId
	 * @param array $wData
	 * @return array
	 */
	public function getTransData($data, $sellerOrderId, $wData)
	{
		//加载配置
		$typeConf = $this->conf->trans_transtype->toArray();
		$auditStatusConf = $this->conf->fabu_audit_status->toArray();
		$afterAuditConf = $this->conf->fabu_after_audit->toArray();
		$transTopicConf = $this->conf->fabu_transtopic->toArray();
		
		
		//获取参数
		$domainName = $data->domainname;
		$transDesc = $data->transdesc;
		$register = $data->register;
		$transDay = $data->transdate;
		$transPoundage = $data->transpoundage;
		$transTime = $data->transtime;
		$transMoney = $data->transmoney;
		
		$fabuLib = new \lib\trans\fabu\FabuLib($this->enameId);
		$data = array();
		$data = $fabuLib->getPublicTransData($domainName, $transDesc, $register, $sellerOrderId, $transDay, 
			$transPoundage, $transTime);
		$data['transType'] = $typeConf['buynow'][0]; // 出售方式
		$data['auditer'] = $this->conf->fabu_default_auditer; // 审核人ID
		$data['auditDate'] = date("Y-m-d H:i:s");
		$data['auditStatus'] = $auditStatusConf['auditPass'][0];
		$data['afterAudit'] = $afterAuditConf['caneltrans'][0];
		$data['transTopic'] = $transTopicConf['notopic'][0];
		$data['topic'] = 0;
		$data['askingPrice'] = $transMoney; // 起拍价
		$data['reservePrice'] = 0; // 保留价
		$data['bidPrice'] = $transMoney; // 当前价格
		                                                       
		// 获取交易权重
		$wLib = new \lib\trans\fabu\FabuWeightLib($this->enameId);
		$data['weight'] = $wLib->getWeight($data['TLDIndex'], $data['sysGroupOne'], $data['sysGroupTwo'], 
			$data['domainLength'], $data['transTopic'], $data['isEnameDomain'], $wData['grade'], $wData['rate'], 
			$wData['dealRate'], $wData['dealCnt'], $wData['entropy'], $data['askingPrice'], $data['domainSLD']);
		
		return $data;
	}
	
	/**
	 * 获取计算权重的相关数据
	 */
	public function getWeightData()
	{
		$wLib = new \lib\trans\fabu\FabuWeightLib($this->enameId);
		//卖家信用和好评率
		$user = $wLib->getUserLevel();
		$data['grade'] = $user['grade'];
		$data['rate'] = $user['rate'];
		//交易成交率
		$data['dealRate'] = $wLib->getDealRate();
		//近30天成交数量
		$data['dealCnt'] = $wLib->getRecentlyDealCnt();
		//熵增
		$data['entropy'] = $wLib->getEntropy();
		return $data;
	}
}
?>
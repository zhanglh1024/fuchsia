<?php
namespace logic\trans\fabu;

use core\Response;
class FabuInquiryLogic extends \logic\trans\fabu\FabuNormalLogic
{

	private $conf;
	private $enameId;

	public function __construct($enameId)
	{
		// 加载配置 
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
		parent::__construct($enameId);
		$this->enameId = $enameId;
	}

	/**
	 * 检查是否正在交易（非我司）
	 * @param string $domainName        	
	 * @return multitype:boolean NULL |multitype:boolean
	 */
	public function isOnSale($domainName)
	{
		// 获取配置
		$fabuFalseTypeConf = $this->conf->fabu_false_type->toArray();
		$InquiryStatusConfig = $this->conf->inquiry_status->toArray();
		$InquiryMod = new \models\trans\InquiryMod();
		if($InquiryMod->getIsReleaseInquiry($this->enameId, $domainName, $InquiryStatusConfig['onsale'][0]))
			return array('result' => TRUE,'msg' => $fabuFalseTypeConf['isReleaseInquiry'][1]);
		return array('result' => FALSE);
	}

	/**
	 * 询价交易结束日期为
	 * 1个月，2个月，3个月，6个月，1年，2年
	 * 
	 * @param unknown $transDate        	
	 * @throws \Exception
	 */
	public function checkTransDate($transDate)
	{
		if(!in_array($transDate, array(30,60,90,180,365,730)))
		{
			throw new \Exception('交易结束日期出错',610001);
		}
	}

	/**
	 * 询价交易结束时间段是当天的
	 * 8:00-8:59 , 9:00-9:59，.......22:00-22:59
	 * 
	 * @param int $transTime        	
	 */
	public function checkTransTime($transTime)
	{
		if(!in_array($transTime, array(8,9,10,11,12,13,14,15,16,17,18,19,20,21,22)))
		{
			throw new \Exception('交易结束时间段出错',610002);
		}
	}

	/**
	 * 验证简介
	 * 
	 * @param unknown $transDesc        	
	 * @return boolean
	 */
	public function checkSimpleDesc($transDesc)
	{
		return true;
	}
	public function checkTransMoney($transMoney)
	{
		if(intval($transMoney) == 0)
		{
			throw new \Exception('价格不能为空',610018);
		}
	}
	public function checkPostData($data)
	{
		$this->checkSimpleDesc($data->transdesc);
		$this->checkTransMoney($data->transmoney);
	}
	
	/**
	 * 获取交易数据
	 */
	/**
	 * 获取交易数据
	 * @param Object $data
	 * @param int $sellerOrderId
	 * @param array $wData
	 * @return array
	 */
	public function getTransData($data, $sellerOrderId, $wData)
	{
		//获取参数
		$typeConf = $this->conf->trans_transtype->toArray();
		$auditStatusConf 	= $this->conf->fabu_audit_status->toArray();
		$afterAuditConf = $this->conf->fabu_after_audit->toArray();
		$transTopicConf = $this->conf->fabu_transtopic->toArray();
		
		//获取参数
		$domainName = $data->domainname;
		$transDesc = $data->transdesc;
		$register = $data->register;
		$transDay = $data->transdate;
		$transPoundage = $data->transpoundage;
		$transTime = $data->transtime;
		$transMoney = $data->transmoney;
		
		$fabuLib = new \lib\trans\fabu\FabuLib($this->enameId);
		$data = array();
		$data = $fabuLib->getPublicTransData($domainName, $transDesc, $register, $sellerOrderId, $transDay,$transPoundage,$transTime);
		$data['transType']		 = $typeConf['inquiry'][0];					//出售方式
		$data['auditer']		 	 = $this->conf->fabu_default_auditer;					//审核人ID
		$data['auditDate']		 = date("Y-m-d H:i:s");
		$data['auditStatus']	 = $auditStatusConf['auditPass'][0];
		$data['afterAudit'] 	 = $afterAuditConf['caneltrans'][0];
		$data['transTopic']	 = $transTopicConf['notopic'][0];
		$data['topic']			 = 0;
		$data['askingPrice'] = $transMoney;			//起拍价
		$data['reservePrice']= 0;				//保留价
		$data['bidPrice']	 = $transMoney;			//当前价格
		$data['weight'] = 0;
	
		return $data;
	}
	
	/**
	 * 锁定域名
	 * @param string $domainName
	 * @return boolean
	 */
	public function lockDomain($domainName)
	{
		return TRUE;
	}
	
	/**
	 * 冻结保证金
	 * @param unknown $domainName
	 * @return boolean|Ambigous <boolean, unknown>
	 */
	public function freezeMargin($domainName, $seller)
	{
		return 0;
	}
	
	/**
	 * 写入询价表
	 * @param array $transData
	 * @return multitype:boolean |multitype:boolean NULL
	 */
	public function addTrans($transData)
	{
		$TIsdk = new \models\trans\InquiryMod();
		$data = array();
		$fabuFalseTypeConf = $this->conf->fabu_false_type->toArray();
		$InquiryStatusConfig = $this->conf->inquiry_status->toArray();
		$now = date("Y-m-d H:i:s");
		$data['AuditListId'] = $transData['auditListId'];
		$data['DomainName'] = $transData['domainName'];
		$data['InquiryDay'] = $transData['forSaleLife'];
		$data['InquiryPrice'] = $transData['bidPrice'];
		$data['Poundage'] = $transData['poundage'];
		
		$data['DomainSLD'] = $transData['domainSLD'];
		$data['DomainTLD'] = $transData['TLDIndex'];
		$data['DomainLen'] = $transData['domainLength'];
		$data['SimpleDec'] = $transData['summary'];
		
		$data['IsDomainInEname'] = $transData['isEnameDomain'];
		$data['DeadTime'] = $transData['deadTime'];
		$data['ClassName'] =  $transData['className'];
		$data['SysGroupOne'] = $transData['sysGroupOne'];
		$data['SysGroupTwo'] = $transData['sysGroupTwo'];
		$data['SubmitDate'] = $transData['submitDate'];
		
		$data['Seller'] = $this->enameId;
		$data['InquiryStatus'] = $InquiryStatusConfig['onsale'][0];
		$data['SellerIp'] = \common\Common::getRequestIp();
		
		$data['CreateDate'] = $now;
		$data['FinishDate'] = date("Y-m-d H:i:s",
			strtotime("+" . $data['InquiryDay'] . " day", strtotime($data['CreateDate'])));
		$pLib = new \lib\trans\common\PublicLib();
		$ymd = $pLib->YearMonthDay(strtotime($data['FinishDate']));
		$data['FinishYear'] = $ymd[0];
		$data['FinishMonth'] = $ymd[1];
		$data['FinishDay'] = $ymd[2];
		
		$data['FinishDateFlag'] = date("Y-m-d",
			strtotime("+" . $data['InquiryDay'] . " day", strtotime($data['CreateDate'])));
		$data['LastChangeDate'] = $now;
		$inquiryId = $TIsdk->addInquiryModel($data);
		if($inquiryId)
			return array('result'=>TRUE);
		\core\Log::write("FALSE,addAuctionDomain,".$transData['domainName'].','.$this->enameId,'trans','fabu');
		return array('result'=>FALSE, 'msg'=>$fabuFalseTypeConf['addTableFalse'][1]);
	}
	
	/**
	 * 获取域名到期时间
	 * @param array $enameDomains
	 * @param array $notEnameDomains
	 * @return multitype:string unknown
	 */
	public function getDomainDeadDate($enameDomains, $notEnameDomains)
	{
		$data = array();
		$domains = new \interfaces\trans\Domains();
		if($enameDomains)
		{
			foreach ($enameDomains as $v)
			{
				$domainDate = $domains->getDomainDate($v['domain']);
				$data[$v['domain']] = $domainDate['expDate'];	//域名到期时间
			}
		}
		if($notEnameDomains)
		{
			foreach ($notEnameDomains as $v)
			{
				$whois = $domains->getWhoisBase($v['domain']);
				$data[$v['domain']] = !empty($whois['ExpirationDate']) ? $whois['ExpirationDate'] : '';
			}
		}
		return $data;
	}
	
	public function addAuditDomain($transData)
	{
		return 0;
	}
}
?>
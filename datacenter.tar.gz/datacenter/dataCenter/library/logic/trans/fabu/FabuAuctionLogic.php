<?php
namespace logic\trans\fabu;
use core\Response;
class FabuAuctionLogic extends \logic\trans\fabu\FabuNormalLogic
{
	private $enameId;
	private $conf;
	public $transType;

	public function __construct($enameId)
	{
		$this->enameId = $enameId;
		parent::__construct($enameId);
		// 加载配置
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'trans');
	}

	/**
	 * 竞价结束的日期最长可以是一周
	 * 从当前时间加一天的时间算起，如当前时间是2014-07-09，那么
	 * 可选择的竞价发布日期是从2014-07-10～2014-07-16
	 *
	 * @param unknown $transDate        	
	 */
	public function checkTransDate($transDate)
	{
		if(!in_array($transDate, array(1,2,3,4,5,6,7)))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610042'),610042);
		}
	}

	/**
	 * 竞价交易结束时间段是当天的
	 * 8:00-8:59 , 9:00-9:59，.......22:00-22:59
	 *
	 * @param unknown $transTime        	
	 */
	public function checkTransTime($transTime)
	{
		if(!in_array($transTime, array(8,9,10,11,12,13,14,15,16,17,18,19,20,21,22)))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610043'),610043);
		}
	}

	function getvalidmoney($money, $edage, $rang)
	{
		$validPrice = array();
		$edage = $edage + 1;
		$i = intval(($money - $edage) / $rang);
		$before = $edage + $rang * $i;
		$after = $edage + $rang * ($i + 1);
		$validPrice[0] = $before;
		$validPrice[1] = $after;
		return $validPrice;
	}

	function rowMoneyRank($rowmoney)
	{
		$validPrice = array();
		$priceArray = array(9999,4999,999,499,49,-1);
		$addArray = array(500,200,100,50,10,1);
		$i = 0;
		foreach($priceArray as $k => $v)
		{
			if($rowmoney > $v)
			{
				$i = $k;
				break;
			}
		}
		$validPrice = $this->getvalidmoney($rowmoney, $priceArray[$i], $addArray[$i]);
			
		$str = sprintf(\common\Lang::create('transmsg')->getMsg('610044'),$priceArray[$k], $addArray[$k],$validPrice[0],$validPrice[1]);
		throw new \Exception($str,610044);
	}

	public function checkTransMoney($transMoney)
	{
		
		if(intval($transMoney) == 0)
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610045'),610045);
		}
		$bad = false;
		$priceArray = array(9999,4999,999,499,49,-1);
		$addArray = array(500,200,100,50,10,1);
		$i = 0;
		foreach($priceArray as $k => $v)
		{
			if($transMoney > $v)
			{
				break;
			}
		}
		$add = $addArray[$k];
		if($transMoney % $add != 0)
		{
			$bad = true;
		}
		
		if($bad)
		{
			$this->rowMoneyRank($transMoney);
		}
	}

	public function checkSimpleDesc($transDesc)
	{}

	/**
	 * 验证数据
	 *
	 * @param unknown $data        	
	 */
	public function checkPostData($data)
	{
		// 获取参数
		$transDate = intval($data->transdate);
		$transTime = $data->transtime;
		$transMoney = intval($data->transmoney);
		
		$this->checkTransDate($transDate);
		$this->checkTransTime($transTime);
		$this->checkTransMoney($transMoney);
	}

	/**
	 * 获取交易数据
	 * @param Object $data        	
	 * @param int $sellerOrderId        	
	 * @param array $wData        	
	 * @return array
	 */
	public function getTransData($data, $sellerOrderId, $wData)
	{
		// 加载配置
		$typeConf = $this->conf->trans_transtype->toArray();
		$auditStatusConf = $this->conf->fabu_audit_status->toArray();
		$afterAuditConf = $this->conf->fabu_after_audit->toArray();
		$transTopicConf = $this->conf->fabu_transtopic->toArray();
		
		// 获取参数
		$domainName = $data->domainname;
		$transDesc = $data->transdesc;
		$register = $data->register;
		$transDay = $data->transdate;
		$transPoundage = $data->transpoundage;
		$transTime = $data->transtime;
		$transMoney = $data->transmoney;
		
		$fabuLib = new \lib\trans\fabu\FabuLib($this->enameId);
		$data = array();
		$data = $fabuLib->getPublicTransData($domainName, $transDesc, $register, $sellerOrderId, $transDay, 
			$transPoundage, $transTime);
		$data['transType'] = $typeConf['auction'][0]; // 出售方式
		$data['auditer'] = $this->conf->fabu_default_auditer; // 审核人ID
		$data['auditDate'] = date("Y-m-d H:i:s");
		$data['auditStatus'] = $auditStatusConf['auditPass'][0];
		$data['afterAudit'] = $afterAuditConf['caneltrans'][0];
		$data['transTopic'] = $transTopicConf['notopic'][0];
		$data['topic'] = 0;
		$data['askingPrice'] = $transMoney; // 起拍价
		$data['reservePrice'] = 0; // 保留价
		$data['bidPrice'] = $transMoney; // 当前价格
		$data['weight'] = 0;
		return $data;
	}
}
?>
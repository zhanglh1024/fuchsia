<?php
namespace logic\trans\fabu;

class FabuNiceLogic
{

	private $conf;
	private $enameId;

	public function __construct($enameId)
	{
		// 加载配置 
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'beach');
		$this->enameId = $enameId;
	}

	/**
	 * 获取还能发布域名的可用时间
	 */
	public function getCanPublicDate()
	{
		$config = $this->conf->beach_conf->toArray()['range'];
		$max_num = $this->conf->beach_conf->toArray()['everyday_max_number'];
		$startPublicTime = $this->conf->beach_conf->toArray()['submitTime'];
		
		if(time() < strtotime($startPublicTime['start']) || time() > strtotime($startPublicTime['end']))
		{
			throw new \Exception(\common\Lang::create('transmsg')->getMsg('610113'), 610113);
		}
		// 开始拍卖时间和结束拍卖时间
		$start = time() < strtotime($config['start'])? $config['start']: date('Y-m-d');
		$end = $config['end'];
		
		// 如果当前时间大于发布的结束时间,就不显示今天
		if(date('H:i') > $config['endhmi'])
		{
			$start = date('Y-m-d', strtotime('+1 days', strtotime($start)));
		}
		
		// 计算时差
		$datetime1 = new \DateTime($start);
		$datetime2 = new \DateTime($end);
		$interval = $datetime1->diff($datetime2);
		$interval = $interval->format('%a');
		
		$dateList = array();
		for($i = 0; $i <= $interval; $i ++)
		{
			$dateList[$i] = date('Y-m-d', (strtotime("+{$i} days", strtotime($start))));
		}
		$dateSelect['list'] = $dateList;
		$dateSelect['range'] = array();
		if($dateList)
		{
			$startHour = explode(':', $config['starhmi']);
			$endHour = explode(":", $config['endhmi']);
			$len = $endHour[0] - $startHour[0];
			for($i = 0; $i <= $len; $i ++)
			{
				$dateSelect['range'][$i] = $startHour[0] + $i . ":" . $startHour[1];
				$dateSelect['range'][$i] .= '-' . ($startHour[0] + $i) . ":" . $endHour[1];
			}
		}
		else
		{
			// 所有发布时间都已经满额
			throw new \EXception('本次活动支持发布的域名数量已达上限，请您期待下一季');
		}
		return $dateSelect;
	}
	public function checkDomainClass($domains)
	{
		if($domains)
		{
			$flag = FALSE;
			$unpass = $pass = array();
			$pDomainLib = new \lib\trans\common\PublicDomainLib();
			$domainInter = new \interfaces\trans\Domains();
			foreach($domains as $domain)
			{
				$info = $domainInter->getDomainGroup($domain);
				$tld = $pDomainLib->getDomainClassAll($domain);
				if($info['domainSysOne'] == 101)
				{
					//字母
					if(in_array($tld, array(2,3)))
					{
						if($info['domainLength'] == 1 || $info['domainLength'] == 2 ||
						in_array($info['domainSysTwo'], array(1,2)))
						{
							$flag = true;
						}
					}
				}
				elseif(in_array($info['domainSysOne'], array(1,2,3)) && in_array($tld, array(1,2,3,4)))
				{
					// 是否是数字
					$config = $this->conf->beach_conf->toArray()['condition'];
					foreach($config as $v)
					{
						if(is_array($v['DomainLen']))
						{
							if(!in_array($info['domainLength'], $v['DomainLen']))
								continue;
						}
						else
						{
							if($v['DomainLen'] != $info['domainLength'])
								continue;
						}
						if(is_array($v['DomainLen']))
						{
							if(!in_array($tld, $v['DomainTld']))
								continue;
						}
						else
						{
							if($v['DomainTld'] != $tld)
								continue;
						}
						$flag = TRUE;
						break;
					}
				}
				if($flag)
					$pass[] = $domain;
				else
					$unpass[] = array('domain' => $domain,'msg' => '不符合本次精品数字拍卖会规则');
			}
			return array($pass,$unpass);
		}
		throw new \Exception('提交的域名不符合要求');
	}
	public function checkRule($domainName)
	{
		$unpass = array();
		return array($domainName,$unpass);
	}
	public function checkDomainSubed($domains)
	{
		$beachConf = $this->conf->beach_conf->toArray();
		$unpass = $pass = array();
		$TCDsdk = new \models\trans\CnSaveDomainMod();
		foreach($domains as $domain)
		{
			if($TCDsdk->checkIsBeach($domain, $beachConf['version']))
			{
				$unpass[] = array('domain' => $domain,
						'msg' => str_replace('%', $beachConf['version'],
							\common\Lang::create('transmsg')->getMsg('610114')));
			}
			else
			{
				$pass[] = $domain;
			}
		}
		return array($pass,$unpass);
	}
	/**
	 * 检查和归类域名
	 *
	 * @param array $domainNames
	 * @return array
	 */
	public function checkUserDomains($domainNames)
	{
		$inEname = array();
		$notUsers = array();
		$notInEname = array();
		$domainsInter = new \interfaces\trans\Domains();
		foreach($domainNames as $domainName)
		{
			// 检查域名是否属用户
			$rs = $domainsInter->getDomainForUser($this->enameId, $domainName);
			if($rs['result'])
			{
				\core\Log::write("$domainName,$this->enameId,".json_encode($rs),'trans','fabubeach');
				$inEname[] = $domainName;
				continue;
			}
			else
			{
				// 检查域名是否在易名
				$rs = $domainsInter->getDomainUs($domainName);
				if($rs['result'])
				{
					\core\Log::write("fabu,inEname,NotUserDomains,$domainName,$this->enameId".json_encode($rs),'trans','fabubeach');
					$notUsers[] = array('domain' => $domainName,
							\common\Lang::create('transmsg')->getMsg('610115'));
				}
				else
				{
					// 非我司域名
					\core\Log::write("FABU,InEname,NotInEnameDomains,$domainName,$this->enameId",'trans','fabubeach');
					$notInEname[] = array('domain' => $domainName,
							'msg' => \common\Lang::create('transmsg')->getMsg('610116'));
				}
			}
		}
		return array($inEname,$notUsers,$notInEname);
	}
	public function getDomainInfo($domainName)
	{
		$domainArr = explode('.', $domainName);
		$data['domainSLD'] = $domainArr[0]; // 二级域名(域名主体)
		$pDomainLib = new \lib\trans\common\PublicDomainLib();
		$data['TLDIndex'] = $pDomainLib->getDomainClassAll($domainName); // 顶级域名（域名后缀）
		$domainInter = new \interfaces\trans\Domains();
		$groupType = $domainInter->getDomainGroup($domainName);
		$data['className'] = $groupType['domainClass']; // 域名类型
		$data['sysGroupOne'] = $groupType['domainSysOne']; // 域名分组一
		$data['sysGroupTwo'] = $groupType['domainSysTwo']; // 域名分组二
		$data['domainLength'] = $groupType['domainLength']; // 域名长度
		$data['domainName'] = $domainName;
	
		return $data;
	}
	public function getBeachClass($domainName)
	{
		$domainName = is_array($domainName)? $domainName :array($domainName);
	
		$pLib = new \lib\trans\common\PublicLib();
		$beachConf = $this->conf->beach_conf->toArray();
		$classConf = $pLib->covertArray($beachConf['class'], 0);
		$classNameConf = $pLib->covertArray($beachConf['class'], 1);
		$classify = array();
		foreach($domainName as $domain)
		{
			$transData = $this->getDomainInfo($domain);
			$topic = $this->checkSpecialCondition($transData, 1);
			$classify[$domain] = $topic != -1? isset($classConf[$topic - 1])? $classNameConf[$topic - 1] :'未知' :'未知';
		}
	
		return $classify;
	}
	/**
	 * 检测进入审核条件
	 *
	 * @param unknown $transData
	 */
	public function checkSpecialCondition($transData, $flg = 0)
	{
		// 对比进入审核条件
		$flag = FALSE;
		$topicId = 0;
		// 是否是数字
		if($transData['sysGroupOne'] == 101)
		{
			if(in_array($transData['TLDIndex'], array(2,3)))
			{
				if($transData['domainLength'] == 1 || $transData['domainLength'] == 2 ||
				in_array($transData['sysGroupTwo'], array(1,2)))
				{
					$flag = true;
					$topicId = 1;
				}
			}
		}
		elseif(in_array($transData['sysGroupOne'], array(1,2,3)))
		{
			$config = $this->conf->beach_conf->toArray()['condition'];
			foreach($config as $v)
			{
				if(is_array($v['DomainLen']))
				{
					if(!in_array($transData['domainLength'], $v['DomainLen']))
						continue;
				}
				else
				{
					if($v['DomainLen'] != $transData['domainLength'])
						continue;
				}
				if(is_array($v['DomainLen']))
				{
					if(!in_array($transData['TLDIndex'], $v['DomainTld']))
						continue;
				}
				else
				{
					if($v['DomainTld'] != $transData['TLDIndex'])
						continue;
				}
				$topicId = $v['TopicId'];
				$flag = TRUE;
				break;
			}
		}
		if($flg)
		{
			return $flag? $topicId :-1;
		}
		if($flag)
		{
			// 设置TopicId（自动归类）
			$transData['topic'] = $topicId;
			return array('result' => TRUE,'data' => $transData);
		}
		// 不满足发布平价域名条件
		$fabuFalseTypeConf = $this->conf->fabu_false_type->toArray();
		\core\Log::write("FABU,InEname,addAgentDomain,".$transData['domainName'].','.$this->enameId,'trans','fabubeach');
		return array('result' => FALSE,'msg' => $fabuFalseTypeConf['parityConditionFalse'][1]);
	}
	
	public function checkPostData($data)
	{
		$dateSelect = $this->getCanPublicDate();
		if(!in_array($data['transDate'], $dateSelect['list']) || !in_array($data['transTime'],$dateSelect['range']))
		{
			return false;
		}
	}
	/**
	 * 获取交易数据
	 * @param Object $data
	 * @param int $sellerOrderId
	 * @param array $wData
	 * @return array
	 */
	public function getTransData($data, $sellerOrderId, $wData)
	{
		// 加载配置
		$typeConf = $this->conf->trans_transtype->toArray();
		$auditStatusConf = $this->conf->fabu_audit_status->toArray();
		$afterAuditConf = $this->conf->fabu_after_audit->toArray();
		$transTopicConf = $this->conf->fabu_transtopic->toArray();
	
		// 获取参数
		$domainName = $data->domainname;
		$transDesc = $data->transdesc;
		$register = $data->register;
		$transDay = $data->transdate;
		$transPoundage = $data->transpoundage;
		$transTime = $data->transtime;
		$transMoney = $data->transmoney;
	
		$fabuLib = new \lib\trans\fabu\FabuLib($this->enameId);
		$data = array();
		$data = $fabuLib->getPublicTransData($domainName, $transDesc, $register, $sellerOrderId, $transDay,
			$transPoundage, $transTime);
		$data['transType'] = $typeConf['auction'][0]; // 出售方式
		$data['auditer'] = $this->conf->fabu_default_auditer; // 审核人ID
		$data['auditDate'] = date("Y-m-d H:i:s");
		$data['auditStatus'] = $auditStatusConf['auditPass'][0];
		$data['afterAudit'] = $afterAuditConf['caneltrans'][0];
		$data['transTopic'] = $transTopicConf['notopic'][0];
		$data['topic'] = 0;
		$data['askingPrice'] = $transMoney; // 起拍价
		$data['reservePrice'] = 0; // 保留价
		$data['bidPrice'] = $transMoney; // 当前价格
		$data['weight'] = 0;
		return $data;
	}
}
?>
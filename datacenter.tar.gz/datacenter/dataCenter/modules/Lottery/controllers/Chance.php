<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class ChanceController extends Yaf\Controller_Abstract
{

	/**
	 * 添加抽奖机会
	 */
	public function addChanceAction()
	{
		try
		{
			form\lottery\lottery\ChanceForm::addChance();
			if(ReturnData::$success)
			{
				$randLogic = new \logic\lottery\lottery\ChanceLogic();
				if($res = $randLogic->CreatChance(ReturnData::$info))
				{
					Response::success($res);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 统计用户抽奖机会
	 */
	public function getCountAction()
	{
		try
		{
			form\lottery\lottery\ChanceForm::getCount();
			if(ReturnData::$success)
			{
				$randLogic = new \logic\lottery\lottery\ChanceLogic();
				if($res = $randLogic->getChanceCount(ReturnData::$info))
				{
					Response::success($res);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 更新抽奖机会
	 */
	public function updateChanceAction()
	{
		try
		{
			form\lottery\lottery\ChanceForm::updateChance();
			if(ReturnData::$success)
			{
				$randLogic = new \logic\lottery\lottery\ChanceLogic();
				if($res = $randLogic->updateChance(ReturnData::$info))
				{
					Response::success('更新成功');
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 使用抽奖机会(没有传id取一条最快过期的)
	 */
	public function useChanceAction()
	{
		try
		{
			form\lottery\lottery\ChanceForm::useChance();
			if(ReturnData::$success)
			{
				$randLogic = new \logic\lottery\lottery\ChanceLogic();
				if($res = $randLogic->useChance(ReturnData::$info))
				{
					Response::success('更新成功');
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
}

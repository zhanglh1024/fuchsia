<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class RecordController extends Yaf\Controller_Abstract
{

	/**
	 * 获取抽奖记录表
	 */
	public function getRecordAction()
	{
		try
		{
			if(isset($_GET['setin']))
			{
				$_GET['setin'] = json_decode($_GET['setin']);
			}
			form\lottery\lottery\RandCodeForm::checkRecord();
			if(ReturnData::$success)
			{
				$randLogic = new \logic\lottery\lottery\RecordLogic();
				$res = $randLogic->getRecordList(ReturnData::$info);
				if($res['flag'])
				{
					Response::success($res);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 抽奖排行榜统计
	 */
	public function getRecordTopAction()
	{
		try
		{
			form\lottery\lottery\RecordForm::getRecordTop();
			if(ReturnData::$success)
			{
				$reordLogic = new \logic\lottery\lottery\RecordLogic();
				$res = $reordLogic->getRecordTop(ReturnData::$info);
				Response::success($res);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 修改抽奖记录
	 */
	public function updateRecordAction()
	{
		try
		{
			form\lottery\lottery\RecordForm::updateRecord();
			if(ReturnData::$success)
			{
				$reordLogic = new \logic\lottery\lottery\RecordLogic();
				if($res = $reordLogic->updateRecord(ReturnData::$info))
				{
					Response::success('更新成功');
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
}

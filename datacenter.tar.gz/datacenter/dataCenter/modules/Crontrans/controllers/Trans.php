<?php

class TransController extends Yaf\Controller_Abstract
{
	public function arrangeDataAndSendSmsAction()
	{
		try
		{
			set_time_limit(0);
			$logic = new \logic\trans\crontab\CronTrans();
			$logic->arrangeData();
			$logic->sendSms();
		}
		catch(\Exception $e)
		{
			echo $e->getMessage() . "\n";
		}
	}

	/**
	 * 更新众筹交易的状态，并处理扣款和退款
	 */
	public function endZcDomainsAction()
	{
		try
		{
			set_time_limit(0);
			$logic = new \logic\trans\crontab\CronZc();
			$logic->endZcDomains();
		}
		catch(\Exception $e)
		{
			echo $e->getMessage()."\n";
		}
	}
	
	/**
	 * 处理众筹开奖结果，更新主表和记录表状态
	 */
	public function doZcLotteryAction()
	{
		try
		{
			set_time_limit(0);
			$logic = new \logic\trans\crontab\CronZc();
			$logic->doZcLottery();
		}
		catch (\Exception $ex)
		{
			echo $ex->getMessage();
		}
	}

}

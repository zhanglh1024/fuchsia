<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;
class BuyerController extends Yaf\Controller_Abstract
{
	private $logic;
	
	/**
	 * 我出价域名
	 */
	public function userBidsAction()
	{
		try
		{
			\form\trans\buyer\BuyerForm::userBid();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\buyer\BuyerLogic();
				$data = $this->logic->userBid(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch (FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch (Exception $e)
		{
			Response::msg($e->getMessage(),$e->getCode());
		}
	}
}
?>
<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;
class EscrowController extends Yaf\Controller_Abstract
{

	/**
	 * 发布中介交易
	 */
	public function addAgencyAction()
	{
		try
		{
			\form\trans\escrow\EscrowForm::addAgencyForm();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\escrow\EscrowLogic(ReturnData::$info->enameid);
				$this->logic->addAgencyLogic(ReturnData::$info);
				Response::success('提交成功');
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 经纪中介列表
	 */
	public function escrowListAction()
	{
		try
		{
			\form\trans\escrow\EscrowForm::listForm();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\escrow\EscrowLogic();
				$data = $this->logic->listLogic(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 添加经纪
	 */
	public function addEscrowAction()
	{
		try
		{
			\form\trans\escrow\EscrowForm::addEscrow();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\escrow\EscrowLogic();
				$data = $this->logic->addEscrowLogic(ReturnData::$info);
				Response::success('提交成功');
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}

	public function escrowSureAction()
	{
		try
		{
			\form\trans\escrow\EscrowForm::escrowSure();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\escrow\EscrowLogic();
				$data = $this->logic->escrowSure(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	public function escrowBuySureAction()
	{
		try
		{
			\form\trans\escrow\EscrowForm::escrowSure();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\escrow\EscrowLogic();
				$data = $this->logic->escrowBuySure(ReturnData::$info);
				Response::success('操作成功');
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	public function escrowSellerSureAction()
	{
		try
		{
			\form\trans\escrow\EscrowForm::escrowSure();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\escrow\EscrowLogic();
				$data = $this->logic->escrowSellerSure(ReturnData::$info);
				Response::success('操作成功');
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 经纪中介详情
	 */
	public function infoAction()
	{
		try
		{
			\form\trans\escrow\EscrowForm::info();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\escrow\EscrowLogic();
				$param = ReturnData::$info;
				$data = $this->logic->getEscrowInfo($param->enameid, $param->id);
				Response::success($data);
			}
		}
		catch (FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch (Exception $e)
		{
			Response::error($e->getMessage(),$e->getCode());
		}
	}
	/**
	 * 通过enameid 获取专属经纪人
	 */
	public function getAgentByEnameIdAction()
	{
		try
		{
			\form\trans\escrow\EscrowForm::getAgentByEnameId();
			if(ReturnData::$success)
			{
				$param = ReturnData::$info;
				$this->logic = new \logic\trans\escrow\EscrowLogic();
				$data = $this->logic->getAgentByEnameIds($param->enameids);
				Response::success($data);
			}
		}
		catch (FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch (Exception $e)
		{
			Response::error($e->getMessage(),$e->getCode());
		}
	}
}
?>
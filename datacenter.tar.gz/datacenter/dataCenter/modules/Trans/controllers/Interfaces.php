<?php

use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class InterfacesController extends \Yaf\Controller_Abstract
{ 

	private $logic;

	/**
	 * 获取域名注册信息(注册商和注册者) 
	 */
	public function getDomainRegInfoAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::regInfoForm();
			if(ReturnData::$success)
			{
				$data = ReturnData::$info;
				$this->logic = new interfaces\trans\Domains();
				$rs = $this->logic->regInfo($data->domain);
				Response::success($rs);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 发送短信验证码
	 */
	public function sendMobileSmsCaptchaAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::sendCaptcha();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\UserCaptcha();
				$info['EnameId'] = ReturnData::$info->enameid;
				$info['smsconfig'] = empty(ReturnData::$info->smsconfig) ? 'transConfig' : ReturnData::$info->smsconfig;
				$info['purpose'] = ReturnData::$info->purpose;
				$rs = $this->logic->sendMobileSmsCaptcha((object)$info);
				Response::success($rs);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 发送语音验证码
	 */
	public function sendMobileVoiceCaptchaAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::sendCaptcha();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\UserCaptcha();
				$info['EnameId'] = ReturnData::$info->enameid;
				$info['smsconfig'] = 'transConfig';
				$info['purpose'] = ReturnData::$info->purpose;
				$rs = $this->logic->sendMobileVoiceCaptcha((object)$info);
				Response::success($rs);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 检查域名是否未被注册
	 */
	public function checkIsUnRegAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::checkIsUnReg();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Domains();
				$data = $this->logic->checkIsUnReg(ReturnData::$info->domain);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	public function getWhoisBaseHaveEmailAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::checkDomain();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Domains();
				$data = $this->logic->getWhoisBaseHaveEmail(ReturnData::$info->domain);
				if(! empty($data['WhoisInfo']))
				{
					$data['WhoisInfo'] = htmlspecialchars($data['WhoisInfo']);
				}
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	public function getWhoisBaseAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::checkDomain();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Domains();
				$data = $this->logic->getWhoisBase(ReturnData::$info->domain);
				if(isset($data['result']) && $data['result'] == false)
				{
					throw new \Exception(Response::getErrMsg(), Response::getErrCode());
				}
				else
				{
					if(! empty($data['WhoisInfo']))
					{
						$data['WhoisInfo'] = htmlspecialchars($data['WhoisInfo']);
					}
					Response::success($data);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取用户信息
	 */
	public function getUserInfoAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::checkEnameId();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Member();
				$data = $this->logic->getMemberInfoByEnameId(ReturnData::$info->enameid);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 检查是否是Godday域名
	 */
	public function isGdDomainAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::checkDomain();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Domains();
				if($this->logic->checkIsGdDomain(ReturnData::$info->domain))
				{
					Response::success(true);
				}
				else
				{
					throw new \Exception(Response::getErrMsg(), Response::getErrCode());
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 锁定域名
	 */
	public function lockDomainAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::lockDomain();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Domains();
				if($this->logic->lockDomain(ReturnData::$info->domain, ReturnData::$info->remark))
				{
					Response::success(true);
				}
				else
				{
					throw new \Exception(Response::getErrMsg(), Response::getErrCode());
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 添加客服预警
	 */
	public function addSecureWarningAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::addSecureWarning();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Member();
				$data = $this->logic->addSecureWarning(ReturnData::$info->enameid, ReturnData::$info->businesstype, 
					ReturnData::$info->domain, ReturnData::$info->content, ReturnData::$info->priority, 
					ReturnData::$info->ip, ReturnData::$info->ext, ReturnData::$info->createdate);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 批量查询域名
	 */
	public function domainBatchRegistQueryAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::domainBatchRegistQuery();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Domains();
				$rs = $this->logic->domainBatchRegistQuery(ReturnData::$info);
				Response::success($rs);
			}
			Response::error('域名格式有误');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 是否手机绑定
	 */
	public function isBindMobileAction()
	{ 
		try
		{
			\form\trans\interfaces\InterfacesForm::isBindMobile();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Member();
				if($this->logic->isBindMobile(ReturnData::$info->enameid))
				{
					Response::success(true);
				}
				else
				{
					throw new \Exception(Response::getErrMsg(), Response::getErrCode());
				}
			}
			Response::error('域名格式有误');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 第一次出价获取随机码
	 */
	public function creatCodeAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::creatCode();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Lottery();
				Response::success(
					$this->logic->creatCode(ReturnData::$info->enameid, ReturnData::$info->transid, 
						ReturnData::$info->domain, ReturnData::$info->bidtime));
			}
			Response::error('获取随机码有误');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 第一个出价获得抽奖机会
	 */
	public function addChanceAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::addChance();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Lottery();
				Response::success(
					$this->logic->addChance(ReturnData::$info->enameid, ReturnData::$info->time, 
						ReturnData::$info->domain));
			}
			Response::error('添加出价抽奖失败');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取域名是不是我司
	 */
	public function getDomainUsAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::getDomainUs();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Domains();
				$data = $this->logic->getDomainUs(ReturnData::$info->domain);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取域名的状态
	 */
	public function getDomainStatusAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::getDomainUs();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Domains();
				$data = $this->logic->getdomainstatusnew(ReturnData::$info->domain);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取域名的分组
	 */
	public function getDomainGroupAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::getDomainGroup();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Domains();
				$data = $this->logic->getDomainGroup(ReturnData::$info->domain);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 卖家回复报价->发送信息给买家
	 */
	public function sendReplyMessAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::sendSellerReplyMess();
			if(ReturnData::$success)
			{
				$userInterfaces = new \interfaces\trans\UserCaptcha();
				$rs = $userInterfaces->getOperateData(ReturnData::$info->noticeCode, ReturnData::$info->enameId);
				if($rs['mobile'] && $rs['mobileType'])
				{
					$sms = true;
				}
				$iMessageLib = new \lib\trans\trans\InquiryMessageLib(True, True, $sms);
				// 卖家报价
				if(ReturnData::$info->flag == 1)
				{
					$data = array('Buyer'=> ReturnData::$info->enameId,'DomainName'=> ReturnData::$info->domain,
							'SellerPrice'=> ReturnData::$info->price,'OperateDate'=> date("Y-m-d H:i:s"),
							'URL'=> 'http://www.ename.com/inquiry/buyerReplyInfo/' . ReturnData::$info->replyId,
							'id'=> ReturnData::$info->replyId);
					$iMessageLib->sellerReply($data);
					Response::success('卖家回复报价,发送信息给买家成功!');
				}
				// 买家出价
				if(ReturnData::$info->flag == 2)
				{
					$data = array('Seller'=> ReturnData::$info->enameId,'DomainName'=> ReturnData::$info->domain,
							'Price'=> ReturnData::$info->price,'OperateDate'=> date("Y-m-d H:i:s"),
							'URL'=> 'http://www.ename.com/inquiry/sellerReplyInfo/' . ReturnData::$info->replyId,
							'id'=> ReturnData::$info->replyId);
					$iMessageLib->buyerReply($data);
					Response::success('买家出价,发送信息给卖家成功!');
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 卖家同意报价->发送信息给买家
	 */
	public function sendAgreeMessAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::sendSellerReplyMess();
			if(ReturnData::$success)
			{
				$userInterfaces = new \interfaces\trans\UserCaptcha();
				$rs = $userInterfaces->getOperateData(ReturnData::$info->noticeCode, ReturnData::$info->enameId);
				if($rs['mobile'] && $rs['mobileType'])
				{
					$sms = true;
				}
				$iMessageLib = new \lib\trans\trans\InquiryMessageLib(True, True, $sms);
				// 卖家报价
				if(ReturnData::$info->flag == 1)
				{
					$data = array('DomainName'=> ReturnData::$info->domain,'Buyer'=> ReturnData::$info->enameId,
							'Margin'=> 50,'TransPrice'=> $info->price,'OperateDate'=> date("Y-m-d H:i:s"),
							'URL'=> 'http://www.ename.com/inquiry/buyerReplyInfo/' . ReturnData::$info->replyId,
							'id'=> ReturnData::$info->replyId);
					$iMessageLib->sellerAgree($data);
					Response::success('卖家同意报价,发送信息给买家成功!');
				}
				// 买家出价
				if(ReturnData::$info->flag == 2)
				{
					$data = array('Seller'=> ReturnData::$info->enameId,'DomainName'=> ReturnData::$info->domain,
							'Price'=> ReturnData::$info->price,'OperateDate'=> date("Y-m-d H:i:s"),
							'URL'=> 'http://www.ename.com/inquiry/sellerReplyInfo/' . ReturnData::$info->replyId,
							'id'=> ReturnData::$info->replyId);
					$iMessageLib->buyerReply($data);
					Response::success('买家出价,发送信息给卖家成功!');
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 询价 卖家回复报价->锁定域名
	 */
	public function lockInquiryDomainAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::lockInquiryDomain();
			if(ReturnData::$success)
			{
				$lib = new \lib\trans\trans\TransInquiryLib();
				$lib->checkDomainStatus(ReturnData::$info->domain); // 检测域名状态是否正常
				$lock = $lib->lockDomain(ReturnData::$info->domain); // 锁定域名
				Response::success($lock);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 询价 买家回复还价->解锁域名
	 */
	public function unlockInquiryDomainAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::lockInquiryDomain();
			if(ReturnData::$success)
			{
				$lib = new \lib\trans\trans\TransInquiryLib();
				$lock = $lib->unlockDomain(ReturnData::$info->domain); // 解锁域名
				Response::success($lock);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 询价 卖家回复报价->域名非我司 ,生成保证金订单
	 */
	public function createInquiryOrderAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::createInquiryOrder();
			if(ReturnData::$success)
			{
				$lib = new \lib\trans\trans\InquiryFinanceLib(ReturnData::$info->seller);
				$orderId = $lib->createOrder(ReturnData::$info->seller, ReturnData::$info->domain, 113, 50, 
					ReturnData::$info->buyer);
				Response::success($orderId);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 询价 买家回复还价->域名非我司 ,取消保证金订单
	 */
	public function cancelInquiryOrderAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::createInquiryOrder();
			if(ReturnData::$success)
			{
				$lib = new \lib\trans\trans\InquiryFinanceLib(ReturnData::$info->seller);
				$res = $lib->canelOrder(ReturnData::$info->seller, ReturnData::$info->orderId);
				Response::success($res);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 询价 卖家同意报价->操作保护数据验证
	 */
	public function checkUserOperateDataAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::inquiryOperation();
			if(ReturnData::$success)
			{
				$userCaptcha = new \interfaces\trans\UserCaptcha();
				$userCaptcha->checkOperateData((object)ReturnData::$info);
				Response::success('true');
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 判断我司域名是否是此人
	 */
	public function getDomainForUserAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::getDomainForUser();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Domains();
				$data = $this->logic->getDomainForUser(ReturnData::$info->enameid, ReturnData::$info->domain);
				Response::success($data);
			}
			Response::error('error');
		}
		catch (FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(),$e->getCode());
		}
	}
	
	/**
	 * 判断域名的状态
	 */
	public function domainStatusAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::getDomainStatus();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Domains();
				$data = $this->logic->getDomainStatus(ReturnData::$info->domain);
				Response::success($data);
			}
			Response::error('error');
		}
		catch (FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(),$e->getCode());
		}
	}
	
	/**
	 * 取消订单
	 */
	public function canelOrderAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::canelOrder();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Finance(ReturnData::$info->enameid);
				$data = $this->logic->canelOrder(ReturnData::$info->bookid, ReturnData::$info->enameid);
				Response::success($data);
			}
			Response::error('error');
		}
		catch (FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(),$e->getCode());
		}
	}
	/**
	 * 买家确认一口价交易->发送信息给买家
	 */
	public function buynowSuccessBuyerAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::buynowSuccessBuyer();
			if(ReturnData::$success)
			{
				$iMessageLib = new \lib\trans\trans\TransMessageLib(
						ReturnData::$info->buyer,
						ReturnData::$info->message ? true : false,
						ReturnData::$info->email ? true : false,
						ReturnData::$info->sms ? true : false);
				$data=array('domainName' => ReturnData::$info->domain,'id' => ReturnData::$info->id,'nowTime'=> ReturnData::$info->nowtime,'price'=> ReturnData::$info->price);
				$iMessageLib->trans_buynow_success_buyer($data);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 买家确认一口价交易->发送信息给卖家
	 */
	public function buynowSuccessSellerAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::buynowSuccessSeller();
			if(ReturnData::$success)
			{
				$iMessageLib = new \lib\trans\trans\TransMessageLib(
						ReturnData::$info->seller,
						ReturnData::$info->message ? true : false,
						ReturnData::$info->email ? true : false,
						ReturnData::$info->sms ? true : false);
				$data=array('domainName' => ReturnData::$info->domain,'id' => ReturnData::$info->id,'nowTime'=>ReturnData::$info->nowtime,'price'=>ReturnData::$info->price);
				$iMessageLib->trans_buynow_success_seller($data);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 买家确认一口价交易->发送信息给卖家 (域名不在易名)
	 */
	public function buynowSuccessSellerNoteNameAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::buynowSuccessSellerNoteName();
			if(ReturnData::$success)
			{
				$iMessageLib = new \lib\trans\trans\TransMessageLib(
						ReturnData::$info->seller,
						ReturnData::$info->message ? true : false,
						ReturnData::$info->email ? true : false,
						ReturnData::$info->sms ? true : false);
				$data=array('domainName' => ReturnData::$info->domain,'id' => ReturnData::$info->id,'createDate'=>ReturnData::$info->createdate,'nowTime'=>ReturnData::$info->nowtime,'price'=>ReturnData::$info->price);
				$iMessageLib->trans_buynow_success_seller_notename($data);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	public function checkIdEmailVerifyAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::checkIdEmailVerify();
			if(ReturnData::$success)
			{
				$interLib = new \interfaces\trans\Verify();
				$data = $interLib->getResultIdEmail(ReturnData::$info->enameId, ReturnData::$info->email);
				Response::success($data);
			}
			Response::error('form check error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	public function checkDnbbsAuthAction()
	{
		try 
		{
			\form\trans\interfaces\InterfacesForm::checkDnbbsAuth();
			if(ReturnData::$success)
			{
				$interLib = new \interfaces\trans\Verify();
				$data = $interLib->getDnbbsVerify(ReturnData::$info->enameId);
				Response::success($data);
			}
			Response::error('form check error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 0701 邮箱
	 */
	public function getEmailByEnameIdAction(){
		
		try
		{
			\form\trans\interfaces\InterfacesForm::getEmailByEnameId();
			if(ReturnData::$success)
			{
				$interLib = new \interfaces\trans\Verify();
				$data = $interLib->getEmailByEnameId(ReturnData::$info->enameId);
				Response::success($data);
			}
			Response::error('form check error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 若发送短信人工重试
	 */
	public function sendSmsRemindAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::sendSmsRemind();
			if(ReturnData::$success)
			{
				$interface = new \logic\trans\crontab\CronTrans();
				$rs = $interface->sendSmsRemind(ReturnData::$info);
				Response::success($rs);
			}
			Response::error(false);
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 新版交易有用到
	 * 发送预订通知
	 */
	public function sendBookMsgAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::sendBookMsg();
			if(ReturnData::$success)
			{
				$iMessageLib = new \lib\trans\trans\TransMessageLib(
						ReturnData::$info->enameId,
						ReturnData::$info->message ? true : false,
						ReturnData::$info->email ? true : false,
						ReturnData::$info->sms ? true : false);
				$data=array('title' => ReturnData::$info->title,'content' => base64_decode(ReturnData::$info->content),
					'getNum'=>ReturnData::$info->getNum,'auctionNum'=>ReturnData::$info->auctionNum,
					'enameId'=>ReturnData::$info->enameId);
				$res = $iMessageLib->sendBookMsg($data);
				Response::success($res);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	public  function checkKeyWordsAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::checkKeyWords();
			if(ReturnData::$success)
			{
				$interface = new \interfaces\bbs\Bbs();
				$rs = $interface->checkIsKeyWord(ReturnData::$info->word);
				Response::success($rs);
			}
			Response::error(false);
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 查询enameId在指定期间是否成功push过指定域名
	 */
	public function isHasPushDomainAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::isHasPushDomain();
			if(ReturnData::$success)
			{
				$start = \date('Y-m-d H:i:s', ReturnData::$info->start);
				$end = \date('Y-m-d H:i:s', ReturnData::$info->end);
				$ismanage = ReturnData::$info->ismanage ? true :false;
				$interface = new \interfaces\trans\Domains();
				$rs = $interface->isHasPushDomain(ReturnData::$info->domain, ReturnData::$info->enameId, $start, $end,$ismanage);
				Response::success($rs);
			}
			Response::error(false);
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 新版交易
	 * 获取交易发布提现和不可提现的设置
	 * 0 不可提现 1可提现
	 */
	public function getAcceptInfoAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::getAcceptInfo();
			if(ReturnData::$success)
			{
				$interface = new \interfaces\trans\Member();
				Response::success($interface->getAcceptInfo(ReturnData::$info->enameId));
			}
			Response::error(false);
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 新版交易
	 * 发送站内信
	 */
	public function sendSiteMsgAction()
	{
		try 
		{
			\form\trans\interfaces\InterfacesForm::sendSiteMsg();
			if(ReturnData::$success)
			{
				$queue = new \interfaces\trans\Queue();
				Response::success($queue->sendSiteMsg(ReturnData::$info->enameId, ReturnData::$info->templateId, json_decode($_POST['tplData'],true), ReturnData::$info->type));
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 新版交易
	 * 发送邮件
	 */
	public function sendMailAction()
	{
		try 
		{
			\form\trans\interfaces\InterfacesForm::sendMail();
			if(ReturnData::$success)
			{
				$queue = new \interfaces\trans\Queue();
				ReturnData::$info->priority = ReturnData::$info->priority ?: 5;
				Response::success($queue->sendMail(ReturnData::$info->templateId, ReturnData::$info->email,json_decode($_POST['tplData'],true), ReturnData::$info->enameId,ReturnData::$info->priority));
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 新版交易
	 * 发送短信
	 */
	public function sendSmsAction()
	{
		try 
		{
			\form\trans\interfaces\InterfacesForm::sendSms();
			if(ReturnData::$success)
			{
				$queue = new \interfaces\trans\Queue();
				ReturnData::$info->priority = ReturnData::$info->priority ?: 5;
				Response::success($queue->sendSms(ReturnData::$info->templateId, ReturnData::$info->phone, json_decode($_POST['tplData'],true), ReturnData::$info->enameId,ReturnData::$info->priority));
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	public function whoisRegisterCheckAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::checkDomain();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Domains();
				$data = $this->logic->whoisRegisterCheck(ReturnData::$info->domain);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 用户入款
	 */
	public function userFinanceInAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::userFinanceIn();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Finance(ReturnData::$info->enameId);
				$data = $this->logic->userFinanceIn(ReturnData::$info);
				Response::success('入款成功');
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 用户扣款
	 */
	public function userFinanceOutAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::userFinanceOut();
			if(ReturnData::$success)
			{
				$this->logic = new \interfaces\trans\Finance(ReturnData::$info->sendId);
				$data = $this->logic->userFinanceOut(ReturnData::$info);
				Response::success('扣款成功');
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
} 
?>
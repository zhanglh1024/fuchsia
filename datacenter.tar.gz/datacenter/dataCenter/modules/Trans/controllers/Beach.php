<?php
	use core\Response;
	use core\form\FormException;
	use core\form\ReturnData;
	class BeachController extends Yaf\Controller_Abstract
	{
		private $logic;
		private $conf;
		private $beachConf;
		private $beachVersion;
		
		public function indexAction()
		{
			try 
			{
				\form\trans\beach\BeachForm::index();
				if(ReturnData::$success)
				{
					$version = 0;
					if(ReturnData::$info->version)
					{
						$version = ReturnData::$info->version;
					}
					else
					{
						$version = $this->getBeachVersion();
					}
					$this->logic = new \logic\trans\beach\BeachLogic($version);
					$data = $this->logic->indexLogic();
					Response::success($data);
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (\Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		
		public function addAction()
		{
			try
			{
				$this->logic = new \logic\trans\beach\BeachLogic($this->getBeachVersion());
				$data = $this->logic->addLogic();
				Response::success($data);
			}
			catch (\Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		
		private function setBeachLogic()
		{
			$this->logic = new \logic\trans\beach\BeachLogic($this->getBeachVersion());
		}
		
		private function getBeachVersion()
		{
			// 加载配置
			$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/trans.ini', 'top');
			$this->beachConf = $this->conf->beach_conf->toArray();
			$this->beachVersion = $this->beachConf['version'];
			return $this->beachConf['version'];
		}
		
		public function moreAction()
		{
			try 
			{
				\form\trans\beach\BeachForm::more();
				if(ReturnData::$success)
				{
					$version = 0;
					if(ReturnData::$info->version)
					{
						$version = ReturnData::$info->version;
					}
					else
					{
						$version = $this->getBeachVersion();
					}
					$this->logic = new \logic\trans\beach\BeachLogic($version,ReturnData::$info->enameid);
					$data = $this->logic->moreLogic(ReturnData::$info);
					Response::success($data);
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (\Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
			
		}
	}
?>
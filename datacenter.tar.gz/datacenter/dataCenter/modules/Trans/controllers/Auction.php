<?php
	use core\Response;
	use core\form\FormException;
	use core\form\ReturnData;
	class AuctionController extends Yaf\Controller_Abstract
	{
		private $logic;
		
		/**
		 * 易拍易卖/专题拍卖域名列表
		 */
		public function topicAction()
		{
			try
			{
				\form\trans\auction\AuctionForm::topic();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\auction\AuctionLogic();
					$data = $this->logic->transTopic(ReturnData::$info);
					Response::success($data);
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		
		/**
		 * 竞价/一口价/询价
		 */
		public function typeAction()
		{
			try
			{
				\form\trans\auction\AuctionForm::type();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\auction\AuctionLogic();
					$data = $this->logic->transType(ReturnData::$info);
					Response::success($data);
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		/**
		 * 获取出价保证金和加价幅度
		 */
		public function getConfAction()
		{
			try
			{
				\form\trans\auction\AuctionForm::getConf();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\auction\AuctionLogic();
					$data = $this->logic->getConf(ReturnData::$info);
					Response::success($data);
				}
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		/**
		 * 获取竞价、询价和认购域名的详细信息
		 */
		public function domainAction()
		{
			try
			{
				\form\trans\auction\AuctionForm::domain();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\auction\AuctionLogic();
					$data = $this->logic->domain(ReturnData::$info);
					Response::success($data);
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}	
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}		
		}
		/**
		 * 询价详情
		 */
		public function inquiryAction()
		{
			try
			{
				\form\trans\auction\AuctionForm::inquiry();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\auction\AuctionLogic();
					$data = $this->logic->inquiry(ReturnData::$info);
					Response::success($data);
				}
				Response::error('error');
			} 
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		/**
		 * 竞价记录
		 */
		public function getBidRecordsAction()
		{
			try
			{
				\form\trans\auction\AuctionForm::getBidRecords();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\auction\AuctionLogic();
					$data = $this->logic->getBidRecords(ReturnData::$info);
					Response::success($data);
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		
		/**
		 * 保存自定义搜索
		 */
		public function addDiySearchAction()
		{
			try
			{
				\form\trans\auction\AuctionForm::addDiySearch();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\auction\AuctionLogic();
					$rs = $this->logic->addDiySearch(ReturnData::$info);
					if(isset($rs['flag'])&&$rs['flag'])
					{
						Response::success($rs['msg']);
					}
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		
		/**
		 * 自定义搜索列表
		 */
		public function getDiySearchAction()
		{
			try 
			{
				\form\trans\auction\AuctionForm::getDiySearch();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\auction\AuctionLogic();
					$data = $this->logic->getDiySearch(ReturnData::$info);
					Response::success($data);
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch(Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		/**
		 * 删除自定义搜索
		 */
		public function delDiySearchAction()
		{
			try 
			{
				\form\trans\auction\AuctionForm::delDiySearch();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\auction\AuctionLogic();
					$rs = $this->logic->delDiySearch(ReturnData::$info);
					if(isset($rs['flag'])&&$rs['flag'])
					{
						Response::success($rs['msg']);
					}
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
	}
?>
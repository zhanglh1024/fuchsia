<?php
	use core\Response;
	use core\form\FormException;
	use core\form\ReturnData;
	class SellerController extends \Yaf\Controller_Abstract
	{
		private $logic;
		
		/**
		 * 正在出售的域名
		 */
		public function onsaleAction()
		{
			try 
			{
				\form\trans\seller\SellerForm::onsale();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\seller\SellerLogic();
					$data = $this->logic->onsale(ReturnData::$info);
					Response::success($data);
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		/**
		 * 出售详细页面
		 */
		public function getOnsaleDetailAction()
		{
			try 
			{
				\form\trans\seller\SellerForm::getOnsaleDetail();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\seller\SellerLogic();
					$data = $this->logic->getOnsaleDetail(ReturnData::$info);
					Response::success($data);
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		
		/**
		 * 交易类型为拍卖的自定义标签
		 */
		public function getShopTagsAction()
		{
			try
			{
				\form\trans\seller\SellerForm::getShopTags();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\seller\SellerLogic();
					$data = $this->logic->getShopTags(ReturnData::$info);
					Response::success($data);
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		/**
		 * 域名设置标签
		 */
		public function setShopTagsAction()
		{
			try
			{
				\form\trans\seller\SellerForm::setShopTag();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\seller\SellerLogic();
					$rs = $this->logic->setShopTag(ReturnData::$info);					
					if(isset($rs['flag'])&&$rs['flag'])
					{
						Response::success($rs['msg']);
					}
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		/**
		 * 取消域名设置的标签
		 */
		public function cancelShopTagAction()
		{
			try
			{
				\form\trans\seller\SellerForm::setShopTag();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\seller\SellerLogic();
					$rs = $this->logic->cancelShopTag(ReturnData::$info);
					if(isset($rs['flag'])&&$rs['flag'])
					{
						Response::success($rs['msg']);
					}
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		/**
		 * 下架操作
		 */
		public function cancelTransAction()
		{
			try
			{
				\form\trans\seller\SellerForm::cancelTrans();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\seller\SellerLogic();
					$rs = $this->logic->cancelTrans(ReturnData::$info);
					if(isset($rs['flag'])&&$rs['flag'])
					{
						Response::msg($rs['msg'],$rs['code'],true);
					}
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch(Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		/**
		 * 批量下架
		 */
		public function cancelTransBatchAction()
		{
			try
			{
				\form\trans\seller\SellerForm::cancelTransBatch();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\seller\SellerLogic();
					$data = $this->logic->cancelTransBatch(ReturnData::$info);
					Response::success($data);
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
	}
?>
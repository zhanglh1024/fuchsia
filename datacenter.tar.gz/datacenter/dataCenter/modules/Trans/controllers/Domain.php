<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class DomainController extends \Yaf\Controller_Abstract
{ 
	private $logic;
	/**
	 * 询价 卖家回复报价->锁定域名
	 */
	public function lockInquiryDomainAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::lockInquiryDomain();
			if(ReturnData::$success)
			{
				$lib = new \lib\trans\trans\TransInquiryLib();
				$lib->checkDomainStatus(ReturnData::$info->domain); // 检测域名状态是否正常
				$lock = $lib->lockDomain(ReturnData::$info->domain); // 锁定域名
				Response::success($lock);
			}
			Response::error('error'); 
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 询价 买家回复还价->解锁域名
	 */
	public function unlockInquiryDomainAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::lockInquiryDomain();
			if(ReturnData::$success)
			{
				$lib = new \lib\trans\trans\TransInquiryLib();
				$lock = $lib->unlockDomain(ReturnData::$info->domain); // 解锁域名
				Response::success($lock);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 询价域名过户
	 */
	public function domainPushAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::domainPush();
			if(ReturnData::$success)
			{
				$domains = new \interfaces\trans\Domains();
				$unlockStatus = 1;
				$rs = $domains->setDomainMyStatus(ReturnData::$info->domain, $unlockStatus);
				if(! $rs['result'])
				{
					throw new \Exception($rs['msg'], $rs['code']);
				}
				$pushDomain = $domains->domainPush(ReturnData::$info->domain, ReturnData::$info->seller, 
					ReturnData::$info->buyer);
				if($pushDomain)
				{
					Response::success(True);
				}
				else
				{
					$lockStatus = 2;
					$rs = $domains->setDomainMyStatus(ReturnData::$info->domain, $lockStatus);
					if(! $rs['result'])
					{
						throw new \Exception($rs['msg'], $rs['code']);
					}
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 交易域名过户
	 */
	public function auctionDomainPushAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::auctionDomainPush();
			if(ReturnData::$success)
			{
				$domains = new \interfaces\trans\Domains();
				$pushDomain = $domains->domainPush(ReturnData::$info->domain, ReturnData::$info->seller,
					ReturnData::$info->buyer);
				if($pushDomain)
				{
					Response::success(TRUE);
				}
			}
			Response::error(Response::getErrMsg());
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	public function setDomainMyStatusAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::setDomainMyStatus();
			if(ReturnData::$success)
			{
				$domains = new \interfaces\trans\Domains();
				$rs = $domains->setDomainMyStatus(ReturnData::$info->domain, ReturnData::$info->status);
				if($rs['result'])
				{
					Response::success($rs);
				}
				Response::error($rs);
			}
			Response::error(FALSE);
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
		/**
		 * 获取域名系统分组和分类
		 */
		public function getDomainGroupAction()
		{
			try
			{
				\form\trans\domain\DomainForm::getDomainGroup();
				if(ReturnData::$success)
				{
					$this->logic = new \logic\trans\domain\DomainLogic();
					$data = $this->logic->getDomainGroup(ReturnData::$info);
					Response::success($data);
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
		
	/**
	 * 判断域名是否为用户所有
	 */
	public function getDomainForUserAction()
	{
		try
		{
			\form\trans\domain\DomainForm::getDomainForUser();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\domain\DomainLogic();
				$data = $this->logic->getDomainForUser(ReturnData::$info);
				Response::success($data);
			}
			Response::error(FALSE);
		}
		catch (FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch (Exception $e)
		{
			Response::msg($e->getMessage(),$e->getCode());
		}
	}
		/**
		 * 获取域名的enameId
		 */
		public function getDomainEnameIdAction()
		{
			try
			{
				\form\trans\domain\DomainForm::getDomainEnameId();
				if(ReturnData::$success)
				{
					$domains = new \interfaces\trans\Domains();
					$rs = $domains->getDomainEnameId(ReturnData::$info->domain);
					Response::success($rs);
				}
				Response::error('error');
			}
			catch(FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch(Exception $e)
			{
				Response::msg($e->getMessage(), $e->getCode());
			}
		}

	/**
	 * 域名过户
	 */
	public function domainPushTransAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::domainPush();
			if(ReturnData::$success)
			{
				$domains = new \interfaces\trans\Domains();
				$pushDomain = $domains->domainPush(ReturnData::$info->domain, ReturnData::$info->seller,
					ReturnData::$info->buyer,ReturnData::$info->isnewinter,ReturnData::$info->isLock);
				if($pushDomain)
				{
					Response::success($pushDomain);
				}
				Response::error(Response::getErrMsg(), Response::getErrCode());
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 获取域名的日期相关参数
	 *
	 * @param string $domainName        	
	 * @return unknown
	 */
	public function getDomainDateAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::getDomainDate();
			if(ReturnData::$success)
			{
				$domains = new \interfaces\trans\Domains();
				$domainData = $domains->getDomainDate(ReturnData::$info->domain);
				Response::success($domainData);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 获取域名的日期相关参数
	 *
	 * @param string $domainName
	 * @return unknown
	 */
	public function getDomainLtdAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::getDomainLtd();
			if(ReturnData::$success)
			{
				$domains = new \interfaces\trans\Domains();
				$domainData = $domains->getDomainLtd(ReturnData::$info->domain);
				Response::success($domainData);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	public function checkIsBlackDomainAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::checkIsBlackDomain();
			if(ReturnData::$success)
			{
				$domains = new \interfaces\trans\Domains();
				$domainData = $domains->isInBlackList(ReturnData::$info->enameIdOrDoamin);
				Response::success($domainData);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	public function setBatchDomainMyStatusAction()
	{
		try
		{
			\form\trans\interfaces\InterfacesForm::setBatchDomainMyStatus();
			if(ReturnData::$success)
			{
				$domains = new \interfaces\trans\Domains();
				$rs = $domains->setDomainMyStatus(ReturnData::$info->domain, ReturnData::$info->status);
				if($rs['result'])
				{
					Response::success($rs);
				}
				Response::error($rs);
			}
			Response::error(FALSE);
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}

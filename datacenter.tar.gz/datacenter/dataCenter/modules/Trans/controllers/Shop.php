<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;
Class ShopController extends \Yaf\Controller_Abstract
{
	private $logic;
	/**
	 * 关注店铺列表
	 */
	public function getShopFavoriteAction()
	{
		try
		{
			form\trans\shop\ShopForm::shopFavoriteList();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$data = $this->logic->getShopFavorite(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 删除关注店铺
	 */
	public function delShopFavoriteAction()
	{
		try
		{
			form\trans\shop\ShopForm::delShopFavorite();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$rs = $this->logic->delShopFavorite(ReturnData::$info);
				if(isset($rs['flag'])&&$rs['flag'])
				{
					Response::success($rs['msg']);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 添加关注店铺
	 */
	public function addShopFavoriteAction()
	{
		try
		{
			form\trans\shop\ShopForm::addShopFavorite();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$rs = $this->logic->addShopFavorite(ReturnData::$info);
				if(isset($rs['flag'])&&$rs['flag'])
				{
					Response::success($rs['msg']);
				}
			}

			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 店铺标签列表
	 */
	public function shopTagsListAction()
	{
		try
		{
			form\trans\shop\ShopForm::shopTagsList();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$data = $this->logic->ShopTagList(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 编辑标签
	 */
	public function getShopTagAction()
	{
		try
		{
			form\trans\shop\ShopForm::setShopTag();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$data = $this->logic->getShopTag(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 保存标签
	 */
	public function setSaveTagAction()
	{
		try
		{
			form\trans\shop\ShopForm::savetag();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$rs = $this->logic->saveTag(ReturnData::$info);
				if(isset($rs['flag'])&&$rs['flag'])
				{
					Response::success($rs['msg']);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 添加标签
	 */
	public function setAddShopTagAction()
	{
		try
		{
			form\trans\shop\ShopForm::setaddShopTag();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$rs = $this->logic->setAddShopTag(ReturnData::$info);
				if(isset($rs['flag'])&&$rs['flag'])
				{
					Response::success($rs['msg']);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 删除标签
	 */
	public function setDelShopTagAction()
	{
		try
		{
			\form\trans\shop\ShopForm::setDelShopTag();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$rs = $this->logic->setDelShopTag(ReturnData::$info);
				if(isset($rs['flag'])&&$rs['flag'])
				{
					Response::success($rs['msg']);
				}
			}

			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取店铺信息
	 */
	public function getShopInfoAction()
	{
		try
		{
			\form\trans\shop\ShopForm::getShopInfo();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$data = $this->logic->getShopInfo(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 更新店铺信息
	 */
	public function updateShopInfoAction()
	{
		try
		{
			\form\trans\shop\ShopForm::updateShopInfo();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$rs = $this->logic->updateShopInfo(ReturnData::$info);
				if(isset($rs['flag'])&&$rs['flag'])
				{
					Response::success($rs['msg']);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 店铺首页域名列表
	 */
	public function shopIndexAction()
	{
		try
		{
			\form\trans\shop\ShopForm::shopIndex();
			
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$data = $this->logic->shopIndex(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 店铺高级搜索
	 */
	public function shopSearchAction()
	{
		try
		{
			\form\trans\shop\ShopForm::shopSearch();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$data = $this->logic->shopSearch(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取店铺首页高级搜索选项标签列表
	 */
	public function getShopTagsForSearchAction()
	{
		try
		{
			\form\trans\shop\ShopForm::getShopTagsForSearch();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$data = $this->logic->getShopTagsForSearch(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 关注域名
	 */
	public function addDomainFavoriteAction()
	{
		try
		{
			\form\trans\shop\ShopForm::addDomainFavorite();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$rs = $this->logic->addDomainFavorite(ReturnData::$info);
				if(isset($rs['flag'])&&$rs['flag'])
				{
					Response::success($rs['msg']);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 取消关注域名
	 */
	public function cancelDomainFavoriteAction()
	{
		try
		{
			\form\trans\shop\ShopForm::cancelDomainFavorite();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$rs = $this->logic->cancelDomainFavorite(ReturnData::$info);
				if(isset($rs['flag'])&&$rs['flag'])
				{
					Response::success($rs['msg']);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 设置星标店铺
	 */
	public function MarkShopAction()
	{
		try
		{
			\form\trans\shop\ShopForm::MarkShop();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$rs = $this->logic->MarkShop(ReturnData::$info);
				if(isset($rs['flag'])&&$rs['flag'])
				{
					Response::success($rs['msg']);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 取消设置星标店铺
	 */
	public function cancelMarkShopAction()
	{
		try
		{
			\form\trans\shop\ShopForm::MarkShop();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$rs = $this->logic->cancelMarkShop(ReturnData::$info);
				if(isset($rs['flag'])&&$rs['flag'])
				{
					Response::success($rs['msg']);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 我关注域名--正在交易/我关域名--交易结束数量和列表
	 */
	public function getDomainFavoriteAction()
	{
		try
		{
			\form\trans\shop\ShopForm::getDomainFavorite();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$data = $this->logic->getDomainFavorite(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 店铺标签排序
	 */
	public function shopTagSortAction()
	{
		try
		{
			\form\trans\shop\ShopForm::tagsSort();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$data = $this->logic->tagsSort(ReturnData::$info);
				Response::success('排序成功');
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获得关注下域名的总数量
	 */
	public function attentionNumAction()
	{
		try
		{
			\form\trans\shop\ShopForm::attentionNum();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\shop\ShopLogic();
				$data = $this->logic->attentionNum(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
			
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}
?>
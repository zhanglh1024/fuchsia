<?php
	/**
	 * 新版交易，发送邮件
	 */
	use core\Response;
	use core\form\FormException;
	use core\form\ReturnData;
	class MessageController extends Yaf\Controller_Abstract
	{ 
		/**
		 * 买家逾期没回复，询价取消提醒
		 */
		public function buyerLateForReplyAction()
		{
			try 
			{
				\form\trans\message\MessageForm::buyerLateForReply();
				if(ReturnData::$success)
				{
					$iMessageLib = new \lib\trans\trans\InquiryMessageLib(
							ReturnData::$info->message ? true : false,
							ReturnData::$info->email ? true : false,
							ReturnData::$info->sms ? true : false);
					$data=array('DomainName' => ReturnData::$info->domain,'Seller' => ReturnData::$info->seller,'SellerPrice'=>ReturnData::$info->sellerprice,'OperateDate'=>\date("Y-m-d H:i:s",ReturnData::$info->operatedate),'ReplyId'=>ReturnData::$info->replyid);
					$iMessageLib->buyerLateForReply($data);
					Response::success($data);
				}
				Response::error('error');
			}
			catch (FormException $e)
			{
				Response::formError($e->getMessage());
			}
			catch (Exception $e)
			{
				Response::msg($e->getMessage(),$e->getCode());
			}
		}
	}
?>
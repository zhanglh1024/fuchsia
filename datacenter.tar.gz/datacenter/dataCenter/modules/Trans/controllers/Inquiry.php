<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;
class InquiryController extends Yaf\Controller_Abstract
{

	private $logic;

	/**
	 * 买家申请延期
	 */
	public function buyerApplyAction()
	{
		try
		{
			\form\trans\trans\TransInquiryForm::apply();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\trans\TransInquiryLogic(ReturnData::$info->enameid);
				$result = $this->logic->buyerApplyLogic(ReturnData::$info);
				if(isset($result['flag'])&&$result['flag'])
				{
					Response::msg($result['msg'],isset($result['code']) ? $result['code'] : '',true);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 卖家申请延期
	 */
	public function sellerApplyAction()
	{
		try
		{
			\form\trans\trans\TransInquiryForm::apply();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\trans\TransInquiryLogic(ReturnData::$info->enameid);
				$result = $this->logic->sellerApplyLogic(ReturnData::$info);
				if(isset($result['flag'])&&$result['flag'])
				{
					Response::msg($result['msg'],isset($result['code']) ? $result['code'] : '',true);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 买家同意延期
	 */
	public function buyerAgreeApplyAction()
	{
		try
		{
			\form\trans\trans\TransInquiryForm::doApply();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\trans\TransInquiryLogic(ReturnData::$info->enameid);
				$result = $this->logic->buyerAgreeApplyLogic(ReturnData::$info);
				if(isset($result['flag'])&&$result['flag'])
				{
					Response::msg($result['msg'],isset($result['code']) ? $result['code'] : '',true);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 卖家同意延期
	 */
	public function sellerAgreeApplyAction()
	{
		try
		{
			\form\trans\trans\TransInquiryForm::doApply();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\trans\TransInquiryLogic(ReturnData::$info->enameid);
				$result = $this->logic->sellerAgreeApplyLogic(ReturnData::$info);
				if(isset($result['flag'])&&$result['flag'])
				{
					Response::msg($result['msg'],isset($result['code']) ? $result['code'] : '',true);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 买家拒绝延期
	 */
	public function buyerRefuseApplyAction()
	{
		try
		{
			\form\trans\trans\TransInquiryForm::doApply();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\trans\TransInquiryLogic(ReturnData::$info->enameid);
				$result = $this->logic->buyerRefuseApplyLogic(ReturnData::$info);
				if(isset($result['flag'])&&$result['flag'])
				{
					Response::msg($result['msg'],isset($result['code']) ? $result['code'] : '',true);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 卖家拒绝延期
	 */
	public function sellerRefuseApplyAction()
	{
		try
		{
			\form\trans\trans\TransInquiryForm::doApply();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\trans\trans\TransInquiryLogic(ReturnData::$info->enameid);
				$result = $this->logic->sellerRefuseApplyLogic(ReturnData::$info);
				if(isset($result['flag'])&&$result['flag'])
				{
					Response::msg($result['msg'],isset($result['code']) ? $result['code'] : '',true);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
}
?>
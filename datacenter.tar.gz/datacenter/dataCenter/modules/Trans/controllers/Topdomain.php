<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class TopdomainController extends \Yaf\Controller_Abstract
{

	/**
	 * 获取珍品域名级别 
	 */
	public function getLevelAction()
	{
		try
		{
			form\trans\topdomain\TopDomainForm::checkDomainForm();
			if(ReturnData::$success)
			{
				$tdLogic = new logic\trans\topdomain\TopDomainLogic();
				if(count(ReturnData::$info->domains)>30)
				{
					Response::error('一次批量查询最多支持30个');
				}
				$msg = $tdLogic->getTopDomainLevel(ReturnData::$info->domains);
				Response::success($msg);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取珍品域名列表
	 * 用于判断是否是珍品域名
	 */
	public function getTopDomainAction()
	{
		try
		{
			\form\trans\topdomain\TopDomainForm::getTopDomain();
			if(ReturnData::$success)
			{
				$tdLogic = new \logic\trans\topdomain\TopDomainLogic();
				$data = $tdLogic->getTopDomain(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	public function getTopDomainListAction()
	{
		try
		{
			
			\form\trans\topdomain\TopDomainForm::getTopDomainList();
			if(ReturnData::$success)
			{
				$tdLogic = new \logic\trans\topdomain\TopDomainLogic();
				$data = $tdLogic->getTopDomainList(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	public function getTopDomainInfoAction()
	{
		try
		{
			
			\form\trans\topdomain\TopDomainForm::getTopDomainInfo();
			if(ReturnData::$success)
			{
				$tdLogic = new \logic\trans\topdomain\TopDomainLogic();
				$data = $tdLogic->getTopDomainInfo(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}
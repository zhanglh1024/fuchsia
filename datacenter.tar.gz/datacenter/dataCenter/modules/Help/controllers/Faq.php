<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;
class FaqController extends Yaf\Controller_Abstract
{

	private $logic;

	public function infoAction()
	{
		try
		{
			\form\help\faq\FaqForm::info();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\help\faq\FaqLogic();
				$data = $this->logic->info(ReturnData::$info);
				Response::success($data);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	public function getGuideFaqAction()
	{
		try
		{
			\form\help\faq\FaqForm::getGuideFaq();
			if(ReturnData::$success)
			{
				$this->logic = new \logic\help\faq\FaqLogic();
				$data = $this->logic->getGuideFaq(ReturnData::$info);
				Response::success($data);
			}	
			Response::error('error');
		}
		catch (FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch (Exception $e)
		{
			Response::msg($e->getMessage(),$e->getCode());
		}
	}
}
?>
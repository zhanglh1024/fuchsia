<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class HuodongController extends Yaf\Controller_Abstract
{

	/**
	 * 获取活动列表
	 */
	public function getActivityListAction()
	{
		try
		{
			form\huodong\activity\ActivityForm::ActivityList();
			if(ReturnData::$success)
			{
				$userLogic = new logic\huodong\activity\ActivityLogic();
				$rs = $userLogic->getActivityList(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取广告列表
	 */
	public function getAdListAction()
	{
		try
		{
			form\huodong\adsystem\AdForm::AdList();
			if(ReturnData::$success)
			{
				$userLogic = new logic\huodong\adsystem\AdsystemLogic();
				$rs = $userLogic->getAdList(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}


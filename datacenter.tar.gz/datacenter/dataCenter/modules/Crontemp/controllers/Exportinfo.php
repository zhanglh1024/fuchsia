<?php
use core\ModBase;

class ExportInfoController extends Yaf\Controller_Abstract
{
	/**
	 * 导出某个用户的财务记录
	 */
	public function financeExportAction($params)
	{
		if(empty($params[0]) && empty($params[1]))
		{
			exit('params error');
		}
		$year = $params[0];//年份
		$enameId = $params[1];//用户ID
		
		$saveFile = "/tmp/enameid_finance_{$enameId}_{$year}_".(date('Y-m-d_H:i:s')).".csv";
		//$saveFile = "/Users/ename/Downloads/enameid_finance_{$enameId}_{$year}_".(date('Y-m-d_H:i:s')).".csv";
		$limit = 10000;
		$finMod = new ModBase('finance');
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
		$finConf = $conf->type->lang->toArray();
		$sonConf = $conf->sonType->lang->toArray();
		$query = "select count(*) from e_finance_general{$year} where EnameId={$enameId}";
		$count = $finMod->getOne($query, '', array());
		echo "{$enameId}在{$year}年共产生财务流水{$count}条\r\n";
		if(empty($count))
		{
			exit("无财务数据");
		}
		$content = array('用户ID', '域名', '操作方式', '金额', '历史金额', '订单号', '备注', '时间');
		$content = implode(",", $content);
		file_put_contents($saveFile, $content."\r\n", FILE_APPEND);
		for ($i = 0; $i < $count; $i = $i + $limit)
		{
			$query = "select * from e_finance_general{$year} where EnameId={$enameId} order by UpdateTime asc limit ".$i.",".$limit;
			$info = $finMod->select($query, '', array());
			if(empty($info))
			{
				exit($i."-".$limit."获取失败");
			}
			foreach ($info as $v)
			{
				$tempInfo = array();
				$tempInfo['enameId'] = $v['EnameId'];
				$tempInfo['domain'] = $v['LinkDomain'];
				$tempInfo['inOutType'] = isset($finConf[$v['InOutType']]) ? $finConf[$v['InOutType']] : $v['InOutType'];
				$inOutMoneyType = '';
				switch ($v['Type'])
				{
					case 1:
						$inOutMoneyType = "消费";
						break;
					case 2:
						$inOutMoneyType = "转入";
						break;
					case 3:
						$inOutMoneyType = "充值";
						break;
					case 4:
						$inOutMoneyType = "提现";
				}
				$tempInfo['inOutMoney'] = round($inOutMoneyType.$v['InOutMoney'], 2);
				$tempInfo['currentMoney'] = round($v['CurrentMoney'], 2);
				$tempInfo['orderId'] = $v['OrderId'];
				$tempInfo['remark'] = (empty($v['Remark']) ? "" : $v['Remark'].";").(empty($v['RemarkHide']) ? "" : $v['RemarkHide'].";").($v['FeeMoney'] > 0 ? "扣除手续费".$v['FeeMoney'] : "");
				$tempInfo['time'] = empty($v['UpdateTime']) ? "" : date('Y-m-d H:i:s',$v['UpdateTime']);
				$content = implode(",", $tempInfo);
				file_put_contents($saveFile, $content."\r\n", FILE_APPEND);
			}
		}
	}
	
	/**
	 * 导出webcc接口下，有设置自动续费的cc域名。
	 * 用excel导出，其中需要包含【id 、联系人、电话、 邮箱、 域名、域名到期时间】
	 */
	public function exportAutoRenewCcDnAction()
	{
		$saveFile = "/tmp/cc_domain_auto_renew.csv";
		//$saveFile = "/var/www/log/cc_domain_auto_renew.csv";
		$dnMod = new ModBase('domain');
		$userMod = new ModBase('user');
		$query = "select EnameId,DomainName,ExpDate from e_domains where DomainLtd=11 and AutoRenew=1 and RegistrarId=61 order by EnameId";
		$dnInfo = $dnMod->select($query, '', array());
		if(empty($dnInfo))
		{
			exit("没有要导出的域名信息");
		}
		//标题
		$content = array('用户ID', '联系人', '电话', '邮箱', '域名', '域名到期时间');
		$content = implode(",", $content);
		file_put_contents($saveFile, $content."\r\n", FILE_APPEND);
		foreach ($dnInfo as $v)
		{
			$query = "select Email,ChName from e_member where EnameId=".$v['EnameId'];
			$userInfo = $userMod->getRow($query, '', array());
			if(empty($userInfo))
			{
				echo $v['EnameId']."获取用户信息失败";
				continue;
			}
			$query = "select Mobile from e_member_ext where EnameId=".$v['EnameId'];
			$userExtInfo = $userMod->getRow($query, '', array());
			if(empty($userExtInfo))
			{
				echo $v['EnameId']."获取用户扩展信息失败";
				continue;
			}
			$content = $v['EnameId'].",".$userInfo['ChName'].",".$userExtInfo['Mobile'].",".$userInfo['Email'].",".$v['DomainName'].",".$v['ExpDate'];
			file_put_contents($saveFile, $content."\r\n", FILE_APPEND);
		}
	}
	
	/**
	 * 导出指定时间内活跃的用户邮箱(2016-08-04)
	 * 排除无域名无款项的用户
	 */
	public function exportUserEmailAction()
	{
		set_time_limit(0);
		$saveFile = "/tmp/user_email.csv";
		$userMod = new ModBase('user');
		$dnMod = new ModBase('domain');
		$finMod = new ModBase('finance');
		$userList = $userMod->select('select distinct(EnameId) from ename_member.e_member_log_login2015 where Status=1 and LoginTime>=1470240000 and LoginFrom in(1,2,6)', '', array());
		if(empty($userList))
		{
			exit('error');
		}
		$i = 0;
		foreach ($userList as $v)
		{
			$dnCount = $dnMod->getOne("select count(*) from e_domains where EnameId = " . $v['EnameId'], '', array());
			if(empty($dnCount))
			{
				continue;//无域名
			}
			$finInfo = $finMod->getRow("select sum(PublicMoney)+sum(UnWithdrawalMoney)+sum(WithdrawalMoney)+sum(MarginMoney)+sum(FreezeMoney) as Money from e_finances where EnameId=" . $v['EnameId'], '', array());
			if(empty($finInfo['Money']))
			{
				continue;//无款项
			}
			$userInfo = $userMod->getRow('select Email from e_member where EnameId = ' . $v['EnameId'], '', array());
			if($userInfo)
			{
				file_put_contents($saveFile, $userInfo['Email']."\r\n", FILE_APPEND);
			}
			$i++;
		}
	}
}
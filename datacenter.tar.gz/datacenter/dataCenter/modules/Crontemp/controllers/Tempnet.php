<?php
use core\ModBase;
/**
 * 
 */
class TempnetController extends Yaf\Controller_Abstract
{
	/**
	 * 人工脚本--测试专用
	 */
	public function uploadAction()
	{
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'verify');
		$templatePerson = array(
				array('postalType' => 'loc', 'cardCode' => '420621198210096039', 'enameId' => 626038, 'locType' => 'QT',
						'locNumber' => "420621198210096039",'img'=>array($conf->verify->upload_image_sfz."2016-01/56a2421423b84388.jpg"),
						'templateId' => 687717,'templateName'=>'ename_intkm069zm'));
// 		echo "person start\r\n";
		$epplib = new \lib\manage\domain\DomainEppLib();
// 		foreach($templatePerson as $person)
// 		{
// 			$locData = array('postalType'=>$person['postalType'],'cardCode'=>$person['cardCode'],'locType'=>$person['locType'],'locNumber'=>$person['locNumber']);
// 			$epplib->updateTemplateApiTest($person['templateId'], "ename.公司", 71, $person, $person['templateName']);
// 			echo "\r\n";
// 		}
		$templateCompany = array(
				array('postalType' => 'loc',
						'img' => array($conf->verify->upload_image_org . "2016-02/56b06dd4f2829423.jpg"),
						'enameId' => 1066761, 'locType' => 'QT', 'locNumber' => "350299100000684",'templateName'=>'ename_ytmktj6zbk',
						'cardCode' => '352230198607010019', 'templateId' => 687651),
				array('postalType' => 'loc', 'cardCode' => '320521198207151712',
						'img' => array($conf->verify->upload_image_org . "2016-02/56cd209de9d9d414.jpg"),
						'enameId' => 193777, 'locType' => 'QT', 'locNumber' => "320582000059937",
						'templateId' => 692596,'templateName'=>'ename_2uhmrn06kx'));
		echo "com start\r\n";
		foreach($templateCompany as $company)
		{
		//	$locData = array('postalType'=>$person['postalType'],'cardCode'=>$person['cardCode'],'locType'=>$person['locType'],'locNumber'=>$person['locNumber']);
			$epplib->updateTemplateApiTest($company['templateId'], "ename.公司", 71, $company, $company['templateName']);
			echo "\r\n";
		}
	}
}

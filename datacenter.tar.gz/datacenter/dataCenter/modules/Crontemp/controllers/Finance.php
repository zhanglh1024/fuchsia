<?php
use core\ModBase;
class FinanceController extends Yaf\Controller_Abstract
{

	public function editBankInfoAction()
	{
		$financeMod = new ModBase('finance');
		$query = "select `BankId`,`Province`,`City` from e_finance_withdrawals_bank_info ";
		$bankInfo = $financeMod->select($query, '', array());
		if(empty($bankInfo))
		{
			exit('not found bank info');
		}
		$cityArr = $this->getCityData();
		foreach($bankInfo as $k => $v)
		{
			if(!$v['Province'] || !$v['City'])
			{
				echo $v['BankId'] . "城市数据为空\r\n";
				\core\Log::write($v['BankId'] . "城市数据为空", 'crontemp/finance', 'editBankInfo');
				continue;
			}
			if(!array_key_exists($v['Province'], $cityArr))
			{
				echo $v['BankId'] . "省份数据错误\r\n";
				\core\Log::write($v['BankId'] . "省份数据错误", 'crontemp/finance', 'editBankInfo');
				continue;
			}
			$cityArrNew = $cityArr[$v['Province']];
			if(in_array($v['City'], $cityArrNew))
			{
				echo $v['BankId'] . "数据正常\r\n";
				\core\Log::write($v['BankId'] . "数据正常", 'crontemp/finance', 'editBankInfo');
				continue;
			}
			if(strpos(implode(',', $cityArrNew), $v['City']) === false)
			{
				echo $v['BankId'] . "城市数据有误\r\n";
				\core\Log::write($v['BankId'] . "城市数据有误", 'crontemp/finance', 'editBankInfo');
				continue;
			}
			foreach($cityArrNew as $k2 => $city)
			{
				if(strpos($city, $v['City']) !== false)
				{
					$query1 = "update `e_finance_withdrawals_bank_info` set `City`='" . $cityArrNew[$k2] .
						 "' where `BankId`=" . $bankInfo[$k]['BankId'];
					$result = $financeMod->update($query1, '', array());
					if($result)
					{
						echo $v['BankId'] . $v['Province'] . "修改成功\r\n";
						\core\Log::write($v['BankId'] . $v['City'] . "修改成功", 'crontemp/finance', 'editBankInfo');
					}
					else
					{
						echo $v['BankId'] . $v['Province'] . "修改失败\r\n";
						\core\Log::write($v['BankId'] . $v['City'] . "修改失败", 'crontemp/finance', 'editBankInfo');
					}
				}
			}
		}
	}

	public function getCityData()
	{
		$cityArr = array();
		$cityArr['北京'] = '北京';
		$cityArr['天津'] = '天津';
		$cityArr['河北'] = '石家庄市,唐山市,秦皇岛市,邯郸市,邢台市,保定市,张家口市,承德市,沧州市,廊坊市,衡水市';
		$cityArr['山西'] = '太原市,大同市,阳泉市,长治市,晋城市,朔州市,晋中市,运城市,忻州市,临汾市,吕梁市';
		$cityArr['内蒙古'] = '呼和浩特市,包头市,乌海市,赤峰市,通辽市,鄂尔多斯市,呼伦贝尔市,巴彦淖尔市,乌兰察布市,兴安盟,锡林郭勒盟,阿拉善盟';
		$cityArr['辽宁'] = '沈阳市,大连市,鞍山市,抚顺市,本溪市,丹东市,锦州市,营口市,阜新市,辽阳市,盘锦市,铁岭市,朝阳市,葫芦岛市';
		$cityArr['吉林'] = '长春市,吉林市,四平市,辽源市,通化市,白山市,松原市,白城市,延边州';
		$cityArr['黑龙江'] = '哈尔滨市,齐齐哈尔市,鸡西市,鹤岗市,双鸭山市,大庆市,伊春市,佳木斯市,七台河市,牡丹江市,黑河市,绥化市,大兴安岭地区';
		$cityArr['上海'] = '上海';
		$cityArr['江苏'] = '南京市,无锡市,徐州市,常州市,苏州市,南通市,连云港市,淮安市,盐城市,扬州市,镇江市,泰州市,宿迁市';
		$cityArr['浙江'] = '杭州市,宁波市,温州市,嘉兴市,湖州市,绍兴市,金华市,衢州市,舟山市,台州市,丽水市';
		$cityArr['安徽'] = '合肥市,芜湖市,蚌埠市,淮南市,马鞍山市,淮北市,铜陵市,安庆市,黄山市,滁州市,阜阳市,宿州市,亳州市,六安市,宣城市,池州市';
		$cityArr['福建'] = '福州市,厦门市,莆田市,三明市,泉州市,漳州市,南平市,龙岩市,宁德市';
		$cityArr['江西'] = '南昌市,景德镇市,萍乡市,九江市,新余市,赣州市,鹰潭市,宜春市,上饶市,吉安市,抚州市';
		$cityArr['山东'] = '济南市,青岛市,淄博市,枣庄市,东营市,烟台市,潍坊市,济宁市,泰安市,威海市,日照市,莱芜市,临沂市,德州市,聊城市,滨州市,菏泽市';
		$cityArr['河南'] = '郑州市,开封市,洛阳市,平顶山市,安阳市,鹤壁市,新乡市,焦作市,濮阳市,许昌市,漯河市,三门峡市,南阳市,商丘市,信阳市,济源市,周口市,驻马店市';
		$cityArr['湖北'] = '武汉市,黄石市,十堰市,宜昌市,襄阳市,鄂州市,荆门市,孝感市,潜江市,仙桃市,荆州市,黄冈市,随州市,咸宁市,天门市,恩施州,神农架林区';
		$cityArr['湖南'] = '长沙市,株洲市,湘潭市,衡阳市,邵阳市,岳阳市,常德市,张家界市,益阳市,郴州市,永州市,怀化市,娄底市,湘西州';
		$cityArr['广东'] = '广州市,韶关市,深圳市,珠海市,汕头市,佛山市,江门市,湛江市,茂名市,肇庆市,惠州市,梅州市,汕尾市,河源市,阳江市,清远市,东莞市,中山市,潮州市,揭阳市,云浮市';
		$cityArr['广西'] = '南宁市,柳州市,桂林市,梧州市,北海市,防城港市,钦州市,贵港市,玉林市,贺州市,百色市,河池市,来宾市,崇左市';
		$cityArr['海南'] = '海口市,三亚市,三沙市,五指山市,琼海市,儋州市,文昌市,万宁市,东方市';
		$cityArr['重庆'] = '重庆';
		$cityArr['四川'] = '成都市,自贡市,攀枝花市,泸州市,德阳市,绵阳市,广元市,遂宁市,内江市,乐山市,南充市,眉山市,宜宾市,广安市,达州市,雅安市,阿坝州,甘孜州,凉山州,巴中市,资阳市';
		$cityArr['贵州'] = '贵阳市,六盘水市,遵义市,铜仁市,黔西南州,毕节市,安顺市,黔东南州,黔南州';
		$cityArr['云南'] = '昆明市,曲靖市,玉溪市,保山市,昭通市,普洱市,丽江市,普洱市,临沧市,楚雄州,红河州,文山州,西双版纳州,大理州,德宏州,怒江州,迪庆州';
		$cityArr['西藏'] = '拉萨市,昌都市,山南地区,日喀则市,那曲地区,阿里地区,林芝地区';
		$cityArr['陕西'] = '西安市,铜川市,宝鸡市,咸阳市,渭南市,延安市,汉中市,安康市,商洛市,榆林市';
		$cityArr['甘肃'] = '兰州市,嘉峪关市,金昌市,白银市,天水市,酒泉市,张掖市,武威市,定西市,陇南市,平凉市,庆阳市,临夏州,甘南州';
		$cityArr['青海'] = '西宁市,海东市,海北州,黄南州,海南州,果洛州,玉树州,海西州';
		$cityArr['宁夏'] = '银川市,石嘴山市,吴忠市,固原市,中卫市';
		$cityArr['新疆'] = '乌鲁木齐市,克拉玛依市,吐鲁番地区,哈密地区,昌吉州,博尔塔拉州,巴音郭楞州,阿克苏地区,克孜勒苏州,喀什地区,和田地区,伊犁州,伊犁地区,塔城地区,阿勒泰地区';
		$cityArr['台湾'] = '台北市,新北市,台中市,台南市,高雄市,基隆市,新竹市,嘉义市';
		$cityArr['香港'] = '香港';
		$cityArr['澳门'] = '澳门';
		foreach($cityArr as $k => $v)
		{
			$cityArr[$k] = explode(',', $v);
		}
		return $cityArr;
	}

	/**
	 * 人工入款 201  NO.59542  四声拍卖会返款
	 * 注意：必须将需要入款的数据，按要求组装好，然后上传服务器到指定文件，每次跑之前都先echo测试看下数据格式是否ok
	 *
	 * 例如：随机码返款
	 * 文件格式为//出价id,返款金额,域名，
	 * 文件名为/var/www/log/crontemp/manualFinanceIn_suiji_2016-07-18.txt
	 * 跑的命令为/usr/local/php/bin/php crontab/cli.php crontemp finance manualFinanceIn suiji
	 *
	 * 其他入款见case
	 */
	public function manualFinanceInAction($params = array())
	{
		if(!isset($params[0]))
		{
			exit('param error');
		}
		$name = $params[0];
		$remarkPre = '海量精品专场拍卖会';
		$remarkHide = '2016.08' . $remarkPre . 'OA61834[经手人:杨亚凤批量]';
		$inTypeSon = 60;//财务配置需要新增
		switch($name)
		{
			case 'suiji':
				//出价id,返款金额,域名
				$remark = $remarkPre . '随机码返款';
				break;
			case 'top':
				//出价id,返款金额
				$remark = $remarkPre . '卖家排名返款';
				break;
// 			case 'fenxiao':
// 				$remark = $remarkPre . '分销返款';
// 				break;
			case 'chujia':
				$remark = $remarkPre . '第二高出价奖励';
				//出价id,返款金额,域名
				break;
		
		}
		$finlog = new \logic\manage\finance\FinanceLogic();
		//$file = fopen("/Users/ename/Downloads/manualFinanceIn_". $name . ".txt", "r");
		$file = fopen("/var/www/log/crontemp/manualFinanceIn_" . $name . ".txt", "r");
		if(!$file)
		{
			exit("打开文件失败");
		}
		$doNum = 0;
		while(!feof($file))
		{
			$line = trim(fgets($file));
			if(!$line)
			{
				continue;
			}
			$doNum++;
			if($doNum > 1)
			{
				break;
			}
			$data = explode(",", $line);
			$enameid = $data[0];
			$money = $data[1];
			$domain = !empty($data[2]) ? $data[2] : '';
		
			if(!$enameid || !$money)
			{
				echo "没有数据\r\n";
				continue;
			}
			// (object)array('enameId','price','intype','moneyType可选','domain可选'，'remark可选','remarkhide可选','adminid可选');
			$send = array('enameId' => $enameid, 'domain' => $domain, 'price' => $money, 'remark' => $remark,
				'remarkHide' => $remarkHide, 'adminId' => 91, 'inType' => 206, 'inTypeSon' => $inTypeSon);
			echo $doNum . " " . implode(",", $send) . "\r\n";
			
			continue;
			if($doNum % 5 == 0)
			{
				sleep(1);
			}
			$finrs = $finlog->manualRecharge((object)$send);
			if(true == $finrs)
			{
				\core\Log::write(implode($send), 'crontemp', 'manualFinanceIn_' . $name . '_suc');
			}
			else
			{
				\core\Log::write(implode($send), 'crontemp', 'manualFinanceIn_' . $name . '_fail');
			}
		}
	}

	/**
	 * 人工入款 对应具体财务类型和产品 扣除积分
	 */
	public function manualDnFinanceInAction()
	{
		$finlog = new \logic\manage\finance\FinanceLogic();
		$file = fopen("/var/www/log/crontemp/manualFinanceIn_errback_2015-11-11.txt", "r");
		if(!$file)
		{
			exit("打开文件失败");
		}
		$doNum = 0;
		$remarkSc = '注册退差价'; // 积分备注
		$remark = '双11APP注册CN域名限时优惠18元，退差价';
		$remarkHide = '双11CN注册优惠OA50516[经手人:杨亚凤批量]';
		$name = 'errback';
		while(!feof($file))
		{
			$line = trim(fgets($file));
			if(!$line)
			{
				continue;
			}
			$doNum++;
			if($doNum > 1)
				break;
			$data = explode(",", $line);
			// $domain = '';
			$domain = $data[0];
			$enameId = $data[1];
			$money = 17;
			if(!$enameId || !$domain)
			{
				echo "没有数据\r\n";
				continue;
			}
			// (object)array('enameId','price','intype','moneyType可选','domain可选'，'remark可选','remarkhide可选','adminid可选');
			$send = array('enameId' => $enameId, 'domain' => $domain, 'price' => $money, 'remark' => $remark, 
				'remarkHide' => $remarkHide, 'adminId' => 91, 'inType' => 206, 'inTypeSon' => 42);
			echo $doNum . " " . implode(",", $send) . "\r\n";
			continue;
			if($doNum % 5 == 0)
				sleep(1);
			$finrs = $finlog->manualRecharge((object)$send);
			if(true == $finrs)
			{
				\core\Log::write(implode($send), 'crontemp', 'manualFinanceIn_' . $name . '_suc');
				// 扣除对应积分
				$this->financeInfoLib = new \lib\manage\finance\FinanceInfoLib($enameId);
				$this->financeInfoLib->getUserFinance();
				$totalScore = $this->financeInfoLib->getTotalScore();
				$scoreLib = new \lib\manage\finance\ScoreLib();
				$scrs = $scoreLib->subScore($enameId, 17, $totalScore, 0, $remarkSc, $domain);
				\core\Log::write($line . ",", json_encode($scrs), 'crontemp', 'manualFinanceIn_' . $name . '_score');
			}
			else
			{
				\core\Log::write(implode($send), 'crontemp', 'manualFinanceIn_' . $name . '_fail');
			}
		}
	}
	
	/**
	 * 人工入款 对应具体财务类型和产品 扣除积分
	 * 活动阶梯返款
	 */
	public function manualJietiFinanceInAction()
	{
		$fileName = "/tmp/wang_renew_back_money_repair_new.csv";
		//$fileName = "/Users/ename/Downloads/wang_renew_back_money.csv";
		$finlog = new \logic\manage\finance\FinanceLogic();
		$file = fopen($fileName, "r");
		if(!$file)
		{
			exit("打开文件失败");
		}
		$doNum = 0;
		$remarkSc = 'wang续费阶梯返款扣除相应积分';//积分备注
		$remark = 'wang续费阶梯返款';
		$remarkHide = 'OA62993[经手人:黄焱福批量]';
		while(!feof($file))
		{
			$line = trim(fgets($file));
			if(!$line)
			{
				continue;
			}
			$doNum++;
			if($doNum > 1)
			{
				//break;
			}
			$data = explode(",", $line);
			$total = $data[0];
			$enameId = $data[1];
			$domain = '';
			if(!$enameId || !$total)
			{
				echo "没有数据\r\n";
				continue;
			}
			$price = $total;//数据修复，已经按阶梯计算好的数据。
// 			if($total < 100)
// 			{
// 				continue;
// 			}
// 			elseif($total >= 100 && $total < 200)
// 			{
// 				$price = $total;
// 			}
// 			elseif($total >= 200 && $total < 500)
// 			{
// 				$price = $total * 2;
// 			}
// 			elseif($total >= 500)
// 			{
// 				$price = $total * 3;
// 			}
			// (object)array('enameId','price','intype','moneyType可选','domain可选'，'remark可选','remarkhide可选','adminid可选');
			$send = array('enameId' => $enameId, 'domain' => $domain, 'price' => $price, 'remark' => $remark,
					'remarkHide' => $remarkHide, 'adminId' => 185, 'inType' => 206, 'inTypeSon' => 64);
			echo $doNum . " " . implode(",", $send) . "\r\n";
			if($doNum % 5 == 0)
			{
				sleep(1);
			}
			$finrs = $finlog->manualRecharge((object)$send);
			if(true == $finrs)
			{
				\core\Log::write(implode($send), 'crontemp', 'manualJietiFinanceIn_suc');
				// 扣除对应积分
				try 
				{
					$this->financeInfoLib = new \lib\manage\finance\FinanceInfoLib($enameId);
					$this->financeInfoLib->getUserFinance();
					$totalScore = $this->financeInfoLib->getTotalScore();
					$scoreLib = new \lib\manage\finance\ScoreLib();
					$scrs = $scoreLib->subScore($enameId, $price, $totalScore, 0, $remarkSc, $domain);
					\core\Log::write($line . ",", $scrs, 'crontemp', 'manualJietiFinanceIn_score');
				}
				catch (Exception $e)
				{
					\core\Log::write($line . ",", $e->getMessage(), 'crontemp', 'manualJietiFinanceIn_score_err');
				}
			}
			else
			{
				\core\Log::write(implode($send), 'crontemp', 'manualJietiFinanceIn_fail');
			}
		}
	}

	/**
	 * 设置消费产生的积分
	 */
	private function setScore($financeType, $money)
	{
		$this->conf = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
		$scoreToJifen = $this->conf->score->toArray();
		$scoreRate = isset($scoreToJifen[$financeType]) ? $scoreToJifen[$financeType] : 0;
		$addScore = floor($scoreRate * $money);
		return $addScore;
	}

	/**
	 * 核查多个域名的最后一次消费情况 关联oa 43040 48257
	 */
	public function ckDnFinRecordsAction()
	{
		$file = '/var/www/log/crontemp/finance/domains0911.txt';
		$saveFile = '/var/www/log/crontemp/finance/domains0911.csv';
		$handle = fopen($file, 'r+');
		if(!$handle)
		{
			\core\Log::write('文件打开失败--' . $file, 'crontemp', 'checkdomainsfinancerecords');
			exit();
		}
		$domains = array();
		while(!feof($handle))
		{
			$str = fgets($handle);
			$str = str_replace("\r\n", "", $str);
			$str = strtolower($str);
			$strArr = explode("\t", $str);
			$domains[$strArr[0]] = $strArr[1];
		}
		if(empty($domains))
		{
			\core\Log::write('没有需要查询的域名', 'crontemp', 'checkdomainsfinancerecords');
			exit();
		}
		$config = new \Yaf\Config\Ini(APP_PATH . '/conf/finance.ini', 'base');
		$domainMod = new ModBase('domain');
		$financeType = $config->type->lang->toArray();
		$title = "序号,拍卖域名名称,消费金额,手续费,买家用户id,卖家用户id,收款日期,是否纳税,纳税日期,纳税金额,纳税税种,备注\r\n";
		file_put_contents($saveFile, $title, FILE_APPEND);
		$cn = 0;
		foreach($domains as $num => $domain)
		{
			if($cn++ > 2)
				break;
			if(!$domain)
				continue;
			echo $domain . "\r\n";
			
			$outTable = 'e_finance_out';
			$outWhere = "LinkDomain = '" . $domain . "' order by CreateDate desc ";
			$financeInfo = $this->getFinHistory($outTable, $outWhere, "*", true);
			if(empty($financeInfo))
			{
				\core\Log::write('没有发现域名[' . $domain . ']的相关出款信息', 'crontemp', 'checkdomainsfinancerecords');
				$info = $num . "," . $domain . ",," . ",,,,,,,,";
			}
			elseif(!isset($financeType[$financeInfo['OutType']]))
			{
				\core\Log::write('财务类型错误[' . $financeInfo['OutId'] . ']', 'crontemp', 'checkdomainsfinancerecords');
				$info = $num . "," . $domain . ",," . ",,,,,,,,";
			}
			else
			{
				$info = $num . "," . $domain . "," . $financeInfo['OutMoney'] . ",";
				$tradeType = array(9, 20, 21, 22, 23, 27, 101, 102, 103, 104);
				for($i = 106; $i <= 129; $i++)
				{
					array_push($tradeType, $i);
				}
				if(in_array($financeInfo['OutType'], $tradeType))
				{
					$inEnameMsg = '域名交易';
					$inTable = 'e_finance_in';
					$inWhere = "OrderId = '" . $financeInfo['OrderId'] . "'";
					$inItem = "`FeeMoney`";
					$financeIn = $this->getFinHistory($inTable, $inWhere, $inItem, true);
					if(empty($financeIn))
					{
						\core\Log::write('没有发现订单[' . $financeInfo['OrderId'] . ']的入款记录,域名[' . $domain . ']', 'crontemp', 
							'checkdomainsfinancerecords');
						$info .= "0," . $financeInfo['EnameId'] . "," . $financeInfo['LinkEnameId'] . ",";
					}
					else
					{
						$info .= $financeIn['FeeMoney'] . "," . $financeInfo['EnameId'] . "," .
							 $financeInfo['LinkEnameId'] . ",";
					}
				}
				else
				{
					$inEnameMsg = '域名管理消费';
					$info .= "," . $financeInfo['EnameId'] . ",,";
				}
				$info .= $financeInfo['CreateDate'] . ",,,,," . $financeType[$financeInfo['OutType']] . "，";
			}
			$domainInfo = $domainMod->getRow(
				"select count(*) as sum from e_domains where DomainName = '" . $domain . "'", '', array());
			$inEnameMsg .= $domainInfo['sum'] ? "，域名在我司" : "，域名不在我司";
			$info .= $inEnameMsg . "\r\n";
			file_put_contents($saveFile, $info, FILE_APPEND);
		}
	}
	
	// 获取财务信息（新表没数据便利历史表）
	public function getFinHistory($table, $where, $item = "*", $limitOne = false)
	{
		$financeMod = new ModBase('finance');
		$query = "select " . $item . " from " . $table . " where " . $where;
		$financeInfo = $financeMod->select($query, '', array(), $limitOne);
		if(empty($financeInfo))
		{
			for($year = 2014; $year >= 2005; $year--)
			{
				$query = "select " . $item . " from " . $table . "_history" . $year . " where " . $where;
				$financeInfo = $financeMod->select($query, '', array(), $limitOne);
				if($financeInfo)
				{
					break;
				}
			}
		}
		return $financeInfo;
	}

	public function cancelOrderByAdminAction()
	{
		$financeIf = new \interfaces\manage\Finance();
		$rs = $financeIf->cancelOrderByAdmin(561305, 118213, '测试后台取消订单[杨亚凤]');
	}

	/**
	 * 根据运维备份的每个月0点的财务e_finances表的完整数据sql取出每个用户的可提现 不可提现 对公款 保证金 冻结款给财务
	 */
	public function getFinancesCsvAction($params = array())
	{
		// INSERT INTO `e_finances` VALUES
		// (1,10001,'0.0000','13668.6000','150849.1600','0.0000','11861.3100','832244.0000','1729706.3100','93000.0000','0.0000',1144114,'-370774.0000','0','103310.1800',1510649),
		// (2,10002,'0.0000','8113.6000','0.0000','0.0000','0.0000','0.0000','0.0000','0.0000','0.0000',8012,'70.0000','0','8113.6000',24226),(3,10003,'0.0000','93.0000','33.0000','0.0000','0.0000','0.0000','0.0000','0.0000','0.0000',7,'5.0000','0','126.0000',1009),(4,10004,'0.0000','25.4300','0.0000','0.0000','0.0000','0.0000','0.0000','0.0000','0.0000',3955,'500.0000','0','23.2400',10215),(5,10005,'0.0000','455.0000','0.0000','0.0000','3615.0000','3160.0000','0.0000','0.0000','0.0000',41658,'7490.0000','0','0.0000',53010),(6,10006,'0.0000','0.0000','0.0000','0.0000','0.0000','0.0000','0.0000','0.0000','0.0000',1500,'0.0000','0','0.0000',1502)
		// mysql> select * from e_finances limit 1\G
		// *************************** 1. row ***************************
		// FinanceId: 1
		// EnameId: 10001
		// PublicMoney: 0.0000
		// UnWithdrawalMoney: 0.0000
		// WithdrawalMoney: 150782.7600
		// MarginMoney: 0.0000
		// DepositMoney: 11861.3100
		// ConsumeMoney: 856339.0000
		// TradingIncomeMoney: 1729706.3100
		// TradingPayMoney: 93000.0000
		// FreezeMoney: 0.0000
		// TotalScore: 1168209
		// InvoiceAmount: -370774.0000
		// InvoiceYear: 0
		// oldMoney: 103310.1800
		// AllScore: 1534744
		// 1 row in set (0.00 sec)
		if(!isset($params[0]) || !isset($params[1]))
		{
			exit('params error');
		}
		$oriFile = $params[0];//ename_finance.e_finances_2016-10-01
		$desFile = $params[1];//20161001
		$fileDir = '/Users/ename/Downloads/';
		$file = fopen($fileDir . $oriFile.'.sql', 'r');
		if(!$file)
		{
			exit("open file failed");
		}
		$all = $useall = $p = $u = $w = $m = 0;
		error_log(implode(",", array("EnameId", "对公款", "不可提现", "可提现", "保证金", "总预付款", "冻结款", "总计")) . "\r\n", 3, 
			$fileDir . "ename_finance.e_finances_all_" . $desFile . ".csv");
		while(!feof($file))
		{
			$line = trim(fgets($file));
			if(!$line || false === stripos($line, ");"))
			{
				continue;
			}
			$line = trim($line);
			$line = str_replace("INSERT INTO `e_finances` VALUES (", "", $line);
			$line = str_replace(");", "", $line);
			$data = explode("),(", $line);
			foreach($data as $v)
			{
				$v = str_replace("'", "", $v);
				$tmp = explode(",", $v);
				$p += $tmp[2];
				$u += $tmp[3];
				$w += $tmp[4];
				$m += $tmp[5];
				$useable = $tmp[2] + $tmp[3] + $tmp[4] + $tmp[5];
				$useall += $useable;
				$newarr = array($tmp[1], $tmp[2], $tmp[3], $tmp[4], $tmp[5], $useable, $tmp[10], $useable + $tmp[10]);
				$all += $useable + $tmp[10];
				error_log(implode(",", $newarr) . "\r\n", 3, 
					$fileDir . "ename_finance.e_finances_all_" . $desFile . ".csv");
			}
		}
		fclose($file);
		echo $p . "－对公\r\n";
		echo $u . "－不可提现\r\n";
		echo $w . "－可提现\r\n";
		echo $m . "－保证金\r\n";
		echo $useall . "-余额\r\n";
		echo $all - $useall . "-冻结\r\n";
		echo $all . "－总额\r\n";
		exit();
	}
	
	/**
	 * 检测订单的price和 FreezeMoneySort的金额是否一致
	 */
	public function checkOrderFreezeMoneySortAction()
	{
		echo "------start------\n";
		$finOrderMod = new \models\manage\finance\FinOrderMod();
		$params = array('StartDate' => '2015-11-01 00:00:00', 'EndDate' => '2015-11-30 23:59:59');
		$result = $finOrderMod->getFinanceFreezeCount($params);
		$count = $result['total'];
		if($count)
		{
			$limit = 200;
			$page = ceil($count / $limit);
			for($i = 0; $i < $page; $i++)
			{
				if($orderList = $finOrderMod->getOrderList($params, $i * $limit . ',' . $limit))
				{
					foreach($orderList as $value)
					{
						$freezeMoneySort = json_decode($value['FreezeMoneySort'], true);
						if(($value['Price'] - $freezeMoneySort['p'] - $freezeMoneySort['u'] - $freezeMoneySort['w'] -
							 $freezeMoneySort['m']) != 0)
						{
							\core\Log::write(json_encode($value), 'Order', 'checkOrderFreezeMoneySort');
						}
					}
					usleep(100);
				}
			}
		}
		echo "------end------\n";
	}

	/**
	 * 检测用户的账户中的冻结款和冻结款列表总额是否一致
	 */
	public function checkUserFreezeMoneyAction()
	{
		echo "------start------\n";
		$finOrderMod = new \models\manage\finance\FinOrderMod();
		$financeMod = new \models\manage\finance\FinancesMod();
		// 统计总条数
		if($count = $financeMod->getOne('select count(*) as count from e_finances where FreezeMoney>0', '', array()))
		{
			$limit = 200;
			$page = ceil($count / $limit);
			for($i = 0; $i < $page; $i++)
			{
				$sql = 'select * from e_finances where FreezeMoney>0 limit ' . $i * $limit . ',' . $limit;
				if($list = $financeMod->select($sql, '', array()))
				{
					foreach($list as $value)
					{
						$sql = 'select sum(Price) as count from e_finance_orders where EnameId = ' . $value['EnameId'] .
							 ' and OrderStatus = 3';
						$freezeCount = $finOrderMod->getOne($sql, '', array());
						$freezeCount = empty($freezeCount) ? 0 : $freezeCount;
						if(($value['FreezeMoney'] - $freezeCount) != 0)
						{
							\core\Log::write('Enameid:' . $value['EnameId'] . ',FreezeMoney:' . $value['FreezeMoney'] . ',OrderFreeCount:' . $freezeCount, 'Order', 'checkUserFreezeMoney');
						}
					}
				}
				usleep(100);
			}
		}
		echo "------end------\n";
	}

	/**
	 * 检测优惠券使用次数
	 */
	public function checkPromoUseTimesAction()
	{
		try
		{
			echo "------start------\n";
			// $promoIds = array(188, 189, 190, 191, 192, 193, 194, 195);
			$promoIds = array(250, 251, 252, 253, 254, 255);
			$promoMod = new \models\manage\finance\ProPromoMod();
			$finOrderMod = new \models\manage\finance\FinOrderMod();
			$sql = 'select count(*) as count from e_products_promo_code where PromoTypeId in (' . implode(',', 
				$promoIds) . ')';
			if($count = $promoMod->getOne($sql, '', array()))
			{
				$limit = 50;
				$page = ceil($count / $limit);
				for($i = 0; $i < $page; $i++)
				{
					$sql = "select * from e_products_promo_code where PromoTypeId in(" . implode(',', $promoIds) .
						 ") limit " . $i * $limit . ",$limit";
					if($list = $promoMod->select($sql, "", array()))
					{
						foreach($list as $value)
						{
							$sql = "select count(*) from e_products_promo_used where PromoId = {$value['PromoId']} and IsCanceled = 0";
							$usedCount = $promoMod->getOne($sql, '', array());
							$sql = "select count(*) from e_products_promo_used where PromoId = {$value['PromoId']} and IsCanceled = 1";
							$cancelCount = $promoMod->getOne($sql, '', array());
							$sql = "select count(*) from e_finance_orders where	PromoId = {$value['PromoId']} and OrderStatus in(1,3)";
							$orderUsed = $finOrderMod->getOne($sql, '', array());
							$sql = "select count(*) from e_finance_orders where	PromoId = {$value['PromoId']} and OrderStatus = 2";
							$orderCancel = $finOrderMod->getOne($sql, '', array());
							if($usedCount != $orderUsed)
							{
								\core\Log::write(
									"和订单已使用次数错误：" . $value['PromoId'] . "\t" . $value['EnameId'] . "\t" . $usedCount .
										 "\t" . $orderUsed, 'crontemp/finance', 'checkPromo');
							}
							if($cancelCount != $orderCancel)
							{
								\core\Log::write(
									"和订单已取消次数错误：" . $value['PromoId'] . "\t" . $value['EnameId'] . "\t" . $cancelCount .
										 "\t" . $orderUsed, 'crontemp/finance', 'checkPromo');
							}
							if($value['UseTimes'] != $usedCount)
							{
								\core\Log::write(
									"优惠码已使用次数错误：" . $value['PromoId'] . "\t" . $value['EnameId'] . "\t" .
										 $value['UseTimes'] . "\t" . $usedCount, 'crontemp/finance', 'checkPromo');
							}
						}
						break;
					}
				}
			}
			echo "------end------\n";
		}
		catch(Exception $e)
		{
			echo $e->getMessage();
		}
	}

	/**
	 * 修复用户出入款记录
	 */
	public function fixUserFinancesAction()
	{
		try
		{
			echo "---------start----------\n";
			// $path = "/home/abc/tmp/promo1116/no_promo_all.log";
			$path = "/home/abc/tmp/promo1116/all.log";
			// 读文件
			$handle = fopen($path, 'r');
			if($handle)
			{
				$finInMod = new \models\manage\finance\FinInMod();
				$finOutMod = new \models\manage\finance\FinOutMod();
				while(!feof($handle))
				{
					$line = trim(fgets($handle));
					if($line)
					{
						$lineArr = explode(",", $line);
						$domain = $lineArr[0];
						$enameid = $lineArr[1];
						$orderid = $lineArr[2];
						$money = $lineArr[3];
						
						// 查询对应入款记录 时间范围2015-11-18 00:00:00 ~ 2015-11-18
						// 02:00:00 备注有：取消订单
						$endData = '2015-11-18 02:00:00';
						// 查询对应记录
						$sql = "select * from e_finance_in where EnameId = $enameid and OrderId = $orderid and LinkDomain = '$domain' and InMoney = $money and InType = 1";
						if($inInfo = $finInMod->getRow($sql, '', array()))
						{
							\core\Log::write(json_encode($inInfo), 'crontemp/finance', 'fixUserFinances');
							// 删除退款流水
							$sql = "delete from e_finance_in where InId = {$inInfo['InId']} and EnameId = $enameid";
							\core\Log::write($sql, 'crontemp/finance', 'fixUserFinances');
							if($finInMod->delete($sql, '', array()))
							{
								// 金额为0，不进行处理
								if($inInfo['InMoney'] != 0)
								{
									// 更新入款表CurrentMoney
									$sql = "update e_finance_in set CurrentMoney = CurrentMoney - {$inInfo['InMoney']} where EnameId = $enameid and CreateDate >= '{$inInfo['CreateDate']}' and CreateDate <= '$endData' and InRemark like %取消订单%";
									\core\Log::write($sql, 'crontemp/finance', 'fixUserFinances');
									$result = $finInMod->update($sql, '', array());
									var_dump($result);
									// 更新出款流水
									$sql = "update from e_finance_out set CurrentMoney = CurrentMoney + {$inInfo['InMoney']} where EnameId = {$enameid} and CreateDate >= {$inInfo['CreateDate']} and CreateDate <= '{$endData}'";
									\core\Log::write($sql, 'crontemp/finance', 'fixUserFinances');
									if(!$finOutMod->update($sql, '', array()))
									{
										\core\Log::write($line . ',' . $sql, 'crontemp/finance', 'fixUserFinancesError');
									}
								}
								else
								{
									\core\Log::write('InMoney:' . $inInfo['InMoney'], 'crontemp/finance', 
										'fixUserFinances');
								}
							}
							else
							{
								\core\Log::write($line . ',' . $sql, 'crontemp/finance', 'fixUserFinancesError');
							}
						}
						else
						{
							\core\Log::write($line . ',' . $sql, 'crontemp/finance', 'fixUserFinancesError');
						}
					}
				}
			}
			fclose($handle);
			echo "---------end----------\n";
		}
		catch(Exception $e)
		{
			echo $e->getMessage();
		}
	}

	/**
	 * 修复预付款为负数的记录 oa：51502
	 */
	public function repairNegMoneyAction()
	{
		$file = "/var/www/files/neg_money.csv";
		$finLogic = new \logic\manage\finance\FinanceLogic();
		$handle = fopen($file, 'r+');
		if(!$handle)
		{
			exit($file . "打开失败");
		}
		while(!feof($handle))
		{
			$line = fgets($handle);
			$info = explode(",", $line);
			if(empty($info[0]) || empty($info[2]))
			{
				continue;
			}
			$enameId = $info[0];
			$price = $info[2];
			$totalMoney = $finLogic->getUserFinance($enameId);
			$totalMoney = empty($totalMoney['UseMoney']) ? 0 : $totalMoney['UseMoney'];
			if($price != $totalMoney)
			{
				echo $enameId . "预付款总额记录异常\r\n";
				\core\Log::write($enameId . "预付款总额记录异常", 'crontemp/finance', 'repair_neg_money');
				continue;
			}
			$params = array('enameId' => $enameId, 'price' => -$price, 'remarkHide' => '2015年调账入款', 'adminId' => 91, 
				'inType' => 207);
			$result = $finLogic->manualRecharge((object)$params);
			$msg = $enameId . "添加人工入款数据" . ($result ? "成功" : "失败");
			echo $msg . "\r\n";
			\core\Log::write($msg, 'crontemp/finance', 'repair_neg_money');
		}
		fclose($handle);
	}

	/**
	 * 修复新财务表bankname为0的情况
	 */
	public function checkBankNameAction()
	{
		echo "=====begin=====\r\n";
		$finMod = new ModBase('finance');
		$query = "select * from e_finance_general2015 where BankName=0 and UpdateTime>1450799999"; // 2015-12-22
		                                                                                           // 23:59:59
		$financeInfo = $finMod->select($query, '', array());
		if(empty($financeInfo))
		{
			exit('no data');
		}
		foreach($financeInfo as $k => $v)
		{
			$query = "select PayType from e_finance_paycenter where PayId=" . $v['PayId'];
			$payInfo = $finMod->getRow($query, '', array());
			if(empty($payInfo))
			{
				echo $v['PayId'] . " not found payinfo\r\n";
				continue;
			}
			$bankName = 0;
			switch($payInfo['PayType'])
			{
				case 1: // 支付宝
					$bankName = 9;
					break;
				case 5: // 盛付通
					$bankName = 10;
					break;
				case 6: // 银联
					$bankName = 11;
					break;
			}
			if(empty($bankName))
			{
				echo $v['PayId'] . " bankname is 0\r\n";
				continue;
			}
			$query = "update e_finance_general2015 set BankName=" . $bankName . " where GeneralId=" . $v['GeneralId'];
			$upResult = $finMod->update($query, '', array());
			if(!$upResult)
			{
				echo $query . "--fail";
			}
		}
		echo "=====end=====\r\n";
	}

	/**
	 * 人工入款 根据对应订单做取消订单退款处理
	 */
	public function manualDnFinanceInByOrderAction()
	{
		$finMod = new ModBase('finance');
		$finlog = new \logic\manage\finance\FinanceLogic();
		$file = fopen("/var/www/log/crontemp/manualFinanceIn_errback_sim_2015-12-08.txt", "r");
		if(!$file)
		{
			exit("打开文件失败");
		}
		$doNum = 0;
		$remarkSc = '域名删除退款'; // 积分备注
		$remark = '取消订单';
		$remarkHide = '域名删除OA51914[经手人:杨亚凤批量]';
		$name = 'errback';
		while(!feof($file))
		{
			$line = trim(fgets($file));
			if(!$line)
			{
				continue;
			}
			$doNum++;
			// if($doNum > 1) break;
			$data = explode(",", $line);
			// $domain = '';
			$domain = $data[1];
			$enameId = $data[0];
			if(!$enameId || !$domain)
			{
				echo "没有数据\r\n";
				continue;
			}
			// 获取域名注册订单
			$orderInfo = $finMod->getRow(
				"select OutMoney,RegistarId,ProductOptions from e_finance_out where outtype = 1 and enameid = $enameId and linkdomain = '" .
					 $domain . "'
                                        and createdate > '2015-12-01'", "", array());
			var_dump($orderInfo);
			if(!$orderInfo)
			{
				\core\Log::write(implode($send), 'crontemp', 'manualFinanceIn_1208_' . $name . '_order_not');
				continue;
			}
			$money = $orderInfo['OutMoney'];
			$regId = $orderInfo['RegistarId'];
			// (object)array('enameId','price','intype','moneyType可选','domain可选'，'remark可选','remarkhide可选','adminid可选');
			$send = array('enameId' => $enameId, 'domain' => $domain, 'price' => $money, 'remark' => $remark, 
				'remarkHide' => $remarkHide, 'adminId' => 91, 'inType' => 1, 'registrarId' => $regId);
			echo $doNum . " " . implode(",", $send) . "\r\n";
			continue;
			if($doNum % 5 == 0)
				sleep(1);
			$finrs = $finlog->manualRecharge((object)$send);
			if(true == $finrs)
			{
				\core\Log::write(implode($send), 'crontemp', 'manualFinanceIn_1208_' . $name . '_suc');
				// 扣除对应积分
				$this->financeInfoLib = new \lib\manage\finance\FinanceInfoLib($enameId);
				$this->financeInfoLib->getUserFinance();
				$totalScore = $this->financeInfoLib->getTotalScore();
				$scoreLib = new \lib\manage\finance\ScoreLib();
				$scrs = $scoreLib->subScore($enameId, 17, $totalScore, 0, $remarkSc, $domain);
				\core\Log::write($line . ",", json_encode($scrs), 'crontemp', 
					'manualFinanceIn_1208_' . $name . '_score');
			}
			else
			{
				\core\Log::write(implode($send), 'crontemp', 'manualFinanceIn_1208_' . $name . '_fail');
			}
		}
	}

	/**
	 * 获取PUSH重复扣款查询
	 */
	public function getRepeatFinanceAction()
	{
		$financeMod = new ModBase('finance');
		$sql = "select count(Inid) as num,LinkDomain,EnameId,LinkEnameId,DATE_FORMAT(CreateDate, '%Y-%m-%d %H' ) as TempDate,InMoney,InRemark,OrderId 
			from e_finance_in2016 WHERE InType='101' AND CreateDate>'2016-01-01 00:00:00' AND InRemark='打包PUSH' 
			group by LinkDomain,EnameId,LinkEnameId,InMoney,InRemark,DATE_FORMAT(CreateDate, '%Y-%m-%d %H' )  HAVING num>1 order by CreateDate DESC";
		$result = $financeMod->select($sql, '', array());
		$myData = array();
		if($result)
		{
			foreach($result as $v)
			{
				$tempSql = "SELECT LinkDomain,EnameId,LinkEnameId,CreateDate,InMoney+FeeMoney as Money,OrderId
					 from e_finance_in2016 WHERE InType='101' AND CreateDate>'2016-01-01 00:00:00' and DATE_FORMAT(CreateDate, '%Y-%m-%d %H' )='" .
					 $v['TempDate'] . "' and LinkDomain='" . $v['LinkDomain'] . "' and EnameId='" . $v['EnameId'] .
					 "' and LinkEnameId='" . $v['LinkEnameId'] . "' AND InMoney='" . $v['InMoney'] . "'";
				$tempData = $financeMod->select($tempSql, '', array());
				if(count($tempData) == 2)
				{
					if(abs(strtotime($tempData[0]['CreateDate']) - strtotime($tempData[1]['CreateDate'])) > 60)
					{
						continue;
					}
				}
				$myData = array_merge($tempData, $myData);
			}
		}
		if($myData)
		{
			\core\Log::write('域名' . ',' . '接收id' . ',' . '发起id' . ',' . '日期' . ',' . '金额' . ',' . '订单id' . "\r\n", 
				'crontemp/finance', 'getRepeatFinance');
			foreach($myData as $v)
			{
				\core\Log::write(
					$v['LinkDomain'] . ',' . $v['EnameId'] . ',' . $v['LinkEnameId'] . ',' . $v['CreateDate'] . ',' .
						 $v['Money'] . ',' . $v['OrderId'] . "\r\n", 'crontemp/finance', 'getRepeatFinance');
			}
		}
		echo 'ok';
		exit();
	}

	/**
	 * 获取普通竞价订单 $orderType=102
	 */
	public function getjingjiaOrderAction()
	{
		header("Content-type: text/html; charset=utf-8");
		$orderStr = trim(file_get_contents('/var/www/ename/datacenter/order.log'));
		$file = '/var/www/ename/datacenter/getjingjiaOrder' . time() . '.csv';
		file_put_contents($file, '卖家' . ',' . '买家' . ',' . '域名' . ',' . '订单号' . ',' . '订单状态' . "\r\n", FILE_APPEND);
		$orderArr = explode("\n", $orderStr);
		$orderArr = array_unique($orderArr);
		$orderArr = array_filter($orderArr);
		$orderMod = new ModBase('finance');
		$orderType = 102;
		$sql = "select * from e_finance_orders where OrderType=" . $orderType;
		if($orderArr)
		{
			foreach($orderArr as $order)
			{
				$temp = explode(",", $order);
				$enameId = $temp[0];
				$linkEnameId = $temp[1];
				$domain = $temp[2];
				$tempSql = $sql . " and EnameId=$enameId and  LinkEnameId=$linkEnameId and  Domain='" . $domain . "'";
				$result = $orderMod->select($tempSql, '', array());
				if($result)
				{
					foreach($result as $v)
					{
						file_put_contents($file, 
							$v['EnameId'] . ',' . $v['LinkEnameId'] . ',' . $v['Domain'] . ',' . $v['OrderId'] . ',' .
								 $v['OrderStatus'] . "\r\n", FILE_APPEND);
					}
				}
			}
		}
		echo '0k';
	}

	/**
	 * 获取一口价正在处理中订单 $orderType=106
	 */
	public function getyikoujiaOrderAction()
	{
		header("Content-type: text/html; charset=utf-8");
		$orderType = 106;
		$startTime = '2016-02-18 00:00:00';
		$endTime = '2016-03-08 10:00:00';
		$orderStatus = 3;
		if($_GET['orderType'])
		{
			$orderType = $_GET['orderType'];
		}
		if($_GET['startTime'])
		{
			$startTime = $_GET['startTime'];
		}
		if($_GET['endTime'])
		{
			$endTime = $_GET['endTime'];
		}
		if($_GET['orderStatus'])
		{
			$orderStatus = $_GET['orderStatus'];
		}
		$sql = "select * from e_finance_orders where OrderType=" . $orderType .
			 " and OrderStatus=$orderStatus and  CreateTime>='" . $startTime . "'";
		if($endTime)
		{
			$sql .= " and  CreateTime<='" . $endTime . "'";
		}
		$file = '/var/www/ename/datacenter/getyikoujiaOrder' . time() . '.csv';
		file_put_contents($file, '卖家' . ',' . '买家' . ',' . '域名' . ',' . '订单号' . ',' . '订单状态' . "\r\n", FILE_APPEND);
		$orderMod = new ModBase('finance');
		$result = $orderMod->select($sql, '', array());
		if($result)
		{
			foreach($result as $v)
			{
				file_put_contents($file, 
					$v['EnameId'] . ',' . $v['LinkEnameId'] . ',' . $v['Domain'] . ',' . $v['OrderId'] . ',' .
						 $v['OrderStatus'] . "\r\n", FILE_APPEND);
			}
		}
		echo '0k';
	}

	/**
	 * 修复用户出入款金额
	 */
	public function repairUserFinanceRecodAction()
	{
		echo "------start------\n";
		try
		{
			$enameId = 48091;
			$balance = 561.00 ;
			$finMod = new ModBase('finance');
			if(!$inData = $finMod->select(
				"select * from e_finance_in2016 where EnameId = ? and CreateDate > '2016-01-01 00:00:00' order by CreateDate ASC,InId ASC", 'i', 
				array($enameId)))
			{
				throw new Exception('获取用户入款记录失败');
			}
			if(!$outData = $finMod->select(
				"select * from e_finance_out2016 where EnameId = ? and CreateDate > '2016-01-01 00:00:00' order by CreateDate ASC,OutId ASC", 'i', 
				array($enameId)))
			{
				throw new Exception('获取用户出款记录失败');
			}
			$i = 1;
			while($outData || $inData)
			{
				echo $i++, "\n";
				if(empty($in) && $inData)
				{
					$in = array_shift($inData);
				}
				if(empty($out) && $outData)
				{
					$out = array_shift($outData);
				}
				if(!empty($in) && !empty($out))
				{
					if($in['CreateDate'] <= $out['CreateDate'])
					{
						$balance = sprintf("%.4f", $balance + $in['InMoney']);
						if($balance != $in['CurrentMoney'])
						{
							$sql = "update e_finance_in2016 set CurrentMoney = {$balance} where InId = {$in['InId']} and EnameId = {$enameId} and OrderId = {$in['OrderId']} and CreateDate = '{$in['CreateDate']}'";
							\core\Log::write($sql, 'crontemp/finance', 'repairUserFinanceRecod');
						}
						unset($in);
					}
					else
					{
						$balance = sprintf("%.4f", $balance - $out['OutMoney']);
						if($balance != $out['CurrentMoney'])
						{
							$sql = "update e_finance_out2016 set CurrentMoney = {$balance} where OutId = {$out['OutId']} and EnameId = {$enameId} and OrderId = {$out['OrderId']} and CreateDate = '{$out['CreateDate']}'";
							\core\Log::write($sql, 'crontemp/finance', 'repairUserFinanceRecod');
						}
						unset($out);
					}
				}
				else if(empty($in) && !empty($out))
				{
					$balance = sprintf("%.4f", $balance - $out['OutMoney']);
					if($balance != $out['CurrentMoney'])
					{
						$sql = "update e_finance_out2016 set CurrentMoney = {$balance} where OutId = {$out['OutId']} and EnameId = {$enameId} and OrderId = {$out['OrderId']} and CreateDate = '{$out['CreateDate']}'";
						\core\Log::write($sql, 'crontemp/finance', 'repairUserFinanceRecod');
					}
					unset($out);
				}
				else if(!empty($in) && empty($out))
				{
					$balance = sprintf("%.4f", $balance + $in['InMoney']);
					if($balance != $in['CurrentMoney'])
					{
						$sql = "update e_finance_in2016 set CurrentMoney = {$balance} where InId = {$in['InId']} and EnameId = {$enameId} and OrderId = {$in['OrderId']} and  CreateDate = '{$in['CreateDate']}'";
						\core\Log::write($sql, 'crontemp/finance', 'repairUserFinanceRecod');
					}
					unset($in);
				}
			}
		}
		catch(Exception $e)
		{
			echo $e->getMessage()."\n";
		}
		echo "------end------\n";
	}

	/**
	 * 检测用户订单金额和扣款顺序金额不符问题
	 */
	public function checkOrderAction()
	{
		echo "-----start-----\n";
		$finMod = new ModBase('finance');
		$sql = "select count(*) from e_finance_orders where OrderId >= 23287568 ";
		if($count = $finMod->getOne($sql, '', array()))
		{
			echo $count, "\n";
			$limit = 1000;
			$page = ceil($count / $limit);
			for($i = 0; $i < $page; $i++)
			{
				echo $i, ",";
				$sql = "select Price,OrderId,FreezeMoneySort from e_finance_orders where OrderId >= 23287568  limit " .
					 $i * $limit . ',' . $limit;
				if($list = $finMod->select($sql, '', array()))
				{
					foreach($list as $value)
					{
						$freezeMoneySort = json_decode($value['FreezeMoneySort'], true);
						$count = floatval($freezeMoneySort['p']) + floatval($freezeMoneySort['u']) +
							 floatval($freezeMoneySort['w']) + floatval($freezeMoneySort['m']);
						if($count != $value['Price'])
						{
							\core\Log::write($value['OrderId'], 'crontemp/finance', 'checkOrder');
						}
					}
				}
			}
		}
		echo "-----end----\n";
	}

	/**
	 * 检测用户账户金额
	 */
	public function checkUserFinanceAction()
	{
		echo "-----start-----\n";
		$finMod = new ModBase("finance");
		$content = file_get_contents("/home/lixk/share/20160323ordersenameid.txt");
		$contentArr = explode("\n", trim($content));
		foreach($contentArr as $enameId)
		{
			if(!$enameId = intval($enameId))
			{
				continue;
			}
			$sql = "select FreezeMoney from e_finances where EnameId = ?";
			if(!$userFinance = $finMod->getRow($sql, 'i', array($enameId)))
			{
				\core\Log::write("获取用户：{$enameId}账户失败", 'crontemp/finance', 'getUserFinanceError');
				continue;
			}
			$sql = "select sum(Price) from e_finance_orders where EnameId = {$enameId} and OrderStatus = 3";
			$freeCount = $finMod->getOne($sql, '', array());
			if(bcsub($userFinance['FreezeMoney'], $freeCount) != 0)
			{
				\core\Log::write("{$enameId}", 'crontemp/finance', "checkUserFinanceError");
			}
			else
			{
				\core\Log::write("{$enameId}", 'crontemp/finance', "checkUserFinanceOk");
			}
		}
		echo "-----end-----\n";
	}

	/**
	 * 0元圆通快递订单处理
	 */
	public function xiufuDelivery0YuanAction()
	{
		echo "-----start-----\n";
		$finMod = new ModBase("finance");
		$sql = "select * from e_finance_invoice where InvoiceAmout >=500 AND DeliveryType=1 AND PayWay=2 AND DeliveryFare=0.0000 and InvoiceStatus in (4,5)";
		$list = $finMod->select($sql, array(), array());
		echo '数量' . count($list) . "\n";
		$finOrder = new \interfaces\manage\Finance();
		foreach($list as $v)
		{
			if(!$v['OrderId'])
			{
				continue;
			}
			$orderInfo = $finOrder->getOrderInfo($v['EnameId'], $v['OrderId']);
			if(!$orderInfo || $orderInfo['OrderStatus'] != 3)
			{
				continue;
			}
			if($v['InvoiceStatus'] == 5)
			{
				$finOrder->confirmOrder((object)array('enameId' => $v['EnameId'], 'orderId' => $v['OrderId']));
			}
			if($v['InvoiceStatus'] == 4)
			{
				$finOrder->cancelOrder((object)array('enameId' => $v['EnameId'], 'orderId' => $v['OrderId']));
			}
		}
		echo "-----OK-----\n";
	}
	
	public function transOrderConfirmAction()
	{
		$file = fopen("/tmp/viya20160708transorder.txt", "r");
		if(!$file)
		{
			exit("打开文件失败");
		}
		$remark = '20160708交易订单手动确认[杨亚凤]';
		$finOrder = new \interfaces\manage\Finance();
		while(!feof($file))
		{
			$line = trim(fgets($file));
			if(!$line)
			{
				continue;
			}
			$doNum ++;
			if($doNum > 1) break;
			$arrs= explode(",", $line);
			$orderId = $arrs[0];
			$moneyType = $arrs[1];
			$enameId = $arrs[2];
			echo $doNum . "," . $orderId . "--" . $enameId . "--" . $moneyType . "\r\n";
			if(!$orderId || !$enameId)
			{
				echo "enameId orerid出错\r\n";
				continue;
			}
			$orderInfo = $finOrder->getOrderInfo($enameId, $orderId);
			if(!$orderInfo || $orderInfo['OrderStatus'] != 3)
			{
				echo "订单info或者状态错误\r\n";
				continue;
			}
			$rs = $finOrder->confirmOrder((object)array('enameId' => $enameId,'orderId' => $orderId,'moneyType'=>$moneyType));
			if($rs)
			{
				\core\Log::write($orderId . "--" . $enameId, 'crontemp/finance', "transOrderConfirm_suc");
			}
			else
			{
				\core\Log::write($orderId . "--" . $enameId, 'crontemp/finance', "transOrderConfirm_fail");
			}
		}
	}

	/**
	 * 人工入款 对应具体财务类型和产品 扣除积分
	 * wang续费转入活动阶梯补返款返款 OA63019
	 */
	public function manualJietiFinanceInRepairAction()
	{
		$fileName = "/tmp/wang_renew_back_money_repair.csv";
		$finlog = new \logic\manage\finance\FinanceLogic();
		$file = fopen($fileName, "r");
		if(!$file)
		{
			exit("打开文件失败");
		}
		$doNum = 0;
		$remarkSc = 'wang续费阶梯返款扣除相应积分';//积分备注
		$remark = 'wang续费阶梯返款';
		$remarkHide = 'OA63019[wang活动补返现]';
		while(!feof($file))
		{
			$line = trim(fgets($file));
			if(!$line)
			{
				continue;
			}
			$doNum++;
			$data = explode(",", $line);
			$total = $data[1];
			$enameId = $data[0];
			$totalOri = $data[2];
			$enameIdOri = $data[3];
			// 比对数据
			if($enameId != $enameIdOri || $total < $totalOri)
			{
				echo $enameId .'、'.$total.'、'. $enameIdOri .'、'.$totalOri. "数据出错啦\r\n";
				continue;
			}
			if($total == $totalOri)
			{
				echo $enameId .'、'.$total.'、'. $enameIdOri .'、'.$totalOri. "数据无需更更新\r\n";
				continue;
			}
			$domain = '';
			//计算现统计给返现的钱
			if($total < 100)
			{
				continue;
			}
			elseif($total >= 100 && $total < 200)
			{
				$price = $total;
			}
			elseif($total >= 200 && $total < 500)
			{
				$price = $total * 2;
			}
			elseif($total >= 500)
			{
				$price = $total * 3;
			}
			//原统计给返现的钱
			if($totalOri < 100)
			{
				$priceOri=0;
			}
			elseif($totalOri >= 100 && $totalOri < 200)
			{
				$priceOri = $totalOri;
			}
			elseif($totalOri >= 200 && $totalOri < 500)
			{
				$priceOri = $totalOri * 2;
			}
			elseif($totalOri >= 500)
			{
				$priceOri = $totalOri * 3;
			}
			//需要补返现
			$price =$price -$priceOri;
			// (object)array('enameId','price','intype','moneyType可选','domain可选'，'remark可选','remarkhide可选','adminid可选');
			$send = array('enameId' => $enameId, 'domain' => $domain, 'price' => $price, 'remark' => $remark,
				'remarkHide' => $remarkHide, 'adminId' => 185, 'inType' => 206, 'inTypeSon' => 64);
			echo $doNum . " " . implode(",", $send) . "\r\n";
			if($doNum % 5 == 0)
			{
				sleep(1);
			}
			$finrs = $finlog->manualRecharge((object)$send);
			if(true == $finrs)
			{
				\core\Log::write(implode($send), 'crontemp', 'manualJietiFinanceIn_suc');
				// 扣除对应积分
				try
				{
					$this->financeInfoLib = new \lib\manage\finance\FinanceInfoLib($enameId);
					$this->financeInfoLib->getUserFinance();
					$totalScore = $this->financeInfoLib->getTotalScore();
					$scoreLib = new \lib\manage\finance\ScoreLib();
					$scrs = $scoreLib->subScore($enameId, $price, $totalScore, 0, $remarkSc, $domain);
					\core\Log::write($line . ",", $scrs, 'crontemp', 'manualJietiFinanceIn_score');
				}
				catch (Exception $e)
				{
					\core\Log::write($line . ",", $e->getMessage(), 'crontemp', 'manualJietiFinanceIn_score_err');
				}
			}
			else
			{
				\core\Log::write(implode($send), 'crontemp', 'manualJietiFinanceIn_fail');
			}
		}
	}
	
	/**
	 * 根据订单信息修复财务出入流水的备注信息
	 */
	public function repairFinanceRemarkAction()
	{
		$finMod = new ModBase('finance');
		$query = "select OrderId,Remark,RemarkHide,EnameId,LinkEnameId from e_finance_orders where OrderId>30294500 and OrderType=106 and OrderStatus=1 and UpdateTime>='2016-10-27 17:30:00' and UpdateTime<='2016-10-27 19:00:00'";
		$orderInfo = $finMod->select($query, '', array());
		if(empty($orderInfo))
		{
			exit('no data');
		}
		foreach ($orderInfo as $v)
		{
			$query = "update e_finance_out2016 set OutRemark='{$v['Remark']}',OutRemarkHide='{$v['RemarkHide']}' where OutType=106 and EnameId={$v['EnameId']} and LinkEnameId={$v['LinkEnameId']} and OrderId={$v['OrderId']}";
			$result = $finMod->update($query, '', array(), true, true);
			echo intval($result)."【".$query."】\r\n";
			$query = "update e_finance_in2016 set InRemark='{$v['Remark']}',InRemarkHide='{$v['RemarkHide']}' where InType=106 and EnameId={$v['LinkEnameId']} and LinkEnameId={$v['EnameId']} and OrderId={$v['OrderId']}";
			$result = $finMod->update($query, '', array(), true, true);
			echo intval($result)."【".$query."】\r\n";
			$query = "update e_finance_general2016 set Remark='{$v['Remark']}',RemarkHide='{$v['RemarkHide']}' where InOutType=106 and OrderId={$v['OrderId']}";
			$result = $finMod->update($query, '', array(), true, true);
			echo intval($result)."【".$query."】\r\n";
		}
	}

	/**
	 * 购物数据修复
	 */
	public function repairShopAction()
	{
		try
		{
			$produceMod = new ModBase('product');
			$num = 0;
			$size = 500;
			while(true)
			{
				$limit = ($num * $size) . ',' . $size;
				$query = "select `ShopId`,`Ext` from e_domain_shop where ShopType=2 and ShopTime<'2016-12-24 00:00:00' limit $limit"; // 转入 改DNSTYPE类型
				$info2 = $produceMod->select($query, '', array());
				if($info2)
				{
					foreach($info2 as $v2)
					{
						$ext = json_decode($v2['Ext'], true);
						if(!isset($ext['dnsType']))
						{
							continue;
						}
						$ext['dnsType'] = (int)$ext['dnsType'];
						$ext['islock'] = isset($ext['islock']) ? (int)$ext['islock'] : 1;
						$ext = json_encode($ext);
						$shopid2 = $v2['ShopId'];
						$updata2 = "UPDATE e_domain_shop set Ext='{$ext}' WHERE `ShopId`={$shopid2}";
						echo $shopid2."\r\n";
						$produceMod->update($updata2, '', array());
					}
				}
				$num++;
				if(empty($info1) && empty($info2))
				{
					break;
				}
			}
			echo 'ok';
		}
		catch(\Exception $e)
		{
			\core\Log::write($e->getMessage(), 'e_domain_shop_update');
		}
	}
}
<?php
use core\ModBase;
use core\core;

class VipController extends Yaf\Controller_Abstract
{
	public function explodeVipListAction()
	{
		echo "begin\r\n";
		$userMod = new ModBase('user');
		$query = "select * from e_member_vip";
		$list = $userMod->select($query, '', array());
		if(!empty($list))
		{
			foreach($list as $v)
			{
				\core\Log::write(var_export($v, true), 'crontemp/vip', 'explodeviplist_backup');
				$tempList = explode(',', $v['Content']);
				if(count($tempList) > 1)
				{
					foreach($tempList as $con)
					{
						$add = "insert into e_member_vip(`AdminUser`,`CreateTime`,`Type`,`Content`) values('{$v['AdminUser']}','{$v['CreateTime']}','{$v['Type']}','{$con}')";
						$addRes = $userMod->add($add, '', array());
						if($addRes)
						{
							\core\Log::write($add, 'crontemp/vip', 'explodeviplist_success');
						}
						else 
						{
							echo "error:".$add."\r\n";
							\core\Log::write($add, 'crontemp/vip', 'explodeviplist_error');
						}
					}
					$del = "delete from e_member_vip where Vid=".$v['Vid'];
					$delRes = $userMod->delete($del, '', array());
					if($delRes)
					{
						\core\Log::write($del, 'crontemp/vip', 'explodeviplist_success');
					}
					else
					{
						echo "error:".$del."\r\n";
						\core\Log::write($del, 'crontemp/vip', 'explodeviplist_error');
					}
				}
			}
		}
		echo "end\r\n";
	}
}

<?php
use core\ModBase;

class SendsmsController extends Yaf\Controller_Abstract
{
	public function sendAction()
	{
		$file = "/tmp/send_sms_enameid.csv";
		$save = "/tmp/send_sms_enameid_mobile.csv";
		//$file = "/Users/ename/Downloads/send_sms_enameid.csv";
		$handle = fopen($file, 'r+');
		if(!$handle)
		{
			exit('文件打开失败');
		}
		$userMod = new ModBase("user");
		$queueLogic = new \logic\manage\newqueue\QueueLogic();
		$i = 1;
		$sendList = array();
		$contents = "尊敬的易名用户：近期我司接到用户反馈，有不法分子冒充我司名义电话通知用户域名信息有变更并索取备案信息的违法行径。在此，特别提醒您:如您收到任何可疑电话或邮件，请您务必联系我司客服（电话／QQ：4000044400，客服邮件：1001@ename.com）进行核实确认，谨防上当受骗。";
		while (!feof($handle))
		{
			$line = fgets($handle);
			$line = trim($line,"\r\n");
			$line = trim($line);
			$enameId = $line;
			if(!empty($enameId))
			{
				if($enameId <= 1040242)
				{
					continue;
				}
				$query = "select Mobile from e_member_ext where EnameId={$enameId}";
				$info = $userMod->getRow($query, "", array());
				if(!empty($info['Mobile']))
				{
					$mobile = $info['Mobile'];
					file_put_contents($save, $enameId.",".$mobile."\r\n", FILE_APPEND);
// 					if(in_array($mobile, $sendList))
// 					{
// 						continue;
// 					}
// 					try 
// 					{
// 						$result = $queueLogic->addQueueNormal(array('Function' => 'send_sms', 'TemplateName' => 'any_template_info', 'EnameId' => $enameId,	'Priority' => 5, 'Target' => $mobile, 'Data' => array('content' => $contents, 'title' => '')));
// 						if($result)
// 						{
// 							$sendList[] = $mobile;
// 							echo $enameId."_".$mobile."发送成功\r\n";
// 							$i++;
// 						}
// 					}
// 					catch (Exception $e)
// 					{
// 						echo $enameId."_".$mobile."发送失败".$e->getMessage()."\r\n";
// 					}
				}
				else 
				{
					echo $enameId."_无手机号\r\n";
				}
			}
// 			if($i % 50 == 0)
// 			{
// 				sleep(5);
// 			}
		}
		fclose($handle);
	}
}
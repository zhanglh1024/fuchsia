<?php
use core\ModBase;
use \lib\manage\domain\DomainLogsLib;

/**
 * 获取webcc转接口 用户id 邮箱和域名
 *
 * @author lixk
 *        
 */
class WebcctransferController extends yaf\Controller_Abstract
{

	/**
	 * 获取所有需要webcc转接口的用户 域名 id邮箱
	 */
	public function getlistAction()
	{
		echo "--------start--------\n";
		set_time_limit(0);
		$list = array();
		// 实例化user和domain模型
		$userMod = new ModBase('user');
		$domainMod = new ModBase('domain');
		
		// 查询条件 注册id为61 且后缀为cc、tv、com、net、biz
		$where = 'DomainLtd in (3,4,11,16,17) and RegistrarId = 61';
		$type = '';
		$values = array();
		// 统计总条数
		$count = $domainMod->getOne('select count(*) num from e_domains where ' . $where, $type, $values);
		
		// 每次查询的条数
		$num = 10000;
		if($count)
		{
			$i = 0;
			while($i < $count)
			{
				$data = array();
				// 查询num条域名数据
				$result = $domainMod->select(
					"select distinct EnameId,DomainName from e_domains where {$where} limit {$i},{$num}", $type, $values);
				// 数据组装
				foreach($result as $v)
				{
					$data[$v['EnameId']]['EnameId'] = $v['EnameId'];
					$data[$v['EnameId']]['DomainName'][] = $v['DomainName'];
				}
				
				// 写入文件
				foreach($data as $v)
				{
					// 读取用户的id邮箱
					$userData = $userMod->getRow('select Email from e_member where EnameId = ?', 'i', 
						array($v['EnameId']));
					// 邮箱不存在记录错误日志
					if(empty($userData) || empty($userData['Email']))
					{
						core\Log::write('ID邮箱不存在;' . $v['EnameId'] . ';' . json_encode($v['DomainName']), 
							'crontemp/webcc', 'mailError');
						continue;
					}
					else
					{
						$domains = count($v['DomainName']) > 8 ? array_slice($v['DomainName'], 0, 7) : $v['DomainName'];
						// 将用户 邮箱 域名记录文件
						\core\Log::write($v['EnameId'] . ';' . $userData['Email'] . ';' . implode('<br />', $domains), 
							'crontemp/webcc', 'getWebccUserDomainMail');
					}
				}
				$i += $num;
			}
		}
		echo "--------end--------\n";
	}

	/**
	 * webcc转接口功能上线，webcc提交转接口45天内有续费的域名名单，跑出来
	 */
	public function getrenewlistAction()
	{
		set_time_limit(0);
		$list = array();
		$financeMod = new ModBase('finance');
		$manageMod = new ModBase('manageother');
		
		$status = array('1' => '提交申请', '2' => '已发转移密码', '3' => '转移成功', '4' => '转移失败', '5' => '正在转接口');
		$list = $manageMod->select("select domain,status,enameid,expdate,createtime from transfer_epp", '', array());
		if(empty($list))
		{
			exit('not found data');
		}
		$newtime = date('Y-m-d H:i:s', strtotime("-45 day -8 hours"));
		echo $newtime . "\r\n";
		foreach($list as $info)
		{
			echo $info['domain'] . "\r\n";
			$rs = $financeMod->getRow(
				"select CreateTime,RegistarId from e_finance_orders where enameid = " . $info['enameid'] . " and ordertype = 3 and orderstatus = 1 
				and domain = '" . $info['domain'] . "' and UpdateTime > '" . $newtime . "' order by orderid desc", '', array());
			$info['createtime'] = date('Y-m-d H:i:s', $info['createtime']);
			$info['expdate'] = date('Y-m-d H:i:s', $info['expdate']);
			$info['status'] = $status[$info['expdate']];
			if($rs)
			{
				echo "do \r\n";
				\core\Log::write(implode(",", $info) . "," . implode(",", $rs), 'crontemp/webcc', 'getrenewlistDo');
			}
			else
			{
				\core\Log::write(implode(",", $info), 'crontemp/webcc', 'getrenewlist');
			}
		}
	}

	/**
	 * 查询域名webcc域名本地转移失败，但注册局状态和本地不一致的域名
	 */
	public function getTransferFailureAction()
	{
		$domainMod = new ModBase('domain');
		$manageMod = new ModBase('manageother');
		$sql = 'select * from transfer_epp where status = 4';
		$result = $manageMod->select($sql, array(), array());
		if($result)
		{
			$transferInMod = new \models\manage\domain\DomainTransferInMod();
			$epp = new \lib\manage\domain\DomainEppLib();
			foreach($result as $value)
			{
				$domainArr = explode('.', $value['domain']);
				$domailtd = strtoupper($domainArr[count($domainArr) - 1]);
				switch($domailtd)
				{
					case 'CC':
						$newregistid = 81;
						break;
					case 'TV':
						$newregistid = 81;
						break;
					case 'BIZ':
						$newregistid = 82;
						break;
					default:
						$newregistid = 21;
						break;
				}
				// 查询域名信息5028
				$domainInfo = $epp->getDomainRegTransInfo($value['domain'], $newregistid);
				if($domainInfo)
				{
					if($domainInfo['status'] == 'clientApproved' || $domainInfo['status'] == 'serverApproved')
					{
						if($epp->getDomainRegInfo($value['domain'], $newregistid))
						{
							\core\Log::write($value['domain'], 'crontemp/webcc', 'transferError');
						}
						else
						{
							\core\Log::write($value['domain'], 'crontemp/webcc', 'transfer5025Error');
						}
					}
					elseif($domainInfo['status'] != 'clientRejected')
					{
						\core\Log::write($value['domain'] . ',' . $domainInfo['status'], 'crontemp/webcc', 
							'transferOtherStatus');
					}
				}
			}
		}
		else
		{
			echo "查无数据\n";
		}
	}

	/**
	 * webcc转接口成功的域名增加注册局状态
	 */
	public function addDomainStatusAction()
	{
		echo "------start------\n";
		$manageMod = new ModBase('manageother');
		$sql = 'select * from transfer_epp where status in(3,4)';
		$result = $manageMod->select($sql, array(), array());
		if($result)
		{
			$transferOutMod = new \models\manage\domain\DomainTransferOutMod();
			$dnManagemod = new \models\manage\domain\DomainsMod();
			$epp = new \lib\manage\domain\DomainEppLib();
			foreach($result as $value)
			{
				if(!$domainInfo = $dnManagemod->getDomainInfo(array('DomainName' => $value['domain'])))
				{
					\core\Log::write('webcc转接口,域名列表中域名' . $value['domain'] . '获取失败', 'crontemp/webcc', 'transferepp');
					continue;
				}
				// 正在转出的 不添加注册局状态
				if($domainInfo['DomainMyStatus'] == 5)
				{
					\core\Log::write('webcc转接口,域名：' . $value['domain'] . '正在转出', 'crontemp/webcc', 'transferepp');
					continue;
				}
				
				if($domainInfo['RegistrarId'] == 61)
				{
					\core\Log::write('webcc转接口,域名：' . $value['domain'] . '接口61 无需增加状态', 'crontemp/webcc', 'transferepp');
					continue;
				}
				
				if(!$rs = $epp->setDomainRegisterStatus($value['domain'], $domainInfo['RegistrarId'], array(3, 4)))
				{
					\core\Log::write('webcc转接口更新注册局状态失败,域名' . $value['domain'], 'crontemp/webcc', 'transferepp');
					continue;
				}
				if(!$dnManagemod->upDomainInfo(array('DomainName' => $value['domain']), array('DomainStatus' => '3,4')))
				{
					\core\Log::write('webcc转接口更新状态失败,域名' . $value['domain'], 'crontemp/webcc', 'transferepp');
				}
			}
		}
		echo "------end------\n";
	}

	/**
	 * 导出6月3号到14号间有过户ID的webcc接口域名
	 */
	public function exportWebccDomainAction()
	{
		$beginTime = "2015-06-03 00:00:00";
		$endTime = "2015-06-14 23:59:59";
		$saveFile = "/var/www/files/webcc_domains.csv";
		$whoisLib = new \common\WhoisLib();
		$dnMod = new ModBase('domain');
		$domainMod = new \models\manage\domain\DomainsMod();
		$gainDomain = array();
		echo "begin export webcc domain\r\n";
		error_log("域名\t当前的ID\t原ID\twhois邮箱\twhois状态\r\n", 3, $saveFile);
		$query = "select * from e_domain_push where ReceiveStatus=1 and SendStatus=0 and ReceiveTime>='" . $beginTime .
			 "' and ReceiveTime<='" . $endTime . "'";
		$info = $dnMod->select($query, '', array());
		if(empty($info))
		{
			\core\Log::write('无相应域名信息--push表', 'crontemp/webcctransfer', 'exportwebccdomain');
		}
		else
		{
			foreach($info as $v)
			{
				$domains = explode("\n", $v['DomainName']);
				foreach($domains as $domain)
				{
					$whois = self::getWhois($domain, $domainMod, $whoisLib);
					if(!$whois)
					{
						continue;
					}
					$gainDomain[] = $domain;
					error_log(
						$domain . "\t" . $v['ReceiveId'] . "\t" . $v['SendId'] . "\t" . $whois['email'] . "\t" .
							 $whois['serInfo'] . "\r\n", 3, $saveFile);
				}
			}
		}
		$transMod = new ModBase('trans');
		$query = "select * from trans_delivery where DeliveryStatus=8 and DeliveryDate>='" . $beginTime .
			 "' and DeliveryDate<='" . $endTime . "'";
		$info = $transMod->select($query, '', array());
		if(empty($info))
		{
			\core\Log::write('无相应域名信息--交易', 'crontemp/webcctransfer', 'exportwebccdomain');
		}
		else
		{
			foreach($info as $v)
			{
				if(in_array($v['DomainName'], $gainDomain))
				{
					\core\Log::write('域名已处理过【' . $v['DomainName'] . '】', 'crontemp/webcctransfer', 'exportwebccdomain');
					continue;
				}
				$whois = self::getWhois($v['DomainName'], $domainMod, $whoisLib);
				if(!$whois)
				{
					continue;
				}
				error_log(
					$v['DomainName'] . "\t" . $v['Seller'] . "\t" . $v['Buyer'] . "\t" . $whois['email'] . "\t" .
						 $whois['serInfo'] . "\r\n", 3, $saveFile);
			}
		}
		echo "end export webcc domain\r\n";
	}

	public function exportUserDomainInfoAction()
	{
		$userIds = array(586378, 561305);
		$whoisLib = new \common\WhoisLib();
		$dnMod = new ModBase('domain');
		$domainMod = new \models\manage\domain\DomainsMod();
		$templateMod = new \models\manage\domain\TemplateMod();
		echo "----export start----";
		foreach($userIds as $userId)
		{
			$saveFile = '/var/www/eNameID-' . $userId . '-DomainList.csv';
			$where = array('EnameId' => $userId, 'RegistrarId' => 61);
			$userDomains = $domainMod->getDomainList($where);
			if($userDomains)
			{
				error_log("ID,域名,模板邮箱,whois邮箱\r\n", 3, $saveFile);
				foreach($userDomains as $domain)
				{
					$templateId = $domain['PrivacyTemp'] ? $domain['PrivacyTemp'] : $domain['TemplateId'];
					$templateInfo = $templateMod->getTempInfoByTempId($templateId);
					if($templateInfo)
					{
						$email = $templateInfo['Email'];
						error_log($userId . ',' . $domain['DomainName'] . ',' . $email . ',' . $email . "\r\n", 3, 
							$saveFile);
					}
				}
			}
		}
		echo "----export success----";
	}

	public function addTempEmailToFileAction()
	{
		$oldFile = '/var/www/webcc_domainsa21.csv';
		$newFile = '/var/www/webcc_domainsa21_new.csv';
		$fh = fopen($oldFile, 'a+') or die('Open File Fail');
		$newFh = fopen($newFile, 'a+') or die('Open New File Fail');
		echo "------start-------\r\n";
		while(!feof($fh))
		{
			$row = trim(fgets($fh));
			$rowArr = !empty($row) ? explode(',', $row) : '';
			if(is_array($rowArr))
			{
				$domain = $rowArr[0];
				$domainMod = new \models\manage\domain\DomainsMod();
				$templateMod = new \models\manage\domain\TemplateMod();
				$domainInfo = $domainMod->getDomainInfo(array('DomainName' => $domain));
				if($domainInfo)
				{
					$templateId = $domainInfo['PrivacyTemp'] ? $domainInfo['PrivacyTemp'] : $domainInfo['TemplateId'];
					$templateInfo = $templateMod->getTempInfoByTempId($templateId);
					if($templateInfo)
					{
						$email = $templateInfo['Email'];
						$saveStr = $row . ',' . $email . "\r\n";
						fwrite($newFh, $saveStr);
					}
					else
					{
						echo 'domain:' . $domain . "get templateInfo error\r\n";
					}
				}
				else
				{
					echo 'Get Domain:' . $domain . " Info Error!\r\n";
				}
			}
		}
		fclose($fh);
		fclose($newFh);
		echo '--------end-------';
	}

	private function getWhois($domain, $domainMod, $whoisLib)
	{
		$domainInfo = $domainMod->getDomainInfo(array('DomainName' => $domain));
		if(!$domainInfo || $domainInfo['RegistrarId'] != 61)
		{
			\core\Log::write('域名接口不是61【' . $domain . '】', 'crontemp/webcctransfer', 'exportwebccdomain');
			return false;
		}
		$whoisInfo = (array)$whoisLib->getWhoisBasicInfoByDomain($domain);
		if(!$whoisInfo || empty($whoisInfo['Status']) || empty($whoisInfo['AdministrativeEmail']))
		{
			\core\Log::write('获取whois信息失败【' . $domain . '】', 'crontemp/webcctransfer', 'exportwebccdomain');
			return false;
		}
		$serverInfo = array();
		foreach(explode(",", $whoisInfo['Status']) as $status)
		{
			$s = explode(" ", $status);
			$serverInfo[] = $s[0];
		}
		$email = empty($whoisInfo['AdministrativeEmail']) ? "获取失败" : $whoisInfo['AdministrativeEmail'];
		return array('serInfo' => implode("--", $serverInfo), 'email' => $email);
	}

	/**
	 * 模板过户
	 */
	public function templatePushAction()
	{
		$content = trim(file_get_contents('/www/1.txt'));
		$lines = explode("\n", $content);
		if($lines)
		{
			$templateMod = new \models\manage\domain\TemplateMod();
			$dnManageLib = new \lib\manage\domain\DomainManageLib();
			$domainlogic = new \logic\manage\domain\DomainManageLogic();
			$sysTemp = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'systemplate');
			$templateLib = new \lib\manage\domain\TemplateLib();
			foreach($lines as &$v)
			{
				if($v = trim($v))
				{
					$info = explode(',', $v);
					$domain = $info[0];
					$enameid = $info[1];
					$params = array('EnameId' => $enameid, 'IsShow' => 1, 'TemplateType' => 2);
					// 获取可以模板 有设置默认模板的话 数组的第一个
					$enTemplates = $templateLib->getUseTemplates($enameid, 'TradeTemplate');
					$templateInfo = empty($enTemplates) ? array('TemplateId' => $sysTemp['systemTempId'][0], 
							'TempUserName' => $sysTemp['systemTempName'], 'TemplateType' => 0) : $enTemplates[0];
					$domainInfo = $dnManageLib->getDomainInfo(array('DomainName' => $domain));
					if($domainInfo['EnameId'] != $enameid)
					{
						\core\Log::write("域名:$domain ,域名无权操作", 'crontemp/webcctransfer', 'templatePushError');
						continue;
					}
					// 判断当前模板 是否 是用户的模板
					$tempIds = array();
					foreach($enTemplates as $v)
					{
						$tempIds[] = $v['TemplateId'];
					}
					if(in_array($domainInfo['TemplateId'], $tempIds))
					{
						\core\Log::write("域名:$domain ,域名无需模板过户", 'crontemp/webcctransfer', 'templatePushError');
						continue;
					}
					
					$data['domain'] = $domain;
					$data['templateId'] = $templateInfo['TemplateId'];
					$data['oldTemplateId'] = $domainInfo['TemplateId'];
					$data['registrarId'] = $domainInfo['RegistrarId'];
					$data['newTemplateName'] = $templateInfo['TempUserName'];
					$data['tempType'] = $templateInfo['TemplateType'];
					$data['oldTemplateName'] = $domainInfo['TempUserName'];
					$data['enameId'] = $enameid;
					
					if($rs = $domainlogic->templatePushLogic($data))
					{
						DomainLogsLib::addDomainService($domain, 
							array('memo' => 'template_push', 'param' => $data, 'rs' => $rs), 17);
						\core\Log::write(
							'模板过户成功，域名：' . $domain . ',Enameid:' . $enameid . ',oldtempid:' . $data['oldTemplateId'] .
								 ',newtemplateid:' . $data['templateId'], 'crontemp/webcctransfer', 'templatePushError');
					}
					else
					{
						\core\Log::write(
							'转接口模板过户失败，域名：' . $domain . ',Enameid:' . $enameid . ',oldtempid:' . $data['oldTemplateId'] .
								 ',newtemplateid:' . $data['templateId'], 'crontemp/webcctransfer', 'templatePushError');
					}
				}
			}
		}
	}
	
	/**
	 * 获取所有webcc域名并比对whois邮箱和模板邮箱是否一致
	 */
	public function getDomainTplMatchAction()
	{
		set_time_limit(0);
		$list = array();
		$userMod = new ModBase('user');
		$domainMod = new ModBase('domain');
		$templateMod = new \models\manage\domain\TemplateMod();
	
		// 查询条件注册id为61
		$where = ' RegistrarId = 61';
		$type = '';
		$values = array();
		// 统计总条数
		$count = $domainMod->getOne('select count(*) num from e_domains where ' . $where, $type, $values);
		var_dump($count);
		// 每次查询的条数
		$num = 10000;
		if($count)
		{
			$i = 0;
			while($i < $count)
			{
				$data = array();
				$result = $domainMod->select(
						"select distinct EnameId,DomainName,PrivacyTemp,TemplateId from e_domains where {$where} order by EnameId desc limit {$i},{$num}", $type, $values);
				foreach($result as $v)
				{
					$whoisEmail = $email = '';
					//获取模板邮箱
					$templateInfo = $templateMod->getTempInfoByTempId($v['PrivacyTemp'] ? $v['PrivacyTemp'] : $v['TemplateId']);
					if($templateInfo)
					{
						$email = $templateInfo['Email'];
					}
					//获取whois邮箱
					$whoisEmail = self::getWhoisEmail($v['DomainName']);
					\core\Log::write($v['EnameId'] . ',' . $v['DomainName'] . "," . $email . "," . $whoisEmail . 
							($whoisEmail == $email ? '一致' : '不一致'), 'crontemp/webcc', 'getDomainTplMatch');
				}
				$i += $num;
			}
		}
	}
	
	/**
	 * 获取whois邮箱
	 * @param string $domain
	 * @return boolean|Ambigous <boolean, array>
	 */
	private function getWhoisEmail($domain)
	{
		return false;
		$whoisLib = new \common\WhoisLib();
		$whoisInfo = (array)$whoisLib->getWhoisBasicInfoByDomain($domain, TRUE);
		if(!$whoisInfo || empty($whoisInfo['Status']) || empty($whoisInfo['AdministrativeEmail']))
		{
			return false;
		}
		return　empty($whoisInfo['AdministrativeEmail']) ? false : $whoisInfo['AdministrativeEmail'];
	}
}
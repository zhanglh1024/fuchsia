<?php
use core\ModBase;
use lib\manage\domain\DomainLogsLib;

class ZhangController extends Yaf\Controller_Abstract
{

	public function indexAction()
	{
		echo \common\Client::getIp();
	}

	public function reparefszaction()
	{

		$sql='update e_domain_operation_log2017 set content="域名续费1年" where logid=4085559';
		$mod = new ModBase('domain');
		$mod->update($sql,"",array());
		die;

		$financeMod = new \core\ModBase('finance');
		$num = 0;
		$size = 5000;
		$start = date('Y-m-d', strtotime('-7 days')) .' 00:00:00';
		$end = date('Y-m-d', strtotime('-7 days')) .' 23:59:59';
		$logic = new \logic\manage\finance\InvoiceLogic();
		$tableName = 'e_finance_out' . date('Y');
		while(true)//跑出款表
		{
			$limit = $num * $size . ',' . $size;
			$sql = "select sum(OutMoney) as total,EnameId,year(CreateDate) as yyear from $tableName where CreateDate>='2016-01-01 00:00:00' and CreateDate<='2016-10-30 23:59:59' and OutType=5 group by EnameId,year(CreateDate)";
			$sql .= " limit " . $limit;
			$resultOut = $financeMod->select($sql, '', array());
			if(empty($resultOut))
			{
				echo "handle e_finance_out over\r\n";
				break;
			}
			foreach($resultOut as $info)
			{
				if($info['yyear'] != date('Y') && $info['yyear'] != date('Y') - 1)
				{
					continue;
				}
				if($info['total'] <= 0.0000)
				{
					continue;
				}
				$data = array('enameId' => $info['EnameId'], 'invoiceFare' => sprintf("%.4f", $info['total']),
						'year' => $info['yyear']);
				if(!$logic->addInvoiceFare($data))
				{
					echo "add user fare failed\r\n";
					\core\Log::write("failed," . implode(",", $data), 'finance', 'invoicefare');
				}
			}
			$num++;
		}
	}


	/**
	 * 域名导出，区分5数字类型 ABBCC,AABBC,AAABC,ABBBC,ABCCC
	 */
public function testAction()
        {
                $domain ="536373.wang";
                $domainTransferLib = new \lib\manage\domain\DomainTransferLib(0);
                $domainTransferLib->setDomainTransferOutSuccessTmp($domain);
        }

	public function checkoutaction(){
		$sql1="select DomainName from e_domain_transfer_out where status=2 and updatetime>='2016-10-08 16:00:00' and updatetime<='2016-10-09 18:00:00'";
		$mod = new ModBase('domain');
		$list = $mod->select($sql1,"",array());
		if($list){
			include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
                        $sdk = new \ApiSdk();
			foreach($list as $info){
				$domain=$info["DomainName"];
				$bak = $mod->getRow("select RegistrarId from e_domains_bak where DomainName='$domain' order by DomainId DESC limit 1","",array());
				$dinfo = $sdk->execSdkFun(5025,array("domain"=>$domain,'registrarID'=>$bak['RegistrarId']));
				if($dinfo['resultCode']==5000){
					echo "$domain,error\r\n";
				}
				else{
					echo "$domain,success\r\n";
				}
				sleep(1);
			}
		}
	}

	public function exportwebccaction()
	{
		$momainsql="select EnameId,DomainName from e_domains where RegistrarId=61 order by EnameId DESC";
		$dmod = new ModBase('domain');
		$mmod = new ModBase('user');
		$domainlist = $dmod->select($momainsql, "", array());
		if($domainlist)
		{
			foreach ($domainlist as $domainInfo){
				$enameId=$domainInfo["EnameId"];
				$domain=$domainInfo["DomainName"];
				$msql="select ChName,Email,ChCompanyName,Mobile from e_member_ext,e_member where e_member.EnameId='$enameId' and e_member_ext.EnameId='$enameId'";
				$memberInfo = $mmod->getRow($msql, "",array());
				if($memberInfo)
				{
					//域名，id，公司，姓名，手机，邮箱
					echo $domain.",".$enameId.",".$memberInfo['ChCompanyName'].','.$memberInfo['ChName'].','.$memberInfo['Mobile'].','.$memberInfo['Email'];
					echo "\r\n";
				}
			}	
		}
	}


	public function reparetradeAction()
	{
		$filecontent = file_get_contents("/tmp/xinghuajiaoyishuju2.csv");
		if(! $filecontent)
		{
			exit("not found data");
		}
		$contentArr = explode("\n", $filecontent);
		//交易id  域名 买家id 卖家id 交易金额 提现方式 备注
		foreach($contentArr as $info)
		{
			if(empty($info))
				continue;
			$jiaoyiarr = explode(",", $info);
			$jiaoid = $jiaoyiarr[0];
			$jiaoyiyuming = $jiaoyiarr[1];
			$doarr = explode("=", $jiaoyiyuming);
			$domain = $doarr[0];
			$buyer = $jiaoyiarr[2];
			$seller =$jiaoyiarr[3];
			$money = $jiaoyiarr[4];
			$tixiantype = $jiaoyiarr[5];
			$remark="";
// 			$remark=$jiaoyiarr[6];
			if(count($doarr)>1)
			{
				$remark = "(打包交易)";
			}
			$orderlib = new \interfaces\manage\Finance();
			$orderdata=array('enameId'=>$buyer,'domain'=>$domain,'linkEnameId'=>$seller,'price'=>$money,'type'=>106,'remarkHide'=>$remark.",管理操作表导致交易数据问题");
			$orderId = $orderlib->addOrder((object) $orderdata);
			if(!$orderId || !is_numeric($orderId))
			{
				echo $info.",create order failed\r\n";
				continue;
			}
			$confirm = $orderlib->confirmOrder((object) array('enameId'=>$buyer,'moneyType'=>$tixiantype,'orderId'=>$orderId,'linkEnameId'=>$seller));
			if($confirm)
			{
				echo $info.",".$orderId.",success\r\n";
			}
			else
			{
				echo $info.",".$orderId.",confirm error\r\n";
			}
die;
			
		}		
	}



	public function checkshuhuiaction($params = array())
	{
		if(empty($params)){
			exit("usage:time enameid");
		}
		$enameId = $params[0];
		$time = isset($params[1]) && !empty($params[1]) ? $params[1] : date('Y-m-d H:i:s',strtotime('-183 days'));
		$sql="select DomainName,EnameId from e_domains_bak where expdate>='$time' and enameid='$enameId'";
		$mod = new ModBase('domain');
		$list = $mod->select($sql, "", array());
		if($list)
		{
			foreach ($list as $info)
			{
				$enameId = $info['EnameId'];
				$domain=$info['DomainName'];
				try {
					$logic = new \logic\manage\domain\DomainRestoreLogic();
					$return = $logic->domainRestoreQuery($enameId, $domain);
				} catch (\Exception $e) {
					$return = 	$e->getMessage().','.$e->getCode();					
				}
				echo $domain.",".$enameId.(is_array($return) ? ',可以赎回' : $return);
				echo "\r\n";
			}
		}
	}


	public function transfertestaction(){
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		$a= $sdk->execSdkFun(5028,array('domain' => "cfcww.com", 'registrarID' => 21));
		print_r($a);
}

	public function delspaction(){
		$mod = new ModBase("domain");
	}


	public function checkdomaininaction(){
		$mod = new ModBase('domain');
		$fmod = new ModBase('finance');
		$sql="select domain ,operatorid from e_domain_log where logtype=1 and issuccess=0 and createtime>='2016-10-12 06:00:00' and createtime<='2016-10-12 10:30:00';";
		$list = $mod->select($sql,'',array());
		if($list){
			include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
			$sdk = new \ApiSdk();
			foreach($list as $info){
				$domainname=$info['domain'];
				$enameId=$info['operatorid'];
				$a= $sdk->execSdkFun(5025,array('domain' => $domainname));
				if($a['resultCode']==5000){
					$fsql="select * from e_finance_orders where domain='$domainname' and enameid='$enameId' and ordertype=1 and orderstatus=2 and createtime>='2016-10-12 06:00:00'";
					$result = $fmod->getRow($fsql,'',array());
					if($result){
						echo $domainname.",".$enameId.','.$result['Price'].",has order success\r\n";
					}
					else{
						echo $domainname.",".$enameId.",reg not create order\r\n";
					}
				}
			}
		}
	
	}


	public function checkqueueaction()
	{
		$mod = new ModBase('newqueue');
		$sql = "select * from e_queue_tasks_detail where function in('domain_transfer_in')  and status=0";
		$queuelist = $mod->select($sql, "", array());
		if($queuelist)
		{
			foreach ($queuelist as $info)
			{
				$queueId = $info['QueueId'];
				$taskId = $info['TaskId'];
				$this->upqueuestatus($queueId, $taskId, 3);
			}
		}
	}

	public function repareAccountaction()
	{
		$tmpname="any_template_info";
		$mod = new ModBase('newqueue');
		//$mod->update("update e_queue_normal set status=3 where queueid=5962829 or queueid=5820247","",array());

		//die;
		$sql="select * from e_queue_normal where Function='send_sms' and TemplateName='account_pwd_error_warning' and Status=0 and CreateTime>=";
		$sql.=strtotime("2017-01-04 00:00:00")." and CreateTime<=".strtotime('2017-02-05 23:59:59');
		$sql.=" limit 100";
		echo $sql."\r\n";
		$domainlist = array();
		$dnmod = new ModBase("domain");
		$list = $mod->select($sql, "", array());
		if($list)
		{
			$queueids = array();
			foreach($list as $info)
			{
				print_r($info);
				$ddd = json_decode($info['Data'],true);
				$domain=$ddd['domain'];
				$domainlist[] = $domain;
				$enameId = $info['EnameId'];
				$upsql="update e_queue_normal set Status=3,createTime=".time()." where QueueId=".$info['QueueId'];
				if($mod->update($upsql, "", array()))
				{
					//$outinfo = $dnmod->select("select * from e_domain_transfer_out where DomainName='$domain' and EnameId='$enameId' and Status=5","",array());
					//if($outinfo && !in_array($domain,$domainlist)){
						$queueids[] = $info['QueueId'];
					//}else{echo $info['QueueId'].",outarealdy";}
				}
				else{
					echo $info['QueueId'].",error\r\n";
				}
				continue;
				if(count($queueids)>50)
				{
					try {
						$logic = new \logic\manage\thrift\QueueLogic();
						var_dump($logic->reRunQueueNormal($queueids));
					} catch (\Exception $e) {
						error_log(json_encode($queueids)."\r\n",3,"/tmp/queueidback.log");
						var_dump($e->getMessage());
					}
					$queueids = array();
					echo "\r\n";
				}
			}
			if(count($queueids)>0){
				try {
					$logic = new \logic\manage\thrift\QueueLogic();
					var_dump($logic->reRunQueueNormal($queueids));
				} catch (\Exception $e) {
					error_log(json_encode($queueids)."\r\n",3,"/tmp/queueidback.log");
					var_dump($e->getMessage());
				}
				$queueids = array();
				echo "\r\n";
			}
		}
	}
	
	public function upqueuestatus($queueId, $taskId, $status)
	{
		$mod = new ModBase('newqueue');
		$status = $mod->update(
		"update e_queue_tasks_detail set status=$status where queueId='{$queueId}' and taskId='{$taskId}' and function in('domain_transfer_in')",
		'', array());
		if(! $status)
		{
			echo "update queue failed,$queueId,$taskId\r\n";
		}
		else
		{
			$taks = $mod->update("update e_queue_tasks set status=$status where taskId=$taskId", '', array());
			if($taks)
			{
				echo "all update queue success,$queueId,$taskId\r\n";
			}
			else
			{
				echo "update queue success,but e_tasks failed,$queueId,$taskId\r\n";
			}
		}
	}	


	public function uploadaction(){
		$regid = "20d28bfa2877ee46";
		//if(!$this->uploadRegistrantCnnic(substr(md5($data['templateName']),0,16), $cardType, 
		//$card, self::getImgFromImageServer($img), $orgImg ? 'E':'I', 'F',$orgImg ? self::getImgFromImageServer($orgImg) : '',$orgCode,$orgProtype))
		$idimg = file_get_contents("/home/zhangjp/1111111111.jpeg");
		$orgimg = "";//file_get_contents("/home/zhangjp/单位证件.png");
		$idType = 'QT';
		$idCode = "K00833657";
		$regtype = "I";
		$region = "F";
		$orgCode = "";
		$logic = new \logic\manage\thrift\VspLogic();
//	public function upLoadRegistrant($regid, $idType, $idCode, $imgbase, $regtype, $region = 'D', $orgCode = '', 
//	$orgType = 'PU', $orgImg = '', $orgProo = 'ORG')
		$return = $logic->upLoadRegistrant($regid, $idType, $idCode, $idimg, $regtype, $region);
		var_dump($return);
		die;
		$regid = "20ebba428b28aab8";
		//if(!$this->uploadRegistrantCnnic(substr(md5($data['templateName']),0,16), $cardType, 
		//$card, self::getImgFromImageServer($img), $orgImg ? 'E':'I', 'F',$orgImg ? self::getImgFromImageServer($orgImg) : '',$orgCode,$orgProtype))
		$idimg = file_get_contents("/home/zhangjp/身份证.jpg");
		$orgimg = file_get_contents("/home/zhangjp/单位证件.png");
		$idType = 'SFZ';
		$idCode = "610527198202074540";
		$regtype = "E";
		$region = "D";
		$orgCode = "5456332";
		$logic = new \logic\manage\thrift\VspLogic();
		$return = $logic->upLoadRegistrant($regid, $idType, $idCode, $idimg, $regtype, $region, $orgCode, 'PR', $orgimg, 
			'YYZZ');
		var_dump($return);

	}

	public function reparetranaction(){
	$sql="select count(1) as total,domain from e_finance_orders where ordertype=3 and orderstatus=1 and createtime>='2016-07-15 00:00:00' and RegistarId!=86 and RegistarId!=81 and RegistarId!=82 group by domain,enameid having total=2;";
	$mod = new ModBase('finance');
	$list = $mod->select($sql,'',array());
	if($list){
		$dmod = new ModBase('domain');
		foreach($list as $info){
			$domain=$info['domain'];
			$sql="select * from e_domain_transfer_app where domain='$domain' and OperateTime>='2016-08-01 00:00:00'";
			$dd = $dmod->getRow($sql,'',array());
			if($dd){
				$sql="select domainname from e_domains where domainname='$domain' and expdate>='2017-12-31 23:59:59'";
				$dn = $dmod->getRow($sql,'',array());
				if(!$dn){
					echo $domain."\r\n";
				}
			}
		}
	}

}
	public function settransferaction(){
		$sql1="update e_domain_transfer_in set transferstatus=-3 where enameid=999518  and transferstatus=2";
		$mod = new ModBase('domain');
		$mod->update($sql1,'',array());
	}

	public function cancaldomainaction()
	{
		
		$domainLogic = new \logic\manage\domain\DomainLogic();
		$rs = $domainLogic->getDomainRecomond((object)array('domain'=>'qhml','suffix'=>'com,net,cn,com.cn'));

		print_r($rs);
		die;
		$info = array('domain'=>'11123.com','enameId'=>15979,'ip'=>'113.88.119.66');
		$logic = new \logic\manage\domain\EdnsLogic();
		$st = $logic->domainUnLock((object)$info);
		var_dump($st);
	}

	public function settransferagainstaction($params = array())
	{
		if(empty($params) || count($params)!=3)
		{
			exit("no params\r\n");
		}
		$enameId = isset($params[0]) ? $params[0] : "";
		$status = isset($params[1]) ? $params[1] : "";
		$limit = isset($params[2]) ? $params[2] : "";
		$mod = new ModBase('domain');
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'transferin');
		$sql="select * from e_domain_transfer_in where  MailCode!='' and Whois!='' and transferstatus=-3 and enameid=253247 and WhoIsEmail!='' limit 200";
		$mod = new \models\manage\domain\DomainTransferInMod();
		$transferInList = $mod->select($sql,"",array());
		if(!$transferInList) exit();
		foreach($transferInList as $info)
		{
			$transferId = $info['TransferInId'];
			$sendCode = rand(1000, 9999);
			$email=$info['WhoIsEmail'];
			$whois=$info['Whois'];
			$mailCode = $info['MailCode'];
			$enameId=$info['EnameId'];
			$submitTime = date("Y-m-d", strtotime($info['CreateTime']));
			$url = $conf->siteUrl . '/transfermail/index/' . $mailCode;
			$domain=$info["DomainName"];
			$data = array('url' => $url, 'domainName' => $domain, 'sendCode' => $sendCode, 'name' => $enameId,
					'submitTime' => $submitTime, 'whois' => $whois, 'foa' => TRUE);
			$queue = new \interfaces\manage\Queue();
			if($queue->sendMail($conf->templateId, $email, $data, $enameId, 0, 'sendmail', 5))
			{
				
				echo $transferId.",".$domain.",success\r\n";
				$mod->upTransferInfo(array('TransferInId' => $transferId),
					array('TransferStatus' => 2, 'UpdateTime' => date('Y-m-d H:i:s'), 'WhoIsEmail' => $email));
			}
			else
			{
				echo $transferId.",".$domain.",add mail error\r\n";
			}
		}
		die;
		var_dump($params);
		$domainList = $mod->select("select * from e_domain_transfer_in where EnameId='$enameId' and transferstatus='$status' limit $limit", "", array());
		if($domainList)
		{
			foreach($domainList as $info)
			{
				$queueArray = array();
				$transferInId = $info['TransferInId'];
				$domain = $info['DomainName'];
				$enameId = $info['EnameId'];
				$queueArray[] = array('domain' =>"naxian.cc", 'dnsType' => 0,"registrarId"=>61);
				$queueData = array('Function' => 'modify_domain_dns', 'Priority' => 5, 'EnameId' => 658319,'Data' => $queueArray);
				try {
					$logic = new \logic\manage\newqueue\QueueLogic();
					$return = $logic->addQueueTask($queueData);
				} catch (\Exception $e) {
					$return = FALSE;
				}
				echo 	$transferInId.",".$domain.",start\r\n";
				if($return)
				{
					$upinfo = $mod->update("update e_domain_transfer_in set transferstatus=-1 where TransferInId=$transferInId and EnameId=$enameId", "", array());
					if($upinfo)
					{
						echo 	$transferInId.",".$domain.",success\r\n";
					}
					else{
						echo 	$transferInId.",".$domain.",failed\r\n";
					}
				}
				
			}
		}
	}

	public function ejiatestaction(){
		$enameId="668690";
		$domain="t1z.com";
		$this->noticeEplus($domain,$enameId,1);
	}

	public function noticeEplus($domain,$enameId,$status)
	{
		if(!$enameId)
		{
			return FALSE;
		}
		try
		{
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'ePlusTransferIn');
			$data = array('user'=>$conf->user,'key'=>$conf->key,'EnameId'=>$enameId,'Domain'=>$domain,'Status'=>$status);
			$notice = \common\Common::requestPost($conf->noticeUrl,$data);
			$return = (is_array($notice) || is_object($notice)) ? json_encode($notice) : $notice;
			var_dump($return);
			\core\Log::write("eplusnotice,{$domain},{$enameId},{$status},{$return},","transfer","eplushnotice");
			$redis = \core\RedisLib::getInstance('common');
			$redis->del($domain.'_realEnameId');
		}
		catch (\Exception $e)
		{
			echo $e->getMessage();
			\core\Log::write("eplusnotice error,{$domain},{$enameId},{$status},".$e->getMessage(),"transfer","eplushnotice");
		}
	}

public function getrediskeyaction()
        {

		$domain="youju.com.cn";
		$mod = new ModBase('domain');
		$mod->update("update e_domains_bak set expdate='2016-05-02 22:33:05' where domainname='$domain'","",array());	
	
		die;

                set_time_limit(0);
                $redis = \core\RedisLib::getInstance('manage');
                $keyslist = $redis->keys("ename_shimingzhi*");
                if($keyslist)
                {
                        foreach($keyslist as $info)
                        {
                                $value = $redis->get($info);
                                error_log(str_replace("ename_shimingzhi", "", $info).",".$value."\r\n",3,"/home/zhangjp/shimingzhi_temp.csv");
                        }
                }
        }

	//如果是新模板的话看下是否有什么接口没注册成功的
	private function checkInterIsReg(){

	}	
	
	//接口注册
	private function interFaceReg(){

	}

	//数据格式化
	private function regdataFormat(){

	}
	
	//删除接口数据
	private function delInterFace(){

	}	
	
	//表删除
	private function delTemplate(){

	}
	/**
	 * 帮用户重新旧的topwang模板
	  1.原来接口有注册的话就注册
          2.检测是否已经存在了 存在的话按照原接口看下是否有注册 没有注册还是给注册上
	  3.如果在跑的时候已经存在了并且已经白名单且关联成功了的话直接过户下域名 
	  4.如果该接口下没有域名了删除下该接口的数据并且设置相对应的状态 如果都没有的话则直接隐藏或者删除数据
          5.top/wang的处理0数据
          6.各种7788不规范数据的修复 
	  7.保证找对认证的name org跟img等等 不能错
	  8.各种7788的日志
	*/

	// 检测是否已经创建过了
	public function checkArealExitTemp($enameId, $templateName)
	{
		$dnmod = new ModBase("domain");
		$sql = "select TemplateId,TemplateName,EnameId,CnStatus,RegistrarId from e_template_zh where EnameId='$enameId' and CreateTime>='2016-10-20 20:00:00'";
		$sql .= " and TemplateName=新_$templateName";
		return $dnmod->getRow($sql, "", array());
	}
	
	
	/**
	 * 提交白名单审核
	 * @param unknown $templateId
	 * @param unknown $enameId
	 */
	public function uploadcnnic($templateId, $enameId)
	{
		try
		{
			$queueLogic = new \logic\manage\newqueue\QueueLogic();
			$tempsInfo = array(array('templateId' => $templateId, 'domain' => 'cnninc.upload'));
			$taskData = array(
					'Function' => 'cnnic_upload', 'Hidden' => 1, 'EnameId' => $enameId, 'Data' => $tempsInfo, 
					'Priority' => 4);
			$rs = $queueLogic->addQueueTask($taskData);
			$mess = "{$templateId},{$enameId}" . ($st ? ",upload success" : ",upload failed");
			echo $mess . "\r\n";
			\core\Log::write($mess, "template", "checktoptemp");
		}
		catch(\Exception $e)
		{
			echo "{$templateId},{$enameId},upload failed";
			\core\Log::write("{$templateId},{$enameId},upload failed", "template", "checktoptemp");
		}
	}

	/**
	 * 接口注册和数据添加
	 * 
	 * @param unknown $oldTempid        	
	 * @param unknown $enameId        	
	 * @param unknown $data        	
	 * @param unknown $edata        	
	 * @param unknown $needRegInter        	
	 */
	public function templateadddb($oldTempid, $enameId, $data, $edata, $needRegInter)
	{
		$templateId = 0;
		$mod = new \models\manage\domain\TemplateMod();
		$addInfo = $mod->addCnTemp($data);
		if($addInfo)
		{
			$templateId = $addInfo;
		}
		if(! $templateId)
		{
			\core\Log::write("{$oldTempid},{$enameId},add db error", "template", "checktoptemp");
			return FALSE;
		}
		$tempType = $data['templateType'];
		$edata['templateId'] = $templateId;
		$edata['templateName'] = $data["templateName"];
		$addEnInfo = $mod->addEnTemp($edata);
		if($addEnInfo)
		{
			$templib = new \lib\manage\domain\TemplateLib();
			$updateDate = array();
			$cnSet = array();
			$sum = array_sum($needRegInter);
			if(! $sum)
			{
				$needRegInter = array("ename.cn" => 1, "ename.top" => 86, "ename.biz" => "82", "ename.asia" => 31);
			}
			foreach($needRegInter as $domain => $value)
			{
				if(! $value)
				{
					echo "{$oldTempid},{$enameId},{$domain},old not reg\r\n";
					\core\Log::write("{$oldTempid},{$enameId},{$domain},old not reg", "template", "checktoptemp");
					continue;
				}
				$regidArr = array();
				if($domain == "ename.cn")
				{
					$interInfo = $templib->interfaceRegTemplate('ename.cn', $templateId, $value, FALSE, $tempType);
					$cnSet['RegistrarId'] = $interInfo ? $interInfo : 0;
					if($interInfo) // 查找的都是白名单 直接上传吧 查不到资料的不会走这里
					{
						$this->uploadcnnic($templateId, $enameId);
					}
				}
				else if($domain == "ename.公司")
				{
					$wangluoInfo = $templib->interfaceRegTemplate('ename.公司', $templateId, FALSE, $data['TemplateName'], 
						$tempType);
					$cnSet['CnIdn'] = $wangluoInfo ? $wangluoInfo : 0;
				}
				else if($domain == "ename.org")
				{
					$orgInfo = $templib->interfaceRegTemplate('ename.org', $templateId, FALSE, FALSE, $tempType);
					$updateDate['OrgId'] = $orgInfo ? $orgInfo : 0;
				}
				elseif($domain == "ename.asia")
				{
					$asiaInfo = $templib->interfaceRegTemplate('ename.asia', $templateId, FALSE, FALSE, $tempType);
					$updateDate['AsiaId'] = $asiaInfo ? $asiaInfo : 0;
				}
				elseif($domain == "ename.pw")
				{
					$pwInfo = $templib->interfaceRegTemplate('ename.pw', $templateId, FALSE, FALSE, $tempType);
					$updateDate['PwId'] = $pwInfo ? $pwInfo : 0;
				}
				else if($domain == "ename.top" || $domain == "ename.wang")
				{
					array_push($regidArr, 
						$templib->interfaceRegTemplate("ename.top", $templateId, FALSE, FALSE, $tempType));
				}
				else if($domain == "ename.biz")
				{
					array_push($regidArr, 
						$templib->interfaceRegTemplate("ename.top", $templateId, FALSE, FALSE, $tempType));
				}
			}
			if($regidArr)
			{
				if(! $templib->addTemplateExt($templateId, $data['enameId'], $regidArr))
				{
					\core\Log::write("{$oldTempid},{$domain},$templateId," . implode("|", $regidArr) .
						 ",update ext failed", "template", "checktoptemp");
				}
			}
			if($cnSet)
			{
				if(! $templib->updateTempalte(array('TemplateId' => $templateId), $cnSet, array()))
				{
					echo "{$oldTempid},{$domain},$templateId,update cntemp failed\r\n";
					\core\Log::write("{$oldTempid},{$domain},$templateId," . json_encode($cnSet) .
						 ",update cntemp failed", "template", "checktoptemp");
				}
			}
			if($updateDate)
			{
				if(! $templib->updateTempalte(array('TemplateId' => $templateId), array(), $updateDate))
				{
					echo "{$oldTempid},{$domain},$templateId,update entemp failed\r\n";
					\core\Log::write(
						"{$oldTempid},{$domain},$templateId," . json_encode($updateDate) . ",update cntemp failed", 
						"template", "checktoptemp");
				}
			}
			echo $templateId;
			return $templateId;
		}
		else
		{
			$mod->delCntemp($templateId);
			\core\Log::write("{$oldTempid},{$templateId},add eninfo error,delete zh", "template", "checktoptemp");
			return false;
		}
	}

	/**
	 * biz/top/pw/asia 需要英文信息注册
	 * 电话长度不能超 直接替换掉86
	 *
	 * @param unknown $templateZhInfo        	
	 * @param unknown $templateEnInfo
	 *        	org street 可能不一样 其他都一样
	 */
	public function checkInfoIsValid($templateZhInfo, $templateEnInfo)
	{
		$templateId = $templateZhInfo['TemplateId'];
		$enameId = $templateZhInfo['EnameId'];
		$mobile = '';
		if(empty($templateZhInfo['TemplateName'])) // 模板名称为空 ename_xxxxx
		{
			return $templateZhInfo['TemplateId'] . 'zh,templatename,empty';
		}
		if(empty($templateZhInfo['FirstName'])) // 姓氏空
		{
			return $templateZhInfo['TemplateId'] . 'zh,firstname,empty';
		}
		if(empty($templateZhInfo['LastName'])) // 名字空
		{
			return $templateZhInfo['TemplateId'] . 'zh,lastname,empty';
		}
		if(empty($templateZhInfo['Org'])) // 组织结构空
		{
			return $templateZhInfo['TemplateId'] . 'zh,org,empty';
		}
		if(empty($templateZhInfo['Name'])) // 组织结构空
		{
			return $templateZhInfo['TemplateId'] . 'zh,name,empty';
		}
		if(empty($templateZhInfo['Street'])) // 街道信息空
		{
			return $templateZhInfo['TemplateId'] . 'zh,street,empty';
		}
		if(empty($templateZhInfo['City'])) // 城市空
		{
			return $templateZhInfo['TemplateId'] . 'zh,City,empty';
		}
		if(empty($templateZhInfo['Province'])) // 省份空
		{
			return $templateZhInfo['TemplateId'] . 'zh,Province,empty';
		}
		if(empty($templateZhInfo['PostCode'])) // 邮编空
		{
			return $templateZhInfo['TemplateId'] . 'zh,PostCode,empty';
		}
		if(empty($templateZhInfo['CountryName'])) // 国家空
		{
			$templateZhInfo['CountryName'] = "CN";
			\core\Log::write("{$templateId},zh,country empty,default cn", "template", "checktoptemp");
		}
		if(empty($templateZhInfo['Email'])) // 邮箱空
		{
			return $templateZhInfo['TemplateId'] . 'zh,Email,empty';
		}
		$templateZhInfo['TelCC'] = $templateZhInfo['TelCC'] ? $templateZhInfo['TelCC'] : '86';
		$templateZhInfo['FaxCC'] = $templateZhInfo['FaxCC'] ? $templateZhInfo['FaxCC'] : 86;
		// 手机传真为空 直接用个人信息来填充
		if(empty($templateZhInfo['Phone']) || empty($templateZhInfo['Fax']) || empty($templateEnInfo['Phone']) ||
			 empty($templateEnInfo['Fax']))
		{
			$memberSql = "select Mobile,Phone from e_member_ext where EnameId = '{$enameId}'";
			$memberMod = new ModBase('user');
			$memberInfo = $memberMod->getRow($memberSql, "", array());
			if(! empty($memberInfo['Mobile']))
			{
				$mobile = $memberInfo['Mobile'];
			}
			else if(! empty($memberInfo['Phone']))
			{
				$mobile = str_replace("-", "", $memberInfo['Phone']);
			}
		}
		if(empty($templateZhInfo['Phone'])) // 电话空
		{
			if(! empty($mobile))
			{
				$templateZhInfo['Phone'] = $mobile;
				\core\Log::write("{$templateId},phone empty,$mobile", "template", "checktoptemp");
			}
			else
			{
				return $templateZhInfo['TemplateId'] . 'zh,Phone,empty';
			}
		}
		// 电话号码多余的86区号删除更新
		if(preg_match("/^86\d{10,12}/", $templateZhInfo['Phone']))
		{
			$templateZhInfo['Phone'] = ltrim($templateZhInfo['Phone'], '86');
			\core\Log::write("{$templateId},zh phone 86 trim", "template", "checktoptemp");
		}
		if(empty($templateZhInfo['Fax'])) // 传真空
		{
			if($templateZhInfo['Phone'])
			{
				$templateZhInfo['Fax'] = $templateZhInfo['Phone'];
			}
			else
			{
				return $templateZhInfo['TemplateId'] . ',zh,fax,empty';
			}
		}
		if(preg_match("/([\x{4e00}-\x{9fa5}])+/ui", $templateEnInfo['Org']))
		{
			$templateEnInfo['Org'] = $this->toPinyin($templateZhInfo['Org']);
			\core\Log::write("{$templateId},en org not english,translate", "template", "checktoptemp");
		}
		if(preg_match("/([\x{4e00}-\x{9fa5}])+/ui", $templateEnInfo['Street']))
		{
			$templateEnInfo['Street'] = $this->toPinyin($templateZhInfo['Street']);
			\core\Log::write("{$templateId},en street not english,translate", "template", "checktoptemp");
		}
		if(preg_match("/([\x{4e00}-\x{9fa5}])+/ui", $templateEnInfo['FirstName']))
		{
			$templateEnInfo['FirstName'] = $this->toPinyin($templateZhInfo['FirstName']);
			\core\Log::write("{$templateId},en firstname not english,translate", "template", "checktoptemp");
		}
		if(preg_match("/([\x{4e00}-\x{9fa5}])+/ui", $templateEnInfo['LastName']))
		{
			$templateEnInfo['LastName'] = $this->toPinyin($templateZhInfo['LastName']);
			\core\Log::write("{$templateId},en lastname not english,translate", "template", "checktoptemp");
		}
		if(preg_match("/([\x{4e00}-\x{9fa5}])+/ui", $templateEnInfo['Name']))
		{
			$templateEnInfo['Name'] = $this->toPinyin($templateZhInfo['Name']);
			\core\Log::write("{$templateId},en name not english,translate", "template", "checktoptemp");
		}
		return array($templateZhInfo, $templateEnInfo);
	}

	public function toPinyin($chinese)
	{
		$chToPy = new \common\chtopy\ChineseToPinyin();
		if(! isset($chinese) || ! $chinese)
		{
			return '';
		}
		return $chToPy->toPinyin($chinese);
	}

	/**
	 * 帮用户重新旧的topwang模板
	 * 1.原来接口有注册的话就注册
	 * 2.检测是否已经存在了 存在的话按照原接口看下是否有注册 没有注册还是给注册上
	 * 3.如果在跑的时候已经存在了并且已经白名单且关联成功了的话直接过户下域名
	 * 4.如果该接口下没有域名了删除下该接口的数据并且设置相对应的状态 如果都没有的话则直接隐藏或者删除数据
	 * 5.top/wang的处理0数据
	 * 6.各种7788不规范数据的修复
	 * 7.保证找对认证的name org跟img等等 不能错
	 * 8.各种7788的日志
	   10.LOC参数貌似错了
	 * 9.数据可能有点多 从16 15 14 13这样开始
	 */
	public function reregtempaction()
	{
		// 大写的注意---需要确认下是不是0一定要删除的
		$dnmod = new ModBase("domain");
		$size = 1;
		$num = 0;
		$startTime = "2016-10-20 20:00:00";
		$checkTime = "2016-01-01 00:00:00";
		ini_set("display_errors","On");
		error_reporting(E_ALL);
		while(true)
		{
			$limit = $size * $num . "," . $size;
			$tempSql = "select * from e_template_zh where CnStatus=2 and IsShow=1 and EnameId=618264 and  CreateTime>='$checkTime' and TemplateType in(1,4) and Createtime<='$startTime' limit $limit";
			$templateList = $dnmod->select($tempSql, "", array());
			if(! $templateList)
				exit("not data\r\n");
			foreach($templateList as $templateInfo)
			{
				echo "start:".$templateInfo["TemplateId"].",".$templateInfo["TemplateName"];
				unset($_POST['cnname']); // 每次循环强制清楚
				unset($_POST['cnorg']); // 每次循环强制清楚
				$enameId = $templateInfo["EnameId"];
				$templateName = $templateInfo["TemplateName"];
				$templateUserName = $templateInfo["TempUserName"];
				$CnStatus = $templateInfo["CnStatus"];
				$templateId = $templateInfo["TemplateId"];
				$exists = $this->checkArealExitTemp($enameId, $templateName);
				if($exists)
				{
					// 存在的话给处理下
					echo $enameId . "," . $templateName . ",exists\r\n";
					\core\Log::write("{$templateId},{$templateName},{$templateUserName},alreay exists", "template", 
						"checktoptemp");
					continue;
				}
				
				$enSql = "select * from e_template_en where TemplateId='$templateId'";
				$enTemplate = $dnmod->getRow($enSql, "", array());
				if(! $enTemplate)
				{
					echo $enameId . "," . $templateName . ",not found entemplate\r\n";
					\core\Log::write("{$templateId},{$templateName},{$templateUserName},not found en temp", "template", 
						"checktoptemp");
					continue;
				}
				
				// 获取需要的模板数据
				$formatData = $this->getRegTempData($templateInfo, $enTemplate);
				if(! $formatData)
				{
					continue;
				}
				$st = $this->getVerifyInfo($enameId, $formatData[0]['name'], 
					$formatData[0]['templateType'] == 1 ? $formatData[0]['org'] : FALSE);
				if(! $st)
				{
					echo $enameId . "," . $templateName . ",not found verifyinfo\r\n";
					continue;
				}
				// cn top wang biz org asia pw 公司网络
				$wangSql = "select * from e_template_ext where TemplateId='$templateId' and EnameId='$enameId' and Registrar=86";
				$bizSql = "select * from e_template_ext where TemplateId='$templateId' and EnameId='$enameId' and Registrar=82";
				$wangInfo = $dnmod->getRow($wangSql, "", array());
				$wangId = $wangInfo ? $wangInfo['Registrar'] : 0;
				$bizInfo = $dnmod->getRow($bizSql, "", array());
				$bizId = $bizInfo ? $bizInfo['Registrar'] : 0;
				$cn = $this->getRegInterValue("ename.cn", $templateInfo["RegistrarId"]);
				$cdnInterFace = $this->getRegInterValue("ename.公司", $templateInfo["CnIdn"]);
				$asiaId = $this->getRegInterValue("ename.asia", $enTemplate["AsiaId"]);
				$orgId = $this->getRegInterValue("ename.org", $enTemplate["OrgId"]);
				$pwId = $this->getRegInterValue("ename.pw", $enTemplate["PwId"]);
				$wangId = $this->getRegInterValue("ename.top", $wangId);
				$bizId = $this->getRegInterValue("ename.top", $bizId);
				$needRegInter = array(
						"ename.cn" => $cn, "ename.公司" => $cdnInterFace, "ename.asia" => $asiaId, "ename.top" => $wangId, 
						"ename.biz" => $bizId, "ename.pw" => $pwId);
				$this->templateadddb($templateId, $enameId, $formatData[0], $formatData[1], $needRegInter);
				die;
			}
			$num ++;
		}
	}

	/**
	 *
	 * @param unknown $cn        	
	 * @param unknown $cdn        	
	 * @param unknown $org        	
	 * @param unknown $asia        	
	 * @param unknown $pw        	
	 * @param unknown $topwang        	
	 * @param unknown $biz        	
	 */
	public function getRegInterValue($domain, $oldValue)
	{
		$return = array(
				"ename.cn" => 1, "ename.wang" => "86", "ename.网络" => "71", 'ename.公司' => '71', 'ename.top' => '86', 
				'ename.biz' => 82, 'ename.org' => '41', 'ename.asia' => '31', 'ename.pw' => '51');
		if($oldValue)
		{
			return isset($return[$domain]) ? $return[$domain] : $oldValue;
		}
		return false;
	}

	/**
	 * 获取扩展数据
	 *
	 * @param unknown $templateId        	
	 * @param unknown $regid        	
	 * @param string $enameId        	
	 */
	public function getExtInfo($templateId, $regid, $enameId = FALSE)
	{
		$lib = new \lib\manage\domain\TemplateLib();
		$info = $lib->getTemplateExt($templateId, $enameId, $regid);
		return $info ? $info["Registrar"] : 0;
	}

	public function UkToGb($city)
	{
		return $city == 'UK' ? 'GB' : $city;
	}

	/**
	 * 获取需要注册的信息
	 * 正常情况下数据英文信息是中文的翻译 但是为了保证人工数据的准确性 中文中文 英文英文 只处理一些数据丢失的问题
	 *
	 * @param unknown $ZhInfo        	
	 * @param unknown $EnInfo        	
	 */
	public function getRegTempData($ZhInfo, $EnInfo)
	{
		$tempData = $this->checkInfoIsValid($ZhInfo, $EnInfo);
		$data = array();
		$edata = array();
		if(is_array($tempData))
		{
			$zhInfo = $tempData[0];
			$templateName = $this->getTemplateNameSystem();
			$data['enameId']=$ZhInfo['EnameId'];	
			$data['templateType'] = $ZhInfo['TemplateType'];
			$data['firstname'] = $zhInfo["FirstName"];
			$data['lastname'] = $zhInfo["LastName"];
			$data['name'] = $zhInfo["Name"] ? $zhInfo["Name"] : ($data["firstname"].$data["lastName"]);
			$data['province'] = $zhInfo["Province"];
			$data['org'] = $zhInfo["Org"];//需要优化下
			$data['city'] = $zhInfo["City"];
			$data['street'] = $zhInfo["Street"];
			$data['postCode'] = trim($zhInfo["PostCode"]);
			$data['countryName'] = $this->UkToGb(strtoupper($zhInfo["CountryName"]));
			$data['telCC'] = trim($zhInfo["TelCC"]);
			$data['phone'] = $zhInfo["Phone"];
			$data['phoneExt'] = '';
			$data['faxCC'] = trim($zhInfo["FaxCC"]);
			$data['fax'] = $zhInfo["Fax"];
			$data['faxExt'] = '';
			$data['email'] = $zhInfo["Email"];
			$data['isShow'] = 1;
			$data['isDefault'] = 0;
			$data['tempUserName'] = "新_".$zhInfo['TempUserName'];
			$data['templateName'] = $templateName;
			
			$enInfo = $tempData[1];
			// 这些以英文本身存在的为准 如果没有的话在翻译
			$edata['enameId']=$ZhInfo['EnameId'];	
			$edata['firstname'] = $enInfo['FirstName'] ? $enInfo['FirstName'] : $this->toPinyin($data['firstName']);
			$edata['lastname'] = $enInfo['LastName'] ? $enInfo['LastName'] : $this->toPinyin($data['lastName']);
			$edata['org'] = $enInfo['Org'] ? $enInfo['Org'] : $this->toPinyin($data['org']);
			$edata['street'] = $enInfo['Street'] ? $enInfo['Street'] : $this->toPinyin($data['street']);
			$edata['name'] = $enInfo['Name'] ? $enInfo['Name'] : ($edata['firstname'] . $edata['lastname']);
			
			// 这些数据以翻译的为准
			$edata['province'] = $this->toPinyin($data['province']);
			$edata['city'] = $this->toPinyin($data['city']);
			$edata['postCode'] = trim($data['postCode']);
			$edata['countryName'] = $data["countryName"];
			$edata['telCC'] = $data['telCC'];
			$edata['phone'] = $data["phone"];
			$edata['phoneExt'] = '';
			$edata['faxCC'] = $data["faxCC"];
			$edata['fax'] = $data['fax'];
			$edata['faxExt'] = '';
			$edata['email'] = $data["email"];
			$data['templateName'] = $templateName;
			return array($data, $edata);
		}
		echo "{$tempData},get data error\r\n";
		\core\Log::write("{$tempData},get data error", "template", "checktoptemp");
		return FALSE;
	}

	/**
	 * 获取16位模板名
	 */
	public function getTemplateNameSystem()
	{
		$templateName = "ename_";
		$chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
		$checkLen = strlen($chars) - 1;
		for($i = 0; $i < 10; $i ++)
		{
			$templateName .= substr($chars, mt_rand(0, $checkLen), 1);
		}
		return $templateName;
	}

	/**
	 * 获取认证的企业认证 身份认证 和身份证号码 企业认证号码
	 */
	public function getVerifyInfo($enameId, $name, $org = FALSE)
	{
		$sfzLib = new \lib\manage\verify\VerifyLib("identity");
		$sfzList = $sfzLib->getVerfifyIdentity($enameId, $name, 1);
		if(! $sfzList)
		{
			return FALSE;
		}
		$returnSfz = $sfzList[0]["Id"];
		if($org)
		{
			$qyLib = new \lib\manage\verify\VerifyLib("company");
			$qyList = $qyLib->getVerfifyCompany($enameId, $org);
			if($qyList)
			{
				$_POST['cnname'] = $returnSfz;
				$_POST['cnorg'] = $qyList[0]['Id'];
				return array($returnSfz, $qyList[0]['Id']);
			}
			return FALSE;
		}
		$_POST['cnname'] = $returnSfz;
		return array($returnSfz, 0);
	}


	public function specialTransferInAction()
	{
		ini_set("display_errors", "On");
		error_reporting(E_ALL);
		$file = file_get_contents("/tmp/specialltransferin.txt", "r");
		if(! $file)
		{
			exit("打开文件失败");
		}
		$transfermod = new \models\manage\domain\DomainTransferInMod();
		$filecontent = explode("\n",$file);
		$regid = 21; // 根据实际后缀来
		$finance = new \interfaces\manage\Finance();
		foreach($filecontent as $info)
		{
			if(!$info)
			{
				continue;
			}
			$inarr = explode(',',$info);
			$enameId = $inarr[0];
			$domainName = $inarr[1];
			$password = $inarr[2];
			$saveLtd = $inarr[3];
			$dnsType = 1;
			$transferLib = new \lib\manage\domain\DomainTransferInLib($enameId);
			$status = $transferLib->checkIsOkToAdd($domainName, FALSE);
			if($status !== true)
			{
				error_log($password . "," . $domainName . ",alread transfering\r\n", 3, "/tmp/spcialtransfer.log");
				echo $password . "," . $domainName . ",alread transfering\r\n";
				continue;
			}
			$templib = new \lib\manage\domain\TemplateLib();
			$templateinfo = $templib->getUseTemplates($enameId,'TransferInTemplate',true);
			$templateId = $templateinfo[0]['TemplateId'];
			$templateName = $templateinfo[0]['TemplateName'];
			$productName = \lib\manage\common\DomainFunLib::getDomainClassAll($domainName);
			// 先订单
			$productType = \lib\manage\common\DomainFunLib::getDomainProductType($domainName);
			$createInfo = array(
					"enameId" => $enameId, "productName"=>".".$productName,"userGroupId"=>2,"productType" => $productType, "domain" => $domainName, "year" => 1,
					"type" => "2", "remarkHide" => "NO.63285  帮提交域名转入", "registarId" => $regid);
			$orderId = $finance->addProductOrder((object) $createInfo);
			if(! $orderId || ! is_numeric($orderId))
			{
				error_log($password . "," . $domainName . ",create order failed\r\n", 3, "/tmp/spcialtransfer.log");
				echo $password . "," . $domainName . ",create order failed\r\n";
				continue;
			}
			$vspLogic = new \logic\manage\thrift\VspLogic();
			$eppLogic = new \logic\manage\thrift\EppLogic();
			$transferReturn = $eppLogic->domainTransferIn($domainName, $password, 1, $templateName,$vspLogic->getDomainBusinessCode($domainName));
			echo $domainName.'\r\n';
			print_r($transferReturn);
			if($transferReturn['resultCode'] == 5000)
			{
				try
				{
					$redis = \core\RedisLib::getInstance('manage');
					$redis->delete("ename_shimingzhi" . $domainName);
				}
				catch(Exception $e)
				{
					echo $e->getMessage() . "\r\n";
				}
				$transferstatus = "6"; // 正在转入
			}
			else if($transferReturn['resultCode'] == 5019 && stripos($transferReturn["data"]["msg"]["resultMsg"], 'auditing') !==false)
			{
				$transferstatus = "3"; // 邮件同意转入
			}
			if(isset($transferstatus))
			{
				$insertData = array(
						'DomainName' => $domainName, 'EnameId' => $enameId, 'SubmitIp' => '127.0.0.1', 'OrderId' => $orderId,
						'TemplateId' => $templateId, 'Year' => 1, 'ProductType' => $productType, 'DnsStatus' => $dnsType,
						'Password' => $password, 'TransferStatus' => $transferstatus, 'CreateTime' => date('Y-m-d H:i:s'),'UpdateTime'=>date('Y-m-d H:i:s'),
						'DomainLtd' => $saveLtd, 'RegistrarId' => $regid);
				if(FALSE == $transfermod->addTransferIn($insertData))
				{
					error_log($password . "," . $domainName . ",add table failed\r\n", 3, "/tmp/spcialtransfer.log");
					continue;
				}
				echo $password . "," . $domainName.",transferin success\r\n";
			}
			else
			{
				echo $password . "," . $domainName.",transferin failed\r\n";
				$this->transferOrderDone($domainName, $orderId, $enameId);
			}
		}
	}

	public function topaction()
	{
	//	$lib = new \lib\manage\domain\CnnicUploadLib();
	//	/$info = array('templateId'=>794394,'domain'=>'cnninc.upload');
	//	var_dump($lib->uploadInfoCnnicWithSoap($info));die;
		//$mod = new \core\ModBase('domain');
		//$mod->update("update e_template_ext set status=0 where templateid=791379 and Registrar=86",'',array());	
		//die;
		//$logic = new \logic\manage\domain\DomainTradeLogic();
		//$st = $logic->setDomainMyStatus('jiuchan.top', 2);
		//var_dump($st);
		//var_dump(\core\Response::getErrMsg());die;
		$logic = new \logic\manage\thrift\VspLogic();
		var_dump($logic->registrantRelUpload('ename_t6x2f8ip1p','ename_t6x2f8ip1p'));
			die;
			$lib = new \lib\manage\domain\TemplateLib();
			if(!$lib->setTemplateExt(array('enameId'=>'1132099','templateId'=>794418,'registrar'=>86), array('newstatus'=>2)))
			{
				echo 333;
			}
	}


	private function contactCnnicaction()
        {
		ini_set('display_errors','On');
		error_reporting(E_ALL);
		$sql="select TemplateName,EnameId,TemplateId from e_template_zh where cnstatus=2 and templatetype in(1,4) order by createtime desc limit 20";
		$mod = new ModBase('domain');
		$list = $mod->select($sql,'',array());
		$lib = new \lib\manage\domain\TemplateLib();
		if(!$list){exit('notdata');}
		foreach($list as $info){
			$templateName=$info['TemplateName'];
			$templateId=$info['TemplateId'];
			$logic = new \logic\manage\thrift\VspLogic();
			$enameId=$info['EnameId'];
			$wang="select * from e_template_ext where TemplateId=$templateId and EnameId=$enameId and Registrar=86";
			$exit = $mod->getRow($wang,'',array());
			if(!$exit){echo $templateId.',not reg topwang'."\r\n";continue;}
			$contact = $logic->registrantRelUpload($templateName, $templateName);
			var_dump($contact);
			if($contact){
				if(!$lib->setTemplateExt(array('EnameId'=>$enameId,'TemplateId'=>$templateId,'Registrar'=>86), array('Status'=>2)))
				{
					echo $templateId.',updaet db error'."\r\n";	
				}
			}else{
				echo $templateId.",contact error\r\n";
			}
		}	
        }

	public function pushaction(){
		$mod = new ModBase('domain');
		$sql="select * from e_domain_push where SendId='68888' and ReceiveStatus='1' and SendStatus='0' and ReceiveTime>='2016-10-18 00:00:00'";
		$list = $mod->select($sql,'',array());
		if($list){
			foreach($list as $info){
				//echo $info['SendId'].','.$info['ReceiveId'].','.$info['ReceiveTime'].','.$info['PushPrice'].','.$info['Ip'].','.$info['ReceiveIp'].','.implode('=',explode("\n",$info['DomainName'])).','.count(explode("\n",$info['DomainName']));
				//echo "\r\n";
			}
		}
		//die;
		$sql2="select * from e_domain_push where ReceiveId='68888' and ReceiveStatus='1' and SendStatus='0' and ReceiveTime>='2016-10-18 00:00:00'";
		$list = $mod->select($sql2,'',array());
		if($list){
			foreach($list as $info){
				echo $info['SendId'].','.$info['ReceiveId'].','.$info['ReceiveTime'].','.$info['PushPrice'].','.$info['Ip'].','.$info['ReceiveIp'].','.implode('=',explode("\n",$info['DomainName'])).','.count(explode("\n",$info['DomainName']));
				echo "\r\n";
			}
		}
	}

	public function dreameraction()
	{
		error_reporting(E_ALL);
		ini_set("display_errors","on");
		$mod = new ModBase("domain");
		$num=0;
		$pagesize=50;
		$logic = new \logic\manage\domain\DomainTemplateLogic();
		while(true){
			$limit=$num*$pagesize.",".$pagesize;	
			$sql="select RegistrarId,DomainName,TemplateId from e_domains where TemplateId=741759 and EnameId=1087024 limit $limit";
			$list = $mod->select($sql,"",array());
			if($list){
				foreach($list as $info){
					$regid=$info['RegistrarId'];
					$domain=$info['DomainName'];
					echo $domain."\r\n";
					$temp = array('enameId'=>1087024,'domain'=>$domain,'tempType'=>1,'templateId'=>'794493','newTemplateName'=>'新临时模板2','oldTemplateName'=>'临时模板','oldTemplateId'=>'741759','registrarId'=>$regid);
					var_dump($logic->templatePush($temp));
				}
				//$data = array('EnameId'=>1087024,'Function'=>'template_push','Hidden'=>1,'Priority'=>4,'Data'=>$temp);
			//	print_r($data);
			//	var_dump($logic->addQueueTask($data));
			}else{
				echo "end ";break;
			}
			$num++;
		}

die;
		$sql="select e.templateid from e_domains as e,e_template_zh as t where e.templateid=t.templateid and 
			e.registrarid=86 and e.templateid not in(413119,428291,626357,626395,697807,741759) and cnstatus=2 and 
			t.templatetype in(1,4) and t.createtime<'2016-10-20 12:01:00' group by e.templateid";
		$mod = new ModBase('domain');
		$sql="update e_domains set isrealname=1 where DomainName='mom.top' and enameid=942016";
		$mod->update($sql,'',array());
		die;
		$list = $mod->select($sql, "", array());
		if(!$list)
		{
			exit('333');
		}
		$sql2 ="select Domain from e_domain_service2016 where servicetype=88";
		$dnlist = $mod->select($sql2, '', array());
		$check = array();
		foreach($list as $info)
		{
			$id = 'old_'.$info['templateid'];///数据库的
			$check[] = $id;
				
		}
		foreach($dnlist as $info)
		{
			$dn = $info['Domain'];
			if(!in_array($dn, $check))
			{
				echo $dn;
				echo "\r\n";
			}
		}

	}

public function fixFifteenTransferAction()
        {
                $file = fopen("/home/yangyf/order2", "r");
                if(!$file)
                {
                        exit("打开文件失败");
                }
                $donn = 0;
                $orderLib = new \interfaces\manage\Finance();
                while(!feof($file))
                {
                        // -5, 7, 30528559
                        $line = trim(fgets($file));
                        if(!$line)
                        {
                                continue;
                        }
                        $lines = explode(',', $line);
                        $orderId = trim($lines[2]);
                        $status = trim($lines[0]);
                        echo $donn++ . '---' . $orderId . ',' . $status . "\r\n";
                        if($donn > 1) exit('test over');
                        $info = $this->domainMod->getRow(
                                "select TransferInId,DomainName,CreateTime,OrderId,EnameId,RegistrarId from e_domain_transfer_in where orderid = $orderId and TransferStatus = 7",
                                array(), array());
                        var_dump($info);
                        if(!$info)
                        {
                                \core\Log::write($line, 'crontemp/transferin', 'fixFifteenTransfer_noinfo');
                                continue;
                        }
                        $domain = $info['DomainName'];
                        echo $domain . "\r\n";
                        // 检测是否存在最新转入记录
                        $newInfo = $this->domainMod->getRow(
                                "select TransferInId from e_domain_transfer_in where domainname = '" . $domain . "' and CreateTime > '" .
                                         $info['CreateTime'] . "' order by TransferInId desc", array(), array());
                        var_dump($newInfo);
                        if($newInfo)
                        {
                                \core\Log::write($line, 'crontemp/transferin', 'fixFifteenTransfer_hasnew');
                                continue;
                        }
                        // 否则重新生成订单并更新转入状态和orderid
                        $productType = \lib\manage\common\DomainFunLib::getDomainProductType($domain);
                        $productName = \lib\manage\common\DomainFunLib::getDomainClassAll($domain);
                        $domainsArr = array('domain' => $domain,'enameId' => $info['EnameId'],'year' => 1,'promoCode' => '',
                                'productName' => '.' . $productName,'userGroupId' => 2,'productType' => $productType,'type' => 2,
                                'remark' => '', 'remarkHide' =>'oa63499', 'registarId' => $info['RegistrarId']);
                        var_dump($domainsArr);
if(FALSE == $orderInfo)
                        {
                                \core\Log::write($line, 'crontemp/transferin', 'fixFifteenTransfer_orderfail');
                        }
                        else
                        {
                                \core\Log::write($line, 'crontemp/transferin', 'fixFifteenTransfer_ordersuc');
                                $upSql = "update e_domain_transfer_in set TransferStatus = $status, OrderId = " . $orderInfo .
                                         " where DomainName = '" . $domain . "' and TransferInId = " . $info['TransferInId'] .
                                         " and enameid = " . $info['EnameId'];
                                echo $upSql . "\r\n";
                                $upRs = $this->domainMod->update($upSql, array(), array());
                                if($upRs)
                                {
                                        \core\Log::write($upSql, 'crontemp/transferin', 'fixFifteenTransfer_upsuc');
                                }
                                else
                                {
                                        \core\Log::write($upSql, 'crontemp/transferin', 'fixFifteenTransfer_upfail');
                                }
                        }
		}
	}
// 批量导出某用户的域名
        public function exportDomainAction()
        {
                $enameId = 642772;
                $exportFile = "/tmp/eNameID-" . $enameId . "-DomainList.csv";
                $dnMod = new ModBase('domain');
                $sql = "select * from e_domains where TemplateId in(787549,691610) and EnameId=" . $enameId;
                $result = $dnMod->select($sql, '', array());
                if(!$result)
                {
                        echo "该用户没有域名";
                        exit();
                }
                $groupSql = "select * from e_domain_group where CreateUser=" . $enameId;
                $groupInfo = $dnMod->select($groupSql, '', array());
                $toCN = array();
                if($groupInfo)
                {
                        foreach($groupInfo as $k => $v)
                        {
                                $toCN[$v['GroupId']] = $v['GroupName'];
                        }
                }
                echo "开始导出用户【" . $enameId . "】的域名\r\n";
                error_log("域名,注册时间,到期时间,状态,分组\r\n", 3, $exportFile);
                foreach($result as $k => $v)
                {
                        $item = $v['DomainName'] . ",";
                        $item .= $v['RegDate'] ? date("Y-m-d", strtotime($v['RegDate']) + 8 * 3600) : '';
                        $item .= ",";
                        $item .= $v['ExpDate'] ? date("Y-m-d", strtotime($v['ExpDate']) + 8 * 3600) : '';
                        $item .= ",";
                        $item .= self::getDomainStatusStr($v['DomainMyStatus'], $v['DomainHoldStatus'], $v['DomainProperty'],
                                $v['DnsType'], $v['AutoRenew'], $v['ExpDate']) . ",";
                        $item .= isset($toCN[$v['DomainGroup']]) ? $toCN[$v['DomainGroup']] : '未分组';
                        $item .= "\r\n";
                        error_log($item, 3, $exportFile);
                }
                echo "结束导出用户【" . $enameId . "】的域名";
        }

private function getDomainStatusStr($status, $holdStatus, $property, $dns, $autoRenew, $expDate)
        {
                $str = array();
                if($dns == 0 || $dns == 4)
                {
                        $str[] = "我司DNS";
                }
                else if($dns == 3)
                {
                        $str[] = "其它DNS";
                }
                $expDate = strtotime($expDate);
                if($expDate < time())
                {   
                        $str[] = "已经到期";
                }   
                else
                {   
                        $day = ceil(($expDate - time()) / (24 * 3600));
                        if($day && $day < 31) 
                        {   
                                $str[] = "即将到期";
                        }   
                }   
                if($status == 2 || $status == 10) 
                {   
                        $str[] = "正在交易";
                }   
                elseif($status == 3)
                {   
                        $str[] = "经纪中介";
                }   
                elseif($status == 4)
                {   
                        $str[] = "正在PUSH";
                }   
                elseif($status == 5 || $status == 6)
                {   
                        $str[] = "正在转出";
                }   
                elseif($status == 7)
                {
                        $str[] = "域名锁定";
                }
                elseif($status == 11)
                {
                        $str[] = "注册商安全锁";
                }
elseif($status == 11)
                {
                        $str[] = "注册商安全锁";
                }
                elseif($status == 12)
                {
                        $str[] = "注册局安全锁";
                }
                elseif($status == 13)
                {
                        $str[] = "安全锁申请中";
                }
                if($holdStatus == 1)
                {
                        $str[] = "禁止解析";
                }
                elseif($holdStatus == 2)
                {
                        $str[] = "DNS锁定";
                }
                elseif($holdStatus == 3)
                {
                        $str[] = "展示页";
                }
                elseif($holdStatus == 5)
                {
                        $str[] = "展示页";
                }
                if($property == 4 || $property == 6)
                {
                        $str[] = "腾讯邮箱";
                }
                if($autoRenew)
                {
                        $str[] = "自动续费";
                }
                return implode('，', $str);
        }


	public function checktransferaction(){
		$mod = new ModBase('domain');
		$fin = new ModBase('finance');
		$list = $mod->select("select * from e_domain_transfer_in where transferstatus>=8 and createtime>='2016-11-01 00:00:00'",'',array());
		if($list){
			foreach($list as $info)
			{
				if(!$info['OrderId']) continue;
				$sql="select * from e_finance_orders where orderid={$info['OrderId']}";
				$order = $fin->getRow($sql,'',array());
				if($order){
					echo $order['OrderId'].",".$info['DomainName'].','.($order['OrderStatus'] ===1 ? 'success' : ($order['OrderStatus']==2 ? 'cancel' : 'ing'));
					echo "\r\n";
				}
				else{
					echo $info['DomainName'].",error\r\n";
				}

					
			
			}
		}
	}

	public function gettempaction(){
		$logic = new \logic\manage\domain\DomainFuncLogic();
		$start="2016-10-01";
		$end="2016-12-31";
		$st = $logic->getNoticeDomainNum($start, $end);
		$type = 1;
		$return = array();
					$format=array();
			foreach($st as $regid=>$listinfo)//接口部分
			{
				foreach($listinfo as $ltd=>$ltdinfo)//后缀
				{
					$ltddescc = $ltd==3 ? 'com后缀' : 'net后缀';
					foreach($ltdinfo as $value)//时间部分
					{
						if($type==2) $dkey = $value['Years'].'-'.$value['Months'];
						else $dkey = $value['Years'].'-'.$value['Months'].'-'.$value['Days'];
						if(isset($format[$regid][$ltddescc][$dkey]))
						{
							$format[$regid][$ltddescc][$dkey]+=$value['Num'];
						}
						else
						{
							$format[$regid][$ltddescc][$dkey] = $value['Num'];
						}
					}
				}
			}
			foreach($format as $desc=>$info)
			{
				foreach($info as $k=>$info2)
				{
					foreach($info2 as $a=>$b)
					{
						echo $desc.','.$k.",".$a.",".$b;
						echo "\r\n";
					}
				}
						echo "\r\n";
			}	
	}

/**
	 * 获取CC用户邮箱
	 */
	public function getccEmailAction()
	{

		//$params = array('domain'=>"cdiao.com",'registrarID'=>21,'preData'=>"2016-11-17T14:05:29Z");
		//include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		//$sdk = new \ApiSdk();
		//$report = $sdk->execSdkFun(5402,$params);
		//var_dump($report);
//die;
		$queueLogic = new \logic\manage\newqueue\QueueLogic();
		$mailData = array('Function' => 'sendmail', 'EnameId' => 618264, 'TemplateName' => 'any_template_info', 'Target' => 'jillpeng@wonderfulworld2016.cn', 'Data' => array('domainName' => "aaa.com", "title"=>"易名中国测试","content"=>"这是测试内容",'enameId' => 618264), 'Priority' => 5);
		$sendResult = $queueLogic->addQueueNormal($mailData);
die;
				$logic = new \logic\manage\thrift\EppLogic();
		$tempData["domain"] = "youlexingkong.com"; 
		var_dump($logic->domainEppChangeRegistrantTemp($tempData));	

		die;
		$fileName = "/tmp/cc_enameid.csv";
		$finlog = new \logic\manage\finance\FinanceLogic();
		$file = fopen($fileName, "r");
		if(!$file)
		{
			exit("打开文件失败");
		}
		$userMod = new ModBase('user');
		while(!feof($file))
		{
			$line = trim(fgets($file));
			if(!$line)
			{
				continue;
			}
			$enameIdSql = "select EnameId,Email from e_member where EnameId='$line'";
			$enameIdResult = $userMod->getRow($enameIdSql, '', array());
			echo $enameIdResult['EnameId'].','.$enameIdResult['Email']."\r\n";
		}
	}

	public function checktradedataaction()
	{
		$xiong = file_get_contents("/tmp/xiong.log");
		if(!$xiong) exit("not fouddata");
		$conteArr = explode("\n",$xiong);
		$mod = new ModBase('domain');
		$fin = new ModBase('finance');
		//卖家  买家  域名 订单Id  6-24
		//1043282 ,981080 ,kpwg.wang,27771531
		foreach($conteArr as $info)
		{
			$infoarr=explode(",",$info);
			$sell = trim($infoarr[0]);
			$buyer=$infoarr[1];
			$domain=$infoarr[2];
			$orderid=$infoarr[3];
			$checkExists = "select * from e_domain_operation_log2016 where logtype=8 and EnameId=$buyer and domainname='$domain' and Content like '%接收域名%' and CreateTime>='2016-06-23 00:00:00'";
			$check=$mod->select($checkExists,'',array());
			$statusCheck = $check ? true :false;
			$orderinfo = $fin->getRow("select * from e_finance_orders where orderid=$orderid", "", array());
			if($orderinfo)
			{
				$ordercheck = $orderinfo['OrderStatus'] == 1 ? true : $orderinfo['OrderStatus'];
			}
			if($statusCheck ===true && $ordercheck ===true)
			{
				echo $info.",isright\r\n";
			}elseif($statusCheck===true && $ordercheck===2)
			{
				echo $info.",ordercacel\r\n";
			}
			elseif($statusCheck===true && $ordercheck ===3)
			{
				echo $info.",ordering\r\n";
			}elseif($statusCheck===false && $ordercheck===2)
			{
				echo $info.",isright\r\n";
			}elseif($statusCheck===false && $ordercheck===1)
			{
				echo $info.",orderconfirm\r\n";
			}elseif($statusCheck===false && $ordercheck===3)
			{
				echo $info.",ordering\r\n";
			}
			else
			{
				echo $info.",idonknow\r\n";
			}
		}
	}


	public function reparelockaction()
	{
		$mod = new ModBase('domain');
		$content = file_get_contents("/tmp/reparetransfer");
		if(!$content) exit("error");
		$domainArr = explode("\n",$content);
		print_r($domainArr);
		$transferList = $mod->select("select * from e_domain_transfer_in where transferstatus>=8 and islock=2","",array());
		if(!$transferList) exit("not data");
		$domains = array();
		foreach($transferList as $info){
			$domain=$info['DomainName'];
			$enameId = $info['EnameId'];
			$successtime = strtotime($info['SuccessTime']);
			$exists = $mod->getRow("select * from e_domain_lock where dl_domain='$domain' and dl_type=3","",array());
			if($exists && in_array($domain,$domainArr)){
				echo $domain."\r\n";
				$id=$exists['dl_id'];	
				$outtime=($successtime)+5184000;	
				$mod->update("update e_domain_lock set dl_out_time=$outtime,dl_lock_time=$successtime where dl_id=$id", '', array());
			}
		}
		
		die;
		$list = $mod->select("select * from e_domain_lock where dl_lock_time>='1480521600'", '', array());
		if($list)
		{
			foreach($list as $info)
			{
				$id=$info['dl_id'];//记录id
				$outtime = ($info['dl_out_time']);//失效时间
				$locktime = ($info['dl_lock_time']);//添加时间
				error_log($id.",".$outtime.",".$locktime."\r\n",3,"/tmp/domainlockback");
				if($locktime!=$outtime-5184000)
				{
					echo $id.",".$outtime.",".$locktime."\r\n";
					$right=$locktime+5184000;
					$mod->update("update e_domain_lock set dl_out_time=$right where dl_id=$id", '', array());
				}
			}
		}
	}

	public function checkDnsToIIdnsAction()
	{
		$content = file_get_contents("/tmp/dnslog.csv");
		if(!$content)
		{
			exit("error file");
		}
		$contentArr = explode("\n", $content);
		$mod = new ModBase('domain');
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		$logic = new \logic\manage\domain\DomainManageLogic();
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'iidns');
		$selfDns = $conf->iidns->toArray();
		foreach($contentArr as $domain)
		{
			$domainName = trim($domain);
			if(!$domainName) continue;
			$domainInfo = $mod->getRow("select * from e_domains where DomainName='$domainName'", "", array());
			if(!$domainInfo)
			{
				echo $domainName.",not found\r\n";continue;
			}	
			$regid = $domainInfo['RegistrarId'];
			$domainId = $domainInfo['DomainId'];
			$checkdata = array('domain' => $domainName, 'registrarID' => $regid);
			$domainSdkInfo = $sdk->execSdkFun(5025, $checkdata);
			if($domainSdkInfo['resultCode'] ==5000)
			{
				$sdkDnsInfo = $domainSdkInfo['data']['DNS'];
				$dnsInfos = is_array($sdkDnsInfo) ? implode(",", $sdkDnsInfo) : $sdkDnsInfo;
				echo $domainName .",".$dnsInfos."\r\n";;
				if(stripos($dnsInfos,"ename.cn")!==false)
				{
					//处理掉
					\core\Log::write("old dsnbak," . $domain.','.$dnsInfos, 'crontemp/domain',
						'checkDnsToIIdnsAction');
					//接口修改dns
					$sendData = array();
					$sendData['domain'] = $domainName;
					$sendData['dns'] = $selfDns;
					$sendData['registrarID'] = $regid;
					$sendData['domainId'] = $domainId;
					$sendData['enameId'] = $domainInfo['EnameId'];
					$sendData['dnsType'] = 0;
					$result = $logic->setDomainDns($sendData);
					if($result)
					{
						//修改db
						$updatezhu = "update e_domains set dnstype=0 where DomainName='$domainName'";
						$updateext="update e_domain_ext set dns='' where DomainId='$domainId'";
						$st1 = $mod->update($updatezhu, "", array());
						\core\Log::write("checkDnsToIIdnsAction," . $domain.',up e_domains '.($st1 ? 'success' :'failed'), 'crontemp/domain',
							'checkDnsToIIdnsAction');
						$st2 = $mod->update($updateext, "", array());
						\core\Log::write("checkDnsToIIdnsAction," . $domain.',up e_domaine_ext '.($st2 ? 'success' :'failed'), 'crontemp/domain',
							'checkDnsToIIdnsAction');
					}else{
						echo $domain.",".$dnsInfos.",error\r\n";
					}	
				}
				else
				{
					echo $domain.",".$dnsInfos.",not ename.cn,not handler\r\n";
				}
			}
		}
	}

	public function checkWhiteAction()
	{
		error_reporting('E_ALL');
		ini_set('display_errors','On');
		$mod = new ModBase('domain');
		$list = $mod->select("select * from e_template_zh where RegistrarId=1 and CreateTime>='2016-10-22 00:00:00' and templatetype in(1,4) and CnStatus in(0,3,4)", "", array());
		if($list)
		{
			include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
			$sdk = new \ApiSdk();
			foreach($list as $info)
			{
				$templateId = $info['TemplateId'];
				$templateName=$info['TemplateName'];
				$enameId = $info['EnameId'];
				echo $templateId .",".$templateName;
				$info = $sdk->execPublicSdkFun('0653', array('registrarId' => $templateName));
				if($info===true)//只处理成功的 不成功的不管
				{
					$updatezh="update e_template_zh set CnStatus=2 where TemplateId=?";
					echo $updatezh;
					echo "\r\n";
					$upinfo = $mod->update($updatezh, "i", array($templateId));
					if(!$upinfo)
					{
						echo ",update db error";
						echo "\r\n";
						continue;
					}
					if($this->contactCnnic($templateName, $enameId, $templateId,86))
					{
						echo "binding success";
					}
					echo "\r\n";
				}
				echo (",".$info["msg"]);
				echo "\r\n";
			}
		}
	}

	public function checkWhite2Action()
	{


		$mod = new ModBase('domain');
		//$mod->update("update e_domain_protection set status=5 where id=65650","",array());
		//die;
		$list = $mod->select("select * from e_template_zh where CreateTime>='2016-12-10 00:00:00' and templatetype in(7) and CnStatus in(2)", "", array());
		if($list)
		{
			include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
			$sdk = new \ApiSdk();
			foreach($list as $info)
			{
				$templateId = $info['TemplateId'];
				$templateName=$info['TemplateName'];
				$enameId = $info['EnameId'];
				echo $templateId .",".$templateName;
				$info = $sdk->execPublicSdkFun('0653', array('registrarId' => $templateName));
				if($info===true)//只处理成功的 不成功的不管
				{
					$top="select * from e_template_ext where TemplateId=$templateId and Registrar=86";
					$topInfo = $mod->getRow($top, "", array());
					if($topInfo)
					{
						if($topInfo['Status'] == 2)
						{
							echo ",arealdy bind success\r\n";
						}
						else
						{
							if($this->contactCnnic($templateName, $enameId, $templateId))
							{
								echo "binding success";
							}
							echo "\r\n";
						}
					}
					else
					{
						echo ",top not reg";
						echo "\r\n";
					}
				}else{
					echo (",".$info["msg"]);
					echo "\r\n";
				}
			}
		}
	}

	
	private function contactCnnic($cnnicName,$enameId,$templateId,$regid = 86)
	{
		$logic = new \logic\manage\thrift\VspLogic();
		$contact = $logic->registrantRelUpload($cnnicName, $cnnicName);
		if($contact)
		{
			$lib = new \lib\manage\domain\TemplateLib();
			if(!$lib->setTemplateExt(array('enameId'=>$enameId,'templateId'=>$templateId,'registrar'=>$regid), array('newstatus'=>2)))
			{
				echo "update topdb error";
			}
			else
			{
				echo "update topdb success";
			}
			return true;
		}
		echo "bind error,";
	}

	public function apptestaction(){
		$logic = new \logic\manage\member\OperateLogic();
		$info = (Object)array('identify'=>'D401','EnameId'=>'19092');
		echo json_encode($logic->getData($info));
	}


	public function midaipushaction()
	{
		//777128
		//将“米贷质押模板”下的21777个域名
		//21611
		$enameId=177446;
		$newTemp=807922;
		$newtempname="常规质押模板";
		$oldTempname="米贷质押模板";
		$oldTempid=777128;
		$regid = 1;
		$mod = new ModBase('domain');
		$num=0;
		$size = 4000;
		while(true)
		{
			$limit = $num*$size.",".$size;
			$list1="select * from e_domains where EnameId=$enameId and TemplateId=$oldTempid";
			$list1 .=" limit $limit";
			$listResult = $mod->select($list1, "", array());
			if($listResult)
			{
				$data =array();
				$logic = new \logic\manage\thrift\QueueLogic();
				foreach($listResult as $info)
				{
					echo $info['DomainName']."\r\n";
					$temp = array('domain'=>$info['DomainName'],'tempType'=>1,'templateId'=>$newTemp,
							'newTemplateName'=>$newtempname,'oldTemplateName'=>$oldTempname,'oldTemplateId'=>$info['TemplateId'],'registrarId'=>$info['RegistrarId']);
					$data[] = $temp;
				}
				$newdata = array('EnameId'=>$enameId,'Function'=>'template_push','Priority'=>4,'Data'=>$data);
				print_r($logic->addQueueTask($newdata));
				sleep(1);
			}
			else
			{
				exit("not data");
			}
			die;
			$num++;
		}
		die;die;die;

		//“4声cn1”下的4999个域名过户到模板“常规质押模板”
		$enameId=177446;
		$newTemp=807922;
		$newtempname="常规质押模板";
		$oldTempname="4声cn1";
		$oldTempid=759887;
		$regid = 1;
		$logic = new \logic\manage\thrift\QueueLogic();
		$mod = new ModBase('domain');
		$list1="select * from e_domains where EnameId=$enameId and TemplateId=$oldTempid and registrarId=1";
		$listResult = $mod->select($list1, "", array());
		if($listResult)
		{
			$data = array();
			foreach($listResult as $info)
			{
				echo $info['DomainName']."\r\n";
				$temp = array('domain'=>$info['DomainName'],'tempType'=>1,'templateId'=>$newTemp,
						'newTemplateName'=>$newtempname,'oldTemplateName'=>$oldTempname,'oldTemplateId'=>$info['TemplateId'],'registrarId'=>1);	
				$data[] = $temp;
			}
			$data = array('EnameId'=>$enameId,'Function'=>'template_push','Priority'=>4,'Data'=>$data);
			var_dump($logic->addQueueTask($data));
		}
	}


public function repareAppRenewAction()
{
	$finmod = new ModBase('finance');
	$sql = 'select * from e_finance_orders where ordertype=3 and enameid=786085 and createtime<"2016-07-20 22:00:00" and  orderstatus=3 and (domain like "%.cn") and RegistarId=11';
	$list = $finmod->select($sql, "", array());
	if(! $list)
	{
		exit("not data\r\n");
	}
	$dnmod = new ModBase('domain');
	foreach($list as $info)
	{
		$domain = $info['Domain'];
		$orderId = $info['OrderId'];
		$enameId = $info['EnameId'];
		$createTime = $info['CreateTime'];
		$oporder = json_decode($info['ProductOptions'], true);
		$orderface = new \interfaces\manage\Finance();
		$oporderyear = $oporder['year'];
		$st1 = $orderface->cancelOrder((object) array('enameId' => $enameId, 'orderId' => $orderId));
		if($st1)
		{
			echo "need confirm,confirm success," . $domain . ',' . $orderId . ',' . $createTime . "\r\n";
		}
		else
		{
			echo "need confirm,confirm failed," . $domain . ',' . $orderId . ',' . $createTime . "\r\n";
		}
		continue;
		$end = date('Y-m-d H:i:s', strtotime($createTime) + 1200);
		$dnlog = "select * from e_domain_service2016 where ServiceType=6 and Domain='$domain' and Content like '%renew%' and Content like '%0611%'";
		$dnlog .= " and Content like '%expDate%' and Content like '%year%'";
		$renewlog = $dnmod->getRow($dnlog, "", array()); // 时间点附近找到
		if($renewlog)
		{
			$content = $renewlog['Content'];
			$content = json_decode($content, true);
			$year = $content['year'];
			$expdate = $content['expDate'];
			$dninfo = $dnmod->getRow("select * from e_domains where DomainName='$domain'", '', array());
			if($dninfo && $dninfo['ExpDate'] == $expdate) // 存在并且还是相同的要做退款处理
			{
				$dbtime = $dninfo['ExpDate'];
				if($dninfo['DomainMyStatus'] == 4)
				{
					// 跳过转接口的
					echo "in transfer," . $domain . ',' . $orderId . ',' . $createTime . ',' . $expdate . ',' .$dninfo['ExpDate'];
				}
				else
				{
					echo "first,cancel," . $domain . ',' . $orderId . ',' . $createTime . ',' . $expdate . ',' .$dninfo['ExpDate'];
					$orderface = new \interfaces\manage\Finance();
					$st1 = $orderface->cancelOrder((object) array('enameId' => $enameId, 'orderId' => $orderId));
					if($st1)
					{
						echo "first cancel,cancel success," . $domain . ',' . $orderId . ',' . $createTime . ',' .
							$expdate . ',' . $dninfo['ExpDate'];
					}
					else
					{
						echo "first cancel,cancel failed," . $domain . ',' . $orderId . ',' . $createTime . ',' .
							$expdate . ',' . $dninfo['ExpDate'];
					}
				}
				echo "\r\n";
				continue;
			}
			if($dninfo && $dninfo['ExpDate'] > $expdate) // 存在并且时间大于当前的续费时间的则看下是否有在一条心的续费日志
			{
				$success = "select * from e_finance_orders where createTime>'$createTime'  and Domain='$domain' and OrderType=3 and OrderStatus=1";
				$insuccess = $finmod->getRow($success, "", array());
				if($insuccess) // 存在一条心的成功数据
				{
					$op = json_decode($insuccess['ProductOptions'], true);
					$opyear = $op['year'];
					$diff = intval(substr($dninfo['ExpDate'], 0, 4) - substr($expdate, 0, 4));
					if($diff == $opyear) // 前一次续费没有成功
					{
						// 第一个订单需要推掉的
						echo "second,cancel," . $domain . ',' . $orderId . ',' . $createTime . ',' . $expdate . ',' .$dninfo['ExpDate'] . "\r\n";
						$orderface = new \interfaces\manage\Finance();
					/*	$st1 = $orderface->cancelOrder((object) array('enameId' => $enameId, 'orderId' => $orderId));
						if($st1)
						{
							echo "need cancel,cancel success," . $domain . ',' . $orderId . ',' . $createTime . ',' .$expdate . ',' . $dninfo['ExpDate'];
						}
						else
						{
							echo "need cancel,cancel failed," . $domain . ',' . $orderId . ',' . $createTime . ',' .$expdate . ',' . $dninfo['ExpDate'];
						}*/
						echo "\r\n";
					}
					else
					{
						echo "third,needcheck," . $domain . ',' . $orderId . ',' . $createTime . ',' . $expdate . ',' .$dninfo['ExpDate'];
						//$orderface = new \interfaces\manage\Finance();
						//$st = $orderface->cancelOrder((object) array('enameId' => $enameId, 'orderId' => $orderId));
						echo "\r\n";
					}
					continue;
				}
				// 之后没有成功的记录 并且最新的时间跟之前提交的对比=续费的年数的要给确认订单
				$diff = intval(substr($dninfo['ExpDate'], 0, 4) - substr($expdate, 0, 4));
				if($diff == $oporderyear)
				{
					echo "111,need confirm," . $domain . ',' . $orderId . ',' . $createTime . ',' . $expdate . ',' .
						$dninfo['ExpDate'];
					echo "\r\n";
					$orderface = new \interfaces\manage\Finance();
				/*	$st1 = $orderface->confirmOrder((object) array('enameId' => $enameId, 'orderId' => $orderId));
					if($st1)
					{
						echo "need confirm,confirm success," . $domain . ',' . $orderId . ',' . $createTime . ',' .$expdate . ',' . $dninfo['ExpDate']."\r\n";
					}
					else
					{
						echo "need confirm,confirm failed," . $domain . ',' . $orderId . ',' . $createTime . ',' .$expdate . ',' . $dninfo['ExpDate']."\r\n";
					}*/
				}
			}
		}else{
			echo $domain . "," . $orderId . ',' . $createTime . ",not found"."\r\n";
			$dninfo = $dnmod->getRow("select * from e_domains where DomainName='$domain'", '', array());
			if($dninfo) // 存在并且还是相同的要做退款处理
			{
				if($dninfo['ExpDate'] < '2017-01 01 00:00:00')
				{
					echo "first,cancel," . $domain . ',' . $orderId . ',' . $createTime . ',' . $dninfo['ExpDate'];
					echo "\r\n";
					continue;
				}
				//已经有成功的记录
				$success = "select * from e_finance_orders where createTime>'$createTime'  and Domain='$domain' and OrderType=3 and OrderStatus=1";
				$insuccess = $finmod->getRow($success, "", array());
				if($insuccess)
				{	
					echo "alreay ok,need cancel," . $domain . ',' . $orderId . ',' . $createTime . ',' . $dninfo['ExpDate'];
					echo "\r\n";
				}
			}
			else
			{
				echo $domain . "," . $orderId . ',' . $createTime . ",not found,out against"."\r\n";
			}
		}
	}
}



	public function checkdnsrenewaction(){
		$content = file_get_contents('/tmp/check_dns_renew_domain.csv');
		$contentArr = explode("\n",$content);
		$mod =new ModBase("domain");
		foreach($contentArr as $info){
			$domain=trim($info);
			$sql="select * from e_domain_delete where domain='$domain' and Result like '%domain del success%'";
			$result=$mod->getRow($sql,'',array());
			if($result){
				echo $domain.",".$result['Time'].",success\r\n";
			}else{
				echo $domain.",not found del or del failed\r\n";
			}	
		}

	}	

public function getccAction()
	{
		$fileName = "/tmp/webcc.csv";
		$file = fopen($fileName, "r");
		if(!$file)
		{
			exit("打开文件失败");
		}
		$userLogic = new logic\manage\whois\WhoisLogic();
		while(!feof($file))
		{
			$line = trim(fgets($file));
			$temp = explode(',', $line);
			$domain = strtolower(trim($temp[0])); // 我司域名
			if(!isset($temp[1]))
			{
				echo '域名无过期时间：' . $domain;
				continue;
			}
			$whoisStatus = '';
			$rs =$userLogic->getWhois($domain);
			if(isset($rs["Status"]))
			{
				$whoisStatus = $rs["Status"];
			}
			error_log($domain.",".$temp[1].','.$whoisStatus."\r\n",3,"/tmp/webcc_get_log");
		}							
		echo 'ok';
	}


	public function upimgaction()
	{
		$info = array('templateId'=>808186,'enameId'=>54159);
		$lib = new \lib\manage\domain\CnnicUploadLib();
		var_dump($lib->uploadInfoCnnicWithSoap($info));
	}
	public function shenxiaohangAction()
	{
		$upstatus="7";
		$filename="/home/zhangjp/import_shenxiaohang_errenameid.csv";
		$filename="/tmp/shenxiaohang2.csv";
		$enameId="1087024";
		$file = fopen("$filename", "r");
		if(! $file)
		{
			exit("打开文件失败");
		}
		if(!$upstatus)
		{
			exit("更新状态错误");
		}
		$domainMod = new ModBase('domain');
		while(! feof($file))
		{
			$line = trim(fgets($file));
			if(! $line)
			{
				continue;
			}
			$domain = $line;
			$domainInfo=$domainMod->getRow("select ExpDate,DomainName,DomainMyStatus,EnameId,TempUserName from e_domains where DomainName='$domain'", "", array());
			if($domainInfo)
			{
				//if(strtotime($domainInfo['ExpDate'])+8*3600<time()){
				//	echo $domain.",".$domainInfo['EnameId'].',time out'."\r\n";
				//	continue;
				//}
				//else{
				//	echo $domain.",".$domainInfo['EnameId'].',time ok'."\r\n";
				//	continue;
				//}
				//continue;
				if($domainInfo['EnameId']!=$enameId)
				{
					echo $domain.",enameid error\r\n";
					continue;
				}
				if($domainInfo['DomainMyStatus'] == $upstatus)
				{
					echo $domain.",success\r\n";
					continue;
				}
				if($domainInfo['TempUserName']!="沈晓航")
				{
					echo $domain.",temp error\r\n";
					continue;
				}
				$st = $domainMod->update("update e_domains set DomainMyStatus='$upstatus' where DomainName='$domain' limit 1", "", array());
				if($st)
				{
					echo $domain.",success\r\n";
					continue;
				}
				echo $domain.",update failed\r\n";
			}else{
				echo $domain.",not found\r\n";
			}
		}
	}
	
	public function domainWeiguiAction()
	{
		$weiguiFile = "/tmp/seqing.csv";
		//$weiguiFile="/tmp/wangbao.csv";
		$remarks = "色情淫秽表格的域名 备注：cnnic通知，域名涉及色情淫秽，要求hold锁定。";
		//$remarks="网络赌博表格的域名  备注：cnnic通知，域名涉及网络赌博，要求hold锁定。";
		$weiguiContent = @file_get_contents($weiguiFile) or die('not found files');
		$seqingemail="/tmp/seqingbaoliemail.csv";
		//$seqingemail="/tmp/walngluodubo.csv";
		$domainMod = new ModBase('domain');
		$epp = new \lib\manage\domain\DomainEppLib();
		$weiguiArr = explode("\n", $weiguiContent);
		$userMod = new ModBase('user');
		$returnS = array();
		$dnlogic = new \logic\manage\domain\DomainManageLogic();
		foreach($weiguiArr as $weiguiInfo)
		{
			$isdel = false;
			if(! $weiguiInfo)
			{
				continue;
			}
			$lineArr = explode("\t", $weiguiInfo);
			$domain = $lineArr[0];
			if(empty($domain))
			{
				$baksql="select * from e_domains_bak where DomainName='$domain'";
				$exists = $domainMod->getRow($baksql, "", array());
				if(!$exists)
				{
					$lineArr[2] = '非我司域名';
					$lineArr[3] = '暂不处理';
					error_log(implode(",", $lineArr) . "\r\n", 3, '/home/zhangjp/baoli_done_1229.csv');
					continue;
				}
				$isdel = true;
			}
			if(!$isdel)
			{
				$sql = "select * from e_domains where DomainName='$domain'";
				$exists = $domainMod->getRow($sql, '', array());
				if(empty($exists))
				{
					$lineArr[2] = '非我司域名';
					$lineArr[3] = '暂不处理';
					error_log(implode(",", $lineArr) . "\r\n", 3, '/home/zhangjp/baoli_done_1229.csv');
					continue;
				}
			}
			if($exists['DomainMyStatus'] == 5)
			{
				$lineArr[2] = '正在转出';
				$lineArr[3] = '暂不处理';
				error_log(implode(",", $lineArr) . "\r\n", 3, '/home/zhangjp/baoli_done_1229.csv');
				continue;
			}
			if($exists['DomainMyStatus'] == 2 || $exists['DomainMyStatus'] == 3)
			{
				$lineArr[2] = '易名中国';
				$lineArr[3] = '正在交易,tradeing';
				echo implode(",", $lineArr) . "\r\n";
				error_log(implode(",", $lineArr) . "\r\n", 3, '/home/zhangjp/baoli_done_1229.csv');
				continue;
			}
			if($exists['DomainMyStatus'] == 14)
			{
				$lineArr[2] = '易名中国';
				$lineArr[3] = '已经处理,tradepro';
				error_log(implode(",", $lineArr) . "\r\n", 3, '/home/zhangjp/baoli_done_1229.csv');
// 				continue;
			}
			if($exists['DomainHoldStatus'] == 1 || stripos($exists['DomainStatus'], '7') !== FALSE)
			{
				$lineArr[2] = '易名中国';
				$lineArr[3] = '已经处理,hold';
				error_log(implode(",", $lineArr) . "\r\n", 3, '/home/zhangjp/baoli_done_1229.csv');
// 				continue;
			}
			if(!$isdel &&$exists['PrivacyTemp'])
			{
				$cancel =$dnlogic->cancelPrivacy($exists);
				if($cancel!==true)
				{
					$lineArr[2] = '易名中国';
					$lineArr[3] = '已经处理,取消隐私失败';
					error_log(implode(",", $lineArr) . "\r\n", 3, '/home/zhangjp/baoli_done_1229.csv');
				}
			}
			//临时处理
			$setDomainStatus = $epp->setDomainRegisterStatus($domain, $exists['RegistrarId'], array(3, 4, 7));
			if(! $setDomainStatus)
			{
				$lineArr[2] = '易名中国';
				$lineArr[3] = '禁止解析失败';
				echo "我司域名禁止解析失败(5012),$domain\r\n";
				error_log("我司域名禁止解析失败(5012)," . $domain . "\r\n", 3, '/tmp/2016domainweigui');
				error_log(implode(",", $lineArr) . "\r\n", 3, '/home/zhangjp/baoli_done_1229.csv');
			//:	continue;
			}
			$upSql = "update e_domains set DomainMyStatus=14,DomainHoldStatus=1,DomainStatus='3,4,7' where DomainName='$domain' limit 1";
			$upsqldel = "update e_domains_bak set DomainMyStatus=14,DomainHoldStatus=1,DomainStatus='3,4,7' where DomainName='$domain' limit 1";
			$upLocal = $domainMod->update($isdel ? $upsqldel : $upSql, '', array());
			$lineArr[2] = '易名中国';
			$lineArr[3] = '已经处理,holdstatus';
			if(! $upLocal)
			{
				echo "域名更新本地状态失败,$domain\r\n"; // go on
				error_log("域名更新本地状态失败," . "$domain" . "\r\n", 3, '/tmp/2016domainweigui');
			}
			error_log(implode(",", $lineArr) . "\r\n", 3, '/home/zhangjp/baoli_done_1229.csv');
			$insertSql = "insert into e_domain_service_ext(Domain,ServiceType,OperateIp,OperateTime,AdminId,EnameId,Content) values(?,?,?,?,?,?,?)";
			$insertType = "sisiiis";
			$insertValue = array($domain, 2, '0.0.0.0', time(), '0', $exists['EnameId'], $remarks);
			$insertNote = $domainMod->add($insertSql, $insertType, $insertValue);
			if(! $insertNote)
			{
				echo "add domain note failed,$domain,$remarks\r\n";
				error_log("add domain note failed,$domain,$remarks\r\n", 3, '/home/zhangjp/baoli_done_1229.csv');
			}
			$enameid = $exists['EnameId'];
			$query = "select Email from e_member where EnameId='" . $enameid . "'";
			$userInfo = $userMod->getRow($query, '', array());
			if($userInfo)
			{
				$returnS[$userInfo['Email']][] = $domain; 
			}
		}
		if($returnS)
		{
			echo "start email";
			echo "\r\n";
			foreach($returnS as $email => $info)
			{
				error_log($email . "=" . implode("<br>", $info) . "\r\n", 3, 
					$seqingemail);
			}
		}
	}

	public function sendweiguiemailaction()
	{
		$emailfile="/tmp/seqingbaoliemail.csv";
		$filecontent=file_get_contents($emailfile);
		if($filecontent)
		{
			$filecontent = explode("\n",$filecontent);
			foreach($filecontent as $info)
			{
				if(!$info) continue;
				$infoarr=explode("=", $info);
				$email=$infoarr[0];
				$domain=$infoarr[1];
				$ncon = "尊敬的用户：<br>您好，我司接到cnnic通知，您账户下的域名：<br>{$domain}<br> 涉及色情淫秽，要求禁止解析。目前已按照要求处理，并限制域名发布交易及push过户。";
				$content = array('title' => "域名禁止解析通知","content"=>$ncon);
				$queue = new \interfaces\manage\Queue();
				var_dump($queue->sendMail('any_template_info', $email, $content, 6));
			}
		}
	}

	public function confirmaction(){
		
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
                        $sdk = new \ApiSdk();
			$tempData = array('domain' => "ed.cn", 'templateId' => "ename_n81uksbml2", 
				'registrarID' => 9);
			$apiInfo = $sdk->execSdkFun(5011, $tempData);
			print_R($apiInfo);
		
		die;
		$queueArray[] = array('domain' =>"naxian.cc", 'dnsType' => 0,"registrarId"=>61,"domainId"=>5705300,"DNS"=>array("dns1.iidns.com","dns2.iidns.com","dns3.iidns.com","dns4.iidns.com","dns5.iidns.com","dns6.iidns.com"));
		$queueData = array('Function' => 'modify_domain_dns', 'Priority' => 5, 'EnameId' => 658319,'Data' => $queueArray);
		$logic = new \logic\manage\newqueue\QueueLogic();
		$return = $logic->addQueueTask($queueData);
		
		die;
		$fileName = "/tmp/order.txt";
		$file = fopen($fileName, "r");
		if(!$file)
		{
			exit("打开文件失败");
		}
		$orderLib = new \interfaces\manage\Finance();
		while(!feof($file))
		{
			$line = trim(trim(fgets($file)), ',');
			$temp = explode(',', $line);
			if(isset($temp[0])&&isset($temp[1]))
			{
				$confirm=array('orderId' => trim($temp[0]), 'enameId' => trim($temp[1]));
				$st = $orderLib->confirmOrder((object) $confirm);
				var_dump($st);echo "\r\n";
			}
			else
			{
				echo '无：' . $temp[0].'/r/n';;
			}
		}
		echo 'ok';

	}


	public function checkImgIsExistsAction()
	{
		$mod = new ModBase("update e_domain_persist set enameid=");	

		die;die;
		$mod = new ModBase("finance");
		$mod->update("update e_finance_orders set RegistarId=61 where orderid in(31478711,31256547,31556765,31223353,31223353,31226538,31223351,31223352,31227198,31385635,31516011)","",array());
		$mod->update("update e_finance_general2016 set RegistrarId=61 where orderid in(31478711,31256547,31556765,31223353,31223353,31226538,31223351,31223352,31227198,31385635,31516011)","",array());
		$mod->update("update e_finance_out2016 set registarid=61 where orderid in(31478711,31256547,31556765,31223353,31223353,31226538,31223351,31223352,31227198,31385635,31516011) and enameid in(437934,521829,318533,157097,157097,399208,157097,87609,985132,483875) limit 11","",array());
		//e_finance_general2016
		die;
		die;
		$mod = new ModBase("domain");
		$mod->update("update e_domains set autorenew=0 where RegistrarId=61 and domainltd in(3,4,11,16,17) and autorenew=1","",array());
		die;
		die;
	//	include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
	//	$sdk = new \ApiSdk();
	//	$data= array('domain' => "mlx.cc", 'password' =>"5G3G77-8SGGkr-u2b-m-", 'period' => 1);
//		$sdkReturn = $sdk->execSdkFun(5005,$data);
//		print_r($sdkReturn);
//		die;
//di//e;
		$sql="select * from e_domain_transfer_in where TransferStatus=7 and RegistrarId!=21 and createtime>='2017-01-03'";
		$mod = new ModBase("domain");
		$list=$mod->select($sql,"",array());
		if(!$list){
			exit("not data");
		}
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();

		$finance = new ModBase("finance");
		foreach($list as $info){
			$enameId=$info["EnameId"];
			$domain=$info["DomainName"];
			$orderId=$info["OrderId"];
			$orderInfo = $finance->getRow("select * from e_finance_orders where OrderId=$orderId","",array());
			if(!$orderInfo)
			{
				echo $domain.",".$orderId.",not found orderinfo\r\n";continue;
			}
			if($orderInfo['OrderType']!=2 && $orderInfo['OrderType']!=3){
				continue;
			}
			if($orderInfo['Price']>1)
			{
				//echo $domain.",".$orderId.",record error found\r\n";
				continue;
			}
			if(stripos($domain,".com")!==false)
			{
				echo $domain.",is com\r\n";
				continue;
			}
			if($orderInfo["OrderStatus"]==3){
				echo $domain.",".$orderId.",orderstatus error\r\n";
				$flib = new \interfaces\manage\Finance();
				$cancel = $cancel=$flib->cancelOrder((object)array('enameId'=>$enameId,'orderId'=>$orderId));
				echo $domain.",cancel,orderid,".($cancel ? 'success' :'failed');
			}
			continue;
			continue;
			$sdkReturn = $sdk->execSdkFun(5029,array("domain"=>$domain));
			if($sdkReturn['resultCode']==5000){
				$st = $mod->update("update e_domain_transfer_in set TransferStatus=7 where TransferInId='{$info['TransferInId']}' and DomainName='{$domain}'","",array());
				if(!$st){
					echo $domain.",refuse success,but update db error\r\n";
					error_log($domain.",refuse success but update db error\r\n",3,"/tmp/transfererrorlist.log");
					$flib = new \interfaces\manage\Finance();
					$cancel = $cancel=$flib->cancelOrder((object)array('enameId'=>$enameId,'orderId'=>$orderId));
					echo $domain.",cancel,orderid,".($cancel ? 'success' :'failed');
					error_log($domain.",cancel,orderid,".($cancel ? 'success' :'failed')."\r\n",3,"/tmp/transfererrorlist.log");
					echo "\r\n";
				}
			}else{
				echo $domain.",not 5000";
				echo "\r\n";
				print_r($sdkReturn);
			}
		}
		die;
			die;
		$fileName="/tmp/checkimg_12";
		//ename_8ls3gzyyzw,verifyPic/org/2009-12/189547_1107.jpg
		$contents = file_get_contents($fileName) or die("error read file");
		$contentArr = explode("\n",$contents);
		foreach($contentArr as $info)
		{
			$regid = explode(",", $info)[0];
			echo $regid;
			$url = explode(",", $info)[1];
			$fileArr = explode('/', $url);
			$file = end($fileArr);
			$path = str_replace($file, '', $url);
			$im = @file_get_contents(\common\ImgServer::getImgUrl($url));
			if (false == $im || trim($im) === 'the file does not exits')
			{
				echo ",not found image\r\n";
				continue;
			}else{
				echo ",exists\r\n";	
			}	
			sleep(1);
		}
	}

	function reparerenewAction()
	{
		$finMod = new ModBase("finance");
		$finList = $finMod->select("select CreateTime,Domain,OrderId,EnameId from e_finance_orders where ordertype=3 and orderstatus=3 and RegistarId!=11","",array());
		if(!$finList)
		{
			exit("empty data");
		}
		$dnMod = new ModBase("domain");
		$financeLib = new \interfaces\manage\Finance();
		foreach($finList as $info)
		{
			$domain = $info['Domain'];
			$enameId = $info['EnameId'];
			$orderId = $info["OrderId"];
			$createtime=$info["CreateTime"];
			$sql="select * from e_domain_transfer_app where Status=1 and Domain='$domain' and OrderId='$orderId' and operator='$enameId'";
			$app = $dnMod->getRow($sql, "", array());
			if($app)
			{
				echo $domain.",".$app['NewExpDate'].",".$app["OperateTime"];
				if($app["NewExpDate"]>$app['OldExpDate'])
				{
					$status = $financeLib->confirmOrder((object)array('enameId'=>$enameId,'orderId'=>$orderId));
					echo $status ? ",confirm succss" : ",confir failed";
				}
				echo "\r\n";continue;
			}
			else
			{
				//2minutes
				$start=date('Y-m-d H:i:s',strtotime($createtime)-60);
				$end=date('Y-m-d H:i:s',strtotime($createtime)+60);
				$sql="select * from e_domain_service2017 where Domain='$domain' and ServiceType=5 and OperationTime>='$start' and OperationTime<='$end' and Content like '%auto_renew%'";
				$sql.=" and Content not like '%msg%'";
				$ex = $dnMod->getRow($sql, "", array());
				if($ex)
				{
					$t2=$ex['OperationTime'];
					$sql2 = "select * from e_domain_service2017 where Domain='$domain' and ServiceType=5 and OperationTime>'$t2' and Content like '%auto_renew%'";
					$sql2.=" and Content not like '%msg%'";	
					if(!$dnMod->getRow($sql2, "", array()))
					{
						echo $domain.",exists";
						$status = $financeLib->confirmOrder((object)array('enameId'=>$enameId,'orderId'=>$orderId));
						echo $status ? ",confirm succss" : ",confir failed";
						echo "\r\n";
					}
					else{
						echo $domain.",not sure,exists\r\n";
					}
				}else{
					echo $domain.",not exists\r\n";
				}
			}
		}

	}

	public function  checkwhitebutnotrealaction()
	{
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		$mod = new ModBase("domain");
		$sql="select DomainName,d.RegistrarId,d.TemplateId,t.TemplateName from e_domains as d,e_template_zh as t where t.templateid not in(413119,428291,626357,626395,697807,741759,794493) and DomainLtd in(3,4,9,10) and IsRealName=3 and d.TemplateId=t.TemplateId and t.CnStatus=2 and d.DomainMyStatus not in(11,12,13,5) and t.templateid!=34095 and d.enameid!=1041792;";
		$tempfile="/tmp/checkwhitebutnotrealaction";
		$list = $mod->select($sql, "", array());
		if($list)
		{
			$num=0;
			foreach($list as $info)
			{
				$domain=$info['DomainName'];
				$templateId = $info['TemplateId'];
				$tempname = $info['TemplateName'];
				$regid = $info['RegistrarId'];
				//过户成功不代表一定可以去掉missing
				$eppLogic = new \logic\manage\thrift\EppLogic();
				$eppupdate = $eppLogic->domainEppChangeRegistrant(array('templateName'=>$tempname,'domain'=>$domain,'registrarID'=>$regid));
				echo $num.",";
				$num++;
				if($eppupdate['resultCode'] ==5000)
				{
					$sdkInfo = $sdk->execSdkFun(5025, array('domain' => $domain, 'registrarID' => $regid));
					if($sdkInfo['resultCode'] != 5000)
					{
						echo $domain.",templatepushsuccess but 5025 error\r\n";
						continue;
					}
					$missInfo = $sdkInfo['data']["extension"]["verificationCode"]["profile"]["missing"];
					if($missInfo)
					{
						if((count($missInfo) == 1 && $missInfo[0]['type'] == 'domain'))
						{
							echo $domain.",domainreal is miss\r\n";//先看下多少数据
						}
						elseif(count($missInfo) == 2)
						{
							echo $domain.",allreal is miss all\r\n";
						}
						else if(count($missInfo) == 1 && $missInfo[0]['type'] == 'real-name')
						{
							echo $domain.",allreal is miss real-name\r\n";
						}
					}
					else
					{
						echo $domain.",all white\r\n";//这部分数据可能是用户自己进行了过户 直接改表就好
						$this->updatevspdomain($domain, 1);//全白了
					}
				}
				else
				{
					echo json_encode($eppupdate).",";
					echo 	$domain.",templatepush error\r\n";				
				}
			}
		}
	}

	private function updatevspdomain($domain, $realname)
	{
		$domainLib = new \lib\manage\domain\DomainManageLib();
		$upInfo = $domainLib->setDomainInfo(array('DomainName' => $domain), array('IsRealName' => $realname));
		if(! $upInfo)
		{
			\core\Log::write("top,realstatus:{$realname},update error," . $domain, 'cronmanage/domain', 
				'checktopisreal');
		}
		else
		{
			\core\Log::write("top,realstatus:{$realname},update success," . $domain, 'cronmanage/domain', 
				'checktopisreal');
		}
	}

	public function uptransfererroraction(){
		$sql="update e_domain_transfer_in set registrarid=81,domainltd=11,dnsstatus=2 where registrarid=0 and enameid=667792 and transferstatus<=6 and DomainName like '%.cc%' limit 83;";
		echo $sql;
		$mod = new ModBase('domain');
		var_dump($mod->update($sql,"",array()));
	}


	public function  checkwhitebutnotreal2action()
	{
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		$mod = new ModBase("domain");
		$sql="select DomainName,d.RegistrarId,d.TemplateId,t.TemplateName from e_domains as d,e_template_zh as t where DomainLtd in(3,4,9,10) and IsRealName=3 and d.TemplateId=t.TemplateId and t.CnStatus=2 and d.DomainMyStatus not in(11,12,13,5) limit 5000,10000;";
		$tempfile="/tmp/checkwhitebutnotrealaction";
		$list = $mod->select($sql, "", array());
		if($list)
		{
			$num=0;
			foreach($list as $info)
			{
				$domain=$info['DomainName'];
				$templateId = $info['TemplateId'];
				$tempname = $info['TemplateName'];
				$regid = $info['RegistrarId'];
				//过户成功不代表一定可以去掉missing
				$eppLogic = new \logic\manage\thrift\EppLogic();
				$eppupdate = $eppLogic->domainEppChangeRegistrant(array('templateName'=>$tempname,'domain'=>$domain,'registrarID'=>$regid));
				echo $num.",";
				$num++;
				if($eppupdate['resultCode'] ==5000)
				{
					$sdkInfo = $sdk->execSdkFun(5025, array('domain' => $domain, 'registrarID' => $regid));
					if($sdkInfo['resultCode'] != 5000)
					{
						echo $domain.",templatepushsuccess but 5025 error\r\n";
						continue;
					}
					$missInfo = $sdkInfo['data']["extension"]["verificationCode"]["profile"]["missing"];
					if($missInfo)
					{
						if((count($missInfo) == 1 && $missInfo[0]['type'] == 'domain'))
						{
							echo $domain.",domainreal is miss\r\n";//先看下多少数据
						}
						elseif(count($missInfo) == 2)
						{
							echo $domain.",allreal is miss all\r\n";
						}
						else if(count($missInfo) == 1 && $missInfo[0]['type'] == 'real-name')
						{
							echo $domain.",allreal is miss real-name\r\n";
						}
					}
					else
					{
						echo $domain.",all white\r\n";//这部分数据可能是用户自己进行了过户 直接改表就好
						$this->updatevspdomain($domain, 1);//全白了
					}
				}
				else
				{
					echo 	$domain.",templatepush error\r\n";				
				}
			}
		}
	}

	public function  checkwhitebutnotrealnew3action()
	{
		ini_set('display_errors','on');
		error_reporting(E_ALL);
		$filename="/tmp/oldis1butnowisnotlist_3.log";
		$file = fopen($filename, "r");
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		$mod = new ModBase("domain");
		$tempfile="/tmp/oldis1butnowisnotlist1.log";
		while(!feof($file)){
			$domain = trim(fgets($file));	
			$time=time();
			$end=strtotime('2017-02-11 01:59:00');
			if($time>$end) {
				echo $domain;exit("time end");
			}
			$sql="select DomainMyStatus,DomainName,d.RegistrarId,d.TemplateId,t.TemplateName,CnStatus from e_domains as d,e_template_zh as t where DomainName='$domain' and d.TemplateId=t.TemplateId";
			$info = $mod->getRow($sql, "", array());
			if(!$info){
				echo $domain.",not foundindb\r\n";continue;
			}
			if($info)
			{
				$domain=$info['DomainName'];
				$templateId = $info['TemplateId'];
				$tempname = $info['TemplateName'];
				$regid = $info['RegistrarId'];
				$cnstatus=$info['CnStatus'];
				$domainstatus=$info['DomainMyStatus'];
				if($cnstatus!=2){
					echo $domain.",cnstatus!=2\r\n";
					continue;
				}
				if(in_array($domainstatus,array(11,12,13,5))){
					echo $domain.",status is error\r\n";continue;
				}
					//过户成功不代表一定可以去掉missing
				$eppLogic = new \logic\manage\thrift\EppLogic();
				$eppupdate = $eppLogic->domainEppChangeRegistrant(array('templateName'=>$tempname,'domain'=>$domain,'registrarID'=>$regid));
				if($eppupdate['resultCode'] ==5000)
				{
					$sdkInfo = $sdk->execSdkFun(5025, array('domain' => $domain, 'registrarID' => $regid));
					if($sdkInfo['resultCode'] != 5000)
					{
						echo $domain.",templatepushsuccess but 5025 error\r\n";
						continue;
					}
					$missInfo = $sdkInfo['data']["extension"]["verificationCode"]["profile"]["missing"];
					if($missInfo)
					{
						if((count($missInfo) == 1 && $missInfo[0]['type'] == 'domain'))
						{
							echo $domain.",domainreal is miss\r\n";//先看下多少数据
						}
						elseif(count($missInfo) == 2)
						{
							echo $domain.",allreal is miss all\r\n";
						}
						else if(count($missInfo) == 1 && $missInfo[0]['type'] == 'real-name')
						{
							echo $domain.",allreal is miss real-name\r\n";
						}
					}
					else
					{
						echo $domain.",all white\r\n";//这部分数据可能是用户自己进行了过户 直接改表就好
						$this->updatevspdomain($domain, 1);//全白了
					}
				}
				else
				{
					echo 	$domain.",first 5025 error\r\n";				
				}
			}
		}
	}

	public function  checkwhitebutnotrealnew2action()
	{
		ini_set('display_errors','on');
		error_reporting(E_ALL);
		$filename="/tmp/oldis1butnowisnotlist_2.log";
		$file = fopen($filename, "r");
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		$mod = new ModBase("domain");
		$tempfile="/tmp/oldis1butnowisnotlist1.log";
		while(!feof($file)){
			$domain = trim(fgets($file));	
			$time=time();
           	$end=strtotime('2017-02-11 01:59:00');
            if($time>$end) {
            	echo $domain;exit("time end");
            }
			$sql="select DomainMyStatus,DomainName,d.RegistrarId,d.TemplateId,t.TemplateName,CnStatus from e_domains as d,e_template_zh as t where DomainName='$domain' and d.TemplateId=t.TemplateId";
			$info = $mod->getRow($sql, "", array());
			if(!$info){
				echo $domain.",not foundindb\r\n";continue;
			}
			if($info)
			{
				$domain=$info['DomainName'];
				$templateId = $info['TemplateId'];
				$tempname = $info['TemplateName'];
				$regid = $info['RegistrarId'];
				$cnstatus=$info['CnStatus'];
				$domainstatus=$info['DomainMyStatus'];
				if($cnstatus!=2){
					echo $domain.",cnstatus!=2\r\n";
					continue;
				}
				if(in_array($domainstatus,array(11,12,13,5))){
					echo $domain.",status is error\r\n";continue;
				}
					//过户成功不代表一定可以去掉missing
				$eppLogic = new \logic\manage\thrift\EppLogic();
				$eppupdate = $eppLogic->domainEppChangeRegistrant(array('templateName'=>$tempname,'domain'=>$domain,'registrarID'=>$regid));
				if($eppupdate['resultCode'] ==5000)
				{
					$sdkInfo = $sdk->execSdkFun(5025, array('domain' => $domain, 'registrarID' => $regid));
					if($sdkInfo['resultCode'] != 5000)
					{
						echo $domain.",templatepushsuccess but 5025 error\r\n";
						continue;
					}
					$missInfo = $sdkInfo['data']["extension"]["verificationCode"]["profile"]["missing"];
					if($missInfo)
					{
						if((count($missInfo) == 1 && $missInfo[0]['type'] == 'domain'))
						{
							echo $domain.",domainreal is miss\r\n";//先看下多少数据
						}
						elseif(count($missInfo) == 2)
						{
							echo $domain.",allreal is miss all\r\n";
						}
						else if(count($missInfo) == 1 && $missInfo[0]['type'] == 'real-name')
						{
							echo $domain.",allreal is miss real-name\r\n";
						}
					}
					else
					{
						echo $domain.",all white\r\n";//这部分数据可能是用户自己进行了过户 直接改表就好
						$this->updatevspdomain($domain, 1);//全白了
					}
				}
				else
				{
					echo 	$domain.",first 5025 error\r\n";				
				}
			}
		}
	}

	public function  checkwhitebutnotrealnewaction()
	{
		ini_set('display_errors','on');
		error_reporting(E_ALL);
		$filename="/tmp/oldis1butnowisnotlist_1.log";
		$file = fopen($filename, "r");
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		$mod = new ModBase("domain");
		$tempfile="/tmp/oldis1butnowisnotlist1.log";
		while(!feof($file)){
			$domain = trim(fgets($file));	
			$time=time();
			$end=strtotime('2017-02-11 01:59:00');
			if($time>$end)
			{
				echo $domain;exit("time end");
			}
			$sql="select DomainMyStatus,DomainName,d.RegistrarId,d.TemplateId,t.TemplateName,CnStatus from e_domains as d,e_template_zh as t where DomainName='$domain' and d.TemplateId=t.TemplateId";
			$info = $mod->getRow($sql, "", array());
			if(!$info){
				echo $domain.",not foundindb\r\n";continue;
			}
			if($info)
			{
				$domain=$info['DomainName'];
				$templateId = $info['TemplateId'];
				$tempname = $info['TemplateName'];
				$regid = $info['RegistrarId'];
				$cnstatus=$info['CnStatus'];
				$domainstatus=$info['DomainMyStatus'];
				if($cnstatus!=2){
					echo $domain.",cnstatus!=2\r\n";
					continue;
				}
				if(in_array($domainstatus,array(11,12,13,5)))
				{
					echo $domain.",status is error\r\n";
					continue;
				}
					//过户成功不代表一定可以去掉missing
				$eppLogic = new \logic\manage\thrift\EppLogic();
				$eppupdate = $eppLogic->domainEppChangeRegistrant(array('templateName'=>$tempname,'domain'=>$domain,'registrarID'=>$regid));
				if($eppupdate['resultCode'] ==5000)
				{
					$sdkInfo = $sdk->execSdkFun(5025, array('domain' => $domain, 'registrarID' => $regid));
					if($sdkInfo['resultCode'] != 5000)
					{
						echo $domain.",templatepushsuccess but 5025 error\r\n";
						continue;
					}
					$missInfo = $sdkInfo['data']["extension"]["verificationCode"]["profile"]["missing"];
					if($missInfo)
					{
						if((count($missInfo) == 1 && $missInfo[0]['type'] == 'domain'))
						{
							echo $domain.",domainreal is miss\r\n";//先看下多少数据
						}
						elseif(count($missInfo) == 2)
						{
							echo $domain.",allreal is miss all\r\n";
						}
						else if(count($missInfo) == 1 && $missInfo[0]['type'] == 'real-name')
						{
							echo $domain.",allreal is miss real-name\r\n";
						}
					}
					else
					{
						echo $domain.",all white\r\n";//这部分数据可能是用户自己进行了过户 直接改表就好
						$this->updatevspdomain($domain, 1);//全白了
					}
				}
				else
				{
					echo 	$domain.",first 5025 error\r\n";				
				}
			}
		}
	}

	private function upddatevspdomain($domain, $realname)
	{
		$domainLib = new \lib\manage\domain\DomainManageLib();
		$upInfo = $domainLib->setDomainInfo(array('DomainName' => $domain), array('IsRealName' => $realname));
		if(! $upInfo)
		{
			\core\Log::write("top,realstatus:{$realname},update error," . $domain, 'cronmanage/domain', 
				'checktopisreal');
		}
		else
		{
			\core\Log::write("top,realstatus:{$realname},update success," . $domain, 'cronmanage/domain', 
				'checktopisreal');
		}
	}

	public function uptransfererroracton(){
		$sql="update e_domain_transfer_in set registrarid=81,domainltd=11,dnsstatus=2 where registrarid=0 and enameid=667792 and transferstatus<=6 and DomainName like '%.cc%' limit 83;";
		echo $sql;
		$mod = new ModBase('domain');
		var_dump($mod->update($sql,"",array()));
	}


	public function  checkwhitebutnotreal3action()
	{
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		$mod = new ModBase("domain");
		$sql="select DomainName,d.RegistrarId,d.TemplateId,t.TemplateName from e_domains as d,e_template_zh as t where DomainLtd in(3,4,9,10) and IsRealName=3 and d.TemplateId=t.TemplateId and t.CnStatus=2 and d.DomainMyStatus not in(11,12,13,5) limit 20000,10000;";
		$tempfile="/tmp/checkwhitebutnotrealaction";
		$list = $mod->select($sql, "", array());
		if($list)
		{
			$num=0;
			foreach($list as $info)
			{
				$domain=$info['DomainName'];
				$templateId = $info['TemplateId'];
				$tempname = $info['TemplateName'];
				$regid = $info['RegistrarId'];
				//过户成功不代表一定可以去掉missing
				$eppLogic = new \logic\manage\thrift\EppLogic();
				$eppupdate = $eppLogic->domainEppChangeRegistrant(array('templateName'=>$tempname,'domain'=>$domain,'registrarID'=>$regid));
				echo $num.",";
				$num++;
				if($eppupdate['resultCode'] ==5000)
				{
					$sdkInfo = $sdk->execSdkFun(5025, array('domain' => $domain, 'registrarID' => $regid));
					if($sdkInfo['resultCode'] != 5000)
					{
						echo $domain.",templatepushsuccess but 5025 error\r\n";
						continue;
					}
					$missInfo = $sdkInfo['data']["extension"]["verificationCode"]["profile"]["missing"];
					if($missInfo)
					{
						if((count($missInfo) == 1 && $missInfo[0]['type'] == 'domain'))
						{
							echo $domain.",domainreal is miss\r\n";//先看下多少数据
						}
						elseif(count($missInfo) == 2)
						{
							echo $domain.",allreal is miss all\r\n";
						}
						else if(count($missInfo) == 1 && $missInfo[0]['type'] == 'real-name')
						{
							echo $domain.",allreal is miss real-name\r\n";
						}
					}
					else
					{
						echo $domain.",all white\r\n";//这部分数据可能是用户自己进行了过户 直接改表就好
						$this->updatevspdomain($domain, 1);//全白了
					}
				}
				else
				{
					echo 	$domain.",templatepush error\r\n";				
				}
			}
		}
	}

	public function verignRealNameAction()
	{
		$file = fopen("/tmp/not_real_name_verign.log", "r");
		if(! $file)
		{
			exit("打开文件失败");
		}
		$dnMod = new ModBase("domain");
		while(! feof($file))
		{
			$domain = trim(fgets($file));
			if(! $domain)
			{
				continue;
			}
			$dnInfo = $dnMod->getRow("select EnameId,DomainName,TemplateId,IsRealName from e_domains where DomainName='{$domain}'", "", array());
			if($dnInfo)
			{
				echo $domain.",realstatus:".$dnInfo['IsRealName']."\r\n";
			}
			else
			{
				echo $domain.",not in db,buguanle\r\n";
			}
		}
	}

	public function verignRealName2Action()
	{
		$file = fopen("/tmp/verign_realstatus_3.log", "r");
		if(! $file)
		{
			exit("打开文件失败");
		}
		$dnMod = new ModBase("domain");
		while(! feof($file))
		{
			$domain = trim(fgets($file));
			if(! $domain)
			{
				continue;
			}
			$domain=strtolower(explode(",",$domain)[0]);
			$dnInfo = $dnMod->getRow("select EnameId,DomainName,TemplateId,IsRealName from e_domains where DomainName='{$domain}'", "", array());
			if($dnInfo)
			{
				if($dnInfo['IsRealName']!=3)
				{
					echo $domain.",not status:3,{$dnInfo['IsRealName']}\r\n";
					continue;
				}
				$templateInfo = $dnMod->getRow("select CnStatus,EnameId FROM e_template_zh where TemplateId='{$dnInfo['TemplateId']}' ", "", array());
				if($templateInfo)
				{
					if($templateInfo['CnStatus']!=2)
					{
						echo $domain.",{$dnInfo['EnameId']},template status not white,{$dnInfo['TemplateId']},{$templateInfo['CnStatus']}\r\n";
						continue;
					}
					else
					{
						echo $domain.",{$dnInfo['EnameId']},template status is white,{$dnInfo['TemplateId']}\r\n";
						continue;
					}
				}
				else
				{
					echo $domain.",not found templateinfo,{$dnInfo['TemplateId']}\r\n";
					continue;
				}
			}
			else
			{
				echo $domain.",not in db,buguanle\r\n";
			}
		}
	}	

	public function bayuengaction()
	{
		$content = file_get_contents("/tmp/bayuefenng") or die("not found");
		$contentArr = explode("\n",$content);
		$dnmod = new ModBase('domain');
		$verifyMod = new ModBase('verify');
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		foreach($contentArr as $info)
		{
			$regid = trim($info);
			$templateInfo = $dnmod->getRow("select CnStatus,TemplateType,Name,EnameId,Org from e_template_zh where TemplateName='$regid'",'',array());
			if($templateInfo)//先只处理白名单的就好 非白名单不管了
			{
				$name = $templateInfo['Name'];
				$org = $templateInfo['Org'];
				$enameId = $templateInfo['EnameId'];
				$templateType = $templateInfo['TemplateType'];
				if($templateType == 1 )//org
				{
					$verifyInfo = $verifyMod->getRow("select * from e_verify_company where companyName='$org' and VerifyStatus=2 and EnameId='$enameId'","",array());
					if($verifyInfo)
					{
						$uploadData = array('registrantId' =>$regid, 'img' => array("verifyPic/org/".$verifyInfo['LicenseImg']));
						$uploadInfo = $sdk->execSdkFun(6991, $uploadData);
						if($uploadInfo['resultCode']!=6000){
							$imagecontent = file_get_contents("http://192.168.20.134:12346/"."verifyPic/org/".$verifyInfo['LicenseImg']);
							$imagecontent=strip_tags($imagecontent);
							if(stripos(trim($imagecontent),"404 Not Found")!==false || stripos(trim($imagecontent),"the file does not exits")!==false)
							{
								echo 	$regid.",not found image\r\n";
								continue;
							}
							echo $regid.",uperror\r\n";
						
						}else{
							echo $regid.",success\r\n";
						}
					}
					else{
						echo $regid.", not found verify\r\n";
					}
				}
				elseif($templateType == 4)
				{
					echo $regid.", geren buguan\r\n";
				}
			}
			else{
				echo $regid.",".($templateInfo ? 'exit but not white' : 'not exist');
				echo "\r\n";
			}
		}
	}

	public function dodoaction(){
		$domain="399yi.com";
		$epplogic = new \logic\manage\thrift\EppLogic();
		$addreturn = $epplogic->domainEppChangeRegistrantTemp(array('domain' => $domain,'registrarID'=>21));
		var_dump($addreturn);
		die;
		$content = file_get_contents("/tmp/baoliu.csv");
		$contentarr = explode("\n",$content);
		$dn = new ModBase("domain");
		foreach($contentarr as $domain)
		{
			$domain = trim($domain);if(!$domain) continue;
			$sql="select count(1) from e_domain_persist where Domain='$domain' and Status=1";
			$info = $dn->getRow($sql,"",array());
			if($info){
				echo $domain.",in persist\r\n";
			}else{
				echo $domain.",not not\r\n";
			}
		}
		
	}
}


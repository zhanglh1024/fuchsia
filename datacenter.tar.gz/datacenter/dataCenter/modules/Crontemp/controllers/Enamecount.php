<?php
use core\ModBase;

/**
 * 统计域名
 */
class EnamecountController extends yaf\Controller_Abstract
{

	private $domainMod;

	private $financeMod;

	private $transMod;

	private $limit;

	public function init()
	{
		// 域名
		$this->domainMod = new ModBase('domain');
		// 财务
		$this->financeMod = new ModBase('finance');
		// 交易
		$this->transMod = new ModBase('trans');
		
		$this->limit = 5000;
	}

	/**
	 * 统计域名10年的注册、交易、转入、push的数量
	 */
	public function domainCountAction()
	{
		echo "-----begin-----\n";
		self::getTransferCount();
		self::getPushCount();
		self::getRegisterCount();
		self::getTransCount();
		echo "-----end-----\n";
	}

	/**
	 * 转入统计
	 */
	private function getTransferCount()
	{
		$sql = 'select count(*) as count from e_domain_transfer_in where TransferStatus in(8,9)';
		$rs = $this->domainMod->getOne($sql, array(), array());
		for($i = 0; $i < ceil($rs / $this->limit); $i ++)
		{
			$sql = "select DomainName from e_domain_transfer_in where TransferStatus in(8,9) limit " . $this->limit * $i .
				 ',' . $this->limit;
			echo $sql . "\n";
			$result = $this->domainMod->select($sql, array(), array());
			foreach($result as $value)
			{
				$this->writeLog($value['DomainName'], 'crontemp/EnameCount', 'transferIn');
			}
			unset($result);
		}
	}

	/**
	 * push统计
	 */
	private function getPushCount()
	{
		$sql = 'select count(*) as count from e_domain_push where ReceiveStatus = 1 and SendStatus = 0';
		$rs = $this->domainMod->getOne($sql, array(), array());
		for($i = 0; $i < ceil($rs / $this->limit); $i ++)
		{
			$sql = "select DomainName from e_domain_push where ReceiveStatus = 1 and SendStatus = 0 limit " .
				 $this->limit * $i . ',' . $this->limit;
			echo $sql . "\n";
			$result = $this->domainMod->select($sql, array(), array());
			foreach($result as $value)
			{
				$domainArr = explode("\n", trim($value['DomainName']));
				foreach($domainArr as $v)
				{
					$this->writeLog($v, 'crontemp/EnameCount', 'push');
				}
				unset($domainArr);
			}
			unset($result);
		}
	}

	/**
	 * 注册统计
	 */
	private function getRegisterCount()
	{
		$tableArr = array('e_finance_out', 'e_finance_out_history2012', 'e_finance_out_history2013', 
				'e_finance_out_history2014');
		foreach($tableArr as $tableName)
		{
			$sql = "select count(*) as count from {$tableName} where OutType = 1";
			$rs = $this->financeMod->getOne($sql, array(), array());
			for($i = 0; $i < ceil($rs / $this->limit); $i ++)
			{
				$sql = "select LinkDomain  from {$tableName} where OutType = 1 limit " . $this->limit * $i . ',' .
					 $this->limit;
				echo $sql . "\n";
				$result = $this->financeMod->select($sql, array(), array());
				foreach($result as $value)
				{
					$this->writeLog($value['LinkDomain'], 'crontemp/EnameCount', 'register');
				}
				unset($result);
			}
		}
		// 12年前的数据进行统计
		$tableArr = array('e_finance_out_history2011', 'e_finance_out_history2010', 'e_finance_out_history2009', 
				'e_finance_out_history2008', 'e_finance_out_history2007', 'e_finance_out_history2006', 
				'e_finance_out_history2005');
		foreach($tableArr as $tableName)
		{
			$sql = "select count(*) as count from {$tableName}";
			$rs = $this->financeMod->getOne($sql, array(), array());
			for($i = 0; $i < ceil($rs / $this->limit); $i ++)
			{
				$sql = "select outRemark  from {$tableName} limit " . $this->limit * $i . ',' . $this->limit;
				echo $sql . "\n";
				$result = $this->financeMod->select($sql, array(), array());
				foreach($result as $value)
				{
					if(false !== strpos($value['outRemark'], '注册'))
					{
						preg_match('/域名[\[:]?([\x{4e00}-\x{9fa5}\w\.-]+)[\]，注册]?/ui',$value['outRemark'],$domain);
						if(empty($domain[1]))
						{
							$this->writeLog($value['outRemark'], 'crontemp/EnameCount', 'registerError');
							continue;
						}
						$this->writeLog($domain[1], 'crontemp/EnameCount', 'register');
					}
				}
				unset($result);
			}
		}
	}

	/**
	 * 交易统计
	 */
	private function getTransCount()
	{
		$tableArr = array('trans_delivery');
		foreach($tableArr as $tableName)
		{
			$sql = "select count(*) as count from {$tableName} where deliverystatus  = 8";
			$rs = $this->transMod->getOne($sql, array(), array());
			for($i = 0; $i < ceil($rs / $this->limit); $i ++)
			{
				$sql = "select DomainName from {$tableName} where deliverystatus = 8 limit " . $this->limit * $i . ',' .
					 $this->limit;
				echo $sql . "\n";
				$result = $this->transMod->select($sql, array(), array());
				foreach($result as $value)
				{
					$this->writeLog($value['DomainName'], 'crontemp/EnameCount', 'trans');
				}
				unset($result);
			}
		}
	}

	/**
	 * 记录文件
	 *
	 * @param unknown $msg
	 * @param string $folder
	 * @param string $prefix
	 */
	private function writeLog($data, $folder = '', $prefix = false)
	{
		$config = \Yaf\Registry::get("config");
		$path = $config->application->logPath;
		unset($config);
		if($folder)
		{
			$path = $path . '/' . $folder;
			if(! file_exists($path))
			{
				@mkdir($path, 0777, TRUE);
			}
		}
		$nowDate = new \DateTime('NOW');
		$fileName = (FALSE == $prefix ? '' : $prefix) . $nowDate->format("Y-m-d") . '.log';
		file_put_contents($path . '/' . $fileName, $data . "\n", FILE_APPEND);
	}
}
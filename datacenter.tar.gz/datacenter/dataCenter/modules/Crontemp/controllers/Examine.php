<?php
use lib\manage\queue\MailLib;

use core\ModBase;

class ExamineController extends Yaf\Controller_Abstract
{
	public function getTempInfoAction()
	{
		/**
		 * 根据域名跑出对应的模板信息和模板联系人身份认证资料和图片
		 */
		$path = "/var/www/files/domain.txt";
		$savePath = "/var/www/files/temp_info.csv";
		$savePicDir = "/var/www/files/";
		$handle = fopen($path, 'r+');
		if(!$handle)
		{
			exit("打开文件失败");
		}
		$domain = array();
		while(!feof($handle))
		{ 
			$line = trim(fgets($handle),"\r\n");
			$line = trim($line);
			if(!empty($line))
			$domain[] = $line;
		}
		//$domain = array('yanfu.com','jiesuanwancheng.org','788.biz');
		$dnMod = new ModBase('domain');
		$verifyMod = new ModBase('verify');
		//获取域名ID
		$info = array();
		foreach ($domain as $k => $v)
		{
			$query = "select TemplateId,EnameId,PrivacyTemp from e_domains where DomainName='".$v."'";
			$tempId = $dnMod->getRow($query, '', array());
			if(empty($tempId))
			{
				\core\Log::write('获取域名模板ID失败【'.$v.'】', 'crontemp/examine', 'gettempinfo');
				continue;
			}
			$info[$k]['domain'] = $v;
			$info[$k]['tempId'] = empty($tempId['PrivacyTemp']) ? $tempId['TemplateId'] : $tempId['PrivacyTemp'];
			$info[$k]['enameId'] = $tempId['EnameId'];
			$info[$k]['privacy'] = $tempId['PrivacyTemp'];
		}
		//获取模版信息和认证信息
		$templateType = array('0' => '临时','1' => '企业','2' => '英文','3' => '委托','4' => '个人','5' => '腾讯',	'6' => '英文隐私','7' => 'CN隐私','8' => 'sedo模板'); // 模板类型
		error_log("模板接口/cn/公司/org/asia/pw/top/biz\tWEBNIC\t模板类型\t关联域名\t是否显示\t邮箱\t国家缩写-省份-城市\t国际区号-电话-分机号\t国际区号-传真-分机号\t街道\t邮编\t备注\r",3,$savePath);
		foreach ($info as $k => $v)
		{
			$query = "select * from e_template_zh where TemplateId = ".$v['tempId'];
			$tempInfoZh = $dnMod->getRow($query, '', array());
			if(empty($tempInfoZh))
			{
				\core\Log::write('获取中文模板信息失败【'.$v['tempId'].'】', 'crontemp/examine', 'gettempinfo');
				continue;
			}
			$query = "select * from e_template_en where TemplateId = ".$v['tempId'];
			$tempInfoEn = $dnMod->getRow($query, '', array());
			if(empty($tempInfoEn))
			{
				\core\Log::write('获取英文模板信息失败【'.$v['tempId'].'】', 'crontemp/examine', 'gettempinfo');
				continue;
			}
			$regidInternet = array('TOP'=>array('ename.open',86),'BIZ'=>array('ename.biz',82));
			foreach($regidInternet as $key => $values)
			{
				$query = "select * from e_template_ext where TemplateId = ".$v['tempId']." and EnameId = ".$v['enameId']." and Registrar = ".$values[1];
				$tempInfoExt = $dnMod->getRow($query, '', array());
				$tempInfoEn[$key] = $tempInfoExt && !empty($tempInfoExt['Registrar']) ? $tempInfoExt['Registrar'] : 0;
			}
			$message = $tempInfoZh['RegistrarId'].'/'.$tempInfoZh['CnIdn'].$tempInfoEn['OrgId'].'/'.$tempInfoEn['AsiaId'].'/'.$tempInfoEn['PwId'].'/'.$tempInfoEn['TOP'].'/'.$tempInfoEn['BIZ']."\t";
			$message .= $tempInfoEn['Webnic']."\t";
			$message .= isset($templateType[$tempInfoZh['TemplateType']]) ? $templateType[$tempInfoZh['TemplateType']] : "";
			$message .= "\t".$tempInfoZh['LinkCount']."\t";
			$message .= $tempInfoZh['IsShow'] ? "是" : "否";
			$message .= "\t".$tempInfoZh['Email']."\t".$tempInfoZh['CountryName']."-".$tempInfoZh['Province']."-".$tempInfoZh['City']."\t".$tempInfoZh['TelCC']."-".$tempInfoZh['Phone']."-".$tempInfoZh['PhoneExt']."\t".$tempInfoZh['FaxCC']."-".$tempInfoZh['Fax']."-".$tempInfoZh['FaxExt']."\t";
			$message .= $tempInfoZh['Street']."\t".$tempInfoZh['PostCode']."\t";
			$message .= $v['privacy'] ? "隐私模板\r" : "\r";
			error_log($message,3,$savePath);
			//获取认证图片信息
			$query = "select * from e_verify_identity where EnameId=".$v['enameId']." and VerifyStatus=2 and IsBound=1";
			$verifyInfo = $verifyMod->getRow($query, '', array());
			if(empty($verifyInfo) || empty($verifyInfo['NewFrontImg']))
			{
				\core\Log::write('获取该用户认证通过的身份绑定图片信息失败【'.$v['enameId'].'】', 'crontemp/examine', 'gettempinfo');
				continue;
			}
			$photo = explode('/',$verifyInfo['NewFrontImg']);
			$fileName="http://managenew.ename.cn/index.php/verify/showPic/?ac=img&imgPath=/opt/ename/verifyPic/sfz/".$photo[0].'/'.$photo[1];
			if(!file_exists($fileName) || !copy($fileName,$savePicDir.$v['domain']."_".$photo[1]))
			{
				\core\Log::write('获取该用户认证通过的身份绑定图片信息失败【'.$v['enameId'].'】', 'crontemp/examine', 'gettempinfo');
			}
		}
	}
	
	private function getVerify($verifyMod,$enameId)
	{
		return $verifyMod->select("select distinct(Name),NewFrontImg from e_verify_identity where EnameId=".$enameId." and VerifyStatus=2", '', array());
	}
	
	private function getTemplate($domainMod,$enameId,$verifyName)
	{
		$tempSql = "select * from e_template_zh where TemplateType in(1,4,2)  and EnameId=$enameId and Name='$verifyName'";
		return $domainMod->select($tempSql, '', array());
	}
	
	private function getDomainList($domainMod,$tempId,$enameId)
	{
		return $domainMod->select("select DomainName from e_domains where TemplateId = $tempId and EnameId = $enameId and DomainLtd in(1,2,3,4,5)",'',array());
	}	
	
	private function shimingMain($verifyMod,$domainMod,$enameId,$ednsLib)
	{
		$isVerify = $this->getVerify($verifyMod, $enameId);
		if(!$isVerify)
		{
			echo $enameId ."not find verify\r\n";
			return FALSE;
		}
		$st = FALSE;
		$temptype = array('1'=>'企业模版','2'=>'国际模版','4'=>'个人模版');
		//认证列表
		foreach($isVerify as $verify)
		{
			$st = FALSE;
			if(empty($verify['NewFrontImg']))
			{
				continue;
			}
			$img = $verify['NewFrontImg'];
			$houzhui = explode(".",$img);
			$houzhui = $houzhui[count($houzhui)-1];
			$verifyBreak = FALSE;
			$verifyName = $verify['Name'];
			$tempList = $this->getTemplate($domainMod, $enameId, $verifyName);
			if(!$tempList)
			{
				echo $verifyName ."not find temp\r\n";
				continue;
			}
			foreach($tempList as $tempInfo)
			{
				$tempId = $tempInfo['TemplateId'];
				$email = $tempInfo['Email'];
				$comname = $tempInfo['Org'];
				$typeName = $temptype[$tempInfo['TemplateType']];
				$country = $tempInfo['CountryName'];
				$linkcount = $tempInfo['LinkCount'];
				$province = $tempInfo['Province'];
				$city = $tempInfo['City'];
				$domainList = $this->getDomainList($domainMod, $tempId, $enameId);
				if(!$domainList)
				{
					echo $tempId ."not find temp\r\n";
					continue;
				}
				foreach($domainList as $domainInfo)//域名列表cn com net org
				{
					$message = '';
					$domainName = $domainInfo['DomainName'];
					$jiexiList = $ednsLib->recordList($domainName);
					print_r($jiexiList);
					if(!empty($jiexiList['status']) && !empty($jiexiList['data']['records']))//解析记录
					{
						$photo = explode('/',$img);
						$fileName="http://managenew.ename.cn/index.php/verify/showPic/?ac=img&imgPath=/opt/ename/verifyPic/sfz/".$photo[0].'/'.$photo[1];
						echo $fileName."\r\n";
						$filecontent = file_get_contents($fileName);
						file_put_contents('/tmp/miaoandxiaoheimg/'.$domainName.'.'.$houzhui,$filecontent);
						$st = TRUE;//找到一个符合的域名就跳出
						$message = $domainName.",$verifyName,$comname,$typeName,$linkcount,$email,$country-$province-$city,";
						$message .=$tempInfo['TelCC']."-".$tempInfo['Phone']."-".$tempInfo['PhoneExt'].",";
						$message .=$tempInfo['FaxCC']."-".$tempInfo['Fax']."-".$tempInfo['FaxExt'];
						$message .= $tempInfo['Street'].",".$tempInfo['PostCode'];
						$message .="\r\n";
						error_log($message,3,'/tmp/miaoxiaoheneed.csv');
						echo "copy image success\r\n";
						break;
					}
					else
					{
						//继续找
						continue;
					}
				}
				if($st)//找到一个域名就退出
				{
					break;
				}
			}
			if($st)
			{
				break;
			}			
		}
		return $st;
	}
	
	//域名	姓名	公司名称	模板类型	关联域名	邮箱	国家缩写-省份-城市	国际区号-电话-分机号	国际区号-传真-分机号	街道	邮编	备注
	public function shiMingZhiAction()
	{
		$domainMod = new ModBase('domain');
		$userMod = new ModBase('user');
		$verifyMod = new ModBase('verify');
		$savePath = "/tmp/miaoandxiaohe.csv";
		$ednsLib = new \lib\manage\domain\DomainEdnsBaseLib();
		$upage = 0;
		$num = 100;
		$need = 0;
		$temptype = array('1'=>'企业模版','2'=>'国际模版','4'=>'个人模版');
		$enameIdList = array();
		while(true)
		{
			if($need>=100)
			{
				break;
			}
			$limit = $upage * $num .",".$num;
			$vipList = $userMod->select("select distinct(content) from e_member_vip where Type=2 limit $limit", '',array());
			if(!$vipList)
			{
				break;
			}
			foreach($vipList as $vipinfo)//vip用户列表
			{
				$vipBreak = FALSE;
				$enameId = explode(",",$vipinfo['content'])[0];
				$enameIdList[] = $enameId;
				$isVerify = $this->getVerify($verifyMod, $enameId);
				if(!$isVerify)
				{
					continue;
				}
				//认证列表
				foreach($isVerify as $verify)
				{
					if(empty($verify['NewFrontImg']))
					{
						continue;
					}
					$st = $this->shimingMain($verifyMod, $domainMod, $enameId, $ednsLib);
					if($st)
					{
						$vipBreak = true;
						break;
					}
				}
				if($vipBreak)
				{
					$need++;
				}
			}
			if($need>=100)
			{
				break;
			}
			$upage++;
		}
		if($need<100)
		{
			echo "not enou 100\r\n";
		}
	}
}
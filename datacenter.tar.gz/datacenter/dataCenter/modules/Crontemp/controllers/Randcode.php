<?php
use core\ModBase;
class RandcodeController extends Yaf\Controller_Abstract
{
	public function bufarandcodeAction()
	{
		$domainMod = new ModBase('lottery');
		$bindtime = strtotime('2015-03-18');
		$filename ='/var/www/ename/randcode2015-03-18.log';
		$instr = file_get_contents($filename);
		$inlist = explode("\n", $instr);
		foreach ($inlist as $key=>$val)
		{
			$valstr = explode('|', $val);
			$valstrin = explode('，', $valstr[2]);
			if(count($valstrin)>2)
			{
				$enameid = explode('：', $valstrin[0]);
				$transid = explode('：', $valstrin[1]);
				$domain = explode('：', $valstrin[2]);
				$code = \common\Random::getNumber(2);
				$query = "insert into e_lottery_randcode(rd_enameid,rd_bindtime,rd_randcode,rd_transid,rd_lotterystatus,rd_domain)";
				$query .=" values(?,?,?,?,?,?)";
				$bindValue = array($enameid[1],$bindtime,$code,$transid[1],1,$domain[1]);
				$rs = $domainMod->add($query, 'iiiiis', $bindValue);
				if(!$rs)
				{
					\core\Log::write('用户：'.$enameid[1].'，交易ID：'.$transid[1].'，域名：'.$domain[1].'补发随机码失败', 'crontemp/lottery', 'randcode');
				}
				else
				{
					$content = array('title' => "精品域名拍卖会随机码");
					$content['content'] = "尊敬的用户".$enameid[1].":<br>您好，您出价了精品拍卖会域名：【".$domain[1]."】，获得随机码：".$code;
					$queue = new \interfaces\manage\Queue();
					$res = $queue->sendSiteMsg($enameid[1], 'any_template_info', $content, 6);
					if(FALSE == $res)
					{
						\core\Log::write("用户：".$enameid[1].'，交易ID：'.$transid[1].'生成随机码成功，发送站内信失败','lottery','randcode');//
					}
				}
			}
		}	
		$bindtime = strtotime('2015-03-17');
		$filename ='/var/www/ename/randcode2015-03-17.log';
		$instr = file_get_contents($filename);
		$inlist = explode("\n", $instr);
		foreach ($inlist as $key=>$val)
		{
			$valstr = explode('|', $val);
			$valstrin = explode('，', $valstr[2]);
			if(count($valstrin)>2)
			{
				$enameid = explode('：', $valstrin[0]);
				$transid = explode('：', $valstrin[1]);
				$domain = explode('：', $valstrin[2]);
				$code = \common\Random::getNumber(2);;
				$query = "insert into e_lottery_randcode(rd_enameid,rd_bindtime,rd_randcode,rd_transid,rd_lotterystatus,rd_domain)";
				$query .=" values(?,?,?,?,?,?)";
				$bindValue = array($enameid[1],$bindtime,$code,$transid[1],1,$domain[1]);
				$rs = $domainMod->add($query, 'iiiiis', $bindValue);
				if(!$rs)
				{
					\core\Log::write('用户：'.$enameid[1].'，交易ID：'.$transid[1].'，域名：'.$domain[1].'补发随机码失败', 'crontemp/lottery', 'randcode');
				}
				else {
					$content = array('title' => "精品域名拍卖会随机码");
					$content['content'] = "尊敬的用户".$enameid[1].":<br>您好，您出价了精品拍卖会域名：【".$domain[1]."】，获得随机码：".$code;
					$queue = new \interfaces\manage\Queue();
					$res = $queue->sendSiteMsg($enameid[1], 'any_template_info', $content, 6);
					if(FALSE == $res)
					{
						\core\Log::write("用户：".$enameid[1].'，交易ID：'.$transid[1].'生成随机码成功，发送站内信失败','lottery','randcode');//
					}
				}
			}
		}	
	}
}
<?php
use core\ModBase;

class TestcgiController extends Yaf\Controller_Abstract
{
	/**
	 * 测试go并发执行cli croncgi/test/index
	 */

	public function indexAction()
	{
		$goServer = new \core\GoServer();
		for($i = 1; $i < 5; $i++)
		{
			$goServer->call($i, 'manage\member\UserMemberLogic::getMemberBaseInfo', array(561305));
		}
		$res = $goServer->send();
		var_dump($res);
	}
	
	public function asycnAction()
	{
		$goServer = new \core\GoServer();
		for($i = 1; $i < 5; $i++)
		{
			$goServer->call($i, 'manage\member\UserMemberLogic::getMemberBaseInfo', array(561305));
		}
		$goServer->asyncSend();
		exit('over');
	}
}

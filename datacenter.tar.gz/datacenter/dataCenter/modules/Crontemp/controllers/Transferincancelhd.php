<?php
use lib\manage\common\DomainFunLib;
use core\Log;
use lib\manage\domain\DomainEppLib;
class TransferincancelhdController extends Yaf\Controller_Abstract
{

	/**
	 * 定时任务　转入活动过期后处理非转入状态的转入以及相应的订单
	 * 1、2016年6月20日00:00---2016年7月01日23:59:59，期间续费/转入.top域名享受.top续费/转入价：15元。
	 * 2、2016年7月02日00:00---2016年8月30日23:59:59，期间续费/转入.top域名享受.top续费/转入价：26元。
	 * 3、2016年9月01日00:00---2016年9月03日23:59:59，期间续费/转入.wang域名享受.wang续费/转入价：23元。
	 * 4、2016年10月14—17日00:00:00—23:59:59，.wang转入29元。
	 * 备注：可以活动结束前一天人工看下没有数据的话，开始检测的起始时间可以跳过不需要检测的
	 * php crontab/cli.php crontemp transferincancelhd checkDnTransferinDeadline 86 top 1472400000 1472572799
	 * php crontab/cli.php crontemp transferincancelhd checkDnTransferinDeadline 86 wang 1472659200 1472918399
	 */
	public function checkDnTransferinDeadlineAction($params = array())
	{
		if(empty($params[0]) && empty($params[1]) && empty($params[2]))
		{
			exit('time error');
		}
		$RegistrarId = $params[0];//活动域名接口ID
		$domainLtd = "." . $params[1];//域名后缀
		$hdstarttime = date('Y-m-d H:i:s', $params[2]);//活动开始时间
		$hdDeadline = date('Y-m-d H:i:s', $params[3]);//活动结束时间
		
		$limit = 1500; // 每次处理转入的条数
		$transInMod = new \models\manage\domain\DomainTransferInMod();
		$domainList = $transInMod->getTransferInfo(
			array('TransferStatus' => '< 4', 'CreateTime >=' => $hdstarttime, 'CreateTime <=' => $hdDeadline, 'like' => array('DomainName' => $domainLtd), 
				'RegistrarId' => $RegistrarId, 'limit' => $limit), 'TransferStatus,DomainName,RegistrarID,OrderId,EnameId,TransferInId', false);

		\core\Log::write('域名条数:' . count($domainList), 'crontemp/transferincancelhd');
		if(!empty($domainList))
		{
			$dnTransferInLib = new \lib\manage\domain\DomainTransferInLib();
			$orderlib = new \interfaces\manage\Finance();
			$domainEpp = new DomainEppLib();
			foreach($domainList as $k => $v) // 处理活动过期订单，更改转入状态；
			{
				try
				{
					echo $v['DomainName'] . ',' . $v['TransferInId'] . "\r\n";
					$noCancelorder = false;
					//重新获取一次转入状态避免执行过长不准确
					$transCheck = $transInMod->getTransferInfo(array('TransferInId' => $v['TransferInId']), 
						'TransferStatus,DomainName,RegistrarID,OrderId,EnameId,TransferInId', true);
					if(!$transCheck)
					{
						\core\Log::write('二次checkinfo出错:' . $v['DomainName'] . ',' . $v['TransferInId'] , 'crontemp/transferincancelhd');
						continue;
					}
					$v = $transCheck;
					if($v['TransferStatus'] >= 4)
					{
						\core\Log::write('检测TransferStatus大于5了:' . $v['DomainName'] . ',' . $v['TransferInId'] , 'crontemp/transferincancelhd');
						continue;
					}
					//邮件同意转入的需要核实5028，转移提交ok的改为正在转入，否则改为取消转入
					if($v['TransferStatus'] == '3')
					{
						$regisTransInfo = $domainEpp->getDomainRegTransInfo($v['DomainName'], $v['RegistrarID'], false, 
							$v['password']); // 查询注册局转移信息
						if($regisTransInfo !== FALSE)
						{
							if(!empty($regisTransInfo['status']) && ($regisTransInfo['status'] == 'pending' ||
								 $regisTransInfo['status'] == 'clientApproved' || $regisTransInfo['status'] == 'serverApproved'))
							{
								$noCancelorder = true;
							}
						}
						else
						{
							\core\Log::write('检测转入5028出错:' . $v['DomainName'], 'crontemp/transferincancelhd');
							continue;
						}
					}
					if($noCancelorder)
					{
						$TransferStatus = 6; // 转入状态置为正在转入
					}
					else
					{
						$TransferStatus = 5; // 转入状态置为已取消
						\core\Log::write('取消转入取消订单:' . $v['DomainName'] . ',' . $v['TransferInId'] . "," . $v['OrderId'], 'crontemp/transferincancelhd');
						//脚本没有正式跑过先不取消订单确保没问题再开启，开始先人工确认是否取消
						if(!$orderlib->cancelOrder((object)array('orderId' => $v['OrderId'], 'enameId' => $v['EnameId'])))
						{
							\core\Log::write('取消转入取消订单失败:' . $v['DomainName'] . "," . $v['OrderId'], 'crontemp/transferincancelhd');
							continue;
						}
					}
					$setResult = $dnTransferInLib->setTransferInfo(array('TransferInId' => $v['TransferInId']), 
						array('TransferStatus' => $TransferStatus, 'UpdateTime' => date('Y-m-d H:i:s'))); // 更新转入状态
					if($setResult == false)
					{
						\core\Log::write('更新转入状态出错:' . $v['DomainName'], 'crontemp/transferincancelhd');
					}
					else
					{
						\core\Log::write('更新转入状态成功:' . $v['DomainName'] . ":" . $TransferStatus, 'crontemp/transferincancelhd');
					}
				}
				catch(\Exception $e)
				{
					\core\Log::write('处理过期活动转入域名出错:' . $e->getMessage(), 'crontemp/transferincancelhd');
				}
			}
		}
	}
}

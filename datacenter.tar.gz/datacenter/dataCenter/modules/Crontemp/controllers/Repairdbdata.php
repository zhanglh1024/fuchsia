<?php
use core\ModBase;

/**
 * 修复迁移db数据
 */
class RepairdbdataController extends Yaf\Controller_Abstract
{
	/**
	 * 将15年表里的16年数据迁移到16年表里--站内信
	 */
	public function messageAction()
	{
		echo "=====begin=====\r\n";
		$beginId = 51007;
		$userMod = new ModBase('user');
		$query = "select * from e_member_message where SendTime>='2016-01-01' limit 10000";
		$resultInfo = $userMod->select($query, '', array());
		foreach ($resultInfo as $k => $v)
		{
			$autoId = $k + $beginId;
			$query = "insert into e_member_message2016(MessageId,EnameId,SendId,MessageType,Status,SendTime,ViewTime,Title,Content,ParamsCode,TemplateId)";
			$query .= " values(".$autoId.",".$v['EnameId'].",".$v['SendId'].",".$v['MessageType'].",".$v['Status'].",'".$v['SendTime']."','".$v['ViewTime']."','".$v['Title']."','".$v['Content']."','".$v['ParamsCode']."','".$v['TemplateId']."')";
			$addResult = $userMod->add($query, '', array());
			if(empty($addResult))
			{
				echo $v['MessageId']."写入失败\r\n";
			}
		}
		echo "=====end=====\r\n";
	}
	
	/**
	 * 对16年部分数据进行排序--站内信
	 */
	public function messageOrderAction()
	{
		echo "=====begin=====\r\n";
		$beginId = 1;
		$endId = 70718;
		$userMod = new ModBase('user');
		$query = "select * from e_member_message2016 where MessageId>=".$beginId." and MessageId<=".$endId;
		$resultInfo = $userMod->select($query, '', array());
		foreach ($resultInfo as $key => $row)
		{
			$volume[$key]  = $row['SendTime'];
		}
		$orderResult = array_multisort($volume, SORT_ASC, $resultInfo);
		if(!$orderResult)
		{
			echo "=====order fail=====";
			exit;
		}
		foreach ($resultInfo as $k => $v)
		{
			$autoId = $k + $beginId;
			$query = "update e_member_message2016 set EnameId=".$v['EnameId'].",SendId=".$v['SendId'].",MessageType=".$v['MessageType'].",Status=".$v['Status'].",SendTime='".$v['SendTime']."',ViewTime='".$v['ViewTime']."',Title='".$v['Title']."',Content='".$v['Content']."',ParamsCode='".$v['ParamsCode']."',TemplateId='".$v['TemplateId']."' where MessageId=".$autoId;
			$upResult = $userMod->update($query, '', array());
			if(empty($upResult))
			{
				echo $v['MessageId']."写入失败\r\n";
			}
		}
		echo "=====end=====\r\n";
	}
	
	/**
	 * 将15年表里的16年数据迁移到16年表里--入款
	 */
	public function transInAction()
	{
		echo "=====begin=====\r\n";
		$beginId = 12369;
		$finMod = new ModBase('finance');
		$query = "select * from e_finance_in where CreateDate>='2016-01-01' limit 3000";
		$resultInfo = $finMod->select($query, '', array());
		foreach ($resultInfo as $k => $v)
		{
			$autoId = $k + $beginId;
			$query = "insert into e_finance_in2016(InId,EnameId,InMoney,CurrentMoney,MoneyType,InType,CreateDate,Operator,InStatus,InRemark,PayId,LinkEnameId,OrderId,FeeMoney,BankName,InRemarkHide,TaxPoint,BankFeeMoney,LinkDomain,InTypeSon,UniqueId,RegistarId)";
			$query .= " values(".$autoId.",".$v['EnameId'].",'".$v['InMoney']."','".$v['CurrentMoney']."',".$v['MoneyType'].",".$v['InType'].",'".$v['CreateDate']."',".$v['Operator'].",".$v['InStatus'].",'".$v['InRemark']."',".$v['PayId'].",".$v['LinkEnameId'].",'".$v['OrderId']."','".$v['FeeMoney']."',".$v['BankName'].",'".$v['InRemarkHide']."','".$v['TaxPoint']."','".$v['BankFeeMoney']."','".$v['LinkDomain']."',".$v['InTypeSon'].",".$v['UniqueId'].",".$v['RegistarId'].")";
			$addResult = $finMod->add($query, '', array());
			if(empty($addResult))
			{
				echo $v['InId']."写入失败\r\n";
			}
		}
		echo "=====end=====\r\n";
	}
	
	/**
	 * 对16年部分数据进行排序--入款
	 */
	public function transInOrderAction()
	{
		echo "=====begin=====\r\n";
		$beginId = 1;
		$endId = 17185;
		$finMod = new ModBase('finance');
		$query = "select * from e_finance_in2016 where InId>=".$beginId." and InId<=".$endId;
		$resultInfo = $finMod->select($query, '', array());
		foreach ($resultInfo as $key => $row)
		{
			$volume[$key]  = $row['CreateDate'];
		}
		$orderResult = array_multisort($volume, SORT_ASC, $resultInfo);
		if(!$orderResult)
		{
			echo "=====order fail=====";
			exit;
		}
		foreach ($resultInfo as $k => $v)
		{
			$autoId = $k + $beginId;
			$query = "update e_finance_in2016 set EnameId=".$v['EnameId'].",InMoney='".$v['InMoney']."',CurrentMoney='".$v['CurrentMoney']."',MoneyType=".$v['MoneyType'].",InType=".$v['InType'].",CreateDate='".$v['CreateDate']."',Operator=".$v['Operator'].",InStatus=".$v['InStatus'].",InRemark='".$v['InRemark']."',PayId=".$v['PayId'].",LinkEnameId=".$v['LinkEnameId'].",OrderId='".$v['OrderId']."',FeeMoney='".$v['FeeMoney']."',BankName=".$v['BankName'].",InRemarkHide='".$v['InRemarkHide']."',TaxPoint='".$v['TaxPoint']."',BankFeeMoney='".$v['BankFeeMoney']."',LinkDomain='".$v['LinkDomain']."',InTypeSon=".$v['InTypeSon'].",UniqueId=".$v['UniqueId'].",RegistarId=".$v['RegistarId']." where InId=".$autoId;
			$upResult = $finMod->update($query, '', array());
			if(empty($upResult))
			{
				echo $v['InId']."写入失败\r\n";
			}
		}
		echo "=====end=====\r\n";
	}
	
	/**
	 * 将15年表里的16年数据迁移到16年表里--出款
	 */
	public function transOutAction()
	{
		echo "=====begin=====\r\n";
		$beginId = 27904;
		$finMod = new ModBase('finance');
		//程序构造sql
// 		$query = "show columns from e_finance_out";
// 		$resultInfo = $finMod->select($query, '', array());
// 		$msg = '';
// 		foreach ($resultInfo as $k => $v)
// 		{
//			$msg .= $v['Field'].",";
//  			$msg .= $v['Field']."=";
// 			if(strpos($v['Type'], 'int') !== false)
// 			{
// 				$msg .= "\".\$v['".$v['Field']."'].\",";
// 			}
// 			else
// 			{
// 				$msg .= "'\".\$v['".$v['Field']."'].\"',";
// 			}
// 		}
// 		echo $msg;exit;
		$query = "select * from e_finance_out where CreateDate>='2016-01-01' limit 3500";
		$resultInfo = $finMod->select($query, '', array());
		foreach ($resultInfo as $k => $v)
		{
			$autoId = $k + $beginId;
			$query = "insert into e_finance_out2016(OutId,EnameId,OutMoney,CurrentMoney,OutType,CreateDate,Operator,OutStatus,OutRemark,OutRemarkHide,LinkDomain,LinkEnameId,OrderId,PromoId,PromoMoney,ProductOptions,OutTypeSon,UniqueId,RegistarId,FeeMoney)";
			$query .= " values(".$autoId.",".$v['EnameId'].",'".$v['OutMoney']."','".$v['CurrentMoney']."',".$v['OutType'].",'".$v['CreateDate']."',".$v['Operator'].",".$v['OutStatus'].",'".$v['OutRemark']."','".$v['OutRemarkHide']."','".$v['LinkDomain']."',".$v['LinkEnameId'].",'".$v['OrderId']."',".$v['PromoId'].",'".$v['PromoMoney']."','".$v['ProductOptions']."',".$v['OutTypeSon'].",".$v['UniqueId'].",".$v['RegistarId'].",'".$v['FeeMoney']."')";
			$addResult = $finMod->add($query, '', array());
			if(empty($addResult))
			{
				echo $v['OutId']."写入失败\r\n";
			}
		}
		echo "=====end=====\r\n";
	}
	
	/**
	 * 对16年部分数据进行排序--出款
	 */
	public function transOutOrderAction()
	{
		echo "=====begin=====\r\n";
		$beginId = 1;
		$endId = 33095;
		$finMod = new ModBase('finance');
		$query = "select * from e_finance_out2016 where OutId>=".$beginId." and OutId<=".$endId;
		$resultInfo = $finMod->select($query, '', array());
		foreach ($resultInfo as $key => $row)
		{
			$volume[$key]  = $row['CreateDate'];
		}
		$orderResult = array_multisort($volume, SORT_ASC, $resultInfo);
		if(!$orderResult)
		{
			echo "=====order fail=====";
			exit;
		}
		foreach ($resultInfo as $k => $v)
		{
			$autoId = $k + $beginId;
			$query = "update e_finance_out2016 set EnameId=".$v['EnameId'].",OutMoney='".$v['OutMoney']."',CurrentMoney='".$v['CurrentMoney']."',OutType=".$v['OutType'].",CreateDate='".$v['CreateDate']."',Operator=".$v['Operator'].",OutStatus=".$v['OutStatus'].",OutRemark='".$v['OutRemark']."',OutRemarkHide='".$v['OutRemarkHide']."',LinkDomain='".$v['LinkDomain']."',LinkEnameId=".$v['LinkEnameId'].",OrderId='".$v['OrderId']."',PromoId=".$v['PromoId'].",PromoMoney='".$v['PromoMoney']."',ProductOptions='".$v['ProductOptions']."',OutTypeSon=".$v['OutTypeSon'].",UniqueId=".$v['UniqueId'].",RegistarId=".$v['RegistarId'].",FeeMoney='".$v['FeeMoney']."' where OutId=".$autoId;
			$upResult = $finMod->update($query, '', array());
			if(empty($upResult))
			{
				echo $v['OutId']."写入失败\r\n";
			}
		}
		echo "=====end=====\r\n";
	}
	
	/**
	 * 将15年表里的16年数据迁移到16年表里--充值订单
	 */
	public function paycenterAction()
	{
		echo "=====begin=====\r\n";
		$finMod = new ModBase('finance');
		$query = "select * from e_finance_paycenter where BeginTime>='2016-01-01'";
		$resultInfo = $finMod->select($query, '', array());
		foreach ($resultInfo as $k => $v)
		{
			$query = "insert into e_finance_paycenter2016(PayId,RandId,TradeNo,RechargeMoney,PayType,BeginTime,EnameId,LinkName,IsSuccess,EndTime,MoneyType,ResponseUrl,RequestUrl,ClientIp,TransId,Domain)";
			$query .= " values(".$v['PayId'].",".$v['RandId'].",'".$v['TradeNo']."','".$v['RechargeMoney']."',".$v['PayType'].",'".$v['BeginTime']."',".$v['EnameId'].",'".$v['LinkName']."',3,'".$v['EndTime']."',".$v['MoneyType'].",'".$v['ResponseUrl']."','".$v['RequestUrl']."','".$v['ClientIp']."',".$v['TransId'].",'".$v['Domain']."')";
			$addResult = $finMod->add($query, '', array());
			if(empty($addResult))
			{
				echo $v['PayId']."写入失败\r\n";
			}
		}
		echo "=====end=====\r\n";
	}
}
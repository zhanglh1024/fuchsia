<?php
use core\ModBase;

class TempwangController extends Yaf\Controller_Abstract
{

	public function checkwangAction()
	{
		$file = fopen("/tmp/newzhucejuwang.csv", "r");
		if(! $file)
		{
			exit("打开文件失败");
		}
		$domainMod = new ModBase('domain');
		while(! feof($file))
		{
			$line = trim(fgets($file));
			if(! $line)
			{
				continue;
			}
			$domain = $line; // 我们的域名
			$sql = "select * from e_domains where DomainName='{$domain}'";
			$result = $domainMod->getRow($sql, '', array()); // 查列表 看下是否有重复的
			if(empty($result))
			{
				error_log($domain . "\r\n", 3, "/tmp/zhangdaguanrenwang222.csv");
			}
		}
	}

	public function checkwangtradeAction()
	{
		$zhangdaguanren = file_get_contents("/tmp/lastresultinoutdomainnotinzhuceju.csv");
		$inoutdomainnotinzhuceju = "/tmp/wang-domain-in-trade.csv";
		$domainContent = file_get_contents($inoutdomainnotinzhuceju);
		if(! $domainContent)
		{
			exit("not found data");
		}
		$domainArr = explode("\n", $domainContent);
		foreach($domainArr as $domain)
		{
			$info = trim($domain);
			$domain = explode(",", $info)[0]; // 交易的数据
			if(stripos($zhangdaguanren, $domain) !== FALSE) // 需要下架的
			{
				error_log($info . "\r\n", 3, "/tmp/zhangdaguanrentradewang.csv");
			}
		}
	}

	public function wangRenewCheckAction()
	{
		$financeMod = new ModBase('finance');
		$dnMod = new ModBase('domain');
		$eppLib = new lib\manage\domain\DomainEppLib();
		$query = "select EnameId,OutMoney,CreateDate,LinkDomain from e_finance_out2016 where OutType=3 and CreateDate>='2016-02-29' and SUBSTR(LinkDomain,-4)='wang'";
		$result = $financeMod->select($query, '', array());
		if(empty($result))
		{
			exit('查无数据');
		}
		foreach($result as $k => $v)
		{
			if($v['OutMoney'] != '48.0000' && $v['OutMoney'] != '50.0000')
			{
				echo $v['LinkDomain'] . "续费超过一年\r\n"; // 目前只有一个数据
				continue;
			}
			$query = "select RegDate,ExpDate from e_domains where DomainName='" . $v['LinkDomain'] . "'";
			$eDnInfo = $dnMod->getRow($query, '', array());
			if($eDnInfo['RegDate'] < '2016')
			{
				echo $v['LinkDomain'] . "2016年之前已注册\r\n";
				continue;
			}
			$exp1 = $eDnInfo['ExpDate'];
			$sDnInfo = $eppLib->getDomainRegInfo($v['LinkDomain'], 86);
			if(! $sDnInfo)
			{
				echo $v['LinkDomain'] . "注册局信息查询失败\r\n";
				continue;
			}
			$exp2 = $sDnInfo['expireDate'];
			if(date('Y-m-d H:i:s', strtotime('+1year', strtotime($exp1))) == $exp2)
			{
				echo $v['LinkDomain'] . "续费正常\r\n";
				continue;
			}
			echo $v['LinkDomain'] . "续费异常\r\n";
		}
	}

	/**
	 * 获取普通竞价订单 $orderType=102
	 */
	public function getjingjiaOrderAction()
	{
		header("Content-type: text/html; charset=utf-8");
		$orderStr = trim(file_get_contents('/tmp/enamecomxinghuajiaoyi.log'));
		$file = '/tmp/getjingjiaOrderxinghua.csv';
		file_put_contents($file, '卖家' . ',' . '买家' . ',' . '域名' . ',' . '订单号' . ',' . '订单状态' . "\r\n", FILE_APPEND);
		$orderArr = explode("\n", $orderStr);
		$orderArr = array_unique($orderArr);
		$orderArr = array_filter($orderArr);
		$orderMod = new ModBase('finance');
		$orderType = 102;
		if($orderArr)
		{
			foreach($orderArr as $order)
			{
				$temp = explode(",", trim($order));
				$enameId = $temp[1];
				$linkEnameId = $temp[0];
				$domain = $temp[2];
				$sql = "select * from e_finance_orders where OrderType=" . $orderType;
				$sql .= " and EnameId=$enameId and  OrderStatus=3 and  LinkEnameId=$linkEnameId and  Domain='" . $domain .
					 "'";
				echo $sql;
				echo "\r\n";
				$result = $orderMod->select($sql, '', array());
				if($result)
				{
					foreach($result as $v)
					{
						file_put_contents($file, 
							$v['EnameId'] . ',' . $v['LinkEnameId'] . ',' . $v['Domain'] . ',' . $v['OrderId'] . "\r\n", 
							FILE_APPEND);
					}
				}
			}
		}
		echo '0k';
	}

	/**
	 * NO.55064 162070转入款项解冻
	 */
	public function checkTransferSecuringFaidAction()
	{
		$domainList = file_get_contents("/tmp/anquanjingbaozhuanru.log") or die('read file error');
		$domainArr = explode("\n", trim($domainList));
		$domainMod = new ModBase('domain');
		$finMod = new ModBase('finance');
		foreach($domainArr as $domain)
		{
			$domain = trim($domain);
			$domainSql = "select OrderId from e_domain_transfer_in where DomainName='{$domain}'";
			$domainResult = $domainMod->select($domainSql, '', array());
			if($domainResult)
			{
				foreach($domainResult as $orderinfo)
				{
					$orderId = $orderinfo['OrderId'];
					$finSql = "select * from e_finance_orders  where OrderId='{$orderId}'";
					$finResult = $finMod->getRow($finSql, '', array());
					if($finResult)
					{
						if($finResult['OrderStatus'] == 2 || $finResult['OrderStatus'] == 3)
						{
							echo "order status error,$domain,$orderId," .
								 ($finResult['OrderStatus'] == 2 ? 'cancel' : 'ing') . "\r\n";
							;
						}
					}
					else
					{
						echo "not found orderinfo,$domain,$orderId\r\n";
					}
				}
			}
		}
	}

	/**
	 * wang域名检测
	 */
	public function checkWangDomainAction()
	{
		// 获取 临时模板id下的 wang域名
		echo "-----start-----\n";
		$sql = "select DomainName from e_domains where EnameId =  667792 and DomainLtd = 29";
		$mod = new \core\ModBase('domain');
		if(! $list = $mod->select($sql, '', array()))
		{
			echo "667792下没有wang域名了\n";
			return FALSE;
		}
		$finMod = new \core\ModBase('finance');
		foreach($list as $domainArr)
		{
			$domain = $domainArr['DomainName'];
			// 查询冻结订单
			$sql = "select * from e_finance_orders where ordertype = 1 and linkdomain = ? and Status = 3";
			if($freezeOrder = $finMod->select($sql, 's', array($domain)))
			{
				\core\Log::write(var_export($freezeOrder, true), 'crontemp/wang', 'freezeOrder');
				continue;
			}
			// 查询所有出款的EnameId
			$sql = "select EnameId,count(*) as count from e_finance_out2016 where outtype = 1 and linkdomain = ? group by EnameId";
			if(! $outData = $finMod->select($sql, 's', array($domain)))
			{
				\core\Log::write($domain, "crontemp/wang", 'no_finance_out');
				continue;
			}
			// 查询所有入款的(取消订单的Id)
			$sql = "select EnameId,count(*) as count from e_finance_in2016 where intype = 203 and inremark = '取消订单' and linkdomain = ?";
			if(! $inData = $finMod->getOne($sql, 'si', array($domain)))
			{
				\core\Log::write($domain, "crontemp/wang", 'no_finance_in');
				continue;
			}
			$outData = $this->dealData($outData);
			$inData = $this->dealData($inData);
			foreach($outData as $enameid => $outCount)
			{
				$inCount = isset($inData[$enameid]) ? intval($inData[$enameid]) : 0;
				$tmpResult = $outCount - $inCount;
				// 出款多
				if($tmpResult > 1)
				{
					\core\Log::write("{$enameid},{$domain},out:{$outCount},in:{$inCount}", 'crontemp/wang', 'out_many');
				}
				else if($tmpResult == 1)
				{
					\core\Log::write("{$enameid},{$domain},out:{$outCount},in:{$inCount}", 'crontemp/wang', 'my_domain');
				}
				else if($tmpResult == 0)
				{
					\core\Log::write("{$enameid},{$domain},out:{$outCount},in:{$inCount}", 'crontemp/wang', 'in_out_OK');
				}
				else
				{
					\core\Log::write("{$enameid},{$domain},out:{$outCount},in:{$inCount}", 'crontemp/wang', 'in_many');
				}
			}
		}
		echo "-----end-----\n";
	}

	private function dealData($data)
	{
		$result = array();
		if($data)
		{
			foreach($data as $value)
			{
				$result[$value['EnameId']] = $value['count'];
			}
		}
		return $result;
	}
}

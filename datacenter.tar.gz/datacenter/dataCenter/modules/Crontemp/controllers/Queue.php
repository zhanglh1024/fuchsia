<?php
use core\ModBase;

class QueueController extends Yaf\Controller_Abstract
{

	public function fixDomainDnsAction()
	{
		echo "-----start-----\n";
		$queueMod = new ModBase('newqueue');
		$sql = 'select count(*) from e_queue_tasks_detail where `Status` = 1 and `Function` = "modify_domain_dns" and `CreateTime` <= 1454553600';
		$count = $queueMod->getOne($sql, '', array());
		if($count)
		{
			$taskLogic = new \logic\manage\newqueue\QueueLogic();
			$domainMod = new ModBase('domain');
			$limit = 200;
			$page = ceil($count / $limit);
			for($i = 0; $i < $page; $i ++)
			{
				$sql = 'select * from e_queue_tasks_detail where `Status` = 1 and `Function` = "modify_domain_dns" and `CreateTime` <= 1454553600 limit ' .
					 $limit * $i . ',' . $limit;
				if($list = $queueMod->select($sql, '', array()))
				{
					foreach($list as $queue)
					{
						try
						{
							$data = json_decode($queue['Data'], true);
							$domain = $data['domain'];
							$queueDns = $data['DNS'];
							// 获取域名id
							$domainId = $domainMod->getOne('select DomainId from e_domains where DomainName = ?', 's', 
								array($domain));
							if($dns = $domainMod->getOne('select Dns from e_domain_ext where DomainId = ?', 'i', 
								array($domainId)))
							{
								// dns判断
								$dnsArr = explode(',', $dns);
								if(array_intersect($dnsArr, $queueDns))
								{
									\core\Log::write('info:' . json_encode($queue), 'crontemp/queue', 'updateSucceess');
									$queueMod->update(
										'update e_queue_tasks_detail set Status = 2,SuccessTime = ？ where QueueId = ?', 
										'ii', array(time(), $queue['QueueId']));
									
									$queueMod->update(
										'update e_queue_tasks set SuccessTotal = SuccessTotal + 1 where TaskId = ?', 'i', 
										array($queue['TaskId']));
									
									$taskInfo = $queueMod->getRow('select * from e_queue_tasks where TaskId = ?', 'i', 
										array($queue['TaskId']));
									if($taskInfo['Total'] == ($taskInfo['SuccessTotal'] + $taskInfo['FailureTotal']))
									{
										$queueMod->update('update e_queue_tasks set Status = 5 where TaskId = ?', 'i', 
											array($taskInfo['TaskId']));
									}
									continue;
								}
								
								// 域名操作日志判断
								if($log = $domainMod->select(
									'select * from e_domain_service2016 where ServiceType = 10 and Domain = ? and OperationTime > ?', 
									'ss', array($domain, '2016-02-04 03:41:37')))
								{
									\core\Log::write('info:' . json_encode($queue), 'crontemp/queue', 'updateFailure');
									$queueMod->update(
										'update e_queue_tasks_detail set Status = 3,SuccessTime = ？ where QueueId = ?', 
										'ii', array(time(), $queue['QueueId']));
									
									$queueMod->update(
										'update e_queue_tasks set FailureTotal = FailureTotal + 1 where TaskId = ?', 'i', 
										array($queue['TaskId']));
									
									$taskInfo = $queueMod->getRow('select * from e_queue_tasks where TaskId = ?', 'i', 
										array($queue['TaskId']));
									if($taskInfo['Total'] == ($taskInfo['SuccessTotal'] + $taskInfo['FailureTotal']))
									{
										$queueMod->update('update e_queue_tasks set Status = 5 where TaskId = ?', 'i', 
											array($taskInfo['TaskId']));
									}
									continue;
								}
							}
							
							// 队列重启
							$result = $taskLogic->setTaskRestart(array('QueueId' => $queue['QueueId']));
							\core\Log::write('QueueId:' . $queue['QueueId'] . ',result:' . $result, 'crontemp/queue', 
								'fixDomainDns');
						}
						catch(\Exception $e)
						{
							\core\Log::write('QueueId:' . $queue['QueueId'] . ',result:' . $e->getMessage(), 
								'crontemp/queue', 'fixDomainDnsError');
						}
					}
				}
			}
		}
		echo "-----end-----\n";
	}

	public function wangSendMailAction()
	{
		$tmp = array(
				1073757 => '3,3', 1071093 => '3,3', 1070363 => '3,3', 1055158 => '1,1', 1051605 => '3,3', 
				1046063 => '1,1', 1037639 => '3,3', 1029648 => '1,1', 1028015 => '2,1', 981651 => '2,2', 976000 => '1,1', 
				953053 => '3,3', 794699 => '5,4', 667788 => '2,1', 637115 => '1,1', 604944 => '6,1', 550097 => '1,1', 
				36888 => '1,1', 11118 => '1,1', 1072113 => '1,0', 1063587 => '13,0', 1036625 => '3,0', 1035688 => '2,0', 
				1032930 => '3,0', 1030697 => '4,0', 1025404 => '1,0', 945532 => '2,0', 761927 => '1,0', 508384 => '2,0', 
				358278 => '1,0', 348606 => '4,0', 314127 => '7,0', 199999 => '1,0', 55552 => '2,0', 483032 => '3,0', 
				489987 => '1,0', 573325 => '2,0', 888036 => '5,0', 923639 => '1,0', 933419 => '1,0', 937391 => '2,0', 
				962965 => '1,0', 970812 => '2,0', 1031428 => '5,0', 1040431 => '1,0', 1040545 => '1,0', 1066380 => '5,0', 
				1067243 => '3,0', 1068373 => '2,0', 1074170 => '1,0', 1074174 => '1,0', 1074289 => '1,0', 
				1074309 => '1,0');
		$queue = new \interfaces\manage\Queue();
		$userMod = new ModBase('user');
		foreach($tmp as $k => $v)
		{
			$query = "select Email from e_member where EnameId=" . $k;
			$result = $userMod->getRow($query, '', array());
			if(empty($result['Email']))
			{
				echo $k . "获取邮箱信息失败\r\n";
				continue;
			}
			$value = explode(",", $v);
			$couponCount = $value[0];
			$moneyCount = $value[1];
			$tmpContent = "尊敬的客户[" . $k . "]：<br>您好，由于近期wang后缀域名注册量暴增，引起了部分问题。近期将给您账户下发送" . $couponCount .
				 "张[5元com/net/cn注册转入优惠券]";
			$tmpContent .= empty($moneyCount) ? "" : "以及" . ($moneyCount * 15) . "元预付款";
			$tmpContent .= "作为补偿，请注意查收!<br>如有疑问，请联系我司客服!感谢您对ename的关注与支持!";
			$tempContentArr['title'] = "wang域名push取消优惠券发放须知";
			$tempContentArr['content'] = $tmpContent;
			echo $queue->sendMail('any_template_info', $result['Email'], $tempContentArr, $k);
		}
	}

	/**
	 * 同步队列模板数据
	 */
	public function syncQueueTemplateAction()
	{
		echo "----------sync start----------\n";
		$oldQueueMod = new ModBase("queue");
		$newQueueMod = new ModBase("newqueue");
		$sql = "select * from e_template_details where IsDefault = 1";
		if(! $reuslt = $oldQueueMod->select($sql, "", array()))
		{
			echo "sysc error,empty data\n";
		}
		else
		{
			foreach($reuslt as $value)
			{
				$sql = "insert into e_queue_template (`TemplateName`,`TemplateRemark`,`TemplateTitle`,`IsDefault`,`AltContent`,`HtmlContent`,`GroupId`,`CreateTime`,`UpdateTime`,`Sort`)values(?,?,?,?,?,?,?,?,?,?)";
				
				$result = $newQueueMod->add($sql, "sssissiiii", 
					array(
							$value['TemplateId'], $value['Name'], $value['Subject'], $value['IsDefault'], 
							$value['AltBody'], $value['HtmlBody'], $value['GroupId'], $value['Created'], 
							$value['Updated'], $value['Sort']));
				var_dump($result);
			}
		}
		echo "----------sync end----------\n";
	}

	/**
	 * 修复队列数据(redis挂了，都设置失败)
	 */
	public function fixQueueAction()
	{
		echo "-----start-----\n";
		$queueLogic = new \logic\manage\newqueue\QueueLogic();
		$where = array('Status' => 0, 'CreateTime <= ' => strtotime('2016-04-15 10:32:02'));
		$count = $queueLogic->getQueueTaskDetailCount($where);
		if($count)
		{
			$limit = 200;
			$page = ceil($count / $limit);
			for($i = 0; $i < $page; $i ++)
			{
				$list = $queueLogic->getQueueTaskDetailList(
					array_merge($where, array('limit' => ($i * $limit) . ',' . $limit)));
				foreach($list as $value)
				{
					try
					{
						$queueLogic->setQueueTaskFailure(array('QueueId' => $value['QueueId']));
					}
					catch(Exception $e)
					{
						\core\Log::write("QueueId : {$value['QueueId']}", 'crontemp/queue', 'fixqueue');
					}
				}
			}
		}
		echo "-----end-----\n";
	}

	/**
	 * 队列优先级0，执行代码
	 */
	public function runQueueMailZeroQueueAction()
	{
		echo "-----start----\n";
		try
		{
			$funcName = 'sendmail';
			$queueCommonLib = new \lib\manage\newqueue\QueueCommonLib();
			$queueFunLib = new \lib\manage\newqueue\QueueFuncLib();
			$queueRunLib = new \lib\manage\newqueue\QueueRunLib();
			$redis = \core\RedisLib::getInstance('manage');
			$queueKey = $queueCommonLib->generateKey('runQue', $funcName, 0);
			echo $count = $redis->lLen($queueKey), "\n";
			if(! $count)
			{
				throw new Exception('队列无数据');
			}
			for($i = 0; $i < $count; $i ++)
			{
				echo $i, ',';
				if(! $info = $redis->lPop($queueKey))
				{
					continue;
				}
				$queueId = intval($info['QueueId']);
				$manualKey = $queueCommonLib->generateKey('manual', $funcName, '', $queueId);
				$cancelKey = $queueCommonLib->generateKey('cancel', $funcName, '', $queueId);
				$restartKey = $queueCommonLib->generateKey('restart', $funcName, '', $queueId);
				if($redis->exists($manualKey))
				{
					$redis->del($manualKey);
					continue;
				}
				elseif($redis->exists($restartKey))
				{
					continue;
				}
				if($redis->exists($cancelKey))
				{
					$redis->del($cancelKey);
					continue;
				}
				$result = $queueFunLib->sendmail($info);
				if($result === true)
				{
					$queueRunLib->updateSuccess($info);
				}
				elseif($result === NULL)
				{
					$queueRunLib->updateFailure($info);
				}
				else
				{
					// 作为批量任务执行后更新成功或者失败次数的依据
					$info['Status'] = $info['Status'] == 3 ? 3 : 5;
					$info['Repeat'] ++;
					if(! $queueRunLib->addRestarQueue($info['QueueId'], $info))
					{
						$queueRunLib->updateFailure($info);
					}
					else
					{
						$queueRunLib->updateResend($info);
					}
				}
			}
			usleep(5000);
		}
		catch(Exception $e)
		{
			echo $e->getMessage(), "\n";
		}
		echo "-----end-----\n";
	}

	/**
	 * 清空短信优先级0的队列
	 */
	public function clearZeroQueueSmsAction()
	{
		echo "----start-----\n";
		$functionName = 'send_sms';
		$queueCommonLib = new \lib\manage\newqueue\QueueCommonLib();
		$redis = \core\RedisLib::getInstance('manage');
		$queueKey = $queueCommonLib->generateKey('runQue', $functionName, 0);
		echo $count = $redis->lLen($queueKey), "\n";
		if(! $count)
		{
			echo "队列无数据\n";
		}
		else
		{
			$redis->del($queueKey);
		}
		echo "-----end-----\n";
	}

	public function reRunNormalgoQueueAction($params = array())
	{
		$num = 0;
		$page = $params ? $params[0] : 200;
		$start = strtotime('2016-09-21 04:00:00');
		$end = strtotime('2016-09-21 09:15:00');
		$logic = new \logic\manage\thrift\QueueLogic();
		while(true)
		{
			$mod = new ModBase('newqueue');
			$limit = $num * $page . "," . $page;
			// 9月21凌晨4点到9点11分之间
			$sql = "select QueueId from e_queue_normal where Function = 'sendmail' and Status = 3 and CreateTime>='$start' and CreateTime<='$end' limit " .
				 $limit;
			$list = $mod->select($sql, "", array());
			if(empty($limit))
			{
				exit("not data");
			}
			$data = array();
			foreach($list as $info)
			{
				echo $info["QueueId"]."\r\n";
				$data[] = $info["QueueId"];
			}
			if($logic->reRunQueueNormal($data))
			{
				echo "rerun success,$limit\r\n";
			}
			else
			{
				echo "rerun failed,$limit\r\n";
			}
			$num ++;
			if($params)
			{
				exit("test end");
			}
		}
	}
}
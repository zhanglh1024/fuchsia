<?php
use core\ModBase;
class SecureController extends Yaf\Controller_Abstract
{
	/** 警报系统临时脚本 */
	
	//域名转入 订单未确认 关联oa:45154
	public function transinCheckAction()
	{
		echo "transinCheck begin\r\n";
		$userMod = new ModBase('user');
		$dnMod = new ModBase('domain');
		$finMod = new ModBase('finance');
		$orderLogic = new \logic\manage\finance\OrderLogic();
		$query = "select * from e_member_secure_warning where BusinessType=7 and Status in (1,2)";
		$secInfo = $userMod->select($query, '', array());
		if(empty($secInfo))
		{
			\core\Log::write('没有域名转入异常警报数据', 'crontemp/secure', 'transincheck');
			exit;
		}
		foreach ($secInfo as $k => $v)
		{
			if(strpos($v['Content'], '入库失败') !== false)
			{
				continue;//需要处理的时订单未确认的情况，入库失败的跳过
			}
			//获取距离警报产生一天内的转入数据
			$query = "select OrderId from e_domain_transfer_in where EnameId='".$v['EnameId']."' and DomainName='".$v['Domain'].
			"' and TransferStatus=8 and UpdateTime<'".date('Y-m-d H:i:s',$v['CreateDate'])."' and UpdateTime>'".date('Y-m-d H:i:s',$v['CreateDate']-24*3600)."'";
			$transinInfo = $dnMod->getRow($query, '', array());
			if(empty($transinInfo['OrderId']))
			{
				\core\Log::write('没有域名转入成功记录【'.$v['EnameId'].'】【'.$v['Domain'].'】', 'crontemp/secure', 'transincheck');
				continue;
			}
			//确认订单是否已经处理过了
			$query = "select * from e_finance_orders where OrderStatus in(1,2) and OrderType=2 and OrderId= ".$transinInfo['OrderId'];
			$orderInfo = $finMod->getRow($query, '', array());
			if(!empty($orderInfo))
			{
				\core\Log::write('订单已经处理过了【OrderId:'.$transinInfo['OrderId'].'】', 'crontemp/secure', 'transincheck');
				continue;
			}
			//获取出款记录
			$query = "select * from e_finance_out where OrderId=".$transinInfo['OrderId'];
			$checkInfo = $finMod->getRow($query, '', array());
			if(empty($checkInfo))
			{
				//确认订单和扣款
				$confirmResult = $orderLogic->confirmOrder((object) array('enameId' => $v['EnameId'], 'orderId' => $transinInfo['OrderId']));
				$msg = $confirmResult == false ? '订单确认成功【'.$transinInfo['OrderId'].'】' : '订单确认失败【'.$transinInfo['OrderId'].'】';
			}
			else 
			{
				//取消订单
				$cancelResult = $orderLogic->cancelOrder((object) array('enameId' => $v['EnameId'], 'orderId' => $transinInfo['OrderId']));
				$msg = $confirmResult == false ? '订单取消成功【'.$transinInfo['OrderId'].'】' : '订单取消失败【'.$transinInfo['OrderId'].'】';
			}
			\core\Log::write($msg, 'crontemp/secure', 'transincheck');
		}
		echo "transinCheck end\r\n";
	}
	//删除警报系统异地登录验证和提醒警报，验证的同用户同ip只保留一条，提醒的同用户同ip同一天只保留两条
	public function delSecLoginInfoAction()
	{
		$userMod = new ModBase('user');
		//删除提醒
		$delStr = "delete from e_member_secure_warning where BusinessType=10 and HandleStatus=4 and Content like '%两次未发送%'";
		$delResult = $userMod->delete($delStr, '', array());
		\core\Log::write('删除多余提醒警报'.($delResult ? '成功' : '失败').'【'.json_encode($v).'】', 'crontemp/secure', 'delseclogininfo');
		//查询验证警报
		$query = "select * from e_member_secure_warning where BusinessType=10 and HandleStatus=3";
		$secInfo = $userMod->select($query, '', array());
		if(empty($secInfo))
		{
			echo '无验证警报信息';
			exit;
		}
		$save = array();
		foreach($secInfo as $k => $v)
		{
			if(in_array($v['EnameId'].'_'.$v['IP'],$save))
			{
				$delStr = "delete from e_member_secure_warning where Id=".$v['Id'];
				$delResult = $userMod->delete($delStr, '', array());
				\core\Log::write('删除多余验证警报'.($delResult ? '成功' : '失败').'【'.json_encode($v).'】', 'crontemp/secure', 'delseclogininfo');
			}
			else 
			{
				$save[] = $v['EnameId'].'_'.$v['IP'];
			}
		}
	}
}
<?php
use lib\manage\domain\DomainLogsLib as DomainLogsLib;
use core\ModBase;
use core\core;
use core\Response;

class TransferinController extends Yaf\Controller_Abstract
{

	private $domainMod;

	private $identityMod;

	private $mod;

	private $domainsmod;

	private $finMod;

	public function init()
	{
		$this->domainMod = new ModBase('domain');
		$this->finMod = new ModBase('finance');
		$this->identityMod = new \models\manage\verify\IdentityVerifyMod();
		$this->mod = new \models\manage\domain\DomainTransferInMod();
		$this->domainsmod = new \models\manage\domain\DomainsMod();
	}

	/**
	 * gd待审核 重新脚本审核
	 */
	public function checkGdDomainAction()
	{
		echo "------start------\n";
		$sql = "select count(*) as count from e_domain_transfer_in where TransferStatus = 9 ";
		$count = $this->domainMod->getOne($sql, array(), array());
		if($count)
		{
			$queueLogic = new \logic\manage\newqueue\QueueLogic();
			$limit = 500;
			$time = date('Y-m-d H:i:s', strtotime('-1 month'));
			$forlimit = ceil($count / $limit);
			for($i = 0; $i < $forlimit; $i ++)
			{
				$sql = 'select * from e_domain_transfer_in where TransferStatus = 9  limit ' . $limit * $i . ',' . $limit;
				$rs = $this->domainMod->select($sql, array(), array());
				foreach($rs as $v)
				{
					// if(self::checkEnameIdIdentity($v['Whois'],
					// $v['DomainName'], $v['EnameId']))
					// {
					// $note = DomainLogsLib::addDomainService($v['DomainName'],
					// '状态还原，系统上次判断bug，程序修复', 2,
					// $v['EnameId']);
					// if(!$note)
					// {
					// \core\Log::write('gd域名' . $v['DomainName'] .
					// 'whois姓名与ID一致，且身份认证通过,添加备注失败',
					// 'crontemp/transferin', 'gddomaintranferin');
					// }
					// if($upDomain =
					// $this->domainsmod->upDomainInfo(array('DomainName' =>
					// $v['DomainName']),
					// array('DomainMyStatus' => 1)))
					// {
					// \core\Log::write('gd域名' . $v['DomainName'] .
					// 'whois姓名与ID一致,更新域名状态DomainMyStatus 成功',
					// 'crontemp/transferin', 'gddomaintranferin');
					// }
					// else
					// {
					// \core\Log::write('gd域名' . $v['DomainName'] .
					// 'whois姓名与ID一致,更新域名状态DomainMyStatus 失败',
					// 'crontemp/transferin', 'gddomaintranferin');
					// }
					
					// $setTransfer = $this->mod->upTransferInfo(
					// array('DomainName' => $v['DomainName'], 'TransferStatus'
					// => 9,
					// 'TransferInId' => $v['TransferInId']),
					// array('TransferStatus' => 8, 'SuccessTime' => date("Y-m-d
					// H:i:s")));
					// if(!$setTransfer)
					// {
					// \core\Log::write('域名' . $v['DomainName'] . '更改转入状态失败,8',
					// 'crontemp/transferin',
					// 'domaintranferin');
					// }
					// else
					// {
					// \core\Log::write('域名' . $v['DomainName'] . '更改转入状态成功,8',
					// 'crontemp/transferin',
					// 'domaintranferin');
					// }
					// }
					// else
					// {
					
					// 判断备注时间 如果是一个月内的有备注 不发邮件
					$sql = 'select * from e_domain_service where ServiceType = 2 and Domain = ? and OperationTime >= ?';
					if($this->domainMod->getRow($sql, 'ss', array($v['DomainName'], $time)))
					{
						\core\Log::write('gd域名' . $v['DomainName'] . '一个月内有备注,不发邮件', 'crontemp/transferin', 
							'gddomaintranferinError');
						continue;
					}
					
					// 添加后台锁定成功后发送邮件
					if($whoidEmail = self::getEmailFromWhoisInfo($v['Whois']))
					{
						try
						{
							$mailData = array(
									'Function' => 'sendmail', 'EnameId' => $v['EnameId'], 
									'TemplateName' => 'gdTransferInCheckFailure', 'Target' => $whoidEmail, 
									'Data' => array('domainName' => $v['DomainName'], 'enameId' => $v['EnameId']), 
									'Priority' => 5);
							$result = $queueLogic->addQueueNormal($mailData);
						}
						catch(\Exception $e)
						{
							\core\Log::write(
								'gd域名' . $v['DomainName'] . '设置域名为后台锁定成功，邮件' . $whoidEmail . '发送失败' . $e->getMessage(), 
								'crontemp/transferin', 'gddomaintranferinError');
							$result = false;
						}
						if(! $result)
						{
							\core\Log::write('gd域名' . $v['DomainName'] . '设置域名为后台锁定成功，邮件' . $whoidEmail . '发送失败', 
								'crontemp/transferin', 'gddomaintranferinError');
						}
						else
						{
							$note = DomainLogsLib::addDomainService($v['DomainName'], '资料不一致，已发邮件通知用户提供材料', 2, 
								$v['EnameId']);
							\core\Log::write('gd域名' . $v['DomainName'] . ' whois邮件' . $whoidEmail . '发送成功', 
								'crontemp/transferin', 'gddomaintranferinSuccess');
						}
					}
					else
					{
						\core\Log::write('gd域名' . $v['DomainName'] . '获取whois邮件失败', 'crontemp/transferin', 
							'gddomaintranferinError');
					}
					// }
				}
			}
		}
		echo "------end------\n";
	}

	/**
	 * 检查用户的身份认证
	 */
	private function checkEnameIdIdentity($whois, $domain, $enameId)
	{
		// 查询用户所有审核通过的身份认证
		$identityList = $this->identityMod->getVerifyInfo(
			array('Type' => 1, 'EnameId' => $enameId, 'VerifyStatus' => 2));
		if(! $identityList)
		{
			\core\Log::write('gd域名' . $domain . '查询用户' . $enameId . '身份认证信息失败', 'crontemp/transferin', 
				'gddomaintranferin');
			return false;
		}
		
		// 匹配whois的联系人信息
		if(! $whoisName = self::getRegistrantNameFromWhoisInfo($whois))
		{
			\core\Log::write('gd域名' . $domain . '匹配whois联系人失败', 'crontemp/transferin', 'gddomaintranferin');
			return false;
		}
		
		// 去掉空格
		$whoisName = strtolower(str_replace(' ', '', $whoisName));
		// 将中文转化为拼音
		$pinyinNameArr = self::getPinyinNames($identityList);
		
		\core\Log::write(
			'gd域名' . $domain . 'whoisName:' . $whoisName . ',get identity check success:' . implode(',', $pinyinNameArr), 
			'crontemp/transferin', 'gddomaintranferin');
		return in_array($whoisName, $pinyinNameArr);
	}

	/**
	 * 获取中文转英文名字
	 *
	 * @param array $identityList        	
	 * @return array
	 */
	private function getPinyinNames($identityList)
	{
		$result = array();
		foreach($identityList as $value)
		{
			$result[] = $value['Name'];
			preg_match_all('/./u', $value['Name'], $chineseNameArr);
			$chineseNameArr = $chineseNameArr[0];
			switch(count($chineseNameArr))
			{
				case 2:
					$result[] = $chineseNameArr[1] . $chineseNameArr[0];
					break;
				case 3:
					$result[] = $chineseNameArr[1] . $chineseNameArr[2] . $chineseNameArr[0];
					$result[] = $chineseNameArr[2] . $chineseNameArr[0] . $chineseNameArr[1];
					break;
				case 4:
					$result[] = $chineseNameArr[2] . $chineseNameArr[3] . $chineseNameArr[0] . $chineseNameArr[1];
					break;
			}
		}
		$chineseToPinyin = new \common\chtopy\ChineseToPinyin();
		foreach($result as $key => $value)
		{
			$result[] = str_replace(' ', '', strtolower($chineseToPinyin->toPinyin($value)));
		}
		return $result;
	}

	/**
	 * 从whois中匹配获取注册者名称
	 *
	 * @return string
	 */
	private function getRegistrantNameFromWhoisInfo($whois)
	{
		$RegistrantName = '';
		$regs = NUll;
		if(preg_match_all("/Registr[ant]*[\s]*[Contact]*[\s]*Name:[\s]*(.*?)(<br[\s\/]*>|[\r\t\n\f]+)+/i", $whois, 
			$regs))
		{
			$RegistrantName = implode(',', $regs['1']);
		}
		return $RegistrantName;
	}

	/**
	 * 从whois中匹配获取whois邮箱
	 *
	 * @return string
	 */
	private function getEmailFromWhoisInfo($whois)
	{
		$Email = '';
		
		// 优先获取registrant email
		if(preg_match("/Registrant[\s]+E[\-]?mail[\s]?:[\s]*([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $whois, $EmailInfo))
		{
			if(! empty($EmailInfo['1']))
			{
				return $EmailInfo['1'];
			}
		}
		
		// 优先获取admin email
		if(preg_match("/(Admin|Administrative)+[\s]+E[\-]?mail[\s]?:[\s]*([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $whois, 
			$EmailInfo))
		{
			if(! empty($EmailInfo['2']))
			{
				return $EmailInfo['2'];
			}
		}
		
		// 优先获取Email Address
		if(preg_match("/E[\-]?mail[\s]?Address:[\s]*([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $whois, $EmailInfo))
		{
			if(! empty($EmailInfo['1']))
			{
				return $EmailInfo['1'];
			}
		}
		
		if(preg_match("/([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $whois, $EmailInfo))
		{
			$Email = $EmailInfo['1'];
		}
		
		if($Email == 'support@propersupport.com')
		{
			if(preg_match("/[Registrant:](.*)[\(]{1}([\w.%-]+@[\w.-]+\.[a-z]{2,4})/i", $whois, $EmailInfo))
			{
				$Email = $EmailInfo['2'];
			}
		}
		
		if(stripos($Email, 'abuse@') !== FALSE)
		{
			$Email = '';
		}
		return $Email;
	}

	/**
	 * wang底层问题，转入数据修复：
	 * 针对转入失败和邮件同意转入的，做检测5028如果为pending或者approved，则需要重新改为正在转入或者直接入库
	 * 1.
	 * 邮件同意转入的，转入状态改为正在转入即可
	 * 2. 转入失败的，状态改为正在转入且需要做人工冻结并更新转入表的订单id
	 */
	public function fixWangTransfer3Action()
	{
		$sql = "select count(*) as count from e_domain_transfer_in where RegistrarId = 86 and TransferStatus in(3,7) ";
		$count = $this->domainMod->getOne($sql, array(), array());
		if($count)
		{
			$domainEppLib = new \lib\manage\domain\DomainEppLib();
			$domains = array();
			$sql = "select TransferInId,DomainName,EnameId,TransferStatus,RegistrarId,Password,OrderId from e_domain_transfer_in where RegistrarId = 86 and TransferStatus in(3,7) order by TransferInId desc limit 1";
			$rs = $this->domainMod->select($sql, array(), array());
			$orderLib = new \interfaces\manage\Finance();
			$memberLib = new \lib\manage\member\MemberLib();
			foreach($rs as $v)
			{
				echo $v['DomainName'] . "\r\n";
				\core\Log::write($v['DomainName'] . "|||" . json_encode($v), 'crontemp/transferin', 
					'fixWangTransfer3_bakup');
				$rsOne = $this->domainMod->getOne(
					"select DomainName from e_domain_transfer_in where DomainName = '" . $v['DomainName'] .
						 "' and RegistrarId = 86 and (TransferStatus <= 2 or TransferStatus in(6,8,9,10))", array(), array());
				if($rsOne)
				{
					\core\Log::write($v['TransferInId'] . "," . $v['DomainName'], 'crontemp/transferin', 
						'fixWangTransfer3_hasnew');
					continue;
				}
				if(isset($domains[$v['DomainName']]))
				{
					$domains[$v['DomainName']] ++;
					continue;
				}
				else
				{
					$domains[$v['DomainName']] = 1;
					\core\Log::write($v['TransferInId'] . "," . $v['DomainName'], 'crontemp/transferin', 
						'fixWangTransfer3_re');
				}
				$info = $domainEppLib->getDomainRegTransInfo($v['DomainName'], $v['RegistrarId'], FALSE, $v['Password']);
				// var_dump($info);exit;
				if($info['resultCode'] != 1000 || ! isset($info['status']) ||
					 FALSE !== stripos($info['status'], 'Rejected'))
				{
					if(3 == $v['TransferStatus'])
					{
						\core\Log::write($v['TransferInId'] . "," . $v['DomainName'], 'crontemp/transferin', 
							'fixWangTransfer3_tosetfail');
					}
					else
					{
						\core\Log::write($v['TransferInId'] . "," . $v['DomainName'], 'crontemp/transferin', 
							'fixWangTransfer3_noneed');
					}
				}
				elseif(strtoupper($info['status']) == 'PENDING' || FALSE !== stripos($info['status'], 'Approved'))
				{
					if(7 == $v['TransferStatus'])
					{
						// 创建新订单，转入状态改为正在转入，更新转入表的订单id，订单隐藏备注oa号
						// \core\Log::write($v['TransferInId'] . "," .
						// $v['DomainName'] . "," . $v['TransferStatus'] . "," .
						// $v['EnameId'], 'crontemp/transferin',
						// 'fixWangTransfer3_ispending_7');
						$memberInfo = $memberLib->getMemberInfoByEnameId($v['EnameId']);
						if(! $memberInfo)
						{
							echo "notmember";
							continue;
						}
						$productType = \lib\manage\common\DomainFunLib::getDomainProductType($v['DomainName']);
						$domainsArr = array(
								'domain' => $v['DomainName'], 'enameId' => $v['EnameId'], 'year' => 1, 'promoCode' => '', 
								'productName' => '.wang', 'userGroupId' => $memberInfo['UserGroup'], 
								'productType' => $productType, 'type' => 2, 'remark' => '', 
								'registarId' => $v['RegistrarId']);
						// var_dump($domainsArr);
						$orderInfo = $orderLib->addProductOrder((object) $domainsArr);
						var_dump($orderInfo);
						if(FALSE == $orderInfo)
						{
							\core\Log::write(
								$v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," .
									 $v['EnameId'] . "," . Response::getErrCode() . ":" . Response::getErrMsg(), 
									'crontemp/transferin', 'fixWangTransfer3_ispending_7_ordererr');
						}
						else
						{
							$upRs = $this->domainMod->update(
								"update e_domain_transfer_in set TransferStatus = 6, OrderId = " . $orderInfo .
									 " where DomainName = '" . $v['DomainName'] . "' and TransferInId = " .
									 $v['TransferInId'] . " and enameid = " . $v['EnameId'], array(), array());
							if($upRs)
							{
								\core\Log::write(
									$v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," .
										 $v['EnameId'], 'crontemp/transferin', 'fixWangTransfer3_ispending_7_upsuc');
							}
							else
							{
								\core\Log::write(
									$v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," .
										 $v['EnameId'], 'crontemp/transferin', 'fixWangTransfer3_ispending_7_uperr');
							}
						}
					}
					else
					{
						// 转入状态改为正在转入即可
						$upRs = $this->domainMod->update(
							"update e_domain_transfer_in set TransferStatus = 6 where DomainName = '" . $v['DomainName'] .
								 "' and TransferInId = " . $v['TransferInId'] . " and enameid = " . $v['EnameId'], 
								array(), array());
						if($upRs)
						{
							\core\Log::write(
								$v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," .
									 $v['EnameId'], 'crontemp/transferin', 'fixWangTransfer3_ispending_3_upsuc');
						}
						else
						{
							\core\Log::write(
								$v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," .
									 $v['EnameId'], 'crontemp/transferin', 'fixWangTransfer3_ispending_3_uperr');
						}
					}
				}
				else
				{
					\core\Log::write(
						$v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," . $v['EnameId'], 
						'crontemp/transferin', 'fixWangTransfer3_other');
				}
			}
		}
	}

	/**
	 * 域名实际已转入且确认订单但是转入状态为"正在转入"状态修复
	 */
	public function repairTransInStatusAction()
	{
		echo "--begin--\r\n";
		$query = "select * from e_domain_transfer_in where TransferStatus=6 and UpdateTime>='2015-11-24 15:00:00' and UpdateTime<='2015-11-25 12:00:00'";
		$dnInfo = $this->domainMod->select($query, '', array());
		foreach($dnInfo as $v)
		{
			echo $v['DomainName'] . "\r\n";
			if(empty($v['OrderId']))
			{
				echo $v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," . $v['EnameId'] .
					 ",无订单ID\r\n";
				\core\Log::write(
					$v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," . $v['EnameId'] .
						 ",无订单ID", 'crontemp/transferin', 'repairdntransinstatus');
				continue;
			}
			$query = "select count(*) from e_domains where DomainName='" . $v['DomainName'] . "'";
			$domainInDb = $this->domainMod->getOne($query, '', array());
			if(empty($domainInDb))
			{
				echo $v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," . $v['EnameId'] .
					 ",域名暂未入库\r\n";
				\core\Log::write(
					$v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," . $v['EnameId'] .
						 ",域名暂未入库", 'crontemp/transferin', 'repairdntransinstatus');
				continue;
			}
			$query = "select count(*) from e_finance_orders where OrderStatus=1 and OrderId=" . $v['OrderId'];
			$orderInfo = $this->finMod->getOne($query, '', array());
			if(empty($orderInfo))
			{
				echo $v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," . $v['EnameId'] .
					 ",订单非成功状态\r\n";
				\core\Log::write(
					$v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," . $v['EnameId'] .
						 ",订单非成功状态", 'crontemp/transferin', 'repairdntransinstatus');
				continue;
			}
			$query = "update e_domain_transfer_in set TransferStatus=8 where TransferInId=" . $v['TransferInId'];
			$upResult = $this->domainMod->update($query, '', array());
			$msg = $v['TransferInId'] . "," . $v['DomainName'] . "状态更新" . ($upResult ? "成功" : "失败");
			echo $msg . "\r\n";
			\core\Log::write($msg, 'crontemp/transferin', 'repairdntransinstatus');
		}
		echo "--end--\r\n";
	}

	/**
	 * 域名转入，自动邮件确认和提交转入处理
	 */
	public function submitTransferAction()
	{
		set_time_limit(0);
		ini_set("display_errors", "on");
		error_reporting(E_ALL);
		$enameId = 1047624;
		$whereext = " enameid = $enameId and TransferStatus=2";
		$sql = "select count(*) as count from e_domain_transfer_in where " . $whereext;
		$count = $this->domainMod->getOne($sql, array(), array());
		var_dump($count);
		if($count)
		{
			$domainEppLib = new \lib\manage\domain\DomainEppLib();
			$domains = array();
			$sql = "select TransferInId,DomainName,EnameId,TransferStatus,RegistrarId,Password,OrderId,CreateTime,MailCode from e_domain_transfer_in where " .
				 $whereext . " ";
			$rs = $this->domainMod->select($sql, array(), array());
			$orderLib = new \interfaces\manage\Finance();
			$memberLib = new \lib\manage\member\MemberLib();
			$datetime = date('Y-m-d H:i:s');
			$donn = 0;
			foreach($rs as $v)
			{
				// if(date('H') >=2 && date('H') < 5) exit('no fit time...');
				echo $donn ++ . "--" . $v['DomainName'] . "\r\n";
				\core\Log::write($v['DomainName'] . "|||" . json_encode($v), 'crontemp/transferin', 
					'submitTransfer_bakup');
				$this->transferMail($enameId, $v, $datetime);
			}
		}
	}

	/**
	 * 域名转入邮件确认和转入提交
	 */
	private function transferMail($enameId, $info, $datetime, $transferStatus = 3)
	{
		$sql = "select Year,TransferInId,DomainName,EnameId,TransferStatus,RegistrarId,Password,OrderId,CreateTime,MailCode from e_domain_transfer_in where TransferInId = " .
			 $info['TransferInId'];
		$info = $this->domainMod->getRow($sql, array(), array());
		$mailCode = $info['MailCode'];
		$domain = $info['DomainName'];
		if($info['TransferStatus'] == 1 || $info['TransferStatus'] > 2 || ! in_array($info['TransferStatus'], 
			array(- 2, 2)))
		{
			\core\Log::write($info['DomainName'] . "|||" . json_encode($info), 'crontemp/transferin', 
				'submitTransfer_nostatus_1');
			// return false;
		}
		// update status
		$id = $info['TransferInId'];
		$oldStatus = $info['TransferStatus'];
		if(! $this->updateStatus($domain, $id, $transferStatus, $oldStatus, $enameId, $datetime))
		{
			return false;
		}
		$returnInfo = $this->doSubmitTransfer($info['DomainName'], $info['Password'], $info['Year']);
		var_dump($returnInfo);
		\core\Log::write($info['DomainName'] . "|||" . json_encode($returnInfo), 'crontemp/transferin', 
			'submitTransfer_do_return');
		if(! $returnInfo || $returnInfo['resultCode'] != 5000)
		{
			$regultMsg = $returnInfo['data']['msg']['resultMsg'];
			if(is_string($regultMsg) && stripos($regultMsg, 'pending') !== false)
			{
				\core\Log::write($info['DomainName'] . "|||" . json_encode($returnInfo), 'crontemp/transferin', 
					'submitTransfer_do_return_pending');
				return false;
			}
			$intCode = $this->formatDomainTransferInfo($returnInfo);
			$this->updateStatus($domain, $id, ($intCode == 1) ? 1 : - 2, 3, $enameId, $datetime);
			\lib\manage\domain\DomainLogsLib::addDomainLog($domain, $enameId, 2, $info, $returnInfo, '国际域名域名申请转入验证失败', 
				0, '117.65.254.239', 'http://www.ename.net/transfermail/action/' . $mailCode . '/3');
			\core\Log::write($info['DomainName'] . "," . $intCode . "|||" . json_encode($returnInfo), 
				'crontemp/transferin', 'submitTransfer_do_return_fail');
			return false;
		}
		$this->updateStatus($domain, $id, 6, 3, $enameId, $datetime);
		// ($domain, $enameId, $logType, $sendData, $returnData, $logDesc,
		// $isSuccess = 1)
		\lib\manage\domain\DomainLogsLib::addDomainLog($domain, $enameId, 2, $info, $returnInfo, '同意转入 操作成功', 1, 
			'117.65.254.239', 'http://www.ename.net/transfermail/action/' . $mailCode . '/3');
		return true;
	}

	/**
	 * 更新域名转入状态
	 */
	private function updateStatus($domain, $id, $transferStatus, $oldStatus, $enameId, $datetime)
	{
		$where = "DomainName = '" . $domain . "' and TransferInId = " . $id . " and enameid = " . $enameId .
			 " and TransferStatus = " . $oldStatus;
		$set = "TransferStatus = " . $transferStatus . ", UpdateTime = '" . $datetime . "'";
		// echo "update e_domain_transfer_in set " . $set . " where " . $where;
		$upRs = $this->domainMod->update("update e_domain_transfer_in set " . $set . " where " . $where, array(), array());
		if($upRs)
		{
			\lib\manage\domain\DomainLogsLib::addDomainService($domain, 
				json_encode(array('memo' => 'update database', 'where' => $where, 'set' => $set, 'retrun' => $upRs)), 11);
			\core\Log::write($domain . ',' . $transferStatus . ',' . $oldStatus, 'crontemp/transferin', 
				'submitTransfer_upto' . $transferStatus . '_suc');
			return true;
		}
		else
		{
			\core\Log::write($domain . ',' . $transferStatus . ',' . $oldStatus, 'crontemp/transferin', 
				'submitTransfer_upto' . $transferStatus . '_fail');
			return false;
		}
	}

	/**
	 * 提交注册局域名转入
	 */
	private function doSubmitTransfer($domain, $password, $period)
	{
		$param = array('domain' => $domain, 'password' => $password, 'period' => $period);
		$subInfo = $this->sdk->execSdkFun(5005, $param);
		\lib\manage\domain\DomainLogsLib::addDomainService($domain, 
			json_encode(array('memo' => 'transfer_in', 'param' => $param, 'return' => $subInfo)), 11);
		return $subInfo;
	}

	/**
	 * 格式化域名转入的错误信息
	 *
	 * @param array $info        	
	 * @return int
	 */
	private function formatDomainTransferInfo($info)
	{
		if($info['resultCode'] == 5019)
		{
			if(is_string($info['data']['msg']['resultMsg']))
			{
				$msg = $info['data']['msg']['resultMsg'];
				if(stripos($msg, 'Authorization error') !== false ||
					 stripos($msg, 'Invalid authorization information') !== false ||
					 stripos($msg, 'Authentication error') !== false)
				{
					return 1;
				}
				if(stripos($msg, 'Object status prohibits') !== false)
				{
					return 2;
				}
				if(stripos($msg, 'out of service') !== false)
				{
					return 3;
				}
			}
		}
		return $info['resultCode'];
	}

	/**
	 * 临时批量更改域名转移密码
	 */
	public function setTransferPassAction()
	{
		$domainMod = new ModBase('domain');
		$file = fopen("/tmp/1047624_isnew.log", "r");
		// $file = fopen("/tmp/rightpassword.txt", "r");
		if(! $file)
		{
			exit("打开文件失败");
		}
		$enameId = 1047624;
		$checkStatus = 1; // password error
		$donn = 0;
		while(! feof($file))
		{
			$domainPass = trim(fgets($file));
			if(! $domainPass)
			{
				continue;
			}
			$domainArr = explode("==", $domainPass);
			$domainName = $domainArr[0];
			$password = $domainArr[1];
			echo $donn ++ . "--" . $domainName . "\r\n";
			// if($donn >1) break;
			$transferSql = "select TransferInId,Password,TransferStatus from e_domain_transfer_in where DomainName = '$domainName' and TransferStatus in(-2,1,2) and EnameId='$enameId'";
			$transferInfo = $domainMod->select($transferSql, '', array());
			var_dump($transferInfo);
			if(empty($transferInfo))
			{
				echo "$domainName,not found right records\r\n";
				error_log($domainPass . "\r\n", 3, "/tmp/1047624_error_no.log");
				continue;
			}
			if(count($transferInfo) > 1)
			{
				echo "$domainName,not found right records\r\n";
				error_log($domainPass . "\r\n", 3, "/tmp/1047624_error_repeat.log");
				continue;
			}
			$transferId = $transferInfo[0]['TransferInId'];
			$password = addslashes($password);
			$upTransferSql = "update e_domain_transfer_in set TransferStatus=2,Password='$password',UpdateTime='" .
				 date('Y-m-d H:i:s') . "' where EnameId='$enameId' and TransferInId=$transferId";
			echo $upTransferSql;
			if($password == $transferInfo[0]['Password'])
			{
				error_log($domainPass . "\r\n", 3, "/tmp/1047624_error_thesame1.log");
				continue;
			}
			error_log($domainPass . "\r\n", 3, "/tmp/1047624_isnew1.log");
			if(! $domainMod->update($upTransferSql, '', array()))
			{
				echo "$domainName,update transferstatus failed\r\n";
				error_log($domainPass . "\r\n", 3, "/tmp/1047624_error_update.log");
				continue;
			}
			echo "$domainName,update success";
			error_log($domainPass . "\r\n", 3, "/tmp/1047624_success.log");
		}
		fclose($file);
	}

	/**
	 * 转入失败，订单冻结解冻
	 */
	public function inOrderCheckAction()
	{
		$happenDate = '2015-09-28 00:00:00';
		$endDate = '2015-09-30 00:00:00';
		$mod = new ModBase('domain');
		$finmod = new ModBase('finance');
		$orderLib = new \interfaces\manage\Finance();
		$query = "select TransferInId,DomainName,EnameId,OrderId from e_domain_transfer_in where TransferStatus=7 and UpdateTime>='" .
			 $happenDate . "' and UpdateTime<='" . $endDate . "'";
		echo $query;
		$dnList = $this->domainMod->select($query, '', array());
		$data = array();
		$dnn = 0;
		foreach($dnList as $info)
		{
			if($dnn ++ > 1)
				break;
			$enameId = $info['EnameId'];
			$domain = $info['DomainName'];
			$orderId = $info['OrderId'];
			echo $dnn . "--" . $enameId . "--" . $domain . "--" . $orderId . "\r\n";
			
			$orderInfo = $finmod->getRow(
				"select orderid from e_finance_orders where orderid = $orderId and orderstatus = 3", '', array());
			if($orderInfo)
			{
				\core\Log::write($domain, 'crontemp/transferin', 'inOrderCheck_1203_need');
				continue;
				$orderRs = $orderLib->cancelOrder((object) array('enameId' => $enameId, 'orderId' => $orderId));
				var_dump($orderRs);
				if(FALSE == $orderRs)
				{
					\core\Log::write($domain, 'crontemp/transferin', 'inOrderCheck_1203_suc');
				}
				else
				{
					\core\Log::write($domain, 'crontemp/transferin', 'inOrderCheck_1203_fail');
				}
			}
			else
			{
				\core\Log::write($domain, 'crontemp/transferin', 'inOrderCheck_1203_noneed');
			}
		}
	}

	public function bacthOrderAction()
	{
		$where = "from e_domain_transfer_in where enameid = 1017186 and CreateTime >='2016-01-19 15:00' and CreateTime <='2016-01-20 18:00:00' and orderid = 0";
		$sql = "select count(*) as count " . $where;
		$count = $this->domainMod->getOne($sql, array(), array());
		if($count)
		{
			$domains = array();
			$sql = "select TransferInId,DomainName,EnameId,TransferStatus,OrderId " . $where . "  ";
			$rs = $this->domainMod->select($sql, array(), array());
			$orderLib = new \interfaces\manage\Finance();
			$productType = \lib\manage\common\DomainFunLib::getDomainProductType('yhnx.net.cn');
			foreach($rs as $v)
			{
				echo $v['DomainName'] . "\r\n";
				\core\Log::write($v['DomainName'] . "|||" . json_encode($v), 'crontemp/transferin', 'bacthOrder');
				$rsOne = $this->domainMod->getOne("select DomainName " . $where . " and TransferStatus =7 ", array(), 
					array());
				if($rsOne)
				{
					\core\Log::write($v['TransferInId'] . "," . $v['DomainName'], 'crontemp/transferin', 
						'bacthOrder_isfailed');
					continue;
				}
				
				// 创建新订单，更新转入表的订单id，订单隐藏备注oa号
				// \core\Log::write($v['TransferInId'] . "," . $v['DomainName']
				// . "," . $v['TransferStatus'] . "," . $v['EnameId'],
				// 'crontemp/transferin', 'fixWangTransfer3_ispending_7');
				$domainsArr = array(
						'domain' => $v['DomainName'], 'enameId' => $v['EnameId'], 'year' => 1, 'promoCode' => '', 
						'productName' => '.net.cn', 'userGroupId' => 2, 'productType' => $productType, 'type' => 2, 
						'remark' => '', 'registarId' => 1);
				var_dump($domainsArr);
				exit();
				$orderInfo = $orderLib->addProductOrder((object) $domainsArr);
				var_dump($orderInfo);
				if(FALSE == $orderInfo)
				{
					\core\Log::write(
						$v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," . $v['EnameId'] .
							 "," . Response::getErrCode() . ":" . Response::getErrMsg(), 'crontemp/transferin', 
							'bacthOrder_ordererr');
				}
				else
				{
					\core\Log::write(
						$v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," . $v['EnameId'] .
							 "," . $orderInfo . "," . Response::getErrCode() . ":" . Response::getErrMsg(), 
							'crontemp/transferin', 'bacthOrder_ordersuc');
					
					$upRs = $this->domainMod->update(
						"update e_domain_transfer_in set OrderId = " . $orderInfo . " where DomainName = '" .
							 $v['DomainName'] . "' and TransferInId = " . $v['TransferInId'] . " and enameid = " .
							 $v['EnameId'], array(), array());
					if($upRs)
					{
						\core\Log::write(
							$v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," .
								 $v['EnameId'], 'crontemp/transferin', 'bacthOrder_upsuc');
					}
					else
					{
						\core\Log::write(
							$v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," .
								 $v['EnameId'], 'crontemp/transferin', 'bacthOrder_uperr');
					}
				}
			}
		}
	}

	/**
	 * 导出域名转入列表的那些待审核的，找出状态是为交易锁定的域名，写到日志．
	 */
	public function transferinStatusCheckAction()
	{
		$logMes = "\n";
		$caculate = 0;
		$domainMod = new \models\manage\domain\DomainsMod();
		$transferInMod = new \models\manage\domain\DomainTransferInMod();
		$count = $transferInMod->getTransferCount(array('in' => array('TransferStatus' => array(9, 10, 11)))); // 取出域名转入列表的那些待审核的
		                                                                                                       // 9
		                                                                                                       // 10
		                                                                                                       // 11
		for($i = 0; $i <= $count['total'] / 500; $i ++)
		{
			$limit = $i * 500 . ',500';
			$transferinList = $transferInMod->getTransferInfo(
				array('in' => array('TransferStatus' => array(9, 10, 11)), 'limit' => $limit), 
				'DomainName,TransferStatus', false); // 获取转入列表中带审核状态的记录
			foreach($transferinList as $key => $value)
			{
				$domainRow = $domainMod->getDomainInfo(array('DomainName' => $value['DomainName']), 'DomainMyStatus'); // 匹配下，域名表的域名状态是否为交易锁定
				                                                                                                       // 14
				if($domainRow && $domainRow['DomainMyStatus'] != 14)
				{
					$logMes .= '[ DomainName: ] [' . $value['DomainName'] . ' ] [ TransferStatus:' .
						 $value['TransferStatus'] . ' ] [ DomainMyStatus:' . $domainRow['DomainMyStatus'] . ' ] ' . "\n";
					$caculate ++;
				}
			}
		}
		$logMes .= "---" . 'Total Domains :' . $caculate;
		\core\Log::write($logMes, 'transferinStatusCheck', 'ErroDomains');
	}

	/**
	 * 导出域名实际已转入，但是订单冻结的 订单号和域名
	 */
	public function getTransInBadorderAction()
	{
		echo "--begin--\r\n";
		$cquery = "select count(*) from e_domain_transfer_in where TransferStatus>=8 and SuccessTime>='2016-01-01 00:00:00'";
		$count = $this->domainMod->getOne($cquery, '', array());
		for($i = 0; $i < $count / 500; $i ++)
		{
			$begin = $i * 500;
			$query = "select * from e_domain_transfer_in where TransferStatus>=8 and SuccessTime>='2016-01-01 00:00:00' limit " .
				 $begin . ",500";
			$dnInfo = $this->domainMod->select($query, '', array());
			foreach($dnInfo as $v)
			{
				if(empty($v['OrderId']))
				{
					echo $v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," . $v['EnameId'] .
						 ",无订单ID\r\n";
					continue;
				}
				$query = "select count(*) from e_domains where DomainName='" . $v['DomainName'] . "'";
				$domainInDb = $this->domainMod->getOne($query, '', array());
				if(empty($domainInDb))
				{
					echo $v['TransferInId'] . "," . $v['DomainName'] . "," . $v['TransferStatus'] . "," . $v['EnameId'] .
						 ",域名未入库\r\n";
					continue;
				}
				$query = "select count(*) from e_finance_orders where OrderStatus=3 and OrderId=" . $v['OrderId'];
				$orderInfo = $this->finMod->getOne($query, '', array());
				if(! empty($orderInfo))
				{
					$msg = $v['OrderId'] . "," . $v['DomainName'];
					\core\Log::write($msg, 'crontemp/transferin', 'getTransInBadorder');
				}
			}
		}
		echo "\r\n--end--\r\n";
	}

	/**
	 * 修复域名实际已转入但是订单冻结的订单
	 */
	public function getTrInBadorderAction()
	{
		echo "--begin--\r\n";
		$cquery = "select count(*) from e_finance_orders where OrderStatus=3 and OrderType=2  and UpdateTime>='2016-01-01 00:00:00'";
		$count = $this->finMod->getOne($cquery, '', array());
		for($i = 0; $i < $count / 500; $i ++)
		{
			$begin = $i * 500;
			$query = "select * from e_finance_orders where OrderStatus=3 and OrderType=2 and UpdateTime>='2016-01-01 00:00:00' limit " .
				 $begin . ",500";
			$OrderInfo = $this->finMod->select($query, '', array());
			foreach($OrderInfo as $v)
			{
				$transferinQuery = "select * from e_domain_transfer_in where DomainName = '" . $v['Domain'] .
					 "' and TransferStatus>=8 and OrderId = " . $v['OrderId'];
				$dnInfo = $this->domainMod->getRow($transferinQuery, '', array());
				if($dnInfo)
				{
					$dmQuery = "select count(*) from e_domains where DomainName='" . $v['Domain'] . "'";
					$domainInDb = $this->domainMod->getRow($dmQuery, '', array());
					if(empty($domainInDb))
					{
						echo $dnInfo['TransferInId'] . "," . $dnInfo['DomainName'] . "," . $dnInfo['TransferStatus'] .
							 "," . $dnInfo['EnameId'] . ",域名未入库\r\n";
						continue;
					}
					$updateQuery = "update e_finance_orders set OrderStatus=1 where OrderId = " . $v['OrderId'];
					$update = false; // $this->finMod->update($updateQuery, '',
					                 // array());//不直接更新订单，而是要confirm订单的，先跑出来再人工确认
					if(false == $update)
					{
						$msg = $dnInfo['OrderId'] . "," . $dnInfo['DomainName'] . ", 订单更新出错\r\n";
						echo $msg;
						\core\Log::write($msg, 'crontemp/transferin', 'getTrInBadorder');
					}
				}
			}
		}
		echo "\r\n--end--\r\n";
	}

	private function transferOrderDone($domain, $orderId, $enameId)
	{
		$finance = new \interfaces\manage\Finance();
		$status = $finance->cancelOrder((object) array('orderId' => $orderId, 'enameId' => $enameId));
		if(! $status)
		{
			error_log("{$domain},{$orderId},{$enameId},cancel order failed\r\n", 3, "/tmp/spcialtransfer.log");
			echo "$domain,$orderId,$enameId,cancel order failed\r\n";
		}
	}
	
	
	public function getBusinessCodeAction()
	{
		ini_set("display_errors", "On");
		error_reporting(E_ALL);
		$enameId = "941703";
		$file = fopen("/tmp/941703" . "_transferin.log", "r");
		if(! $file)
		{
			exit("打开文件失败");
		}
		$bus = array();
		while(! feof($file))
		{
			$domainPass = trim(fgets($file));
			if(! $domainPass)
			{
				continue;
			}
			$domainPass = explode(",", $domainPass);
			$domainName = $domainPass[0];
			$bus[] = $domainName;
		}
		fclose($file);
		while(true)
		{
			$domains = array();
			if(!$bus)
			{
				break;
			}
			$vspLogic = new \logic\manage\thrift\VspLogic();
			$domains = array_splice($bus, 0, 100);
			$return = $vspLogic->getDomainBusinessCodeBatch($domains);
			print_r($return);
			sleep(1);
		}
	}
	
	// 手动转入
	// 防止出现垃圾记录 先底层接口在写表
	public function specialTransferInAction()
	{
		ini_set("display_errors", "On");
		error_reporting(E_ALL);
		$enameId = "941703";
		$file = fopen("/tmp/941703" . "_transferin.log", "r");
		if(! $file)
		{
			exit("打开文件失败");
		}
		$regid = 21; // 根据实际后缀来
		$transferLib = new \lib\manage\domain\DomainTransferInLib($enameId);
		$finance = new \interfaces\manage\Finance();
		$saveLtd = 3;
		$templateId = 768898;
		$dnsType = 1;
		$templateName = "ename_o1asdwc8hr";
		$transfermod = new \models\manage\domain\DomainTransferInMod();
		while(! feof($file))
		{
			$transferstatus = null;
			$domainPass = trim(fgets($file));
			if(! $domainPass)
			{
				continue;
			}
			$domainPass = explode(",", $domainPass);
			$domainName = $domainPass[0];
			$password = $domainPass[1];
			
			// 转入表
			$status = $transferLib->checkIsOkToAdd($domainName, FALSE);
			if($status !== true)
			{
				error_log($password . "," . $domainName . ",alread transfering\r\n", 3, "/tmp/spcialtransfer.log");
				echo $password . "," . $domainName . ",alread transfering\r\n";
				//$this->transferOrderDone($domainName, $orderId, $enameId);
				continue;
			}
			
			$productName = \lib\manage\common\DomainFunLib::getDomainClassAll($domainName);
			// 先订单
			$productType = \lib\manage\common\DomainFunLib::getDomainProductType($domainName);
			$createInfo = array(
					"enameId" => $enameId, "productName"=>".".$productName,"userGroupId"=>2,"productType" => $productType, "domain" => $domainName, "year" => 1, 
					"type" => "2", "remarkHide" => " NO.62265  ID：941703 域名转入", "registarId" => $regid);
			$orderId = $finance->addProductOrder((object) $createInfo);
			if(! $orderId || ! is_numeric($orderId))
			{
				error_log($password . "," . $domainName . ",create order failed\r\n", 3, "/tmp/spcialtransfer.log");
				echo $password . "," . $domainName . ",create order failed\r\n";
				continue;
			}
			$vspLogic = new \logic\manage\thrift\VspLogic();
			$eppLogic = new \logic\manage\thrift\EppLogic();
			$transferReturn = $eppLogic->domainTransferIn($domainName, $password, 1, $templateName,$vspLogic->getDomainBusinessCode($domainName));
			if($transferReturn['resultCode'] == 5000)
			{
				try
				{
					$redis = \core\RedisLib::getInstance('manage');
					$redis->delete("ename_shimingzhi" . $domainName);
				}
				catch(Exception $e)
				{
					echo $e->getMessage() . "\r\n";
				}
				$transferstatus = "6"; // 正在转入
			}
			else if($transferReturn['resultCode'] == 5019 && stripos($transferReturn["data"]["msg"]["resultMsg"], 'auditing') !==false)
			{
				$transferstatus = "3"; // 邮件同意转入
			}
			if(isset($transferstatus))
			{
				$insertData = array(
						'DomainName' => $domainName, 'EnameId' => $enameId, 'SubmitIp' => '127.0.0.1', 'OrderId' => $orderId,
						'TemplateId' => $templateId, 'Year' => 1, 'ProductType' => $productType, 'DnsStatus' => $dnsType,
						'Password' => $password, 'TransferStatus' => $transferstatus, 'CreateTime' => date('Y-m-d H:i:s'),'UpdateTime'=>date('Y-m-d H:i:s'),
						'DomainLtd' => $saveLtd, 'RegistrarId' => $regid);
				if(FALSE == $transfermod->addTransferIn($insertData))
				{
					error_log($password . "," . $domainName . ",add table failed\r\n", 3, "/tmp/spcialtransfer.log");
					continue;
				}
				echo $password . "," . $domainName.",transferin success\r\n";
			}
			else
			{
				echo $password . "," . $domainName.",transferin failed\r\n";
				$this->transferOrderDone($domainName, $orderId, $enameId);
			}
			sleep(2);
		}
		fclose($file);
	}

	/**
	 * oa63499
	 * 15天转入退单处理失败回滚处理
	 * 检测转入是否存在新记录，无则重新冻结并将转入状态还原回去
	 */
	public function fixFifteenTransferAction()
	{
		$file = fopen("/home/yangyf/order2", "r");
		if(!$file)
		{
			exit("打开文件失败");
		}
		$donn = 0;
		$orderLib = new \interfaces\manage\Finance();
		while(!feof($file))
		{
			// -5, 7, 30528559
			$line = trim(fgets($file));
			if(!$line)
			{
				continue;
			}
			$lines = explode(',', $line);
			$orderId = trim($lines[2]);
			$status = trim($lines[0]);
			echo $donn++ . '---' . $orderId . ',' . $status . "\r\n";
			if($donn > 1) exit('test over');
			$info = $this->domainMod->getRow(
				"select TransferInId,DomainName,CreateTime,OrderId,EnameId,RegistrarId from e_domain_transfer_in where orderid = $orderId and TransferStatus = 7", array(), array());
			var_dump($info);
			if(!$info)
			{
				\core\Log::write($line, 'crontemp/transferin', 'fixFifteenTransfer_noinfo');
				continue;
			}
			$domain = $info['DomainName'];
			echo $domain . "\r\n";
			// 检测是否存在最新转入记录
			$newInfo = $this->domainMod->getRow(
				"select TransferInId from e_domain_transfer_in where domainname = '" . $domain . "' and CreateTime > '" .
					 $info['CreateTime'] . "' order by TransferInId desc", array(), array());
			var_dump($newInfo);
			if($newInfo)
			{
				\core\Log::write($line, 'crontemp/transferin', 'fixFifteenTransfer_hasnew');
				continue;
			}
			// 否则重新生成订单并更新转入状态和orderid
			$productType = \lib\manage\common\DomainFunLib::getDomainProductType($domain);
			$productName = \lib\manage\common\DomainFunLib::getDomainClassAll($domain);
			$domainsArr = array('domain' => $domain,'enameId' => $info['EnameId'],'year' => 1,'promoCode' => '',
				'productName' => '.' . $productName,'userGroupId' => 2,'productType' => $productType,'type' => 2,
				'remark' => '', 'remarkHide' =>'oa63499', 'registarId' => $info['RegistrarId']);
			var_dump($domainsArr);
			continue;
			$orderInfo = $orderLib->addProductOrder((object)$domainsArr);
			var_dump($orderInfo);
			if(FALSE == $orderInfo)
			{
				\core\Log::write($line, 'crontemp/transferin', 'fixFifteenTransfer_orderfail');
			}
			else
			{
				\core\Log::write($line, 'crontemp/transferin', 'fixFifteenTransfer_ordersuc');
				$upSql = "update e_domain_transfer_in set TransferStatus = $status, OrderId = " . $orderInfo .
					 " where DomainName = '" . $domain . "' and TransferInId = " . $info['TransferInId'] .
					 " and enameid = " . $info['EnameId'];
				$upRs = $this->domainMod->update($upSql, array(), array());
				if($upRs)
				{
					\core\Log::write($upSql, 'crontemp/transferin', 'fixFifteenTransfer_upsuc');
				}
				else
				{
					\core\Log::write($upSql, 'crontemp/transferin', 'fixFifteenTransfer_upfail');
				}
			}
		}
	}
}
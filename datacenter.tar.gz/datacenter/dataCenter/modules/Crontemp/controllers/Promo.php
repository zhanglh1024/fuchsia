<?php
use core\ModBase;

class PromoController extends Yaf\Controller_Abstract
{
	/**
	 * 优惠券使用情况检测
	 */
	public function checkPromoNumAction()
	{
		echo "--begin--\r\n";
		$proMod = new ModBase('product');
		$finMod = new ModBase('finance');
		$query = "select * from e_products_promo_code where PromoTypeId>=188 and PromoTypeId<=195";
		$proInfo = $proMod->select($query, '', array());
		foreach ($proInfo as $k => $v)
		{
			$query = "select count(*) from e_finance_out where PromoId=".$v['PromoId'];
			$promoNum = $finMod->getOne($query, '', array());
			$msg = "PromoId:".$v['PromoId'].",PromoTypeId:".$v['PromoTypeId'].",PromoCode:".$v['PromoCode']."使用次数和订单表".($v['UseTimes'] == $promoNum ? "一致".$v['UseTimes'] : "不一致".$v['UseTimes'].','.$promoNum);
			echo $msg."\r\n";
			\core\Log::write($msg,'crontemp/promo','checkpromonum');
			$query = "select count(*) from e_products_promo_used where PromoId=".$v['PromoId'];
			$promoUsedNum = $proMod->getOne($query, '', array());
			$msg = "PromoId:".$v['PromoId'].",PromoTypeId:".$v['PromoTypeId'].",PromoCode:".$v['PromoCode']."使用次数和已使用次数表".($v['UseTimes'] == $promoUsedNum ? "一致".$v['UseTimes'] : "不一致".$v['UseTimes'].','.$promoUsedNum);
			echo $msg."\r\n";
			\core\Log::write($msg,'crontemp/promo','checkpromonum');
		}
		echo "--end--\r\n";
	}
	
	/**
	 * 检测优惠券使用的量并修改截止使用时间
	 */
	public function checkUsedPromoAction()
	{
		$promoTypeId = 239;
		$num = 35000;
		$proMod = new ModBase('product');
		$query = "select count(*) from e_products_promo_used where PromoTypeId={$promoTypeId} and IsCanceled=0";
		$count = $proMod->getOne($query, '', array());
		echo "CC域名8元注册优惠券使用量：".$count."\r\n";
		if($count && $count > $num)
		{
			$date = date('Y-m-d', strtotime('-1day'))." 23:59:59";
			$query = "update e_products_promo_type set UseEndDate='{$date}' where PromoTypeId={$promoTypeId}";
			$flag = $proMod->update($query, '', array());
			$msg = "CC域名8元注册优惠券使用截止时间更新({$date})".($flag ? "成功" : "失败");
			echo $msg."\r\n";
			self::sendNotice("cc域名8元注册优惠活动程序自动结束提醒", $msg);
		}
	}
	
	private function sendNotice($title, $msg)
	{
		$queueLogic = new \logic\manage\newqueue\QueueLogic();
		$config = array(561305 => array('15280250851', 'yangyf@ename.com'), 918750 => array('15160036923', 'huangyf@ename.com'), 612463 => array('18559222663', 'wangyt@ename.com'));
		foreach($config as $k => $v)
		{
			$queueLogic->addQueueNormal(
				array('Function' => 'send_sms', 'TemplateName' => 'any_template_info', 'EnameId' => $k,
						'Priority' => 5, 'Target' => $v[0], 'Data' => array('content' => $msg, 'title' => $title)));
		}
	}
}
<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class TransferController extends Yaf\Controller_Abstract
{
	/**
	 * 域名转出列表
	 */
	public function transferOutListAction()
	{ 
		try
		{ 
			form\manage\domain\DomainTransferOutForm::transferList();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\TransferOutLogic(ReturnData::$info->EnameId);
				$res = $domainLogic->transferOutList(ReturnData::$info);
				if($res['flag'])
				{
					Response::success($res['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 提交域名转出
	 */
	public function transferOutAction()
	{
		try
		{
			form\manage\domain\DomainTransferOutForm::transferoutSave();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\TransferOutLogic(ReturnData::$info->EnameId);
				$res = $domainLogic->transferOutCheck(ReturnData::$info);
				if($res['flag'])
				{
					Response::success($res['msg']);
				}
				else
				{
					Response::msg();
				}

			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 *发送转移密码
	 */
	public function transferOutSaveAction()
	{
		try
		{
			form\manage\domain\DomainTransferOutForm::settransferout();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\TransferOutLogic(ReturnData::$info->EnameId);
				$res = $domainLogic->setTransferOut(ReturnData::$info);
				if($res['flag'])
				{
					Response::success($res['msg']);
				}
				else
				{
					Response::msg();
				}

			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 取消发送
	 */
	public function transferOutCancelAction()
	{
		try
		{
			form\manage\domain\DomainTransferOutForm::cancelTransferOut();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\TransferOutLogic(ReturnData::$info->EnameId);
				$res = $domainLogic->transferOutCanel(ReturnData::$info);
				if($res['flag'])
				{
					Response::success($res['msg']);
				}
				else
				{
					Response::msg();
				}

			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 确认域名转出
	 */
	public function transferOutVerifyAction()
	{
		try
		{
			form\manage\domain\DomainTransferOutForm::transferVerify();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\TransferOutLogic(ReturnData::$info->EnameId);
				$res = $domainLogic->transferOutVerifyLogic(ReturnData::$info);
				if($res['flag'])
				{
					Response::success($res['msg']);
				}
				else
				{
					Response::msg();
				}

			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 提交域名转入
	 */
	public function transferInAction()
	{
		try
		{
			form\manage\domain\DomainTransferInForm::addTransferIn();
			if(ReturnData::$success)
			{
				$transferInLogic = new \logic\manage\domain\DomainTransferInLogic(ReturnData::$info->enameId);
				$return = $transferInLogic->saveTransferIn(ReturnData::$info);
				Response::success($return);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 域名转入列表
	 */
	public function transferInListAction()
	{
		try
		{
			form\manage\domain\DomainTransferInForm::transferInList();
			if(ReturnData::$success)
			{
				$transferInLogic = new \logic\manage\domain\DomainTransferInLogic(ReturnData::$info->enameId);
				$return = $transferInLogic->transferInList(ReturnData::$info);
				Response::success($return);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 取消转入
	 */
	public function transferInCancelAction()
	{
		try
		{
			form\manage\domain\DomainTransferInForm::transferInCancel();
			if(ReturnData::$success)
			{
				$transferInLogic = new \logic\manage\domain\DomainTransferInLogic(ReturnData::$info->enameId);
				$transferInLogic->transferInCancel(ReturnData::$info);
				Response::success('取消域名转入成功');
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 查询转入状态
	 */
	public function checkTransferStatusAction()
	{
		try
		{
			form\manage\domain\DomainTransferInForm::checkTransferStatus();
			if(ReturnData::$success)
			{
				$transferInLogic = new \logic\manage\domain\DomainTransferInLogic(ReturnData::$info->enameId);
				$return = $transferInLogic->checkTransferStatus(ReturnData::$info);
				Response::success($return);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取转入信息
	 */
	public function getTransferInfoAction()
	{
		try
		{
			form\manage\domain\DomainTransferInForm::getTransferInfo();
			if(ReturnData::$success)
			{
				$transferInLogic = new \logic\manage\domain\DomainTransferInLogic(ReturnData::$info->enameId);
				$return = $transferInLogic->getTransferInfo(ReturnData::$info);
				Response::success($return);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 更新转入信息
	 */
	public function setTransferInfoAction()
	{
		try
		{
			form\manage\domain\DomainTransferInForm::setTransferInfo();
			if(ReturnData::$success)
			{
				$transferInLogic = new \logic\manage\domain\DomainTransferInLogic(ReturnData::$info->enameId);
				$return = $transferInLogic->setTransferIn(ReturnData::$info);
				Response::success($return === true ? '域名转入更新成功' : $return);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 重发邮件
	 */
	public function resendTransferMailAction()
	{
		try
		{
			form\manage\domain\DomainTransferInForm::resendTransferMail();
			if(ReturnData::$success)
			{
				$transferInLogic = new \logic\manage\domain\DomainTransferInLogic(ReturnData::$info->enameId);
				$return = $transferInLogic->resendTransferMail(ReturnData::$info);
				Response::success($return);
			}
			Response::error();
		}
		catch(\FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}		
	}
}
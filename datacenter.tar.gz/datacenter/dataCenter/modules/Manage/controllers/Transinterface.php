<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class TransInterfaceController extends \Yaf\Controller_Abstract
{
	/**
	 * 通过域名ID获取交易结拍价格和日期
	 * @param array $ids
	 */
	public function getTransInfoByIdsAction()
	{
		try
		{
			form\manage\domain\DomainInterfaceForm::getTransInfoByIds();
			if(ReturnData::$success)
			{
				$transInterface = new \interfaces\trans\Trans();
				$domainTransInfo = $transInterface->getdomainsByIds(ReturnData::$info->id);
				Response::success($domainTransInfo);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 通过enameid获取专属经纪人信息 （','分隔）
	 */
	public function getAgentByEnameIdsAction()
	{
		try
		{
			form\manage\domain\DomainInterfaceForm::getAgentByEnameIds();
			if(ReturnData::$success)
			{
				$transInterface = new \interfaces\trans\Trans();
				$agentInfo = $transInterface->getAgentByEnameId(ReturnData::$info->enameId);
				Response::success($agentInfo);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}
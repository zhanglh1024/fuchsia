<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class StatController extends Yaf\Controller_Abstract
{
	/* 域名消费统计 */
	public function domainCostAction()
	{
		try
		{
			form\manage\finance\FinanceForm::statByMonth();
			if(ReturnData::$success)
			{
				$generalLogic = new \logic\manage\finance\FinanceGeneralLogic();
				$result = $generalLogic->domainCost((array)ReturnData::$info);
				Response::success($result);
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	/* 交易统计 */
	public function tradeAction()
	{
		try
		{
			form\manage\finance\FinanceForm::statByMonth();
			if(ReturnData::$success)
			{
				$generalLogic = new \logic\manage\finance\FinanceGeneralLogic();
				$result = $generalLogic->trade((array)ReturnData::$info);
				Response::success($result);
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	/* 用户统计 */
	public function userAction()
	{
		try
		{
			form\manage\finance\FinanceForm::statByMonth();
			if(ReturnData::$success)
			{
				$generalLogic = new \logic\manage\finance\FinanceGeneralLogic();
				$result = $generalLogic->user((array)ReturnData::$info);
				Response::success($result);
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	/* 域名消费额排名 */
	public function domainCostRankingAction()
	{
		try
		{
			form\manage\finance\FinanceForm::statByMonth();
			if(ReturnData::$success)
			{
				$generalLogic = new \logic\manage\finance\FinanceGeneralLogic();
				$result = $generalLogic->domainCostRanking((array)ReturnData::$info);
				Response::success($result);
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	/* 域名交易额排名 */
	public function tradeRankingAction()
	{
		try
		{
			form\manage\finance\FinanceForm::statByMonth();
			if(ReturnData::$success)
			{
				$generalLogic = new \logic\manage\finance\FinanceGeneralLogic();
				$result = $generalLogic->tradeRanking((array)ReturnData::$info);
				Response::success($result);
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	/* 域名交易额排名（去掉push） */
	public function tradeRankingNoPushAction()
	{
		try
		{
			form\manage\finance\FinanceForm::statByMonth();
			if(ReturnData::$success)
			{
				$generalLogic = new \logic\manage\finance\FinanceGeneralLogic();
				$result = $generalLogic->tradeRankingNoPush((array)ReturnData::$info);
				Response::success($result);
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	/* 域名类型统计 */
	public function domainTypeAction()
	{
		try
		{
			form\manage\finance\FinanceForm::statByMonth();
			if(ReturnData::$success)
			{
				$generalLogic = new \logic\manage\finance\FinanceGeneralLogic();
				$result = $generalLogic->domainType((array)ReturnData::$info);
				Response::success($result);
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	/* 入款方式统计 */
	public function financeInTypeAction()
	{
		try
		{
			form\manage\finance\FinanceForm::statByMonth();
			if(ReturnData::$success)
			{
				$generalLogic = new \logic\manage\finance\FinanceGeneralLogic();
				$result = $generalLogic->financeInType((array)ReturnData::$info);
				Response::success($result);
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 *  预付款详细统计 
	 */
	public function prePayAction()
	{
		try
		{
			form\manage\finance\FinanceForm::statByMonth();
			if(ReturnData::$success)
			{
				$generalLogic = new \logic\manage\finance\FinanceGeneralLogic();
				$result = $generalLogic->prePay((array)ReturnData::$info);
				Response::success($result);
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 *  预付款总额统计
	 */
	public function prePayTotalAction()
	{
		try
		{
			form\manage\finance\FinanceForm::statByMonth();
			if(ReturnData::$success)
			{
				$generalLogic = new \logic\manage\finance\FinanceGeneralLogic();
				$result = $generalLogic->prePay((array)ReturnData::$info, true);
				Response::success($result);
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 *  按接口统计
	 */
	public function registrarAction()
	{
		try
		{
			form\manage\finance\FinanceForm::statByMonth();
			if(ReturnData::$success)
			{
				$generalLogic = new \logic\manage\finance\FinanceGeneralLogic();
				$result = $generalLogic->registrar((array)ReturnData::$info, true);
				Response::success($result);
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
}
<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class PromoController extends Yaf\Controller_Abstract
{

	/**
	 * 获取当前用户可以优惠券列表
	 */
	public function getAvailableCouponListAction()
	{
		try
		{
			form\manage\promo\PromoForm::getCouponList();
			if(ReturnData::$success)
			{
				$logic = new logic\manage\promo\PromoLogic();
				$return = $logic->getAvailableCouponList(ReturnData::$info);
				if(is_array($return))
				{
					Response::success($return);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取优惠券列详细信息(管理前台购物车改版使用)
	 */
	public function getCouponDetailAction()
	{
		try
		{
			form\manage\promo\PromoForm::getCouponDetail();
			if(ReturnData::$success)
			{
				$logic = new logic\manage\promo\PromoLogic();
				Response::success($logic->getCouponDetail(ReturnData::$info));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取用户优惠券列表(管理前台购物车改版使用)
	 */
	public function getUserCouponListAction()
	{
		try
		{
			form\manage\promo\PromoForm::getUserCouponListForm();
			if(ReturnData::$success)
			{
				$logic = new logic\manage\promo\PromoLogic();
				$return = $logic->getUserCouponList(ReturnData::$info);
				if(is_array($return))
				{
					Response::success($return);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 检查优惠券是否可以用
	 */
	public function checkCouponAction()
	{
		try
		{
			form\manage\promo\PromoForm::checkCoupon();
			if(ReturnData::$success)
			{
				$logic = new logic\manage\promo\PromoLogic();
				$return = $logic->checkCoupon();
				if(is_array($return))
				{
					Response::success($return);
				}
			}
			Response::error(Response::getErrMsg() ? Response::getErrMsg() : '');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取优惠券具体信息
	 */
	public function getCouponInfoAction()
	{
		try
		{
			form\manage\promo\PromoForm::getCoupon();
			if(ReturnData::$success)
			{
				$logic = new logic\manage\promo\PromoLogic();
				Response::success($logic->getCouponInfo(ReturnData::$info));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取优惠券列表（包括可使用的 已经过期的 已经使用过的）
	 * 用于app
	 */
	public function getCouponListAction()
	{
		try
		{
			form\manage\promo\PromoForm::getCouponList();
			if(ReturnData::$success)
			{
				$logic = new logic\manage\promo\PromoLogic();
				Response::success($logic->getCouponList(ReturnData::$info));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取优惠券注册，转入，续费和全部各统计数目
	 * @param $promoStatus 1:未使用   4：已使用，已失效
	 */
	public function getCouponCountAppAction()
	{
		try
		{
			form\manage\promo\PromoForm::getCouponCountApp();
			if(ReturnData::$success)
			{
				$logic = new logic\manage\promo\PromoLogic();
				Response::success($logic->getCouponCountApp(ReturnData::$info));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 优惠券统计已使用
	 */
	public function getPromoCodeCountAction()
	{
		try
		{
			form\manage\promo\PromoForm::getPromoCodeCount();
			if(ReturnData::$success)
			{
				$logic = new logic\manage\promo\PromoLogic();
				Response::success($logic->getPromoCodeCount(ReturnData::$info));
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}

<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class DomainrestoreController extends Yaf\Controller_Abstract
{
	/**
	 * 查看域名赎回列表
	 */
	public function restoreListAction()
	{
		try
		{
			form\manage\domain\DomainRestoreForm::restoreListForm();
			if(ReturnData::$success)
			{
				$logic = new logic\manage\domain\DomainRestoreLogic();
				$return = $logic->getRestoreList(ReturnData::$info);
				if($return)
				{
					Response::success($return);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 赎回详情
	 */
	public function restoreDetailAction()
	{
		try
		{
			form\manage\domain\DomainRestoreForm::getRestoreDetailForm();
			if(ReturnData::$success)
			{
				$logic = new logic\manage\domain\DomainRestoreLogic();
				$return = $logic->getRestoreDetail(ReturnData::$info);
				if(is_array($return) && !empty($return))
				{
					Response::success($return);
				}
			}
			Response::error(isset($return) ? $return : 'error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 赎回备注
	 */
	public function restoreRemarkAction()
	{
		try
		{
			form\manage\domain\DomainRestoreForm::restoreSetRemarkForm();
			if(ReturnData::$success)
			{
				$logic = new logic\manage\domain\DomainRestoreLogic();
				if($logic->restoreRemark(ReturnData::$info))
				{
					Response::success('success');
					exit;
				}
				Response::error('error');
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}


	/**
	 * 判断域名是否可赎回
	 */
	public function domainRestoreQueryAction()
	{
		try
		{
			form\manage\domain\DomainRestoreForm::domainRestoreQuery();
			if(ReturnData::$success)
			{
				$enameId = ReturnData::$info->enameId;
				$domain = ReturnData::$info->domain;
				$domainRestoreLogic = new logic\manage\domain\DomainRestoreLogic();
			   Response::success($domainRestoreLogic->domainRestoreQuery($enameId, $domain));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 域名直接赎回
	 */
	public function domainRestoreDirectlyAction()
	{
		try
		{
			form\manage\domain\DomainRestoreForm::domainRestoreDirect();
			if(ReturnData::$success)
			{
				$domainRestoreLogic = new logic\manage\domain\DomainRestoreLogic();
				Response::success($domainRestoreLogic->domainRestoreDirect(ReturnData::$info));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * org asia域名 域名赎回操作
	 */
	public function domainRestoreOperAction()
	{
		try
		{
			form\manage\domain\DomainRestoreForm::domainRestoreOperForm();
			if(ReturnData::$success)
			{
				$logic = new logic\manage\domain\DomainRestoreLogic();
				$return = $logic->domainRestoreOper(ReturnData::$info);
				if(is_array($return) && ! empty($return))
				{
					Response::success($return);
				}
			}
			Response::error(isset($return)? $return: 'error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}

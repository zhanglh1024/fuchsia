<?php
class GztapiController extends Yaf\Controller_Abstract
{

	public function IndexAction()
	{
		$gztApi = new vendor\gztapi();
		echo time();
		$redis = core\redislib::getInstance("common");
		var_dump($redis->set("a",time()));
		var_dump($redis->get("a"));
	}
}
<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class DomainController extends Yaf\Controller_Abstract
{
	/**
	 * 查看域名是否是珍品跟抢滩域名 是否已经在本年度内已经优惠过
	 */
	public function checkTopDomainAction()
	{
		try
		{
			form\manage\domain\DomainForm::topDomainExists();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainTopLogic();
				$return = $domainLogic->checkTopDomain(ReturnData::$info->domain, ReturnData::$info->checkTime);
				if(is_array($return) && !empty($return))
				{
					Response::success($return);
				}
			}
			Response::error(isset($return) ? $return : 'error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取珍品域名记录
	 */
	public function getTopDomainAction()
	{
		try
		{
			form\manage\domain\DomainForm::getTopDomain();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainTopLogic();
				$return = $domainLogic->getTopDomainConsume();
				if(is_array($return) && !empty($return))
				{
					Response::success($return);
				}
			}
			Response::error(isset($return) ? $return : 'error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取珍品域名数量
	 */
	public function getTopDomainCountAction()
	{
		try
		{
			form\manage\domain\DomainForm::getTopDomain();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainTopLogic();
				$return = $domainLogic->getTopDomainCount();
				if(is_array($return) && !empty($return))
				{
					Response::success($return);
				}
			}
			Response::error(isset($return) ? $return : 'error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 添加珍品域名记录
	 */
	public function addTopDomainAction()
	{
		try
		{
			form\manage\domain\DomainForm::addTopDomainForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainTopLogic();
				if($domainLogic->addTopDomainConsume())
				{
					Response::success('success');
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
 
	/**
	 * 查看域名是否可以注册
	 */
	public function domainRegistQueryAction()
	{
		try
		{
			form\manage\domain\DomainForm::domainRegistQuery();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainLogic();
				Response::success($domainLogic->domainRegistQuery(ReturnData::$info));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取人工提醒待处理数量
	 */
	public function getDomainRemindCountAction()
	{
		try
		{
			$domainLogic = new \logic\manage\domain\DomainLogic();
			$rs = $domainLogic->getDomainRemindCount();
			Response::success($rs);
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取域名安全锁未处理数
	 */
	public function getDomainProtectionCountAction()
	{
		try
		{
			$domainLogic = new \logic\manage\domain\DomainLogic();
			$rs = $domainLogic->getDomainProtectionCount();
			Response::success($rs);
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	public function getDomainProtectionCnComAction()
	{
		try
		{
			form\manage\domain\DomainForm::domainsecureCount();
			$domainLogic = new \logic\manage\domain\DomainLogic();
			Response::success($domainLogic->getDomainProtectCnCount(ReturnData::$info));
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	public function simpleRegAction()
	{
		try
		{
			form\manage\domain\DomainForm::simpledomainRegist();
			if(ReturnData::$success)
			{
				$domainLogic = new \logic\manage\domain\DomainLogic();
				$rs = $domainLogic->simpleDomainReg(ReturnData::$info);
				Response::success($rs);
			}
			Response::error();
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 域名批量查询是否可以注册
	 */
	public function domainQueryBatchAction()
	{
		try
		{
			form\manage\domain\DomainForm::domainRegistQueryBatch();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainLogic();
				Response::success($domainLogic->domainQueryBatch(ReturnData::$info));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 115查看域名是否可以注册
	 */
	public function domainQueryOtherAction()
	{
		try
		{
			form\manage\domain\DomainForm::domainRegistQueryOther();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainLogic();
				Response::success($domainLogic->domainRegistQueryOther(ReturnData::$info));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 115域名续费注册
	 */
	public function registerrenewAction()
	{
		try
		{
			form\manage\domain\DomainForm::domainRegist();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\cart\CartLogic(ReturnData::$info->enameId);
				Response::success($domainLogic->domainRegistOther(ReturnData::$info));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	public function getDomainSuffixAction()
	{
		try{
			form\manage\domain\DomainForm::simpledomainRegist();
			$domainLogic = new \logic\manage\domain\DomainLogic();
			$rs = $domainLogic->getdomainsuffix();
			Response::success($rs);
		}
		catch (Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * whois平台用的域名注册查询连同推荐域名一起
	 */
	public function domainRecommondAction()
	{
		try{
			form\manage\domain\DomainForm::domainRecommond();
			$domainLogic = new \logic\manage\domain\DomainLogic();
			$rs = $domainLogic->getDomainRecomond(ReturnData::$info);
			Response::success($rs);
		}
		catch (Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}		
	}
}

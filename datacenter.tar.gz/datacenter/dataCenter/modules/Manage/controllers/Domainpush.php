<?php
use logic\manage\domain\DomainPushLogic;

use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class DomainPushController extends Yaf\Controller_Abstract
{
	/**
	 * 域名push列表(正在交易 交易结束)
	 */
	public function domainPushListAction()
	{
		try
		{
			form\manage\domain\DomainPushForm::pushList();
			if(ReturnData::$success)
			{
				$push = new logic\manage\domain\DomainPushLogic(ReturnData::$info->enameId);
				Response::success($push->domainPushList(ReturnData::$info));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 域名Push个数(正在交易)
	 */
	public function domainPushCountAction()
	{
		try
		{
			form\manage\domain\DomainPushForm::pushList();
			if(ReturnData::$success)
			{
				$push = new logic\manage\domain\DomainPushLogic(ReturnData::$info->enameId);
				Response::success($push->domainPushCount());
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * Push详情(收到 发送)
	 */
	public function domainPushInfoAction()
	{
		try
		{
			form\manage\domain\DomainPushForm::pushInfo();
			if(ReturnData::$success)
			{
				$push = new logic\manage\domain\DomainPushLogic(ReturnData::$info->enameId);
				Response::success($push->domainpushInfo(ReturnData::$info,ReturnData::$info->ver));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * api push详情
	 */
	public function domainPushInfoApiAction()
	{
		try
		{
			form\manage\domain\DomainPushForm::pushInfo();
			if(ReturnData::$success)
			{
				$push = new logic\manage\domain\DomainPushLogic(ReturnData::$info->enameId);
				Response::success($push->domainPushFormatInfo(ReturnData::$info,ReturnData::$info->ver));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 提交域名Push
	 */
	public function pushDomainAction()
	{
		try
		{
			form\manage\domain\DomainPushForm::pushDomain();
			if(ReturnData::$success)
			{
				$push = new logic\manage\domain\DomainPushLogic(ReturnData::$info->EnameId);
				$result = $push->pushDomain(ReturnData::$info);
				if($result['flag'])
				{
					Response::success($result);
				}
				else 
				{
					Response::error($result['msg'],$result['code']);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 域名Push操作
	 */
	public function operatePushDomainAction()
	{
		try
		{
			form\manage\domain\DomainPushForm::operatePushDomain();
			if(ReturnData::$success)
			{
				$push = new logic\manage\domain\DomainPushLogic(ReturnData::$info->EnameId);
				$result = $push->actionPushDomain(ReturnData::$info->pushId,ReturnData::$info->operationType);//2:拒绝 3:取消
				if($result['flag'])
				{
					Response::success($result['msg']);
				}
				else 
				{
					Response::error($result['msg'],$result['code']);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 验证批量Push的域名状态
	 */
	public function domainPushCheckAction()
	{
		try
		{
			form\manage\domain\DomainPushForm::checkPushDomainStatus();
			if(ReturnData::$success)
			{
				$push = new logic\manage\domain\DomainPushLogic(ReturnData::$info->enameId);
				$result = $push->checkPushDomainStatus(ReturnData::$info->domains);
				Response::success($result);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 获取PUSH列表
	 */
	public function getPushListAction()
	{
		try
		{
			form\manage\domain\DomainPushForm::getPushList();
			if(ReturnData::$success)
			{
				$push = new logic\manage\domain\DomainPushLogic(ReturnData::$info->enameId);
				$result = $push->getPushList(ReturnData::$info);
				Response::success($result);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 接收PUSH操作
	 */
	public function receptPushAction()
	{
		try 
		{ 
			form\manage\domain\DomainPushForm::receptPush();
			if(ReturnData::$success)
			{
				$push = new logic\manage\domain\DomainPushLogic(ReturnData::$info->enameId);
				$result = $push->receptPush(ReturnData::$info);
				Response::success($result);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		} 
	}
}

<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;
class OrderController extends Yaf\Controller_Abstract
{
	/**
	 * 创建产品订单
	 */
	public function addProductOrderAction()
	{
		try
		{
			form\manage\finance\OrderForm::addProductOrderForm();
			if(ReturnData::$success)
			{
				$orderLogic = new logic\manage\finance\OrderLogic();
				if($orderId = $orderLogic->addProductOrder(ReturnData::$info))
				{
					Response::success(array('orderId' => $orderId));
				}
				Response::msg();
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 创建无产品订单
	 */
	public function addOrderAction()
	{
		try
		{ 
			form\manage\finance\OrderForm::addOrderForm();
			if(ReturnData::$success)
			{
				$orderLogic = new logic\manage\finance\OrderLogic();
				if($orderId = $orderLogic->addOrder(ReturnData::$info))
				{
					Response::success(array('orderId' => $orderId));
				}
				Response::msg();
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 确认订单
	 */
	public function confirmOrderAction()
	{
		try
		{
			form\manage\finance\OrderForm::confirmOrderForm();
			if(ReturnData::$success)
			{
				$orderLogic = new logic\manage\finance\OrderLogic();
				if($orderLogic->confirmOrder(ReturnData::$info))
				{
					Response::success();
				}
				Response::msg();
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 取消订单
	 */
	public function cancelOrderAction()
	{
		try
		{
			form\manage\finance\OrderForm::cancelOrderForm();
			if(ReturnData::$success)
			{
				$orderLogic = new logic\manage\finance\OrderLogic();
				if($orderLogic->cancelOrder(ReturnData::$info))
				{
					Response::success();
				}
				Response::msg();
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取订单信息
	 */
	public function getOrderInfoAction()
	{
		try
		{
			form\manage\finance\OrderForm::getOrderInfoForm();
			$orderLogic = new logic\manage\finance\OrderLogic();
			$result = $orderLogic->getOrderInfo(ReturnData::$info->enameId, ReturnData::$info->orderId);
			Response::success($result);
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 修改某订单中的冻结金额
	 */
	public function updateFreezeMoneyAction()
	{
	}
	
	public function getOrderListAction()
	{
		try
		{
			form\manage\finance\OrderForm::getOrderListForm();
			$orderLogic = new logic\manage\finance\OrderLogic();
			$result = $orderLogic->getOrderListByContion((array)ReturnData::$info, false);
			Response::success($result);
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 更改订单的信息
	 */
	public function updateOrderInfoByOrderIdAction()
	{
		try
		{
			form\manage\finance\OrderForm::updateOrderInfoForm();
			$orderLogic = new logic\manage\finance\OrderLogic();
			Response::success($orderLogic->setOrderInfo((array)ReturnData::$info));
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}		
	}
}

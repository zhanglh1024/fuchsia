<?php
use models\manage\verify\IdentityVerifyMod;

use core\Response;
use core\form\FormException;
use core\form\ReturnData;
use common\Common;

class VerifyController extends Yaf\Controller_Abstract
{

	/**
	 * 获取认证信息列表
	 */
	public function getVerifyListAction()
	{
		try
		{
			form\manage\verify\VerifyForm::checkListParam();
			if(ReturnData::$success)
			{
				$userLogic = new logic\manage\verify\VerifyLogic(ReturnData::$info->verifyflag);
				$rs = $userLogic->getVerifyList(ReturnData::$info, ReturnData::$info->verifyflag);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 删除认证信息
	 */
	public function delVerifyAction()
	{
		try
		{
			form\manage\verify\VerifyForm::checkfailureId();
			if(ReturnData::$success)
			{
				$userLogic = new logic\manage\verify\VerifyLogic(ReturnData::$info->verifyflag);
				$rs = $userLogic->delFailure(ReturnData::$info, ReturnData::$info->verifyflag);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 添加邮箱认证
	 */
	public function addEmailVerifyAction()
	{
		try
		{
			form\manage\verify\VerifyForm::checkEmailVerify();
			if(ReturnData::$success)
			{
				if(!\common\MailSendLimit::sendMailIsOutOfLimit(ReturnData::$info->EnameId, 'verify_sendEmailCaptcha'))
				{
					throw new Exception('邮件发送超出限制', 200162);
				}
				$userLogic = new logic\manage\verify\VerifyLogic('email');
				$rs = $userLogic->addEmailVerify(ReturnData::$info);
				if($rs['flag'])
				{
					\common\MailSendLimit::setSendMail(ReturnData::$info->EnameId, 'verify_sendEmailCaptcha', 86400);
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 添加企业认证
	 */
	public function addCompanyVerifyAction()
	{
		try
		{
			form\manage\verify\VerifyForm::checkCompanyVerify();
			if(ReturnData::$success)
			{
				$userLogic = new logic\manage\verify\VerifyLogic('company');
				$rs = $userLogic->addCompanyVerify(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 添加身份认证
	 */
	public function addIdentityVerifyAction()
	{
		try
		{
			form\manage\verify\VerifyForm::checkIdentityVerify();
			if(ReturnData::$success)
			{
				$userLogic = new logic\manage\verify\VerifyLogic('identity');
				$rs = $userLogic->addIdentityVerify(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取认证通过的信息列表
	 */
	public function getPassVerifyListAction()
	{
		try
		{
			form\manage\verify\VerifyForm::checkPassListParam();
			if(ReturnData::$success)
			{
				$userLogic = new logic\manage\verify\VerifyLogic();
				$rs = $userLogic->getPassVerifyList(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取认证通过的信息列表
	 */
	public function infoIsCompleteAction()
	{
		try
		{
			form\manage\verify\VerifyForm::checkUserInfo();
			if(ReturnData::$success)
			{
				$userLogic = new logic\manage\verify\VerifyLogic();
				$rs = $userLogic->infoIsComlete(ReturnData::$info->EnameId, ReturnData::$info->verifyflag);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取身份认证和企业认证未处理的数量
	 *
	 * @param int $type
	 *        	类型 1=>身份认证,2=>企业认证
	 */
	public function getTodoCountAction()
	{
		try
		{
			form\manage\verify\VerifyForm::getTodoCount();
			if(ReturnData::$success)
			{
				$userLogic = new logic\manage\verify\VerifyLogic();
				$rs = $userLogic->getTodoCount(ReturnData::$info->type);
				Response::success($rs);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 查询身份认证是否通过
	 */
	public function queryIdentityAction()
	{
		try
		{
			form\manage\verify\VerifyForm::queryIdentity();
			if(ReturnData::$success)
			{
				$verifyLogic = new logic\manage\verify\VerifyLogic();
				$rs = $verifyLogic->queryIdentity(ReturnData::$info);
				Response::success($rs);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 查询企业认证是否通过
	 */
	public function queryCompanyAction()
	{
		try
		{
			form\manage\verify\VerifyForm::queryCompany();
			if(ReturnData::$success)
			{
				$verifyLogic = new logic\manage\verify\VerifyLogic();
				$rs = $verifyLogic->queryCompany(ReturnData::$info);
				Response::success($rs);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 判断是否已经bbs认证
	 * return array(...)、status 0为提交认证 1为认证申请中 2为认证成功 3为 认证失败
	 */
	public function queryDnbbsAction()
	{
		try
		{
			form\manage\verify\VerifyForm::queryDnbbs();
			if(ReturnData::$success)
			{
				$verifyLogic = new logic\manage\verify\VerifyLogic();
				$rs = $verifyLogic->queryDnbbs(ReturnData::$info->enameId);
				Response::success($rs);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
    /**
     * 发票授权委托
     */
	public function proxyInvoiceAction()
	{
		try
		{  	
			form\manage\verify\VerifyForm::proxyInvoice();
			if(ReturnData::$success)
			{
				$verifyLogic = new logic\manage\verify\VerifyLogic();
				$rs = $verifyLogic->proxyInvoice(ReturnData::$info);
				Response::success($rs);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 申请发票授权委托
	 */
	public function addProxyInvoiceAction()
	{
		try
		{
			form\manage\verify\VerifyForm::addProxyInvoice();
			if(ReturnData::$success)
			{
				$verifyLogic = new logic\manage\verify\VerifyLogic();
				$rs = $verifyLogic->addProxyInvoice(ReturnData::$info);
				Response::success($rs);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 删除发票授权委托
	 */
	public function delProxyInvoiceAction()
	{
		try
		{
			form\manage\verify\VerifyForm::delProxyInvoice();
			if(ReturnData::$success)
			{
				$verifyLogic = new logic\manage\verify\VerifyLogic();
				$rs = $verifyLogic->delProxyInvoice(ReturnData::$info);
				Response::success($rs);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 根据ID获取发票授权委托详细
	 */
	public function getProxyInvoiceByIdAction()
	{
		try
		{
			form\manage\verify\VerifyForm::getProxyInvoiceById();
			if(ReturnData::$success)
			{
				$verifyLogic = new logic\manage\verify\VerifyLogic();
				$rs = $verifyLogic->getProxyInvoiceById(ReturnData::$info->ID);
				Response::success($rs);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 根据ID修改发票授权委托
	 */
	public function updateProxyInvoiceByIdAction() 
	{
		try
		{
			form\manage\verify\VerifyForm::updateProxyInvoiceById();
			if(ReturnData::$success)
			{
				$verifyLogic = new logic\manage\verify\VerifyLogic();
				$rs = $verifyLogic->updateProxyInvoiceById(ReturnData::$info);
				Response::success($rs);
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}

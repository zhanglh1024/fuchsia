<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class EdnsController extends Yaf\Controller_Abstract
{
	/**
	 * 添加域名
	 */
	public function addDomainAction()
	{
		try
		{
			$_POST['domain'] = empty($_POST['domain']) ? '' : urldecode(strtolower($_POST['domain']));
			form\manage\domain\DomainEdnsForm::checkAddDomin();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->addDomain(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 域名加锁
	 */
	public function domainLockAction()
	{
		try
		{
			$_POST['domain'] = empty($_POST['domain']) ? '' : urldecode(strtolower($_POST['domain']));
			form\manage\domain\DomainEdnsForm::checkAddDomin();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->domainLock(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 域名解锁
	 */
	public function domainUnLockAction()
	{
		try
		{
			$_POST['domain'] = empty($_POST['domain']) ? '' : urldecode(strtolower($_POST['domain']));
			form\manage\domain\DomainEdnsForm::checkAddDomin();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->domainUnLock(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 域名设置为展示页
	 */
	public function domainCustompageAction()
	{
		try
		{
			$_POST['domain'] = empty($_POST['domain']) ? '' : urldecode(strtolower($_POST['domain']));
			form\manage\domain\DomainEdnsForm::checkAddDomin();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->domainCustompage(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 解析记录列表
	 */
	public function recordListAction()
	{
		try
		{
			$_GET['domain'] = urldecode(strtolower($_GET['domain']));
			form\manage\domain\DomainEdnsForm::checkrecordlist();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->recordList(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 添加解析记录
	 */
	public function createRdByDnAction()
	{
		try
		{
			$_POST['domain'] = empty($_POST['domain']) ? '' : urldecode(strtolower($_POST['domain']));
			$_POST['subdomain'] = empty($_POST['subdomain']) ? '@' : urldecode(strtolower($_POST['subdomain']));
			$_POST['rvalue'] = empty($_POST['rvalue']) ? '' : urldecode($_POST['rvalue']);
			form\manage\domain\DomainEdnsForm::addRecordForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->createRdByDn(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 修改解析记录
	 */
	public function modifyAction()
	{
		try
		{
			$_POST['domain'] = empty($_POST['domain']) ? '' : urldecode(strtolower($_POST['domain']));
			$_POST['subdomain'] = empty($_POST['subdomain']) ? '' : urldecode(strtolower($_POST['subdomain']));
			$_POST['rvalue'] = empty($_POST['rvalue']) ? '' : urldecode($_POST['rvalue']);
			form\manage\domain\DomainEdnsForm::editRecordForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->modify(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 删除域名解析记录
	 */
	public function removeRecordAction()
	{
		try
		{
			$_POST['domain'] = empty($_POST['domain']) ? '' : urldecode(strtolower($_POST['domain']));
			form\manage\domain\DomainEdnsForm::removeRecordForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->removeRecord(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 启用域名解析记录
	 */
	public function recordEnableAction()
	{
		try
		{
			$_POST['domain'] = empty($_POST['domain']) ? '' : urldecode(strtolower($_POST['domain']));
			form\manage\domain\DomainEdnsForm::removeRecordForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->recordEnable(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 停用域名解析记录
	 */
	public function recordDisableAction()
	{
		try
		{
			$_POST['domain'] = empty($_POST['domain']) ? '' : urldecode(strtolower($_POST['domain']));
			form\manage\domain\DomainEdnsForm::removeRecordForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->recordDisable(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 暂停或启动域名解析
	 */
	public function recordHandleAction()
	{
		try
		{
			$_POST['domain'] = empty($_POST['domain']) ? '' : urldecode(strtolower($_POST['domain']));
			form\manage\domain\DomainEdnsForm::handleRecordForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->recordHandle(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch (Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 域名解析记录详情
	 */
	public function recordInfoAction()
	{
		try
		{
			$_GET['domain'] = empty($_GET['domain']) ? '' : urldecode(strtolower($_GET['domain']));
			form\manage\domain\DomainEdnsForm::recordInfoForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->recordInfo(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * URL转发审核列表
	 */
	public function auditListAction()
	{
		try
		{
			form\manage\domain\DomainEdnsForm::auditListForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->auditList(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * URL转发审核操作
	 */
	public function auditAction()
	{
		try
		{
			form\manage\domain\DomainEdnsForm::auditForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->audit(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * URL转发审核操作
	 */
	public function batchAuditAction()
	{
		try
		{
			form\manage\domain\DomainEdnsForm::auditForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->batchAudit(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * URL转发白名单列表
	 */
	public function urlDomainListAction()
	{
		try
		{
			form\manage\domain\DomainEdnsForm::urlDomainListForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->urlDomainList(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 添加新的URL转发白名单
	 */
	public function addWhiteListAction()
	{
		try
		{
			form\manage\domain\DomainEdnsForm::addWhiteForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->addWhiteList(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 编辑的URL转发白名单
	 */
	public function editWhiteListAction()
	{
		try
		{
			form\manage\domain\DomainEdnsForm::editWhiteForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->editWhiteList(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 *  删除的URL转发白名单
	 */
	public function urldRemoveAction()
	{
		try
		{
			form\manage\domain\DomainEdnsForm::urldRemoveForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->urldRemove(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 域名日志列表信息
	 */
	public function domainLogListAction()
	{
		try
		{
			$_GET['domain'] = empty($_GET['domain']) ? '' : urldecode(strtolower($_GET['domain']));
			form\manage\domain\DomainEdnsForm::domainLogForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->domainLogList(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 根据解析记录id  获取 域名信息
	 */
	public function domainInfoAction()
	{
		try
		{
			form\manage\domain\DomainEdnsForm::domainLoglistForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->domainInfo(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 域名信息
	 */
	public function domainInfoByDnAction()
	{
		try
		{
			$_POST['domain'] = empty($_GET['domain']) ? '' : urldecode(strtolower($_GET['domain']));
			form\manage\domain\DomainEdnsForm::domainLogForm();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->domainInfoByDn(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::msg();
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取URL审核申请中的数量
	 */
	public function getAuditingNumAction()
	{
		try 
		{
			form\manage\domain\DomainEdnsForm::getAuditingNum();
			if (ReturnData::$success) 
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->getAuditingNum(ReturnData::$info);
				Response::success($rs);
			}
			Response::error();
		} 
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
	}
	/**
	 * 批量解析域名操作
	 */
	public function batchDnsAction()
	{
		try
		{
			form\manage\domain\DomainEdnsForm::batchdns();
			if (ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->batchDnsLogic(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs);
				}
				else {
					Response::error($rs['errorMsg']);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 *批量解析域名状态验证
	 */
	public function batchDnsCheckAction()
	{
		try
		{
			form\manage\domain\DomainEdnsForm::batchdnscheck();
			if (ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\EdnsLogic();
				$rs = $domainLogic->batchDnsCheck(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs);
				}
				else {
					Response::error($rs);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}

<?php
use \logic\manage\finance\PayCenterLogic;
use core\Response;
use core\form\FormException;
use core\form\ReturnData;
use form\manage\finance\PaycenterForm;

/**
 * 在线充值相关接口
 */
class PaycenterController extends Yaf\Controller_Abstract
{
	/**
	 * 获取充值信息数目
	 */
	public function getPayInfoCountAction()
	{
		try
		{
			PaycenterForm::getPayInfoList();
			if(ReturnData::$success)
			{
				$payCenterLogic = new PayCenterLogic(ReturnData::$info->enameId);
				$return = $payCenterLogic->getPayCenterCount((array)ReturnData::$info);
				if($return)
				{
					Response::success($return);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取充值信息
	 */
	public function getPayInfoListAction()
	{
		try
		{
			PaycenterForm::getPayInfoList();
			if(ReturnData::$success)
			{
				$payCenterLogic = new PayCenterLogic(ReturnData::$info->enameId);
				$return = $payCenterLogic->getPayCenterList((array)ReturnData::$info);
				if($return)
				{
					Response::success($return);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 根据payid获取充值信息
	 */
	public function getPayInfoByPayIdAction()
	{
		try
		{
			PaycenterForm::getPayCenterByPayId();
			if(ReturnData::$success)
			{
				$payCenterLogic = new PayCenterLogic();
				$result = $payCenterLogic->getPayCenterByPayId((array)ReturnData::$info);
				if($result)
				{
					Response::success($result);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 根据transid获取充值信息
	 */
	public function getPayInfoByTransIdAction()
	{
		try
		{
			PaycenterForm::getPayCenterByTransId();
			if(ReturnData::$success)
			{
				$payCenterLogic = new PayCenterLogic();
				$result = $payCenterLogic->getPayCenterByTransId((array)ReturnData::$info);
				if($result)
				{
					Response::success($result);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取充值信息
	 */
	public function getPayInfoAction()
	{
		try
		{
			PaycenterForm::getPayInfoList();
			if(ReturnData::$success)
			{
				$payCenterLogic = new PayCenterLogic();
				$result = $payCenterLogic->getPayCenter((array)ReturnData::$info);
				if($result)
				{
					Response::success($result);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 增加在线充值信息
	 */
	public function addPayInfoAction()
	{
		try
		{
			PaycenterForm::addPayCenterInfo();
			if(ReturnData::$success)
			{
				$payCenterLogic = new PayCenterLogic();
				$result = $payCenterLogic->addPayCenterInfo((array)ReturnData::$info);
				if($result)
				{
					Response::success($result);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 更新在线充值信息
	 */
	public function updatePayInfoAction()
	{
		try
		{
			PaycenterForm::updatePayInfo();
			if(ReturnData::$success)
			{
				$payCenterLogic = new PayCenterLogic();
				$result = $payCenterLogic->updatePayInfo((array)ReturnData::$info);
				if($result)
				{
					Response::success($result);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 更新保证金充值订单
	 */
	public function updateMarginAction()
	{
		try
		{
			PaycenterForm::updatePayInfo();
			if(ReturnData::$success)
			{
				$payCenterLogic = new PayCenterLogic(ReturnData::$info->enameId);
				$result = $payCenterLogic->updateMargin((array)ReturnData::$info);
				if($result)
				{
					Response::success($result);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 根据mobile和payId更新充值订单EnameId
	 * app快速充值使用
	 */
	public function updatePayInfoByMobileAction()
	{
		try
		{
			PaycenterForm::updatePayInfo();
			if(ReturnData::$success)
			{
				$payCenterLogic = new PayCenterLogic();
				$result = $payCenterLogic->setPayInfoByMobile((array)ReturnData::$info);
				if($result)
				{
					Response::success($result);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 充值成功后的一系列操作--支付中心调用
	 * 更新充值记录，给用户入款，产生入款流水等
	 * @params payId,rechargeMoney
	 */
	public function doPaycenterUpdateAction()
	{
		try
		{
			PaycenterForm::updatePayInfo();
			if(ReturnData::$success)
			{
				$payCenterLogic = new PayCenterLogic();
				$result = $payCenterLogic->doPaycenterUpdate((array)ReturnData::$info);
				if($result)
				{
					Response::success($result);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
}
<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class CustomerCountController extends Yaf\Controller_Abstract
{
	/**
	 * 添加重复审核的数据
	 */
	public function customerCountAddAction()
	{
		try
		{
			form\manage\verify\CustomerCountForm::addCustomerCount();
			if(ReturnData::$success)
			{
				$logic = new logic\help\customercount\CustomerCountLogic();
				if($logic->addCustomerCountSecond(ReturnData::$info))
				{
					Response::success('添加成功');
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取二次统计的数据
	 */
	public function customerCountGetAction()
	{
		try
		{
			form\manage\verify\CustomerCountForm::getCustomerCount();
			if(ReturnData::$success)
			{
				$logic = new logic\help\customercount\CustomerCountLogic();
				Response::success($logic->getCustomerCountSecond(ReturnData::$info));
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}

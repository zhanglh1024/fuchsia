<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class DomainRegDnsController extends Yaf\Controller_Abstract
{
	/**
	 * 域名注册DNS
	 */
	public function addRegDnsAction()
	{
		try
		{
			form\manage\domain\DomainEdnsForm::addRegDns();
			if(ReturnData::$success)
			{
				$domainRegDnsLogic = new logic\manage\domain\DomainRegDnsLogic();
				$return = $domainRegDnsLogic->addRegDns((array) ReturnData::$info);
				if($return['flag'])
				{
					Response::success($return['msg']);
				}
				else 
				{
					Response::error($return['msg']);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 域名注册DNS 查询
	 */
	public function queryRegDnsAction()
	{
		try
		{
			form\manage\domain\DomainEdnsForm::queryRegDns();
			if(ReturnData::$success)
			{
				$domainRegDnsLogic = new logic\manage\domain\DomainRegDnsLogic();
				$return = $domainRegDnsLogic->queryRegDns((array) ReturnData::$info);
				if($return['flag'])
				{
					Response::success($return['data']);
				}
				else 
				{
					Response::error($return['msg']);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 域名注册DNS 更新
	 */
	public function updateRegDnsAction()
	{
		try
		{
			form\manage\domain\DomainEdnsForm::queryRegDns();
			if(ReturnData::$success)
			{
				$domainRegDnsLogic = new logic\manage\domain\DomainRegDnsLogic();
				$return = $domainRegDnsLogic->updateRegDns((array) ReturnData::$info);
				if($return['flag'])
				{
					Response::success($return['msg']);
				}
				else 
				{
					Response::error($return['msg']);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 域名注册DNS 获取记录数
	 */
	public function getRegDnsCountsAction()
	{
		try
		{
			form\manage\domain\DomainEdnsForm::queryRegDns();
			if(ReturnData::$success)
			{
				$domainRegDnsLogic = new logic\manage\domain\DomainRegDnsLogic();
				$return = $domainRegDnsLogic->getRegDnsCounts((array)ReturnData::$info);
				if($return['flag'])
				{
					Response::success($return['data']);
				}
				else 
				{
					Response::error($return['msg']);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	
}

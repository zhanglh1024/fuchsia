<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;
class QueueController extends Yaf\Controller_Abstract
{
	public function indexAction()
	{
	}

	/**
	 * 发送邮件
	 */
	public function sendMailAction()
	{
		try
		{
			form\manage\queue\QueueForm::checkSendMailForm();
			if(ReturnData::$success)
			{
				$queueLogic = new \logic\manage\newqueue\QueueLogic();
				$mailData = array('Function' => ReturnData::$info->function, 'EnameId' => ReturnData::$info->enameId, 'TemplateName' => ReturnData::$info->templateId, 'Target' => ReturnData::$info->email, 'Data' => ReturnData::$info->data, 'Priority' => ReturnData::$info->priority);
				$result = $queueLogic->addQueueNormal($mailData);
				if($result)
				{
					Response::success();
				}
				Response::msg();
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 发送短信
	 */
	public function sendSmsAction()
	{
		try
		{
			form\manage\queue\QueueForm::checkSendSmsForm();
			if(ReturnData::$success)
			{
				$queueLogic = new \logic\manage\newqueue\QueueLogic();
				$smsData = array('Function' => ReturnData::$info->function, 'EnameId' => ReturnData::$info->enameId, 'TemplateName' => ReturnData::$info->templateId, 'Target' => ReturnData::$info->phone, 'Data' => ReturnData::$info->data, 'Priority' => ReturnData::$info->priority);
				$rs = $queueLogic->addQueueNormal($smsData);
				if($rs)
				{
					Response::success();
				}
				Response::msg();
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 发送语音短信
	 */
	public function sendAudioSmsAction()
	{
		try
		{
			form\manage\queue\QueueForm::checkSendSmsForm();
			if(ReturnData::$success)
			{
				$queueLogic = new \logic\manage\newqueue\QueueLogic();
				$audioSmsData = array('Function' => ReturnData::$info->function, 'EnameId' => ReturnData::$info->enameId, 'TemplateName' => ReturnData::$info->templateId, 'Target' => ReturnData::$info->phone, 'Data' => ReturnData::$info->data, 'Priority' => ReturnData::$info->priority);
				$rs = $queueLogic->addQueueNormal($audioSmsData);
				if($rs)
				{
					Response::success();
				}
				Response::msg();
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 添加批量任务，暂时没有对外http调用
	 */
	public function addTaskAction()
	{
		try
		{
			form\manage\queue\QueueForm::checkAddTaskForm();
			if(ReturnData::$success)
			{
				$queueLogic = new \logic\manage\newqueue\QueueLogic();
				$taskData = array('Function' => ReturnData::$info->function, 'EnameId' => ReturnData::$info->enameId, 'Data' => ReturnData::$info->data, 'Priority' => ReturnData::$info->priority, 'Hidden' => ReturnData::$info->hidden);
				$rs = $queueLogic->addQueueTask($taskData);
				if($rs)
				{
					Response::success();
				}
				Response::msg();
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}

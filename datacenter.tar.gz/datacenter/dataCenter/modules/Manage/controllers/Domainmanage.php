<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class DomainManageController extends Yaf\Controller_Abstract
{
	/**
	 * 域名管理
	 */
	public function adminAction() 
	{
		try
		{
			form\manage\domain\DomainManageForm::admin();
			if(ReturnData::$success)
			{
				$manage = new logic\manage\domain\DomainManageLogic();
				Response::success($manage->admin(ReturnData::$info));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取域名自动续费设置
	 */
	public function autoRenewGetAction()
	{
		try
		{
			form\manage\domain\DomainManageForm::autoRenew();
			if(ReturnData::$success)
			{
				$manage = new logic\manage\domain\DomainManageLogic();
				Response::success($manage->autoRenew(ReturnData::$info));
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 更新域名续费设置
	 */
	public function setAutoRenewAction()
	{
		try
		{
			form\manage\domain\DomainManageForm::setautoRenew();
			if(ReturnData::$success)
			{
				$manage = new logic\manage\domain\DomainManageLogic();
				$manage->autoRenewSet(ReturnData::$info);
				Response::success('续费设置修改成功');
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取域名高级搜索的条件（主要是用户域名分组，其他读取配置）
	 */
	public function getAdvanceListAction()
	{
		try
		{
			form\manage\domain\DomainManageForm::getDomainGroup();
			if(ReturnData::$success)
			{
				$manage = new logic\manage\domain\DomainManageLogic();
				Response::success($manage->getDomainGroupList(ReturnData::$info));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 根据条件获取域名列表
	 */
	public function getDomainListByAdvanceAction()
	{
		try
		{
			form\manage\domain\DomainManageForm::advanceSearch();
			if(ReturnData::$success)
			{
				$manage = new logic\manage\domain\DomainManageLogic();
				Response::success($manage->getDomainListByAdvance(ReturnData::$info));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 续费域名
	 */
	public function domainRenewAction()
	{
		try
		{
			form\manage\domain\DomainManageForm::domainRenew();
			if(ReturnData::$success)
			{
				$manage = new logic\manage\domain\DomainManageLogic();
				if(\common\Common::getRequestUser() == 'manage')
				{
					$result = $manage->domainRenew(
						array('domain' => ReturnData::$info->domain, 'year' => ReturnData::$info->period, 
							'expDate' => ReturnData::$info->expDate, 'enameId' => ReturnData::$info->enameId)); // 0611
				}
				else
				{
					$result = $manage->domainRenewOther(ReturnData::$info);
				}
			}
			if($result)
			{
				Response::success("域名续费成功");
			}
			else
			{
				Response::error(Response::getErrMsg(), Response::getErrCode());
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 模板过户（单个）
	 */
	public function templatePushOnceAction()
	{
		try
		{
			form\manage\domain\DomainManageForm::templatePushOnce();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainTemplateLogic();
				$rs = $domainLogic->templatePush((array)ReturnData::$info);
				if (!$rs)
				{
					Response::msg('模板过户失败');
				}
				else
				{
					Response::success('模板过户成功');
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 设置DNS
	 */
	public function setDomainDnsAction()
	{
		try
		{
			form\manage\domain\DomainManageForm::setDomainDns();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainManageLogic();
				$rs = $domainLogic->checkDomainDns((array)ReturnData::$info);
				if (!$rs) 
				{
					Response::msg();
				}
				else
				{
					Response::success('DNS修改成功');
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 设置DNS--队列
	 */
	public function setDnsByQueueAction()
	{
		try
		{
			form\manage\domain\DomainManageForm::setDomainDnsByQueue();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainManageLogic(ReturnData::$info->EnameId);
				$rs = $domainLogic->setDomainDnsByQueue((array)ReturnData::$info);
				if ($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::error($rs['msg']);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 设置DNS前验证域名状态
	 */
	public function setDnsCheckAction()
	{
		try
		{
			form\manage\domain\DomainManageForm::setDomainDns();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainManageLogic(ReturnData::$info->enameId);
				$rs = $domainLogic->checkSetDnsDomainStatus(ReturnData::$info->domain);
				Response::success($rs);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 域名模板过户
	 */
	public function templatePushAction()
	{
		try
		{
			form\manage\domain\DomainManageForm::templatePush();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainManageLogic();
				$rs = $domainLogic->templatePush(ReturnData::$info);
				Response::success($rs);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 域名模板过户(队列）
	 */
	public function tempPushByQueueAction()
	{
		try
		{
			form\manage\domain\DomainManageForm::templatePushByQueue();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainManageLogic(ReturnData::$info->enameId);
				$rs = $domainLogic->templatePushByQueue(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else 
				{
					Response::error($rs['msg']);
				}
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 * 域名模板过户前验证域名状态
	 */
	public function tempPushCheckAction()
	{
		try
		{
			form\manage\domain\DomainManageForm::templatePush();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainManageLogic(ReturnData::$info->enameId);
				$rs = $domainLogic->checkTemplatePushDomainStatus(ReturnData::$info->domain);
				Response::success($rs);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	public function setDomainGroupAction()
	{
		try
		{
			form\manage\domain\DomainManageForm::domainSetGroup();
			if(ReturnData::$success)
		{
			$domainLogic = new logic\manage\domain\DomainManageLogic();
			$rs = $domainLogic->setDomainsGroup(ReturnData::$info);
			Response::success($rs);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 设置或取消隐私保护
	 */
	public function setPrivacyAction()
	{ 
		try
		{ 
			form\manage\domain\DomainManageForm::setPrivacy();
			if(ReturnData::$success)
			{
				$domainLogic = new logic\manage\domain\DomainManageLogic();
				$res = $domainLogic->setPrivacyNew(ReturnData::$info);
				if($res)
				{
					Response::success($res);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 合作接口域名续费转接口
	 */
	public function cooperRegidRenewAction()
	{
		try
		{ 
			form\manage\domain\DomainManageForm::cooperRegidRenewForm();
			if(ReturnData::$success)
			{
				$domainLogic = new \logic\manage\domain\DomainManageLogic();
				$res = $domainLogic->cooperRegidRenew(ReturnData::$info->enameId,ReturnData::$info->domain,ReturnData::$info->orderId);
				if($res)
				{
					Response::success($res);
				}
			}
			Response::error('error');
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}		
	}
}

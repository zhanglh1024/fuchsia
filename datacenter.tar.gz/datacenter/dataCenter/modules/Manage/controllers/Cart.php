<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class CartController extends Yaf\Controller_Abstract
{
	/**
	 * 购物车结算
	 */
	public function resultAction()
	{
		try
		{
			form\manage\cart\CartForm::overCart();
			if(ReturnData::$success)
			{
				$cartLogic = new logic\manage\cart\CartLogic(ReturnData::$info->enameId);
				$return = $cartLogic->overCart(ReturnData::$info);
				Response::success($return);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取域名注册续费转入价格和可以用的模板
	 */
	public function getDomainPriceAction()
	{
		try
		{
			form\manage\cart\CartForm::getDomainPrice();
			if(ReturnData::$success)
			{
				$cartLogic = new logic\manage\cart\CartLogic(ReturnData::$info->enameId);
				Response::success($cartLogic->getDomainPrice(ReturnData::$info));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 获取购物车数量
	 * 
	 * @param $enameId 
	 */
	public function getCartCountAction()
	{
		try 
		{
			form\manage\cart\CartForm::getCartCount();
			if (ReturnData::$success) 
			{
				$cartLogic = new logic\manage\cart\CartLogic(ReturnData::$info->enameId);
				$rs = $cartLogic->getCartCount();
				Response::success($rs);
			}
			Response::error();
		} 
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
	}
	
	/**
	 * 更新购物车
	 *
	 */
	public function updateCartByShopIdAction()
	{
		try
		{
			form\manage\cart\CartForm::updateCartByShopId();
			if (ReturnData::$success) 
			{
				$cartLogic = new logic\manage\cart\CartLogic(ReturnData::$info->EnameId);
				$rs = $cartLogic->updateCartByShopId(ReturnData::$info);
				Response::success($rs);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
	}
}

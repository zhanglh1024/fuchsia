<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class WhoisController extends Yaf\Controller_Abstract
{
	/**
	 *
	 * 获取WHOIS基本信息
	 */
	public function getWhoisAction()
	{
		try
		{
			form\manage\whois\WhoisForm::checkDomain();
			if(ReturnData::$success)
			{
				$userLogic = new logic\manage\whois\WhoisLogic();
				$rs = $userLogic->getWhois(ReturnData::$info->domain);
				if($rs && count($rs) > 1)
				{
					Response::success(array('data'=>$rs));
				}
				else
				{
					Response::msg();
				}

			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 *
	 * 获取WHOIS基本信息含邮箱
	 */
	public function getWhoisHasMailAction()
	{
		try
		{
			form\manage\whois\WhoisForm::checkDomain();
			if(ReturnData::$success)
			{
				$userLogic = new logic\manage\whois\WhoisLogic();
				$rs = $userLogic->getWhois(ReturnData::$info->domain,true);
				if($rs && count($rs) > 1)
				{
					Response::success(array('data'=>$rs));
				}
				else
				{
					Response::msg();
				}
	
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	/**
	 *
	 * 获取WHOIS详细信息
	 */
	public function getWhoisDetailAction()
	{
		try
		{
			form\manage\whois\WhoisForm::checkDomain();
			if(ReturnData::$success)
			{
				$userLogic = new logic\manage\whois\WhoisLogic();
				$rs = $userLogic->getWhoisDetail(ReturnData::$info->domain,ReturnData::$info->WhoisServer);
				if($rs)
				{
					Response::success(array('data'=>$rs));
				}
				else
				{
					Response::msg();
				}
	
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}

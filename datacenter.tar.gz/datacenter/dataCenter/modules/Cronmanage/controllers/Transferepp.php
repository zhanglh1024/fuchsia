
<?php
use core\Response;
use lib\manage\domain\DomainLogsLib;
use lib\manage\common\DomainFunLib;

class TransferEppController extends Yaf\Controller_Abstract
{

	/**
	 * WEBCC转接口同步用户
	 */
	public function transEppAction()
	{
		try
		{
			// 实例化类
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'webcctransfer');
			$client = new yar_client($conf->rpc->manage_other . "/index");
			$mod = new \models\manage\domain\DomainTransferInMod();
			$epp = new \lib\manage\domain\DomainEppLib();
			$dnManagemod = new \models\manage\domain\DomainsMod();
			$ordlogic = new \logic\manage\finance\OrderLogic();
			$redis = \core\RedisLib::getInstance('common');
			$redisKey = 'transepp_domainstatus';
			// 获取记录
			$weblist = array();
			$result = $client->getData(array('status' => '2,5'));
			if($result['flag'] == false)
			{
				\core\Log::write('webcc转接口同步域名状态获取转接口数据失败', 'cronmanage/webcc', 'transferepp');
				exit();
			}
			if($weblist = $result['data'])
			{
				// 15天前的时间
				$nowtime = time() - 1296000;
				foreach($weblist as $key => $val)
				{
					$transferInfo = null;
					\core\Log::write('webcc转接口同步域名状态，域名：' . $val['domain'] . '同步--START', 'cronmanage/webcc', 
						'transferepp');
					// 获取转入表信息
					if($val['status'] == 5)
					{
						if(! $transferInfo = $mod->getTransferInfo(
							array('DomainName' => $val['domain'], 'EnameId' => 667792, 'order' => 'TransferInId desc')))
						{
							\core\Log::write('webcc转接口获取转入信息失败，域名,' . $val['domain'], 'cronmanage/webcc', 'transferepp');
							continue;
						}
					}
					
					// rpc、转入表、域名表默认状态
					$status = $transstatus = 0;
					$domainstatus = 1;
					
					// 获取转接口域名 新注册id
					$domainArr = explode('.', $val['domain']);
					$domailtd = strtoupper($domainArr[count($domainArr) - 1]);
					switch($domailtd)
					{
						case 'CC':
						case 'TV':
							$newregistid = 81;
							break;
						case 'BIZ':
							$newregistid = 82;
							break;
						default:
							$newregistid = 21;
							break;
					}
					$domainfo = $epp->getDomainRegInfo($val['domain'], $newregistid);
					if(!$domainfo)
					{
						if($val['status'] == 2 && ($newregistid == 81 || $newregistid == 82))
						{
							$this->transferEppCheck($val['domain'], 2 ,$val['id'] ); // 转移状态为已发转移密码 检测域名是否还在我司
							continue;
						}
						// 转入表 有数据 不判断 rpc的时间
						if(! empty($transferInfo))
						{
							if($transferInfo['TransferStatus'] == 7)
							{
								$status = 4;
								$transstatus = 7;
							}
							else if(strtotime($transferInfo['UpdateTime']) < $nowtime &&
								 $transferInfo['TransferStatus'] <= 7)
							{
								$status = 4;
								$transstatus = 7;
							}
						}
						else if($val['updateTime'] < $nowtime)
						{
							$status = 4;
						}
					}
					else
					{
						$status = 3;
						$transstatus = 8;
					}
					if($status)
					{
						// 更新epp表域名状态
						$up = $client->updateData($val['id'], array('status' => $status, 'updatetime' => time()));
						if($up['flag'] == false)
						{
							\core\Log::write('webcc转接口同步域名状态更新webcc转接口失败，域名：' . $val['domain'], 'cronmanage/webcc', 
								'transferepp');
							continue;
						}
						
						// 更新转入表状态(正在转接口需要修改转入表记录)
						if($val['status'] == 5 && ! empty($transferInfo) && $transstatus)
						{
							if($transstatus == 7)
							{
								$tranres = $mod->upTransferInfo(array('TransferInId' => $transferInfo['TransferInId']), 
									array('TransferStatus' => $transstatus));
							}
							else
							{
								$tranres = $mod->upTransferInfo(array('TransferInId' => $transferInfo['TransferInId']), 
									array('TransferStatus' => $transstatus, 'SuccessTime' => date('Y-m-d H:i:s')));
							}
							if(! $tranres)
							{
								\core\Log::write('webcc转接口同步转入表失败,域名' . $val['domain'] . '状态：' . $transstatus, 
									'cronmanage/webcc', 'transferepp');
								$client->updateData($val['id'], array('status' => 5, 'updatetime' => time()));
								continue;
							}
							
							// 转入表状态为邮件确认成功或正在转接口 需要添加注册局状态
							if(in_array($transferInfo['TransferStatus'], array(3, 6, 8)))
							{
								$registerid = $status == 3 ? $newregistid : 61;
								if(! $rs = $epp->setDomainRegisterStatus($val['domain'], $registerid, array(3, 4)))
								{
									\core\Log::write('webcc转接口更新注册局状态失败,域名' . $val['domain'], 'cronmanage/webcc', 
										'transferepp');
									$client->updateData($val['id'], array('status' => 5, 'updatetime' => time()));
									$mod->upTransferInfo(array('TransferInId' => $transferInfo['TransferInId']), 
										array('TransferStatus' => $transferInfo['TransferStatus']));
									continue;
								}
							}
						}
						// 恢复域名转接口之前的状态
						$statusres = $redis->get($redisKey . $val['domain']);
						if($statusres)
						{
							$domainstatus = $statusres;
						}
						else
						{
							\core\Log::write('webcc转接口同步域名状态,查询开始域名失败,域名' . $val['domain'], 'cronmanage/webcc', 
								'transferepp');
						}
						
						// 确认订单
						$params = array('enameId' => $val['enameId'], 'orderId' => $val['orderId']);
						$enameId = $val['enameId'];
						$successData = $failData = array();
						$successData['enameId'] = $enameId;
						$successData['domain'] = $val['domain'];
						$successData['oldRegid'] = 'webcc接口';
						$successData['newRegid'] = '厦门易名';
						$successData['expdate'] = $domainfo['expireDate'];
						$successData['adminUrl'] = 'http://www.ename.net/manage/admin/' . $val['domain'];
						$successData['ednsUrl'] = 'http://www.ename.net/dns/domainrecord/' . $val['domain'];
						$successData['domainList'] = 'http://www.ename.net/manage/domainlist';
						$failData['enameId'] = $enameId;
						$failData['domain'] = $val['domain'];
						$failData['adminUrl'] = 'http://www.ename.net/manage/admin/' . $val['domain'];
						if($status == 3)
						{
							$this->sendEmailAndSiteMsg($enameId, $successData, $val['domain']);
							$setData = array(
									'DomainMyStatus' => $domainstatus, 'RegistrarId' => $newregistid, 
									'ExpDate' => $domainfo['expireDate'], 'DomainStatus' => '3,4');
							// webcc 转接口成功后 cc、tv、biz的域名你属性为 11
							if(in_array($domailtd, array('CC', 'TV', 'BIZ')))
							{
								$setData['DomainProperty'] = 11;
							}
							$upDomainInfo = $dnManagemod->upDomainInfo(array('DomainName' => $val['domain']), $setData);
							$rd = $ordlogic->confirmOrder((object) $params);
						}
						else
						{
							$this->sendEmailAndSiteMsg($enameId, $failData, $val['domain'], false);
							$upDomainInfo = $dnManagemod->upDomainInfo(array('DomainName' => $val['domain']), 
								array('DomainMyStatus' => $domainstatus, 'DomainStatus' => '3,4'));
							$rd = $ordlogic->cancelOrder((object) $params);
						}
						if(! $rd)
						{
							\core\Log::write('webcc转接口同步域名状态失败,确认订单失败,域名' . $val['domain'], 'cronmanage/webcc', 
								'transferepp');
						}
						if(! $upDomainInfo)
						{
							$data = array('domain' => $val['domain'], 'oldStatus' => 4, 'newStatus' => $domainstatus);
							\lib\manage\domain\DomainLogsLib::addDomainService($val['domain'], 
								array('memo' => 'transfer_status', 'param' => $data, 'return' => $upDomainInfo), 28);
							\core\Log::write('webcc转接口同步域名状态失败,' . $val['domain'], 'cronmanage/webcc', 'transferepp');
						}
						else
						{
							$data = array('domain' => $val['domain'], 'oldStatus' => 4, 'newStatus' => $domainstatus);
							\lib\manage\domain\DomainLogsLib::addDomainService($val['domain'], 
								array('memo' => 'transfer_status', 'param' => $data, 'return' => $upDomainInfo), 28);
							$redis->del($redisKey . $val['domain']);
						}
					}
					else
					{
						\core\Log::write('webcc转接口同步域名状态错误，域名：' . $val['domain'], 'cronmanage/webcc', 'transferepp');
					}
					if($status == 4) // webcc转接口失败
					{
						$this->transferEppCheck($val['domain'], 4, $val['id']); // 检测域名是否还在我司
					}
					\core\Log::write('webcc转接口同步域名状态，域名：' . $val['domain'] . '同步--END', 'cronmanage/webcc', 
						'transferepp');
				}
			}
		}
		catch(Exception $e)
		{
			\core\Log::write($e->getMessage(), 'cronmanage/webcc', 'transferepp');
		}
	}

	/**
	 * 判断域名是否已经转出到其他注册商 若已经转出到其他注册商
	 * @param string $domain
	 * @param int $status 转接口状态为已发转移密码2 转接口状态为正在转接口5
	 *  @param int $id 转接口记录ID
	 */
	private function transferEppCheck($domain, $status ,$id)
	{
		$dnManagemod = new \models\manage\domain\DomainsMod();
		$domainInfo= $dnManagemod->getDomainInfo(array('DomainName' => $domain));
		if(!$domainInfo)
		{
			return false;
		}
		// 域名是否不在我司
		$epp = new \lib\manage\domain\DomainEppLib();
		$domainRegInfo = $epp->getDomainRegInfo($domain, $domainInfo['RegistrarId'], true);
		if(!(isset($domainRegInfo['resultCode']) && $domainRegInfo['resultCode'] == 5007))
		{
			return false;
		}
		if(!(isset($domainRegInfo['data']['msg']) &&
			stripos($domainRegInfo['data']['msg'], 'System message (Domain Not Found)') !== FALSE))
		{
			return false;
		}
		\core\Log::write($domain.'转接口域名出库', 'cronmanage/webcc', 'transferepp');
		//先发邮件跟踪一段时间
		$sendEmails = array('561305' => 'yangyf@ename.com', '1033657' => 'xuww@ename.com');
		foreach($sendEmails as $enameid => $email)
		{
			$queueLogic = new \logic\manage\newqueue\QueueLogic();
			$queueLogic->addQueueNormal(array('Function' => 'sendmail', 'TemplateName' => 'any_template_info', 'EnameId' => $enameid,
				'Priority' => 5, 'Target' => $email, 'Data' => array('content' => $domain . ':注意检查下转出记录，域名数据及其转接口是否ok', 'title' => '提醒：webcc转接口域名其他注册商转出')));
		}
		// 1. 转接口状态为已发转移密码2 更新转接口状态为失败，
		if($status == 2)
		{
			// 更新epp表域名状态
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'webcctransfer');
			$client = new yar_client($conf->rpc->manage_other . "/index");
			$up = $client->updateData($id, array('status' => 4, 'updatetime' => time()));
			if($up['flag'] == false)
			{
				\core\Log::write('webcc转接口同步域名状态更新webcc转接口失败，域名：' . $domain, 'cronmanage/webcc', 'transferepp');
				return false;
			}
		}
		// 2. 域名状态改为正在转出
		$upDomainInfo = $dnManagemod->upDomainInfo(array('DomainName' => $domain), 
			array('DomainMyStatus' => 5, 'DomainStatus' => '3,4'));
		// 3. 新增一条转出记录状态为成功
		$transoutMod = new \models\manage\domain\DomainTransferOutMod();
		$transoutMod->addTransferOut(array('domainName'=>$domain,'outRegistrarId'=>$domainInfo['RegistrarId'],'status'=>'2','remark'=>'转接口域名转出','enameId'=>$domainInfo['EnameId'],
			'tipWay'=>'0','createIp'=>\common\common::getRequestIp()));
// 		// 4. 给域名出库
// 		$redis = \core\RedisLib::getInstance('common');
// 		$redis->rPush('domain_domainDeleteList', 
// 			json_encode(
// 				array('domainId' => $domainInfo['DomainId'], 'domainName' => $domain, 
// 					'expDate' => date("Y-m-d H:i:s", strtotime("+1 years", strtotime($domainInfo['ExpDate']))))));
		// 4. 转接口域名出库删除域名
		$domainBakMod = new \models\manage\domain\DomainBakMod();
		$domainBakInfo = $domainBakMod->getDomainBakOne(array('DomainId' => $domainInfo['DomainId']));
		// 备份表无信息的时候添加
		if(empty($domainBakInfo))
		{
			$domainBakMod->addDomain($domainInfo);
		}
		$delDomain = $dnManagemod->delDomain($domainInfo['DomainId']);
		$putOutStatus = $delDomain ? 2 : 3;
		\lib\manage\domain\DomainLogsLib::addDomainService($domainInfo['DomainName'],
			array('memo' => '转接口域名出库删除域名', 'param' => $domainInfo['DomainName'], 'return' => $putOutStatus), 62);
		$domainExtMod = new \models\manage\domain\DomainExtMod();
		$domainExtMod->delDomain($domainInfo['DomainId']);
		$domainBakMod->upDomainInfo(array('DomainId' => $domainInfo['DomainId']),
			array('Status' => $putOutStatus));
		$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'domain_delete_success'));
		$amqp->sendMq(array('uid' => $domainInfo['EnameId'], 'dn' => $domainInfo['DomainName'], 'time' => time()));
	}
	
	/**
	 * 转接口成功or失败发送邮件and站内信
	 *
	 * @param
	 *        	$enameId
	 * @param $sendData array        	
	 * @param $status bool
	 *        	转接口成功or失败
	 */
	private function sendEmailAndSiteMsg($enameId, $sendData, $domain, $status = true)
	{
		$userModule = new \models\manage\member\EmemberMod('');
		$queueLib = new \interfaces\manage\Queue();
		$userInfo = $userModule->getMemberInfo($enameId);
		$userEmail = $userInfo['Email'];
		if($status)
		{
			if($queueLib->sendMail('domain_transferpp_notice_mail', $userEmail, $sendData, 0, 0, 'sendmail', 4))
			{
				\core\Log::write('转接口成功发送邮件，域名：' . $domain, 'cronmanage/webcc', 'transferepp');
			}
			else
			{
				\core\Log::write('转接口失败发送邮件，域名：' . $domain, 'cronmanage/webcc', 'transferepp');
			}
			if($queueLib->sendSiteMsg($enameId, 'domain_transferpp_notice_mail', $sendData, 25))
			{
				\core\Log::write('转接口成功发送站内信，域名：' . $domain, 'cronmanage/webcc', 'transferepp');
			}
			else
			{
				\core\Log::write('转接口失败发送站内信，域名：' . $domain, 'cronmanage/webcc', 'transferepp');
			}
		}
		else
		{
			if($queueLib->sendMail('domain_transferpp_notice_fail', $userEmail, $sendData, 0, 0, 'sendmail', 4))
			{
				\core\Log::write('转接口成功发送邮件，域名：' . $domain, 'cronmanage/webcc', 'transferepp');
			}
			else
			{
				\core\Log::write('转接口失败发送邮件，域名：' . $domain, 'cronmanage/webcc', 'transferepp');
			}
			if($queueLib->sendSiteMsg($enameId, 'domain_transferpp_notice_fail', $sendData, 25))
			{
				\core\Log::write('转接口成功发送站内信，域名：' . $domain, 'cronmanage/webcc', 'transferepp');
			}
			else
			{
				\core\Log::write('转接口失败发送站内信，域名：' . $domain, 'cronmanage/webcc', 'transferepp');
			}
		}
	}

	public function checkTransferAction()
	{
		set_time_limit(0);
		$transferEppLogic = new \logic\manage\domain\DomainTransferEppLogic();
		$domainList = $transferEppLogic->getTransferEppList(
			array('status' => 2, 'operateTime<' => date("Y-m-d H:i:s", time() - 5 * 24 * 3600)));
		if(empty($domainList))
		{
			exit("not found data:" . date('Y-m-d H:i:s'));
		}
		$memberLib = new \lib\manage\member\MemberLib();
		$dnLib = new \lib\manage\domain\DomainManageLib();
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		$emailList = array();
		$enameIdList = array();
		foreach($domainList as $info)
		{
			$enameId = $info['Operator'];
			$domain = $info['Domain'];
			$oldEpp = $info['OldApp'];
			$orderId = $info['OrderId'];
			$domainInfo = $dnLib->getDomainInfo(array('DomainName' => $domain, 'EnameId' => $enameId));
			if(empty($domainInfo))
			{
				\core\Log::write('转接口查询域名失败域名：' . $domain, 'cronmanage/inter23', 'transferepp');
				continue;
			}
			if(isset($enameIdList[$enameId]))
			{
				$email = $emailList[$enameId];
			}
			else
			{
				$memberInfo = $memberLib->getMemberBaseInfoByEnameId($enameId);
				if(empty($memberInfo))
				{
					echo '转接口查找用户信息失败：' . $domain . "\r\n";
					\core\Log::write('转接口查找用户信息失败：' . $domain, 'cronmanage/inter23', 'transferepp');
					continue;
				}
				$enameIdList[$enameId] = $enameId;
				$email = $memberInfo["Email"];
				$emailList[$enameId] = $email;
			}
			$regInfo = $sdk->execSdkFun(5025, array('domain' => $domain, 'registrarID' => $oldEpp));
			if($regInfo['resultCode'] == 5007)
			{
				$transferEppLogic->transferEppSuccess($domain, $enameId, $domainInfo, $orderId, $email);
			}
			else
			{
				if($info['OperateTime'] > date("Y-m-d H:i:s", time() - 8 * 24 * 3600))
				{
					continue;
				}
				$transferEppLogic->transferEppFailed($domain, $enameId, $orderId, $email, $info['NewApp'], $regInfo);
			}
		}
	}

	/**
	 * 其他com/net域名转到厦门易名
	 * 前台提交没办法立即成功 只能定时跑 并且提交时间跟间隔时间10分钟后才去提交转入
	 */
	public function checkTransferVspAction()
	{
		$transferEppLogic = new \logic\manage\domain\DomainTransferEppLogic();
		$domainList = $transferEppLogic->getTransferEppList(array('in' => array('Status' => array(6, 7))));
		if(empty($domainList))
		{
			exit("not found data:" . date('Y-m-d H:i:s'));
		}
		$dnLib = new \lib\manage\domain\DomainManageLib();
		$tempLib = new \lib\manage\domain\TemplateLib(); 
		$eppLib = new \lib\manage\domain\DomainEppLib();
		$finance = new \interfaces\manage\Finance();
		$eppMod = new \models\manage\domain\DomainTransferAppMod();
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		foreach($domainList as $info)
		{
			$eppLogic = new \logic\manage\thrift\EppLogic();
			$vspLogic = new \logic\manage\thrift\VspLogic();
			$tranStatus = $info['Status'];
			$enameId = $info['Operator'];
			$domain = $info['Domain'];
			$oldEpp = $info['OldApp'];
			$orderId = $info['OrderId'];
			$newEpp = $info['NewApp'];
			$appId = $info['AppId'];
			if($info['Status'] != 6 && $info['Status'] != 7)
			{
				continue;
			}
			if(time() - strtotime($info['OperateTime']) < 600) // basecode时间限制
			{
				echo "time not start\r\n";
				continue;
			}
			
			$domainInfo = $dnLib->getDomainInfo(array('DomainName' => $domain));
			if(! $domainInfo)
			{
				echo "$domain,not found\r\n";
				DomainLogsLib::addDomainService($domain, 'not found domaininfo', 34);
				continue;
			}
			$domainStatus = $domainInfo['DomainStatus']; // 域名原来的状态信息
			
			if(time() - strtotime($info['OperateTime'])>604800)//7还在处理中的当做失败处理了 通常是code获取不到问题了如 89字眼等
			{
				echo "$domain,time out 7 days\r\n";
				DomainLogsLib::addDomainService($domain, 'time out 7 days', 34);
				$this->setTransferFaild($domain, $oldEpp, $enameId, $orderId, $domainStatus, $appId);
				continue;
			}
			
			$businesscode = $vspLogic->getDomainBusinessCode($domain); // 查询不到可以给重新上传一次
			if(! $businesscode)
			{
				echo $domain . ",not businesscode,reupload\r\n";
				continue;
			}
			$domain = strtolower($domain);
			$baseCode64 = $vspLogic->getDomainBase64Code($domain, $businesscode); // 审核中的
			                                                                      // 或者程序蹦的都算进行中
			if($baseCode64 === 2 || $baseCode64 === FALSE)
			{
				echo "$domain,in auding\r\n";
				DomainLogsLib::addDomainService($domain, 'in auding', 34);
				continue;
			}
			
			if($baseCode64 === 3)
			{
				echo "$domain,unpass\r\n";
				DomainLogsLib::addDomainService($domain, 'unpass', 34);
				$this->setTransferFaild($domain, $oldEpp, $enameId, $orderId, $domainStatus, $appId);
				continue;
			}
			
			$tmpId = $this->checkTemplateIdWhite($domainInfo['TemplateId'], $enameId);
			$templateInfo = $tempLib->getTempInfo($tmpId);
			if(! $templateInfo)
			{
				echo "$domain,not found tempateinfo\r\n";
				DomainLogsLib::addDomainService($domain, 'not found templateinfo', 34);
				continue;
			}
			
			if($templateInfo['CnStatus'] != 2 && $tranStatus == 7) // 续费转接口
			{
				echo "$domain,renewtotransfer\r\n";
				DomainLogsLib::addDomainService($domain, 'renewtotransfer,not cnstatus=2', 34);
				$this->setTransferFaild($domain, $oldEpp, $enameId, $orderId, $domainStatus, $info['AppId']);
				continue;
			}
			
			// 查询域名旧接口信息
			$domainOldInfo = $eppLib->getDomainRegInfo($domain, $oldEpp, true);
			if($domainOldInfo['resultCode'] != 5000)
			{
				DomainLogsLib::addDomainService($domain, array($oldEpp, $domainOldInfo), 34);
				continue;
			}
			
			// 续费转接口检查是否是通过实名的 没有的话给处理下载转接口
			$returnCheck = $this->transferEppVspCheck($domain, $domainOldInfo['data']);
			if(is_array($returnCheck))
			{
				if($returnCheck['resultCode'] != 5000)
				{
					echo "$domain,vsptemplatepush error\r\n";
					continue;
				}
				$domainOldInfo = $eppLib->getDomainRegInfo($domain, $oldEpp, true);
				if($domainOldInfo['resultCode'] != 5000)
				{
					DomainLogsLib::addDomainService($domain, array($oldEpp, $domainOldInfo, 'reback error'), 34);
					continue;
				}
			}
			// 清除状态限制
			$result = $eppLib->setDomainRegisterStatus($domain, $oldEpp, array());
			if(! $result)
			{
				DomainLogsLib::addDomainService($domain, array($oldEpp, 'set status error'), 34);
				continue;
			}
			
			// 提交内部转移
			$result = $eppLogic->domainTransferIn($domain, $domainOldInfo['data']['password'], 1, 
				$templateInfo['TemplateName'], $businesscode);
			if($result['resultCode'] != 5000) // 提交转移失败则回退状态 【退单】
			{
				echo $domain . ",transererro\r\n";
				DomainLogsLib::addDomainService($domain, 
					array('转接口提交失败', $result, $businesscode, $domainOldInfo['data']['password']), 34);
				$this->setTransferFaild($domain, $oldEpp, $enameId, $orderId, $domainStatus, $info['AppId']);
				continue;
			}
			
			// 同意转出
			$result = $eppLib->transferOutDomain($domain, $oldEpp, $enameId);
			// 内部转移正常来说都不会失败 出现失败的另外处理 【这边还是给确认下订单】
			if(! $result)
			{
				$transferOutApp = array(
						'msg' => 'epp:' . $oldEpp . 'transfer approve 5031', 'result' => $result, 
						'oldexp' => $domainInfo['ExpDate']);
				DomainLogsLib::addDomainService($domain, $transferOutApp, 34);
				// $finance->confirmOrder((object)
				// array('enameId'=>$enameId,'orderId'=>$orderId));
				// continue;
			}
			
			// 转移成功后给加锁
			$result = $eppLib->setDomainRegisterStatus($domain, $newEpp, explode(',', $domainStatus));
			if(! $result)
			{
				DomainLogsLib::addDomainService($domain, 
					array('msg' => 'oldepp:' . $newEpp . 'add status', 'param' => $domainStatus, 'result' => 'failed'), 
					34);
			}
			
			// 同步下过期时间
			$domainRegInfo = $eppLib->getDomainRegInfo($domain, $newEpp, true);
			$expDate = $domainRegInfo['resultCode'] == 5000 ? $domainRegInfo['data']['expireDate'] : date("Y-m-d H:i:s", 
				strtotime($domainOldInfo['data']['expireDate'] . "+ 1 year"));
			$setInfo = array(
					'ExpDate' => $expDate, 'DomainStatus' => $domainStatus, 'RegistrarId' => $newEpp, 
					'DomainMyStatus' => $transferEppLogic->domainRedisStatus($domain));
			$transferEppLogic->domainRedisStatus($domain,true);//成功后删除数据
			if(22 == $newEpp)
			{
				$setInfo['DomainProperty'] = 7;
			}
			else
			{
				$setInfo['DomainProperty'] = DomainFunLib::getDomainProductType($domain);
			}
			if($tmpId && $tmpId != $domainInfo['TemplateId'])
			{
				$setInfo['TemplateId'] = $tmpId;
			}
			if(! $dnLib->setDomainInfo(array('DomainId' => $domainInfo['DomainId']), $setInfo))
			{
				DomainLogsLib::addDomainService($domain, array('uplocalfailed', $setInfo), 34);
			}
			$finance->confirmOrder((object) array('enameId' => $enameId, 'orderId' => $orderId));
			if($tranStatus == 7)
			{
				$dnLib->updateTransferOrder($orderId, $enameId, $oldEpp, $newEpp);
			}
			$eppMod->updateTransferApp(array('AppId' => $info['AppId']), array('Status' => 1, 'NewExpDate' => $expDate));
		}
	}

	/**
	 * 转接口失败处理
	 * 
	 * @param unknown $domain        	
	 * @param unknown $oldEpp        	
	 * @param unknown $enameId        	
	 * @param unknown $orderId        	
	 * @param unknown $domainStatus        	
	 * @param unknown $appId        	
	 */
	private function setTransferFaild($domain, $oldEpp, $enameId, $orderId, $domainStatus, $appId)
	{
		$finance = new \interfaces\manage\Finance();
		$eppLib = new \lib\manage\domain\DomainEppLib();
		$dnLib = new \lib\manage\domain\DomainManageLib();
		$eppMod = new \models\manage\domain\DomainTransferAppMod();
		$transferEppLogic = new \logic\manage\domain\DomainTransferEppLOgic();
		$finance->cancelOrder((object) array('enameId' => $enameId, 'orderId' => $orderId));
		$backStatus = is_string($domainStatus) ? explode(',', $domainStatus) : $backStatus;
		$backStatus = $backStatus ? $backStatus : array(3, 4);
		$rebackStatus = $eppLib->setDomainRegisterStatus($domain, $oldEpp, $backStatus);
		$rebackDomain = $dnLib->setDomainInfo(array('DomainName' => $domain), 
			array('DomainMyStatus' => $transferEppLogic->domainRedisStatus($domain)));
		$setAppStatus = $eppMod->updateTransferApp(array('AppId' => $appId), array('Status' => 4));
		$transferEppLogic->domainRedisStatus($domain,true);//转接口失败清楚之前旧的redis信息
		DomainLogsLib::addDomainService($domain, array($rebackStatus, $rebackDomain, $setAppStatus), 34);
	}

	private function checkTemplateIdWhite($templateId, $enameId)
	{
		$templateLib = new \lib\manage\domain\TemplateLib();
		$templateInfo = $templateLib->getTempInfo($templateId);
		if($templateInfo && $templateInfo['CnStatus'] == 2)
		{
			return $templateId;
		}
		$info = $templateLib->getUseTemplates($enameId, 'TransferInTemplate', true);
		if(! empty($info[0]['TemplateId']) && $info[0]['TemplateId'] != $templateId)
		{
			return $info[0]['TemplateId'];
		}
		return $templateId;
	}

	public function transferEppVspCheck($domain,$regInfo)
	{
		if(empty($regInfo["extension"]["verificationCode"]["profile"]["missing"]))
		{
			return true;
		}
		$missInfo = $regInfo["extension"]["verificationCode"]["profile"]["missing"];
		$eppLogic = new \logic\manage\thrift\EppLogic();
		foreach($missInfo as $k => $v)//unknow which
		{
			if($v["type"] == 'domain')//暂时只处理域名的 不处理模板的 模板让用户自己去过户处理
			{
				$return = $eppLogic->domainEppChangeRegistrantTemp(array('domain'=>$domain));
				DomainLogsLib::addDomainService($domain, array('renewtotransferapp not vsp,',$return), 34);
				return $return;
			}
		}
		RETURN TRUE;
	}
}
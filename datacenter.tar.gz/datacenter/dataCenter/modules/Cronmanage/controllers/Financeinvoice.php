<?php
use core\ModBase;
use lib\manage\common\DomainFunLib;
use core\Log;
class FinanceInvoiceController extends Yaf\Controller_Abstract
{
	/**
	 * 修复漏掉的数据
	 */
	public function fixZjjyAction()
	{
		//2015 全部
		set_time_limit(0);
		$financeMod = new \core\ModBase('finance');
		$logic = new \logic\manage\finance\InvoiceLogic();
		$sql2015 = "select sum(InOutMoney) as total,EnameId,2015 as yyear from e_finance_general2015 where Type=1  and InOutType=112 and TypeSon=3 group by EnameId,yyear";
// 		$sql2015 = "select sum(OutMoney) as total,EnameId,2015 as yyear from e_finance_out2015 where outtype=112 and outtypeson=3 group by EnameId,yyear ";
		$zhong2015 = $financeMod->select($sql2015, '', array());
		echo "start 2015\r\n";
		if(!empty($zhong2015))
		{
			foreach($zhong2015 as $info2015)
			{
				if($info2015['yyear'] != date('Y') && $info2015['yyear'] != date('Y') - 1)
				{
					continue;
				}
				if($info2015['total'] <= 0.0000)
				{
					continue;
				}
				$data = array('enameId' => $info2015['EnameId'], 'invoiceFare' => sprintf("%.4f", $info2015['total']),
						'year' => $info2015['yyear']);
				if(!$logic->addInvoiceFare($data))//update = update +
				{
					echo "add user out fare failed\r\n";
					\core\Log::write("failed,origin out" . implode(",", $data), 'finance', 'invoicefareoriginfix');
				}
			}
		}
		echo "start 2016\r\n";
		//2016 部分
		$sql2016 = "select sum(OutMoney) as total,EnameId,2016 as yyear from e_finance_out2016 where outtype=112 and ";
		$sql2016 .= " outtypeson=3  and CreateDate>='2016-01-01 00:00:00' and CreateDate<='2016-02-20 23:59:59' group by EnameId,yyear";
		$zhong2016 = $financeMod->select($sql2016, '', array());
		if(!empty($zhong2016))
		{
			foreach($zhong2016 as $info2016)
			{
				if($info2016['yyear'] != date('Y') && $info2016['yyear'] != date('Y') - 1)
				{
					continue;
				}
				if($info2016['total'] <= 0.0000)
				{
					continue;
				}
				$data = array('enameId' => $info2016['EnameId'], 'invoiceFare' => sprintf("%.4f", $info2016['total']),
						'year' => $info2016['yyear']);
				if(!$logic->addInvoiceFare($data))//update = update +
				{
					echo "add user out fare failed\r\n";
					\core\Log::write("failed,origin out" . implode(",", $data), 'finance', 'invoicefareoriginfix');
				}
			}
		}				 
	}
	
	/**
	 * 从2015-01-01开始，用户在易名的消费，包括注册、续费、转入、保证金、违约金、手续费等，按年统计。（额度只包括今年和去年的，跨年时前年的额度要扣掉）
	 * 跑15年新流水数据   一次性
	 */
	public function getUserInvoiceByNewFareAction()
	{
		set_time_limit(0);
		$financeMod = new \core\ModBase('finance');
		$num = 0;
		$size = 5000;
		$logic = new \logic\manage\finance\InvoiceLogic();
		$tableName = 'e_finance_general2015';
		$tmpTime = strtotime("2015-12-22 23:59:47");
		while(true)//跑出款表
		{
			//目前跑到2015-12-22 23:59:47
			$limit = $num * $size . ',' . $size;
			$sql = "select sum(InOutMoney) as total,EnameId,FROM_UNIXTIME( UpdateTime, '%Y')  as yyear from $tableName where Type=1  and InOutType=5 group by EnameId,yyear";
			$sql .= " limit " . $limit;
			$resultOut = $financeMod->select($sql, '', array());
			if(empty($resultOut))
			{
				echo "handle e_finance_general2015 out  over\r\n";
				break;
			}
			foreach($resultOut as $info)
			{
				if($info['yyear'] != date('Y') && $info['yyear'] != date('Y') - 1)
				{
					continue;
				}
				if($info['total'] <= 0.0000)
				{
					continue;
				}
				$data = array('enameId' => $info['EnameId'], 'invoiceFare' => sprintf("%.4f", $info['total']),
						'year' => $info['yyear']);
				if(!$logic->addInvoiceFare($data))//update = update +
				{
					echo "add user out fare failed\r\n";
					\core\Log::write("failed,origin out" . implode(",", $data), 'finance', 'invoicefareorigin');
				}
			}
			$num++;
		}
		die;
// 		$outNUm = 0;
// 		$tableName = 'e_finance_general2015';
// 		$tmpTime = strtotime('2015-12-22 23:59:47');
// 		while(true)//跑入款表 手续费
// 		{
// 			$secondLimit = $outNUm * $size . ',' . $size;
// 			$inSql = "select sum(FeeMoney) as total,EnameId,FROM_UNIXTIME( UpdateTime, '%Y') as yyear from $tableName ";
// 			$inSql .= " where UpdateTime>{$tmpTime} and InOutType in(8,10,101,102,103,104,105,106,107,108,109,110,113,114,115,116,117,119,121,122,123,124,125,126,127,128,129)";
// 			$inSql .= " and Type=2 and FeeMoney>0.0000 and LinkEnameId!=''";
// 			$inSql .= " group by EnameId,yyear limit $secondLimit";
// 			$resultIn = $financeMod->select($inSql, '', array());
// 			if(empty($resultIn))
// 			{
// 				echo "handler e_finance_general in over\r\n";
// 				break;
// 			}
// 			foreach($resultIn as $info)
// 			{
// 				if($info['yyear'] != date('Y') && $info['yyear'] != date('Y') - 1)
// 				{
// 					continue;
// 				}
// 				if($info['total'] <= 0.0000)
// 				{
// 					continue;
// 				}
// 				$data = array('enameId' => $info['EnameId'], 'invoiceFare' => sprintf("%.4f", $info['total']),
// 						'year' => $info['yyear']);
// 				if(!$logic->addInvoiceFare($data))
// 				{
// 					echo "add user in fare failed\r\n";
// 					\core\Log::write("failed,origin in" . implode(",", $data), 'finance', 'invoicefareorigin');
// 				}
// 			}
// 			$outNUm++;
// 		}
	}

	/**
	 * 扣除已经开过的发票余额 目前仅仅是针对15年的数据
	 * 跑财务已经开过的数据  一次性数据
	 */
	public function invoiceReduceAction()
	{
		set_time_limit(0);
		$invoiceContent = file_get_contents("/tmp/gooduserfare.csv") or die("not found file");
		if(!$invoiceContent)
		{
			die("已开发票数据为空");
		}
		$invoiceArr = explode("\n", $invoiceContent);
		$logic = new \logic\manage\finance\InvoiceLogic();
		$lib = new \lib\manage\finance\FinanceInvoiceLib();
		$year = 2015;
		$bigFare = array();
		foreach($invoiceArr as $invoice)
		{
			if(!trim($invoice))
			{
				continue;
			}
			$infoArr = explode(",", $invoice);
			$enameId = $infoArr[0];
			$invoceNum = sprintf("%.4f", $infoArr[1]);
			if(isset($bigFare[$enameId]))
			{
				$bigFare[$enameId] += $invoceNum;
			}
			else
			{
				$bigFare[$enameId] = $invoceNum;
			}
		}
		if(!$bigFare)
		{
			exit('not data');
		}
		foreach($bigFare as $enameId => $userFare)
		{
			$where = array('enameId' => $enameId, 'year' => $year);
			$fareInfo = $logic->getInvoiceFare($where, TRUE);
			if(!$fareInfo)
			{
				echo "用户{$enameId},还未添加2015消费额度\r\n";
				\core\Log::write("not add fare before," . $enameId . ',' . $year . ',' . $userFare, 'finance', 'invoicefare2015');
				continue;
			}
			if($fareInfo['Canuse'] < $userFare)
			{
				echo "用户{$enameId},2015可开发票额度不足扣除\r\n";
				\core\Log::write("not enough before," . $enameId . ',' . $year . ',' . $userFare . ',' . $fareInfo['Canuse'], 'finance', 'invoicefare2015');
				//continue; 不足的话允许负数
			}
			$update = $lib->updateInvoiceFare($where, array('canUse' => -$userFare, 'used' => $userFare));
			if(!$update)
			{
				echo "更新用户{$enameId},2015可开发票额度失败请重试\r\n";
				\core\Log::write("update fare failed before," . $enameId . ',' . $year . ',' . $userFare, 'finance', 'invoicefare2015');
			}
			else
			{
				echo "更新用户{$enameId},2015可开发票额度成功\r\n";
				echo $enameId . ',' . $year . ',' . $userFare . ',' . $fareInfo['Canuse'] . "\r\n";
				\core\Log::write("update fare success before," . $enameId . ',' . $year . ',' . $userFare . ',' . $fareInfo['Canuse'], 'finance', 'invoicefare2015');
			}
		}
	}
 
	/**
	 * 修复财务漏掉的数据
	 * 跑财务错误的数据需要修复的   一次性
	 */
	public function repareFinanceFareAction()
	{
		set_time_limit(0);
		$invoiceContent = file_get_contents("/tmp/jingjijiaoyineed.csv") or die("not found file");
		if(!$invoiceContent)
		{
			die("已开发票数据为空");
		}
		$invoiceArr = explode("\n", $invoiceContent);
		$logic = new \logic\manage\finance\InvoiceLogic();
		$lib = new \lib\manage\finance\FinanceInvoiceLib();
		$year = 2015;
		$bigFare = array();
		foreach($invoiceArr as $invoice)
		{
			if(!trim($invoice))
			{
				continue;
			}
			$infoArr = explode(",", $invoice);
			$needReduceId = $infoArr[0];//需要扣除
			$needAddId = $infoArr[1];//需要添加
			$invoceNum = sprintf("%.4f", $infoArr[3]);//双方需要增加或者减少的
			$reduceWhere = array('enameId' => $needReduceId, 'year' => $year);
			$needReduceInfo = $logic->getInvoiceFare($reduceWhere, TRUE);
			if(!$needReduceInfo)
			{
				echo "用户reduce:{$needReduceId},还未添加2015消费额度\r\n";
				\core\Log::write("not add fare before reduce," . $needReduceId . ',' . $year . ',' . $invoceNum, 'finance', 'invoicefare2015second');
				continue;
			}
			$addWhere = array('enameId' => $needAddId, 'year' => $year);
			$addInfo = $logic->getInvoiceFare($addWhere, TRUE);
			if(!$addInfo)
			{
				$notexistadd = $logic->addInvoiceFare(array('enameId'=>$needAddId,'year'=>$year,'invoiceFare'=>$invoceNum));
				echo "用户add:{$needAddId},还未添加2015消费额度,重新添加".($notexistadd ? "success" : "failed")."\r\n";
				\core\Log::write("not add fare before add," . $needReduceId . ',' . $year . ',' . $invoceNum, 'finance', 'invoicefare2015second');
				continue;
			}
			$updateReduce = $lib->updateInvoiceFare($reduceWhere, array('canUse' => -$invoceNum, 'used' => $invoceNum));//可用减少 已用增加
			$updateAdd = $lib->updateInvoiceFare($addWhere, array('canUse' => $invoceNum, 'used' => -$invoceNum));//可用增加 已用减少
			$remsg = $updateReduce ? $needReduceId . ',' . $year . ',' . $invoceNum .',reduce,success' :  $needReduceId . ',' . $year . ',' . $invoceNum .',reduce,fail';
			$addmsg = $updateAdd ? $needAddId . ',' . $year . ',' . $invoceNum .',add,success' :  $needAddId . ',' . $year . ',' . $invoceNum .',add,fail';
			echo $remsg ."\r\n";
			echo $addmsg."\r\n";
			\core\Log::write($remsg, 'finance', 'invoicefare2015second');
			\core\Log::write($addmsg, 'finance', 'invoicefare2015second');
		}
	}

	/**
	 * 取消订单的操作  新流水操作简单点  量少直接操作
	 * Remark` varchar(200) NOT NULL DEFAULT '' COMMENT '进出款备注',
	 *`RemarkHide` varch
	 * 1出 2入
	 * 24 25 26  纯消费的
	 * 8 105 121 122 123 102 103 104 106 115 110 108 109 113 114 116 入款 手续费的
	 * 取消订单的操作  新流水 一次性跑
	 */
	public function orderCancelFareAction()
	{
		ini_set("display_errors","On");
		error_reporting(E_ALL);
		set_time_limit(0);
		$mod = new ModBase('finance');
		$table = 'e_finance_general2015';
		$tmpTime = strtotime('2015-12-22 23:59:47');
		//出款入款都可以 这边直接跑入款的
		$cancelSql = "select * from $table where Type=2 and InOutType in(1,108) and (Remark like '%取消订单%' or RemarkHide like '%取消订单%') ";
		$cancelResult = $mod->select($cancelSql, '', array());
		if(empty($cancelResult))
		{
			exit("取消订单暂时无数据\r\n");
		}
		$all = array(24, 25, 26,1,2,3,4,9);
		$manFee = array(8, 105, 121, 122, 123, 102, 103, 104, 106, 115, 110, 108, 109, 113, 114, 116);
		foreach($cancelResult as $info)
		{
			$inEnameId = $info['EnameId'];//现在入款的id
			$enameId = $info['LinkEnameId'];//这个是需要被扣除手续费的用户
			$domain = $info['LinkDomain'];//域名
			$type = $info['InOutType'];//类型
			if(!$enameId && in_array($type,array(1,2,3,4,9)))//通常都是这种人工查理的 不是正常走订单的
			{
				$rightResult = array('FeeMoney'=>0.0000,'InOutMoney'=>$info['InOutMoney'],'EnameId'=>$inEnameId,'UpdateTime'=>$info['UpdateTime']);
			} 
			else
			{
				//根据原来入款的id去查找
				$right = "select * from $table where Type=2 and InOutType=$type and EnameId='{$enameId}' and LinkEnameId='{$inEnameId}' and LinkDomain='{$domain}'";
				$rightResult = $mod->getRow($right, '', array());
			}
			if(empty($rightResult))
			{
				echo "{$enameId},{$inEnameId},{$domain},{$type},取消订单查无数据\r\n";
				\core\Log::write("cancel order not found," . $inEnameId . ',' . $enameId . ',' . $domain . ',' . $type, 'finance', 'invoicefarecancelorder');
				continue;
			}
			$fee = $rightResult['FeeMoney'];
			$inOutMoney = $rightResult['InOutMoney'];
			$fare = in_array($type, $all) ? $inOutMoney : $fee;
			if($fare <= 0.0000)
			{
				continue;
			}
			$enameId = $rightResult['EnameId'];
			$fare = sprintf("%.4f", $fare);
			$year = date('Y', $rightResult['UpdateTime']);//2015
			$invoice = new \logic\manage\finance\InvoiceLogic();
			$invoiceLib = new \lib\manage\finance\FinanceInvoiceLib();
			$userFare = $invoice->getInvoiceFare(array('enameId' => $enameId, 'year' => $year), TRUE);
			if(empty($userFare))
			{
				echo "{$enameId}还未添加发票数据\r\n";
				\core\Log::write("cancel order not add fare befare," . $inEnameId . ',' . $enameId . ',' . $domain . ',' . $type, 'finance', 'invoicefarecancelorder');
			}
			else
			{
				$status = $invoiceLib->updateInvoiceFare(array('enameId' => $enameId, 'year' => $year), array(
						'canUse' => -$fare));
				$message = $status ? 'cancel order,update success,' : 'cancel order,update failed';
				\core\Log::write($message . $enameId . ',' . $year . ',' . $fare . ',' . $userFare['Canuse'].','.$domain, 'finance', 'invoicefarecancelorder');
				if($status && $userFare['Canuse'] < $fare)
				{
					//针对变成复数的记录下
					\core\Log::write('cancel order,fushu,' . $enameId . ',' . $year . ',' . $fare . ',' . $userFare['Canuse'].','.$domain, 'finance', 'invoicefarecancelorder');
				}
				echo "{$enameId},取消订单," . $message . "\r\n";
			}
		}
	}

	/**
	 * 取消订单的操作  新流水操作简单点  量少直接操作
	 * Remark` varchar(200) NOT NULL DEFAULT '' COMMENT '进出款备注',
	 *`RemarkHide` varch
	 * 1出 2入
	 * 24 25 26  纯消费的
	 * 8 105 121 122 123 102 103 104 106 115 110 108 109 113 114 116 入款 手续费的
	 * 跑取消订单的操作  需要每天跑
	 */
	public function orderCancelFareOldAction()
	{
		set_time_limit(0);
		ini_set("display_errors","On");
		error_reporting(E_ALL);
		$mod = new ModBase('finance');
		$table = 'e_finance_in'.date('Y');
		$start = date('Y-m-d', strtotime('-7 days')) .' 00:00:00';
		$end = date('Y-m-d', strtotime('-7 days')) .' 23:59:59';
		//出款入款都可以 这边直接跑入款的
		$cancelSql = "select * from $table where InType in(1,2,3,4,9,8,24,25,26,105,121,122,123,102,103,104,106,115,110,108,109,113,114,116) and (InRemark like '%取消订单%' or InRemarkHide like '%取消订单%') ";
		$cancelSql .=" and CreateDate>='{$start}' and CreateDate<='{$end}'";
		$cancelResult = $mod->select($cancelSql, '', array());
		if(empty($cancelResult))
		{
			exit("取消订单暂时无数据\r\n");
		}
		$all = array(24, 25, 26,1,2,3,4,9,8);
		$manFee = array(8, 105, 121, 122, 123, 102, 103, 104, 106, 115, 110, 108, 109, 113, 114, 116);
		foreach($cancelResult as $info)
		{
			$inEnameId = $info['EnameId'];//现在入款的id
			$enameId = $info['LinkEnameId'];//这个是需要被扣除手续费的用户
			$domain = $info['LinkDomain'];//域名
			$type = $info['InType'];//类型
			//根据原来入款的id去查找
			if($enameId)
			{
				$right = "select * from $table where  InType=$type and EnameId='{$enameId}' and LinkEnameId='{$inEnameId}' and LinkDomain='{$domain}'";
				$rightResult = $mod->getRow($right, '', array());
			}
			else
			{
				if(in_array($type,array(1,2,3,4,9)))//各种人工乱数据 目前已知的
				{
					$rightResult = array('FeeMoney'=>0.0000,'InMoney'=>$info['InMoney'],'EnameId'=>$inEnameId,'CreateDate'=>$info['CreateDate']);
				}
				else
				{
					$rightResult = array();
				}
			}
			if(empty($rightResult))
			{
				echo "{$enameId},{$inEnameId},{$domain},{$type},取消订单查无数据\r\n";
				\core\Log::write("cancel order not found," . $inEnameId . ',' . $enameId . ',' . $domain . ',' . $type, 'finance', 'invoicefarecancelorder');
				continue;
			}
			$fee = $rightResult['FeeMoney'];
			$inOutMoney = $rightResult['InMoney'];
			$fare = in_array($type, $all) ? $inOutMoney : $fee;
			$fare = sprintf("%.4f", $fare);
			if($fare <= 0.0000)
			{
				continue;
			}
			$enameId = $rightResult['EnameId'];
			$year = date('Y', strtotime($rightResult['CreateDate']));//2015
			$invoice = new \logic\manage\finance\InvoiceLogic();
			$invoiceLib = new \lib\manage\finance\FinanceInvoiceLib();
			$userFare = $invoice->getInvoiceFare(array('enameId' => $enameId, 'year' => $year), TRUE);
			if(empty($userFare))
			{
				echo "{$enameId}还未添加发票数据\r\n";
				\core\Log::write("cancel order not add fare befare," . $inEnameId . ',' . $enameId . ',' . $domain . ',' . $type, 'finance', 'invoicefarecancelorder');
			}
			else
			{
				$status = $invoiceLib->updateInvoiceFare(array('enameId' => $enameId, 'year' => $year), array(
						'canUse' => -$fare));
				$message = $status ? 'cancel order,update success,' : 'cancel order,update failed';
				\core\Log::write($message . $enameId . ',' . $year . ',' . $fare . ',' . $userFare['Canuse'].','.$domain, 'finance', 'invoicefarecancelorder');
				if($status && $userFare['Canuse'] < $fare)
				{
					//针对变成复数的记录下
					\core\Log::write('cancel order,fushu,' . $enameId . ',' . $year . ',' . $fare . ',' . $userFare['Canuse'].','.$domain, 'finance', 'invoicefarecancelorder');
				}
				echo "{$enameId},取消订单,{$fare},{$domain}," . ($status ? '成功' : '失败') . "\r\n";
			}
		}
	}

	/**
	 * 退款处理 需要扣除掉对应的发票额度
	 * 手续费 8,101,102,103,104,105,106,107,108,109,110,113,114,115,116,117,118,119,121,122,123,124,125,126,127,128,129  原大类
	 * 新小类
	 * 53一口价
	 * 61违约金
	 * 62;		//预定保证金
	 * 68;		//普通竞价
	 * 数字最好四位小数
	 */ 
	public function backFundAction()
	{
		set_time_limit(0);
		ini_set("display_errors","On");
		error_reporting(E_ALL);
		$mod = new ModBase('finance');
		$invoice = new \logic\manage\finance\InvoiceLogic();
		$invoiceLib = new \lib\manage\finance\FinanceInvoiceLib();
		$start = date('Y-m-d', strtotime('-7 days')) .' 00:00:00';
		$end = date('Y-m-d', strtotime('-7 days')) .' 23:59:59';
		$table = "e_finance_in".date('Y');
		//人工退款    注册42  续费64  转入43   转接口44  赎回63
		$manBackDomain = "select EnameId,sum(InMoney) as tuitotal,year(CreateDate) as year from $table where InType=202 and InTypeSon in(42,43,44,63,64) and CreateDate>='{$start}' and CreateDate<='{$end}' group by EnameId";//注册续费转入转接口赎回数据
		$this->setUserFare($mod->select($manBackDomain, '', array()),202);

		//系统退款
		$sysSql = "select EnameId,sum(InMoney) as tuitotal,year(CreateDate) as year from $table where InType=203 and (InRemark like '%注册域名审核失败%' or InRemark like '%域名赎回退款域名%' ) and CreateDate>='{$start}' and CreateDate<='{$end}' group by EnameId";
		$this->setUserFare($mod->select($sysSql, '', array()),203);

		//人工退款处理逻辑：对于这种涉及到手续费的
		//直接根据每条记录取查找入款流水的记录，条件是：财务类型 一口价+买家id（当前记录的enameid）+域名找到当时的卖家 扣除卖家的手续费
		$otherManSql = "select * from $table where InType=202 and InTypeSon in(53,61,62,68) and CreateDate>='{$start}' and CreateDate<='{$end}'";
		$otherManResult = $mod->select($otherManSql, '', array());
		if($otherManResult)
		{
			foreach($otherManResult as $otherInfo)
			{
				$enameId = $otherInfo['EnameId'];
				$linkDomain = $otherInfo['LinkDomain'];
				$typeSon = $otherInfo['InTypeSon'];
				$oldFinType = $this->getBzjType($linkDomain, $typeSon);
				if(!$oldFinType)
				{
					echo "{$enameId},{$linkDomain},{$typeSon},error fintype,未匹配到数据\r\n";
					continue;
				}
				//正常情况是一条记录就够了
				$oldManFeeSql = "select * from $table where InType=$oldFinType and LinkDomain='{$linkDomain}' and ";
				$oldManFeeSql .= " LinkEnameId=$enameId";
				$oldManFeeResult = $mod->select($oldManFeeSql, '', array());
				if(empty($oldManFeeResult))
				{
					echo "{$enameId},{$linkDomain},{$typeSon},not found manfee,未匹配到数据\r\n";
					continue;
				}
				foreach($oldManFeeResult as $oldManInfo)
				{
					$needReduceEname = $oldManInfo["EnameId"];
					$manFee = $oldManInfo['FeeMoney'];//字段需要在看下
					$year = date('Y', strtotime($oldManInfo['CreateDate']));//字段需要在看下
					$userFare = $invoice->getInvoiceFare(array('enameId' => $needReduceEname, 'year' => $year), TRUE);
					if(empty($userFare))
					{
						echo "手续费类型：{$typeSon},{$linkDomain},{$needReduceEname}还未添加发票数据\r\n";
						\core\Log::write("sys back,man fee not add before" . $needReduceEname . ',' . $year . ',' . $manFee, 'finance', 'invoicefaresysyback');
					}
					else
					{
						$status = $invoiceLib->updateInvoiceFare(array('enameId' => $needReduceEname, 'year' => $year), array(
								'canUse' => -$manFee));
						$message = $status ? 'sys back,man fee update success,' : 'sys back,man fee,update failed';
						\core\Log::write($message . $needReduceEname . ',' . $year . ',' . $manFee . ',' . $userFare['Canuse'], 'finance', 'invoicefaresysyback');
						if($status && $userFare['Canuse'] < $manFee)
						{
							//针对变成复数的记录下
							\core\Log::write('sys back,man fee fushu,' . $needReduceEname . ',' . $year . ',' . $manFee . ',' . $userFare['Canuse'], 'finance', 'invoicefaresysyback');
						}
						echo "手续费类型：{$typeSon},{$oldFinType},{$linkDomain},{$needReduceEname}" . ($status ? '成功' : '失败') . "\r\n";
					}
				}
			}
		}
	}

	/**
	 * 新流水来  第一次跑
	 * 系统退款 人工退款   一次性跑
	 */
	public function backFundNewAction()
	{
		set_time_limit(0);
		ini_set("display_errors","On");
		error_reporting(E_ALL);
		$mod = new ModBase('finance');
		$invoice = new \logic\manage\finance\InvoiceLogic();
		$invoiceLib = new \lib\manage\finance\FinanceInvoiceLib();
		$begin = date('Y-m-d 00:00:00');
		$end = date('Y-m-d 23:59:59');

		$table = "e_finance_general2015";
		//人工退款 --目前最大 2015-12-18 18:08:31    注册42  续费64  转入43   转接口44  赎回63
		$manBackDomain = "select EnameId,sum(InOutMoney) as tuitotal,FROM_UNIXTIME( UpdateTime, '%Y') as year from $table where InOutType=202 and TypeSon in(42,43,44,63,64) group by EnameId";//注册续费转入转接口赎回数据
		$this->setUserFare($mod->select($manBackDomain, '', array()), 202);

		//ok
		//系统退款  --目前最大时间2015-12-21 12:06:19
		//线上数据
		$sysSql = "select EnameId,sum(InOutMoney) as tuitotal,FROM_UNIXTIME( UpdateTime, '%Y') as year from $table where InOutType=203 and (Remark like '%注册域名审核失败%' or RemarkHide like '%域名赎回退款域名%' ) group by EnameId";
		$this->setUserFare($mod->select($sysSql, '', array()), 203);

		//人工退款处理逻辑：对于这种涉及到手续费的
		//直接根据每条记录取查找入款流水的记录，条件是：财务类型 一口价+买家id（当前记录的enameid）+域名找到当时的卖家 扣除卖家的手续费
		$otherManSql = "select * from $table where InOutType=202 and TypeSon in(53,61,62,68)";
		$otherManResult = $mod->select($otherManSql, '', array());
		if($otherManResult)
		{
			foreach($otherManResult as $otherInfo)
			{
				$enameId = $otherInfo['EnameId'];
				$linkDomain = $otherInfo['LinkDomain'];
				$typeSon = $otherInfo['TypeSon'];
				$oldFinType = $this->getBzjType($linkDomain, $typeSon);
				if(!$oldFinType)
				{
					echo "{$enameId},{$linkDomain},{$typeSon},error fintype,未匹配到数据\r\n";
					continue;
				}
				//正常情况是一条记录就够了
				$oldManFeeSql = "select * from $table where InOutType=$oldFinType and LinkDomain='{$linkDomain}' and ";
				$oldManFeeSql .= " LinkEnameId=$enameId";
				$oldManFeeResult = $mod->select($oldManFeeSql, '', array());
				if(empty($oldManFeeResult))
				{
					echo "{$enameId},{$linkDomain},{$typeSon},not found manfee,未匹配到数据\r\n";
					continue;
				}
				foreach($oldManFeeResult as $oldManInfo)
				{
					$needReduceEname = $oldManInfo["EnameId"];
					$manFee = $oldManInfo['FeeMoney'];//字段需要在看下
					$year = date('Y', $oldManInfo['UpdateTime']);//字段需要在看下
					$userFare = $invoice->getInvoiceFare(array('enameId' => $needReduceEname, 'year' => $year), TRUE);
					if(empty($userFare))
					{
						echo "手续费类型：{$typeSon},{$linkDomain},{$needReduceEname}还未添加发票数据\r\n";
						\core\Log::write("sys back,man fee not add before" . $needReduceEname . ',' . $year . ',' . $manFee, 'finance', 'invoicefaresysyback');
					}
					else
					{
						$status = $invoiceLib->updateInvoiceFare(array('enameId' => $needReduceEname, 'year' => $year), array(
								'canUse' => -$manFee));
						$message = $status ? 'sys back,man fee update success,' : 'sys back,man fee,update failed';
						\core\Log::write($message . $needReduceEname . ',' . $year . ',' . $manFee . ',' . $userFare['Canuse'], 'finance', 'invoicefaresysyback');
						if($status && $userFare['Canuse'] < $manFee)
						{
							//针对变成复数的记录下
							\core\Log::write('sys back,man fee fushu,' . $needReduceEname . ',' . $year . ',' . $manFee . ',' . $userFare['Canuse'], 'finance', 'invoicefaresysyback');
						}
						echo "手续费类型：{$typeSon},{$oldFinType},{$linkDomain},{$needReduceEname}" . ($status ? '成功' : '失败') . "\r\n";
					}
				}
			}
		}
	}

	/**
	 * 保证金类型
	 * 24; //.中国预订保证金
	 * 25; //com预订保证金   根据后缀来判断
	 * 26; //NET预订保证金
	 */
	public function getBzjType($domain, $typeSon)
	{
		$typeTypeSon = array('53' => '106', '61' => '109', '68' => '102');
		if(isset($typeTypeSon[$typeSon]))
		{
			return $typeTypeSon[$typeSon];
		}
		if($domain)
		{
			$ltd = \lib\manage\common\DomainFunLib::getDomainClass($domain);
			$ltdType = array('CN' => 24, '中国' => 24, 'COM' => '25', 'NET' => '26');
			return isset($ltdType[$ltd]) ? $ltdType[$ltd] : FALSE;
		}
		return FALSE;
	}

	public function repareRefundAction()
	{
		
	}
	
	
	
	private function setUserFare($result, $systype)
	{
		if(empty($result))
		{
			echo $systype . ",暂时无退款\r\n";
			return true;
		}
		$invoice = new \logic\manage\finance\InvoiceLogic();
		$invoiceLib = new \lib\manage\finance\FinanceInvoiceLib();
		foreach($result as $info)
		{
			$enameId = $info['EnameId'];
			$fare = sprintf("%.4f", $info['tuitotal']);
			$year = $info['year'];
			$userFare = $invoice->getInvoiceFare(array('enameId' => $enameId, 'year' => $year), TRUE);
			if(empty($userFare))
			{
				echo "{$enameId},{$systype},还未添加发票数据\r\n";
				\core\Log::write("{$systype},sys back,not add before" . $enameId . ',' . $year . ',' . $fare, 'finance', 'invoicefaresysyback');
			}
			else
			{
				$status = $invoiceLib->updateInvoiceFare(array('enameId' => $enameId, 'year' => $year), array(
						'canUse' => -$fare));
				$message = $status ? "{$systype},sys back,update success" : "{$systype},sys back,update failed";
				\core\Log::write($message . $enameId . ',' . $year . ',' . $fare . ',' . $userFare['Canuse'], 'finance', 'invoicefaresysyback');
				if($status && $userFare['Canuse'] < $fare)
				{
					//针对变成复数的记录下
					\core\Log::write("{$systype},sys back,fushu," . $enameId . ',' . $year . ',' . $fare . ',' . $userFare['Canuse'], 'finance', 'invoicefaresysyback');
				}
				echo "{$enameId},{$systype},系统退款" . ($status ? '成功' : '失败') . "\r\n";
			}
			return true;
		}
	}
}

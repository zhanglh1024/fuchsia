<?php 
use core\ModBase;
use lib\manage\domain\DomainLogsLib;
use lib\manage\common\DomainFunLib;

class DomainController extends Yaf\Controller_Abstract
{

	/**
	 * webcc过期域名删除
	 *
	 * @param
	 *        	是否全部接口 1：是 0：只有61接口
	 */
	public function delWebccDomainAction($params = array())
	{
		set_time_limit(0);
		ini_set('memory_limit', '200M'); 
		$domainLib = new \lib\manage\domain\DomainManageLib();
		if(empty($params[0]))
		{
			$where = array('ExpDate<' => gmdate('Y-m-d H:i:s', time() - 40 * 24 * 3600), 'RegistrarId' => 61);
		}
		else
		{
			$where = array('ExpDate<' => gmdate('Y-m-d H:i:s', time() - 46 * 24 * 3600));
		}
		$order = 'ExpDate desc';
		$domainList = $domainLib->getDomainList($where, '', $order); // 量少直接删除
		if(empty($domainList))
		{
			exit(date('Y-m-d H:i:s') . ",not found webcc domain\r\n");
		}
		$eppLib = new \lib\manage\domain\DomainEppLib();
		foreach($domainList as $webcc)
		{
			$return = $this->delDomain($webcc, $eppLib);
			\core\Log::write("delete_expire_webcc_" . ($return ? 'success' : 'failed') . '_' . $webcc['DomainName'], 
				'cronmanage/domain', 'del_webcc');
		}
	}

	/**
	 * 中旭过期域名删除
	 */
	public function delZhongXuDomainAction()
	{
		set_time_limit(0);// 用来限制页面执行时间
		ini_set('memory_limit', '200M');// ini_set()具有更改PHP.ini设置
		$domainLib = new \lib\manage\domain\DomainManageLib();
		$where = array('RegistrarId' => 11, 'ExpDate <' => gmdate('Y-m-d H:i:s', time() - 29 * 24 * 3600));
		$order = 'ExpDate desc';
		$domainList = $domainLib->getDomainList($where, '', $order); // 量少直接删除
		if(empty($domainList))
		{
			exit(date('Y-m-d H:i:s') . ",not found zhongxu domain\r\n");
		}
		foreach($domainList as $domain)
		{
			$return = $this->delDomianOnly($domain);
			\core\Log::write("delete_expire_zhongxu_" . ($return ? 'success' : 'failed') . '_' . $domain['DomainName'], 
				'cronmanage/domain', 'del_zhongxu');
		}
	}

	/**
	 * 单独删除域名
	 */
	private function delDomianOnly($domainInfo)
	{
		$domain = $domainInfo['DomainName'];
		$domainId = $domainInfo['DomainId'];
		$enameId = $domainInfo['EnameId'];
		$domainExtMod = new \models\manage\domain\DomainExtMod();
		$domainExt = $domainExtMod->getOneDomainExt(array('DomainId' => $domainId));
		if(! $domainExt)
		{
			$domainExt = array(
					'DomainId' => $domainId, 'Dns' => '', 'DomainFrom' => '1', 'DomainIcp' => '', 'TemplateType' => '1', 
					'Remark' => '', 'Tooltip' => '1', 'TooltipWay' => '1,2,3', 'pwd' => '');
		}
		if(isset($domainExt['EnameId']))
		{
			unset($domainExt['EnameId']);
		}
		if(isset($domainInfo['Roid']))
		{
			unset($domainInfo['Roid']);
		}
		$lib = new \lib\manage\domain\DomainTransferLib($enameId);
		if(! empty($domainInfo) && ! empty($domainExt))
		{
			// 包括域名表和扩展表 存在则更新 写入域名备份表失败才终止
			if(! $lib->deleteDomain($domain, $domainInfo, $domainExt, 1))
			{
				\core\Log::write("zhongxu_deldomainext_failed_" . $domain, 'cronmanage/domain', 'del_zhongxu');
				return false;
			}
		}
		
		$domainmod = new \models\manage\domain\DomainsMod();
		$delInfo = $domainmod->delDomain($domainId);
		if($delInfo)
		{
			if(FALSE == $domainExtMod->delDomain($domainId))
			{
				\core\Log::write("zhongxu_deldomainext_failed_" . $domain, 'cronmanage/domain', 'del_zhongxu');
			}
			// 域名删除通知消息中心
			$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'domain_delete_success'));
			$amqp->sendMq(array('uid' => $enameId, 'time' => time(), 'dn' => $domain));
			return TRUE;
		}
		\core\Log::write("zhongxu_deldomainext_failed_" . $domain, 'cronmanage/domain', 'del_zhongxu');
		return FALSE;
	}

	/**
	 * 删除域名
	 */
	private function delDomain($domainInfo, $eppLib)
	{
		$domain = $domainInfo['DomainName'];
		$domainId = $domainInfo['DomainId'];
		$enameId = $domainInfo['EnameId'];
		$registrarId = $domainInfo['RegistrarId'];
		if($registrarId != 61)
		{
			$regInfo = $eppLib->getDomainRegInfo($domain, $registrarId);
			if(empty($regInfo))
			{
				\core\Log::write("delete_expire_webcc_failed_" . $domain, 'cronmanage/domain', 'del_webcc');
				continue;
			}
			if(stripos($regInfo['status'], 'server') !== false)
			{
				\core\Log::write("delete_expire_webcc_failed_" . $domain . '出库失败，状态：' . $regInfo['status'], 
					'cronmanage/domain', 'del_webcc');
				continue;
			}
		}
		$domainExtMod = new \models\manage\domain\DomainExtMod();
		$domainExt = $domainExtMod->getOneDomainExt(array('DomainId' => $domainId));
		if(! $domainExt)
		{
			$domainExt = array(
					'DomainId' => $domainId, 'Dns' => '', 'DomainFrom' => '1', 'DomainIcp' => '', 'TemplateType' => '1', 
					'Remark' => '', 'Tooltip' => '1', 'TooltipWay' => '1,2,3', 'pwd' => '');
		}
		if(isset($domainExt['EnameId']))
		{
			unset($domainExt['EnameId']);
		}
		if(isset($domainInfo['Roid']))
		{
			unset($domainInfo['Roid']);
		}
		$lib = new \lib\manage\domain\DomainTransferLib($enameId);
		if(! empty($domainInfo) && ! empty($domainExt))
		{
			// 包括域名表和扩展表 存在则更新 写入域名备份表失败才终止
			if(! $lib->deleteDomain($domain, $domainInfo, $domainExt, 1))
			{
				\core\Log::write("webcc_domainbakdata_failed_" . $domain, 'cronmanage/domain', 'del_webcc');
				return false;
			}
		}
		// 删除域名dns修改，排除webcc
		if(61 != $registrarId)
		{
			$rs = $eppLib->setDomainDns($domain, 0, array('dns1' => 'rep1.iidns.com', 'dns2' => 'rep2.iidns.com'), 
				$registrarId);
			if(! empty($rs))
			{
				\core\Log::write("webcc_change_domain_rep_dns_success_" . $domain . "DNS更改rep为成功", 'cronmanage/domain', 
					'del_webcc');
			}
			else
			{
				\core\Log::write("webcc_change_domain_rep_dns_failed_" . $domain . "DNS更改rep为失败", 'cronmanage/domain', 
					'del_webcc');
			}
		}
		$domainmod = new \models\manage\domain\DomainsMod();
		$delInfo = $domainmod->delDomain($domainId);
		if($delInfo)
		{
			if(FALSE == $domainExtMod->delDomain($domainId))
			{
				\core\Log::write("webcc_deldomainext_failed_" . $domain, 'cronmanage/domain', 'del_webcc');
			}
			// 域名删除通知消息中心
			// $msgCenter = new \common\MsgCenterLib();
			// $msgCenter->addMsgList(1003, array('enameid' => $enameId, 'toid'
			// => 0, 'domain' => $domain));
			$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'domain_delete_success'));
			$amqp->sendMq(array('uid' => $enameId, 'dn' => $domain, 'time' => time()));
		}
		\core\Log::write("webcc_deldomain_failed_" . $domain, 'cronmanage/domain', 'del_webcc');
		return FALSE;
	}

	/**
	 * 更新域名的roid，whois改整，只需处理com net cc tv
	 * 慢查询，数据量太大一次跑250个，不让select太频繁，一个小时执行一次
	 */
	public function setDomainRoidAction()
	{
		$hours = date('H', time());
		if($hours >= '02' && $hours < '05') // 2点到5点跳过
		{
			exit('0205time');
		}
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$domainLib = new \lib\manage\domain\DomainManageLib();
		$sdk = new \ApiSdk();
		// $result = $domainLib->getDomainList(array('Roid' => '', 'in' =>
		// array('DomainLtd' => array(3, 4, 11, 17))), '0,10');
		// 数据量太多，临时改为跑接口
		$result = $domainLib->getDomainList(
			array('Roid' => '', 'in' => array('RegistrarID' => array(21, 22, 23, 24, 25, 26))), '0,250');
		if(empty($result))
		{
			break;
		}
		foreach($result as $domainInfo)
		{
			$sdkInfo = $sdk->execSdkFun(5025, array('domain' => $domainInfo['DomainName'], 'registrarID' => $domainInfo['RegistrarId']));
			if($sdkInfo['resultCode'] == 5000)
			{
				if(empty($sdkInfo['data']['roid'])) 
				{
					\core\Log::write("roidNil：" . $domainInfo['DomainName'], 'cronmanage/domain', 'setDomainRoid');
				}
				else 
				{
					$upInfo = $domainLib->setDomainInfo(array('DomainName' => $domainInfo['DomainName']), array('Roid' => $sdkInfo['data']['roid']));
					if(! $upInfo)
					{
						\core\Log::write("upfailed：" . $domainInfo['DomainName'], 'cronmanage/domain', 'setDomainRoid');
					}
				}
			}
			else
			{
				\core\Log::write("5025failed：" . $domainInfo['DomainName'], 'cronmanage/domain', 'setDomainRoid');
			}
		}
	}
	
	public function updatePrivacyMailCheckAction()
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'webcctransfer');
		$client = new \yar_client($conf->rpc->manage_other . "/privacyMail");
		$rs = json_decode($client->getPrivacyMailCheck(array()), true);
		if($rs['data']['flag'] && $rs['data']['num'] > 0)
		{
			foreach($rs['data']['list'] as $v)
			{
				// 邮件标题base64解码，先替换编码标识开头和结尾后做base64解码然后做gbk转utf8
				$tmpTitle = str_ireplace(array('=?gb2312?B?', '=?utf-8?B?', '=?gb18030?B?'), '', $v['MailTitle'], 
					$repcount);
				if($repcount)
				{
					$tmpTitle = imap_mime_header_decode($v['MailTitle'])[0]->text;
					// gbk强转utf8
					if(stripos($v['MailTitle'], "=?gb") !== FALSE && substr($v['MailTitle'], - 2) == '?=')
					{
						$tmpTitle = @iconv("GBK", "UTF-8//TRANSLIT//IGNORE", $tmpTitle);
					}
				}
				// 更新操作
				if($tmpTitle)
				{
					$client->updatePrivacyMailCheck($v['Id'], 0, array('MailTitle' => $tmpTitle));
				}
			}
		}
	}

	/**
	 * 定时任务--抢注入库的域名
	 */
	public function qiangzhuDomainAction()
	{
		try
		{
			$domainMod = new ModBase('qz');
			DomainLogsLib::addDomainService('qz.add', array('memo' => 'qiangzhu_add', 'c' => '执行了域名抢注入库'), 26);
			$delDate = date("Y-m-d");
			$startTime = strtotime($delDate . " 00:00:00");
			$endTime = strtotime($delDate . " 23:59:59");
			$list = $domainMod->select(
				"select * from domain where RegTime>='$startTime' and RegTime<='$endTime' order by RegTime Desc", '', 
				array());
			if($list !== false)
			{
				// $registar=new \lib\epp\config\Registar();
				// $regArr=$registar::$eppId;
				$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'qiangzhu');
				$regArr = $conf->epp_registar_id->toArray();
				// 添加中文域名的转码
				$punycode = new \common\Punycode();
				$domainLib = new \lib\manage\domain\DomainManageLib();
				$epp = new \lib\manage\domain\DomainEppLib();
				$redis = new \lib\manage\common\RedisLib();
				$queue = new \interfaces\manage\Queue();
				$qiangzhu = new \lib\manage\domain\DomainRegistLib();
				$domainPushLib = new \lib\manage\domain\DomainPushLib();
				foreach($list as $v)
				{
					$punyDomain = $punycode->decode($v['DomainName']);
					$templateId = \lib\manage\common\DomainFunLib::isChinaDomain($punyDomain) ? $conf->qiangzhuTempCn : $conf->qiangzhuTempNet;
					if(! $punyDomain)
					{
						DomainLogsLib::addDomainService('qz.add', 
							array('memo' => 'qiangzhu_add', 'domain' => $v['DomainName'], 'c' => '转码后的域名不存在'), 26);
						continue;
					}
					if($domainLib->getDomainInfo(array('DomainName' => $punyDomain)))
					{
						DomainLogsLib::addDomainService($punyDomain, 
							array('memo' => 'domain_exits', 'c' => '域名已经存在放弃入库'), 26);
						continue;
					}
					$regName = trim(strtolower($v['RegistrarName']));
					$regName = ($regName == 'eeqq') ? 'eeau' : $regName;
					$regId = isset($regArr[$regName]) ? $regArr[$regName] : FALSE;
					if($regId == false)
					{
						DomainLogsLib::addDomainService($punyDomain, 
							array('memo' => 'registrarId_not_exits', 'c' => $regName), 26);
						continue;
					}
					$createDate = $expireDate = '';
					$domainData = $epp->getDomainRegInfo($punyDomain, $regId);
					if(! $domainData)
					{
						DomainLogsLib::addDomainService($punyDomain, 
							array('memo' => '5025_is_not_info', 'info' => "查询域名注册局信息失败"), 26);
						$times = $redis->getData('qz_sdk_times');
						if($times && $times == date("Y-m-d"))
						{
							return true;
						}
						if($times == false)
						{
							$redis->setData("qz_sdk_times", date("Y-m-d"));
						}
						$queue->sendSms('any_template_info', $conf->qiangzhuMobile, 
							array('title' => $punyDomain, 'content' => '抢注入库失败,查询域名注册局信息失败'), $conf->qiangzhuEnameId, 0, 
							'send_sms', 5);
						continue;
					}
					else
					{
						$createDate = date("Y-m-d H:i:s", strtotime($domainData['data']['createDate']));
						$expireDate = date("Y-m-d H:i:s", strtotime($domainData['data']['expireDate']));
					}
					$tempName = \lib\manage\common\DomainFunLib::isChinaDomain($punyDomain) ? '临时模板1' : '临时模板2';
					$productType = \lib\manage\common\DomainFunLib::getDomainProductType($punyDomain);
					$return = $qiangzhu->domainInDbBaseTable($punyDomain, $regId, $createDate, $expireDate, $createDate, 
						$conf->newQiangzhuUserId, $tempName, $templateId, $productType);
					if(! $return)
					{
						DomainLogsLib::addDomainService($punyDomain, array('memo' => 'insert_fail_dc', 'c' => '域名入库失败'), 
							26);
						continue;
					}
					DomainLogsLib::addDomainService($domain, array('memo' => 'insert_success_dc', 'c' => '域名入库成功'), 26);
					$domainPushLib->domainExtAdd($return, $conf->newQiangzhuUserId, 
						\lib\manage\common\DomainFunLib::isChinaDomain($punyDomain) ? 4 : 2);
					$epp->setDomainRegisterStatus($punyDomain, $regId);
					$epp->setDomainDns($punyDomain, 1, array('dns1.iidns.com'), $regId);
				}
			}
			else
			{
				echo '没有需要抢注入库的域名';
				DomainLogsLib::addDomainService('qz.add', array('memo' => 'qiangzhu_add', 'c' => '没有读取到数据'), 26);
			}
			DomainLogsLib::addDomainService('qz.add', array('memo' => 'qiangzhu_add', 'c' => 'over'), 26);
		}
		catch(Exception $e)
		{
			DomainLogsLib::addDomainService('qz.add', array('memo' => 'qiangzhu_add', 'error' => $e->getMessage()), 26);
		}
	}

	/**
	 * 队列删除域名
	 */
	public function delQueueDnAction()
	{
		try
		{
			$redis = \core\RedisLib::getInstance('common');
			for($i = 0; $i < 100; $i ++)
			{
				$list = $redis->blPop('domain_domainDeleteList', 10);
				$putOutStatus = 3;
				if(is_array($list) && count($list) == 2)
				{
					$v = json_decode($list[1], true);
					$persistMod = new \models\manage\domain\DomainPersistMod();
					$domainMod = new \models\manage\domain\DomainsMod();
					$domainBakMod = new \models\manage\domain\DomainBakMod();
					$domainExtMod = new \models\manage\domain\DomainExtMod();
					$domainDelMod = new \models\manage\domain\DomainDelMod();
					include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
					$sdk = new \ApiSdk();
					$domain = $domainMod->getDomainInfo(array('DomainId' => $v['domainId']));
					\core\Log::write(json_encode($domain), 'cronmanage/domain', 'domain_delete');
					if(! empty($domain))
					{
						$domainBakInfo = $domainBakMod->getDomainBakOne(array('DomainId' => $v['domainId']));
						// 备份表无信息的时候添加
						if(empty($domainBakInfo))
						{
							$domainBakMod->addDomain($domain);
						}
						if($domain['ExpDate'] == $v['expDate'] && $domain['ExpDate'] < date('Y-m-d H:i:s', 
							time() + 172800)) // 域名没有续费，继续执行出库删除
						{
							$persist = $persistMod->getDomainInfo(array('Domain' => $domain));
							if(! empty($persist)) // 不存在保留域名表中，进行出库和注册局删除
							{
								$params = array(
										'domain' => $v['domainName'], 'status' => array(), 
										'registrarID' => $domain['RegistrarId']);
								$info = $sdk->execSdkFun(5012, $params);
								\core\Log::write('5012:' . json_encode($info), 'cronmanage/domain', 
									'domain_delete_list');
								$status = $info['resultCode'] == 5000 ? 2 : 3;
								$domainDelMod->addDomainDel(
									array(
											'domainId' => $v['domainId'], 'domain' => $v['domainName'], 
											'status' => $status, 'result' => $info));
								$regParams = array(
										'domain' => $v['domainName'], 'registrarID' => $domain['RegistrarId']);
								$delInfo = $sdk->execSdkFun(5004, $regParams); // 注册局删除域名
								\core\Log::write('5004:' . json_encode($delInfo), 'cronmanage/domain', 'domain_delete_list');
								$status = $delInfo['resultCode'] == 5000 ? 2 : 3; // 删除成功状态是2，失败时3
								$domainDelMod->addDomainDel(
									array(
											'domainId' => $v['domainId'], 'domain' => $v['domainName'], 
											'status' => $status, 'result' => $delInfo)); // 记录注册局删除域名返回结果
								if($delInfo['resultCode'] == 5000)
								{
									// 域名删除通知消息到监控中心			
									$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'domain_delete_success'));
									$amqp->sendMq(array('uid' => $domain['EnameId'], 'dn' => $v['domainName'], 'time' => time()));
									$delDomain = $domainMod->delDomain($v['domainId']);
									$putOutStatus = $delDomain ? 2 : 3;
									$domainExtMod->delDomain($v['domainId']);
								}
								$domainBakMod->upDomainInfo(array('DomainId' => $v['domainId']), 
									array('Status' => $putOutStatus));
							}
							else
							{
								$domainBakMod->upDomainInfo(array('DomainId' => $v['domainId']), array('Status' => 5));
							}
						}
						else
						{
							$domainBakMod->upDomainInfo(array('DomainId' => $v['domainId']), array('Status' => 4));
						}
					}
				}
			}
		}
		catch(\Exception $e)
		{
			\core\Log::write($e->getMessage(), 'cronmanage/domain', 'domain_delete');
			exit($e->getMessage());
		}
	}

	/**
	 * 获取7天内注册的cn域名，写入redis，供检测实际是否注册成功调用
	 */
	public function getCnCheckDnAction()
	{
		$day = 8;
		$i = $n = 0;
		$num = 500;
		try
		{
			$redis = \core\RedisLib::getInstance('common');
			$dnMod = new ModBase('domain');
			while(true)
			{
				$query = "select * from e_domains where RegDate<'" . gmdate("Y-m-d", time() - ($day - 2) * 24 * 3600) .
					 " 23:59:59' and RegDate>'" . gmdate("Y-m-d", time() - $day * 24 * 3600) .
					 " 00:00:00' and (ClassName=1 or ClassName=3) order by DomainId asc limit " . ($i * $num) . ',' .
					 $num;
				$dnList = $dnMod->select($query, '', array());
				if(! empty($dnList))
				{
					++ $i;
					foreach($dnList['data'] as $v)
					{
						++ $n;
						$data = array(
								'domain' => $v['DomainId'], 'domainName' => $v['DomainName'], 
								'createDate' => $v['RegDate'], 'registrarId' => $v['RegistrarId'], 
								'enameId' => $v['EnameId']);
						if(! $redis->rPush('domain_checkCnDomain', json_encode($data)))
						{
							DomainLogsLib::addDomainService($v['DomainName'], 
								'定时任务--检测最近7天注册的CN域名，加入redis失败' . json_encode($data), 27);
						}
					}
				}
				else
				{
					break;
				}
			}
			$dnSize = $redis->lSize('domain_checkCnDomain');
			if($dnSize > 20000)
			{
				$queueLogic = new \logic\manage\newqueue\QueueLogic();
				$params = array(
						'Function' => 'send_sms', 'Target' => "15280250851", 'EnameId' => 561305, 'Priority' => 5, 
						'Data' => array('content' => "cn域名注册审核数量达到" . $dnSize . "个,您可以关注并手动执行"), 
						'TemplateName' => 'any_template_info');
				$queueLogic->addQueueNormal($params); // 提醒到亚凤
				$params['Target'] = "14759283577";
				$params['EnameId'] = 618264;
				$queueLogic->addQueueNormal($params); // 提醒到建平
			}
		}
		catch(\Exception $e)
		{
			DomainLogsLib::addDomainService('cron_get_cn_domain', '定时任务--检测最近7天注册的CN域名，' . $e->getMessage(), 27);
		}
	}

	/**
	 * 检测cn域名是否实际注册成功
	 */
	public function checkCnRegFailAction()
	{
		try
		{
			$redis = \core\RedisLib::getInstance('common');
			for($i = 0; $i < 20; $i ++)
			{
				$list = $redis->blPop('domain_checkCnDomain', 10);
				if(is_array($list) && count($list) == 2)
				{
					$data = json_decode($list[1]);
					if(! DomainFunLib::isChinaDomain($data->domainName))
					{
						continue;
					}
					if($this->checkDomainIsExits($data->domainName, $data->registrarId, $data->createDate))
					{
						continue;
					}
					if(! $this->deleteDomainByDomainId($data->domain, $data->domainName))
					{
						continue;
					}
					$orderId = $this->treatOrder($data->domainName, $data->enameId, $data->domain, $data->createDate);
					if($orderId !== false)
					{
						$this->backOrder($orderId, $data->enameId, $data->domainName);
					}
				}
				else
				{
					DomainLogsLib::addDomainService('cron_check_cn_domain', '数据获取失败' . json_encode($list), 27);
				}
				sleep(1);
			}
		}
		catch(\Exception $e)
		{
			DomainLogsLib::addDomainService('cron_check_cn_domain', '定时任务--检测最近7天注册的CN域名，' . $e->getMessage(), 27);
		}
	}

	private function checkDomainIsExits($domain, $registrarId, $regDate)
	{
		$eppLib = new \lib\manage\domain\DomainEppLib();
		$check = true;
		// 查询域名注册局信息
		$info = $eppLib->getDomainRegInfo($domain, $registrarId);
		\core\Log::write($domain . '|' . json_encode($info), 'cronmanage/domain', 'check_cn_domain_reg_fail');
		if(! empty($info))
		{
			$createData = strtotime($info['createDate']);
			if(abs(strtotime($regDate) - $createData) < 3600)
			{
				return true;
			}
			else
			{
				$check = false;
			}
		}
		\core\Log::write($domain . '|' . json_encode(array('regdate' => $regDate, 'result' => $info)), 
			'cronmanage/domain', 'check_cn_domain_reg_fail');
		if($check === true) // 查询接口返回非5000的值
		{
			if(! isset($info['msg']))
			{
				return true;
			}
			$resultMsg = isset($info['msg']['resultMsg']) ? $info['msg']['resultMsg'] : false;
			if($resultMsg !== false && stripos($resultMsg, 'Object does not exist') === FALSE &&
				 stripos($resultMsg, 'Authorization error') === FALSE)
			{
				return true;
			}
		}
		return false;
	}

	private function deleteDomainByDomainId($domainId, $domainName)
	{
		$dnMod = new \models\manage\domain\DomainsMod();
		$eppLib = new \lib\manage\domain\DomainEppLib();
		$info = $dnMod->getRow("select * from e_domains where DomainId=?", 'i', $domainId);
		if(empty($info))
		{
			DomainLogsLib::addDomainService($domainName, 
				array('memo' => 'cron_check_cn_domain', 'c' => $domainId . '域名信息获取失败'), 27);
			return false;
		}
		if($info['RegistrarId'] != 61)
		{
			$cinfo = $eppLib->getDomainRegInfo($domainName, $info['RegistrarId']);
			$cinfo = $this->sdk->execSdkFun(5025, array('domain' => $domainName, 'registrarID' => $info['RegistrarId']));
			if(! empty($cinfo))
			{
				$deleteFlag = TRUE;
				// 中文国内域名cn和中国后缀的，简繁体为同一个。假如检测的模板id不一致则可能被审核删除后二次注册，此时5025存在，但是需要删除域名
				if($info['ClassName'] == 3 && in_array($info['DomainLtd'], array(2, 24)))
				{
					$tempInfo = $dnMod->getRow(
						"select TemplateName from e_template_zh where TemplateId=" . $info['TemplateId'], '', array());
					if(! empty($tempInfo) && $cinfo['registrant'] != $tempInfo['TemplateName'])
					{
						$deleteFlag = FALSE;
						\core\Log::write(
							$domainName . '|' . json_encode(
								array(
										'memo' => 'del_domain_template_unmatch', 
										'check' => $cinfo['registrant'] . "," . $tempInfo['TemplateName'], 
										'c' => '准备删除域名')), 'cronmanage/domain', 'check_cn_domain_reg_fail');
					}
				}
				if($deleteFlag)
				{
					DomainLogsLib::addDomainService($domainName, 
						array('memo' => 'cron_check_cn_domain', 'c' => '注册局域名存在不能删除!' . $domainName), 27);
					return false;
				}
			}
		}
		$dataExt = $dnMod->getRow("select * from e_domain_ext where DomainId=" . $domainId, '', array());
		$dataExt = $dataExt ? $dataExt : array(
				'DomainId' => $domainId, 'Dns' => '1', 'DomainFrom' => '1', 'DomainIcp' => '1', 'TemplateType' => '1', 
				'Remark' => '1', 'Tooltip' => '1', 'TooltipWay' => '1', 'LastClosePrivacy' => '0000-00-00 00:00:00', 
				'pwd' => '');
		if(isset($dataExt['EnameId']))
		{
			unset($dataExt['EnameId']);
		}
		$dnTransLib = new \lib\manage\domain\DomainTransferLib($info['EnameId']);
		$dnBakRes = $dnTransLib->deleteDomain($domainName, $info, $dataExt, 27);
		if(empty($dnBakRes))
		{
			DomainLogsLib::addDomainService($domainName, 
				array('memo' => 'cron_check_cn_domain', 'c' => $domainName . '写入备份表失败'), 27);
			return false;
		}
		$delRes = $dnMod->delDomain($domainId);
		if($delRes)
		{
			// 删除域名扩展记录
			$dnMod->delete("delete from e_domain_ext where DomainId=" . $domainId, '', array());
			return true;
		}
		else
		{
			DomainLogsLib::addDomainService($domainName, 
				array('memo' => 'cron_check_cn_domain', 'c' => $domainName . '域名删除失败'), 27);
			return false;
		}
	}

	private function treatOrder($domain, $enameId, $domainId, $regDate)
	{
		$dnMod = new ModBase('domain');
		$whereDn = $regDate >= '2012-11-08 14:30:00' ? $domainId : $domain;
		$orderInfo = $dnMod->getRow(
			"select Content from e_domain_service where Domain=" . $whereDn . " and ServiceType=33 and UserId=" .
				 $enameId, '', array());
		if(! empty($orderInfo['Content']))
		{
			return $orderInfo['Content'];
		}
		$url = 'http://www.ename.com/auctioninterface/getbookdomaintransorderid';
		$key = 'Auction@ename#$getbookdomaintransorderid';
		$time = time();
		$sid = md5($key . $time);
		$url .= '?enameid=' . $enameId . '&domain=' . $domain . '&sid=' . $sid . '&times=' . $time;
		$return = file_get_contents($url);
		\core\Log::write(
			json_encode(
				array(
						'memo' => 'query-domain', 'return' => json_decode($return, true), 'domain' => $domain, 
						'domainId' => $domainId, 'enameId' => $enameId)), 'cronmanage/domain', 'check_cn_domain_reg_fail');
		$info = json_decode($return, TRUE);
		if($info['ServiceCode'] == 1000)
		{
			return $info['Items'];
		}
		else
		{
			DomainLogsLib::addDomainService($domain, 
				array('memo' => 'query-domain', 'c' => 'CN域名,无订单号,放弃退款', 'domain' => $domainId . '-' . $domain), 27);
		}
		return false;
	}

	private function backOrder($orderId, $enameId, $domain)
	{
		try
		{
			$productOrderLib = new \lib\manage\finance\ProductOrderLib($enameId);
			$productOrderLib->cancelOrder($orderId);
			$siteMesLogic = new \logic\manage\information\SiteMessageLogic();
			$siteMesLogic->addMessage(
				array(
						'EnameId' => $enameId, 'Data' => array('enameId' => $enameId, 'domain' => $domain), 
						'TemplateId' => 'domain_register_error', 'MessageType' => 9));
			\core\Log::write(
				$domain . '|' . json_encode(array('memo' => 'back-order', 'c' => 'CN域名自动退款', 'order' => $orderId)), 
				'cronmanage/domain', 'check_cn_domain_reg_fail');
		}
		catch(Exception $e)
		{
			DomainLogsLib::addDomainService($domain, 
				array('memo' => 'back-order', 'c' => '自动退款发生错误', 'msg' => $e->getMessage()), 27);
		}
	}

	/**
	 * 定时任务--域名注册续费转入批量站内信邮件通知
	 */
	public function checkUmessageMailAction()
	{
		$domainRegLib = new \lib\manage\domain\DomainRegistLib();
		$startData = date('Y-m-d', strtotime('-1 days')) . ' 00:00:00';
		$endData = date('Y-m-d', strtotime('-1 days')) . ' 23:59:59';
		$regisid = array(1, 21, 31, 41, 51, 61, 71, 81, 82, 86);
		$regDomainData = $domainRegLib->getRegDomainData($startData, $endData, $regisid); // 注册数据
		$renewData = $this->getRenewData(date('Y-m-d', strtotime('-1 days'))); // 续费数据
		$domainTransferInLib = new lib\manage\domain\DomainTransferInLib();
		$transferData = $domainTransferInLib->getTransferDataAll($startData, $endData); // 转入数据
		$domainManageLib = new \lib\manage\domain\DomainManageLib();
		$domainManageLib->domainRegRenewDone($regDomainData, 'reg');
		$domainManageLib->domainRegRenewDone($renewData, 'renew');
		$domainManageLib->domainTransferDone($transferData);
		echo 'ok';
	}

	private function getRenewData($day)
	{
		$redis = \core\RedisLib::getInstance('manage');
		$redisKey = 'domain_renew0611_' . $day;
		$redisData = $redis->sGetMembers($redisKey);
		if(empty($redisData))
		{
			return FALSE;
		}
		$redis->del($redisKey);
		$return = array();
		foreach($redisData as $value)
		{
			$domainEnameId = explode('_', $value);
			$return[$domainEnameId[0]][] = $domainEnameId[1];
		}
		return $return;
	}

	/**
	 * 域名自动续费
	 *
	 * @throws Exception
	 */
	public function autoRenewAction()
	{
		echo "-----start-----\n";
		try
		{
			\lib\manage\domain\DomainLogsLib::addDomainService("renew.cron", "定时任务---自动续费开始", 5);
			$domainMod = new \models\manage\domain\DomainsMod();
			$runTime = time();
			$date = date("Y-m-d 23:59:59", strtotime("+30 day"));
			$where = ' AutoRenew = 1 and DomainProperty != 4 and DomainProperty != 6 and ExpDate < ?';
			$sql = 'select count(*) from e_domains where ' . $where;
			if(! $count = $domainMod->getOne($sql, 's', array($date)))
			{
				throw new Exception('没有自动续费的域名');
			}
			// 警报 发送短信提醒
			if($count > 20000)
			{
				$queueLogic = new \logic\manage\newqueue\QueueLogic();
				$sendData = array(
						'Priority' => 5, 'Function' => 'send_sms', 
						'Data' => array('title' => '自动续费数量超额', 'content' => '自动续费总数超过20000，已达到：' . $count), 
						'TemplateName' => 'manual_control_template', 'Target' => '15280250851', 'EnameId' => 561305);
			}
			// 同步数据到临时续费临时表(按enameid排序方面余额不足时跳过)
			$sql = 'insert into e_domain_renew_tmp(DomainId,EnameId,ExpDate,AddDate) (select DomainId,EnameId,UNIX_TIMESTAMP(ExpDate),' .
				 $runTime . ' from e_domains where ' . $where . ' order by EnameId ASC,Expdate ASC)';
			if(! $domainMod->add($sql, 's', array($date)))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService('renew.cron', '同步续费域名到临时表失败', 5);
			}
			// 开始自动续费---start---
			$limit = 200;
			$page = ceil($count / $limit);
			
			$orderLib = new \interfaces\manage\Finance();
			$domainInterface = new \interfaces\manage\Domains();
			$domainQueryLib = new \lib\manage\domain\DomainQueryLib();
			$topDomainLib = new \lib\manage\domain\DomainTopLib();
			$orderLogic = new \logic\manage\finance\OrderLogic();
			$dnManageLogic = new \logic\manage\domain\DomainManageLogic();
			$sitemessageLogic = new \logic\manage\information\SiteMessageLogic();
			$redis = \core\RedisLib::getInstance('manage');
			
			// 余额不足跳过的enameid
			$jumpEnameId = FALSE;
			for($i = 0; $i < $page; $i ++)
			{
				$sql = 'select * from e_domain_renew_tmp where AddDate = ? limit ?';
				if($list = $domainMod->select($sql, 'is', array($runTime, $limit * $page . ',' . $limit)))
				{
					foreach($list as $value)
					{
						echo $value['DomainId'], ',';
						if(! $info = $domainMod->getDomainInfo(array('DomainId' => $value['DomainId']), '*', TRUE))
						{
							\core\Log::write('DomainId:' . $value['DomainId'] . ',自动续费,获取域名信息失败', 'cronmanage/domain', 
								'auto_renew');
							continue;
						}
						$isRenewalApp = $redis->get($info['EnameId'].strtolower($info['DomainName']) . 'for_repeate_renewal_mark');//app续费成功记录
						$isRenewalPc = $redis->get($info['EnameId'].strtolower($info['DomainName']) . 'for_repeate_renewal_mark_pc');//pc续费成功记录
						if($isRenewalApp || $isRenewalPc)
						{
							\lib\manage\domain\DomainLogsLib::addDomainService($info['DomainName'], 
								array('memo' => 'auto_renew', 'result' => '24h内重复续费'), 5);
							continue;
						}
						// 自动续费条件判断
						if($info['AutoRenew'] == 1 && $info['ExpDate'] < $date&&
							 !in_array($info['DomainProperty'], array(4, 6)))
						{
							// 域名正在转出放弃续费
							if($info['DomainMyStatus'] == 5)
							{
								\lib\manage\domain\DomainLogsLib::addDomainService($info['DomainName'], 
									array('memo' => 'auto_renew', 'result' => '域名正在转出放弃续费'), 5);
								continue;
							}
							// 再次判断时间 过期时间比当前时间大43天的 放弃续费
							if(strtotime($info['ExpDate']) + 8 * 3600 - time() > 43 * 24 * 3600)
							{
								\lib\manage\domain\DomainLogsLib::addDomainService($info['DomainName'], 
									array('memo' => 'auto_renew', 'result' => '过期时间超过43天放弃续费'), 5);
								continue;
							}
							if($jumpEnameId && $jumpEnameId == $info['EnameId'])
							{
								echo $info['EnameId'] . ',' . $info['DomainId'] . ',' . $info['DomainName'] .
									 '用户余额不足，跳过续费。';
								$data = array(
										'EnameId' => $info['EnameId'], 'TemplateId' => 'tempAutoRenew', 
										'Data' => array(
												'domain' => $info['DomainName'], 'expDate' => $info['ExpDate'], 
												'msg' => '可用余额不足'), 'MessageType' => 11);
								$sitemessageLogic->addMessage($data);
								continue;
							}
							//旧数据处理  新数据直接判断
							$renewCheck = DomainFunLib::checkisRealDomainRenew($info['DomainName'], $info['IsRealName'], $info['RegDate']);
							if(!$renewCheck)
							{ 
								\lib\manage\domain\DomainLogsLib::addDomainService($info['DomainName'],
									array('memo' => 'auto_renew', 'result' => '新数据未实名'), 5);
								continue;
							}
							try
							{
								$result = $this->domainRenew($info, $topDomainLib, $orderLogic, $dnManageLogic, $redis);
							}
							catch(Exception $e)
							{
								if($e->getCode() == 410024)
								{
									$jumpEnameId = $info['EnameId'];
									$renewMsg = '可用余额不足';
								}
								else
								{
									$renewMsg = $e->getMessage();
								}
								$data = array(
										'EnameId' => $info['EnameId'], 'TemplateId' => 'tempAutoRenew', 
										'Data' => array(
												'domain' => $info['DomainName'], 'expDate' => $info['ExpDate'], 
												'msg' => $renewMsg), 'MessageType' => 11);
								$sitemessageLogic->addMessage($data);
							}
						}
					}
				}
			}
		}
		catch(Exception $e)
		{
			echo $e->getMessage() . "\n";
		}
		echo "-----end-----\n";
	}


	/**
	 * 域名续费
	 *
	 * @param array $domainInfo        	
	 * @return boolean
	 */
	private function domainRenew($domainInfo, $topDomainLib, $orderLogic, $dnManageLogic, $redis)
	{
		$param = new stdClass();
		$param->enameId = $domainInfo['EnameId'];
		$param->type = 3; // 域名续费
		$param->productType = $domainInfo['DomainProperty'];
		$param->domain = $domainInfo['DomainName'];
		$param->year = 1;
		$ltd = \lib\manage\common\DomainFunLib::getDomainClassAll($domainInfo['DomainName']);
		$param->productName = '.' . $ltd;
		// 判断是否珍品或者抢滩域名
		$topInfo = $topDomainLib->checkTopDomain($domainInfo['DomainName'], date('Y'));
		if(is_array($topInfo))
		{
			$param->specialPrice = TRUE;
			$param->price = $topInfo['price'];
			$param->remark = $topInfo['remark'];
		}
		// 创建产品订单
		if(! $orderId = $orderLogic->addProductOrder($param))
		{
			throw new Exception(\core\Response::getErrMsg(), \core\Response::getErrCode());
		}
		// 域名续费
		$params = array(
				'domain' => $domainInfo['DomainName'], 'year' => 1, 'expDate' => $domainInfo['ExpDate'], 
				'enameId' => $domainInfo['EnameId']);
		
		$rs = $dnManageLogic->domainrenew($params);
		$param = new stdClass();
		$param->enameId = $domainInfo['EnameId'];
		$param->orderId = $orderId;
		if($rs == TRUE)
		{
			if($orderLogic->confirmOrder($param))
			{
				$rs = $dnManageLogic->checkExpireHold(
					array(
							'domain' => $domainInfo['DomainName'], 'expDate' => $domainInfo['ExpDate'], 
							'enameId' => $domainInfo['EnameId'], 'email' => $data['email'], 
							'extData' => array(
									'DnsType' => $domainInfo['DnsType'], 'DomainId' => $domainInfo['DomainId'], 
									'RegistrarId' => $domainInfo['RegistrarId'])));
			}
			else
			{
				\core\Log::write('域名:' . $domainInfo['DomainNa'] . ',自动续费成功，订单：' . $orderId . '确认失败', 
					'cronmanage/domain', 'autorenwConfirmOrderError');
			}
			\lib\manage\domain\DomainLogsLib::addDomainService($domainInfo['DomainName'], 
				array('memo' => 'auto_renew', 'result' => '自动续费成功'), 5);
			$redis->set($domainInfo['EnameId'] . strtolower($domainInfo['DomainName']) . 'for_repeate_renewal_mark', '1', 86400); // 续费成功写redis，24小时内不让重复续费
		}
		else
		{
			if(! $orderLogic->cancelOrder($param))
			{
				\core\Log::write('域名:' . $domainInfo['DomainNa'] . ',自动续费失败，订单：' . $orderId . '取消失败', 
					'cronmanage/domain', 'autorenwCancelOrderError');
			}
			throw new Exception('接口续费失败');
		}
	}
}

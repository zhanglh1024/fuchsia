<?php
use core\ModBase;

class ProductController extends Yaf\Controller_Abstract
{
	/**
	 * 活动开始和结束的前一天通知相关人员
	 */
	public function activityTimeNoticeAction()
	{
		$proMod = new ModBase('product');
		$day = 1;//活动提前提醒的天数
		$beginTimeStr = strtotime(date('Y-m-d', strtotime('+'.$day.'days')).' 00:00:00');
		$msg = '';
		$manageConf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$dnLtdArray = $manageConf->domainLtd->toArray();
		$productConf = new \Yaf\Config\Ini(APP_PATH . '/conf/product.ini', 'product');
		$productTypeArray = $productConf->productType->toArray();
		$queueLogic = new \logic\manage\newqueue\QueueLogic();
		//即将开始的活动
		$endTimeStr = strtotime(date('Y-m-d', strtotime('+'.$day.'days')).' 23:59:59');
		$query = "select ac_type,ac_content_admin,ac_begin_time,ac_end_time,ac_dn_ltd,ac_product_type from e_products_activity where ac_status=1 and ac_begin_time>={$beginTimeStr} and ac_begin_time<={$endTimeStr}";
		$acInfo = $proMod->select($query, '', array());
		if(empty($acInfo))
		{
			echo "无开始活动提醒\r\n";
		}
		else 
		{
			foreach ($acInfo as $k => $v)
			{
				$msg .= '即将开始的活动：';
				$msg .= $v['ac_type'] == 1 ? '[普通活动]' : '[长期活动]';
				$msg .= '['.$v['ac_content_admin'].']';
				$msg .= ',活动时间：'.date('Y-m-d H:i:s', $v['ac_begin_time']).'到'.date('Y-m-d H:i:s', $v['ac_end_time']).'，';
				$msg .= '后缀类型：'.(empty($dnLtdArray[$v['ac_dn_ltd']]) ? $v['ac_dn_ltd'] : $dnLtdArray[$v['ac_dn_ltd']]).'，';
				$msg .= '产品类型：'.(empty($productTypeArray[$v['ac_product_type']]) ? $v['ac_product_type'] : $productTypeArray[$v['ac_product_type']]).'。';
			}
		}
		//即将结束的活动
		$query = "select ac_type,ac_content_admin,ac_begin_time,ac_end_time,ac_dn_ltd,ac_product_type from e_products_activity where ac_status=1 and ac_end_time>={$beginTimeStr} and ac_end_time<={$endTimeStr}";
		$acInfo = $proMod->select($query, '', array());
		if(empty($acInfo))
		{
			echo "无结束活动提醒\r\n";
		}
		else
		{
			foreach ($acInfo as $k => $v)
			{
				$msg .= '即将结束的活动：';
				$msg .= $v['ac_type'] == 1 ? '[普通活动]' : '[长期活动]';
				$msg .= '['.$v['ac_content_admin'].']';
				$msg .= ',活动时间：'.date('Y-m-d H:i:s', $v['ac_begin_time']).'到'.date('Y-m-d H:i:s', $v['ac_end_time']).'，';
				$msg .= '后缀类型：'.(empty($dnLtdArray[$v['ac_dn_ltd']]) ? $v['ac_dn_ltd'] : $dnLtdArray[$v['ac_dn_ltd']]).'，';
				$msg .= '产品类型：'.(empty($productTypeArray[$v['ac_product_type']]) ? $v['ac_product_type'] : $productTypeArray[$v['ac_product_type']]).'。';
			}
		}
		//发送提醒
		if($msg)
		{
			self::sendNotice($title, '活动预告和提醒');
		}
		echo "--end--\r\n";
	}
	
	/**
	 * net注册活动限量7w定时检测提醒
	 */
	public function netRegLimitNoticeAction()
	{
		$finMod = new ModBase('finance');
		$query = "select count(*) from e_finance_out2016 where OutType=1 and CreateDate>='2016-10-11 12:00:00' and CreateDate<='2016-10-14 11:59:59' and SUBSTR(LinkDomain,-3)='net'";
		$dnCount = $finMod->getOne($query, '', array());
		if($dnCount && $dnCount >= 65000)
		{
			$title = '活动注册量警报';
			$msg = "2016年10月份net17元注册活动注册量已达【{$dnCount}】,请注意及时调整注册价格。";
			self::sendNotice($title, $msg);
		}
	}
	
	private function sendNotice($title, $msg)
	{
		$queueLogic = new \logic\manage\newqueue\QueueLogic();
		$config = array(561305 => array('15280250851', 'yangyf@ename.com'), 612463 => array('18559222663', 'wangyt@ename.com'), 914252 => array('18631085867', 'chenyw@ename.com'));
		foreach($config as $k => $v)
		{
			try 
			{
				$queueLogic->addQueueNormal(
					array('Function' => 'send_sms', 'TemplateName' => 'any_template_info', 'EnameId' => $k,
							'Priority' => 5, 'Target' => $v[0], 'Data' => array('content' => $msg, 'title' => $title)));
				$queueLogic->addQueueNormal(
					array('Function' => 'sendmail', 'TemplateName' => 'any_template_info', 'EnameId' => $k,
							'Priority' => 5, 'Target' => $v[1], 'Data' => array('content' => $msg, 'title' => $title)));
			}
			catch (\Exception $e)
			{
				echo $k."提醒发送失败".$e->getMessage()."\r\n";
			}
		}
	}
	
	public function productCostCheckAction()
	{
		$checkCost = 3;//成本 + n >= 我们的价格 产生警报
		$proMod = new ModBase('product');
		$query = "select * from e_products where ProductStatus=1 and ProductCurrency=2";
		$proList = $proMod->select($query, '', array());
		if(empty($proList))
		{
			exit('no data');
		}
		$msg = '';
		try
		{
			$acLogic = new \logic\manage\product\ActivityLogic();
			$proRate = $acLogic->getProductRate();
		}
		catch(\Exception $e)
		{
			echo "go汇率获取失败，改用文件缓存获取".$e->getMessage()."\r\n";
			$proRate = $acLogic->getProductRate(false);
		}
		if(empty($proRate))
		{
			exit("汇率有误");
		}
		$tempConfig = array(1 => '注册', 2 => '转入', 3 => '续费', 4 => '赎回');
		foreach($proList as $v)
		{
			$query = "select Price from e_products_price where GroupId=2 and ProductId={$v['ProductId']}";
			$proPrice = $proMod->getRow($query, '', array());
			if(empty($proPrice['Price']))
			{
				echo "ProductId:".$v['ProductId'].",产品价格获取失败\r\n";
				continue;
			}
			$cost = json_decode($v['ProductCost'], true);
			$dollarCost = json_decode($v['DollarCost'], true);
			$price = json_decode($proPrice['Price'], true);
			if($v['IsDomain'])
			{
				for($i=1; $i<=4; $i++)
				{
					$costPrice = $proRate*$dollarCost[$i];
					if(!empty($dollarCost[$i]) && $costPrice >= $price[$i] - $checkCost)
					{
						echo $v['ProductDesc'].",类型:{$tempConfig[$i]},成本价:{$costPrice},产品价:{$price[$i]}\r\n";
						$msg .= "【".$v['ProductDesc'].",类型:{$tempConfig[$i]},成本价:{$costPrice},产品价:{$price[$i]}】";
					}
				}
			}
			else 
			{
				if(!empty($dollarCost[0]) && $proRate*$dollarCost[0] >= $price[0] - $checkCost)
				{
					$costPrice = $proRate*$dollarCost[0];
					echo $v['ProductDesc'].",成本价:{$costPrice},产品价:{$price[0]}\r\n";
					$msg .= "【".$v['ProductDesc'].",成本价:{$costPrice},产品价:{$price[0]}】";
				}
			}
		}
		if($msg)
		{
			$msg = "价格警报|当前汇率：{$proRate}。".$msg;
			//echo $msg;
			self::sendNotice('产品价格警报', $msg);
		}
	}
	
	/**
	 * 2017 年1月1日00:00:00-12月31日23:59:59期间，同一ID用户当日续费量（不含转移续费）超过 500 个（含）时，续费价：29元/个/年。－－－－－－这个可以做一个机智，通知我们用户id，以及个数，超过500个的才提醒，人工返款
	 */
	public function wangRenewBackMoneyNoticeAction()
	{
		$yesterday = date('Y-m-d', strtotime('-1day'));
		$yesterdayUnixBegin = strtotime($yesterday);
		$yesterdayUnixEnd = strtotime($yesterday.'23:59:59');
		if($yesterdayUnixBegin < strtotime('2017-01-01') || $yesterdayUnixBegin >= strtotime('2018-01-01'))
		{
			exit("提醒时间异常");
		}
		$finMod = new ModBase('finance');
		$query = "select sum(DomainYear) as total,EnameId from e_finance_general2017 where Type=1 and InOutType=3 and IsCancelOrder=0 and DomainLtd=29 and UpdateTime>={$yesterdayUnixBegin} and UpdateTime<={$yesterdayUnixEnd} group by EnameId having total>=500";
		$list = $finMod->select($query, '', array());
		//$list = array(array('EnameId' => 652909, 'total' => 50));
		if(empty($list))
		{
			exit("当日[{$yesterday}]无wang续费达标提醒");
		}
		$msg = '';
		foreach($list as $v)
		{
			$msg .= "用户【{$v['EnameId']}】续费量【{$v['total']}】年<br>";
		}
		if($msg)
		{
			$msg = "[{$yesterday}]wang续费达标提醒:<br>".$msg;
			echo $msg."\r\n";
			self::sendNotice("[{$yesterday}]wang续费达标提醒", $msg);
		}
	}
	
	/**
	 * club注册量满46000时提醒
	 */
	public function clubRegisterNoticeAction()
	{
		$finMod = new ModBase('finance');
		$query = "select count(*) from e_finance_out2017 where OutType=1 and substr(linkdomain,-4)='club'";
		$count = $finMod->getOne($query, '', array());
		if(empty($count) || $count<46000)
		{
			exit();
		}
		$msg = "club注册量已达{$count}个";
		echo $msg."\r\n";
		self::sendNotice("club注册量提醒", $msg);
	}
	
}
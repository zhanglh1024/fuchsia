<?php
use core\ModBase;
use lib\manage\common\DomainFunLib;
use core\Log;

class FinanceController extends Yaf\Controller_Abstract
{
	
	public function reparefszaction()
	{
		$financeMod = new \core\ModBase('finance');
		$num = 0;
		$size = 5000;
		$start = date('Y-m-d', strtotime('-7 days')) .' 00:00:00';
		$end = date('Y-m-d', strtotime('-7 days')) .' 23:59:59';
		$logic = new \logic\manage\finance\InvoiceLogic();
		$tableName = 'e_finance_out' . date('Y');
		while(true)//跑出款表
		{
			$limit = $num * $size . ',' . $size;
			$sql = "select sum(OutMoney) as total,EnameId,year(CreateDate) as yyear from $tableName where CreateDate>='2016-01-01 00:00:00' and CreateDate<='2016-10-30 23:59:59' and OutType=5 group by EnameId,year(CreateDate)";
			$sql .= " limit " . $limit;
			$resultOut = $financeMod->select($sql, '', array());
			if(empty($resultOut))
			{
				echo "handle e_finance_out over\r\n";
				break;
			}
			foreach($resultOut as $info)
			{
				if($info['yyear'] != date('Y') && $info['yyear'] != date('Y') - 1)
				{
					continue;
				}
				if($info['total'] <= 0.0000)
				{
					continue;
				}
				$data = array('enameId' => $info['EnameId'], 'invoiceFare' => sprintf("%.4f", $info['total']),
						'year' => $info['yyear']);
				if(!$logic->addInvoiceFare($data))
				{
					echo "add user fare failed\r\n";
					\core\Log::write("failed," . implode(",", $data), 'finance', 'invoicefare');
				}
			}
			$num++;
		}
	}

	/**
	 * 2016年给用户返款的发票额度扣除
	 */
	public function repareReturnMoneyAction()
	{
		$financeMod = new \core\ModBase('finance');
		$logic = new \logic\manage\finance\InvoiceLogic();
		$year=2016;
		$resultIn = $financeMod->select(
			'SELECT EnameId,InMoney,InRemark,InRemarkHide,InTypeSon,LinkDomain from e_finance_in'.$year.' WHERE InType=206 and InTypeSon in(0,42,43,64)', 
			'', array());//InTypeSon 42  有条记录 362258 3数字wang买一送一返款 记录成了InTypeSon 42  应该不扣
		if(empty($resultIn))
		{
			echo "handler e_finance_in over\r\n";
			break;
		}
		foreach($resultIn as $info)
		{
			if($info['InMoney'] <= 0.0000 || ($info['InTypeSon']==42 && $info['EnameId']==362258) )
			{
				continue;
			}
			$data = array('enameId' => $info['EnameId'], 'invoiceFare' => sprintf("%.4f", -$info['InMoney']), 
				'year' => $year);
			if(!$logic->addInvoiceFare($data))
			{
				echo "add user fare failed\r\n";
				\core\Log::write("failed," . implode(",", $data), 'finance', 'invoicefare');
			}
			echo $info['EnameId'].'额度'.$info['InMoney']."\r\n";
		}
		echo "ok\r\n";
	}
	
	/**
	 * 从2014-01-01开始，用户在易名的消费，包括注册、续费、转入、保证金、违约金、手续费等，按年统计。（额度只包括今年和去年的，跨年时前年的额度要扣掉）
	 * 100以下扣款  100-200 都有  200以上入款
	 */
	public function getUserInvoiceFareAction()
	{ 
		$financeMod = new \core\ModBase('finance');
		$num = 0;
		$size = 5000;
		$start = date('Y-m-d', strtotime('-7 days')) .' 00:00:00';
		$end = date('Y-m-d', strtotime('-7 days')) .' 23:59:59';
		$logic = new \logic\manage\finance\InvoiceLogic();
		$year = date('Y', strtotime('-7 days'));
		$tableName = 'e_finance_out' . $year ;
		while(true)//跑出款表
		{
			$limit = $num * $size . ',' . $size;
			$sql = "select sum(OutMoney) as total,EnameId,year(CreateDate) as yyear from $tableName where CreateDate>='{$start}' and CreateDate<='{$end}' and (OutType in(1,2,3,4,5,9,24,25,26,13,14,15,19) or (OutType=112 and OutTypeSon=3) or (OutType=111 and OutTypeSon=3) or (OutType=34 and OutTypeSon=36)) group by EnameId,year(CreateDate)";
			$sql .= " limit " . $limit;
			$resultOut = $financeMod->select($sql, '', array());
			if(empty($resultOut))
			{
				echo "handle e_finance_out over\r\n";
				break;
			}
			foreach($resultOut as $info)
			{
				if($info['yyear'] != date('Y') && $info['yyear'] != date('Y') - 1)
				{
					continue;
				}
				if($info['total'] <= 0.0000)
				{
					continue;
				}
				$data = array('enameId' => $info['EnameId'], 'invoiceFare' => sprintf("%.4f", $info['total']),
						'year' => $info['yyear']);
				if(!$logic->addInvoiceFare($data))
				{
					echo "add user fare failed\r\n";
					\core\Log::write("failed," . implode(",", $data), 'finance', 'invoicefare');
				}
			}
			$num++;
		}
		$outNUm = 0;
		$tableName = 'e_finance_in'.$year;
		while(true)//跑入款表 手续费
		{
			$limit = $outNUm * $size . ',' . $size;
			$inSql = "select sum(FeeMoney) as total,EnameId,year(CreateDate) as yyear from $tableName ";
			$inSql .= " where CreateDate>='{$start}' and CreateDate<='{$end}' and InType in(8,10,101,102,103,104,105,106,107,108,109,110,113,114,115,116,117,118,119,121,122,123,124,125,126,127,128,129,130,131,132,135)";
			$inSql .= " and LinkEnameId!=''";
			$inSql .= " group by EnameId,year(CreateDate) limit $limit";
			$resultIn = $financeMod->select($inSql, '', array());
			if(empty($resultIn))
			{
				echo "handler e_finance_in over\r\n";
				break;
			}
			foreach($resultIn as $info)
			{
				if($info['yyear'] != date('Y') && $info['yyear'] != date('Y') - 1)
				{
					continue;
				}
				if($info['total'] <= 0.0000)
				{
					continue;
				}
				$data = array('enameId' => $info['EnameId'], 'invoiceFare' => sprintf("%.4f", $info['total']),
						'year' => $info['yyear']);
				if(!$logic->addInvoiceFare($data))
				{
					echo "add user fare failed\r\n";
					\core\Log::write("failed," . implode(",", $data), 'finance', 'invoicefare');
				}
			}
			$outNUm++;
		}
	}

	/**
	 * 1.无脑跑财务出款表入款表
	 * 2.数据信息最完整
	 * 3.如果是人工退款，人工扣款等，这种以前财务类型固定是人工的，要能根据备注匹配出来，把他改为具体的比如域名注册财务类型
	 */
	public function financeRecordOutAction()
	{
		ini_set('memory_limit', '256M');
		$outMod = new \models\manage\finance\FinOutMod();
		$genelMod = new \models\manage\finance\FinGeneralMod();
		$payMod = new \models\manage\finance\FinPayMod();
		$pageNum = 200;
		$type = 1;
		$beginTime = date('Y-m-d', strtotime('-1day')) . ' 00:00:00';
		$endTime = date('Y-m-d', strtotime('-1day')) . ' 23:59:59';
		//$beginTime = "2016-10-26 00:00:00";
		//$endTime = "2016-10-26 23:59:59";
		$year = substr($beginTime, 0, 4);
		$year = intval($year);
		//判断当天记录是否已跑过
		$genelCount = $genelMod->getFinGeneralCount(array('Type' => $type, 'byYear' => $year, 'startDate' => strtotime($beginTime), 'endDate' => strtotime($endTime)));
		if(!empty($genelCount))
		{
			\core\Log::write($beginTime."-".$endTime."|流水已同步过", 'finance', 'financeRecordOut');
			exit($beginTime."-".$endTime."|流水已同步过");
		}
		//查找minid
		$query = "select OutId from e_finance_out{$year} where CreateDate>='{$beginTime}' and CreateDate<='{$endTime}' order by OutId asc";
		$minInfo = $outMod->getRow($query, '', array());
		if(empty($minInfo))
		{
			\core\Log::write($beginTime."-".$endTime."|minId获取失败", 'finance', 'financeRecordOut');
			exit($beginTime."-".$endTime."|minId获取失败");
		}
		//查找maxid
		$query = "select OutId from e_finance_out{$year} where CreateDate>='{$beginTime}' and CreateDate<='{$endTime}' order by OutId desc";
		$maxInfo = $outMod->getRow($query, '', array());
		if(empty($maxInfo))
		{
			\core\Log::write($beginTime."-".$endTime."|maxId获取失败", 'finance', 'financeRecordOut');
			exit($beginTime."-".$endTime."|maxId获取失败");
		}
		$minId = $minInfo['OutId'];
		$maxId = $maxInfo['OutId'];
		//获取需要特殊跳过的记录ID，记录ID在范围内，但是时间不在范围内的记录
		$jumpId = array();
		$query = "select OutId from e_finance_out{$year} where OutId>={$minId} and OutId<={$maxId} and (CreateDate<'{$beginTime}' or CreateDate>'{$endTime}')";
		$jumpInfo = $outMod->select($query, '', array());
		if(!empty($jumpInfo))
		{
			foreach($jumpInfo as $v)
			{
				$jumpId[] = $v['OutId'];
			}
		}
		echo "minId:{$minId},maxId:{$maxId}".(empty($jumpId) ? '' : ',jumpId:'.implode(',', $jumpId))."\r\n";
		\core\Log::write($beginTime."-".$endTime."|minId:{$minId},maxId:{$maxId}".(empty($jumpId) ? '' : 'jumpId:'.implode(',', $jumpId)), 'finance', 'financeRecordOut');
		
		$startId = $minId;
		while($startId <= $maxId)
		{ 
			$endId = $pageNum + $startId;
			$endId = $endId > $maxId ? $maxId : $endId;
			if($startId == $minId)
			{
				$outWhere = array('OutId>' => $startId, "OutId<" => $endId);
			}
			else
			{
				$outWhere = array('OutId>' => $startId + 1, "OutId<" => $endId);
			}
			$outWhere['byYear'] = $year;
			$outResult = $outMod->getFinanceOut2($outWhere);
			if(empty($outResult))
			{
				if($endId == $maxId)
				{
					break;
				}
				$startId = $endId;
				continue;
			}
			foreach($outResult as $outInfo)
			{
				//特殊记录ID跳过
				if(in_array($outInfo['OutId'], $jumpId))
				{
					continue;
				}
				echo $outInfo['OutId'] . ",";
				$data = array('EnameId' => $outInfo['EnameId'], 'RegistrarId' => $outInfo['RegistarId'],
						'DomainLtd' => $this->getDomainLtd($outInfo['LinkDomain']), 'Type' => $type,
						'InOutType' => $outInfo['OutType'], 'PayId' => '', 'InOutStatus' => $outInfo['OutStatus'],
						'MoneyType' => '', 'ProductName' => '', 'FreezeMoneySort' => '',
						'LinkEnameId' => $outInfo['LinkEnameId'], 'OrderId' => $outInfo['OrderId'],
						'OrderType' => $outInfo['OutType'], 'ProductId' => '', 'BankName' => '', 'AdminId' => '',
						'FeeMoney' => isset($outInfo['FeeMoney']) ? $outInfo['FeeMoney'] : '',
						'PromoId' => $outInfo['PromoId'], 'PromoMoney' => $outInfo['PromoMoney'],
						'TypeSon' => $outInfo['OutTypeSon'], 'UniqueId' => $outInfo['UniqueId'],
						'InOutMoney' => $outInfo['OutMoney'], 'CurrentMoney' => $outInfo['CurrentMoney'],
						'UpdateTime' => $outInfo['CreateDate'], 'LinkDomain' => $outInfo['LinkDomain'],
						'ProductOptions' => $outInfo['ProductOptions'], 'Remark' => $outInfo['OutRemark'],
						'RemarkHide' => $outInfo['OutRemarkHide'], 'ProductPrice' => 0);
				$cancelRemark = $outInfo['OutRemark'] . $outInfo['OutRemarkHide'];
				$data['IsCancelOrder'] = 0;
				if(stripos($cancelRemark, '取消订单') !== FALSE || stripos($cancelRemark, '经纪交易失败') !== FALSE)
				{
					$data['IsCancelOrder'] = 1;
				}
				$data['InOutType'] = $data['InOutType'] == 13 ? 3 : $data['InOutType'];
				$data['Type'] = $outInfo['OutType'] == 6 ? 4 : $type;
				//订单信息
				if($outInfo['OrderId'])
				{
					$orderInfo = $this->getOrderInfo($outInfo['OrderId']);
					if(!$orderInfo)
					{
						\core\Log::write("not found order info," . $outInfo['OutId'], 'finance', 'financeRecordOut');
						continue;
					}
					$data['FreezeMoneySort'] = $orderInfo['FreezeMoneySort'];
					$data['ProductName'] = $orderInfo['ProductName'];
					$data['ProductId'] = $orderInfo['ProductId'];
					$data['AdminId'] = $orderInfo['AdminId'];
					$data['RegistrarId'] = $orderInfo['RegistarId'];
					$data['ProductCost'] = $orderInfo['ProductCost'];
					if(!empty($orderInfo['ProductOptions']))
					{
						$jsonInfo = json_decode($orderInfo['ProductOptions'], true);
						$data['ProductPrice'] = !empty($jsonInfo['productPrice']) ? $jsonInfo['productPrice'] : 0;
					}
				}
				$data['byYear'] = $year;
				$data = $this->getDomainYear($data);
				$data['UpdateTime'] = is_numeric($data['UpdateTime']) ? $data['UpdateTime'] : strtotime($data['UpdateTime']);
				$data['RegistrarId'] = $this->getDomainRegid($data, $data['UpdateTime']);
				//充值银行特殊处理
				if(!empty($data['PayId']) && empty($data['BankName']))
				{
					$data['BankName'] = $this->getPayBankName($data['PayId'], $payMod);
				}
				//提现银行特殊处理
				if(!empty($data['OrderId']) && $outInfo['OutType'] == 6 && !empty($outInfo['OutBankName']))
				{
					$data['BankName'] = $outInfo['OutBankName'];
				}
				$data = $this->checkReFundIn($data);
				$findData = array('EnameId' => $data['EnameId'], 'InOutType' => $data['InOutType'],
						'LinkDomain' => $data['LinkDomain'], 'OrderId' => $data['OrderId'],
						'UpdateTime' => $data['UpdateTime'], 'Remark' => $outInfo['OutRemark'],
						'InOutMoney' => $outInfo['OutMoney'], 'CurrentMoney' => $outInfo['CurrentMoney']);
				if(!empty($data['byYear']))
				{
					$findData['byYear'] = $data['byYear'];
				}
				// 				if(!$genelMod->getFinGeneralCount($findData))
				// 				{
				if(!$genelMod->addFinGeneral($data))
				{
					\core\Log::write("add general fail," . $outInfo['OutId'], 'finance', 'financeRecordOut');
				}
				// 				}
			}
			$startId = $endId;
			if($startId >= $maxId)
			{
				if(!$this->setRedisMid('setm', 'outaction', 'min', $maxId))
				{
					\core\Log::write("set mid fail," . $maxId, 'finance', 'financeRecordOut');
				}
				break;
			}
		}
	}

	/**
	 * 重复入款
	 * 在线充值: 其他备注：重复入款(支付宝|20151214000726522201763777|1763777|OA521792015充值重复入款记录[经手人:杨亚凤]);
	 */
	public function checkReFundIn($record)
	{
		if($record['InOutType'] == 200 && (stripos($record['RemarkHide'], '充值重复入款记录') !== FALSE) || stripos($record['Remark'], '重复入款') !== FALSE)
		{
			$infoArr = explode("|", $record['RemarkHide']);
			if(stripos($infoArr[0], '支付宝') !== FALSE)
			{
				$bankName = 9;
			}
			elseif(stripos($infoArr[0], '银联') !== FALSE)
			{
				$bankName = 11;
			}
			elseif(stripos($infoArr[0], '盛付通') !== FALSE)
			{
				$bankName = 10;
			}
			else
			{
				$bankName = 0;
			}
			$record['PayId'] = $infoArr[2];
			$record['BankName'] = $bankName;
		}
		return $record;
	}

	/**
	 * 15年 成本为空的填充订单的成本，没有则填充当前的成本
	 * 修复区间 4473689-4631685
	 */
	public function financeRecordOutFixAction()
	{
		ini_set('memory_limit', '256M');
		$outMod = new \models\manage\finance\FinOutMod();
		$genelMod = new \models\manage\finance\FinGeneralMod();
		$pageNum = 200;
		$type = 1;
		$year = 2015;
		$maxId = 4631685;
		$startId = $minId = 4473689;
		while($startId <= $maxId)
		{
			$endId = $pageNum + $startId;
			if($endId > $maxId)
			{
				$endId = $maxId;
			}
			$outWhere = array('OutId>' => $startId, "OutId<" => $endId, 'orderId>' => 0);
			$outResult = $outMod->getFinanceOut2($outWhere);
			if(empty($outResult))
			{
				echo "no result...";
				$startId = $endId;
				continue;
			}
			foreach($outResult as $outInfo)
			{
				if(!$outInfo['ProductOptions'] && !in_array($outInfo['OutType'], array(1, 2, 3, 4, 13, 14)))
				{
					\core\Log::write($outInfo['OutId'], 'finance', 'financeRecordOutFixno');
					continue;
				}
				$data = array('EnameId' => $outInfo['EnameId'], 'RegistrarId' => $outInfo['RegistarId'],
						'DomainLtd' => $this->getDomainLtd($outInfo['LinkDomain']), 'Type' => $type,
						'InOutType' => $outInfo['OutType'], 'PayId' => '', 'InOutStatus' => $outInfo['OutStatus'],
						'MoneyType' => '', 'ProductName' => '', 'FreezeMoneySort' => '',
						'LinkEnameId' => $outInfo['LinkEnameId'], 'OrderId' => $outInfo['OrderId'],
						'OrderType' => $outInfo['OutType'], 'ProductId' => '', 'BankName' => '', 'AdminId' => '',
						'FeeMoney' => isset($outInfo['FeeMoney']) ? $outInfo['FeeMoney'] : '',
						'PromoId' => $outInfo['PromoId'], 'PromoMoney' => $outInfo['PromoMoney'],
						'TypeSon' => $outInfo['OutTypeSon'], 'UniqueId' => $outInfo['UniqueId'],
						'InOutMoney' => $outInfo['OutMoney'], 'CurrentMoney' => $outInfo['CurrentMoney'],
						'UpdateTime' => $outInfo['CreateDate'], 'LinkDomain' => $outInfo['LinkDomain'],
						'ProductOptions' => $outInfo['ProductOptions'], 'Remark' => $outInfo['OutRemark'],
						'RemarkHide' => $outInfo['OutRemarkHide'], 'ProductPrice' => 0);
				$data['isCancelOrder'] = stripos($outInfo['OutRemark'], '取消订单') !== FALSE ? 1 : 0;//是否是取消生成的记录
				$data['Type'] = $outInfo['OutType'] == 6 ? 4 : $type;
				//订单信息
				if($outInfo['OrderId'])
				{
					$orderInfo = $this->getOrderInfo($outInfo['OrderId']);
					if(!$orderInfo)
					{
						\core\Log::write($outInfo['OutId'], 'finance', 'financeRecordOutFix2');
						continue;
					}
					$data['FreezeMoneySort'] = $orderInfo['FreezeMoneySort'];
					$data['ProductName'] = $orderInfo['ProductName'];
					$data['ProductId'] = $orderInfo['ProductId'];
					$data['AdminId'] = $orderInfo['AdminId'];
					$data['RegistrarId'] = $orderInfo['RegistarId'];
					$data['ProductCost'] = $orderInfo['ProductCost'];
					if(!empty($orderInfo['ProductOptions']))
					{
						$jsonInfo = json_decode($orderInfo['ProductOptions'], true);
						$data['ProductPrice'] = !empty($jsonInfo['productPrice']) ? $jsonInfo['productPrice'] : 0;
					}
				}
				$data = $this->getDomainYear($data);
				$data['UpdateTime'] = is_numeric($data['UpdateTime']) ? $data['UpdateTime'] : strtotime($data['UpdateTime']);
				$data['RegistrarId'] = $this->getDomainRegid($data, $data['UpdateTime']);
				$findData = array('EnameId' => $data['EnameId'], 'InOutType' => $data['InOutType'], 'Type' => 1,
						'LinkDomain' => $data['LinkDomain'], 'OrderId' => $data['OrderId'],
						'UpdateTime' => $data['UpdateTime'], 'Remark' => $outInfo['OutRemark'],
						'InOutMoney' => $outInfo['OutMoney'], 'CurrentMoney' => $outInfo['CurrentMoney']);
				$cnnt = $genelMod->getFinGeneralCount($findData);
				if(!$cnnt)
				{
					\core\Log::write($outInfo['OutId'], 'finance', 'financeRecordOutFix1');
				}
				elseif($cnnt > 1)
				{
					\core\Log::write($outInfo['OutId'] . "," . $cnnt, 'finance', 'financeRecordOutFix3');
				}
				else
				{
					if(!$genelMod->updateGeneral($findData, $data))
					{
						\core\Log::write($outInfo['OutId'], 'finance', 'financeRecordOutFix4');
					}
				}
			}
			$startId = $endId;
			if($startId > $maxId)
			{
				if(!$this->setRedisMid('setm', 'outaction', 'min', $maxId))
				{
					\core\Log::write("set mid fail," . $maxId, 'finance', 'financeRecordOut');
				}
				break;
			}
		}
	}

	/**
	 * 1.无脑跑财务出款表入款表
	 * 2.数据信息最完整
	 * 3.如果是人工退款，人工扣款等，这种以前财务类型固定是人工的，要能根据备注匹配出来，把他改为具体的比如域名注册财务类型===
	 */
	public function financeRecordInAction()
	{
		ini_set('memory_limit', '256M');
		$inMod = new \models\manage\finance\FinInMod();
		$genelMod = new \models\manage\finance\FinGeneralMod();
		$payMod = new \models\manage\finance\FinPayMod();
		$pageNum = 200;
		$type = 2;
		$beginTime = date('Y-m-d', strtotime('-1day')) . ' 00:00:00';
		$endTime = date('Y-m-d', strtotime('-1day')) . ' 23:59:59';
		//$beginTime = "2016-10-26 00:00:00";
		//$endTime = "2016-10-26 23:59:59";
		$year = substr($beginTime, 0, 4);
		$year = intval($year);
		//判断当天记录是否已跑过
		$genelCount = $genelMod->getFinGeneralCount(array('Type' => $type, 'byYear' => $year, 'startDate' => strtotime($beginTime), 'endDate' => strtotime($endTime)));
		if(!empty($genelCount))
		{
			\core\Log::write($beginTime."-".$endTime."|流水已同步过", 'finance', 'financeRecordIn');
			exit($beginTime."-".$endTime."|流水已同步过");
		}
		//查找minid
		$query = "select InId from e_finance_in{$year} where CreateDate>='{$beginTime}' and CreateDate<='{$endTime}' order by InId asc";
		$minInfo = $inMod->getRow($query, '', array());
		if(empty($minInfo))
		{
			\core\Log::write($beginTime."-".$endTime."|minId获取失败", 'finance', 'financeRecordIn');
			exit($beginTime."-".$endTime."|minId获取失败");
		}
		//查找maxid
		$query = "select InId from e_finance_in{$year} where CreateDate>='{$beginTime}' and CreateDate<='{$endTime}' order by InId desc";
		$maxInfo = $inMod->getRow($query, '', array());
		if(empty($maxInfo))
		{
			\core\Log::write($beginTime."-".$endTime."|maxId获取失败", 'finance', 'financeRecordIn');
			exit($beginTime."-".$endTime."|maxId获取失败");
		}
		$minId = $minInfo['InId'];
		$maxId = $maxInfo['InId'];
		//获取需要特殊跳过的记录ID，记录ID在范围内，但是时间不在范围内的记录
		$jumpId = array();
		$query = "select InId from e_finance_in{$year} where InId>={$minId} and InId<={$maxId} and (CreateDate<'{$beginTime}' or CreateDate>'{$endTime}')";
		$jumpInfo = $inMod->select($query, '', array());
		if(!empty($jumpInfo))
		{
			foreach($jumpInfo as $v)
			{
				$jumpId[] = $v['InId'];
			}
		}
		echo "minId:{$minId},maxId:{$maxId}".(empty($jumpId) ? '' : ',jumpId:'.implode(',', $jumpId))."\r\n";
		\core\Log::write($beginTime."-".$endTime."|minId:{$minId},maxId:{$maxId}".(empty($jumpId) ? '' : 'jumpId:'.implode(',', $jumpId)), 'finance', 'financeRecordIn');

		$startId = $minId;
		while($startId <= $maxId)
		{
			$endId = $pageNum + $startId;
			$endId = $endId > $maxId ? $maxId : $endId;
			if($startId == $minId)
			{
				$inWhere = array('InId>' => $startId, 'InId<' => $endId);
			}
			else
			{
				$inWhere = array('InId>' => $startId + 1, 'InId<' => $endId);
			}
			$inWhere['byYear'] = $year;
			$inList = $inMod->getFinanceIn2($inWhere);
			if(empty($inList))
			{
				if($endId == $maxId)
				{
					break;
				}
				$startId = $endId;
				continue;
			}
			foreach($inList as $info)
			{
				//特殊ID记录跳过
				if(in_array($info['InId'], $jumpId))
				{
					continue;
				}
				echo $info['InId'] . ",";
				$data = array('EnameId' => $info['EnameId'], 'RegistrarId' => '',
						'DomainLtd' => $this->getDomainLtd($info['LinkDomain']), 'Type' => $type,
						'InOutType' => $info['InType'], 'PayId' => $info['PayId'], 'InOutStatus' => $info['InStatus'],
						'MoneyType' => $info['MoneyType'], 'ProductName' => '', 'FreezeMoneySort' => '',
						'LinkEnameId' => $info['LinkEnameId'], 'OrderId' => $info['OrderId'],
						'OrderType' => $info['InType'], 'ProductId' => '', 'BankName' => $info['BankName'],
						'AdminId' => $info['Operator'],
						'FeeMoney' => isset($info['FeeMoney']) ? $info['FeeMoney'] : '', 'PromoId' => '',
						'PromoMoney' => '', 'TypeSon' => $info['InTypeSon'], 'UniqueId' => $info['UniqueId'],
						'InOutMoney' => $info['InMoney'], 'CurrentMoney' => $info['CurrentMoney'],
						'UpdateTime' => strtotime($info['CreateDate']), 'LinkDomain' => $info['LinkDomain'],
						'Remark' => $info['InRemark'], 'RemarkHide' => $info['InRemarkHide'], 'ProductPrice' => 0);
				$cancelRemark = $info['InRemark'] . $info['InRemarkHide'];
				$data['IsCancelOrder'] = 0;
				if(stripos($cancelRemark, '取消订单') !== FALSE || stripos($cancelRemark, '经纪交易失败') !== FALSE)
				{
					$data['IsCancelOrder'] = 1;
				}
				$data['InOutType'] = $data['InOutType'] == 13 ? 3 : $data['InOutType'];
				$data['Type'] = $info['InType'] == 200 ? 3 : $type;
				if($info['OrderId'])
				{
					$orderInfo = $this->getOrderInfo($info['OrderId']);
					if(!$orderInfo)
					{
						\core\Log::write("not found order info," . $info['InId'], 'finance', 'financeRecordIn');
						continue;
					}
					$data['FreezeMoneySort'] = $orderInfo['FreezeMoneySort'];
					$data['ProductName'] = $orderInfo['ProductName'];
					$data['ProductId'] = $orderInfo['ProductId'];
					$data['AdminId'] = $orderInfo['AdminId'];
					$data['RegistrarId'] = $orderInfo['RegistarId'];
					$data['ProductCost'] = $orderInfo['ProductCost'];
					$data['ProductOptions'] = $orderInfo['ProductOptions'];
					if(!empty($orderInfo['ProductOptions']))
					{
						$jsonInfo = json_decode($orderInfo['ProductOptions'], true);
						$data['ProductPrice'] = !empty($jsonInfo['productPrice']) ? $jsonInfo['productPrice'] : 0;
					}
				}
				$data = $this->getDomainYear($data);
				$data['byYear'] = $year;
				$data['UpdateTime'] = is_numeric($data['UpdateTime']) ? $data['UpdateTime'] : strtotime($data['UpdateTime']);
				$data['RegistrarId'] = $this->getDomainRegid($data, $data['UpdateTime']);
				if(!empty($data['PayId']) && empty($data['BankName']))
				{
					$data['BankName'] = $this->getPayBankName($data['PayId'], $payMod);
				}
				$findData = array('EnameId' => $data['EnameId'], 'InOutType' => $data['InOutType'],
						'LinkDomain' => $data['LinkDomain'], 'OrderId' => $data['OrderId'],
						'UpdateTime' => $data['UpdateTime'], 'Remark' => $info['InRemark'],
						'InOutMoney' => $info['InMoney'], 'CurrentMoney' => $info['CurrentMoney']);
				if(!empty($data['byYear']))
				{
					$findData['byYear'] = $data['byYear'];
				}
				// 				if(!$genelMod->getFinGeneralCount(array_merge($findData)))
				// 				{
				if(!$genelMod->addFinGeneral($data))
				{
					\core\Log::write("add general fail," . $outInfo['OutId'], 'finance', 'financeRecordIn');
				}
				// 				}
			}
			$startId = $endId;
			if($startId >= $maxId)
			{
				if(!$this->setRedisMid('setm', 'inaction', 'min', $maxId))
				{
					\core\Log::write("set mid fail," . $maxId, 'finance', 'financeRecordIn');
				}
				break;
			}
		}
	}

	/**
	 * 获取充值订单的银行类型
	 * @param int $payId
	 * @return number
	 */
	private function getPayBankName($payId, \models\manage\finance\FinPayMod $payMod)
	{
		$bankName = 0;
		$payInfo = $payMod->getPayInfoPayId($payId, date('Y'));
		//获取充值订单信息跨年兼容一天
		if(!$payInfo)
		{
			$newYear = date('Y').'0101000000';
			$newYearUnix = strtotime($newYear);
			$nowUnix = time();
			if($nowUnix >= $newYearUnix && $nowUnix <= $newYearUnix + 86400)
			{
				$payInfo = $payMod->getPayInfoPayId($payId, date('Y')-1);
			}
		}
		if(!$payInfo)
		{
			\core\Log::write("not found pay info," . $payId, 'finance', 'financeRecordInFix');
		}
		else
		{
			switch($payInfo['PayType'])
			{
				case 1://支付宝
					$bankName = 9;
					break;
				case 5://盛付通
					$bankName = 10;
					break;
				case 6://银联
					$bankName = 11;
					break;
				case 7://民生
					$bankName = 13;
					break;
				default://其他
					$bankName = 0;
					break;
			}
		}
		return $bankName;
	}

	/**
	 * 填充域名
	 */
	private function getLinkDomain($remark, $hideRemark)
	{
		if(preg_match("/([\x{4e00}-\x{9fa5}]|[a-zA-Z0-9-])+(\.[a-z]{2,4})?\.([a-z]|[\x{4e00}-\x{9fa5}]){2,4}$/ui", $remark, $arr))
		{
			return isset($arr[0]) ? $arr[0] : FALSE;
		}
		if(preg_match("/([\x{4e00}-\x{9fa5}]|[a-zA-Z0-9-])+(\.[a-z]{2,4})?\.([a-z]|[\x{4e00}-\x{9fa5}]){2,4}$/ui", $hideRemark, $arr))
		{
			return isset($arr[0]) ? $arr[0] : FALSE;
		}
		return FALSE;
	}

	private function getALBNumber($chinse)
	{
		if(is_numeric($chinse))
		{
			return $chinse;
		}
		$arr = array("一" => 1, "二" => 2, "三" => 3, "四" => 4, "五" => 5, "六" => 6, "七" => 7, "八" => 8, "九" => 9,
				"十" => 10);
		return array_key_exists($chinse, $arr) ? $arr[$chinse] : 0;
	}

	/**
	 * 获取财务入款信息
	 */
	private function getFinanceInInfo($enameId, $intype, $orderId)
	{
		$inMod = new \models\manage\finance\FinInMod();
		$return = $inMod->getFinanceIn(array('enameId' => $enameId, 'offset' => 0, 'num' => 1, 'type' => $intype,
				'orderId' => $orderId));
		if($return)
		{
			return $return[0];
		}
		return FALSE;
	}

	/**
	 * 订单信息
	 */
	private function getOrderInfo($orderId)
	{
		$orderMod = new \models\manage\finance\FinOrderMod();
		$orderInfo = $orderMod->getOrderByOrderId($orderId);
		return $orderInfo;
	}

	/**
	 * 获取域名后缀
	 */
	private function getDomainLtd($domain)
	{
		if($domain)
		{
			$config = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
			$ltd = \lib\manage\common\DomainFunLib::getDomainLtd($config->domainLtd->toArray(), $domain);
			if($ltd)
			{
				return $ltd;
			}
		}
		return '';
	}

	/**
	 * 获取域名的注册商ID
	 * 1.在订单表和出入款表的RegistarId为0或者空的情况下自动匹配
	 * 2.仅需处理域名注册1／转入2／续费3／赎回4／转接口14
	 *
	 * @param string $domain 域名
	 * @param int $financeType 订单类型
	 * @param date $doTime 订单成功时间
	 * @return int|boolean
	 */
	private function getDomainRegid($financeInfo, $doTime)
	{
		if(!empty($financeInfo['RegistrarId']))
		{
			return $financeInfo['RegistrarId'];
		}
		$domain = $financeInfo['LinkDomain'];
		$financeType = $financeInfo['InOutType'];
		if($domain)
		{
			$domainMod = new ModBase('domain');
			$regId = 0;
			switch($financeType)
			{
				//续费转入的读取默认regid
				case 1:
				case 2:
				case 4:
					$domainFix = $this->domainRouter($domain);
					if(0 == $domainFix)
						break;
					//不知道这边为啥会是0
					//webcc新接口上线时间待定
					if(in_array($domainFix, array('cc', 'tv', 'biz')) && $doTime >= strtotime('2015-03-04 18:00:00'))
					{
						$regId = DomainSupport::$domainSupport[$domainFix];
					}
					else
					{
						$regId = isset($domainFix['suffix']) ? $domainFix['suffix'] : $domainFix;
					}
					break;
				//续费的读取是否域名表有记录，没有的话读取续费时间后的最早一条备份表数据；并判断续费之后是否做过转接口
				case 3:
					$regId = $this->getRenewLog($domain, $doTime);
					break;
				case 14:
					if(in_array($domain, array('boduo.cn', 'guze.cn', 'yuse.cn')))
					{
						$regId = 1;
					}
					else
					{
						$app = $domainMod->getRow("select NewApp from e_domain_transfer_app where Domain= ? and Status = ? ", 'si', array(
								$domain, 3));
						if($app)
						{
							$regId = $app['NewApp'];
						}
					}
					break;
				default:
					break;
			}
			return $regId;
		}
		return 0;
	}

	/**
	 * 根据续费日志返回regid
	 */
	private function getRenewLog($domain, $time)
	{
		$loglist = \lib\manage\domain\DomainLogsLib::getDomainService(array('Domain' => $domain, 'ServiceType' => 6,
				'Content' => 'renewal success'));
		if(empty($loglist))
		{
			return FALSE;
		}
		foreach($loglist as $info)
		{
			//正常情况下续费订单跟流水的时间不会差很多 直接这么取了
			$day = date('Y-m-d', strtotime($info['OperationTime']));
			$waterDay = date('Y-m-d', $time);
			if($day == $waterDay)
			{
				$params = json_decode($info['Content'], true);
				if($params['param'])
				{
					return !empty($params['param']['registrarID']) ? $params['param']['registrarID'] : 0;
				}
			}
		}
		return 0;
	}

	/**
	 * 获取底层默认接口ID
	 * @param unknown $domain
	 * @return number|multitype:string
	 */
	private function domainRouter($domain)
	{
		$domainLtd = \lib\manage\common\DomainFunLib::getDomainClass($domain);
		if(!$domainLtd)
		{
			return 0;
		}
		$domainLtd = strtolower($domainLtd);
		include_once APP_PATH . '/dataCenter/library/lib/manage/eNameSdkApi/application/domain/config/ApiDomainConfig.php';

		$domainInfo['domainName'] = \lib\manage\common\DomainFunLib::getDomainBody($domain);
		// 新增支持.中国后缀判断
		if(in_array($domainLtd, CnnicIdnSuffix::$cnnicIdnSuffix))
		{
			$check_cn = \lib\manage\common\DomainFunLib::isCnDomain($domain);
		}
		else
		{
			$check_cn = \lib\manage\common\DomainFunLib::isCnBody($domain);
		}
		// 验证是否是中文域名
		if($check_cn == 1)
		{
			if(in_array($domainLtd, IdnSufixEpp::$idnSufixEpp))
			{
				$domainLtd = $domainLtd . 'idn';
			}
			elseif(in_array($domainLtd, CnnicIdnSuffix::$cnnicIdnSuffix))
			{
				$domainLtd = 'cnidn';
			}
			elseif(in_array($domainLtd, array("公司", "网络")))
			{
				$domainLtd = $domainLtd;
			}
			else
			{
				return 0; // 域名不合法
			}
		}
		else
		{
			if(in_array($domainLtd, CnnicIdnSuffix::$cnnicIdnSuffix))
			{
				return 0;
			}
		}
		// 判断系统是否支持
		if(array_key_exists($domainLtd, DomainSupport::$domainSupport))
		{
			return array('suffix' => DomainSupport::$domainSupport[$domainLtd]);
		}
		else
		{
			return 0;
		}
	}

	/**
	 * 记录上次操作的最大和最小id
	 * @param action:获取还是更新   key：出入款的key
	 */
	private function setRedisMid($action, $type, $mtype, $num = 1)
	{
		$redis = new \lib\manage\common\RedisLib();
		if($action == 'getm')
		{
			return $redis->getData($type . '|' . $mtype);
		}
		else
		{
			return $redis->setData($type . '|' . $mtype, $num);
		}
	}

	private function getDomainYear($data)
	{
		if(!empty($data['ProductOptions']))
		{
			$jsonInfo = json_decode($data['ProductOptions'], true);
			if(!empty($jsonInfo['year']))
			{
				$data['DomainYear'] = $jsonInfo['year'];
			}
		}
		else
		{
			if(in_array($data['InOutType'], array(1, 2, 3, 4, 14)))
			{
				$data['DomainYear'] = 1;
			}
		}
		return $data;
	}

	/**
	 * 根据备注或者隐藏备注修复新财务表的domainltd和linkdomain
	 */
	public function repairDnLtdAction()
	{
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
		$domainLtdArray = $conf->domainLtd->toArray();
		$finGeneralMod = new ModBase('finance');
		$query = "select * from e_finance_general2015 where DomainLtd=0 or LinkDomain=''";
		$resultInfo = $finGeneralMod->select($query, '', array());
		if(!empty($resultInfo))
		{
			foreach($resultInfo as $k => $v)
			{
				$domain = self::getLinkDomain($v['Remark'], $v['RemarkHide']);
				$domainLtd = $domain ? DomainFunLib::getDomainLtd($domainLtdArray, $domain) : false;
				if($domain && $domainLtd)
				{
					$query = "update e_finance_general2015 set DomainLtd=" . $domainLtd . ",LinkDomain='" . $domain . "' where GeneralId=" . $v['GeneralId'];
					if(!$finGeneralMod->update($query, '', array()))
					{
						\core\Log::write('domain信息修复失败【' . $query . '】', 'cronmanage/finance', 'repairdnltd');
					}
				}
			}
		}
	}
	
	
	/**
	 * 临时 修复跨年 发票额度 数据错误 2016-12-25~2016-12-29  请在2017-01-05号跑 
	 * 
	 */
	public function fixUserInvoiceFareAction()
	{
		$financeMod = new \core\ModBase('finance');
		$num = 0;
		$size = 5000;
		$start = '2016-12-25 00:00:00';
		$end =  '2016-12-29 23:59:59';
		$logic = new \logic\manage\finance\InvoiceLogic();
		$year = '2016';
		$tableName = 'e_finance_out' . $year ;
		while(true)//跑出款表
		{
			$limit = $num * $size . ',' . $size;
			$sql = "select sum(OutMoney) as total,EnameId,year(CreateDate) as yyear from $tableName where CreateDate>='{$start}' and CreateDate<='{$end}' and (OutType in(1,2,3,4,5,9,24,25,26,13,14,15,19) or (OutType=112 and OutTypeSon=3) or (OutType=111 and OutTypeSon=3) or (OutType=34 and OutTypeSon=36)) group by EnameId,year(CreateDate)";
			$sql .= " limit " . $limit;
			$resultOut = $financeMod->select($sql, '', array());
			if(empty($resultOut))
			{
				echo "handle e_finance_out over\r\n";
				break;
			}
			foreach($resultOut as $info)
			{
				if($info['yyear'] != date('Y') && $info['yyear'] != date('Y') - 1)
				{
					continue;
				}
				if($info['total'] <= 0.0000)
				{
					continue;
				}
				$data = array('enameId' => $info['EnameId'], 'invoiceFare' => sprintf("%.4f", $info['total']),
					'year' => $info['yyear']);
				echo "out:".json_encode($data)."\n";
				if(!$logic->addInvoiceFare($data))
				{
					echo "add user fare failed\r\n";
					\core\Log::write("failed," . implode(",", $data), 'finance', 'invoicefare');
				}
			}
			$num++;
		}
		$outNUm = 0;
		$tableName = 'e_finance_in'.$year;
		while(true)//跑入款表 手续费
		{
			$limit = $outNUm * $size . ',' . $size;
			$inSql = "select sum(FeeMoney) as total,EnameId,year(CreateDate) as yyear from $tableName ";
			$inSql .= " where CreateDate>='{$start}' and CreateDate<='{$end}' and InType in(8,10,101,102,103,104,105,106,107,108,109,110,113,114,115,116,117,118,119,121,122,123,124,125,126,127,128,129,130,131,132,135)";
			$inSql .= " and LinkEnameId!=''";
			$inSql .= " group by EnameId,year(CreateDate) limit $limit";
			$resultIn = $financeMod->select($inSql, '', array());
			if(empty($resultIn))
			{
				echo "handler e_finance_in over\r\n";
				break;
			}
			foreach($resultIn as $info)
			{
				if($info['yyear'] != date('Y') && $info['yyear'] != date('Y') - 1)
				{
					continue;
				}
				if($info['total'] <= 0.0000)
				{
					continue;
				}
				$data = array('enameId' => $info['EnameId'], 'invoiceFare' => sprintf("%.4f", $info['total']),
					'year' => $info['yyear']);
				echo "in".json_encode($data)."\n";
				if(!$logic->addInvoiceFare($data))
				{
					echo "add user fare failed\r\n";
					\core\Log::write("failed," . implode(",", $data), 'finance', 'invoicefare');
				}
			}
			$outNUm++;
		}
	}
}

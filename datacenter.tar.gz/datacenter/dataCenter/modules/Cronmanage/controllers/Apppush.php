<?php
use core\Response;
class ApppushController extends Yaf\Controller_Abstract
{

	public function transPushAction()
	{
		try
		{
			$pushLogic = new \logic\manage\member\AppPushLogic();
			$this->pushConf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'apppush');
			$open = $this->pushConf->open;
			if($open == 1)
			{
				$pushLogic->TransPush();
			}
		}
		catch(Exception $e)
		{
			\core\Log::write($e->getMessage(), 'app_push');
		}
	}
	
	public function messPushAction()
	{
		try
		{
			$pushLogic = new \logic\manage\member\AppPushLogic();
			$pushLogic->messPush();
		}
		catch(Exception $e)
		{
			\core\Log::write($e->getMessage(), 'app_push');
		}
	}
}
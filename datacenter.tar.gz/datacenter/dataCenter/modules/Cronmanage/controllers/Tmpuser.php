<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class TmpuserController extends Yaf\Controller_Abstract
{
	/**
	 *
	 * 用户信息导入appmember表传值starid,endid,数据库查询氏>=startid and <endid
	 */
	public function insertAppuserAction()
	{
		try
		{
			form\manage\member\MemberForm::checkGetEnameId();
			if(ReturnData::$success)
			{
				$userLogic = new logic\manage\member\UserMemberLogic();
				$rs = $userLogic->insertAppMember(ReturnData::$info);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::error($rs['msg']);
				}
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
	/**
	 *
	 * 用户信息导入appmember表
	 */
	public function insertAppFriendsAction()
	{
		try
		{
			form\manage\member\MemberForm::checkEnameId();
			if(ReturnData::$success)
			{
				$userLogic = new logic\manage\member\UserMemberLogic();
				$rs = $userLogic->insertAppFriends(ReturnData::$info->EnameId);
				if($rs['flag'])
				{
					Response::success($rs['msg']);
				}
				else
				{
					Response::error($rs['msg']);
				}
			}
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(Exception $e)
		{
			Response::error($e->getMessage(), $e->getCode());
		}
	}
}

<?php
use core\ModBase;
use lib\manage\common\DomainFunLib;

class UserController extends Yaf\Controller_Abstract
{
	// 根据enameid和safeadd检测成功登陆次数超过五次设置成安全地址
	private function checkSafeAdd($userMod, $enameId, $safeAdd, $ip)
	{
		$safeAdInfo = $userMod->getRow(
			"select * from e_member_safeadress where EnameId=" . $enameId . " and SafeAdd='" . $safeAdd . "'", '', 
			array());
		if(!empty($safeAdInfo))
		{
			return true; // 用户安全地址已设置
		}
		$isFiveQuery = "select count(SafeAdd) as total,FROM_UNIXTIME(LoginTime, '%Y-%m-%d') as lotime from e_member_log_login2015 where EnameId=" .
			 $enameId . " and SafeAdd='" . $safeAdd . "' and Status=1 and LoginFrom in(1,6) and LoginTime>=" .
			 strtotime(' -6 months') . " group by lotime order by lotime desc";
		$fiveResult = $userMod->select($isFiveQuery, '', array());
		if(count($fiveResult) >= 5)
		{
			$insert = "insert into e_member_safeadress(EnameId,Ip,UpdateTime,SafeAdd) values(" . $enameId . ",'" . $ip .
				 "'," . time() . ",'" . $safeAdd . "')";
			$insertResult = $userMod->add($insert, '', array());
			\core\Log::write('成功登陆次数超过五次设置成安全地址' . ($insertResult ? '成功' : '失败') . '【' . $insert . '】', 
				'cronmanage/user', 'addlogininfoandaddr');
		}
	}
	// 将redis中的登录信息写入到登录日志表 并 判断登录5次成功后自动设为安全地址
	public function addLoginInfoAndAddrAction()
	{
		$handleNum = 20; // 每次运行脚本处理的个数
		try
		{
			$redis = \core\RedisLib::getInstance('cas');
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/data.ini', 'rpc');
			$userMod = new ModBase('user');
			$userLoginLogMod = new \models\manage\member\MemberLogLoginMod();
			$secureWarningMod = new \models\manage\member\SecureWarningMod();
			for($i = 0; $i <= $handleNum; $i++)
			{
				$loginInfo = $redis->rPop("UserInfo-cas-new");
				if(empty($loginInfo))
				{
					exit(); // redis队列中登录数据
				}
				// 获取地区信息
				$iflocation = isset($loginInfo['iflocation']) ? trim($loginInfo['iflocation']) : '';
				if(empty($iflocation) && isset($loginInfo['loginFrom']) && $loginInfo['loginFrom'] == 1)
				{
					$secGetAd = self::secGetAddress($userMod, $loginInfo['ip']);
					if($secGetAd['flag'])
					{
						$iflocation = $secGetAd['data'];
						self::repairSecAdd($userMod, $secureWarningMod, $loginInfo['ip'], $secGetAd['data'], 
							$secGetAd['type'], $loginInfo['enameId']);
					}
					else if($secGetAd['msg'] == '当天请求次数已达1000次' || $secGetAd['msg'] == 'wfc')
					{
						$iflocation = 'wfc'; // 特殊字段，等待更新
					}
				}
				// 添加登录信息
				$info = array('EnameId' => $loginInfo['enameId'], 'Email' => $loginInfo['email'], 
						'Ip' => $loginInfo['ip'], 'Status' => $loginInfo['loginStatus'], 
						'LoginTime' => $loginInfo['loginTime'], 
						'Remark' => isset($loginInfo['remark']) ? $loginInfo['remark'] : '', 
						'Browser' => $loginInfo['userAgent'], 'LoginFrom' => $loginInfo['loginFrom'], 
						'SafeAdd' => $iflocation);
				if(isset($loginInfo['openId']) && isset($loginInfo['openType']))
				{
					$info['OpenId'] = $loginInfo['openId'];
					$info['OpenType'] = $loginInfo['openType'];
				}
				$addResult = $userLoginLogMod->addInfo($info);
				\core\Log::write('添加登录信息' . ($addResult ? '成功' : '失败') . '【' . json_encode($info) . '】', 
					'cronmanage/user', 'addlogininfoandaddr');
				if(!empty($info['Status']) && 1 == $info['Status'])
				{
					// 如果用户是用邮箱登录的，重新用邮箱取获取用户id
					// if(empty($loginInfo['enameId']))
					// {
					// $getEnameId = $userMod->getRow("select EnameId from
					// e_member where Email='".$loginInfo['email']."'", '',
					// array());
					// $loginInfo['enameId'] = empty($getEnameId) ? 0 :
					// $getEnameId['EnameId'];
					// }
					// 更新用户最后一次登录记录 非模拟登陆
					if ($loginInfo['loginFrom']!=5)
					{
						$upStr = "update e_member set LastLoginIp='" . $loginInfo['ip'] . "',LastLoginTime='" .
							date("Y-m-d H:i:s", $loginInfo['loginTime']) . "' where EnameId=" . $loginInfo['enameId'];
							$upResult = $userMod->update($upStr, '', array());
							\core\Log::write('更新最后一次登录信息' . ($upResult ? '成功' : '失败') . '【' . $upStr . '】', 'cronmanage/user',
								'addlogininfoandaddr');
					}
					if(!empty($iflocation) && $iflocation != 'wfc')
					{
						self::checkSafeAdd($userMod, $loginInfo['enameId'], $iflocation, $loginInfo['ip']);
					}
				}
			}
		}
		catch(Exception $e)
		{
			echo $e->getMessage();
			\core\Log::write($e->getMessage(), 'cronmanage/user', 'addlogininfoandaddr');
		}
	}
	// 未知地址登录和异地登录－警报写入，及其安全地址优化
	public function checkLoginSecAction()
	{
		$handleNum = 15; // 每次运行脚本处理的个数
		try
		{
			$redis = \core\RedisLib::getInstance('common');
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/data.ini', 'rpc');
			$userMod = new ModBase('user');
			$secureWarningMod = new \models\manage\member\SecureWarningMod();
			$tempIp = array();
			for($i = 1; $i <= $handleNum; $i++)
			{
				$secInfo = $redis->rPop("cas_login_secure_add");
				if(empty($secInfo))
				{
					exit(); // redis队列中无未知地区登录警报数据
				}
				// $secInfo['secType']:1,异地登录警报处理 2,异地登录验证 3,异地登录提醒 4,app异地登录提醒
				// 异地登录警报处理
				if(!isset($secInfo['secType']) || $secInfo['secType'] == 1)
				{
					$getSecInfo = $secureWarningMod->getWarningList(
						array('EnameId' => $secInfo['enameId'], 'IP' => $secInfo['ip'], 'BusinessType' => 10, 
								'HandleStatus' => 1, 'Status' => 3, 'Priority' => 6, 'order' => 'Id desc ', 
								'limit' => ' 1'));
					if(!empty($getSecInfo))
					{
						$i--; // 警报中有已经处理的类似的警报 不占用处理个数
						\core\Log::write('已有类似已处理的未知地区异地登录警报，不添加警报【' . json_encode($secInfo) . '】', 'cronmanage/user', 'checkloginsec');
						$secGetAd = self::secGetAddress($userMod, $secInfo['ip']);
						if($secGetAd['flag'])
						{
							self::repairSecAdd($userMod, $secureWarningMod, $secInfo['ip'], $secGetAd['data'], 
								$secGetAd['type'], $secInfo['enameId']);
						}
						continue;
					}
					$getSecInfo = $secureWarningMod->getWarningList(
						array('EnameId' => $secInfo['enameId'], 'IP' => $secInfo['ip'], 'BusinessType' => 10, 
								'HandleStatus' => 0, 'Status' => 1, 'Priority' => 6, 'order' => 'Id desc ', 
								'limit' => ' 1'));
					if(!empty($getSecInfo))
					{
						$i--; // 警报中有未处理的类似的警报 不占用处理个数
						\core\Log::write('已有类似未处理的未知地区异地登录警报，不添加警报【' . json_encode($secInfo) . '】', 'cronmanage/user', 'checkloginsec');
						if(!in_array($secInfo['ip'], $tempIp))
						{
							$secGetAd = self::secGetAddress($userMod, $secInfo['ip']);
							if($secGetAd['flag'])
							{
								self::repairSecAdd($userMod, $secureWarningMod, $secInfo['ip'], $secGetAd['data'], 
									$secGetAd['type'], $secInfo['enameId']);
							}
						}
						continue;
					}
					//警报中没有类似的，则重新获取地区并写入警报，发送提醒
					$secGetAd = self::secGetAddress($userMod, $secInfo['ip'], 3);//强制获取地区，无城市的以横杠‘－’拼接运营商
					if($secGetAd['flag'])
					{
						self::repairSecAdd($userMod, $secureWarningMod, $secInfo['ip'], $secGetAd['data'],
							$secGetAd['type']);
						$safeAdInfo = $userMod->getRow(
							"select * from e_member_safeadress where EnameId=" . $secInfo['enameId'] . " and SafeAdd='" .
								 $secGetAd['data'] . "'", '', array());
						if(empty($safeAdInfo)) // 不在安全地址列表中，发送提醒
						{
							$remindMsg = self::sendUserLoginremind($userMod, $secureWarningMod, $secInfo['enameId'], 
								$secInfo['time'], $secInfo['ip'], $secGetAd['data']);
							if($remindMsg['isSend'])
							{
								$content = $secInfo['ip'] . ',' . $secGetAd['data'] . ',' . $remindMsg['content'];
								$params = array('enameid' => $secInfo['enameId'], 'BusinessType' => 10, 'domain' => '', 
										'Content' => $content, 'IP' => $secInfo['ip'], 'Priority' => 6, 
										'CreateDate' => $secInfo['time'], 'Status' => 3, 'HandleStatus' => 4, 
										'Handle' => 21, 'UpdateDate' => time());
								$addResult = $secureWarningMod->addInfo($params);
								\core\Log::write(
									'添加未知地区异地登录警报' . ($addResult ? '成功' : '失败') . '【' . json_encode($params) . '】', 
									'cronmanage/user', 'checkloginsec');
							}
						}
					}
					else
					{
						$tempIp[] = $secInfo['ip'];
						$params = array('enameid' => $secInfo['enameId'], 'BusinessType' => 10, 'domain' => '', 
								'Content' => '未知地址' . ',' . $secGetAd['data'], 'IP' => $secInfo['ip'], 'Priority' => 6, 
								'CreateDate' => $secInfo['time'], 'Status' => 1, 'HandleStatus' => 0);
						$addResult = $secureWarningMod->addInfo($params);
						\core\Log::write('添加未知地区异地登录警报' . ($addResult ? '成功' : '失败') . '【' . json_encode($params) . '】', 
							'cronmanage/user', 'checkloginsec');
					}
				}
				// 异地登录验证处理
				if(isset($secInfo['secType']) && $secInfo['secType'] == 2)
				{
					$getSecInfo = $secureWarningMod->getCount(
						array('EnameId' => $secInfo['enameId'], 'IP' => $secInfo['ip'], 'BusinessType' => 10, 
								'HandleStatus' => 3, 'Status' => 3, 'Priority' => 6, 
								'createbegin' => date('Y-m-d') . ' 00:00:00', 'createend' => date('Y-m-d') . ' 23:59:59'));
					if(empty($getSecInfo) || empty($getSecInfo['sum']))
					{
						$content = $secInfo['ip'] . ',' . $secInfo['address'] . ',短信验证';
						$params = array('enameid' => $secInfo['enameId'], 'BusinessType' => 10, 'domain' => '', 
								'Content' => $content, 'IP' => $secInfo['ip'], 'Priority' => 6, 
								'CreateDate' => $secInfo['time'], 'Status' => 3, 'HandleStatus' => 3, 'Handle' => 21, 
								'UpdateDate' => time());
						$addResult = $secureWarningMod->addInfo($params);
						\core\Log::write('添加异地登录验证警报' . ($addResult ? '成功' : '失败') . '【' . json_encode($params) . '】', 
							'cronmanage/user', 'checkloginsec');
					}
					else
					{
						\core\Log::write('当天已存在有异地登录验证警报【' . $secInfo['enameId'] . '】【' . $secInfo['ip'] . '】', 
							'cronmanage/user', 'checkloginsec');
					}
					// 添加安全地址
					/*
					 * $insert = "insert into
					 * e_member_safeadress(EnameId,Ip,UpdateTime,SafeAdd)
					 * values(".$secInfo['enameId'].",'".$secInfo['ip']."',".$secInfo['time'].",'".$secInfo['address']."')";
					 * $addResult = $userMod->add($insert,'',array());
					 * \core\Log::write('添加安全地址'.($addResult ? '成功' :
					 * '失败').'【'.$insert.'】', 'cronmanage/user',
					 * 'checkloginsec');
					 */
				}
				// 异地登录提醒处理
				if(isset($secInfo['secType']) && $secInfo['secType'] == 3)
				{
					$remindMsg = self::sendUserLoginremind($userMod, $secureWarningMod, $secInfo['enameId'], 
						$secInfo['time'], $secInfo['ip'], $secInfo['address']);
					if($remindMsg['isSend'])
					{
						$content = $secInfo['ip'] . ',' . $secInfo['address'] . ',' . $remindMsg['content'];
						$params = array('enameid' => $secInfo['enameId'], 'BusinessType' => 10, 'domain' => '', 
								'Content' => $content, 'IP' => $secInfo['ip'], 'Priority' => 6, 
								'CreateDate' => $secInfo['time'], 'Status' => 3, 'HandleStatus' => 4, 'Handle' => 21, 
								'UpdateDate' => time());
						$addResult = $secureWarningMod->addInfo($params);
						\core\Log::write(
							'添加未知地区异地登录提醒警报' . ($addResult ? '成功' : '失败') . '【' . json_encode($params) . '】', 
							'cronmanage/user', 'checkloginsec');
					}
				}
				// app异地登录提醒处理
				if(isset($secInfo['secType']) && $secInfo['secType'] == 4)
				{
					$remindMsg = self::sendUserLoginremind($userMod, $secureWarningMod, $secInfo['enameId'], 
						$secInfo['time'], $secInfo['ip'], $secInfo['address'], $secInfo['deviceToken']);
					if($remindMsg['isSend'])
					{
						$content = 'app异常登录设备号:' . $secInfo['deviceToken'] . ',' . $remindMsg['content'];
						$params = array('enameid' => $secInfo['enameId'], 'BusinessType' => 10, 'domain' => '', 
								'Content' => $content, 'IP' => $secInfo['ip'], 'Priority' => 6, 
								'CreateDate' => $secInfo['time'], 'Status' => 3, 'HandleStatus' => 4, 'Handle' => 21, 
								'UpdateDate' => time(), 'Ext' => $secInfo['deviceToken']);
						$addResult = $secureWarningMod->addInfo($params);
						\core\Log::write(
							'添加未知地区异地登录提醒警报' . ($addResult ? '成功' : '失败') . '【' . json_encode($params) . '】', 
							'cronmanage/user', 'checkloginsec');
					}
				}
			}
		}
		catch(Exception $e)
		{
			echo $e->getMessage();
			\core\Log::write($e->getMessage(), 'cronmanage/user', 'checkloginsec');
		}
	}
	// 通过二次获取地区修复警报信息和登录信息
	private function repairSecAdd($userMod, $secureWarningMod, $ip, $address, $type, $enameId = false)
	{
		//有发现空格的先过滤下
		$address = trim($address);
		if(!$address)
		{
			return false;
		}
		if($enameId)
		{
			$safeAdInfo = $userMod->getRow(
				"select * from e_member_safeadress where EnameId=" . $enameId . " and SafeAdd='" . $address . "'", '', 
				array());
			$upStr = "update e_member_secure_warning set Status=3,UpdateDate='" . time() . "',HandleStatus=" .
				 (empty($safeAdInfo) ? 2 : 1) . ",Remark='二次获取地区脚本修复',Content='未知地址,二次修复得到地区信息【" . $address .
				 "】',Handle=21 where EnameId=" . $enameId . " and IP='" . $ip .
				 "' and BusinessType=10 and HandleStatus=0 and Status=1";
			$upResult = $secureWarningMod->update($upStr, '', array());
			\core\Log::write('异地登录警报信息修复' . ($upResult ? '成功' : '失败') . '【' . $upStr . '】', 'cronmanage/user', 
				'checkloginsec');
			if($upResult)
			{
				$infoList =$secureWarningMod->getWarningList(array('EnameId'=>$enameId,'BusinessType'=>10,'HandleStatus'=>0,'Status'=>1,'IP'=>$ip));
				$amqp = new \common\AmqpSdkBase(array(), array('exchangeName' => 'member_secure_warning'));
				foreach ($infoList as $secureInfo)
				{
					$amqp->sendMq(
						array('name' => 'member_secure_warning', 'enameId' => $enameId, 'businessType' => 10,
							'oldStatus' => 1, 'newStatus' => 3, 'domain' => '', 'time' => time(),'createTime'=>$secureInfo['CreateDate']));
				}
			}
		}
		if($type == 2) // $type=1说明登录表的地区信息正常，不去更新
		{
			$upStr = "update e_member_log_login2015 set SafeAdd='" . $address . "' where Ip='" . $ip .
				 "' and (SafeAdd='' or SafeAdd='wfc')";
			$upResult = $userMod->update($upStr, '', array());
			\core\Log::write('登录表地区信息修复' . ($upResult ? '成功' : '失败') . '【' . $upStr . '】', 'cronmanage/user', 
				'checkloginsec');
		}
	}
	// 异地登录提醒
	private function sendUserLoginremind($userMod, $secureWarningMod, $enameId, $time, $ip, $address, 
		$deviceToken = false)
	{
		$today = strtotime(date('Y-m-d'));
		$query = "select count(*) as sum from e_member_secure_warning where EnameId=$enameId and Status=3 and BusinessType=10 and HandleStatus=4 and CreateDate>=" .
			 $today . " and CreateDate<=" . ($today + 86399);
		// app异常登录提醒(只发邮件,一个设备号总的只需要提醒一次)
		if(!empty($deviceToken))
		{
			$query .= ' and Ext = "' . $deviceToken.'" ';
		}
		$secCount = $secureWarningMod->getOne($query, '', array());
		if($deviceToken && $secCount > 0 || $secCount > 1)
		{
			\core\Log::write(
				'未添加的异地登录提醒警报【' . $enameId . '】【' . date("Y-m-d H:i:s", $time) . '】【' . $ip . '】【' . $address . '】【' .
					 $deviceToken . '】', 'cronmanage/user', 'checkloginsec');
			return array('isSend' => false);
		}
		// 暂时不发送提醒,实际上线需要发送的时候本行删除即可
		return array('isSend' => true, 'content' => '暂不发送提醒'); 
		$query = "select IsMobileVerified,Email from e_member where EnameId=" . $enameId;
		$mInfo = $userMod->getRow($query, '', array());
		// pc优先发短信,app只发邮件
		if(empty($deviceToken))
		{
			if(!empty($mInfo) && $mInfo['IsMobileVerified'] == 1)
			{
				$query = "select Mobile from e_member_ext where EnameId=" . $enameId;
				$pInfo = $userMod->getRow($query, '', array());
				// 发送短信提醒
				if(empty($pInfo['Mobile']))
				{
					\core\Log::write('获取用户手机号失败【' . $enameId . '】改用邮件发送提醒', 'cronmanage/user', 'checkloginsec');
				}
				else
				{
					try 
					{
						$queueLogic = new \logic\manage\newqueue\QueueLogic();
						$smsData = array('Function' => 'send_sms', 'EnameId' => $enameId, 'TemplateName' => 'accountwebloginremind', 'Target' => $pInfo['Mobile'], 'Data' => array('enameId' => $enameId), 'Priority' => 4);
						$sendResult = $queueLogic->addQueueNormal($smsData);
					}
					catch (\Exception $e)
					{
						$sendResult = false;
					}
					if($sendResult)
					{
						\core\Log::write('异地登录短信提醒发送成功【' . $enameId . '】【' . $pInfo['Mobile'] . '】', 'cronmanage/user', 
							'checkloginsec');
						return array('isSend' => true, 'content' => '短信提醒');
					}
					else
					{
						\core\Log::write('异地登录短信提醒发送失败【' . $enameId . '】【' . $pInfo['Mobile'] . '】改用邮件发送提醒', 
							'cronmanage/user', 'checkloginsec');
					}
				}
			}
		}
		// 没有绑定手机或者手机获取失败采用邮件发送
		try
		{
			$queueLogic = new \logic\manage\newqueue\QueueLogic();
			$mailTempate = empty($deviceToken) ? 'accountwebloginremind' : 'accountapploginremind';
			$data = array('enameId' => $enameId, 'logintime' => $time, 'email' => $mInfo['Email'], 'address' => $address, 'ip' => $ip, 'deviceToken' => $deviceToken);
			$mailData = array('Function' => 'sendmail', 'EnameId' => $enameId, 'TemplateName' => $mailTempate, 'Target' => $mInfo['Email'], 'Data' => $data, 'Priority' => 4);
			$sendResult = $queueLogic->addQueueNormal($mailData);
		}
		catch (\Exception $e)
		{
			$sendResult = false;
		}
		\core\Log::write('异地登录邮件提醒发送' . ($sendResult ? '成功' : '失败') . '【' . $enameId . '】【' . $mInfo['Email'] . '】', 'cronmanage/user', 'checkloginsec');
		return array('isSend' => true, 'content' => '邮件提醒');
	}
	// 二次获取地区
	// return type 1:从登录表正常获取 2:接口获取
	//LoginFrom = array(1 => '平台登录', 2 => 'APP登录', 3 => 'API第三方登录', 4 => 'Ename管理工具系统', 5 => '模拟登录', 6 => 'H5登录');
	/**
	 * 二次获取地区
	 * @param ModBase $userMod
	 * @param string $ip
	 * @param string $isAdminRepair 1普通获取优先读登录日志，2定时重新获取ip地区修复，3获取用于警报显示未知地址依然返回地区
	 * @return array
	 */
	private function secGetAddress(ModBase $userMod, $ip = '', $isAdminRepair = 1)
	{
		if(!DomainFunLib::checkIsIp($ip))
		{
			\core\Log::write('ip格式错误【' . $ip . '】', 'cronmanage/user', 'checkloginsec');
			return array('flag' => false, 'msg' => 'ip格式错误');
		}
		$query = "select SafeAdd from e_member_log_login2015 where Ip = '" . $ip . "' and SafeAdd != ''";
		$getAdInfo = $userMod->getRow($query, '', array());
		$safeAdd = empty($getAdInfo) ? false : trim($getAdInfo['SafeAdd']);
		if(!empty($safeAdd) && $safeAdd != 'wfc')
		{
			return array('flag' => true, 'data' => $getAdInfo['SafeAdd'], 'type' => 1);
		}
		$query = "select SafeAdd,LoginTime from e_member_log_login2015 where Ip = '" . $ip . "' and LoginFrom = 1 "; // 外网历史ip重新匹配过新ip库的地区，因此不必限制时间了
		$getAdInfo = $userMod->getRow($query, '', array());
		if(1 == $isAdminRepair && !empty($getAdInfo))
		{
			if(empty($getAdInfo['SafeAdd'])) // 已经请求过ip接口，地区为空
			{
				\core\Log::write('该ip请求过接口，地区为空【' . $ip . '】', 'cronmanage/user', 'checkloginsec');
				return array('flag' => false, 'msg' => '该ip请求过接口，地区为空');
			}
			if($getAdInfo['SafeAdd'] != 'wfc') // 返回之前请求过接口的地区信息
			{
				return array('flag' => true, 'data' => $getAdInfo['SafeAdd'], 'type' => 1);
			}
			if(date('Y-m-d', $getAdInfo['LoginTime']) == date('Y-m-d')) // 如果是同一天请求次数已满，这天就不再请求接口
			{
				\core\Log::write('今天接口请求次数已满，不再请求【' . $ip . '】', 'cronmanage/user', 'checkloginsec');
				return array('flag' => false, 'msg' => '今天接口请求次数已满，不再请求');
			}
			\core\Log::write('该ip上次请求接口的时候接口请求次数已满，今天再次请求【' . $ip . '】', 'cronmanage/user', 'checkloginsec');
		}
		try
		{
			//如果是警报列表来获取地区则返回完整的地区不做省份城市强制判断，用于警报显示
			$ipInfoMsg = $this->getLocations($ip,3 == $isAdminRepair ? true : false);
			if(empty($ipInfoMsg) || $ipInfoMsg == 'wfc' || false !== strpos($ipInfoMsg, '-'))
			{
				$return['flag'] = false;
				$return['msg'] = '根据IP获取参考地址失败';
				$return['data'] = $ipInfoMsg;
				\core\Log::write('根据IP获取参考地址失败' . '【' . $ip . '】' . $ipInfoMsg, 'cronmanage/user', 'checkloginsec');
			}
			else
			{
				$return['data'] = $ipInfoMsg;
				$return['flag'] = true;
			}
			$return['type'] = 2;
			return $return;
		}
		catch(Exception $e)
		{
			\core\Log::write($e->getMessage(), 'cronmanage/user', 'checkloginsec_err');
			return array('flag' => false, 'msg' => $e->getMessage());
		}
	}
	// 临时脚本，二次获取地区脚本上线后修复异地登录警报和登录日志地区信息
	// 修复警报未知ip每天0点之前不占用ip数量限制
	public function adminRepairAddrAction()
	{
		$userMod = new ModBase('user');
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/data.ini', 'rpc');
		$secureWarningMod = new \models\manage\member\SecureWarningMod();
		// 先修复登录日志表及相关enameid的警报信息
		$query = "select EnameId,Ip from e_member_log_login2015 where SafeAdd = '' or SafeAdd = 'wfc' group by Ip,EnameId";
		$getLoginInfo = $userMod->select($query, '', array());
		if(empty($getLoginInfo))
		{
			\core\Log::write('没有需要修复的登录数据', 'cronmanage/user', 'adminrepairaddr');
		}
		else
		{
			foreach($getLoginInfo as $k => $v)
			{
				$secGetAd = self::secGetAddress($userMod, $v['Ip'], 2);
				if($secGetAd['flag'])
				{
					self::repairSecAdd($userMod, $secureWarningMod, $v['Ip'], $secGetAd['data'], 2, $v['EnameId']);
				}
			}
		}
		// 单独修复警报数据
		$getSecInfo = $secureWarningMod->getWarningList(
			array('BusinessType' => 10, 'HandleStatus' => 0, 'Status' => 1, 'Priority' => 6), 'Id,IP,EnameId');
		if(empty($getSecInfo))
		{
			\core\Log::write('没有需要修复的警报数据', 'cronmanage/user', 'adminrepairaddr');
		}
		else
		{
			foreach($getSecInfo as $k => $v)
			{
				$secGetAd = self::secGetAddress($userMod, $v['IP'], 2);
				if($secGetAd['flag'])
				{
					self::repairSecAdd($userMod, $secureWarningMod, $v['IP'], $secGetAd['data'], 1, $v['EnameId']);
				}
			}
		}
	}
	/**
	 * 临时脚本，ipip.net库累计获取地区信息失败次数多后，用该脚本修复，脚本采用ip.taobao.com淘宝ip库
	 */
	public function adminRepairAddrByTaobaoAction()
	{
		$limit = 10;//淘宝ip库有限制
		$userMod = new ModBase('user');
		$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/data.ini', 'rpc');
		$client = new \Yar_Client($conf->manageother . '/ip');
		$secureWarningMod = new \models\manage\member\SecureWarningMod();
		// 先修复登录日志表及相关enameid的警报信息
		$query = "select count(t.counts) from (select count(*) as counts from e_member_log_login2015 where SafeAdd = '' or SafeAdd = 'wfc' group by Ip,EnameId) t";
		$loginCount = $userMod->getOne($query, '', array());
		if(empty($loginCount))
		{
			\core\Log::write('没有需要修复的登录数据', 'cronmanage/user', 'adminrepairaddrbytaobao');
		}
		else 
		{
			for($i = 0; $i < $loginCount; $i = $i + $limit)
			{
				$query = "select EnameId,Ip from e_member_log_login2015 where SafeAdd = '' or SafeAdd = 'wfc' group by Ip,EnameId limit $i,$limit";
				$getLoginInfo = $userMod->select($query, '', array());
				foreach($getLoginInfo as $k => $v)
				{
					$secGetAd = self::secGetAddrByTaobao($client, $v['Ip']);
					if($secGetAd['flag'])
					{
						self::repairSecAdd($userMod, $secureWarningMod, $v['Ip'], $secGetAd['data'], 2, $v['EnameId']);
					}
				}
				sleep(1);//等待1s后继续
			}
		}
		// 单独修复警报数据
		$where = array('BusinessType' => 10, 'HandleStatus' => 0, 'Status' => 1, 'Priority' => 6);
		$secCount = $secureWarningMod->getCount($where);
		if(empty($secCount))
		{
			\core\Log::write('没有需要修复的警报数据', 'cronmanage/user', 'adminrepairaddr');
		}
		else
		{
			for($i = 0; $i < $secCount; $i = $i + $limit)
			{
				$where['limit'] = $i.','.$limit;
				$getSecInfo = $secureWarningMod->getWarningList($where, 'Id,IP,EnameId');
				foreach($getSecInfo as $k => $v)
				{
					$secGetAd = self::secGetAddrByTaobao($client, $v['Ip']);
					if($secGetAd['flag'])
					{
						self::repairSecAdd($userMod, $secureWarningMod, $v['IP'], $secGetAd['data'], 1, $v['EnameId']);
					}
				}
				sleep(1);
			}
		}
	}
	
	private function secGetAddrByTaobao($client, $ip)
	{
		try
		{
			$return = $client->getTaobaoAddress($ip);
			$return = json_decode($return, true);
			if(!$return['flag'])
			{
				\core\Log::write($return['msg'] . '【' . $ip . '】', 'cronmanage/user', 'adminrepairaddrbytaobao');
			}
			return $return;
		}
		catch(Exception $e)
		{
			\core\Log::write($e->getMessage(), 'cronmanage/user', 'adminrepairaddrbytaobao');
			return array('flag' => false, 'msg' => $e->getMessage());
		}
	}
	
	/**
	 * 每月5日账户报告
	 */
	public function accountReportAction($params = array())
	{
		$number = 4; 
		$hashKeyPart = empty($params[0]) ? 0 : $params[0];
		if(!in_array($hashKeyPart,range(1, $number)))
		{
			exit("key error\r\n");
		}
		$hashKey = "new_vip_member_list_".date('m',strtotime('-1 months'))."_".$hashKeyPart;
		$start = date('Y-m-01 00:00:00', strtotime('-1 month'));
		$end = date('Y-m-d 23:59:59', strtotime('+1month', strtotime($start))-1);
		$redis = \core\RedisLib::getInstance('manage');
		$memberList = $redis->hKeys($hashKey); 
		$redis->setOption(Redis::OPT_SERIALIZER, Redis::SERIALIZER_PHP);
		if(!$memberList)
		{
			exit("$hashKey,not data\r\n");
		}
		$memberList = array_unique($memberList);
		$baseUrl = 'http://www.ename.com/auctioninterface/getshopforbbs';
		$key = 'AuctionPrice#@ename#$511';
		$date = date('Y年m月', strtotime('-1 month'));
		$link = 'http://www.ename.net/member/accountreport?m=' . date('Ym', strtotime('-1 month'));
		$accountReportMod = new \models\manage\member\AccountReportMod();
		$dnMod = new \models\manage\domain\DomainsMod();
		$dnPushMod = new \models\manage\domain\DomainPushMod();
		$tranInMod = new \models\manage\domain\DomainTransferInMod();
		$tranOutMod = new \models\manage\domain\DomainTransferOutMod();
		$userMod = new \models\manage\member\EmemberMod();
		$finOutMod = new \models\manage\finance\FinOutMod();
		$finInMod = new \models\manage\finance\FinInMod();
		$siteMsgLogic = new \logic\manage\information\SiteMessageLogic();
		$queueNorLib = new \lib\manage\newqueue\QueueNormalLib();
		foreach($memberList as $enameId)
		{
			$check = $accountReportMod->getReport(array('EnameId' => $enameId, 'Month' => date('Ym', strtotime('-1 month'))));
			if(!empty($check))
			{
				\core\Log::write($enameId . '账户报告已存在', 'cronmanage/user', 'accountreport');
				continue;
			}
			$accountInfo = $financeInfo = $domainInfo = $tradeInfo = $expenses = $income = array();
			$financeInfoLib = new \lib\manage\finance\FinanceInfoLib($enameId);
			try 
			{
				//当前账户情况
				$financeInfo = $financeInfoLib->getUserFinance();
				$accountInfo['balance'] = !empty($financeInfo) ? number_format($financeInfo['UseMoney'] + $financeInfo['FreezeMoney'], 2) : '0.00';//账户余额
				$query = 'select sum(DrawalMoney) from e_finance_withdrawals where Status = 5 and EnameId = ' . $enameId . ' and CreateDate >= "' . $start . '" and CreateDate <= "' . $end . '"';
				$withdrawalCount = $finInMod->getOne($query, '', array());
				$accountInfo['withdraw'] = empty($withdrawalCount) ? 0 : $withdrawalCount;//提现金额
				$dnCount = $dnMod->getDomainCount(array('EnameId' => $enameId));
				$accountInfo['domainCount'] = empty($dnCount['sum']) ? 0 : $dnCount['sum'];//域名总数
				$expCount = $dnMod->getDomainCount(array('EnameId' => $enameId, 'ExpDate<' => date('Y-m-d H:i:s')));
				$accountInfo['expCount'] = empty($expCount['sum']) ? 0 : $expCount['sum'];//过期域名总数
				$exp30Count = $dnMod->getDomainCount(array('EnameId' => $enameId, 'ExpDate<' => date("Y-m-d H:i:s", time()+2592000)));
				$accountInfo['exp30Count'] = empty($exp30Count['sum']) ? 0 : $exp30Count['sum'];//30天内过期域名总数
				$userInfo = $userMod->getMemberInfo($enameId);
				$accountInfo['email'] = empty($userInfo['IsEmailVerified']) ? 0 : $userInfo['IsEmailVerified'];
				$accountInfo['mobile'] = empty($userInfo['IsMobileVerified']) ? 0 : $userInfo['IsMobileVerified'];
				$accountInfo['identity'] = empty($userInfo['IsIdentityVerified']) ? 0 : $userInfo['IsIdentityVerified'];
				$accountInfo['operateProtect'] = empty($userInfo['IsSetOperateProtect']) ? 0 : $userInfo['IsSetOperateProtect'];//账户绑定信息
				$time = time();
				$url = $baseUrl . '?times=' . $time . '&enameId=' . $enameId . '&sid=' . md5($key . $time);
				$shop = json_decode(@file_get_contents($url), true);
				if($shop['ServiceCode'] == 1000)//获取用户店铺信息
				{
					$accountInfo['shop'] = 1;
					$accountInfo['sellerNum'] = $shop['SellerHonorNum'];
					$accountInfo['sellerLevel'] = $shop['SellerHonorLevel'];
					$accountInfo['sellerType'] = $shop['SellerHonorType'];
					$accountInfo['buyerNum'] = $shop['BuyerHonorNum'];
					$accountInfo['buyerLevel'] = $shop['BuyerHonorLevel'];
					$accountInfo['buyerType'] = $shop['BuyerHonorType'];
				}
				//本月域名报告
				$receivePushCount = $dnPushMod->getOne("select count(*) from e_domain_push p, e_domain_push_details d where d.PushId=p.PushId and p.ReceiveId=".$enameId." and p.ReceiveStatus=1 and p.ReceiveTime>='".$start."' and p.ReceiveTime<='".$end."'", '', array());
				$domainInfo['receivePush'] = empty($receivePushCount) ? 0 : $receivePushCount;//接受push域名个数
				$sendPushCount = $dnPushMod->getOne("select count(*) from e_domain_push p, e_domain_push_details d where d.PushId=p.PushId and p.SendId=".$enameId." and p.ReceiveStatus=1 and p.ReceiveTime>='".$start."' and p.ReceiveTime<='".$end."'", '', array());
				$domainInfo['sendPush'] = empty($sendPushCount) ? 0 : $sendPushCount;//发送push域名个数
				$transferOutCount = $tranOutMod->getTransferCount(array('EnameId' => $enameId, 'Status' => 2, 'CreateTime>' => $start, 'CreateTime<' => $end));
				$domainInfo['transferOut'] = empty($transferOutCount['sum']) ? 0 : $transferOutCount['sum'];//转出域名个数
				$transferInCount = $tranInMod->getTransferCount(array('EnameId' => $enameId, 'TransferStatus' => 8, 'SuccessTime>' => $start, 'SuccessTime<' => $end));
				$domainInfo['transferIn'] = empty($transferInCount['total']) ? 0 : $transferInCount['total'];//转入域名个数
				$expDelete = $dnMod->getOne("select count(*) from e_domains_bak where EnameId=".$enameId." and ExpDate>='".date('Y-m-d H:i:s', strtotime('-45 days'))."'", '', array());
				$domainInfo['expDelete'] = empty($expDelete) ? 0 : $expDelete;//未续费删除域名
				//年份跨年特殊处理
				$byYear = date('Y') != date('Y', strtotime('-1 month')) ? date('Y') - 1 : date('Y');
				$renewCount = $finOutMod->getFinanceOutCount(array('enameId' => $enameId, 'type' => 3, 'startDate' => $start, 'endDate' => $end, 'byYear' => $byYear));
				$domainInfo['renew'] = empty($renewCount['sum']) ? 0 : $renewCount['sum'];//续费域名
				$registCount = $finOutMod->getFinanceOutCount(array('enameId' => $enameId, 'type' => 1, 'startDate' => $start, 'endDate' => $end, 'byYear' => $byYear));
				$domainInfo['regist'] = empty($registCount['sum']) ? 0 : $registCount['sum'];//注册域名
				$newDomain = $dnMod->getDomainCount(array('EnameId' => $enameId, 'AddDate>' => $start, 'AddDate<' => $end));
				$domainInfo['new'] = empty($newDomain['sum']) ? 0 : $newDomain['sum'];//新增域名
				//本月财务收入
				$recharge = $finInMod->getOne("select sum(InMoney) from e_finance_in".$byYear." where EnameId=".$enameId." and CreateDate>='".$start."' and CreateDate<='".$end."' and InType=200", '', array());
				$income['recharge'] = empty($recharge) ? 0 : sprintf("%01.2f", $recharge);
				$push = $finInMod->getOne("select sum(InMoney) from e_finance_in".$byYear." where EnameId=".$enameId." and CreateDate>='".$start."' and CreateDate<='".$end."' and InType=101", '', array());
				$income['push'] = empty($push) ? 0 : sprintf("%01.2f", $push);
				$trade = $finInMod->getOne("select sum(InMoney) from e_finance_in".$byYear." where EnameId=".$enameId." and CreateDate>='".$start."' and CreateDate<='".$end."' and InType in(102,103,104,105,106,107,108,109,113,114,116,115,117,118,121,122,123,124,125,126,127,128)", '', array());
				$income['trade'] = empty($trade) ? 0 : sprintf("%01.2f", $trade);
				$intermediary = $finInMod->getOne("select sum(InMoney) from e_finance_in".$byYear." where EnameId=".$enameId." and CreateDate>='".$start."' and CreateDate<='".$end."' and InType in(111,112)", '', array());
				$income['intermediary'] = empty($intermediary) ? 0 : sprintf("%01.2f", $intermediary);
				$sum = $finInMod->getOne("select sum(InMoney) from e_finance_in".$byYear." where EnameId=".$enameId." and CreateDate>='".$start."' and CreateDate<='".$end."'", '', array());
				$income['sum'] = empty($sum) ? 0 : sprintf("%01.2f", $sum);
				$income['other'] = sprintf("%01.2f", $income['sum'] - $income['recharge'] - $income['push'] - $income['trade'] - $income['intermediary']);
				//本月财务支出
				$finRegDomain = $finInMod->getOne("select sum(OutMoney) from e_finance_out".$byYear." where EnameId=".$enameId." and CreateDate>='".$start."' and CreateDate<='".$end."' and OutType=1", '', array());
				$expenses['regDomain'] = empty($finRegDomain) ? 0 : sprintf("%01.2f", $finRegDomain);
				$finRenew = $finInMod->getOne("select sum(OutMoney) from e_finance_out".$byYear." where EnameId=".$enameId." and CreateDate>='".$start."' and CreateDate<='".$end."' and OutType=3", '', array());
				$expenses['renew'] = empty($finRenew) ? 0 : sprintf("%01.2f", $finRenew);
				$finTransferIn = $finInMod->getOne("select sum(OutMoney) from e_finance_out".$byYear." where EnameId=".$enameId." and CreateDate>='".$start."' and CreateDate<='".$end."' and OutType=2", '', array());
				$expenses['transferIn'] = empty($finTransferIn) ? 0 : sprintf("%01.2f", $finTransferIn);
				$finPush = $finInMod->getOne("select sum(OutMoney) from e_finance_out".$byYear." where EnameId=".$enameId." and CreateDate>='".$start."' and CreateDate<='".$end."' and OutType=101", '', array());
				$expenses['push'] = empty($finPush) ? 0 : sprintf("%01.2f", $finPush);
				$finBook = $finInMod->getOne("select sum(OutMoney) from e_finance_out".$byYear." where EnameId=".$enameId." and CreateDate>='".$start."' and CreateDate<='".$end."' and OutType in(8,24,25,26,110,9,105,121,122,123)", '', array());
				$expenses['book'] = empty($finBook) ? 0 : sprintf("%01.2f", $finBook);
				$finTrade = $finInMod->getOne("select sum(OutMoney) from e_finance_out".$byYear." where EnameId=".$enameId." and CreateDate>='".$start."' and CreateDate<='".$end."' and OutType in(102,103,104,106,108,109,107,113,114,115,116,117,118,124,125,126,127,128)", '', array());
				$expenses['trade'] = empty($finTrade) ? 0 : sprintf("%01.2f", $finTrade);
				$finIntermediary = $finInMod->getOne("select sum(OutMoney) from e_finance_out".$byYear." where EnameId=".$enameId." and CreateDate>='".$start."' and CreateDate<='".$end."' and OutType in(20,21,22,23,10,111,112)", '', array());
				$expenses['intermediary'] = empty($finIntermediary) ? 0 : sprintf("%01.2f", $finIntermediary);
				$finSum = $finInMod->getOne("select sum(OutMoney) from e_finance_out".$byYear." where EnameId=".$enameId." and CreateDate>='".$start."' and CreateDate<='".$end."'", '', array());
				$expenses['sum'] = empty($finSum) ? 0 : sprintf("%01.2f", $finSum);
				$expenses['other'] = sprintf("%01.2f", $expenses['sum']-$expenses['regDomain']-$expenses['renew']-$expenses['transferIn']-$expenses['push']-$expenses['book']-$expenses['trade']-$expenses['intermediary']);
				//域名交易报告
				$tradeReport = $redis->hGet('manage:vip:transdata', $enameId);
				$tradeInfo['book'] = $tradeReport['bookCount'];
				$tradeInfo['buy'] = $tradeReport['buyCount'];
				$tradeInfo['sell'] = $tradeReport['sellCount'];
				$tradeInfo['escrow'] = $tradeReport['escrowCount'];
				$data = array('enameId' => $enameId, 'month' => date('Ym', strtotime('-1 month')), 'accountInfo' => json_encode($accountInfo), 'domainInfo' => json_encode($domainInfo), 'tradeInfo' => json_encode($tradeInfo), 'expenses' => json_encode($expenses), 'incomes' => json_encode($income));
				$addRes = $accountReportMod->addReport($data);
				if(!$addRes)
				{
					\core\Log::write($enameId . '|添加账户报告失败|' . json_encode($data), 'cronmanage/user', 'accountreport');
					continue;
				}
				$email = trim($userInfo['Email']);
				if(!empty($email) && DomainFunLib::isEmail($email))
				{
					try
					{
						$queueLogic = new \logic\manage\thrift\QueueLogic();
						$queueLogic->addQueueNormal(array('TemplateName'=>'account_report_mail','Function'=>"sendmail","EnameId"=>$enameId,"Target"=>$email,"Priority"=>4,'Data'=>array('enameid' => $enameId, 'link' => $link, 'date' => $date)));
					}
					catch (\Exception $e)
					{
						\core\Log::write($e->getMessage().",".$email, 'cronmanage/user', 'accountreport');
					}
				}
				$siteMsgLogic->addMessage(array('EnameId' => $enameId, 'TemplateId' => 'account_report_mail', 'Data' => array('enameid' => $enameId, 'link' => $link, 'date' => $date), 'MessageType' => 6));
			}
			catch (\Exception $e)
			{
				\core\Log::write($e->getMessage(), 'cronmanage/user', 'accountreport');
				continue;
			}
		}
	}

	
	public function delVipLastListAction()
	{
		try
		{
			$redis = \core\RedisLib::getInstance('manage');
			$number = 4;
			for($i=1;$i<=$number;$i++)
			{
				$redis->delete("new_vip_member_list_".date('m',strtotime('-1 months')).'_'.$i);
			}
		} catch (\Exception $e) {
			\core\Log::write("delVipLastList error", 'cronmanage/user', 'accountreport');
		}
	}
	
	/**
	 * 获取vip用户列表写入redis 交易到时候直接调用这个列表获取相关数据 每个月5号使用 5号过户删除相关旧数据
	 * 查询了最近一年每个月的登陆信息基本维持在1-2W之间 直接全表扫一次
	 * 最多放入三个hash里头
	 */
	public function getVipMemberAction()
	{
		try
		{
			set_time_limit(0);
			$redis = \core\RedisLib::getInstance('manage');
			$number = 4;
			$memberMod = new ModBase('user');
			$startTime = date('Y-m-01 00:00:00', strtotime('-1 months'));
			$endTime = date('Y-m-d 23:59:59', strtotime('+1 month', strtotime($startTime))-1);
			$memberSql = "select EnameId from e_member where LastLoginTime>='{$startTime}' and LastLoginTime<='{$endTime}'";
			$memberList = $memberMod->select($memberSql, "", array());
			if(! $memberList)
			{
				exit("not found userlist");
			}
			$allCount = count($memberList);
			\core\Log::write("vipaccount,count,{$allCount}", 'cronmanage/user', 'accountreport');
			$everyHashCount = ceil($allCount/$number)+1;
			foreach($memberList as $memberInfo)
			{
				$enameId = $memberInfo['EnameId'];
				for($i=1;$i<=$number;$i++)
				{
					$hashKey = "new_vip_member_list_".date('m',strtotime('-1 months')).'_'.$i;
					if($redis->hLen($hashKey)<$everyHashCount)
					{
						if(! $redis->hExists($hashKey, $enameId))
						{
							if(!$redis->hSet($hashKey, $enameId, $enameId))
							{
								\core\Log::write("add user to viplist error,{$hashKey},{$enameId}", 'cronmanage/user', 'accountreport');
							}
						}
						break;
					}
				}
			}
		}
		catch (\Exception $e)
		{
			\core\Log::write($e->getMessage(), 'cronmanage/user', 'accountreport');
		}
	}

	private function getLocations($ip, $force = false)
	{
		try
		{
			$logic = new \logic\manage\thrift\IpLogic();
			$result = $logic->getLocation($ip);
			$capitalConfig = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'china_capital_city');
			$capitalCity = $capitalConfig->capitalcity->toArray();
			$location = '';
			$flag = false; // 标志是否中国地区不完整
			if($result['City'] == 'N/A' && $result['Country'] == '中国' && !empty($result['Region']) && $result['Region'] != 'N/A' &&
				 in_array($result['Isp'], array('联通', '电信', '移动'))) // 国家为“中国”,城市为“N/A”的IP全部指向省会城市
			{
				$result['City'] = $capitalCity[$result['Region']];
			}
			if(!empty($result['Country']) && $result['Country'] != 'N/A')
			{
				if($result['Country'] == '中国')
				{
					if(empty($result['Region']) || empty($result['City']) || $result['Region'] == 'N/A' ||
						 $result['City'] == 'N/A') // 国内地址，需要定位到省市 否则''
					{
						// 中国地区无城市的不强制返回空，用于安全警报显示，反之返回''
						if(false == $force)
						{
							return '';
						}
						else
							$flag = true;
					}
				}
				else
				{
					if($result['Country'] == '局域网' || $result['Country'] == '本地地址' || empty($result['Region']) ||
						 $result['Region'] == 'N/A') // 国外，需要定位到区域 否则'' 局域网和本地地址返回也当''
					{
						return '';
					}
				}
				$location .= $result['Country'];
			}
			else
			{
				return ''; // 获取地址失败
			}
			if(!empty($result['Region']) && $result['Region'] != 'N/A')
			{
				$location .= $result['Region'];
			}
			if(!empty($result['City']) && $result['City'] != 'N/A' && $result['Region'] != $result['City'])
			{
				$location .= $result['City'];
				if(!(strpos($result['City'], '自治州') || in_array($result['City'], array('兴安盟', '锡林郭勒盟', '阿拉善盟')) ||
					 strpos($result['City'], '地区')))
				{
					$location .= '市';
				}
			}
			if(true == $flag && true == $force && !empty($result['Isp']) && $result['Isp'] != 'N/A')
			{
				return $location . "-" . $result['Isp'];
			}
			return $location;
		}
		catch(Exception $e)
		{
			return 'wfc'; // 请求异常和请求频率超出限制
		}
	}
}

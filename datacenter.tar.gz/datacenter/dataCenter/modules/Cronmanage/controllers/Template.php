<?php
use \lib\manage\domain\DomainLogsLib as DomainLogsLib;
use core\ModBase;
class TemplateController extends Yaf\Controller_Abstract
{
	/**
	 * 白名单检测
	 */
	public function checkTemplateWhiteAction()
	{
		\core\Log::write('cnnic.cron,定时任务---设置白名单通过或者不通过开始', 'cronmanage/template', 'checkwhite');
		$beforTenDays = date("Y-m-d H:i:s", time() - 10 * 24 * 3600);
		$beforTenHours = date("Y-m-d H:i:s", time() - 10 * 3600);
		$tempLogic = new \logic\manage\domain\CronTemplateLogic();
		$tempLogic->setWhiteCron($beforTenDays, 1);
		sleep(3);
		$tempLogic->setWhiteCron($beforTenHours, 0);
		\core\Log::write('cnnic.cron,定时任务---设置白名单通过或者不通过OVER', 'cronmanage/template', 'checkwhite');
	}

	/**
	 * 白名单过百检测 大概每2小时跑一次
	 */
	public function checkTemplateWhiteTwoAction()
	{
		\core\Log::write('white.cron,定时任务---设置白名单通过开始', 'cronmanage/template', 'checkwhite');
		$tempLogic = new \logic\manage\domain\CronTemplateLogic();
		$tempLogic->setWhiteCron(date("Y-m-d H:i:s", time() - 2 * 3600), 1, true);
		\core\Log::write('white.cron,定时任务---设置白名单通过OVER', 'cronmanage/template', 'checkwhite');
	}
	
	public function uploadNgTempAction()
	{
		$redis = \core\RedisLib::getInstance('manage');
		$len = $redis->lLen('uploadngtemp');
		if(!$len)
		{
			exit("not ng template");
		}
		echo "llen:".$len.",个模板\r\n";
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		for($i=0;$i<20;$i++)
		{
			$info = $redis->lPop('uploadngtemp');
			if(!$info || empty($info['registrantId']) || empty($info['img']))
			{
				continue;
			}
			$uploadData = array('registrantId' => $info['registrantId'], 'img' => $info['img']);
			$uploadInfo = $sdk->execSdkFun(6991, $uploadData);
			$message = $uploadInfo['resultCode'] ==6000 ? "success" : "failed";
			\core\Log::write($info['registrantId'].",".$info['img'][0].",".$message, 'cronmanage/template', 'upngbosstemp');
		}
	}

	/**
	 * zdns资料上传 --处理旧数据
	 */
	public function zdnsUploadFile2Action()
	{
		$size = 500;
		$num = 0;
		set_time_limit(0);
		while(true)
		{
			$limit = ($num * $size) . ',' . $size;
			$sql = "SELECT distinct a.* from e_template_zh a,e_template_ext b WHERE a.CreateTime>'2012-01-01 00:00:00' and a.CreateTime<'2017-02-14 18:00:00' and a.CnStatus=2 and a.TemplateId=b.TemplateId and b.`Status`=2  and b.Registrar=86 order by b.TemplateId desc limit $limit";
			$mod = new ModBase('domain');
			$result = $mod->select($sql, '', array());
			\core\db::closeBeforeConn('domain');
			if(empty($result))
			{
				echo 'not data';
				break;
			}
			foreach($result as $v)
			{
				$ZdnsUploadLib = new lib\manage\domain\ZdnsUploadLib();
				if($ZdnsUploadLib->uploadInfoZdnsWithSoap($v['TemplateId'], $v))
				{
					echo $v['TemplateId'] . 'upload success' . "\r\n";
				}
				else
				{
					echo $v['TemplateId'] . 'upload error' . "\r\n";
				}
			}
			$num++;
		}
		echo 'ok';
	}

	/**
	 * zdns资料上传 --处理新模板
	 */
	public function zdnsUploadFileAction()
	{
		$size = 500;
		$num = 0;
		set_time_limit(0);
		while(true)
		{
			$limit = ($num * $size) . ',' . $size;
			$sql = "SELECT distinct a.* from e_template_zh a,e_template_ext b WHERE a.CreateTime>'2017-02-14 18:00:00' and a.CnStatus=2 and a.TemplateId=b.TemplateId and b.`Status`=2  and b.Registrar=86 order by b.TemplateId desc limit $limit";
			$mod = new ModBase('domain');
			$result = $mod->select($sql, '', array());
			\core\db::closeBeforeConn('domain');
			if(empty($result))
			{
				echo 'not data';
				break;
			}
			foreach($result as $v)
			{
				$ZdnsUploadLib = new lib\manage\domain\ZdnsUploadLib();
				if($ZdnsUploadLib->uploadInfoZdnsWithSoap($v['TemplateId'], $v))
				{
					echo $v['TemplateId'] . 'upload success' . "\r\n";
				}
				else
				{
					echo $v['TemplateId'] . 'upload error' . "\r\n";
				}
			}
			$num++;
		}
		echo 'ok';
	}
	/**
	 * ZDNS 查询WANG审核状态 并通过WANG 绑定 VIP --需部定时跑
	 */
	public function zdnsUpDataAction()
	{
		$size = 500;
		$num = 0;
		set_time_limit(0);
		$templateLib = new \lib\manage\domain\TemplateLib();
		while(true)
		{
			$limit = ($num * $size) . ',' . $size;
			$sql = "SELECT distinct a.TemplateName,a.TemplateId from e_template_zh a,e_template_ext b WHERE a.CreateTime>'2012-01-01 00:00:00'  and (a.CnStatus=2 or a.CnStatus=3)  and  a.TemplateId=b.TemplateId  and (b.`Status`=10 or b.`Status`=30) and b.Registrar=86 order by b.TemplateId desc limit $limit";
			$mod = new ModBase('domain');
			$result = $mod->select($sql, '', array());
			\core\db::closeBeforeConn('domain');
			if(empty($result)) 
			{
				echo 'not data';
				break;
			}
			$registrantIds = array();
			$templateNameToId=array();
			foreach($result as $v)
			{
				$registrantIds[] = $v['TemplateName'] . ',' . 'WANG';
				$templateNameToId[$v['TemplateName']]=$v['TemplateId'];
			}
			$data['RegistrantIds'] = $registrantIds;
			$vspLogic = new \logic\manage\thrift\VspLogic();
			$info = $vspLogic->zdnsRegistrantAuditResultQueryBatch($data);
			if($info)
			{
				foreach($info as $k => $v)
				{
					$set = array();
					if($v == 1) // 审核通过
					{
						\lib\manage\domain\DomainLogsLib::addDomainService($k, 
							array('memo' => 'adddomainservice', 'result' => '审核WANG通过'), 22);
						if($templateLib->setTemplateExt(array('registrar' => 86, 'templateId' => $templateNameToId[$k]), 
							array('newstatus' => '+2')))
						{
							\lib\manage\domain\DomainLogsLib::addDomainService($k, 
								array('memo' => 'adddomainservice', 'result' => 'setTemplateExt更新失败'), 22);
						}
						$this->bangding($k, 'VIP', 32, $k, 'WANG',$templateNameToId[$k]);
						$this->bangding($k, 'CLUB',34, $k, 'WANG',$templateNameToId[$k]);
					}
					else 
						if($v == 3) // 审核不通过
						{
							\lib\manage\domain\DomainLogsLib::addDomainService($k, 
								array('memo' => 'adddomainservice', 'result' => '审核WANG不通过'), 22);
							if($templateLib->setTemplateExt(array('registrar' => 86, 'templateId' => $templateNameToId[$k]), 
								array('newstatus' => '+1')))
							{
								\lib\manage\domain\DomainLogsLib::addDomainService($k, 
									array('memo' => 'adddomainservice', 'result' => 'setTemplateExt更新失败'), 22);
								echo $k . 'WANG审核不通过 TemplateExt更新失败' . "\r\n";
								continue;
							}
							echo $k . 'WANG审核不通过 TemplateExt更新成功' . "\r\n";
							continue;
						}
				}
			}
			$num++;
		}
		echo 'ok';
	}

	private function bangding($registrantId, $tldName, $templateRegistrantId, $passAuditRegistrantId, $passAuditTldName,$templateId)
	{
		// 绑定VIP后缀
		$dataBind['RegistrantId'] = $registrantId;
		$dataBind['TldName'] = $tldName;
		$dataBind['PassAuditRegistrantId'] = $passAuditRegistrantId;
		$dataBind['PassAuditTldName'] = $passAuditTldName;
		$templateLib = new \lib\manage\domain\TemplateLib();
		$vspLogic = new \logic\manage\thrift\VspLogic();
		$vspRes = $vspLogic->zdnsRegistrantBind($dataBind);
		if($vspRes) // 绑定成功
		{
			\lib\manage\domain\DomainLogsLib::addDomainService($registrantId, 
				array('memo' => 'adddomainservice', 'result' => '绑定' . $tldName . '成功'), 22);
			if($templateLib->setTemplateExt(
				array('registrar' => $templateRegistrantId, 'templateId' => $templateId), array('newstatus' => '+2')))
			{
				echo $registrantId . 'WANG审核通过，' . $tldName . '绑定成功,TemplateExt更新失败' . "\r\n";
				\lib\manage\domain\DomainLogsLib::addDomainService($registrantId, 
					array('memo' => 'adddomainservice', 'result' => 'setTemplateExt更新失败'), 22);
				return false;
			}
			echo $registrantId . 'WANG审核通过，' . $tldName . '绑定 TemplateExt更新成功' . "\r\n";
			return true;
		}
		else // 绑定失败
		{
			\lib\manage\domain\DomainLogsLib::addDomainService($registrantId, 
				array('memo' => 'adddomainservice', 'result' => '绑定' . $tldName . '失败'), 22);
			if($templateLib->setTemplateExt(
				array('registrar' => $templateRegistrantId, 'templateId' => $templateId), array('newstatus' => '+1')))
			{
				\lib\manage\domain\DomainLogsLib::addDomainService($registrantId, 
					array('memo' => 'adddomainservice', 'result' => 'setTemplateExt更新失败'), 22);
				echo $registrantId . 'WANG审核通过，绑定' . $tldName . '失败 TemplateExt更新失败' . "\r\n";
				return false;
			}
			echo $registrantId . 'WANG审核通过，绑定' . $tldName . '失败 TemplateExt更新成功' . "\r\n";
			return false;
		}
	}
}

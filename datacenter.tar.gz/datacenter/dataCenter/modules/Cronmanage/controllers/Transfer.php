<?php
use core\Response;
use core\ModBase;
use lib\manage\common\DomainFunLib;
use lib\manage\domain\DomainLogsLib;
class TransferController extends Yaf\Controller_Abstract
{
	
	/**
	 * 域名转出发送确认邮件
	 * 目前只针对（.com .net .org .asia .biz .info .wang .top .中国 .公司 .网络）后缀
	 */
	public function sendTransoutCMailAction()
	{
		$num = 100;//脚本一次处理的条数
		$transoutFoaBeginTime = "2015-06-25 17:00:00";//和前台对应
		$order = mt_rand(0, 1) ? 'desc' : 'asc';
		$base_url= 'http://www.ename.net/transfermail/transferOutVerify';
		$transoutLtd = array('COM','NET','ORG','ASIA','BIZ','INFO','WANG','TOP','中国','公司','网络');
		include_once APP_PATH . '/dataCenter/library/lib/manage/ApiSdk.php';
		$sdk = new \ApiSdk();
		$transoutMod = new \models\manage\domain\DomainTransferOutMod();
		$domainMod = new \models\manage\domain\DomainsMod();
		$transoutInfo = $transoutMod->getTransferInfo(array('Status' => 1, 'CreateTime>' => $transoutFoaBeginTime), 'TransferOutId '.$order, $num);//密码发送成功的
		if(!$transoutInfo)
		{
			\core\Log::write('没有需要发送确认邮件的转出域名', 'cronmanage/transfer', 'sendtransoutcmail');
			exit;
		}
		foreach($transoutInfo as $k => $v)
		{
			$domainInfo = $domainMod->getDomainInfo(array('DomainName' => $v['DomainName']));
			if(!$domainInfo || !in_array(DomainFunLib::getDomainClass($v['DomainName']),$transoutLtd))
			{
				continue;
			}
			$eppData = array('domain' => $v['DomainName'], 'registrarID' => $domainInfo['RegistrarId']);
			if(86 == $domainInfo['RegistrarId'])
			{
				$eppData['password'] = $domainInfo['DomainPassword'];
			}
			$info = $sdk->execSdkFun(5028, $eppData);
			if($info['resultCode'] != 5000 || (isset($info['data']['status']) && strtoupper($info['data']['status']) != 'PENDING'))
			{
				\core\Log::write('域名不是转移状态【'.$v['DomainName'].'】', 'cronmanage/transfer', 'sendtransoutcmail');
				continue;
			}
			$data['enameId'] = $v['EnameId'];
			$data['submitTime'] = $v['CreateTime'];
			$data['domain'] = $v['DomainName'];
			$data['url'] = $base_url.'/'.$v['TransferOutId'].'/'.md5($v['EnameId'].'/'.$v['TransferOutId']);
			$whois = new \interfaces\manage\Whois();
			$whoisMail = $whois->getWhoisHasMail($v['DomainName']);
			if(!$whoisMail || empty($whoisMail['AdministrativeEmail']))
			{
				\core\Log::write('域名转出发送邮箱验证，获取whois邮箱失败【'.$v['DomainName'].'】', 'cronmanage/transfer', 'sendtransoutcmail');
				continue;
			}
			try
			{
				$queueLogic = new \logic\manage\newqueue\QueueLogic();
				$mailData = array('Function' => 'sendmail', 'EnameId' => $v['EnameId'], 'TemplateName' => 'domainTransferOutConfirm', 'Target' => $whoisMail['AdministrativeEmail'], 'Data' => $data, 'Priority' => 5);
				$status = $queueLogic->addQueueNormal($mailData);
			}
			catch (\Exception $e)
			{
				\core\Log::write('发送域名转出确认邮件失败【'.$v['DomainName'].'】【'.$whoisMail['AdministrativeEmail'].'】', 'cronmanage/transfer', 'sendtransoutcmail');
				continue;
			}
			if(!$status)
			{
				\core\Log::write('发送域名转出确认邮件失败【'.$v['DomainName'].'】【'.$whoisMail['AdministrativeEmail'].'】', 'cronmanage/transfer', 'sendtransoutcmail');
				continue;
			}
			$info = $transoutMod->editTransferOut(array('transferOutId' => $v['TransferOutId']), array('status' => '5', 'UpdateTime' => date("Y-m-d H:i:s")));
			if(!$info)
			{
				\core\Log::write('发送域名转出确认邮件成功，但状态修改失败【'.$v['DomainName'].'】', 'cronmanage/transfer', 'sendtransoutcmail');
			}
		}
	}
	/**
	 * 定时任务--检测域名是否转出成功
	 */
	public function  checkTransferOutSuccessAction($params = array())
	{
		try
		{ 
			\core\Log::write('check.out,定时任务--检测域名是否转出成功Start', 'cronmanage/transfer', 'checktransferout');
			$transferOutLib = new \lib\manage\domain\DomainTransferOutLib(0);
			$transferOutLib->transferOutSetSuccess($params);
			\core\Log::write('check.out,定时任务--检测域名是否转出成功OVER', 'cronmanage/transfer', 'checktransferout');
		}
		catch(\Exception $e)
		{
			\core\Log::write('check.out,定时任务--检测域名转出错误信息', 'cronmanage/transfer', 'checktransferout');
		}
	}
}
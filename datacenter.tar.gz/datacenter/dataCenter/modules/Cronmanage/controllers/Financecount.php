<?php
class FinancecountController extends Yaf\Controller_Abstract
{
	/**
	 * app充值相关统计
	 */
	public function paycenteraction()
	{
		$logic = new logic\manage\finance\FinanceLogic();
		$logic->payCenterCount();
	}
}
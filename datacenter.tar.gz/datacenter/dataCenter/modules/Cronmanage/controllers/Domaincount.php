<?php
class DomaincountController extends Yaf\Controller_Abstract
{
	public function domainCountAction()
	{
		$logic = new logic\manage\domain\DomainCountLogic();
		$logic->addDomainCount();
	}
}

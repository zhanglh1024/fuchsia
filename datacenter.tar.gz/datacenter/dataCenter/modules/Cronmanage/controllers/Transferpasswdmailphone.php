<?php

/**
 * 用户控制器
 */
class TransferpasswdmailphoneController extends Yaf\Controller_Abstract
{

	/**
	 * 自动审核
	 * 1=>邮箱修改,2=>修改手机绑定,3=>获取转移密码,4=>找回密码,5=>取消操作保护
	 */
	public function autoCheckAction()
	{
		try
		{
			// 实例化 模型
			$mod = new \models\manage\member\TransferpasswdMailMod();
			// 数据获取条件 等待确认checkStatus 6、更新时间大于7天
			$params = array('checkStatus' => 6, 'endDate' => $_SERVER['REQUEST_TIME'] - 604800);
			$result = $mod->getList($params);
			if(! empty($result))
			{
				// 实例化后台备注模型
				$memberRemarkMod = new \models\manage\member\MemberRemarkMod();
				// 读取后台备注配置
				$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'member');
				$remarkMessage = $conf->user->remark->type->toArray();
				// 备注类型 1对在线取消操作保护的备注 2对在线修改id注册邮箱的备注 3对在线开通短信获取转移密码功能的备注
				// 4对在线找回密码的备注 5对在线修改绑定手机的备注
				$remarkType = array(1 => 2, 2 => 5, 3 => 3, 4 => 4, 5 => 1);
				// 站内信模板id
				$tempaleIds = array(1 => 'regemailFaile', 2 => 'modifyPhoneFaileMessage', 
						3 => 'transferpasswdFaileMessage', 4 => 'findPassword_faile', 5 => 'operateProtectionFail');
				// 失败备注信息
				$remark = '逾期未确认申请失效，请重新提交资料审核。';
				// 实例化 队列
				$queue = new \interfaces\manage\Queue();
				foreach($result as $key => $value)
				{
					// 更新数据
					$params = array('checkStatus' => 3, 'remark' => $remark);
					if(! $mod->updateData($params, $value['id']))
					{
						// 记录日志
						\core\Log::write('id:' . $value['id'] . 'set checkStatus=3 更新失败,', 
							'cronmanage/transferPasswdMailPhone');
						continue;
					}
					
					// 添加后台备注
					$memberRemarkType = $remarkType[$value['type']];
					$params = array('EnameId' => $value['enameId'], 'OperatorId' => 0, 'OperatorName' => '系统', 
							'CreateTime' => date('Y-m-d H:i:s', $_SERVER['REQUEST_TIME']), 'Ip' => '127.0.0.1', 
							'RemarkType' => $memberRemarkType, 
							'Content' => $remarkMessage[$memberRemarkType] . ':' . $remark);
					if(! $memberRemarkMod->addData($params))
					{
						// 记录日志
						\core\Log::write('id:' . $value['id'] . 'set checkStatus=3 更新成功,添加后台日志失败', 
							'cronmanage/transferPasswdMailPhone');
					}
					// 站内信消息
					if($value['type'] == 2 || $value['type'] == 3)
					{
						$data = array("enameId" => $value['enameId'], 'VerifyMessage' => $remark);
					}
					else
					{
						$data = array("enameId" => $value['enameId'], 'remark' => $remark);
					}
					// 发送站内信
					if(! $queue->sendSiteMsg($value['enameId'], $tempaleIds[$value['type']], $data, 6))
					{
						\core\Log::write('id:' . $value['id'] . 'set checkStatus=3 成功，发送站内信失败', 
							'cronmanage/transferPasswdMailPhone');
					}
				}
			}
		}
		catch(Exception $e)
		{
			\core\Log::write($e->getMessage(), 'cronmanage/transferPasswdMailPhone');
		}
	}
}
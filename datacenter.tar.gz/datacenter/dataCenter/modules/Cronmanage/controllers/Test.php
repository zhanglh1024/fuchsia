<?php
class TestController extends Yaf\Controller_Abstract
{
	public function indexAction()
	{
		echo \common\Client::getIp();
	}
	
	/**
	 * 测试go的请求执行，返回值必须echo json
	 */
	public function testcgiAction($params)
	{
		echo json_encode('you got it.');
		error_log(date("Y-m-d H:i:s") . " " . json_encode($params) . "\r\n",3, "/tmp/viyatestgocgi.log");
		exit;
	}
}
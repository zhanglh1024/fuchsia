<?php
use core\ModBase;
class DomainNoticeController extends Yaf\Controller_Abstract
{

	/**
	 * 到期自动续费，当中文cn域名≥500或者英文cn域名>=1500或者国际com和net域名≥3000发送提醒邮件到cw@ename.com
	 * 不含腾讯邮箱域名
	 * 获取当天过期的域名
	 * 外网没有部署
	 */
	public function autoRenewRemindAction()
	{
		try 
		{
			$domainLogic = new \logic\manage\domain\DomainManageLogic();
			$return = $domainLogic->sendAutoRenewNotice();
			if($return['send'] && $return['flag'])
			{
				\core\Log::write('域名到期续费大额数目邮件提醒发送成功', 'auto_renew_notice');
			}
			if($return['send'] && !$return['flag'])
			{
				\core\Log::write($return['data'].'域名到期续费大额数目邮件提醒发送失败', 'auto_renew_notice');
			}
		}
		catch(\Exception $e)
		{
			\core\Log::write($e->getMessage(), 'auto_renew_notice');
		}
	}
	
	/**
	 * 定时任务 域名到期提醒--发送域名到期提醒
	 * 从暂存的文件读取enameid
	 */
	public function dnExpTipAction()
	{
		$thisMonth = date('Ym');
		$thisDay = date('Y-m-d');
		$dnNoticeLogic = new \logic\manage\domain\DomainExpTipLogic();
		$dnLogLib = new \lib\manage\domain\DomainLogsLib();
		\core\Log::write("域名到期提醒开始", 'cronmanage/domainnotice','dn_exp_notice');
		$dnLogLib->addDomainService('exptip.cron', '定时任务---域名到期提醒开始', 53);
		$config = \Yaf\Registry::get("config");
		$filePath = $config->application->logPath;
		$fileDir = $filePath."/cronmanage/domainnotice/".$thisMonth;
		for($i = 1;;$i++)
		{
			if(!file_exists($fileDir."/".$thisDay."_".$i.".log"))
			{
				break;
			}
			$enameIdStr = file_get_contents($fileDir."/".$thisDay."_".$i.".log");
			$enameIdArr = explode(",", $enameIdStr);
			foreach ($enameIdArr as $enameId)
			{
				if(!empty($enameId))
				{
					try 
					{
						\core\Log::write($enameId . ",start", 'cronmanage/domainnotice','domain_exp_bak_enameid');
						$result = $dnNoticeLogic->dnExpTipByEnameId($enameId);
						\core\Log::write($enameId . ",end," . json_encode($result), 'cronmanage/domainnotice','domain_exp_bak_enameid');
					}
					catch (\Exception $e)
					{
						\core\Log::write($e->getMessage(), 'cronmanage/domainnotice','dn_exp_exception');
					}
				}
			}
		}
		\core\Log::write("域名到期提醒结束", 'cronmanage/domainnotice','dn_exp_notice');
		$dnLogLib->addDomainService('exptip.cron', '定时任务---域名到期提醒结束', 53);
	}
	
	/**
	 * 定时任务 域名到期提醒--获取有域名即将到期的enameid
	 * 以文件的形式暂存enameid
	 */
	public function getDnExpEnameIdAction()
	{
		$checkLimit = 30000;//获取enameid时每次获取的次数
		$thisMonth = date('Ym');
		$thisDay = date('Y-m-d');
		$checkTime = date('Y-m-d',strtotime('+30days')).' 15:59:59';
		$dnMod = new ModBase('domain');
		$query = "select count(distinct EnameId) from e_domains where ExpDate<='".$checkTime."'";
		$countResult = $dnMod->getOne($query, '', array());
		if(empty($countResult))
		{
			echo $thisDay."今日无到期域名提醒";
			\core\Log::write("今日无到期域名提醒", 'cronmanage/domainnotice','dn_exp_notice');
			exit();
		}
		\core\Log::write("获取到期域名提醒EnameId开始,Total:".$countResult, 'cronmanage/domainnotice','dn_exp_notice');
		$config = \Yaf\Registry::get("config");
		$filePath = $config->application->logPath;
		$fileDir = $filePath."/cronmanage/domainnotice/".$thisMonth;
		if(!file_exists($fileDir))
		{
			@mkdir($fileDir, 0777, TRUE);
		}
		for($i = 0,$j = 1; $i < $countResult; $i = $i+$checkLimit,$j++)
		{
			$query = "select EnameId from e_domains where ExpDate<='".$checkTime."' group by EnameId order by EnameId asc limit $i,$checkLimit";
			$enameIds = $dnMod->select($query, '', array());
			foreach ($enameIds as $enameInfo)
			{
				file_put_contents($fileDir."/".$thisDay."_".$j.".log", $enameInfo['EnameId'].",", FILE_APPEND);
			}
		}
		\core\Log::write("获取到期域名提醒EnameId结束", 'cronmanage/domainnotice','dn_exp_notice');
	}
	
	/**
	 * 临时根据enameid发送域名到期提醒
	 */
	public function tempDnExpTipAction()
	{
		$dnNoticeLogic = new \logic\manage\domain\DomainExpTipLogic();
		$enameid = array(11000);
		foreach ($enameid as $id)
		{
			echo $id;
			$result = $dnNoticeLogic->dnExpTipByEnameId($id);
		}
	}

	/**
	 * 定时任务 合作接口域名注册成功后通知
	 */
	public function checkDnspodAddAction()
	{
		try
		{ 
			$domainsMod = new models\manage\domain\DomainsMod();
			$domainList = $domainsMod->getDomainList(
				array(
						'regStartDate' => gmdate('Y-m-d H:i:s', time() - 86700), 'regEndDate' => gmdate('Y-m-d H:i:s'), 
						'RegistrarId' => 24
				), '', '', 'DomainName');
			if(! $domainList || ! is_array($domainList))
			{
				echo '没有搜索到新加的dnspod域名';
				\core\Log::write("没有搜索到新加的dnspod域名", 'checkDnspodAdd', 'check_dns_pod_add');
				exit();
			}
			else
			{
				foreach($domainList as $info)
				{
					$request = \common\Common::requestPost('http://ename-reg.dnspod.com', 
						array(
								'domain' => $info['DomainName']
						));
					$request = json_decode($request, TRUE);
					if(FALSE !== $request && isset($request['ret_code']) && 1 == $request['ret_code'])
					{
						\core\Log::write(json_encode(array($info, $request)), 'checkDnspodAdd_suc', 'check_dns_pod_add');
					}
					else
					{
						\core\Log::write(json_encode(array($info, $request)), "checkDnspodAdd_error", 'check_dns_pod_add');
					}
				}
			}
		}
		catch(\Exception $e)
		{
			\core\Log::write($e->getMessage(), "checkDnspodAdd_error", 'check_dns_pod_add');
		}
	}
	
	/**
	 * 域名到期or即将到期提醒到财务，按接口id（注册商）和后缀区分提醒
	 * @param array $params
	 */
	public function expDomainRemindSelfAction($params = array())
	{
		set_time_limit(0);
		try
		{
			if(! isset($params[0]))
			{
				exit('params error.');
			}
			$parm = $params[0];
			switch($parm)
			{
				case 'expAutoRenew':
					// 每月月底当天跑到期自动续费域名的量
					// 到期自动续费，是指域名到期后用户未续费，且域名未进入赎回期的域名，赎回期目前暂定以到期30天来计算。
					// $expTimeBegin = gmdate("Y-m-d", strtotime('-30days')) . '
					// 00:00:00';
					$expTimeBegin = '0000-00-00 00:00:00'; // 改为累计在库
					$expTimeEnd = gmdate("Y-m-d") . ' 23:59:59';
					$title = '已到期在库域名数量提醒';
					break;
				case 'sevenDaysExp':
					// 每天发未来7天域名到期的量
					$expTimeBegin = gmdate("Y-m-d") . ' 00:00:00';
					$expTimeEnd = gmdate("Y-m-d", strtotime('+7days')) . ' 23:59:59';
					$title = '未来7天域名到期域名数量提醒';
					break;
			}
			if(! isset($expTimeBegin))
			{
				exit('expTime error.');
			}
			$sendConfig = array(
					80000 => array('cw@ename.com'), 612463 => array('wangyt@ename.com'), 
					561305 => array('yangyf@ename.com'), 1070509 => array('gaohx@ename.com')); // 需要发送的邮箱
			$dnMod = new ModBase('domain');
			$sql = "select DomainId,DomainLtd,RegistrarId,DomainName,ExpDate from e_domains where DomainId > ? and ExpDate>='{$expTimeBegin}' and ExpDate<='{$expTimeEnd}' limit 500;";
			$domainId = 0;
			$tmpInfo = $sortInfo = array();
			$date = gmdate("Y-m-d");
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'registrar');
			$config = $conf->registrarId->toArray();
			$conf = new \Yaf\Config\Ini(APP_PATH . '/conf/manage.ini', 'domain');
			$dnLtd = $conf->domainLtd->toArray();
			while(true)
			{
				$dnInfo = $dnMod->select($sql, 'i', array($domainId));
				if(! $dnInfo)
				{
					break;
				}
				foreach($dnInfo as $v)
				{
					$domainId = $v['DomainId'];
					$tmpLtd = $v['DomainLtd'];
					if(in_array($v['DomainLtd'], array(1, 2, 6, 21, 22, 23)))
					{
						$tmpLtd = 2;
					}
					elseif(in_array($v['DomainLtd'], array(3, 9)))
					{
						$tmpLtd = 3;
					}
					elseif(in_array($v['DomainLtd'], array(4, 10)))
					{
						$tmpLtd = 4;
					}
					else
					{
						$tmpLtd = $v['DomainLtd'];
					}
					$tmpInfo[$v['RegistrarId']][$tmpLtd] = isset($tmpInfo[$v['RegistrarId']][$tmpLtd]) ? ($tmpInfo[$v['RegistrarId']][$tmpLtd] +
						 1) : 1;
					$sortInfo[$v['RegistrarId']] = isset($sortInfo[$v['RegistrarId']]) ? ($sortInfo[$v['RegistrarId']] +
						 1) : 1;
					$DomainLtd = isset($dnLtd[$tmpLtd])?$dnLtd[$tmpLtd]:$tmpLtd;
					$Registrar = isset($config[$v['RegistrarId']])?$config[$v['RegistrarId']]:$v['RegistrarId'];
					\core\Log::write(
						$DomainLtd . ',' . $Registrar . ',' . $v['DomainName'] . ',' . $v['ExpDate'], 
						'cronmanage/domain/expDomainRemindSelf', $parm . '_' . $v['RegistrarId'] . '_' . $tmpLtd . '_');
				}
			}
			if(! empty($sortInfo))
			{
				
				$queueLogic = new \logic\manage\newqueue\QueueLogic();
				// 针对cn后缀和中英文重新组装避免太多显示不好看
				// 排序max
				arsort($sortInfo);
				// 组装发送内容
				$msg = $title;
				foreach($sortInfo as $regid => $vk)
				{
					$regs = $tmpInfo[$regid];
					$msg .= '<p style="color:red">' . $regid . '接口' .
						 (isset($config[$regid]) ? ' ［注册商：' . $config[$regid] . '］' : '') . '<p>';
					$tmpNum = 0;
					foreach($regs as $tld => $v)
					{
						$msg .= (isset($dnLtd[$tld]) ? $dnLtd[$tld] : $tld) . "：" . $v . "<br>";
						$tmpNum += $v;
					}
					$msg .= "汇总：" . $tmpNum . "<br><br>";
				}
				echo $msg;
				\core\Log::write($msg, 'cronmanage/domain/expDomainRemindSelf', $parm);
				foreach($sendConfig as $k => $v)
				{
					$mailData = array(
							'Function' => 'sendmail', 'TemplateName' => 'any_template_info', 'EnameId' => $k, 
							'Priority' => 5, 'Target' => $v[0], 'Data' => array('content' => $msg, 'title' => $title));
					$queueLogic->addQueueNormal($mailData);
				}
				echo '发送完毕';
			}
		}
		catch(\Exception $e)
		{
			\core\Log::write($e->getMessage(), 'domain_exp_notice_ename');
		}
	}
}
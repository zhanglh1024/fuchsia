<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;
class CategoryController extends Yaf\Controller_Abstract
{
	private $categoryLogic;

	public function init()
	{
		$this->categoryLogic = new logic\portal\category\CategoryLogic();
	}

	/**
	 * 获取栏目列表
	 */
	public function getCategoryAction()
	{
		try
		{
			form\portal\category\CategoryForm::getCategoryForm();
				
			$return = $this->categoryLogic->getCategory(ReturnData::$info);
			if($return)
			{
				Response::success($return);
			}
			Response::error($return);
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 增加栏目
	 */
	public function addCategoryAction()
	{
		try
		{
			form\portal\category\CategoryForm::addCategoryForm();
				
			$return = $this->categoryLogic->addCategory(ReturnData::$info);
			Response::success($return);
			
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 修改栏目
	 */
	public function editCategoryAction()
	{
		try
		{
				
			form\portal\category\CategoryForm::editCategoryForm();
				
			$return = $this->categoryLogic->editCategory(ReturnData::$info);
			Response::success($return);
			
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 删除栏目
	 */
	public function delCategoryAction()
	{
		try
		{
			form\portal\category\CategoryForm::delCategoryForm();
				
			$return = $this->categoryLogic->delCategory(ReturnData::$info->categoryId);
			Response::success($return);
			
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 根据ID获取栏目
	 */
	public function getOneCategoryAction()
	{
		try
		{
			form\portal\category\CategoryForm::getOneCategoryForm();
			$return = $this->categoryLogic->getOneCategory(ReturnData::$info->categoryId);
			if($return)
			{
				Response::success($return);
			}
			Response::error($return);
				
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}
<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;
class AnnounceController extends Yaf\Controller_Abstract
{
	private $accounceLogic;
	
	public function init()
	{
		$this->announceLogic = new logic\portal\announce\AnnounceLogic();
	}
	
	/**
	 * 获取公告列表
	 */
	public function getAnnounceListAction()
	{
		try
		{
			form\portal\announce\AnnounceForm::getAnnounceListForm();
			
			$return = $this->announceLogic->getAnnounceList(ReturnData::$info);
			if($return)
			{
				Response::success($return);
			}
			Response::error($return);
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 增加公告
	 */
	public function addAnnounceAction()
	{
		try
		{
			form\portal\announce\AnnounceForm::addAnnounceForm();
			
			$return = $this->announceLogic->addAnnounce(ReturnData::$info);
			Response::success($return);
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 修改公告
	 */
	public function editAnnounceAction()
	{
		try
		{
			form\portal\announce\AnnounceForm::editAnnounceForm();
			
			$return = $this->announceLogic->editAnnounce(ReturnData::$info);
			Response::success($return);
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 删除公告
	 */
	public function delAnnounceAction()
	{
		try
		{
			form\portal\announce\AnnounceForm::delAnnounceForm();
			
			$return = $this->announceLogic->delAnnounce(ReturnData::$info->announceId);
			Response::success($return);
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 根据ID获取公告
	 */
	
	public function getOneAnnounceAction()
	{
		try
		{
			form\portal\announce\AnnounceForm::getOneAnnounceForm();
			
				$return = $this->announceLogic->getOneAnnounce(ReturnData::$info->announceId);
				if($return)
				{
					Response::success($return);
				}
			Response::error($return);
			
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
}
<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;
class SeoController extends Yaf\Controller_Abstract
{
	private $seoLogic;

	public function init()
	{
		$this->seoLogic = new logic\portal\seo\SeoLogic();
	}

	/**
	 * 获取专题列表
	 */
	public function getSeoAction()
	{
		try
		{
			$return = $this->seoLogic->getSeo();
			if($return)
			{
				Response::success($return);
			}
			Response::error($return);
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 修改专题
	 */
	public function editSeoAction()
	{
		try
		{
			form\portal\seo\SeoForm::editSeoForm();
			$return = $this->seoLogic->editSeo(ReturnData::$info);
			Response::success($return);
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}

	/**
	 * 根据ID或class获取专题
	 */
	public function getOneSeoAction()
	{
		try
		{
			form\portal\seo\SeoForm::getOneSeoForm();
			$return = $this->seoLogic->getOneSeo(ReturnData::$info);
			if($return)
			{
				Response::success($return);
			}
			Response::error($return);
			
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}
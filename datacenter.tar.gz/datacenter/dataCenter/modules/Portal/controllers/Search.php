<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;
class SearchController extends Yaf\Controller_Abstract
{
	private $searchLogic;

	public function init()
	{
		$this->searchLogic = new logic\portal\search\SearchLogic();
	}
	
	/**
	 * 获取索引
	 */
	public function getSearchIndexAction()
	{
		try
		{
			form\portal\search\SearchForm::getSearchIndexForm();		
			$return = $this->searchLogic->getSearchIndex(ReturnData::$info);
			if($return)
			{
				Response::success($return);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取搜索列表
	 */
	public function getSearchListAction()
	{
		try
		{
			form\portal\search\SearchForm::getSearchListForm();
			$return = $this->searchLogic->getSearchList(ReturnData::$info);
			if($return)
			{
				Response::success($return);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}
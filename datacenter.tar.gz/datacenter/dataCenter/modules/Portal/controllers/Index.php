<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class IndexController extends Yaf\Controller_Abstract
{
	/**
	 * demo
	 */
	public function indexAction()
	{
		try
		{
			form\portal\index\IndexForm::checkIndexForm();
			if(ReturnData::$success)
			{
				$indexLogic = new logic\portal\index\IndexLogic();
				$return = $indexLogic->index();
				Response::success($return);
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}

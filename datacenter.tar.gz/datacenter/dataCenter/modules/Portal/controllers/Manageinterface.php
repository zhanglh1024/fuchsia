<?php
use core\Response;
use core\form\FormException;
use core\form\ReturnData;

class ManageInterfaceController extends Yaf\Controller_Abstract
{
	private $manageInterface;
	
	public function init()
	{
		$this->manageInterface = new \interfaces\portal\ManageInterface();
	}
	
	/**
	 * 获取用户购物车和站内信数量
	 */
	public function getUserHeadInfoAction()
	{
		try
		{
			form\portal\manageInterface\ManageInterfaceForm::checkEnameId();
			$msgResult = $this->manageInterface->getSiteMessageCount(ReturnData::$info->enameId);
			$cartResult = $this->manageInterface->getSiteCartCount(ReturnData::$info->enameId);
			if(is_int($msgResult) && is_int($cartResult))
			{
				Response::success(array('msgCount' => $msgResult, 'cartCount' => $cartResult));
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 获取用户头像和昵称信息
	 */
	public function getUserShowInfoAction()
	{
		try
		{
			form\portal\manageInterface\ManageInterfaceForm::checkEnameId();
			$showResult = $this->manageInterface->getUserAppInfo(ReturnData::$info->enameId);
			if(!empty($showResult['flag']))
			{
				Response::success($showResult['msg']);
			}
			Response::error($showResult['msg']);
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
	
	/**
	 * 设置用户管理平台积分
	 */
	public function setManageScoreAction()
	{
		try
		{
			form\portal\manageInterface\ManageInterfaceForm::checkScore();
			$scoreResult = $this->manageInterface->setUserScore(ReturnData::$info);
			if(!empty($scoreResult) && $scoreResult['flag'] == 1)
			{
				Response::success();
			}
			Response::error();
		}
		catch(FormException $e)
		{
			Response::formError($e->getMessage());
		}
		catch(\Exception $e)
		{
			Response::msg($e->getMessage(), $e->getCode());
		}
	}
}
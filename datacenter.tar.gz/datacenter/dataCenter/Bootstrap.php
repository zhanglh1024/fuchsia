<?php

function myExceptionHandler()
{
	$errInfo = error_get_last();
	if($errInfo && is_array($errInfo))
	{
		error_log(date('Y-m-d H:i:s') . var_export($errInfo, TRUE), 3, '/tmp/dataCenter_sys_error' . date('Y-m-d') . ".log");
	}
}
register_shutdown_function('myExceptionHandler');

class Bootstrap extends Yaf\Bootstrap_Abstract
{

	/**
	 * 所有的RPC请求都走index控制器
	 */
	public function _initRoute()
	{
		$router = Yaf\Dispatcher::getInstance()->getRouter();
		$route = new Yaf\Route\Rewrite("/index/:action/", array("controller"=> "index","action"=> "index"));
		$router->addRoute('rpc', $route);
	}

	public function _initConfig()
	{
		date_default_timezone_set('Asia/Shanghai');
		Yaf\Registry::set('config', Yaf\Application::app()->getConfig());
		Yaf\Registry::set('access', new Yaf\Config\Ini(APP_PATH . '/conf/access.ini'));
		Yaf\Registry::set('data', new Yaf\Config\Ini(APP_PATH . '/conf/data.ini'));
		Yaf\Dispatcher::getInstance()->autoRender(FALSE); // 关闭自动加载模板
	}

	public function _initPlugin(Yaf\Dispatcher $dispatcher)
	{
		$yafRequest = new \Yaf\Request\Http();
		if(false === $yafRequest->isCli())
		{
			$dispatcher->registerPlugin(new LogincheckPlugin());
		}
	}
}
